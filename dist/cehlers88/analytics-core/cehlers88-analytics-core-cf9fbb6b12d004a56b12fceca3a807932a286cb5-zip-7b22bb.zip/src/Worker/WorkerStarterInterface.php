<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Worker;

use Cehlers88\AnalyticsCore\Entity\Worker;

/**
 * Starts a worker on behalf of the core - the macro `startWorker` starts through it. Running
 * a worker (the executor, its checks, the journal) is the application's, so the application
 * implements it; without an implementation the macro answers with an error instead.
 */
interface WorkerStarterInterface
{
    /**
     * Queues one run of the worker, now - it need not be due. The run happens later, outside
     * the command that asked for it; a disabled worker or one that is already running is not
     * started.
     */
    public function start(Worker $worker): void;
}
