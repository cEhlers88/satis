<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;

/**
 * Runs a command whose name is only known while the run goes on - read from a variable, a
 * custom object or a switch. A definition names its commands literally, so without this a
 * procedure needs one branch per command it might call.
 *
 * The name must be one of a command row: CommandFactory takes an unknown name for data and
 * would hand it back unrun, which here would look like a command that returned its own name.
 *
 * The arguments are taken as they are (no precompiled arguments) and handed to the command
 * the way a definition would: the command's own policy decides what of them runs first - the
 * branches of an `if`, the `try` of a try_catch must not run before it is even called.
 */
class ExecuteCommandMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    private const string PROPERTY_COMMAND = 'command';
    private const string PROPERTY_ARGUMENTS = 'arguments';

    public function __construct(
        private readonly CommandFactory $commandFactory,
    )
    {
    }

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return $property->name === self::PROPERTY_COMMAND
            ? PropertyUi::create()->placeholder('echo')
            : null;
    }

    public function init(): ExecuteCommandMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_COMMAND, MacroPropertyDTO::TYPE_STRING, 'Name of the command to run'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ARGUMENTS, ['array'], 'The arguments of the command by name', []));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Runs the command a name names - for a command chosen while the run goes on.';
    }

    public function getName(): string
    {
        return 'executeCommand';
    }

    public function needPrecompiledArguments(): bool
    {
        return false;
    }

    protected function run(): ?array
    {
        $commandName = $this->resolve($this->getPropertyValue(self::PROPERTY_COMMAND));
        $commandName = is_scalar($commandName) ? trim((string)$commandName) : '';

        if ($commandName === '') {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'executeCommand needs the name of a command.'));
        }
        if ($this->commandFactory->getCommandByName($commandName) === null) {
            return $this->_createRunResult(null, ErrorDTO::create(404, sprintf('There is no command "%s".', $commandName)));
        }

        $arguments = $this->getPropertyValue(self::PROPERTY_ARGUMENTS);
        if ($arguments instanceof CommandDTO || $arguments instanceof PropertyDTO) {
            // the whole map comes from a command - get_var, json ...
            $arguments = $this->resolve($arguments);
        }

        $command = $this->commandFactory->commandDtoByDefinition([$commandName, []]);
        if ($command === null) {
            return $this->_createRunResult(null, ErrorDTO::create(404, sprintf('There is no command "%s".', $commandName)));
        }

        return $this->_createRunResult($this->getMacroEnvironment()->getCommandPlayer()->run(
            self::withArguments($command, self::arguments($arguments))
        ));
    }

    /** A value that is a command - or a property holding one - run; anything else as it is. */
    private function resolve(mixed $value): mixed
    {
        if ($value instanceof PropertyDTO) {
            $value = $value->value;
        }

        return $value instanceof CommandDTO ? $this->_runCommandDefinition($value) : $value;
    }

    /**
     * The command with the given arguments in place of its defaults - values that are
     * commands stay commands, so the player treats them like those of any definition.
     * A name the command does not declare is kept aside, as a definition would keep it.
     */
    private static function withArguments(CommandDTO $command, array $arguments): CommandDTO
    {
        $command = clone $command;
        $properties = [];
        foreach ($command->properties as $property) {
            if (array_key_exists($property->name, $arguments)) {
                $property = clone $property;
                $property->value = $arguments[$property->name];
                $property->hasSubCommand = $property->value instanceof CommandDTO;
                $property->isDefaultValue = false;
                unset($arguments[$property->name]);
            }
            $properties[] = $property;
        }
        $command->properties = $properties;
        foreach ($arguments as $name => $value) {
            $command->unknownProperties[] = PropertyDTO::create((string)$name, $value);
        }

        return $command;
    }

    /**
     * The arguments as a list by name - an object (a definition decoded without `assoc`) is
     * taken as one, anything else as no arguments at all.
     */
    private static function arguments(mixed $arguments): array
    {
        if (is_object($arguments)) {
            $arguments = get_object_vars($arguments);
        }

        return is_array($arguments) && !array_is_list($arguments) ? $arguments : [];
    }
}
