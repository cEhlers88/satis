<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\ValueSuggestionsInterface;
use Cehlers88\AnalyticsCore\Repository\WorkerRepository;
use Cehlers88\AnalyticsCore\Worker\WorkerStarterInterface;

/**
 * Starts a worker from a command - a procedure can have the import worker run once it has
 * fetched new files, instead of waiting for its interval. The start is only queued: the
 * worker runs afterwards, on its own - a disabled worker or one that is still running does
 * not - so the result says that it was asked to start, not what it did.
 *
 * In the protected mode nothing is started.
 */
class StartWorkerMacro extends AbstractMacro implements PropertyUiProviderInterface, ValueSuggestionsInterface
{
    private const string PROPERTY_WORKER = 'worker';

    public function __construct(
        private readonly WorkerRepository        $workerRepository,
        private readonly ?WorkerStarterInterface $workerStarter = null,
    )
    {
    }

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return $property->name === self::PROPERTY_WORKER
            ? PropertyUi::create()->suggestValuesFromMacro()
            : null;
    }

    /** Every worker by its name - a name that several workers share by their id. */
    public function suggestValues(string $propertyName, array $properties): array
    {
        if ($propertyName !== self::PROPERTY_WORKER) {
            return [];
        }

        $workers = array_filter(
            $this->workerRepository->findAll(),
            static fn(mixed $worker): bool => $worker instanceof Worker && $worker->getId() !== null
        );
        usort($workers, static fn(Worker $left, Worker $right): int
            => [mb_strtolower((string)$left->getName()), $left->getId()] <=> [mb_strtolower((string)$right->getName()), $right->getId()]);

        $nameCounts = array_count_values(array_map(static fn(Worker $worker): string => (string)$worker->getName(), $workers));
        $suggestions = [];

        foreach ($workers as $worker) {
            $name = (string)$worker->getName();
            if ($name === '' || is_numeric($name) || $nameCounts[$name] > 1) {
                // a numeric name would be read as an id
                $suggestions[(string)$worker->getId()] = $name === '' ? '#' . $worker->getId() : $name . ' · #' . $worker->getId();
            } else {
                $suggestions[$name] = '#' . $worker->getId();
            }
        }

        return $suggestions;
    }

    public function init(): StartWorkerMacro
    {
        $this->_source = 'CoreBundle';
        $this->setProperty(MacroPropertyDTO::create(self::PROPERTY_WORKER, [
            MacroPropertyDTO::TYPE_INT,
            MacroPropertyDTO::TYPE_STRING,
        ], 'The name or id of the worker to start'));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Starts a worker now - the run is queued and happens afterwards.';
    }

    public function getName(): string
    {
        return 'startWorker';
    }

    protected function run(): ?array
    {
        if ($this->workerStarter === null) {
            return $this->_createRunResult(null, ErrorDTO::create(501, 'No worker starter is registered in this application.'));
        }

        $nameOrId = $this->getPropertyValue(self::PROPERTY_WORKER);
        $nameOrId = is_scalar($nameOrId) ? trim((string)$nameOrId) : '';
        if ($nameOrId === '') {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'startWorker needs the name or id of a worker.'));
        }

        $worker = $this->findWorker($nameOrId);
        if ($worker === null) {
            return $this->_createRunResult(null, ErrorDTO::create(404, sprintf('There is no worker "%s".', $nameOrId)));
        }

        try {
            $started = $this->runProtectedFragment(
                function () use ($worker): bool {
                    $this->workerStarter->start($worker);

                    return true;
                },
                static fn(): bool => false
            );
        } catch (\Throwable $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(500, $exception->getMessage()));
        }

        return $this->_createRunResult(array_filter([
            'id' => $worker->getId(),
            'name' => $worker->getName(),
            'started' => $started,
            'protectedMode' => $started ? null : true,
        ], static fn(mixed $value): bool => $value !== null));
    }

    private function findWorker(string $nameOrId): ?Worker
    {
        if (ctype_digit($nameOrId)) {
            $worker = $this->workerRepository->find((int)$nameOrId);
            if ($worker instanceof Worker) {
                return $worker;
            }
        }

        $worker = $this->workerRepository->findOneBy(['name' => $nameOrId]);

        return $worker instanceof Worker ? $worker : null;
    }
}
