<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttributeMonitoring;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;

/**
 * The recorded history of a custom object: what the monitorings of its attributes measured
 * (Support\Monitoring) - one series per monitored attribute with its values, the times they
 * were taken and a summary, so a procedure can ask "did the meter rise since yesterday?"
 * without reading the raw statistics.
 *
 * Monitoring keeps every series at its maximal length and fills the front with zeros
 * (timestamp 0) until it is reached; those fillers are no measurements and are left out.
 */
class GetCustomObjectStatisticsMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    private const string PROPERTY_NAME_OR_ID = 'nameOrId';
    private const string PROPERTY_LIMIT = 'limit';

    public function __construct(
        private CustomObjectProvider $_customObjectProvider
    )
    {
    }

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return $property->name === self::PROPERTY_LIMIT
            ? PropertyUi::create()->placeholder('0 = alle Messwerte')
            : null;
    }

    public function init(): GetCustomObjectStatisticsMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME_OR_ID, [
                MacroPropertyDTO::TYPE_INT,
                MacroPropertyDTO::TYPE_STRING
            ], 'Specify the name or id of the custom object'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_LIMIT, MacroPropertyDTO::TYPE_INT, 'Only the latest that many measurements of each series - all of them when 0', 0));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Returns what the monitorings of a custom object measured - per attribute its values, times and a summary.';
    }

    public function getName(): string
    {
        return 'getCustomObjectStatistics';
    }

    protected function run(): ?array
    {
        $nameOrId = $this->getPropertyValue(self::PROPERTY_NAME_OR_ID);
        $nameOrId = is_scalar($nameOrId) ? trim((string)$nameOrId) : '';
        $limit = max(0, (int)$this->getPropertyValue(self::PROPERTY_LIMIT));

        if ($nameOrId === '') {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'getCustomObjectStatistics needs the name or id of a custom object.'));
        }

        $entity = $this->findEntity($nameOrId);
        if ($entity === null) {
            return $this->_createRunResult(null, ErrorDTO::create(404, sprintf('There is no custom object "%s".', $nameOrId)));
        }

        $series = [];
        foreach ($entity->getAttributes() as $attribute) {
            if (!$attribute instanceof CustomEntityAttribute) {
                continue;
            }
            foreach ($attribute->getMonitorings() as $monitoring) {
                if (!$monitoring instanceof CustomEntityAttributeMonitoring) {
                    continue;
                }
                $key = (string)$attribute->getName();
                if (isset($series[$key])) {
                    // a second monitoring of the same attribute - an interval of its own
                    $key .= ' #' . $monitoring->getId();
                }
                $series[$key] = self::series($monitoring, $limit);
            }
        }

        return $this->_createRunResult([
            'id' => $entity->getId(),
            'name' => $entity->getName(),
            'className' => $entity->getClassName(),
            'attributes' => $series,
        ]);
    }

    private function findEntity(string $nameOrId): ?CustomEntity
    {
        $filter = ctype_digit($nameOrId) ? ['id' => (int)$nameOrId] : ['name' => $nameOrId];
        $entity = $this->_customObjectProvider->getCustomEntitiesBy($filter, false)[0] ?? null;

        return $entity instanceof CustomEntity ? $entity : null;
    }

    /**
     * @return array{values: list<mixed>, timestamps: list<int>, count: int, last: mixed, lastAt: ?string, min: int|float|null, max: int|float|null, avg: int|float|null, change: int|float|null, lastRun: ?string}
     */
    private static function series(CustomEntityAttributeMonitoring $monitoring, int $limit): array
    {
        $details = $monitoring->getStatistic()?->getDetails() ?? [];
        $seriesKey = $details['options']['monitoredAttribute'] ?? $monitoring->getAttribute()?->getName();
        $rawValues = is_string($seriesKey) && is_array($details[$seriesKey] ?? null) ? array_values($details[$seriesKey]) : [];
        $rawTimestamps = is_array($details['timestamp'] ?? null) ? array_values($details['timestamp']) : [];

        // the series are aligned from their end - both are trimmed and filled to the same length
        $offset = count($rawTimestamps) - count($rawValues);
        $values = [];
        $timestamps = [];
        foreach ($rawValues as $index => $value) {
            $timestamp = (int)($rawTimestamps[$index + $offset] ?? 0);
            if ($timestamp <= 0) {
                continue;
            }
            $values[] = $value;
            $timestamps[] = $timestamp;
        }
        if ($limit > 0 && count($values) > $limit) {
            $values = array_slice($values, -$limit);
            $timestamps = array_slice($timestamps, -$limit);
        }

        $numbers = array_values(array_filter($values, static fn(mixed $value): bool => is_int($value) || is_float($value)));
        $last = $values === [] ? null : $values[array_key_last($values)];

        return [
            'values' => $values,
            'timestamps' => $timestamps,
            'count' => count($values),
            'last' => $last,
            'lastAt' => $timestamps === [] ? null : date(DATE_ATOM, $timestamps[array_key_last($timestamps)]),
            'min' => $numbers === [] ? null : min($numbers),
            'max' => $numbers === [] ? null : max($numbers),
            'avg' => $numbers === [] ? null : array_sum($numbers) / count($numbers),
            // from the first to the last measurement - "how much did it rise"
            'change' => count($numbers) < 2 ? null : $numbers[count($numbers) - 1] - $numbers[0],
            'lastRun' => $monitoring->getLastRun()?->format(DATE_ATOM),
        ];
    }
}
