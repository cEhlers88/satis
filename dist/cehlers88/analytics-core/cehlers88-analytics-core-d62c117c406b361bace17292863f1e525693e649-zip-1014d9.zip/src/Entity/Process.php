<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\DTO\QuickInfoDTO;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Process\DTO\ResultWorkerDefinitionDTO;
use Cehlers88\AnalyticsCore\Process\DTO\StartInfoDTO;
use Cehlers88\AnalyticsCore\Repository\ProcessRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ProcessRepository::class)]
class Process extends AbstractRunnableEntity
{
    public const DETAILS_KEY_START_INFO = 'start_info';
    public const DETAILS_KEY_STATE_HISTORY = 'state_history';
    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(length: 255)]
    private ?string $description = null;

    #[ORM\Column(nullable: true)]
    private ?array $details = null;

    #[ORM\Column(
        name: 'sort',
        type: 'integer',
        nullable: false,
        insertable: false,
        updatable: false,
        columnDefinition: "INT GENERATED ALWAYS AS (
        CASE
            WHEN (state & 8192) <> 0 AND (state & 16) <> 0 THEN 745
            WHEN (state & 8192) <> 0 AND (state & 8) <> 0 THEN 735
            WHEN (state & 8192) <> 0 AND (state & 2) <> 0 THEN 725
            WHEN (state & 8192) <> 0 AND (state & 1) <> 0 THEN 723
            WHEN (state & 8192) <> 0 AND (state & 4) <> 0 THEN 720
            WHEN (state & 8192) <> 0 THEN 700
            WHEN (state & 1024) <> 0 THEN 600
            WHEN (state & 64) <> 0 THEN 400
            WHEN (state & 8) <> 0 THEN 350
            WHEN (state & 512) <> 0 THEN 270
            WHEN (state & 2) <> 0 THEN 250
            WHEN (state & 1) <> 0 THEN 230
            WHEN (state & 16) <> 0 AND (state & 8192) = 0 THEN 210
            WHEN (state & 4) <> 0 THEN 200
            WHEN (state & 4096) <> 0 THEN 10
            ELSE 100
        END
    ) STORED",
        generated: 'ALWAYS'
    )]
    private ?int $sort = null;

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getRunnerAttributeValue(string $attribute, mixed $defaultValue = null): mixed
    {
        $aruments = $this->getStartInfo()->runner_arguments ?? [];
        $result = $aruments[$attribute] ?? $defaultValue;
        return $result;
    }

    /**
     * Retrieves the start information from the details.
     *
     * If no details are available, returns a new `StartInfoDTO` instance when
     * the `$subKey` parameter is null. Otherwise, returns null for an undefined sub-key.
     *
     * If `$subKey` is provided, attempts to retrieve the specified sub-key
     * from the `start_info` array within the details.
     *
     * If `$subKey` is not provided, returns a `StartInfoDTO` instance created
     * from the `start_info` array within the details.
     *
     * @param string|null $subKey Optional. The specific sub-key of the `start_info` to retrieve.
     * @return mixed The corresponding value of the sub-key, a `StartInfoDTO` instance, or null if unavailable.
     */
    public function getStartInfo(?string $subKey = null): mixed
    {
        $details = $this->getDetails();
        if ($details === null) {
            return is_null($subKey) ? new StartInfoDTO() : null;
        }

        if (!is_null($subKey)) {
            return $details[self::DETAILS_KEY_START_INFO][$subKey] ?? null;
        }

        return StartInfoDTO::createFromArray($details[self::DETAILS_KEY_START_INFO] ?? []);
    }

    public function getDetails(): ?array
    {
        return $this->details;
    }

    public function setDetails(?array $details): static
    {
        $this->details = $details;

        return $this;
    }

    /**
     * Retrieves the runner class from the start information.
     *
     * @return string|null Returns the runner class if available, or null if it is not set or empty.
     */
    public function getRunnerClass(): ?string
    {
        /** @var StartInfoDTO $startInfo */
        $startInfo = $this->getStartInfo();

        return empty($startInfo->runner) ? null : $startInfo->runner;
    }

    public function getResultWorkerDefinition(): ?ResultWorkerDefinitionDTO
    {
        $defArray = $this->getDetails()['result_worker'] ?? null;

        if ($defArray === null) {
            return null;
        }

        return ResultWorkerDefinitionDTO::createFromArray($defArray);
    }

    /**
     * Sets the runner class in the start information and updates the start information.
     *
     * @param string $runnerClass The runner class to be set.
     * @return static Returns the current instance after updating the start information.
     */
    public function setRunnerClass(string $runnerClass): static
    {
        /** @var StartInfoDTO $startInfo */
        $startInfo = $this->getStartInfo();
        $startInfo->runner = $runnerClass;

        return $this->setStartInfo($startInfo);
    }

    public function setStartInfo(StartInfoDTO $startInfo): static
    {
        $this->details[self::DETAILS_KEY_START_INFO] = $startInfo->toArray();
        return $this;
    }

    public function getSort(): ?int
    {
        return $this->sort;
    }

    public function getQuickInfo(): QuickInfoDTO
    {
        $result = parent::getQuickInfo();
        $result->message = 'Process ';

        if ($this->hasState(eRunningState::BufferComplete)) {
            if ($this->hasState(eRunningState::WillStart)) {
                $result->percentage = 40;
            } else {
                $result->percentage = 30;
            }
        } else if ($this->hasState(eRunningState::Running)) {
            $result->percentage = 45;
        } else if ($this->hasState(eRunningState::WillStart)) {
            $result->percentage = 10;
        } else if ($this->hasState(eRunningState::Finished)) {
            $result->percentage = 100;
        } else if ($this->hasState(eRunningState::Finishing)) {
            $result->percentage = 80;
        } else if ($this->hasState(eRunningState::Buffering)) {
            $result->percentage = 20;
        }

        return $result;
    }

    public function addStateToHistory(?eRunningState $state = null): static
    {
        if (is_null($state)) {
            $state = $this->getState();
        }

        if (!isset($this->details[self::DETAILS_KEY_STATE_HISTORY])) {
            $this->details[self::DETAILS_KEY_STATE_HISTORY] = [];
        }

        $this->details[self::DETAILS_KEY_STATE_HISTORY][] = [
            new \DateTimeImmutable(), $state->value
        ];

        return $this;
    }

    public function getStateHistory(): array
    {
        return $this->details[self::DETAILS_KEY_STATE_HISTORY] ?? [];
    }
}
