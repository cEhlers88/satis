<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\DTO\QuickInfoDTO;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

class AbstractRunnableEntity extends AbstractEntity
{
    #[ORM\Column(type: Types::BIGINT)]
    protected ?string $state = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    protected ?\DateTimeInterface $startedAt = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    protected ?\DateTimeInterface $finishedAt = null;

    #[ORM\Column]
    protected ?bool $enabled = null;

    public function __construct()
    {
        parent::__construct();
        $this->setState(eRunningState::New);
    }

    public function addState(eRunningState ...$states): static
    {
        $current = $this->state !== null
            ? (int)$this->state
            : eRunningState::Unknown->value;

        foreach ($states as $state) {
            if ($state === eRunningState::Unknown) {
                continue;
            }

            if ($current === eRunningState::Unknown->value) {
                $current = $state->value;
            } else {
                $current |= $state->value;
            }
        }

        $this->state = (string)$current;

        return $this;
    }

    public function getStartedAt(): ?\DateTimeInterface
    {
        return $this->startedAt;
    }

    public function setStartedAt(?\DateTimeInterface $startedAt): static
    {
        $this->startedAt = $startedAt;

        return $this;
    }

    public function getFinishedAt(): ?\DateTimeInterface
    {
        return $this->finishedAt;
    }

    public function setFinishedAt(?\DateTimeInterface $finishedAt): static
    {
        $this->finishedAt = $finishedAt;

        return $this;
    }

    /**
     * @return eRunningState[]
     */
    public function getState(): array
    {
        $value = $this->state ?? eRunningState::Unknown->value;

        if ($value === eRunningState::Unknown->value) {
            return [eRunningState::Unknown];
        }

        $result = [];

        foreach (eRunningState::cases() as $case) {
            if ($case === eRunningState::Unknown) {
                continue;
            }

            if ($value & $case->value) {
                $result[] = $case;
            }
        }

        return $result;
    }

    /**
     * @param eRunningState ...$states
     * @return $this
     */
    public function setState(eRunningState ...$states): static
    {
        if ($states === []) {
            $this->state = eRunningState::Unknown->value;
            return $this;
        }

        $value = 0;

        foreach ($states as $state) {
            if ($state === eRunningState::Unknown) {
                continue;
            }

            $value |= $state->value;
        }

        $this->state = $value === 0 ? eRunningState::Unknown->value : $value;

        return $this;
    }

    public function getStateValue(): int
    {
        return (int)($this->state ?? eRunningState::Unknown->value);
    }

    public function isWaiting(): bool
    {
        return $this->isEnabled() && $this->getNextRunAt() !== null && $this->getNextRunAt() < new \DateTimeImmutable();
    }

    public function isEnabled(): bool
    {
        return $this->enabled ?? false;
    }

    public function removeState(eRunningState ...$states): static
    {
        $current = $this->state ?? eRunningState::Unknown->value;

        foreach ($states as $state) {
            if ($state === eRunningState::Unknown) {
                continue;
            }

            $current &= ~$state->value;
        }

        if ($current === 0) {
            $current = eRunningState::Unknown->value;
        }

        $this->state = $current;

        return $this;
    }

    public function setEnabled(bool $enabled): static
    {
        $this->enabled = $enabled;

        return $this;
    }

    public function setStateValue(int $value): static
    {
        $this->state = (string)$value;
        return $this;
    }

    public function getQuickInfo(): QuickInfoDTO
    {
        $result = new QuickInfoDTO();

        $result->hasError = $this->hasState(eRunningState::Error) || $this->hasState(eRunningState::FatalError);
        $result->hasWarning = $this->hasState(eRunningState::Suspicious);

        return $result;
    }

    public function hasState(eRunningState $state): bool
    {
        $current = (int)($this->state ?? eRunningState::Unknown->value);
        return ($current & $state->value) !== 0;
    }

    /**
     * Adds a state to the history.
     *
     * @param eRunningState|null $state The state to add, or null to add the current state.
     * @return $this
     */
    public function addStateToHistory(?eRunningState $state = null): static
    {
        return $this;
    }

    public function getStateHistory(): array
    {
        return [];
    }
}