<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ProcessView;

class ProcessAssembler extends AbstractAssembler
{
    public function one(EntityInterface|Process $entity): ProcessView
    {
        $details = $entity->getDetails();
        $buffer = new ProcessView(
            id: $entity->getId(),
            name: $entity->getName(),
            resultWorkerName: isset($details['result_worker']) ? $details['result_worker']['worker'] : '',
            runnerName: $details['start_info']['runner'],
            state: $entity->getState()
        );

        $buffer->quickInfo = $entity->getQuickInfo();

        return $buffer;
    }
}