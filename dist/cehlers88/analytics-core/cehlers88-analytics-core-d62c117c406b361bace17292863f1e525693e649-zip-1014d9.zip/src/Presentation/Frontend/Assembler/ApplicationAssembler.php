<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ApplicationView;


class ApplicationAssembler extends AbstractAssembler
{
    public function one(EntityInterface|Application $entity): ApplicationView
    {
        $buffer = new ApplicationView(
            id: $entity->getId(),
            name: $entity->getName()
        );

        $buffer->badge = BadgeDTO::create(
            $entity->getName(),
            $entity->getColor()
        );

        return $buffer;
    }
}