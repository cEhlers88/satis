<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\DTO\QuickInfoDTO;

class ProcessView implements ViewInterface
{
    public QuickInfoDTO $quickInfo;
    public string $stateString = '';

    public function __construct(
        public int    $id,
        public string $name,
        public string $resultWorkerName,
        public string $runnerName,
        public array  $state
    )
    {
        $this->quickInfo = new QuickInfoDTO();
        $this->stateString = implode(', ', array_map(fn($e) => $e->name, $this->state));
    }
}