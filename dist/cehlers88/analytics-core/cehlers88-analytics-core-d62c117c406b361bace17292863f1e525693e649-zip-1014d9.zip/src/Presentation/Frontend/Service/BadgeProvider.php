<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Service;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

class BadgeProvider
{
    /**
     * @param eRunningState[] $eRunningStates
     * @return BadgeDTO[]
     */
    public function getBadgesByRunningStates(array $eRunningStates): array
    {
        $buffer = [];

        foreach ($eRunningStates as $state) {
            switch ($state) {
                case eRunningState::WillStart:
                    $buffer[] = BadgeDTO::create('Will start', '#c7820f');
                    break;
                case eRunningState::Finished:
                    $buffer[] = BadgeDTO::create('Finished', '#c7820f');
                    break;

                default:
                    $buffer[] = BadgeDTO::create($state->name, '#999999');
                    break;
            }
        }

        return $buffer;
    }
}