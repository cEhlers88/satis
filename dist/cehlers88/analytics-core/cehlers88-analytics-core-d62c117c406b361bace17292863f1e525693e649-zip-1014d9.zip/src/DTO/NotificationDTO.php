<?php

namespace Cehlers88\AnalyticsCore\DTO;

class NotificationDTO extends DTO
{

}