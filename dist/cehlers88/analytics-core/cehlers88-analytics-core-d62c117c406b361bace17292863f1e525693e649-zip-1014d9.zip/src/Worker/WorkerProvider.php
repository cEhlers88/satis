<?php

namespace Cehlers88\AnalyticsCore\Worker;

use Analytics\ApplicationContext;
use Analytics\ENUM\eWorkerCounterKey;
use Analytics\Logger\SimpleConsoleLogger;
use Analytics\MacroEnvironment;
use Analytics\Message\StartHandleWorkerErrorMessage;
use Analytics\Provider\WorkerJobProvider;
use Analytics\Utils\UnitUtils;
use Cehlers88\AnalyticsCore\Entity\RunChain;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\Repository\WorkerJournalRepository;
use Cehlers88\AnalyticsCore\Repository\WorkerRepository;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Cehlers88\AnalyticsCore\Worker\Observer\Message\WorkerErrorObserverMessage;
use Cehlers88\AnalyticsCore\Worker\Observer\Message\WorkerFinishedObserverMessage;
use Cehlers88\AnalyticsCore\Worker\Observer\Message\WorkerStartedObserverMessage;
use Symfony\Component\DependencyInjection\Attribute\AutowireIterator;
use Symfony\Component\Messenger\MessageBusInterface;

class WorkerProvider
{
    private bool $_debugMode = false;
    private LoggerInterface $_logger;
    private ?RunChain $runChain = null;

    /**
     * WorkerProvider constructor.
     * @param iterable<WorkerInterface> $workers
     * @param MacroEnvironment $macroEnvironment
     * @param WorkerRepository $workerRepository
     * @param WorkerJournalRepository $workerJournalRepository
     * @param MessageBusInterface $messageBus
     */
    public function __construct(
        #[AutowireIterator('worker')]
        private iterable                $workers,
        private ApplicationContext      $applicationContext,
        private MacroEnvironment        $macroEnvironment,
        private WorkerRepository        $workerRepository,
        private WorkerJobProvider       $workerJobProvider,
        private WorkerJournalRepository $workerJournalRepository,
        private MessageBusInterface     $messageBus,
        private ObserverProvider        $observerProvider,
    )
    {
        $this->_logger = new SimpleConsoleLogger();
    }

    public function enableDebugMode(bool $enable = true): static
    {
        $this->_debugMode = $enable;
        return $this;
    }

    public function getUnrelatedWorkers(): array
    {
        $buffer = [];
        foreach ($this->getWorkers() as $worker) {
            $buffer[] = [
                'hasEntity' => true,
                'name_entity' => $worker->getName(),
                'has_worker' => false,
                'name_worker' => $worker->getWorkerClass()
            ];
        }

        foreach ($this->getWorkerClasses() as $worker) {
            $found = false;
            for ($i = 0; count($buffer) > $i; $i++) {
                if ($buffer[$i]['name_worker'] === get_class($worker)) {
                    $buffer[$i]['has_worker'] = true;
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $buffer[] = [
                    'hasEntity' => false,
                    'name_entity' => '',
                    'has_worker' => true,
                    'name_worker' => get_class($worker)
                ];
            }
        }
        $result = [];
        foreach ($buffer as $entry) {
            if (!$entry['hasEntity'] || !$entry['has_worker']) {
                $result[] = $entry;
            }
        }
        return $result;
    }

    public function getWorkers($applicationIdFilters = [], bool $returnInstance = false): array
    {
        return array_reduce(
            (count($applicationIdFilters) === 0 ? $this->workerRepository->findAll() : $this->workerRepository->findBy_applicationIds($applicationIdFilters)),
            function ($carry, $workerEntity) use ($applicationIdFilters, $returnInstance) {
                $carry[] = $returnInstance ? $this->getWorkerInstanceByEntityId($workerEntity->getId()) : $workerEntity;
                return $carry;
            },
            []
        );
    }

    public function getWorkerInstanceByEntityId(int $workerId): ?AbstractWorker
    {
        $workerEntity = $this->workerRepository->find($workerId);
        return $this->getWorkerInstanceByName($workerEntity->getWorkerClass());
    }

    public function getWorkerInstanceByName(string $workerName): ?AbstractWorker
    {
        foreach ($this->workers as $worker) {
            if ($worker->getName() === $workerName) {
                $worker->setMacroPlayer($this->macroEnvironment->getMacroPlayer());
                return $worker;
            }
        }
        return null;
    }

    public function getWorkerClasses(): iterable
    {
        return $this->workers;
    }

    public function getWorkerById(int $workerId): ?Worker
    {
        return $this->workerRepository->find($workerId);
    }

    public function executeWorker(int $workerId, ?LoggerInterface $logger = null, $doRunnableChecks = true): void
    {
        if (!is_null($logger)) {
            $this->_logger = $logger;
        }

        $workerEntity = $this->workerRepository->find($workerId);
        $this->_executeWorker($workerEntity, $doRunnableChecks);
    }

    private function _executeWorker(Worker $workerEntity, bool $doRunableChecks = true): bool
    {
        if ($doRunableChecks && !$this->_checkWorkerIsRunnable($workerEntity)) {
            return false;
        }

        $startMemory = memory_get_usage(true);
        $startPeakMemory = memory_get_peak_usage(true);
        $startTime = microtime(true);

        $this->macroEnvironment->setApplication($workerEntity->getApplication());
        $workerInstance = $this->getWorkerInstanceByName($workerEntity->getWorkerClass());
        if (is_null($workerInstance)) {
            $this->_logger->info('Ignoring worker ' . $workerEntity->getName() . ' because it is not a valid worker (class not found)');
            return false;
        }

        if (is_null($workerInstance)) {
            return false;
        }

        $workerInstance->init($workerEntity, $this->_logger, $this->_debugMode);
        $workerInstance->loadPropertyValues($workerEntity->getProperties(), true);

        if ($doRunableChecks) {
            if (!$workerInstance->allowRun()) {
                $this->_logInfo(sprintf('Worker %s is not allowed to run', $workerEntity->getName()), true);
                return false;
            }
        }

        $this->_logInfo(sprintf('<Worker id="%d" worker-name="%s" application="%d" class-name="%s" version="%s">',
            $workerEntity->getId(),
            $workerEntity->getName(),
            $workerEntity->getApplication()->getId(),
            $workerInstance->getName(),
            $workerInstance->getVersion()
        ));
        if ($workerEntity->hasState(eRunningState::Maintenance)) {
            $this->_logger->warning('Worker is in maintenance mode.');
        }
        $this->workerRepository->setWorkerStarted($workerEntity, true);

        $this->observerProvider->dispatch(new WorkerStartedObserverMessage(
            $workerInstance,
            $workerEntity
        ));

        $workerResult = new WorkerResultDTO();

        $currentAction = "";
        try {
            foreach ($workerInstance->getRequiredJobs() as $requiredJob) {
                $currentAction = 'add job "' . $requiredJob . '"';
                $workerInstance->addJob($this->workerJobProvider->getJobByName($requiredJob));
            }
            $currentAction = 'configure worker';
            $workerInstance->configure($workerEntity->getProperties());
            $currentAction = 'execute worker';
            $workerResult = $workerInstance->execute();
        } catch (\Throwable $e) {
            $workerResult->error = $e->getMessage();
            $this->_setError(
                'WorkerProvider',
                'Error while ' . $currentAction,
                $e,
                $workerEntity
            );
        }

        try {
            $startFinishingAt = microtime(true);
            $workingObjectsCount = $workerResult->workerInfos[WorkerResultDTO::KEY_WORKING_OBJECTS_COUNT];

            $runtime = microtime(true) - $startTime;
            $peakMemory = memory_get_peak_usage(true);
            $usedMemoryBytes = max(0, $peakMemory - $startMemory);
            $formattedUsedMemory = UnitUtils::bytesToHuman($usedMemoryBytes);

            $newState = $workerInstance->reachedTimeout() ? eRunningState::Timeout : eRunningState::Finished;
            $newState = !empty($workerResult->error) ? eRunningState::Error : $newState;

            $newStateValue = ($workingObjectsCount === 0 ? eRunningState::NoWork->value + $newState->value : $newState->value);

            $appStartTime = $this->applicationContext->getStartTime();
            $nextStartTime = new \DateTime($appStartTime->format('Y-m-d H:i:s'));

            if (!$workerResult->timedOut) {
                $nextStartTime->add(new \DateInterval($workerEntity->getRunInterval()));
            }
            $workerEntity->setNextRunAt($nextStartTime);

            $this->workerRepository->setWorkerFinished(
                $workerEntity,
                $workerResult,
                $newStateValue,
                true
            );

            if (!empty($workerResult->error)) {
                $this->_logger->error('Worker ' . $workerEntity->getName() . ' finished with error: ' . $workerResult->error);
            }

            if ($workingObjectsCount > 0 || $newState === eRunningState::Error) {
                $this->workerJournalRepository->addWorkerResult($workerEntity, $workerResult);
            }

            if (($newState->value & eRunningState::Error->value) === eRunningState::Error->value) {
                $this->messageBus->dispatch(new StartHandleWorkerErrorMessage(
                    $workerResult->error,
                    $workerEntity->getId()
                ));
            }

            $this->_logger->info(sprintf('</Worker name="%s" new-state="%s" duration="%s" finish-duration="%s" used-memory="%s" has-error=%s working-objects-count=%d>',
                $workerEntity->getName(),
                implode(',', array_map(fn($state) => $state->name, $workerEntity->getState())),
                UnitUtils::formatDuration($runtime, 's'),
                UnitUtils::formatDuration(microtime(true) - $startFinishingAt, 's'),
                $formattedUsedMemory,
                (!empty($workerResult->error) ? 'true' : 'false'),
                $workingObjectsCount
            ));

            $this->observerProvider->dispatch(new WorkerFinishedObserverMessage(
                $workerInstance,
                $workerEntity,
                [
                    'appStartTime' => $appStartTime->format('d.m.Y | H:i:s'),
                    'workerInterval' => $workerEntity->getRunInterval(),
                    'duration' => $workerResult->runtime,
                    'finishingDuration' => microtime(true) - $startFinishingAt,
                    'state' => $newState,
                    'formatedNextRunAt' => $workerEntity->getNextRunAt()->format('d.m.Y | H:i:s'),
                ]
            ));
        } catch (\Throwable $e) {
            $this->_setError(
                'WorkerProvider',
                '"' . $e->getMessage() . '" while save worker result',
                $e,
                $workerEntity
            );
        }

        return true;
    }

    private function _checkWorkerIsRunnable(Worker $workerEntity): bool
    {
        if ($workerEntity->hasState(eRunningState::Running)) {
            $this->_logInfo('Ignoring worker ' . $workerEntity->getName() . ' because it is already running', true);
            return false;
        }

        if (!$workerEntity->isEnabled()) {
            $this->_logInfo('Ignoring worker ' . $workerEntity->getName() . ' because it is disabled', true);
            return false;
        }

        if (!is_null($workerEntity->getNextRunAt()) && $workerEntity->getNextRunAt() > new \DateTime()) {
            $this->_logInfo('Ignoring worker ' . $workerEntity->getName() . ' because it is not due to run', true);
            return false;
        }

        return true;
    }

    private function _logInfo(string $message, bool $requireDebugMode = false): void
    {
        if ($requireDebugMode === true && !$this->_debugMode) return;
        $this->_logger->info($message);
    }

    /**
     * @param Worker|null $workerEntity
     * @param int $code
     * @param array|\Exception $details
     * @param bool $isFatal
     */
    private function _setError(
        string     $source,
        string     $message,
        \Throwable $details,
        Worker     $workerEntity = null,
        int        $code = 0,
        bool       $isFatal = false,
    )
    {
        $extendedMessage = sprintf('%sError in %s: "%s"', ($isFatal ? 'Fatal-' : ''), $source, $message);
        $this->_logger->warning($extendedMessage);

        $errorDetails = [
            'exceptionTrace' => $details->getTraceAsString(),
        ];

        $this->observerProvider->dispatch(new WorkerErrorObserverMessage(
            $workerEntity,
            $errorDetails
        ));

        if ($isFatal) {
            $workerEntity
                ->setState(eRunningState::FatalError)
                ->incrementCounter(eWorkerCounterKey::FAILED);
        } else {
            if ($workerEntity->getRestRetries() === 0) {
                $this->_setError('WorkerProvider', 'Worker has no retries left', $details, $workerEntity, 0, true);
                return;
            }
            $workerEntity
                ->addState(eRunningState::Error)
                ->incrementCounter(eWorkerCounterKey::FAILED);
        }
        try {
            $this->workerRepository->save($workerEntity, true);
            $this->workerJournalRepository->addWorkerResult($workerEntity, WorkerResultDTO::createFromException($details));
        } catch (\Throwable $e) {
            $this->_logger->error('Error while save worker error: ' . $e->getMessage());
        }

        $this->messageBus->dispatch(new StartHandleWorkerErrorMessage(
            $details->getMessage(),
            $workerEntity->getId()
        ));
    }

    public function executeWorkersByPriorityLevel(int $priorityLevel, LoggerInterface $logger): void
    {
        $this->_logger = $logger;

        $workers = $this->workerRepository->findBy_priority($priorityLevel, $this->runChain);
        if (count($workers) === 0) {
            $logger->warning('No workers found for priority level ' . $priorityLevel);
            return;
        }

        $logger->info('Start worker execution (' . count($workers) . ' with priority = ' . $priorityLevel . ')');

        foreach ($workers as $workerEntity) {
            $this->_executeWorker($workerEntity);
        }
    }

    public function executeWaitingWorkers(): array
    {
        $totalExecutedWorkers = 0;
        $result = [];
        while (true) {
            $workers = $this->workerRepository->fetchWaitingWorkers($this->runChain, $result);

            if (count($workers) === 0) {
                if ($totalExecutedWorkers === 0) {
                    $this->_logInfo('No waiting workers found', true);
                } else {
                    $this->_logger->removeTabSpace(3);
                    $this->_logInfo(sprintf('</ExecutionCycle executed-workers=%d>', $totalExecutedWorkers));
                }
                return $result;
            }

            $executedAnyInThisRound = false;

            if ($totalExecutedWorkers === 0) {
                $this->_logInfo(sprintf('<ExecutionCycle execute-workers=%d>', count($workers)));
                $this->_logger->addTabSpace(3);
            }

            foreach ($workers as $workerEntity) {
                if ($totalExecutedWorkers === 0) {
                    $this->_logInfo(sprintf('<env %s/>',$this->applicationContext->getInfoString()));
                }

                $workerExecutionResult = false;
                try {
                    $workerExecutionResult = $this->_executeWorker($workerEntity);
                } catch (\Exception $e) {
                    $this->_setError('WorkerProvider', 'Error while execute worker', $e, $workerEntity);
                }

                if ($workerExecutionResult) {
                    $result[] = $workerEntity;
                    $totalExecutedWorkers++;
                    $executedAnyInThisRound = true;
                    break;
                }

                $this->_logger->info(sprintf('Worker %s skipped (currently not runnable).', $workerEntity->getName()));
                $this->_logger->removeTabSpace(3);
            }

            if (!$executedAnyInThisRound) {
                $this->_logger->info('No more runnable workers found in current waiting list.');
                break;
            }
        }
        return $result;
    }

    public function setLogger(LoggerInterface $logger): static
    {
        $this->_logger = $logger;
        return $this;
    }

    public function setActiveRunChain(RunChain $runChain): static
    {
        $this->runChain = $runChain;
        return $this;
    }

    public function setWorkerState(int $workerId, eRunningState $state): static
    {
        $workerEntity = $this->workerRepository->find($workerId);
        $workerEntity->setState($state);
        $workerEntity->setUpdatedAt(new \DateTime());
        $this->workerRepository->save($workerEntity, true);

        return $this;
    }

    public function resolveWorkerPropertyDefinition(Worker $worker): array
    {
        $instance = $this->getWorkerInstanceByName($worker->getWorkerClass());
        $result = [];
        foreach ($instance->getProperties() as $property) {
            $result[] = [$property->type, $property->name, $property->value];
        }
        return $result;
    }
}