<?php

namespace Cehlers88\AnalyticsCore\Worker\Job;

interface JobInterface
{

}