<?php

namespace Cehlers88\AnalyticsCore\Observer;

use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;

interface ObserverInterface
{
    public function canHandle(ObserverMessageInterface $message): bool;

    public function handle(ObserverMessageInterface $message): void;
}