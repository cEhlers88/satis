<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\Application;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\Security\Core\User\UserInterface;

/**
 * @extends ServiceEntityRepository<Application>
 *
 * @method Application|null find($id, $lockMode = null, $lockVersion = null)
 * @method Application|null findOneBy(array $criteria, array $orderBy = null)
 * @method Application[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ApplicationRepository extends ServiceEntityRepository
{
    private ?UserInterface $user = null;

    public function __construct(
        ManagerRegistry  $registry,
        private Security $security
    )
    {
        parent::__construct($registry, Application::class);
    }

    public function add(Application $application): Application
    {
        $this->getEntityManager()->persist($application);
        $this->getEntityManager()->flush();
        return $application;

    }

    /**
     * @return Application[]
     */
    public function findAll(): array
    {
        $result = parent::findAll();
        $user = $this->getUser();

        if ($user->hasRole('ROLE_ADMIN')) {
            return $result;
        }

        return array_filter($result, function ($application) use ($user) {
            return $application->allowRead($user);
        });
    }

    public function getUser(): UserInterface
    {
        if (is_null($this->user)) {
            return $this->security->getUser() ?? new User();
        }
        return $this->user;
    }

    public function setUser(UserInterface $user): static
    {
        $this->user = $user;
        return $this;
    }
}
