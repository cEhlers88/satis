<?php

namespace Cehlers88\AnalyticsCore\Worker\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;
use DateTime;

/** Data transfer object containing worker execution results. */
class WorkerResultDTO extends DTO
{
    public const string KEY_WORKING_OBJECTS_COUNT = 'working_objects_count';
    public const string KEY_BENCHMARK = 'benchmark';

    /** @var array|null */
    public ?array $error = null;
    /** @var int|null */
    public ?int $startedAt = -1;
    /** @var int|null */
    public ?int $endedAt = -1;
    /** @var float|null */
    public ?float $runtime = 0;
    /** @var bool|null */
    public ?bool $timedOut = false;
    /** @var array|null */
    public ?array $jobResults = [];
    /** @var array|null */
    public ?array $environment = [];

    /** @var array */
    public array $warnings = [];

    /** @var array */
    public array $messages = [];

    public function __construct(
        /** @var array|null */
        public ?array $workerInfos = []
    )
    {
        $this->startedAt = (new DateTime())->getTimestamp();
    }

    /**
     * Create a WorkerResultDTO from a JSON or serialized string.
     *
     * @param string $string Serialized result data.
     * @return WorkerResultDTO
     */
    public static function createFromString(string $string): WorkerResultDTO
    {
        if (empty($string)) {
            $result = new self();
            $result->startedAt = null;
            return $result;
        }

        try {
            $json = json_decode($string, true, 512, JSON_THROW_ON_ERROR);

            if (is_array($json)) {
                $result = new self();

                $errorValue = $json['error'] ?? null;
                $result->error = is_string($errorValue) ? [$errorValue] : $errorValue;
                $result->startedAt = $json['startedAt'] ?? null;
                $result->endedAt = $json['endedAt'] ?? null;
                $result->runtime = $json['runtime'] ?? -1;
                $result->timedOut = $json['timedOut'] ?? false;
                $result->jobResults = $json['jobResults'] ?? [];
                $result->warnings = $json['warnings'] ?? [];
                $result->messages = $json['messages'] ?? [];
                $result->workerInfos = $json['workerInfos'] ?? [];

                return $result;
            }
        } catch (\JsonException $e) {

        }

        $unserialized = @unserialize($string);
        if ($unserialized instanceof self) {
            return $unserialized;
        }

        return new self();
    }

    /**
     * Create a WorkerResultDTO from a throwable.
     *
     * @param \Throwable $e The exception or error.
     * @return WorkerResultDTO
     */
    public static function createFromException(\Throwable $e): WorkerResultDTO
    {
        $result = new self();
        $result->error = [$e->getMessage()];
        $result->endedAt = (new DateTime())->getTimestamp();

        return $result;

    }

    /** Get the string representation. */
    public function __toString(): string
    {
        return $this->serialize();
    }

    /** Serialize the DTO to a JSON string. */
    public function serialize(): string
    {
        return json_encode([
            'error' => $this->error,
            'startedAt' => $this->startedAt,
            'endedAt' => $this->endedAt,
            'runtime' => $this->runtime,
            'timedOut' => $this->timedOut,
            'jobResults' => $this->jobResults,
            'warnings' => $this->warnings,
            'messages' => $this->messages,
            'workerInfos' => $this->workerInfos
        ]);
    }

    /** Get the formatted start date/time string. */
    public function getFormatedStartedAt(): string
    {
        if ($this->startedAt === null || $this->startedAt === -1) {
            return '';
        }

        return (new DateTime())->setTimestamp($this->startedAt)->format('d.m.Y | H:i:s');
    }

    /** Get the formatted end date/time string. */
    public function getFormattedEndedAt(): string
    {
        if ($this->startedAt === null || $this->startedAt === -1 || $this->endedAt === null || $this->endedAt === -1) { // if not started or not finished, no end time is available
            return '';
        }

        return (new DateTime())->setTimestamp($this->endedAt)->format('d.m.Y | H:i:s');
    }
}