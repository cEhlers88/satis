<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.01.26
 * Time: 07:18
 */

namespace Cehlers88\AnalyticsCore\Configuration\DTO;

use Cehlers88\AnalyticsCore\ENUM\eInputType;
use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class ConfigurationSuggestItemDTO extends ConfigurationItemDTO
{
    public string $entityClass = '';
    public string $valueField = '';
    public string $valueLabelField = '';

    public static function createSuggest(
        string $key,
        string $label = '',
        string $entityClass = '',
        string $valueField = 'id',
        string $valueLabelField = 'name',
        string $description = '',
        mixed  $defaultValue = null,
        array  $staticOptions = [],
    ): static
    {
        $instance = new self();

        $instance->key = $key;
        $instance->inputType = eInputType::SUGGEST;
        $instance->label = $label ?? $key;
        $instance->description = $description;
        $instance->defaultValue = $defaultValue;
        $instance->valueField = $valueField;
        $instance->valueLabelField = $valueLabelField;
        $instance->children = $staticOptions;
        $instance->entityClass = $entityClass;

        return $instance;
    }
}