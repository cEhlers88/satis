<?php

namespace Cehlers88\AnalyticsCore\Observer;

use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;
use Cehlers88\AnalyticsCore\Support\Error\AbstractErrorBag;

/** Provider for managing and notifying observers. */
class ObserverProvider extends AbstractErrorBag
{
    /**
     * @param iterable<ObserverInterface> $observers
     */
    public function __construct(
        private iterable $observers
    )
    {

    }

    /**
     * Dispatch a message to all observers that can handle it.
     *
     * @param ObserverMessageInterface $message
     * @return void
     */
    public function dispatch(ObserverMessageInterface $message): void
    {
        foreach ($this->observers as $observer) {
            if ($observer->canHandle($message)) {
                try {
                    $observer->handle($message);
                } catch (\Exception $e) {
                    $this->getLogger()->error($e->getMessage(), [
                        'code' => $e->getCode(),
                        'trace' => $e->getTraceAsString(),
                        'file' => $e->getFile(),
                        'line' => $e->getLine(),
                        'observerMessageKey' => $message->getKey(),
                    ]);
                }
            }
        }
    }
}