<?php

namespace Cehlers88\AnalyticsCore\Support\Logging;

use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;

/** Base class for logger implementations. */
abstract class AbstractLogger implements LoggerInterface
{
    protected array $properties = [];
    protected int $tabSpaces = 0;
    protected bool $addDateTimeToLogMessage = true;
    protected bool $addTypeToLogMessage = true;
    private mixed $willCreateLogHandler = null;

    public function configure(array $config): static
    {
        foreach ($config as $key => $value) {
            foreach ($this->properties as $property) {
                if ($property->name === $key) {
                    $property->value = $value;
                    break;
                }
            }
        }
        return $this;
    }

    public function getProperties(): array
    {
        return $this->properties;
    }

    public function log(eDebuggerLogType $logType, string $message, array $additionalInfos = [])
    {
        switch ($logType) {
            case eDebuggerLogType::ERROR:
                $this->error($message, []);
                break;

            case eDebuggerLogType::WARNING:
                $this->warning($message);
                break;

            default:
                $this->info($message);
                break;
        }
    }

    public function addDateTimeToLogMessage(bool $addDateTime): static
    {
        $this->addDateTimeToLogMessage = $addDateTime;
        return $this;
    }

    public function addTypeToLogMessage(bool $addType): static
    {
        $this->addTypeToLogMessage = $addType;
        return $this;
    }

    public function addTabSpace(int $tabSpaceCount = 1): static
    {
        $this->tabSpaces += $tabSpaceCount;
        return $this;
    }

    public function removeTabSpace(int $tabSpaceCount = 1): static
    {
        $this->tabSpaces -= $tabSpaceCount;
        return $this;
    }

    public function setIgnoreInfoLog(bool $ignoreInfoLog = true): static
    {
        return $this;
    }

    public function setWillCreateLogHandler(callable $willCreateLogHandler): static
    {
        $this->willCreateLogHandler = $willCreateLogHandler;
        return $this;
    }

    public function getName(): string
    {
        return static::class;
    }

    public function progressStart(int $max, string $name = ''): void
    {

    }

    public function progressAdvance(int $step = 1, string $name = ''): void
    {

    }

    public function getPropertyValue(string $name, mixed $defaultValue = null): mixed
    {
        foreach ($this->properties as $property) {
            if ($property->name === $name) {
                return $property->value;
            }
        }
        return $defaultValue;
    }

    public function setPropertyValue(string $name, mixed $value): static
    {
        foreach ($this->properties as &$property) {
            if ($property->name === $name) {
                $property->value = $value;
                return $this;
            }
        }

        return $this;
    }

    public function startGroup(string $name, array $data = []): static
    {
        return $this;
    }

    public function endGroup(string $name): static
    {
        // TODO: Implement endGroup() method.
        return $this;
    }

    public function finalize(): static
    {
        // TODO: Implement finalize() method.
        return $this;
    }

    protected function dispatchWillCreateLogHandler(): static
    {
        if ($this->willCreateLogHandler) {
            call_user_func($this->willCreateLogHandler);
        }
        return $this;
    }
}