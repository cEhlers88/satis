<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.09.2024
 * Time: 02:02
 */

namespace Cehlers88\AnalyticsCore\Support\Logging;

class SimpleConsoleLogger extends AbstractLogger implements LoggerInterface
{
    private bool $ignoreInfoLog = false;

    public function info(string $message): void
    {
        if ($this->ignoreInfoLog) return;
        $this->_output($message, 'I');
    }

    private function _output(string $message, string $type = 'I'): void
    {
        $this->dispatchWillCreateLogHandler();
        $hasAnyPrefix = false;
        if ($this->addDateTimeToLogMessage) {
            echo (new \DateTime())->format('Y-m-d H:i:s') . ' ';
            $hasAnyPrefix = true;
        }
        if ($this->addTypeToLogMessage) {
            echo '[' . $type . '] ';
            $hasAnyPrefix = true;
        }
        if ($hasAnyPrefix) {
            echo '|';
        }
        echo str_pad(' ', $this->tabSpaces) . $message . PHP_EOL;
    }

    public function error(string $message, array $data = []): void
    {
        $this->_output($message, 'E');
    }

    public function warning(string $message): void
    {
        $this->_output($message, 'W');
    }

    public function setIgnoreInfoLog(bool $ignoreInfoLog = true): static
    {
        $this->ignoreInfoLog = $ignoreInfoLog;
        return $this;
    }

    public function startGroup(string $name, array $data = []): static
    {
        $attributes = [];
        foreach ($data as $key => $value) {
            $attributes[] = "$key=\"$value\"";
        }
        $this->_output('<' . $name . ' ' . implode(' ', $attributes) . '>', 'G');
        $this->addTabSpace(3);
        return $this;
    }

    public function endGroup(string $name): static
    {
        $this->removeTabSpace(3);
        $this->_output('</' . $name . '>', 'G');
        return $this;
    }
}