<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

use Analytics\Abstract\AbstractPropertyHolder;
use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Process\Runner\ProcessRunnerInterface;

/** Base class for process result workers. */
abstract class AbstractProcessResultWorker extends AbstractPropertyHolder implements ProcessResultWorkerInterface
{
    /** @var Process */
    protected Process $process;

    private int $statusCode = -1;
    private ProcessRunnerInterface $runner;

    /** Set the process entity. */
    public function setProcess(Process $process): static
    {
        $this->process = $process;
        return $this;
    }

    /**
     * Run the result worker for the given process.
     *
     * @param Process $process
     * @param mixed $result
     * @param int $statusCode
     * @return static
     */
    public function run(Process $process, mixed $result, int $statusCode = -1): static
    {
        $this->process = $process;
        $this->process->addState(eRunningState::ProcessingResult);

        $this->handleResult($result);

        $this->process
            ->removeState(eRunningState::ProcessingResult)
            ->addState(eRunningState::ResultProcessed);

        return $this;
    }

    public function setStatusCode(int $statusCode): static
    {
        $this->statusCode = $statusCode;
        return $this;
    }

    public function setRunner(ProcessRunnerInterface $runner): static
    {
        $this->runner = $runner;
        return $this;
    }
}