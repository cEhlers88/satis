<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support\Math;

use Cehlers88\AnalyticsCore\Support\Math\ArithmeticExpression;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class ArithmeticExpressionTest extends TestCase
{
    private const array VALUES = ['netto' => 100, 'soll' => '80', 'ist' => 100.0, 'kunde.betrag' => 12.5, 'text' => 'n/a'];

    public static function dataProviderForExpressions(): array
    {
        return [
            'number' => ['42', 42],
            'precedence' => ['2 + 3 * 4', 14],
            'parentheses' => ['(2 + 3) * 4', 20],
            'division' => ['7 / 2', 3.5],
            'exact division stays whole' => ['8 / 2', 4],
            'modulo' => ['7 % 3', 1],
            'modulo of floats' => ['7.5 % 2', 1.5],
            'power is right-associative' => ['2 ^ 3 ^ 2', 512],
            'sign binds weaker than power' => ['-2 ^ 2', -4],
            'double sign' => ['3 - -2', 5],
            'names' => ['netto * 1.19', 119.0],
            'numeric text is a number' => ['(ist - soll) / soll * 100', 25.0],
            'braces' => ['{kunde.betrag} * 2', 25.0],
            'functions' => ['round(10 / 3, 2) + max(1, 5, 3) - min(4, 2) + abs(-1)', 7.33],
            'floor, ceil and sqrt' => ['floor(2.7) + ceil(2.1) + sqrt(16)', 9.0],
            'exponent notation' => ['1.5e3 + .5', 1500.5],
        ];
    }

    #[DataProvider('dataProviderForExpressions')]
    public function test_evaluate(string $expression, int|float $expected): void
    {
        $result = ArithmeticExpression::evaluate($expression, self::resolver());

        $this->assertSame(get_debug_type($expected), get_debug_type($result));
        $this->assertEqualsWithDelta($expected, $result, 0.0000001);
    }

    public static function dataProviderForErrors(): array
    {
        return [
            'empty' => ['', 'empty'],
            'division by zero' => ['1 / (2 - 2)', 'Division by zero'],
            'unknown name' => ['foo + 1', 'foo'],
            'no number' => ['text * 2', '"text" is no number'],
            'unknown function' => ['median(1, 2)', 'Unknown function'],
            'wrong argument count' => ['abs(1, 2)', 'Wrong number of arguments'],
            'unclosed parenthesis' => ['(1 + 2', '")" is missing'],
            'trailing operator' => ['1 +', 'ends too early'],
            'stray character' => ['1 + $a', 'Unexpected "$"'],
            'two numbers' => ['1 2', 'Unexpected "2" at position 3'],
            'negative square root' => ['sqrt(-4)', 'square root'],
            'unclosed brace' => ['{netto * 2', 'Unclosed'],
        ];
    }

    #[DataProvider('dataProviderForErrors')]
    public function test_errors(string $expression, string $message): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage($message);

        ArithmeticExpression::evaluate($expression, self::resolver());
    }

    public function test_names_of_leaves_out_functions(): void
    {
        $this->assertSame(['netto', 'kunde.betrag'], ArithmeticExpression::namesOf('round(netto * {kunde.betrag}, 2) + netto'));
    }

    private static function resolver(): callable
    {
        return static function (string $name): mixed {
            if (!array_key_exists($name, self::VALUES)) {
                throw new \InvalidArgumentException(sprintf('There is no value "%s".', $name));
            }

            return self::VALUES[$name];
        };
    }
}
