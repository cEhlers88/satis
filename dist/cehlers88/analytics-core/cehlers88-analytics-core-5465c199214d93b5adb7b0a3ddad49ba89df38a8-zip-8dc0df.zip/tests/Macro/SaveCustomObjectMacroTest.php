<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectInterface;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Macro\Debugger\IMacroDebugger;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\SaveCustomObjectMacro;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class SaveCustomObjectMacroTest extends TestCase
{
    public function test_an_existing_object_by_id_gets_its_attributes(): void
    {
        $meter = (new SaveCustomObjectMacroTestMeter())->setName('Strom');
        $provider = $this->createProvider();
        $provider->method('getCustomEntitiesBy')->with(['id' => 7])->willReturn([$meter]);
        $provider->expects($this->once())->method('updateAttributes')
            ->with($meter, ['value' => 42, 'details' => '{"unit":"kWh"}']);

        $result = $this->createMacro($provider)->execute([
            'nameOrId' => 7,
            'attributes' => ['value' => 42, 'details' => ['unit' => 'kWh']],
        ]);

        $this->assertFalse($result['hasError']);
        $this->assertSame($meter, $result['returnValue']);
    }

    public function test_an_unknown_id_is_not_created(): void
    {
        $provider = $this->createProvider();
        $provider->method('getCustomEntitiesBy')->willReturn([]);
        $provider->expects($this->never())->method('updateAttributes');

        $result = $this->createMacro($provider)->execute(['nameOrId' => '12', 'attributes' => ['value' => 1]]);

        $this->assertSame(404, $result['error']->number);
    }

    public function test_an_unknown_name_is_created_with_its_class(): void
    {
        $saved = (new SaveCustomObjectMacroTestMeter())->setName('Gas');
        $provider = $this->createProvider();
        $provider->method('getCustomEntitiesBy')
            ->with(['name' => 'Gas', 'className' => SaveCustomObjectMacroTestMeter::class])
            ->willReturn([]);
        $provider->method('createNewCustomEntity')->with(SaveCustomObjectMacroTestMeter::class)
            ->willReturn(new SaveCustomObjectMacroTestMeter());
        $provider->expects($this->once())->method('updateAttributes')
            ->with($this->callback(static fn(CustomObjectInterface $object): bool => $object->getName() === 'Gas'), ['value' => 3.5]);
        $provider->method('getCustomEntityByClassNameAndName')->with(SaveCustomObjectMacroTestMeter::class, 'Gas')->willReturn($saved);

        // the short name of the class, in any case
        $result = $this->createMacro($provider)->execute(['nameOrId' => 'Gas', 'attributes' => ['value' => 3.5], 'className' => 'saveCustomObjectMacroTestMeter']);

        $this->assertFalse($result['hasError']);
        $this->assertSame($saved, $result['returnValue']);
    }

    public function test_an_unknown_name_without_class_is_an_error(): void
    {
        $provider = $this->createProvider();
        $provider->method('getCustomEntitiesBy')->willReturn([]);

        $result = $this->createMacro($provider)->execute(['nameOrId' => 'Gas', 'attributes' => ['value' => 1]]);

        $this->assertSame(422, $result['error']->number);
        $this->assertStringContainsString('className', $result['error']->message);
    }

    public function test_only_registered_classes_are_accepted(): void
    {
        $provider = $this->createProvider();
        $provider->expects($this->never())->method('createNewCustomEntity');

        $result = $this->createMacro($provider)->execute(['nameOrId' => 'x', 'attributes' => ['a' => 1], 'className' => \ArrayObject::class]);

        $this->assertSame(422, $result['error']->number);
    }

    public function test_attributes_need_names(): void
    {
        $result = $this->createMacro($this->createProvider())->execute(['nameOrId' => 1, 'attributes' => [1, 2]]);

        $this->assertSame(422, $result['error']->number);
    }

    public function test_simulation_mode_writes_nothing(): void
    {
        $meter = (new SaveCustomObjectMacroTestMeter())->setName('Strom');
        $provider = $this->createProvider();
        $provider->method('getCustomEntitiesBy')->willReturn([$meter]);
        $provider->expects($this->never())->method('updateAttributes');

        $result = $this->createMacro($provider, true)->execute(['nameOrId' => 'Strom', 'attributes' => ['value' => 5]]);

        $this->assertFalse($result['hasError']);
        $this->assertSame(5, $result['returnValue']->getAttribute('value'));
    }

    private function createProvider(): CustomObjectProvider&MockObject
    {
        $provider = $this->createMock(CustomObjectProvider::class);
        $provider->method('getCustomClasses')->willReturn([new SaveCustomObjectMacroTestMeter()]);

        return $provider;
    }

    private function createMacro(CustomObjectProvider $provider, bool $simulation = false): SaveCustomObjectMacro
    {
        $environment = $this->createMock(MacroEnvironment::class);
        $environment->method('isSimulationMode')->willReturn($simulation);
        $environment->method('getDebugger')->willReturn($this->createMock(IMacroDebugger::class));

        $macro = new SaveCustomObjectMacro($provider);
        $macro->setMacroEnvironment($environment);

        return $macro;
    }
}

class SaveCustomObjectMacroTestMeter extends AbstractCustomObject
{
}
