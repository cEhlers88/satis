<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\CalculateMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use PHPUnit\Framework\TestCase;

class CalculateMacroTest extends TestCase
{
    public function test_values_are_used_by_name_and_path(): void
    {
        $result = $this->createMacro()->execute([
            'expression' => 'netto * 1.19 + kunde.rabatt',
            'values' => ['netto' => 100, 'kunde' => ['rabatt' => -10]],
        ]);

        $this->assertFalse($result['hasError']);
        $this->assertEqualsWithDelta(109.0, $result['returnValue'], 0.0000001);
    }

    public function test_precision_rounds_and_zero_gives_a_whole_number(): void
    {
        $this->assertSame(3.33, $this->createMacro()->execute(['expression' => '10 / 3', 'precision' => 2])['returnValue']);
        $this->assertSame(3, $this->createMacro()->execute(['expression' => '10 / 3', 'precision' => 0])['returnValue']);
        $this->assertSame(10 / 3, $this->createMacro()->execute(['expression' => '10 / 3'])['returnValue']);
    }

    public function test_a_name_not_in_values_is_read_from_the_variables(): void
    {
        $variables = $this->createMock(VariablesProvider::class);
        $variables->method('getVariableValue')->willReturnCallback(static fn(string $name): mixed => match ($name) {
            'soll' => 80,
            'kunde' => ['umsatz' => '120'],
            default => throw new \Exception('Variable ' . $name . ' not found'),
        });

        $macro = $this->createMacro($variables);

        $this->assertSame(25.0, $macro->execute(['expression' => '(100 - soll) / soll * 100'])['returnValue']);
        $this->assertSame(240, $macro->execute(['expression' => 'kunde.umsatz * 2'])['returnValue']);

        $unknown = $macro->execute(['expression' => 'ist + 1']);
        $this->assertTrue($unknown['hasError']);
        $this->assertSame(422, $unknown['error']->number);
        $this->assertStringContainsString('"ist"', $unknown['error']->message);
    }

    public function test_an_invalid_expression_is_an_error(): void
    {
        $result = $this->createMacro()->execute(['expression' => '1 / 0']);

        $this->assertTrue($result['hasError']);
        $this->assertSame('Division by zero.', $result['error']->message);
    }

    private function createMacro(?VariablesProvider $variables = null): CalculateMacro
    {
        $environment = $this->createMock(MacroEnvironment::class);
        if ($variables !== null) {
            $environment->method('getVariablesStoreProvider')->willReturn($variables);
        }

        $macro = new CalculateMacro();
        $macro->setMacroEnvironment($environment);

        return $macro;
    }
}
