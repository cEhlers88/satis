<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\MapMacro;
use PHPUnit\Framework\TestCase;

class MapMacroTest extends TestCase
{
    private const array BOOKINGS = [
        ['id' => 1, 'amount' => 800, 'customer' => ['name' => 'Miete GmbH']],
        ['id' => 2, 'amount' => 45.5, 'customer' => ['name' => 'Bäcker']],
        ['id' => 3],
    ];

    public function test_field_turns_entries_into_values(): void
    {
        $result = $this->createMacro()->execute(['data' => self::BOOKINGS, 'field' => 'customer.name']);

        $this->assertFalse($result['hasError']);
        $this->assertSame(['Miete GmbH', 'Bäcker', null], $result['returnValue']);
    }

    public function test_fields_as_list_keep_their_names(): void
    {
        $result = $this->createMacro()->execute(['data' => self::BOOKINGS, 'fields' => ['id', 'amount']]);

        $this->assertSame([
            ['id' => 1, 'amount' => 800],
            ['id' => 2, 'amount' => 45.5],
            ['id' => 3, 'amount' => null],
        ], $result['returnValue']);
    }

    public function test_fields_as_object_rename(): void
    {
        $result = $this->createMacro()->execute([
            'data' => self::BOOKINGS,
            'fields' => ['kunde' => 'customer.name', 'betrag' => 'amount'],
        ]);

        $this->assertSame(['kunde' => 'Miete GmbH', 'betrag' => 800], $result['returnValue'][0]);
    }

    public function test_one_field_in_a_list_arrives_as_text_and_still_selects(): void
    {
        // AbstractMacro::execute() unwraps ["id"] to "id"
        $result = $this->createMacro()->execute(['data' => self::BOOKINGS, 'fields' => ['id']]);

        $this->assertSame([['id' => 1], ['id' => 2], ['id' => 3]], $result['returnValue']);
    }

    public function test_a_single_record_counts_as_a_list_of_it(): void
    {
        $result = $this->createMacro()->execute(['data' => [['id' => 7, 'amount' => 1]], 'field' => 'id']);

        $this->assertSame([7], $result['returnValue']);
    }

    public function test_objects_are_read_as_well(): void
    {
        $result = $this->createMacro()->execute(['data' => [(object)['a' => (object)['b' => 1]], (object)['a' => (object)['b' => 2]]], 'field' => 'a.b']);

        $this->assertSame([1, 2], $result['returnValue']);
    }

    public function test_field_and_fields_together_or_neither_is_an_error(): void
    {
        $both = $this->createMacro()->execute(['data' => self::BOOKINGS, 'field' => 'id', 'fields' => ['amount', 'id']]);
        $neither = $this->createMacro()->execute(['data' => self::BOOKINGS]);

        $this->assertSame(422, $both['error']->number);
        $this->assertSame(422, $neither['error']->number);
    }

    private function createMacro(): MapMacro
    {
        $macro = new MapMacro();
        $macro->setMacroEnvironment($this->createMock(MacroEnvironment::class));

        return $macro;
    }
}
