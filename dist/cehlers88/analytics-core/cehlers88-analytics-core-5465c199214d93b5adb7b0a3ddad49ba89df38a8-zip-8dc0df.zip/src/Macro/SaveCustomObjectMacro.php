<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectInterface;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;

/**
 * The counterpart of `getCustomObject`: changes attributes of a custom object or
 * creates it, so a procedure can keep what it found out - a meter reading, the
 * last successful sync. Attributes not named stay as they are.
 *
 * By id the object has to exist. By name it is created when there is none yet,
 * which needs `className` - one of the registered custom object classes, by its
 * full or its short name; never any class, since the provider instantiates it.
 * In simulation mode (the debugger) nothing is written.
 */
class SaveCustomObjectMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    private const string PROPERTY_NAME_OR_ID = 'nameOrId';
    private const string PROPERTY_ATTRIBUTES = 'attributes';
    private const string PROPERTY_CLASS_NAME = 'className';

    public function __construct(
        private readonly CustomObjectProvider $customObjectProvider
    )
    {
    }

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_ATTRIBUTES => PropertyUi::create()->placeholder('{"value": 42}'),
            self::PROPERTY_CLASS_NAME => PropertyUi::create()->placeholder('nur zum Anlegen nötig'),
            default => null,
        };
    }

    public function init(): SaveCustomObjectMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME_OR_ID, [
                MacroPropertyDTO::TYPE_INT,
                MacroPropertyDTO::TYPE_STRING
            ], 'Name or id of the custom object'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ATTRIBUTES, MacroPropertyDTO::TYPE_ARRAY, 'The attributes to set (name => value) - the others stay as they are'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CLASS_NAME, MacroPropertyDTO::TYPE_STRING, 'Class of the custom object, full or short name - needed to create one, and narrows the search by name', ''));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Sets attributes of a custom object, or creates it.';
    }

    public function getName(): string
    {
        return 'saveCustomObject';
    }

    protected function run(): ?array
    {
        $nameOrId = $this->getPropertyValue(self::PROPERTY_NAME_OR_ID);
        $nameOrId = is_string($nameOrId) ? trim($nameOrId) : $nameOrId;
        $attributes = $this->getPropertyValue(self::PROPERTY_ATTRIBUTES);
        $attributes = is_object($attributes) ? (array)$attributes : $attributes;
        $classReference = trim((string)$this->getPropertyValue(self::PROPERTY_CLASS_NAME));

        if ($nameOrId === null || $nameOrId === '') {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'The custom object needs a name or an id.'));
        }
        if (!is_array($attributes) || ($attributes !== [] && array_is_list($attributes))) {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'The attributes have to be given as name => value.'));
        }

        // attributes are stored as text - a list or an object as its JSON
        $attributes = array_map(
            static fn(mixed $value): mixed => is_array($value) || is_object($value) ? json_encode($value, JSON_UNESCAPED_UNICODE) : $value,
            $attributes
        );

        $className = null;
        if ($classReference !== '') {
            $className = $this->findClass($classReference);
            if ($className === null) {
                return $this->_createRunResult(null, ErrorDTO::create(422, sprintf('There is no custom object class "%s".', $classReference)));
            }
        }

        $object = $this->find($nameOrId, $className);
        $isNew = $object === null;

        if ($isNew) {
            if (is_int($nameOrId) || ctype_digit((string)$nameOrId)) {
                return $this->_createRunResult(null, ErrorDTO::create(404, sprintf('There is no custom object #%s.', $nameOrId)));
            }
            if ($className === null) {
                return $this->_createRunResult(null, ErrorDTO::create(422, sprintf(
                    'There is no custom object "%s" - to create it, name its class in "className".', $nameOrId
                )));
            }
            $object = $this->customObjectProvider->createNewCustomEntity($className)->setName((string)$nameOrId);
        }

        if ($this->getMacroEnvironment()->isSimulationMode()) {
            foreach ($attributes as $name => $value) {
                $object->setAttribute((string)$name, $value);
            }
            $this->log(eDebuggerLogType::INFO, sprintf(
                'Simulation: custom object "%s" would be %s.', $object->getName(), $isNew ? 'created' : 'saved'
            ), ['attributes' => $attributes]);

            return $this->_createRunResult($object);
        }

        try {
            $this->customObjectProvider->updateAttributes($object, $attributes);
        } catch (\Throwable $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(500, $exception->getMessage()));
        }

        // the provider saves into a row of its own - the new object only learns its id by reading it back
        $saved = match (true) {
            $isNew => $this->customObjectProvider->getCustomEntityByClassNameAndName($object->getClassName(), $object->getName()),
            $object->getId() > 0 => $this->find($object->getId(), null),
            default => null,
        };

        return $this->_createRunResult($saved ?? $object);
    }

    private function find(int|string $nameOrId, ?string $className): ?CustomObjectInterface
    {
        if (is_int($nameOrId) || ctype_digit($nameOrId)) {
            $found = $this->customObjectProvider->getCustomEntitiesBy(['id' => (int)$nameOrId])[0] ?? null;

            return $found instanceof CustomObjectInterface && ($className === null || $found->getClassName() === $className) ? $found : null;
        }

        $filters = ['name' => $nameOrId];
        if ($className !== null) {
            $filters['className'] = $className;
        }
        $found = $this->customObjectProvider->getCustomEntitiesBy($filters)[0] ?? null;

        return $found instanceof CustomObjectInterface ? $found : null;
    }

    /** The registered class the reference names - by its full name or, ignoring case, its short one. */
    private function findClass(string $reference): ?string
    {
        $reference = ltrim($reference, '\\');
        foreach ($this->customObjectProvider->getCustomClasses() as $class) {
            $className = is_object($class) ? $class::class : (string)$class;
            $shortName = substr($className, (int)strrpos('\\' . $className, '\\'));
            if ($className === $reference || strcasecmp($shortName, $reference) === 0) {
                return $className;
            }
        }

        return null;
    }
}
