<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 31.08.2024
 * Time: 09:20
 */

namespace Cehlers88\AnalyticsCore\Process\Runner;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Process\DTO\StartInfoDTO;
use Cehlers88\AnalyticsCore\Process\ProcessProvider;
use Cehlers88\AnalyticsCore\Process\ProcessResultWorkerProvider;
use Cehlers88\AnalyticsCore\Repository\ProcessRepository;
use Cehlers88\AnalyticsCore\Support\Error\AbstractErrorBag;

/** Base class for process runners. */
abstract class AbstractProcessRunner extends AbstractErrorBag implements ProcessRunnerInterface
{
    public const STARTINFO_KEY_RUNNER_ARGUMENTS = 'runner_arguments';
    public const CODE_INVALID_ARGUMENTS = 510;

    /** @var Process|null */
    protected ?Process $process = null;

    /** @var ProcessProvider */
    protected ProcessProvider $processProvider;

    /** @var ProcessRepository */
    protected ProcessRepository $processRepository;

    protected ProcessResultWorkerProvider $resultWorkerProvider;

    public function setProcessResultWorkerProvider(ProcessResultWorkerProvider $resultWorkerProvider): static
    {
        $this->resultWorkerProvider = $resultWorkerProvider;
        return $this;
    }

    /** Run the process, delegating to validation or handling as appropriate. */
    public function run(): void
    {
        if ($this->process->hasState(eRunningState::NeedsValidation)) {
            $this->validate();
            return;
        }

        if ($this->process->hasState(eRunningState::Invalid)) {
            return;
        }

        if ($this->process->hasState(eRunningState::Error)) {
            return;
        }

        if ($this->process->hasState(eRunningState::Canceled)) {
            $this->process->setState(eRunningState::Canceled); // to remove every not "Canceled" state
            return;
        }

        if ($this->process->hasState(eRunningState::ProcessingResult)) {
            $resultWorkerDefinition = $this->process->getResultWorkerDefinition();
            $resultHandler = $this->resultWorkerProvider->getResultWorkerByClass($resultWorkerDefinition->worker);
            $resultHandler
                ->setProcess($this->process)
                ->setStatusCode($this->getResultStatusCode())
                ->setRunner($this)
                ->handleResult($this->getProcessResult());
            return;
        }

        $this->handle();

        if ($this->process->hasState(eRunningState::ProcessingResult)) {
            $this->process->addState(eRunningState::Ran);
        }
    }

    /** Validate that all required arguments are present. */
    public function validate(): static
    {
        foreach ($this->getRequiredArguments() as $var) {
            if (is_null($this->getProcess()->getRunnerAttributeValue($var))) {
                $this->process->addState(eRunningState::Invalid);
                $this->logInfo('Missing argument "' . $var . '"');
            }
        }

        $this->process->removeState(eRunningState::NeedsValidation);

        return $this;
    }

    /** @return array<int, string> */
    public function getRequiredArguments(): array
    {
        return [];
    }

    /*public function handleExternalResponse(Process $process, mixed $response): ProcessRunnerResultDTO
    {
              if (!$process->hasState(eProcessState::WAITING)) {
                  throw new \RuntimeException('Process is not waiting for external response');
              }

              $this->process = $process;
              $this->handle();
              $result = ProcessRunnerResultDTO::createSuccess();
              $result->newState = $this->process->getStateValue();

        return ProcessRunnerResultDTO::createSuccess();
    }*/

    /**
     * @param bool $createIfNotExist
     * @return Process|null
     */
    public function getProcess(bool $createIfNotExist = true): ?Process
    {
        return $this->process ?? ($createIfNotExist ? new Process() : null);
    }

    /** Set the process entity. */
    public function setProcess(Process $process): static
    {
        $this->process = $process;
        return $this;
    }

    public function getResultStatusCode(): int
    {
        return -1;
    }

    public function getProcessResult(): mixed
    {
        return null;
    }

    /** Handle the process execution logic. */
    abstract public function handle(): void;

    /** @return array<string, mixed> */
    public function getArguments(): array
    {
        return $this->getProcess()->getStartInfo(StartInfoDTO::KEY_RUNNER_ARGUMENTS) ?? [];
    }

    /**
     * Set an error on the process and record it in details.
     *
     * @param string $message
     * @param int $code
     * @param array<string, mixed> $data
     * @return ErrorDTO
     */
    public function setError(string $message, int $code = -1, array $data = []): ErrorDTO
    {
        $this->process
            ->addState(eRunningState::Error);
        $details = $this->process->getDetails() ?? [];
        $errors = $details['errors'] ?? [];
        if (count($errors) > 0) {
            if (end($errors) !== $message) {
                $errors[] = $message;
            }
        }
        $details['errors'] = $errors;
        $this->process->setDetails($details);

        return parent::setError($message, $code, $data);
    }

    /** Set the process provider. */
    public function setProcessProvider(ProcessProvider $processProvider): static
    {
        $this->processProvider = $processProvider;
        return $this;
    }

    /** Set the process repository. */
    public function setProcessRepository(ProcessRepository $processRepository): static
    {
        $this->processRepository = $processRepository;
        return $this;
    }
}