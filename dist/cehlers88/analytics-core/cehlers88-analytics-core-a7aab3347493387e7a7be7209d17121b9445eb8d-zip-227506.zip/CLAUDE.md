# CLAUDE.md

Guidance for AI assistants working in this repository.

## What this project is

`cehlers88/analytics-core` is a **PHP library** (not an application) that provides the core
building blocks of an analytics platform: Doctrine domain entities and repositories, a
background worker framework, process orchestration, a macro/command scripting engine,
an observer bus, a configuration system, a dashboard/widget layer, and a presentation
(assembler → view) layer.

It is consumed as a Composer package by a host Symfony application (`Analytics\…`,
deployed as `analytics.c-ehlers.de`). **The host application is not in this repository.**

- Package type: `library`, license: proprietary
- PSR-4: `Cehlers88\AnalyticsCore\` → `src/`, `Cehlers88\AnalyticsCore\Tests\` → `tests/`
- Requires PHP **>= 8.4** (`composer.json`); CI runs 8.4. The README still says 8.3 — trust
  `composer.json`.
- Required extensions: `curl`, `soap`, `simplexml`

## Commands

```bash
composer install --no-interaction --prefer-dist   # install dev dependencies
vendor/bin/phpunit                                # run the whole suite (~196 tests)
vendor/bin/phpunit tests/Worker                   # run one directory
vendor/bin/phpunit --filter testSetAndGetSharedData
vendor/bin/phpunit --display-skipped              # see why tests were skipped
```

There is no linter, static analyser, or formatter configured. PHPUnit is the only tooling.

If `composer install` fails on a missing platform extension in a sandbox, use
`--ignore-platform-req=ext-soap` — the test suite does not exercise SOAP.

## The most important gotcha: undeclared framework dependencies

`composer.json` declares only `symfony/security-core` and `phpunit/phpunit`. But `src/`
freely uses **Doctrine ORM/DBAL/DoctrineBundle, Symfony Console, Messenger, HttpFoundation,
SecurityBundle, Mercure, Twig**, and classes from the host app's own `Analytics\` namespace
(`Analytics\ENUM\eWorkerJobType`, `Analytics\Interface\IWidget`, `Analytics\Utils\UnitUtils`,
`Analytics\DTO\WidgetSubmitResultDTO`, …). None of those are installed here.

Consequences to keep in mind:

- Any class that touches Doctrine, Twig, or `Analytics\*` **cannot be instantiated in this
  repo's test suite.** It only works once the host application autoloads it.
- Tests for such units must either be skipped with an explicit reason, or written against a
  minimal in-repo stub. Both patterns exist:
  - `tests/Dashboard/DashboardManagerTest.php` — `markTestSkipped('Doctrine is not installed; …')`
  - `tests/Worker/SharedDataStoreTest.php` — a hand-written stub implementing only the part
    of `WorkerInterface` under test, so no `Analytics\*` import is needed.
- Prefer designing new code so the testable logic lives in a plain PHP class (DTO, ENUM,
  validator, settings object) that can be unit-tested without a container.

## Repository layout

```
src/
├── AnalyticsCore.php          Bundle plugin entry point (extends Support\AbstractBundlePlugin)
├── Command/                   AbstractCommand (Symfony Console base) + command DTOs & docs
├── Configuration/             Group-based, variable-store-persisted configuration
├── CustomObject/              Dynamic, DB-defined entity classes (AbstractCustomObject)
├── DTO/                       Shared DTOs (Result, Error, Role, Badge, Notification, …)
├── Dashboard/                 DashboardManager + pluggable dashboard setting providers
├── ENUM/                      Enums, incl. ENUM/State/ (eRunningState, eTrackingBufferState)
├── Entity/                    38 Doctrine ORM domain models + Abstract* bases
├── Executor/                  Lifecycle-managed AbstractExecutor (preStart/onStart/execute/onEnd)
├── Factory/                   CommandFactory
├── Macro/                     Macro scripting engine: macros, extensions, protectors, debuggers
├── Message/                   Symfony Messenger messages
├── Observer/                  Observer bus: provider, messages, argument resolvers
├── Player/                    CommandPlayer, MacroPlayer, ProcedurePlayer
├── Presentation/              Assemblers, Frontend views, Backend JSON, server-side renderers
├── Process/                   ProcessProvider, Runner/, ResultWorker/, lifecycle messages
├── Provider/                  WidgetProvider, MacroExtensionProvider, VariablesProvider
├── Recorder/                  TrackingRecorder, CaptureEventRecorder
├── Repository/                Doctrine repositories (AbstractRepository adds an ID blacklist)
├── Resources/config/services.yaml   ← the DI wiring / tag registry (see below)
├── Security/                  Doorman (permission gate), Role/, MagicRole/
├── ServiceEndpointRunner/     Pluggable outbound service endpoint runners
├── Support/                   Logging, Error bags, PropertyBag, Profiler, Monitoring, DTO base
├── Validator/                 CommandDefinitionValidator
├── Widget/                    AbstractWidget + concrete dashboard widgets
└── Worker/                    AbstractWorker, jobs, WorkerProvider, lifecycle messages
templates/                     Twig templates for widgets (rendered by WidgetProvider)
doc/                           Per-module long-form documentation (linked from README)
tests/                         PHPUnit tests, mirroring the src/ tree
```

## Architecture: how extension works

Nearly every subsystem uses the same shape:

1. An **interface** (`FooInterface`) plus an **`AbstractFoo`** base with sane defaults.
2. Implementations are auto-discovered by Symfony autoconfiguration and **tagged** via
   `_instanceof` in `src/Resources/config/services.yaml`.
3. A **`FooProvider`** receives `!tagged_iterator <tag>` and drives them.

`src/Resources/config/services.yaml` is therefore the single source of truth for what is
pluggable. Current tag map:

| Interface / base class                          | Tag                                          |
|-------------------------------------------------|----------------------------------------------|
| `Macro\MacroInterface`                          | `analytics.macro`                            |
| `Worker\WorkerInterface`                        | `analytics.worker`                           |
| `Worker\Job\JobInterface`                       | `worker_job`                                 |
| `Support\MonitoringRule\MonitoringRuleInterface`| `analytics.monitoring_rule`                  |
| `Support\UserInteractionFunction\…Interface`    | `analytics.user_interaction_function`        |
| `Support\Logging\LoggerInterface`               | `logger`                                     |
| `Observer\ObserverInterface`                    | `analytics.observer`                         |
| `Observer\ArgumentResolver\…Interface`          | `analytics.observer_message_argument_resolver` |
| `Presentation\Assembler\AssemblerInterface`     | `analytics.assemblers`                       |
| `Presentation\ServerSideRenderer\…Interface`    | `analytics.server_side_renderer`             |
| `Configuration\GroupInterface`                  | `analytics.configuration`                    |
| `Executor\ExecutorInterface`                    | `analytics.executor`                         |
| `Process\Runner\ProcessRunnerInterface`         | `analytics.process_runner`                   |
| `Process\ResultWorker\ProcessResultWorkerInterface` | `analytics.process_result_worker`        |
| `Macro\Extension\MacroExtensionInterface`       | `macro_extension`                            |
| `Macro\Protector\MacroProtectorInterface`       | `macro_protector`                            |
| `Security\MagicRole\MagicRoleInterface`         | `magic_role`                                 |
| `ServiceEndpointRunner\…Interface`              | `analytics.service_endpoint_runner`          |
| `Widget\AbstractWidget`                         | `widget`                                     |
| `Dashboard\DashboardSettingProviderInterface`   | `dashboard_setting_provider`                 |

**When you add a new pluggable interface or provider, you must also add it to
`services.yaml`** — either as an `_instanceof` tag or as an explicit service with a
`!tagged_iterator` argument. `Entity/`, `ENUM/`, and `Observer/ArgumentResolver/` are
explicitly excluded from service registration.

`ProcessProvider` additionally reads env vars `REMOVE_ABORTED_PROCESSES_OLDER_THAN`,
`REMOVE_FINISHED_PROCESSES_OLDER_THAN`, `REMOVE_UNFINISHED_PROCESSES_OLDER_THAN` — these are
supplied by the host application.

### Subsystem quick reference

- **Worker** — `AbstractWorker` (a `AbstractPropertyBag`) processes "working objects"
  (usually `TrackingBuffer` rows) through a list of `JobInterface` jobs, tracks benchmarks,
  timeouts, warnings, and a per-run shared-data store; emits Started/Finished/Error
  observer messages. See `doc/worker-system.md`.
- **Executor** — `AbstractExecutor::run()` is `final` and drives
  `configure → preStart → onStart → execute → onEnd`, wrapping each phase in try/catch and
  recording errors with `ERR_*` codes. Profiling and log grouping are automatic.
- **Process** — `ProcessProvider` starts a `Process` entity via a `ProcessRunnerInterface`
  (curl request, command player, …) and post-processes the outcome with
  `ProcessResultWorkerInterface` implementations.
- **Macro / Player** — `MacroPlayer` executes tagged macros within a `MacroEnvironment`;
  `MacroProtectorInterface` gates what may run (e.g. `DemoModeMacroProtector`);
  `CommandPlayer` and `ProcedurePlayer` play stored command definitions.
- **Observer** — `ObserverProvider::dispatch()` never throws; observer exceptions are logged.
  Use `dispatchWithReport()` when the caller needs to know which observers handled a message.
  Messages implement `ObserverMessageInterface::getKey()`.
- **Security** — `Doorman` is the permission gate: required roles (`RoleDTO`/`ExtendedRoleDTO`)
  are checked against the current user, with `MagicRoleInterface` implementations providing
  computed roles (`AnyOf`, `AllOf`, `NoneOf`, `IsClient`). A user holding `ROLE_ADMIN` passes
  even when roles remain unresolved (the reason is recorded).
- **Widget / Dashboard** — widgets declare `getSettingDefinitions()` (`PropertyDTO[]`),
  `getRequiredRoles()`, `isSelectable()`, and a Twig template under `templates/widget/`.
  `WidgetProvider` resolves access and rendering; `DashboardManager` and
  `DashboardSettingsProvider` manage multi-dashboard state per user.
- **Presentation** — `AssemblerInterface` implementations convert entities/custom objects
  into `ViewInterface` view objects (frontend) or JSON DTOs (backend); `AssemblerProvider`
  dispatches to the right one via `getUseFor()`.
- **CustomObject** — `AbstractCustomObject` wraps a `CustomEntity` row plus its
  `CustomEntityAttribute`s, giving DB-defined dynamic entity types with attribute monitoring.

## Coding conventions

Follow the surrounding code; the established patterns are:

- **Naming**: `FooInterface` for interfaces, `AbstractFoo` for bases, `FooDTO` for DTOs,
  `FooProvider` for tagged-service registries. Enums are lower-`e`-prefixed PascalCase:
  `eRunningState`, `eInputType`, `eDebuggerLogType`.
- **Enums** are backed (`: int` / `: string`) and often carry static helpers such as
  `toKeyValueArray()`. `eRunningState` uses bit-shift values (`1 << n`) — never renumber
  existing cases.
- **DTOs** extend `Support\DTO\DTO`, use public properties, and offer static named
  constructors (`ResultDTO::createSuccess()`, `createError()`, `PropertyDTO::create()`).
- **Fluent setters** return `static`/`self` throughout — keep that.
- Entities extend `Entity\AbstractEntity` (id, `created_at`, `modified_at`, `updated_at`, tags)
  or a more specific `Abstract*Entity`; mapping is via PHP 8 attributes (`#[ORM\Column]`).
  Properties are camelCase, except the inherited snake_case timestamps on `AbstractEntity`.
- Repositories extend `Repository\AbstractRepository`; use
  `createPrefilteredQueryBuilder($alias)` instead of `createQueryBuilder()` so the ID
  blacklist is honoured.
- Older files carry a `Created by PhpStorm` docblock header and `_`-prefixed private
  properties. Both are legacy — do not add them to new files, do not strip them from old ones.
- Docblocks: short one-line `/** … */` summaries on classes and non-obvious methods; add
  `@param`/`@return` mainly where the type alone is not enough (e.g. `@return PropertyDTO[]`).
- Comments in code are English. Some commit messages and PR titles are German — either is fine.

## Git & release workflow

- Default branch: `main`. Work on a feature branch and open a PR; do not push to `main`.
- **Commits follow Conventional Commits** — `release-please` parses them to cut releases and
  generate `CHANGELOG.md`. Use `feat:`, `fix:`, `chore:`, and scopes like `feat(widget):`.
  A `feat:` bumps the minor version, so pick the type deliberately.
- Do not hand-edit `CHANGELOG.md` or bump versions — `release-please` owns both.
- CI (`.github/workflows/phpunit.yml`) runs `composer install` + `vendor/bin/phpunit` on
  PHP 8.4 for pushes and PRs to `main`. Keep the suite green.
- On a published release, `trigger-satis.yml` dispatches a rebuild of the private Satis
  repository. `renovate.json` keeps dependencies updated.
- `composer.lock` is listed in `.gitignore` but is nonetheless tracked in git — leave it
  committed and update it when dependencies change.

## Documentation expectations

`doc/` holds long-form per-module documentation linked from the README's table. It currently
covers entities, repositories, worker system, process system, executor, observer,
configuration, custom objects, logging, support, enums, presentation, commands, and validator.

Newer subsystems (`Macro/`, `Widget/`, `Dashboard/`, `Security/`, `Player/`, `Recorder/`,
`ServiceEndpointRunner/`) have no `doc/` page yet. When you make a substantial change:

- Update the matching `doc/*.md` page if one exists.
- Update the README's project-structure tree and module table if you add or remove a top-level
  `src/` directory.
