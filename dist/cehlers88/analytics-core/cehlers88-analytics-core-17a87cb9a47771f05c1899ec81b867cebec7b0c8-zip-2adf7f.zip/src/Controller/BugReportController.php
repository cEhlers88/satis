<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Controller;

use Cehlers88\AnalyticsCore\DTO\ResultDTO;
use Cehlers88\AnalyticsCore\ENUM\eBugReportState;
use Cehlers88\AnalyticsCore\Entity\BugReport;
use Cehlers88\AnalyticsCore\Entity\BugReportComment;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Repository\BugReportRepository;
use Cehlers88\AnalyticsCore\Support\BugReport\BugReportAttachmentStorage;
use Cehlers88\AnalyticsCore\Support\BugReport\BugReportService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\Exception\JsonException;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Routing\Attribute\Route;

/**
 * The backend of the bug report modal (templates/bugReport/), which every page of a
 * dashboard can open.
 *
 * Who may do what:
 *  - anybody signed in reports bugs, reads their own reports and writes to them,
 *  - an administrator reads every report, comments (also among administrators only),
 *    moves a report along, corrects it, deletes it and makes changelog entries from
 *    what was fixed.
 *
 * The lists and the single report come back as rendered HTML: the modal puts it in place
 * as it is, so the templates decide what a reporter and an administrator get to see.
 * Everything that changes something carries the CSRF token "bug_report".
 */
#[Route('/admin_api/bug-report', name: 'analytics_core_bug_report_')]
class BugReportController extends AbstractController
{
    public const CSRF_TOKEN_ID = 'bug_report';
    public const CSRF_HEADER = 'X-CSRF-Token';
    private const FILE_ID = '[a-f0-9]{16}';

    public function __construct(
        private readonly BugReportRepository        $reports,
        private readonly BugReportService           $service,
        private readonly BugReportAttachmentStorage $attachments,
    ) {
    }

    /**
     * The reports somebody may see, as the list of the modal. Query: scope (mine|all),
     * state, severity, q.
     */
    #[Route('', name: 'list', methods: ['GET'])]
    public function list(Request $request): Response
    {
        $user = $this->currentUser();
        $asAdmin = $this->isAdmin() && $request->query->get('scope', 'all') !== 'mine';

        $reports = $this->reports->findFor($user, $asAdmin, [
            'state' => $request->query->get('state'),
            'severity' => $request->query->get('severity'),
            'query' => $request->query->get('q'),
        ]);

        return $this->success('Fehlermeldungen', [
            'html' => $this->renderView('bugReport/_list.html.twig', [
                'reports' => array_map(fn(BugReport $report): array => $this->service->describe($report, $this->isAdmin(), $user), $reports),
                'asAdmin' => $asAdmin,
                'canAdmin' => $this->isAdmin(),
            ]),
            ...$this->counters($user),
        ]);
    }

    /** Only the numbers - the badge on the button asks for these. */
    #[Route('/counts', name: 'counts', methods: ['GET'])]
    public function counts(): Response
    {
        return $this->success('Fehlermeldungen', $this->counters($this->currentUser()));
    }

    /** JSON body: {title, description, severity, context: {page, browser, screen, version, language}} */
    #[Route('', name: 'create', methods: ['POST'])]
    public function create(Request $request): Response
    {
        $user = $this->currentUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $body = $this->body($request);
        if ($body instanceof Response) {
            return $body;
        }

        try {
            $report = $this->service->create($user, $body, is_array($body['context'] ?? null) ? $body['context'] : []);
        } catch (\InvalidArgumentException $exception) {
            return $this->error($exception->getMessage(), 400);
        }

        return $this->withReport($report, 'Die Meldung ist angekommen - danke!', 201);
    }

    #[Route('/{reportId}', name: 'show', requirements: ['reportId' => '\d+'], methods: ['GET'])]
    public function show(int $reportId): Response
    {
        $report = $this->findOrFail($reportId);

        return $report instanceof Response ? $report : $this->withReport($report, '');
    }

    /** JSON body: {title?, description?, severity?} - the reporter may correct a report nobody took on yet. */
    #[Route('/{reportId}', name: 'update', requirements: ['reportId' => '\d+'], methods: ['POST'])]
    public function update(int $reportId, Request $request): Response
    {
        $report = $this->findOrFail($reportId);
        if ($report instanceof Response) {
            return $report;
        }
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        if (!$this->isAdmin() && $report->getState() !== eBugReportState::New) {
            return $this->error('Die Meldung wird schon bearbeitet und lässt sich nicht mehr ändern.', 403);
        }
        $body = $this->body($request);
        if ($body instanceof Response) {
            return $body;
        }

        try {
            $this->service->update($report, $body, $this->currentUser());
        } catch (\InvalidArgumentException $exception) {
            return $this->error($exception->getMessage(), 400);
        }

        return $this->withReport($report, 'Gespeichert');
    }

    /** JSON body: {text, internal?} - `internal` is a note among administrators. */
    #[Route('/{reportId}/comment', name: 'comment', requirements: ['reportId' => '\d+'], methods: ['POST'])]
    public function comment(int $reportId, Request $request): Response
    {
        $report = $this->findOrFail($reportId);
        if ($report instanceof Response) {
            return $report;
        }
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $body = $this->body($request);
        if ($body instanceof Response) {
            return $body;
        }

        try {
            $this->service->comment(
                $report,
                $this->currentUser(),
                (string)($body['text'] ?? ''),
                $this->isAdmin() && ($body['internal'] ?? false) === true,
            );
        } catch (\InvalidArgumentException $exception) {
            return $this->error($exception->getMessage(), 400);
        }

        return $this->withReport($report, 'Kommentar gespeichert');
    }

    /** JSON body: {text} - somebody changes what they said themselves. */
    #[Route('/{reportId}/comments/{commentId}', name: 'edit_comment', requirements: ['reportId' => '\d+', 'commentId' => '\d+'], methods: ['POST'])]
    public function editComment(int $reportId, int $commentId, Request $request): Response
    {
        $report = $this->findOrFail($reportId);
        if ($report instanceof Response) {
            return $report;
        }
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $body = $this->body($request);
        if ($body instanceof Response) {
            return $body;
        }
        $comment = $this->commentOf($report, $commentId);
        if ($comment === null) {
            return $this->error('Diesen Kommentar gibt es nicht (mehr).', 404);
        }

        try {
            $this->service->editComment($comment, $this->currentUser(), (string)($body['text'] ?? ''));
        } catch (\InvalidArgumentException $exception) {
            return $this->error($exception->getMessage(), 403);
        }

        return $this->withReport($report, 'Kommentar geändert');
    }

    /**
     * Takes a comment back: the last one is gone, an older one stays as discarded - see
     * BugReportService::removeComment().
     */
    #[Route('/{reportId}/comments/{commentId}', name: 'remove_comment', requirements: ['reportId' => '\d+', 'commentId' => '\d+'], methods: ['DELETE'])]
    public function removeComment(int $reportId, int $commentId, Request $request): Response
    {
        $report = $this->findOrFail($reportId);
        if ($report instanceof Response) {
            return $report;
        }
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $comment = $this->commentOf($report, $commentId);
        if ($comment === null) {
            return $this->error('Diesen Kommentar gibt es nicht (mehr).', 404);
        }

        try {
            $gone = $this->service->removeComment($comment, $this->currentUser());
        } catch (\InvalidArgumentException $exception) {
            return $this->error($exception->getMessage(), 403);
        }

        return $this->withReport($report, $gone ? 'Der Kommentar ist gelöscht' : 'Der Kommentar ist als verworfen markiert');
    }

    /** JSON body: {state} - see eBugReportState. Administrators only. */
    #[Route('/{reportId}/state', name: 'state', requirements: ['reportId' => '\d+'], methods: ['POST'])]
    public function state(int $reportId, Request $request): Response
    {
        $report = $this->findOrFail($reportId, true);
        if ($report instanceof Response) {
            return $report;
        }
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $body = $this->body($request);
        if ($body instanceof Response) {
            return $body;
        }

        $state = eBugReportState::tryFrom((string)($body['state'] ?? ''));
        if ($state === null) {
            return $this->error('Diesen Status gibt es nicht.', 400);
        }
        $this->service->changeState($report, $state, $this->currentUser());

        return $this->withReport($report, sprintf('Status: %s', $state->label()));
    }

    #[Route('/{reportId}', name: 'delete', requirements: ['reportId' => '\d+'], methods: ['DELETE'])]
    public function delete(int $reportId, Request $request): Response
    {
        $report = $this->findOrFail($reportId, true);
        if ($report instanceof Response) {
            return $report;
        }
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }

        $this->service->remove($report);

        return $this->success('Die Meldung ist gelöscht', $this->counters($this->currentUser()));
    }

    /** Multipart upload, the files as "files[]" - any kind of file, see the download below. */
    #[Route('/{reportId}/attachments', name: 'attach', requirements: ['reportId' => '\d+'], methods: ['POST'])]
    public function attach(int $reportId, Request $request): Response
    {
        $report = $this->findOrFail($reportId);
        if ($report instanceof Response) {
            return $report;
        }
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }

        $files = $this->uploadedFiles($request);
        if ($files === []) {
            return $this->error('Es ist keine Datei angekommen - vielleicht war sie zu groß.', 400);
        }

        $errors = [];
        $stored = 0;
        foreach ($files as $file) {
            if (count($report->getAttachments()) >= BugReportAttachmentStorage::MAX_FILES_PER_REPORT) {
                $errors[] = sprintf('Mehr als %d Dateien gehen nicht.', BugReportAttachmentStorage::MAX_FILES_PER_REPORT);
                break;
            }
            try {
                $report->addAttachment($this->attachments->add((int)$report->getId(), $file));
                $stored++;
            } catch (\InvalidArgumentException $exception) {
                $errors[] = $exception->getMessage();
            }
        }
        if ($stored === 0) {
            return $this->error($errors[0] ?? 'Die Datei konnte nicht gespeichert werden.', 400);
        }
        $report->setUpdatedAt(new \DateTime());
        $this->reports->save($report, true);

        return $this->withReport($report, $errors === [] ? 'Angehängt' : implode(' ', $errors));
    }

    /**
     * An attachment - as a download, never as a page.
     *
     * What a user uploaded is served from the origin of the dashboard: an HTML or SVG file
     * among it must not become a page that runs here. Only raster images are shown with
     * their type, everything else leaves as an unnamed stream that nothing may sniff.
     */
    #[Route('/{reportId}/attachments/{fileId}', name: 'attachment', requirements: ['reportId' => '\d+', 'fileId' => self::FILE_ID], methods: ['GET'])]
    public function attachment(int $reportId, string $fileId, Request $request): Response
    {
        $report = $this->findOrFail($reportId);
        if ($report instanceof Response) {
            return $report;
        }
        $attachment = $report->getAttachment($fileId);
        $path = $attachment === null ? null : $this->attachments->path($reportId, $fileId);
        if ($attachment === null || $path === null) {
            return $this->error('Diese Datei gibt es nicht (mehr).', 404);
        }

        $inline = $request->query->getBoolean('inline') && BugReportAttachmentStorage::isPreviewable($attachment['mimeType']);
        $response = new BinaryFileResponse($path, 200, [], false, null, false, true);
        $response->headers->set('Content-Type', $inline ? $attachment['mimeType'] : 'application/octet-stream');
        $response->setContentDisposition(
            $inline ? ResponseHeaderBag::DISPOSITION_INLINE : ResponseHeaderBag::DISPOSITION_ATTACHMENT,
            $attachment['name'],
            self::asciiFileName($attachment['name']),
        );
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        $response->headers->set('Content-Security-Policy', "default-src 'none'; sandbox");

        return $response;
    }

    #[Route('/{reportId}/attachments/{fileId}', name: 'detach', requirements: ['reportId' => '\d+', 'fileId' => self::FILE_ID], methods: ['DELETE'])]
    public function detach(int $reportId, string $fileId, Request $request): Response
    {
        $report = $this->findOrFail($reportId);
        if ($report instanceof Response) {
            return $report;
        }
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        if ($report->getAttachment($fileId) === null) {
            return $this->error('Diese Datei gibt es nicht (mehr).', 404);
        }

        $report->removeAttachment($fileId);
        $report->setUpdatedAt(new \DateTime());
        $this->reports->save($report, true);
        $this->attachments->remove($reportId, $fileId);

        return $this->withReport($report, 'Die Datei ist entfernt');
    }

    /**
     * Makes changelog entries from what was fixed. JSON body: {reports?: [id, …], target?}
     * - without ids every fixed report that was not moved yet goes.
     */
    #[Route('/changelog', name: 'changelog', methods: ['POST'])]
    public function changelog(Request $request): Response
    {
        $this->denyUnlessAdmin();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $body = $this->body($request);
        if ($body instanceof Response) {
            return $body;
        }

        $wanted = $this->reports->findForChangelog();
        $ids = $body['reports'] ?? null;
        if (is_array($ids) && $ids !== []) {
            $ids = array_map('intval', $ids);
            $wanted = array_values(array_filter($wanted, static fn(BugReport $report): bool => in_array($report->getId(), $ids, true)));
        }
        if ($wanted === []) {
            return $this->error('Es gibt keine behobenen Meldungen, die noch nicht im Changelog stehen.', 400);
        }

        $result = $this->service->toChangelog($wanted, $this->currentUser(), is_string($body['target'] ?? null) ? $body['target'] : null);
        if ($result['moved'] === 0) {
            return $this->error('Kein Changelog nimmt Einträge entgegen.', 422);
        }

        return $this->success(
            sprintf('%d %s ins Changelog übernommen', $result['moved'], $result['moved'] === 1 ? 'Meldung' : 'Meldungen'),
            ['moved' => $result['moved'], 'target' => $result['target']],
        );
    }

    /** The comment of that report - internal ones only for an administrator. */
    private function commentOf(BugReport $report, int $commentId): ?BugReportComment
    {
        foreach ($report->getComments() as $comment) {
            if ($comment->getId() === $commentId && (!$comment->isInternal() || $this->isAdmin())) {
                return $comment;
            }
        }

        return null;
    }

    /** The report, or the answer that there is none - and that somebody else's is none of your business. */
    private function findOrFail(int $reportId, bool $adminOnly = false): BugReport|Response
    {
        $user = $this->currentUser();
        if ($adminOnly) {
            $this->denyUnlessAdmin();
        }
        $report = $this->reports->find($reportId);
        // the same answer either way: no hint that the report exists
        if ($report === null || (!$this->isAdmin() && !$report->belongsTo($user))) {
            return $this->error(sprintf('Fehlermeldung #%d gibt es nicht.', $reportId), 404);
        }

        return $report;
    }

    /** The report as the modal shows it, plus the numbers the button carries. */
    private function withReport(BugReport $report, string $message, int $status = 200): Response
    {
        return $this->success($message, [
            'id' => $report->getId(),
            'html' => $this->renderView('bugReport/_detail.html.twig', [
                'report' => $this->service->describe($report, $this->isAdmin(), $this->currentUser()),
                'canAdmin' => $this->isAdmin(),
                'isReporter' => $report->belongsTo($this->currentUser()),
            ]),
            ...$this->counters($this->currentUser()),
        ], $status);
    }

    /** @return array{counts: array<string, int>, adminCounts: array<string, int>|null} */
    private function counters(?User $user): array
    {
        return [
            'counts' => $this->reports->countStates($user, false),
            'adminCounts' => $this->isAdmin() ? $this->reports->countStates($user, true) : null,
        ];
    }

    private function currentUser(): ?User
    {
        $this->denyAccessUnlessGranted('ROLE_USER');
        $user = $this->getUser();

        return $user instanceof User ? $user : null;
    }

    private function isAdmin(): bool
    {
        return $this->isGranted('ROLE_ADMIN');
    }

    private function denyUnlessAdmin(): void
    {
        $this->currentUser();
        if (!$this->isAdmin()) {
            throw $this->createAccessDeniedException('Das dürfen nur Administratoren.');
        }
    }

    private function refuseWithoutToken(Request $request): ?Response
    {
        $token = $request->headers->get(self::CSRF_HEADER) ?? (string)$request->request->get('_token', '');

        return $this->isCsrfTokenValid(self::CSRF_TOKEN_ID, $token)
            ? null
            : $this->error('Der Sicherheitsschlüssel passt nicht - bitte die Seite neu laden.', 403);
    }

    /** @return array<string, mixed>|Response */
    private function body(Request $request): array|Response
    {
        try {
            return $request->toArray();
        } catch (JsonException) {
            return $this->error('Der Inhalt der Anfrage ist kein JSON-Objekt.', 400);
        }
    }

    /** @return list<UploadedFile> */
    private function uploadedFiles(Request $request): array
    {
        $files = [];
        // the array goes into a variable of its own: array_walk_recursive takes it by reference
        $all = $request->files->all();
        array_walk_recursive($all, static function (mixed $value) use (&$files): void {
            if ($value instanceof UploadedFile) {
                $files[] = $value;
            }
        });

        return $files;
    }

    private function success(string $message, mixed $data = [], int $status = 200): Response
    {
        return $this->json(ResultDTO::createSuccess($message, $data, $status), $status);
    }

    private function error(string $message, int $status = 500): Response
    {
        return $this->json(ResultDTO::createError($message, $status), $status);
    }

    /** A name every browser can save, next to the one the user gave. */
    private static function asciiFileName(string $name): string
    {
        $ascii = preg_replace('/[^\x20-\x7E]/', '_', $name) ?? '';
        $ascii = str_replace(['"', '\\'], '_', $ascii);

        return trim($ascii) === '' ? 'download' : $ascii;
    }
}
