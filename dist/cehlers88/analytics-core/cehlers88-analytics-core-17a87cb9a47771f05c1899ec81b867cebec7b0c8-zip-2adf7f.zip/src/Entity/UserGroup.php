<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\UserGroupRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * A group of users that hands its roles on to every member.
 *
 * The roles of a user are the roles assigned to the user directly plus the roles of
 * all groups the user belongs to (User::getRoles()) - a group is the way to give the
 * same set of roles to several users and to change it for all of them at once.
 */
#[ORM\Entity(repositoryClass: UserGroupRepository::class)]
#[ORM\UniqueConstraint(name: 'UNIQ_USER_GROUP_NAME', fields: ['name'])]
class UserGroup extends AbstractEntity
{
    #[ORM\Column(length: 100)]
    private string $name = '';

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    /**
     * @var list<string> The roles every member gets
     */
    #[ORM\Column]
    private array $roles = [];

    /**
     * @var Collection<int, User>
     */
    #[ORM\ManyToMany(targetEntity: User::class, mappedBy: 'userGroups')]
    private Collection $users;

    /**
     * @var Collection<int, self>
     */
    #[ORM\ManyToMany(targetEntity: self::class, inversedBy: 'childUserGroups')]
    private Collection $parentUserGroups;

    /**
     * @var Collection<int, self>
     */
    #[ORM\ManyToMany(targetEntity: self::class, mappedBy: 'parentUserGroups')]
    private Collection $childUserGroups;

    public function __construct()
    {
        $this->users = new ArrayCollection();
        $this->parentUserGroups = new ArrayCollection();
        $this->childUserGroups = new ArrayCollection();
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    /**
     * @return list<string>
     */
    public function getRoles(): array
    {

        $inherited = [];
        foreach ($this->getAncestors() as $ancestor) {
            array_push($inherited, ...$ancestor->getOwnRoles());
        }

        return array_values(array_unique([...$inherited, ...$this->getOwnRoles()]));
    }

    /**
     * @param list<string> $roles
     */
    public function setRoles(array $roles): static
    {
        $this->roles = array_values(array_unique(array_map('strval', $roles)));

        return $this;
    }

    /**
     * The roles of the group itself, without the ones it inherits from the groups above it -
     * what setRoles() stores and what editing a group works on.
     *
     * @return list<string>
     */
    public function getOwnRoles(): array
    {
        return array_values(array_unique(array_map('strval', $this->roles)));
    }

    /**
     * Every group above this one, however far up - what it inherits its roles from.
     *
     * @return list<self>
     */
    public function getAncestors(): array
    {
        $found = [];
        $walk = static function (self $group, array &$found) use (&$walk): void {
            foreach ($group->getParentUserGroups() as $parent) {
                // a group that inherits in a circle would walk forever
                if (!in_array($parent, $found, true)) {
                    $found[] = $parent;
                    $walk($parent, $found);
                }
            }
        };
        $walk($this, $found);

        return $found;
    }

    /**
     * @return Collection<int, self>
     */
    public function getParentUserGroups(): Collection
    {
        return $this->parentUserGroups;
    }

    /**
     * @return Collection<int, User>
     */
    public function getUsers(): Collection
    {
        return $this->users;
    }

    /** The owning side is the user - adding here keeps both sides in step. */
    public function addUser(User $user): static
    {
        if (!$this->users->contains($user)) {
            $this->users->add($user);
            $user->addUserGroup($this);
        }

        return $this;
    }

    public function removeUser(User $user): static
    {
        if ($this->users->removeElement($user)) {
            $user->removeUserGroup($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, self>
     */
    public function getChildUserGroups(): Collection
    {
        return $this->childUserGroups;
    }

    public function addChildUserGroup(self $childUserGroup): static
    {
        if (!$this->childUserGroups->contains($childUserGroup)) {
            $this->childUserGroups->add($childUserGroup);
            $childUserGroup->addParentUserGroup($this);
        }

        return $this;
    }

    public function addParentUserGroup(self $parentUserGroup): static
    {
        if (!$this->parentUserGroups->contains($parentUserGroup)) {
            $this->parentUserGroups->add($parentUserGroup);
        }

        return $this;
    }

    public function removeChildUserGroup(self $childUserGroup): static
    {
        if ($this->childUserGroups->removeElement($childUserGroup)) {
            $childUserGroup->removeParentUserGroup($this);
        }

        return $this;
    }

    public function removeParentUserGroup(self $parentUserGroup): static
    {
        $this->parentUserGroups->removeElement($parentUserGroup);

        return $this;
    }
}
