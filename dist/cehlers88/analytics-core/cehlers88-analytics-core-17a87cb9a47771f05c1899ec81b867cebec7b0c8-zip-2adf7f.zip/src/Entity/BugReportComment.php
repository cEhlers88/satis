<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\BugReportCommentRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * What was said about a bug report - by the reporter, by an administrator, or by the
 * system itself when a state changed.
 *
 * `internal` marks a note among administrators: the reporter never gets to see it.
 */
#[ORM\Entity(repositoryClass: BugReportCommentRepository::class)]
#[ORM\Table(name: 'bug_report_comment')]
class BugReportComment extends AbstractEntity
{
    #[ORM\ManyToOne(targetEntity: BugReport::class, inversedBy: 'comments')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private ?BugReport $report = null;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?User $author = null;

    #[ORM\Column(length: 255)]
    private string $authorName = '';

    #[ORM\Column(type: Types::TEXT)]
    private string $text = '';

    #[ORM\Column]
    private bool $internal = false;

    /** Written by the system, not by a person - a state that changed, say. */
    #[ORM\Column]
    private bool $automatic = false;

    /**
     * When the author took it back. A comment that somebody has already answered to is not
     * deleted - the history would have a hole in it; it is marked as discarded, and its text
     * is only shown when it is asked for.
     */
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $discardedAt = null;

    /** When the author last changed the text - shown next to the time it was written. */
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $editedAt = null;

    public function getReport(): ?BugReport
    {
        return $this->report;
    }

    public function setReport(?BugReport $report): static
    {
        $this->report = $report;

        return $this;
    }

    public function getAuthor(): ?User
    {
        return $this->author;
    }

    public function setAuthor(?User $author): static
    {
        $this->author = $author;

        return $this;
    }

    public function getAuthorName(): string
    {
        return $this->authorName;
    }

    public function setAuthorName(string $authorName): static
    {
        $this->authorName = $authorName;

        return $this;
    }

    public function getText(): string
    {
        return $this->text;
    }

    public function setText(string $text): static
    {
        $this->text = $text;

        return $this;
    }

    public function isInternal(): bool
    {
        return $this->internal;
    }

    public function setInternal(bool $internal): static
    {
        $this->internal = $internal;

        return $this;
    }

    public function isAutomatic(): bool
    {
        return $this->automatic;
    }

    public function setAutomatic(bool $automatic): static
    {
        $this->automatic = $automatic;

        return $this;
    }

    public function getDiscardedAt(): ?\DateTimeInterface
    {
        return $this->discardedAt;
    }

    public function setDiscardedAt(?\DateTimeInterface $discardedAt): static
    {
        $this->discardedAt = $discardedAt;

        return $this;
    }

    public function isDiscarded(): bool
    {
        return $this->discardedAt !== null;
    }

    public function getEditedAt(): ?\DateTimeInterface
    {
        return $this->editedAt;
    }

    public function setEditedAt(?\DateTimeInterface $editedAt): static
    {
        $this->editedAt = $editedAt;

        return $this;
    }

    /** Whether that user wrote it - only they may change or take back what they said. */
    public function isBy(?User $user): bool
    {
        return $user !== null && $this->author !== null && $this->author->getId() === $user->getId();
    }
}
