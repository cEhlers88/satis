<?php


namespace Cehlers88\AnalyticsCore\Recorder;

use Cehlers88\AnalyticsCore\DTO\RecorderResultDTO;
use Cehlers88\AnalyticsCore\Recorder\TrackingRecorder;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Symfony\Component\HttpFoundation\Request;

class CaptureEventRecorder
{
    public function __construct(
        private TrackingRecorder      $trackingRecorder,
        private ApplicationRepository $applicationRepository
    )
    {
    }

    public function handleDataArray(array $data, $key): RecorderResultDTO
    {
        return RecorderResultDTO::createSuccess([

        ]);
    }

    public function handleRequest(Request $request, $key): RecorderResultDTO
    {
        if (!$request->request->has('token')) {
            return RecorderResultDTO::createError('Token not found');
        }

        $token = $request->request->get('token');
        $application = $this->applicationRepository->findOneBy(['token' => $token]);

        if (!$application) {
            return RecorderResultDTO::createError('Application not found');
        }
        $this->trackingRecorder->track(
            $application,
            [
                ...$request->request->all(),
                'ip' => $request->getClientIp(),
                'key' => $key,
                'content' => $request->getContent(),
                'post' => $_POST,
                'request_all' => $request->request->all(),
                'header' => $request->headers->all(),
                'get' => $_GET,
                'server' => [
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'],
                    'request_uri' => $_SERVER['REQUEST_URI'],
                    'request_method' => $_SERVER['REQUEST_METHOD']
                ]
            ]
        );

        return RecorderResultDTO::createSuccess('Captured event successfully', [
            'application' => $application->getName(),
        ]);
    }
}