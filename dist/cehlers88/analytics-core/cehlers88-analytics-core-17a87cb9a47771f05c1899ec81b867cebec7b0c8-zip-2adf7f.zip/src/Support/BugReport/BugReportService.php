<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Support\BugReport;

use Cehlers88\AnalyticsCore\ENUM\eBugReportSeverity;
use Cehlers88\AnalyticsCore\ENUM\eBugReportState;
use Cehlers88\AnalyticsCore\Entity\BugReport;
use Cehlers88\AnalyticsCore\Entity\BugReportComment;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Event\BugReport\BugReportChangedEvent;
use Cehlers88\AnalyticsCore\Event\BugReport\BugReportCreatedEvent;
use Cehlers88\AnalyticsCore\Event\Changelog\AddChangelogEntriesEvent;
use Cehlers88\AnalyticsCore\Repository\BugReportRepository;
use Cehlers88\AnalyticsCore\Support\Markdown\MarkdownRenderer;
use Psr\EventDispatcher\EventDispatcherInterface;

/**
 * Everything that happens to a bug report: it is reported, talked about, moved along, and
 * ends up in a changelog.
 *
 * The service knows nothing of the application it runs in - who may do what is decided by
 * BugReportController, and whoever wants to be told about a report (a toast, a push
 * message) listens to the events dispatched here.
 */
class BugReportService
{
    public const MAX_TITLE_LENGTH = 200;
    public const MAX_DESCRIPTION_LENGTH = 20000;
    public const MAX_COMMENT_LENGTH = 10000;
    /** How much of a discarded comment is shown before it has to be asked for. */
    public const DISCARDED_PREVIEW_LENGTH = 60;
    /** What the modal may tell about the moment of the report - everything else is dropped. */
    public const CONTEXT_KEYS = ['page', 'url', 'browser', 'screen', 'version', 'language'];
    public const MAX_CONTEXT_LENGTH = 500;

    public function __construct(
        private readonly BugReportRepository       $reports,
        private readonly BugReportAttachmentStorage $attachments,
        private readonly ?EventDispatcherInterface $eventDispatcher = null,
    ) {
    }

    /**
     * @param array<string, mixed> $input title, description, severity
     * @param array<string, mixed> $context what the browser knew - see CONTEXT_KEYS
     */
    public function create(?User $reporter, array $input, array $context = []): BugReport
    {
        $report = new BugReport();
        $report->setReporter($reporter)
            ->setReporterName(self::nameOf($reporter))
            ->setTitle($this->readTitle($input))
            ->setDescription($this->readDescription($input))
            ->setSeverity($this->readSeverity($input) ?? eBugReportSeverity::Normal)
            ->setContext(self::cleanContext($context))
            ->setState(eBugReportState::New)
            ->setCreatedAt(new \DateTime())
            ->setUpdatedAt(new \DateTime());

        $this->reports->save($report, true);
        $this->eventDispatcher?->dispatch(new BugReportCreatedEvent($report));

        return $report;
    }

    /** Title, description and severity of a report - the reporter's while it is new, an administrator's always. */
    public function update(BugReport $report, array $input, ?User $actor): BugReport
    {
        if (array_key_exists('title', $input)) {
            $report->setTitle($this->readTitle($input));
        }
        if (array_key_exists('description', $input)) {
            $report->setDescription($this->readDescription($input));
        }
        $severity = $this->readSeverity($input);
        if ($severity !== null && $severity !== $report->getSeverity()) {
            $report->setSeverity($severity);
            $this->note($report, $actor, sprintf('Dringlichkeit: %s', $severity->label()));
        }
        $report->setUpdatedAt(new \DateTime());
        $this->reports->save($report, true);
        $this->eventDispatcher?->dispatch(new BugReportChangedEvent($report, BugReportChangedEvent::UPDATED, $actor));

        return $report;
    }

    public function comment(BugReport $report, ?User $author, string $text, bool $internal = false): BugReportComment
    {
        $text = trim($text);
        if ($text === '') {
            throw new \InvalidArgumentException('Ein Kommentar braucht einen Text.');
        }
        if (mb_strlen($text) > self::MAX_COMMENT_LENGTH) {
            throw new \InvalidArgumentException(sprintf('Ein Kommentar darf höchstens %d Zeichen lang sein.', self::MAX_COMMENT_LENGTH));
        }

        $comment = $this->addComment($report, $author, $text, $internal, false);
        $this->reports->save($report, true);
        $this->eventDispatcher?->dispatch(new BugReportChangedEvent($report, BugReportChangedEvent::COMMENTED, $author, $comment));

        return $comment;
    }

    /**
     * Changes what somebody said - their own comment, and only as long as it is theirs to
     * change: what the system wrote and what was taken back stay as they are.
     */
    public function editComment(BugReportComment $comment, ?User $actor, string $text): BugReportComment
    {
        if (!$comment->isBy($actor) || $comment->isAutomatic() || $comment->isDiscarded()) {
            throw new \InvalidArgumentException('Dieser Kommentar lässt sich nicht mehr ändern.');
        }
        $text = trim($text);
        if ($text === '') {
            throw new \InvalidArgumentException('Ein Kommentar braucht einen Text.');
        }
        if (mb_strlen($text) > self::MAX_COMMENT_LENGTH) {
            throw new \InvalidArgumentException(sprintf('Ein Kommentar darf höchstens %d Zeichen lang sein.', self::MAX_COMMENT_LENGTH));
        }

        $comment->setText($text)->setEditedAt(new \DateTime())->setUpdatedAt(new \DateTime());
        $report = $comment->getReport();
        if ($report !== null) {
            $report->setUpdatedAt(new \DateTime());
            $this->reports->save($report, true);
            $this->eventDispatcher?->dispatch(new BugReportChangedEvent($report, BugReportChangedEvent::COMMENTED, $actor, $comment));
        }

        return $comment;
    }

    /**
     * Takes a comment back.
     *
     * The last thing that was said is simply gone - nobody has answered to it yet. Anything
     * older stays where it is and is marked as discarded: the history keeps its order, and
     * the text is only shown when somebody asks for it.
     *
     * @return bool whether the comment was removed for good
     */
    public function removeComment(BugReportComment $comment, ?User $actor): bool
    {
        if (!$comment->isBy($actor) || $comment->isAutomatic() || $comment->isDiscarded()) {
            throw new \InvalidArgumentException('Dieser Kommentar lässt sich nicht zurücknehmen.');
        }
        $report = $comment->getReport();
        if ($report === null) {
            throw new \InvalidArgumentException('Dieser Kommentar gehört zu keiner Meldung.');
        }

        $gone = self::isLastComment($report, $comment);
        if ($gone) {
            $report->removeComment($comment);
        } else {
            $comment->setDiscardedAt(new \DateTime())->setUpdatedAt(new \DateTime());
        }
        $report->setUpdatedAt(new \DateTime());
        $this->reports->save($report, true);
        $this->eventDispatcher?->dispatch(new BugReportChangedEvent($report, BugReportChangedEvent::COMMENTED, $actor));

        return $gone;
    }

    /** Whether nothing was said after it. */
    public static function isLastComment(BugReport $report, BugReportComment $comment): bool
    {
        $comments = $report->getComments()->toArray();
        $last = end($comments);

        return $last !== false && $last === $comment;
    }

    /** Moves the report along; the state is written into its history as a comment of its own. */
    public function changeState(BugReport $report, eBugReportState $state, ?User $actor): BugReport
    {
        if ($state === $report->getState()) {
            return $report;
        }
        $report->setState($state)
            ->setClosedAt($state->isOpen() ? null : new \DateTime())
            ->setUpdatedAt(new \DateTime());
        $this->note($report, $actor, sprintf('Status: %s', $state->label()));
        $this->reports->save($report, true);
        $this->eventDispatcher?->dispatch(new BugReportChangedEvent($report, BugReportChangedEvent::STATE_CHANGED, $actor));

        return $report;
    }

    public function remove(BugReport $report): void
    {
        $id = $report->getId();
        $this->reports->remove($report, true);
        if ($id !== null) {
            $this->attachments->removeAll($id);
        }
    }

    /**
     * Hands fixed reports over to whoever keeps a changelog (the develope bundle, say) and
     * remembers which ones went there - none of them is offered twice.
     *
     * @param list<BugReport> $reports
     * @return array{moved: int, target: string|null, reports: list<BugReport>} the reports that went
     */
    public function toChangelog(array $reports, ?User $actor, ?string $target = null): array
    {
        $wanted = array_values(array_filter(
            $reports,
            static fn(BugReport $report): bool => $report->getState()->belongsInChangelog() && $report->getChangelogAt() === null,
        ));
        if ($wanted === [] || $this->eventDispatcher === null) {
            return ['moved' => 0, 'target' => null, 'reports' => []];
        }

        $event = $this->eventDispatcher->dispatch(new AddChangelogEntriesEvent(
            array_map(static fn(BugReport $report): string => sprintf('%s (Fehlermeldung #%d)', $report->getTitle(), $report->getId()), $wanted),
            $target,
            'Fehlermeldungen',
            $actor?->getUserIdentifier(),
        ));
        if (!$event instanceof AddChangelogEntriesEvent || !$event->isHandled()) {
            return ['moved' => 0, 'target' => null, 'reports' => []];
        }

        $movedAt = new \DateTime();
        foreach ($wanted as $report) {
            $report->setChangelogAt($movedAt);
            $this->note($report, $actor, 'Ins Changelog übernommen.');
            $this->reports->save($report);
        }
        $this->reports->save($wanted[0], true);

        return ['moved' => count($wanted), 'target' => $event->getAcceptedBy(), 'reports' => $wanted];
    }

    /**
     * The report as its templates show it - the comments already thinned out to what the
     * one looking at it may read.
     *
     * @return array<string, mixed>
     */
    public function describe(BugReport $report, bool $asAdmin, ?User $viewer = null): array
    {
        $markdown = new MarkdownRenderer();
        $comments = [];
        foreach ($report->getComments() as $comment) {
            if ($comment->isInternal() && !$asAdmin) {
                continue;
            }
            $own = $comment->isBy($viewer) && !$comment->isAutomatic();
            $comments[] = [
                'id' => $comment->getId(),
                'author' => $comment->getAuthorName(),
                'text' => $comment->getText(),
                'html' => $markdown->render($comment->getText()),
                'internal' => $comment->isInternal(),
                'automatic' => $comment->isAutomatic(),
                'createdAt' => $comment->getCreatedAt(),
                'editedAt' => $comment->getEditedAt(),
                'discarded' => $comment->isDiscarded(),
                'discardedAt' => $comment->getDiscardedAt(),
                // a discarded comment shows this much of itself; the rest has to be asked for
                'preview' => $comment->isDiscarded() ? self::preview($comment->getText()) : '',
                'own' => $own && !$comment->isDiscarded(),
            ];
        }

        return [
            'id' => $report->getId(),
            'title' => $report->getTitle(),
            'description' => $report->getDescription(),
            'descriptionHtml' => $markdown->render($report->getDescription()),
            'state' => $report->getState(),
            'severity' => $report->getSeverity(),
            'reporter' => $report->getReporterName(),
            'context' => $report->getContext(),
            'attachments' => array_map(static fn(array $attachment): array => [
                ...$attachment,
                'previewable' => BugReportAttachmentStorage::isPreviewable($attachment['mimeType']),
            ], $report->getAttachments()),
            'comments' => $comments,
            'createdAt' => $report->getCreatedAt(),
            'updatedAt' => $report->getUpdatedAt(),
            'closedAt' => $report->getClosedAt(),
            'changelogAt' => $report->getChangelogAt(),
            'inChangelog' => $report->getChangelogAt() !== null,
        ];
    }

    /** The first few words of a discarded comment, ending in an ellipsis. */
    public static function preview(string $text): string
    {
        $text = trim(preg_replace('/\s+/u', ' ', MarkdownRenderer::stripColors($text)) ?? '');
        if ($text === '') {
            return '…';
        }

        return mb_strlen($text) <= self::DISCARDED_PREVIEW_LENGTH
            ? $text
            : rtrim(mb_substr($text, 0, self::DISCARDED_PREVIEW_LENGTH)) . ' …';
    }

    /** The name a report is signed with - the account may be gone when it is read again. */
    public static function nameOf(?User $user): string
    {
        return $user?->getUserIdentifier() ?? 'Unbekannt';
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, string>
     */
    public static function cleanContext(array $context): array
    {
        $clean = [];
        foreach (self::CONTEXT_KEYS as $key) {
            $value = $context[$key] ?? null;
            if (!is_string($value) && !is_int($value)) {
                continue;
            }
            $value = trim(preg_replace('/[\x00-\x1F\x7F]/u', ' ', (string)$value) ?? '');
            if ($value !== '') {
                $clean[$key] = mb_substr($value, 0, self::MAX_CONTEXT_LENGTH);
            }
        }

        return $clean;
    }

    /** A line the system writes itself - a state that changed, a report that went to the changelog. */
    private function note(BugReport $report, ?User $actor, string $text): void
    {
        $this->addComment($report, $actor, $text, false, true);
    }

    private function addComment(BugReport $report, ?User $author, string $text, bool $internal, bool $automatic): BugReportComment
    {
        $comment = new BugReportComment();
        $comment->setAuthor($author)
            ->setAuthorName(self::nameOf($author))
            ->setText($text)
            ->setInternal($internal)
            ->setAutomatic($automatic)
            ->setCreatedAt(new \DateTime())
            ->setUpdatedAt(new \DateTime());
        $report->addComment($comment);
        $report->setUpdatedAt(new \DateTime());

        return $comment;
    }

    /** @param array<string, mixed> $input */
    private function readTitle(array $input): string
    {
        $title = trim(str_replace(["\r", "\n"], ' ', (string)($input['title'] ?? '')));
        if ($title === '') {
            throw new \InvalidArgumentException('Eine Fehlermeldung braucht einen Titel.');
        }

        return mb_substr($title, 0, self::MAX_TITLE_LENGTH);
    }

    /** @param array<string, mixed> $input */
    private function readDescription(array $input): string
    {
        $description = trim((string)($input['description'] ?? ''));
        if ($description === '') {
            throw new \InvalidArgumentException('Bitte beschreibe, was passiert ist.');
        }
        if (mb_strlen($description) > self::MAX_DESCRIPTION_LENGTH) {
            throw new \InvalidArgumentException(sprintf('Die Beschreibung darf höchstens %d Zeichen lang sein.', self::MAX_DESCRIPTION_LENGTH));
        }

        return $description;
    }

    /** @param array<string, mixed> $input */
    private function readSeverity(array $input): ?eBugReportSeverity
    {
        $severity = $input['severity'] ?? null;
        if ($severity === null || $severity === '') {
            return null;
        }
        $found = is_string($severity) ? eBugReportSeverity::tryFrom($severity) : null;
        if ($found === null) {
            throw new \InvalidArgumentException('Diese Dringlichkeit gibt es nicht.');
        }

        return $found;
    }
}
