<?php

namespace Cehlers88\AnalyticsCore\Support;

use Cehlers88\AnalyticsCore\Support\DTO\CurlResponseDTO;
use RuntimeException;

class CurlHelper
{
    private int $timeout = 10;
    private bool $returnTransfer = true;

    public function get(string $url, array $headers = []): CurlResponseDTO
    {
        return $this->_exec($url, 'GET', '', $headers);
    }

    private function _exec(
        string $url,
        string $method,
        string $body = '',
        array  $headers = [],
    ): CurlResponseDTO
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, $this->returnTransfer);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        if (!empty($body)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $response = curl_exec($ch);

        if ($response === false) {
            throw new RuntimeException(
                sprintf(
                    'Curl error (%d): %s',
                    curl_errno($ch),
                    curl_error($ch)
                )
            );
        }

        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $body = $response;

        if ($statusCode !== 200) {
            throw new RuntimeException('Curl error: ' . $statusCode . ' ' . $body . '');
        }

        try {
            $body = json_decode($response, true);
            if (is_null($body) && !is_null($response)) {
                $body = $response;
            }
        } catch (\Exception) {
            $body = $response;
        }

        return new CurlResponseDTO(
            $statusCode,
            $body
        );
    }

    public function post(string $url, mixed $data, array $headers): CurlResponseDTO
    {
        $headers[] = 'Content-Type: application/json';
        $data = is_string($data) ? $data : json_encode($data, JSON_THROW_ON_ERROR);
        return $this->_exec($url, 'POST', $data, $headers);
    }

    public function postJson(
        string $url,
        mixed  $data = [],
        array  $headers = []
    ): CurlResponseDTO
    {
        $headers[] = 'Content-Type: application/json';
        $data = is_string($data) ? $data : json_encode($data, JSON_THROW_ON_ERROR);

        return $this->_exec(
            $url,
            'POST',
            $data,
            $headers
        );
    }
}