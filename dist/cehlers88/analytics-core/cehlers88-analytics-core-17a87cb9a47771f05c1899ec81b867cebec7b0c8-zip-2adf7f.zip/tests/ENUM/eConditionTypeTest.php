<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\ENUM;

use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use PHPUnit\Framework\TestCase;

class eConditionTypeTest extends TestCase
{
    public function test_every_type_is_read_back_from_the_operator_it_is_written_as(): void
    {
        foreach (eConditionType::cases() as $type) {
            $this->assertSame($type, eConditionType::tryFromOperator($type->operator()), $type->name);
        }
    }

    public function test_reads_the_other_spellings_regardless_of_their_case(): void
    {
        $this->assertSame(eConditionType::EQUALS, eConditionType::tryFromOperator('==='));
        $this->assertSame(eConditionType::NOT_EQUALS, eConditionType::tryFromOperator('!=='));
        $this->assertSame(eConditionType::AND, eConditionType::tryFromOperator('AND'));
        $this->assertSame(eConditionType::NOT_CONTAINS, eConditionType::tryFromOperator('not contains'));
        $this->assertSame(eConditionType::STARTS_WITH, eConditionType::tryFromOperator(' Starts With '));
    }

    public function test_names_the_other_spellings_of_a_type(): void
    {
        $this->assertSame(['===', 'equals'], eConditionType::EQUALS->aliases());
        $this->assertSame(['not contains'], eConditionType::NOT_CONTAINS->aliases());
        $this->assertSame(['starts with'], eConditionType::STARTS_WITH->aliases());
    }

    public function test_a_word_that_is_no_operator_is_none(): void
    {
        $this->assertNull(eConditionType::tryFromOperator('if'));
        $this->assertNull(eConditionType::tryFromOperator(''));
    }

    public function test_tells_logical_types_from_comparisons(): void
    {
        $this->assertTrue(eConditionType::XOR->isLogical());
        $this->assertTrue(eConditionType::NOT->isLogical());
        $this->assertFalse(eConditionType::LESS_THAN->isLogical());
    }
}
