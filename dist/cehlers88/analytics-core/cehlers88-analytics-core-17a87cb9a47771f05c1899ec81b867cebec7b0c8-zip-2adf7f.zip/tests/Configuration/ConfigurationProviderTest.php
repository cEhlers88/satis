<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Configuration;

use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\Entity\VariableStore;
use Cehlers88\AnalyticsCore\ENUM\eInputType;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\VariableStoreRepository;
use PHPUnit\Framework\TestCase;

/**
 * The buffer the configuration masks are built from: every declared item with what the
 * store holds for it, plus the constants and the individuals - the variables no
 * configuration group declares.
 */
class ConfigurationProviderTest extends TestCase
{
    private function group(string $key, string $title, ConfigurationItemDTO ...$items): AbstractConfigurationGroup
    {
        return new class($key, $title, $items) extends AbstractConfigurationGroup {
            /** @param ConfigurationItemDTO[] $items */
            public function __construct(private string $key, private string $title, private array $items)
            {
            }

            public function getItems(): array
            {
                return $this->items;
            }

            public function getGroupTitle(): string
            {
                return $this->title;
            }

            public function getGroupDescription(): string
            {
                return '';
            }

            public function getKey(): string
            {
                return $this->key;
            }
        };
    }

    private function variable(string $name, mixed $value, string $type = 'string'): VariableStore
    {
        return new VariableStore()
            ->setName($name)
            ->setContext(eMacroVariableContext::SERVER)
            ->setValue([$type, $value]);
    }

    /** @param VariableStore[] $variables */
    private function provider(array $groups, array $variables): ConfigurationProvider
    {
        $variableStoreRepository = $this->createMock(VariableStoreRepository::class);
        $variableStoreRepository->method('findAll')->willReturn($variables);

        return new ConfigurationProvider(
            $groups,
            $this->createMock(ApplicationRepository::class),
            $variableStoreRepository,
            $this->createMock(VariablesProvider::class)
        );
    }

    /** Every declared item gets what is stored for it, whatever else the store holds. */
    public function testEveryGroupKeepsItsItemsHoweverManyVariablesAreStored(): void
    {
        $provider = $this->provider(
            [
                $this->group('main.general', 'General', ConfigurationItemDTO::create('serverHomeUrl', 'Home URL', eInputType::TEXT_SINGLE_LINE, 'http://localhost')),
                $this->group('main.automatics', 'Automatics', ConfigurationItemDTO::create('temporaryRunChain', 'Run chain')),
            ],
            [
                $this->variable('main.general.serverHomeUrl', 'https://analytics.example'),
                $this->variable('main.automatics.temporaryRunChain', '7'),
                $this->variable('mqtt.host', 'broker.local'),
                $this->variable('CONSTANT.apiKey', 'secret'),
            ]
        );

        $buffer = $provider->getConfigurations();
        $groups = [];
        foreach ($buffer as $group) {
            $groups[$group['key']] = $group;
        }

        $this->assertSame(['main.general', 'main.automatics', 'CONSTANT', 'individuals'], array_keys($groups));
        $this->assertCount(1, $groups['main.general']['items']);
        $this->assertCount(1, $groups['main.automatics']['items'], 'the second group has to survive the first one');

        $url = $groups['main.general']['items'][0];
        $this->assertSame('main.general.serverHomeUrl', $url['key'], 'an item is buffered under its whole variable name');
        $this->assertSame([[
            'application_id' => -1,
            'context' => eMacroVariableContext::SERVER,
            'type' => 'string',
            'value' => 'https://analytics.example',
        ]], $url['values']);

        $runChain = $groups['main.automatics']['items'][0];
        $this->assertSame('7', $runChain['values'][0]['value']);
    }

    public function testAnItemWithoutAStoredValueFallsBackToItsDefault(): void
    {
        $provider = $this->provider(
            [$this->group('main.general', 'General', ConfigurationItemDTO::create('runChainHistoryLength', 'History', eInputType::NUMBER, 100))],
            []
        );

        $item = $provider->getConfigurations()[0]['items'][0];

        $this->assertSame(100, $item['values'][0]['value']);
        $this->assertArrayNotHasKey('type', $item['values'][0], 'a default is not a stored value');
    }

    public function testConstantsAndIndividualsAreCollected(): void
    {
        $provider = $this->provider(
            [$this->group('main.general', 'General', ConfigurationItemDTO::create('serverHomeUrl', 'Home URL'))],
            [
                $this->variable('CONSTANT.apiKey', 'secret'),
                $this->variable('CONSTANT.password', 'hunter2', 'password'),
                $this->variable('mqtt.host', 'broker.local'),
                $this->variable('mqtt.port', 1883, 'numeric'),
            ]
        );

        $buffer = $provider->getConfigurations();
        $constants = $buffer[1];
        $individuals = $buffer[2];

        $this->assertSame('CONSTANT', $constants['key']);
        $this->assertCount(2, $constants['items']);
        $this->assertSame('apiKey', $constants['items'][0]['key'], 'the prefix is not part of the name any more');
        $this->assertSame(eInputType::PASSWORD, $constants['items'][1]['inputDef']->inputType, 'a password stays hidden');

        $this->assertSame(ConfigurationProvider::KEY_INDIVIDUALS, $individuals['key']);
        $this->assertCount(2, $individuals['items']);
        $this->assertSame('mqtt.host', $individuals['items'][0]['key']);
        $this->assertSame('host', $individuals['items'][0]['label'], 'the label is the last part of the name');
        $this->assertSame(1883, $individuals['items'][1]['values'][0]['value']);
    }

    public function testAStoredListBecomesARepeatableInput(): void
    {
        $provider = $this->provider([], [$this->variable('main.general.banEndpoints', [['url' => '/spam'], ['url' => '/bots']], 'array')]);

        $item = $provider->getConfigurations()[1]['items'][0];

        $this->assertSame(eInputType::REPEAT, $item['inputDef']->inputType);
        $this->assertCount(1, $item['inputDef']->children, 'the fields of a row come from its first entry');
        $this->assertSame('url', $item['inputDef']->children[0]->key);
    }

    public function testAVariableWithoutAValueDoesNotBreakTheBuffer(): void
    {
        $broken = new VariableStore()->setName('mqtt.broken')->setContext(eMacroVariableContext::SERVER);

        $item = $this->provider([], [$broken])->getConfigurations()[1]['items'][0];

        $this->assertNull($item['values'][0]['value']);
        $this->assertSame(eInputType::TEXT_SINGLE_LINE, $item['inputDef']->inputType);
    }
}
