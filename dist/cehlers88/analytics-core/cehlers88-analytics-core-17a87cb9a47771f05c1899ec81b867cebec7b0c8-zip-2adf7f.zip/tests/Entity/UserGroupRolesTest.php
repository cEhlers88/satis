<?php

namespace Cehlers88\AnalyticsCore\Tests\Entity;

use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Entity\UserGroup;
use Doctrine\Common\Collections\ArrayCollection;
use PHPUnit\Framework\TestCase;

class UserGroupRolesTest extends TestCase
{
    protected function setUp(): void
    {
        if (!class_exists(ArrayCollection::class)) {
            $this->markTestSkipped('doctrine/collections is not installed');
        }
    }

    private function group(string $name, array $roles): UserGroup
    {
        return (new UserGroup())->setName($name)->setRoles($roles);
    }

    public function testAUserInheritsTheRolesOfItsGroups(): void
    {
        $user = (new User())->setRoles(['ROLE_DASHBOARD', 'ROLE_DASHBOARD']);
        $editors = $this->group('Editors', ['ROLE_DASHBOARD', 'ACCESS_DOCUMENTS']);
        $finance = $this->group('Finance', ['ACCESS_FIBU', 'ACCESS_DOCUMENTS']);

        $user->addUserGroup($editors);
        $finance->addUser($user);

        $this->assertSame(['ROLE_DASHBOARD'], $user->getAssignedRoles());
        $this->assertSame(['ROLE_DASHBOARD', 'ACCESS_DOCUMENTS', 'ACCESS_FIBU'], $user->getGroupRoles());
        $this->assertSame(['ROLE_DASHBOARD', 'ACCESS_DOCUMENTS', 'ACCESS_FIBU', 'ROLE_USER'], $user->getRoles());
        $this->assertTrue($user->hasRole('ACCESS_FIBU'));
        $this->assertSame(['ROLE_DASHBOARD' => ['Editors'], 'ACCESS_DOCUMENTS' => ['Editors', 'Finance'], 'ACCESS_FIBU' => ['Finance']], $user->getRoleSources());
        $this->assertTrue($finance->getUsers()->contains($user), 'both sides of the relation are kept in step');
        $this->assertTrue($user->getUserGroups()->contains($finance));
    }

    public function testLeavingAGroupTakesItsRolesAway(): void
    {
        $user = new User();
        $admins = $this->group('Admins', ['ROLE_ADMIN']);
        $user->addUserGroup($admins);
        $this->assertContains('ROLE_ADMIN', $user->getRoles());

        $admins->removeUser($user);

        $this->assertSame(['ROLE_USER'], $user->getRoles());
        $this->assertCount(0, $user->getUserGroups());
        $this->assertCount(0, $admins->getUsers());
    }

    public function testChangingTheRolesOfAGroupChangesItsMembers(): void
    {
        $user = new User();
        $group = $this->group('Support', ['ROLE_DASHBOARD']);
        $user->addUserGroup($group);

        $group->setRoles(['ALLOW_REMOTE_DEBUG']);

        $this->assertSame(['ALLOW_REMOTE_DEBUG', 'ROLE_USER'], $user->getRoles());
    }
}
