<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Entity;

use Cehlers88\AnalyticsCore\Entity\Client;
use PHPUnit\Framework\TestCase;

class ClientVisitTest extends TestCase
{
    public function testTheLastVisitOnlyMovesForward(): void
    {
        $client = (new Client())->setFirstVisit(new \DateTime('2026-09-01 10:00'));

        $client->registerVisit(new \DateTime('2026-09-10 08:00'));
        $client->registerVisit(new \DateTime('2026-09-05 12:00'));

        $this->assertEquals(new \DateTime('2026-09-10 08:00'), $client->getLastVisit(), 'a late report of an older visit changes nothing');
        $this->assertEquals(new \DateTime('2026-09-01 10:00'), $client->getFirstVisit());
    }

    public function testAVisitBeforeTheFirstOneMovesTheFirstVisitBack(): void
    {
        $client = (new Client())->setFirstVisit(new \DateTime('2026-09-10 10:00'));

        $client->registerVisit(new \DateTime('2026-09-02 09:00'));

        $this->assertEquals(new \DateTime('2026-09-02 09:00'), $client->getFirstVisit());
        $this->assertEquals(new \DateTime('2026-09-02 09:00'), $client->getLastVisit());
    }

    public function testANewClientStartsWithoutALastVisit(): void
    {
        $this->assertNull((new Client())->getLastVisit());
    }
}
