<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support;

use Cehlers88\AnalyticsCore\Support\Markdown\MarkdownRenderer;
use PHPUnit\Framework\TestCase;

class MarkdownRendererTest extends TestCase
{
    public function testWithoutAResolverAnImageStaysText(): void
    {
        $html = (new MarkdownRenderer())->render('![logo](https://example.org/logo.png)');

        $this->assertStringNotContainsString('<img', $html);
    }

    public function testTheResolverDecidesWhereImagesComeFrom(): void
    {
        $renderer = new MarkdownRenderer(static fn(string $source): ?string => str_starts_with($source, 'changelog-image:')
            ? '/images/' . substr($source, 16)
            : null);

        $html = $renderer->render("![Screen \"1\"](changelog-image:ab12)\n\n![evil](javascript:alert(1))");

        $this->assertStringContainsString('<img src="/images/ab12" alt="Screen &quot;1&quot;" loading="lazy">', $html);
        $this->assertStringNotContainsString('javascript:alert(1)"', $html, 'a refused source is no image');
    }

    public function testTheMarkdownOfTheNotesStaysAsItWas(): void
    {
        $html = (new MarkdownRenderer())->render("## Release\n- [x] **done** task\n- [ ] open");

        $this->assertStringContainsString('<h4>Release</h4>', $html);
        $this->assertStringContainsString('<li class="is-task is-done"><input type="checkbox" disabled checked> <strong>done</strong> task</li>', $html);
        $this->assertSame(['done' => 1, 'total' => 2], MarkdownRenderer::taskCount("- [x] a\n- [ ] b"));
    }
}
