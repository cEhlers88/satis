<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Support\AbstractPropertyBag;
use PHPUnit\Framework\TestCase;

/**
 * Shared services (workers, jobs, executors) are handed out as copies, which
 * only works if a copy does not share the mutable property definitions.
 */
class AbstractPropertyBagCloneTest extends TestCase
{
    public function testCopyDoesNotShareItsPropertyDefinitions(): void
    {
        $original = $this->createBag();
        $original->addProperty(PropertyDTO::create('limit', 1000, 'int', true));

        $copy = clone $original;
        $copy->setPropertyValue('limit', 5);

        self::assertSame(1000, $original->getPropertyValue('limit'));
        self::assertSame(5, $copy->getPropertyValue('limit'));
        self::assertNotSame($original->getProperty('limit'), $copy->getProperty('limit'));
    }

    public function testPropertiesAddedToACopyStayOnTheCopy(): void
    {
        $original = $this->createBag();

        $copy = clone $original;
        $copy->addProperty(PropertyDTO::create('allowed_runtime', -1));

        self::assertTrue($copy->hasProperty('allowed_runtime'));
        self::assertFalse($original->hasProperty('allowed_runtime'));
    }

    private function createBag(): AbstractPropertyBag
    {
        return new class extends AbstractPropertyBag {
        };
    }
}
