<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support\Condition;

use Cehlers88\AnalyticsCore\DTO\ConditionGroupDTO;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\Support\Condition\ConditionEvaluator;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class ConditionEvaluatorTest extends TestCase
{
    public static function plainValues(): array
    {
        return [
            'true' => [true, true],
            'false' => [false, false],
            'number above zero' => [1, true],
            'zero' => [0, false],
            'string true' => ['TRUE', true],
            'string one' => ['1', true],
            'any other string' => ['yes', false],
            'null' => [null, false],
            'list of fulfilled values' => [[true, 1, 'true'], true],
            'list with one unfulfilled value' => [[true, false], false],
            'empty list' => [[], true],
        ];
    }

    #[DataProvider('plainValues')]
    public function test_plain_values_keep_the_meaning_the_if_macro_gave_them(mixed $condition, bool $expected): void
    {
        $this->assertSame($expected, new ConditionEvaluator()->evaluate($condition));
    }

    public static function comparisons(): array
    {
        return [
            'equal regardless of the type an editor wrote it in' => [['==', [1, '1']], true],
            'not equal' => [['!=', [1, 2]], true],
            'greater than reads left to right' => [['>', [3, 2]], true],
            'a chain holds when every pair does' => [['<', [1, 5, 10]], true],
            'a chain fails on any pair' => [['<', [1, 11, 10]], false],
            'contains in a string' => [['contains', ['hello', 'ell']], true],
            'not contains in a list' => [['!contains', [['a', 'b'], 'c']], true],
            'starts with' => [['startsWith', ['foobar', 'foo']], true],
            'ends with' => [['ends with', ['foobar', 'foo']], false],
            'a single value compares to nothing' => [['==', [1]], false],
            'a group inside a comparison stands for its result' => [['==', [['&&', [true, true]], true]], true],
        ];
    }

    #[DataProvider('comparisons')]
    public function test_compares_the_values_of_a_group(array $condition, bool $expected): void
    {
        $this->assertSame($expected, new ConditionEvaluator()->evaluate($condition));
    }

    public static function logicalGroups(): array
    {
        return [
            'and' => [['&&', [true, ['==', [1, 1]]]], true],
            'or' => [['||', [false, false]], false],
            'xor holds for an odd number of fulfilled values' => [['xor', [true, false, true]], false],
            'not' => [['!', [false]], true],
            'not over several values reads as not all of them' => [['not', [true, false]], true],
        ];
    }

    #[DataProvider('logicalGroups')]
    public function test_combines_the_conditions_of_a_logical_group(array $condition, bool $expected): void
    {
        $this->assertSame($expected, new ConditionEvaluator()->evaluate($condition));
    }

    public function test_reads_a_group_that_was_already_read_into_a_dto(): void
    {
        $condition = ConditionGroupDTO::create([
            ConditionGroupDTO::create([2, 1], eConditionType::GREATER_THAN),
            true,
        ], eConditionType::AND);

        $this->assertTrue(new ConditionEvaluator()->evaluate($condition));
    }

    public function test_compares_what_a_value_that_still_has_to_run_results_in(): void
    {
        $resolve = static fn(mixed $value): mixed => $value instanceof \stdClass ? $value->result : $value;

        $this->assertTrue(new ConditionEvaluator()->evaluate(
            ['==', [$this->command('get_var', 'x'), 'x']],
            $resolve
        ));
    }

    public function test_stops_at_the_first_value_that_decides_the_group(): void
    {
        $resolved = [];
        $resolve = static function (mixed $value) use (&$resolved): mixed {
            if (!$value instanceof \stdClass) {
                return $value;
            }
            $resolved[] = $value->name;

            return $value->result;
        };

        $evaluator = new ConditionEvaluator();

        $this->assertTrue($evaluator->evaluate(['||', [$this->command('first', true), $this->command('second', true)]], $resolve));
        $this->assertFalse($evaluator->evaluate(['&&', [$this->command('third', false), $this->command('fourth', true)]], $resolve));
        $this->assertSame(['first', 'third'], $resolved);
    }

    /** Stands in for a command - what the resolver runs is up to the caller. */
    private function command(string $name, mixed $result): \stdClass
    {
        return (object)['name' => $name, 'result' => $result];
    }
}
