<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support\BugReport;

use Cehlers88\AnalyticsCore\Support\BugReport\BugReportAttachmentStorage;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class BugReportAttachmentStorageTest extends TestCase
{
    private string $directory;
    private BugReportAttachmentStorage $storage;

    protected function setUp(): void
    {
        $this->directory = sys_get_temp_dir() . '/bug-report-attachments-' . bin2hex(random_bytes(4));
        $this->storage = new BugReportAttachmentStorage($this->directory);
    }

    protected function tearDown(): void
    {
        self::removeDirectory($this->directory);
    }

    public static function removeDirectory(string $directory): void
    {
        if (!is_dir($directory)) {
            return;
        }
        foreach (scandir($directory) ?: [] as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $path = $directory . '/' . $entry;
            is_dir($path) ? self::removeDirectory($path) : unlink($path);
        }
        rmdir($directory);
    }

    private function upload(string $content, string $name, string $mimeType = 'text/plain'): UploadedFile
    {
        $path = tempnam(sys_get_temp_dir(), 'bug-report-upload-');
        file_put_contents($path, $content);

        return new UploadedFile($path, $name, $mimeType, null, true);
    }

    public function testAnyKindOfFileIsStoredUnderAHarmlessName(): void
    {
        $attachment = $this->storage->add(12, $this->upload('kaboom', '../../etc/pässwörter.log', 'text/plain'));

        $this->assertMatchesRegularExpression('/^[a-f0-9]{16}$/', $attachment['id'], 'nothing of the name reaches the disk');
        $this->assertSame('pässwörter.log', $attachment['name']);
        // whatever else arrives as a name: no directory and no control character survives it
        $this->assertSame('.._.._etc__passwd', BugReportAttachmentStorage::cleanName("../../etc\0/passwd"));
        $this->assertSame('Datei', BugReportAttachmentStorage::cleanName(" \n "));
        $this->assertSame(6, $attachment['size']);
        $this->assertSame('text/plain', $attachment['mimeType']);
        $this->assertSame('kaboom', file_get_contents((string)$this->storage->path(12, $attachment['id'])));
        $this->assertFalse(BugReportAttachmentStorage::isPreviewable($attachment['mimeType']));
    }

    public function testOnlyRasterImagesAreEverShownInline(): void
    {
        foreach (['image/png', 'image/jpeg', 'image/gif', 'image/webp'] as $mimeType) {
            $this->assertTrue(BugReportAttachmentStorage::isPreviewable($mimeType));
        }
        foreach (['image/svg+xml', 'text/html', 'application/pdf'] as $mimeType) {
            $this->assertFalse(BugReportAttachmentStorage::isPreviewable($mimeType), $mimeType . ' must not be shown inline');
        }
        // an svg claiming to be a png is stored, but never handed out as an image
        $attachment = $this->storage->add(12, $this->upload('<svg onload="alert(1)"></svg>', 'shot.png', 'image/svg+xml'));
        $this->assertSame('image/svg+xml', $attachment['mimeType']);
        $this->assertFalse(BugReportAttachmentStorage::isPreviewable($attachment['mimeType']));
    }

    public function testAMimeTypeThatIsNoneBecomesAStream(): void
    {
        $attachment = $this->storage->add(12, $this->upload('x', 'weird', "text/plain;\r\nX-Evil: 1"));

        $this->assertSame('application/octet-stream', $attachment['mimeType']);
    }

    public function testAnEmptyFileIsRefused(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->storage->add(12, $this->upload('', 'empty.log'));
    }

    public function testOnlyTheFilesOfThatReportAreFound(): void
    {
        $attachment = $this->storage->add(12, $this->upload('kaboom', 'log.txt'));

        $this->assertNotNull($this->storage->path(12, $attachment['id']));
        $this->assertNull($this->storage->path(13, $attachment['id']), 'a file belongs to its report');
        $this->assertNull($this->storage->path(12, '../../../etc/passwd'));
        $this->assertNull($this->storage->path(12, 'ffffffffffffffff'));
    }

    public function testFilesGoWithTheirReport(): void
    {
        $first = $this->storage->add(12, $this->upload('one', 'one.txt'));
        $second = $this->storage->add(12, $this->upload('two', 'two.txt'));

        $this->storage->remove(12, $first['id']);
        $this->assertNull($this->storage->path(12, $first['id']));
        $this->assertNotNull($this->storage->path(12, $second['id']));

        $this->storage->removeAll(12);
        $this->assertNull($this->storage->path(12, $second['id']));
        $this->assertDirectoryDoesNotExist($this->directory . '/12');
    }
}
