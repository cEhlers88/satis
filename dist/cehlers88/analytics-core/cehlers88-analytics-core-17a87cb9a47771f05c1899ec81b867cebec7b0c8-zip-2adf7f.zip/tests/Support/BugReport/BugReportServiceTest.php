<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support\BugReport;

use Cehlers88\AnalyticsCore\ENUM\eBugReportSeverity;
use Cehlers88\AnalyticsCore\ENUM\eBugReportState;
use Cehlers88\AnalyticsCore\Entity\BugReport;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Event\BugReport\BugReportChangedEvent;
use Cehlers88\AnalyticsCore\Event\BugReport\BugReportCreatedEvent;
use Cehlers88\AnalyticsCore\Event\Changelog\AddChangelogEntriesEvent;
use Cehlers88\AnalyticsCore\Repository\BugReportRepository;
use Cehlers88\AnalyticsCore\Support\BugReport\BugReportAttachmentStorage;
use Cehlers88\AnalyticsCore\Support\BugReport\BugReportService;
use PHPUnit\Framework\TestCase;
use Psr\EventDispatcher\EventDispatcherInterface;

class BugReportServiceTest extends TestCase
{
    /** @var list<object> */
    private array $dispatched = [];
    private bool $changelogTakesEntries = true;

    private function service(): BugReportService
    {
        $this->dispatched = [];

        $reports = $this->createMock(BugReportRepository::class);
        $reports->method('save')->willReturnCallback(static function (BugReport $report): void {
            // the database would give the report its id; the tests do it here
            if ($report->getId() === null) {
                (new \ReflectionProperty(BugReport::class, 'id'))->setValue($report, 17);
            }
        });

        $dispatcher = new class($this->dispatched, $this->changelogTakesEntries) implements EventDispatcherInterface {
            public function __construct(private array &$dispatched, private readonly bool $takesEntries)
            {
            }

            public function dispatch(object $event): object
            {
                $this->dispatched[] = $event;
                if ($event instanceof AddChangelogEntriesEvent && $this->takesEntries) {
                    $event->accept('test.changelog', count($event->entries));
                }

                return $event;
            }
        };

        return new BugReportService(
            $reports,
            new BugReportAttachmentStorage(sys_get_temp_dir() . '/bug-report-service-test'),
            $dispatcher,
        );
    }

    private function user(int $id, string $identifier = 'melder@example.test'): User
    {
        $user = $this->createStub(User::class);
        $user->method('getId')->willReturn($id);
        $user->method('getUserIdentifier')->willReturn($identifier);

        return $user;
    }

    /** @return list<object> */
    private function dispatchedOf(string $class): array
    {
        return array_values(array_filter($this->dispatched, static fn(object $event): bool => $event instanceof $class));
    }

    public function testAReportKeepsWhoReportedItAndWhatTheBrowserKnew(): void
    {
        $service = $this->service();

        $report = $service->create($this->user(3), [
            'title' => "  Speichern bricht ab\nsofort  ",
            'description' => 'Beim Speichern kommt ein Fehler.',
            'severity' => 'high',
        ], [
            'page' => 'Report-Editor',
            'url' => 'https://analytics.example/dashboard/reports',
            'geheim' => 'wird nicht übernommen',
            'browser' => str_repeat('a', BugReportService::MAX_CONTEXT_LENGTH + 50),
        ]);

        $this->assertSame('Speichern bricht ab sofort', $report->getTitle());
        $this->assertSame('melder@example.test', $report->getReporterName());
        $this->assertSame(eBugReportState::New, $report->getState());
        $this->assertSame(eBugReportSeverity::High, $report->getSeverity());
        $this->assertSame(['page', 'url', 'browser'], array_keys($report->getContext()));
        $this->assertSame(BugReportService::MAX_CONTEXT_LENGTH, mb_strlen($report->getContext()['browser']));
        $this->assertCount(1, $this->dispatchedOf(BugReportCreatedEvent::class));
    }

    public function testAReportNeedsATitleADescriptionAndASeverityThatExists(): void
    {
        $service = $this->service();
        $complete = ['title' => 'Kaputt', 'description' => 'Alles kaputt'];

        foreach ([
            ['input' => ['description' => 'Alles kaputt'], 'message' => 'Titel'],
            ['input' => ['title' => 'Kaputt'], 'message' => 'beschreibe'],
            ['input' => [...$complete, 'severity' => 'weltuntergang'], 'message' => 'Dringlichkeit'],
        ] as $case) {
            try {
                $service->create(null, $case['input']);
                $this->fail('accepted: ' . json_encode($case['input']));
            } catch (\InvalidArgumentException $exception) {
                $this->assertStringContainsString($case['message'], $exception->getMessage());
            }
        }
        $this->assertSame([], $this->dispatched, 'nothing is announced that was not stored');
    }

    public function testAStateThatChangesIsWrittenIntoTheHistoryAndClosesTheReport(): void
    {
        $service = $this->service();
        $report = $service->create($this->user(3), ['title' => 'Kaputt', 'description' => 'Alles kaputt']);
        $admin = $this->user(1, 'admin@example.test');

        $service->changeState($report, eBugReportState::InProgress, $admin);
        $this->assertNull($report->getClosedAt(), 'a report being worked on is not closed');

        $service->changeState($report, eBugReportState::Fixed, $admin);

        $this->assertSame(eBugReportState::Fixed, $report->getState());
        $this->assertNotNull($report->getClosedAt());
        $this->assertSame(
            ['Status: In Arbeit', 'Status: Behoben'],
            array_map(static fn($comment): string => $comment->getText(), $report->getComments()->toArray()),
        );
        $this->assertTrue($report->getComments()->first()->isAutomatic());

        $changes = $this->dispatchedOf(BugReportChangedEvent::class);
        $this->assertCount(2, $changes);
        $this->assertSame(BugReportChangedEvent::STATE_CHANGED, $changes[0]->change);
        $service->changeState($report, eBugReportState::Fixed, $admin);
        $this->assertCount(2, $this->dispatchedOf(BugReportChangedEvent::class), 'the state it already has changes nothing');
    }

    public function testOnlyAdministratorsSeeInternalComments(): void
    {
        $service = $this->service();
        $report = $service->create($this->user(3), ['title' => 'Kaputt', 'description' => '**Alles** kaputt']);
        $admin = $this->user(1, 'admin@example.test');

        $service->comment($report, $this->user(3), 'Passiert immer noch.');
        $internal = $service->comment($report, $admin, 'Liegt am Cache.', true);

        $this->assertTrue($internal->isInternal());
        $this->assertSame(
            ['Passiert immer noch.', 'Liegt am Cache.'],
            array_column($service->describe($report, true)['comments'], 'text'),
        );
        $this->assertSame(
            ['Passiert immer noch.'],
            array_column($service->describe($report, false)['comments'], 'text'),
        );
        $this->assertStringContainsString('<strong>Alles</strong>', $service->describe($report, false)['descriptionHtml']);

        $changed = $this->dispatchedOf(BugReportChangedEvent::class);
        $this->assertTrue($changed[0]->concernsReporter());
        $this->assertFalse($changed[1]->concernsReporter(), 'an internal note is none of the reporter\'s business');
    }

    public function testAnEmptyCommentIsRefused(): void
    {
        $service = $this->service();
        $report = $service->create(null, ['title' => 'Kaputt', 'description' => 'Alles kaputt']);

        $this->expectException(\InvalidArgumentException::class);
        $service->comment($report, null, "  \n ");
    }

    public function testOnlyFixedReportsGoToTheChangelogAndOnlyOnce(): void
    {
        $service = $this->service();
        $admin = $this->user(1, 'admin@example.test');
        $fixed = $service->create($this->user(3), ['title' => 'Speichern bricht ab', 'description' => 'x']);
        $service->changeState($fixed, eBugReportState::Fixed, $admin);
        $open = $service->create($this->user(3), ['title' => 'Noch offen', 'description' => 'x']);

        $result = $service->toChangelog([$fixed, $open], $admin);

        $this->assertSame(1, $result['moved']);
        $this->assertSame('test.changelog', $result['target']);
        $this->assertNotNull($fixed->getChangelogAt());
        $entries = $this->dispatchedOf(AddChangelogEntriesEvent::class)[0]->entries;
        $this->assertSame(['Speichern bricht ab (Fehlermeldung #17)'], $entries);

        $this->assertSame(0, $service->toChangelog([$fixed], $admin)['moved'], 'a report goes to the changelog once');
    }

    public function testNothingIsMarkedWhenNoChangelogTakesTheEntries(): void
    {
        $this->changelogTakesEntries = false;
        $service = $this->service();
        $report = $service->create($this->user(3), ['title' => 'Kaputt', 'description' => 'x']);
        $service->changeState($report, eBugReportState::Fixed, $this->user(1, 'admin@example.test'));

        $result = $service->toChangelog([$report], null);

        $this->assertSame(0, $result['moved']);
        $this->assertNull($report->getChangelogAt());
    }

    public function testSomebodyMayChangeWhatTheySaidThemselves(): void
    {
        $service = $this->service();
        $author = $this->user(3);
        $report = $service->create($author, ['title' => 'Kaputt', 'description' => 'x']);
        $comment = $service->comment($report, $author, 'Passiert immer noch.');

        $service->editComment($comment, $author, '  Passiert nur im Firefox.  ');

        $this->assertSame('Passiert nur im Firefox.', $comment->getText());
        $this->assertNotNull($comment->getEditedAt());

        foreach ([
            'somebody else' => $this->user(4, 'anderer@example.test'),
            'nobody' => null,
        ] as $case => $actor) {
            try {
                $service->editComment($comment, $actor, 'Fremder Text');
                $this->fail('changed by ' . $case);
            } catch (\InvalidArgumentException) {
                $this->assertSame('Passiert nur im Firefox.', $comment->getText());
            }
        }
    }

    public function testWhatTheSystemWroteIsNobodysToChange(): void
    {
        $service = $this->service();
        $admin = $this->user(1, 'admin@example.test');
        $report = $service->create($this->user(3), ['title' => 'Kaputt', 'description' => 'x']);
        $service->changeState($report, eBugReportState::Fixed, $admin);
        $note = $report->getComments()->last();

        $this->assertTrue($note->isAutomatic());
        $this->expectException(\InvalidArgumentException::class);
        $service->editComment($note, $admin, 'Anderer Text');
    }

    public function testTheLastCommentIsGoneAndAnOlderOneStaysAsDiscarded(): void
    {
        $service = $this->service();
        $author = $this->user(3);
        $report = $service->create($author, ['title' => 'Kaputt', 'description' => 'x']);
        $first = $service->comment($report, $author, 'Der erste Beitrag.');
        $second = $service->comment($report, $author, 'Der zweite Beitrag.');

        // auf den ersten wurde schon geantwortet - er bleibt als verworfen stehen
        $this->assertFalse($service->removeComment($first, $author));
        $this->assertCount(2, $report->getComments());
        $this->assertTrue($first->isDiscarded());
        $this->assertSame('Der erste Beitrag.', $first->getText(), 'the text is kept, only not shown');

        // der letzte dagegen ist einfach weg
        $this->assertTrue($service->removeComment($second, $author), 'nobody had answered to it');
        $this->assertCount(1, $report->getComments());
    }

    public function testACommentThatWasTakenBackStaysThatWay(): void
    {
        $service = $this->service();
        $author = $this->user(3);
        $report = $service->create($author, ['title' => 'Kaputt', 'description' => 'x']);
        $comment = $service->comment($report, $author, 'Erst so, dann so.');
        $service->comment($report, $author, 'Und noch etwas.');
        $service->removeComment($comment, $author);

        foreach (['editComment', 'removeComment'] as $method) {
            try {
                $method === 'editComment'
                    ? $service->editComment($comment, $author, 'Doch nicht')
                    : $service->removeComment($comment, $author);
                $this->fail($method . ' worked on a discarded comment');
            } catch (\InvalidArgumentException) {
                $this->assertTrue($comment->isDiscarded());
            }
        }
    }

    public function testADiscardedCommentOnlyShowsItsBeginning(): void
    {
        $long = str_repeat('Sehr viel Text. ', 20);

        $this->assertSame('…', BugReportService::preview('   '));
        $this->assertSame('Kurz und gut.', BugReportService::preview("Kurz\n  und gut."));
        $this->assertStringEndsWith(' …', BugReportService::preview($long));
        $this->assertLessThanOrEqual(
            BugReportService::DISCARDED_PREVIEW_LENGTH + 2,
            mb_strlen(BugReportService::preview($long)),
        );
    }

    public function testEverybodySeesOnlyTheirOwnCommentsAsTheirs(): void
    {
        $service = $this->service();
        $author = $this->user(3);
        $admin = $this->user(1, 'admin@example.test');
        $report = $service->create($author, ['title' => 'Kaputt', 'description' => 'x']);
        $service->comment($report, $author, 'Von mir.');
        $service->comment($report, $admin, 'Von der Verwaltung.');
        $service->changeState($report, eBugReportState::Accepted, $admin);

        $own = array_column($service->describe($report, true, $author)['comments'], 'own');
        $this->assertSame([true, false, false], $own, 'only the own one, and never what the system wrote');

        $comments = $service->describe($report, true, $admin)['comments'];
        $this->assertSame([false, true, false], array_column($comments, 'own'));
        $this->assertTrue($comments[2]['automatic']);
    }

    public function testAReportKnowsWhoItBelongsTo(): void
    {
        $service = $this->service();
        $report = $service->create($this->user(3), ['title' => 'Kaputt', 'description' => 'x']);

        $this->assertTrue($report->belongsTo($this->user(3)));
        $this->assertFalse($report->belongsTo($this->user(4)));
        $this->assertFalse($report->belongsTo(null));
    }
}
