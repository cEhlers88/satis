<?php

namespace Cehlers88\AnalyticsCore\Tests\Support\MonitoringRule;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Support\MonitoringRule\AbstractMonitoringRule;
use PHPUnit\Framework\TestCase;

class AbstractMonitoringRuleTest extends TestCase
{
    public function testARuleWithoutArgumentDefinitionsAcceptsAnything(): void
    {
        $rule = new class extends AbstractMonitoringRule {
            public function execute(): self
            {
                return $this;
            }
        };

        $this->assertSame([], $rule->getArgumentDefinitions());
        $this->assertTrue($rule->validateArguments([]));
        $this->assertTrue($rule->validateArguments(['whatever' => 1]));
    }

    public function testDeclaredArgumentsDecideWhatIsRequired(): void
    {
        $rule = $this->makeRuleWithDefinitions();

        $this->assertFalse($rule->validateArguments([]));
        $this->assertFalse($rule->validateArguments(['min' => 10]));
        $this->assertTrue($rule->validateArguments(['min' => 10, 'max' => 30]));
    }

    public function testOptionalArgumentsMayBeLeftOut(): void
    {
        $rule = $this->makeRuleWithDefinitions();

        $this->assertTrue($rule->validateArguments(['min' => 0, 'max' => 1]));
    }

    public function testSetArgumentsRejectsWhatValidationRefuses(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        $this->makeRuleWithDefinitions()->setArguments(['min' => 10]);
    }

    private function makeRuleWithDefinitions(): AbstractMonitoringRule
    {
        return new class extends AbstractMonitoringRule {
            public function getArgumentDefinitions(): array
            {
                return [
                    PropertyDTO::create('min', null, 'float'),
                    PropertyDTO::create('max', null, 'float'),
                    PropertyDTO::create('applicationId', 1, 'int', isOptional: true),
                ];
            }

            public function execute(): self
            {
                return $this;
            }
        };
    }
}
