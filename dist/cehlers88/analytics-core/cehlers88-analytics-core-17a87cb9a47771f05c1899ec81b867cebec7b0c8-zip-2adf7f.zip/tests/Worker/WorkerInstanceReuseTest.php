<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Worker;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Repository\WorkerJournalRepository;
use Cehlers88\AnalyticsCore\Repository\WorkerRepository;
use Cehlers88\AnalyticsCore\Support\Logging\BufferLogger;
use Cehlers88\AnalyticsCore\Worker\AbstractWorker;
use Cehlers88\AnalyticsCore\Worker\WorkerProvider;
use Doctrine\ORM\EntityManagerInterface;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Messenger\MessageBusInterface;

/**
 * Several worker entities may use the same worker class, e.g. two "self_care"
 * workers of different applications in one run chain. Each run has to get a
 * worker instance of its own.
 */
class WorkerInstanceReuseTest extends TestCase
{
    private AbstractWorker $prototype;
    private WorkerProvider $workerProvider;

    /**
     * The repositories extend Doctrine's ServiceEntityRepository, which the core
     * does not declare - the embedding application supplies it.
     */
    public static function setUpBeforeClass(): void
    {
        if (!interface_exists(EntityManagerInterface::class)) {
            self::markTestSkipped('Doctrine is not installed; WorkerProvider can only be tested in an application context.');
        }
    }

    public function testEveryCallHandsOutASeparateCopy(): void
    {
        $first = $this->workerProvider->getWorkerInstanceByName($this->prototype->getName());
        $second = $this->workerProvider->getWorkerInstanceByName($this->prototype->getName());

        self::assertInstanceOf($this->prototype::class, $first);
        self::assertNotSame($first, $second);
        self::assertNotSame($this->prototype, $first);
    }

    public function testTheSameWorkerClassCanBeConfiguredForTwoEntities(): void
    {
        $first = $this->workerProvider->getWorkerInstanceByName($this->prototype->getName());
        $second = $this->workerProvider->getWorkerInstanceByName($this->prototype->getName());

        $first->configure([['int', 'limit', 5]]);
        // Used to throw 'Property "allowed_runtime" already exists'.
        $second->configure([['int', 'limit', 10]]);

        self::assertSame(5, $first->getPropertyValue('limit'));
        self::assertSame(10, $second->getPropertyValue('limit'));
        self::assertSame(1000, $this->prototype->getPropertyValue('limit'));
        self::assertFalse($this->prototype->hasProperty('allowed_runtime'));
    }

    public function testInitLogsWithTheLoggerAndDebugModeOfTheRun(): void
    {
        $worker = $this->workerProvider->getWorkerInstanceByName($this->prototype->getName());
        $logger = new BufferLogger();

        $worker->init($this->createWorkerEntity(15, 'self_care'), $logger, true);

        self::assertStringContainsString(
            'Initializing worker "self_care" (id=15)',
            implode(PHP_EOL, $logger->getBuffer())
        );
    }

    protected function setUp(): void
    {
        $this->prototype = new class extends AbstractWorker {
            public function __construct()
            {
                $this->addProperty(PropertyDTO::create('limit', 1000, 'int', true));
            }

            public function getWorkingObjects(): array
            {
                return [];
            }
        };

        $this->workerProvider = new WorkerProvider(
            [$this->prototype],
            $this->createStub(MacroEnvironment::class),
            $this->createStub(WorkerRepository::class),
            $this->createStub(WorkerJournalRepository::class),
            $this->createStub(MessageBusInterface::class),
            $this->createStub(ObserverProvider::class),
            $this->createStub(TrackingBufferRepository::class),
        );
    }

    private function createWorkerEntity(int $id, string $name): Worker
    {
        $entity = $this->createStub(Worker::class);
        $entity->method('getId')->willReturn($id);
        $entity->method('getName')->willReturn($name);
        $entity->method('getApplication')->willReturn($this->createStub(Application::class));

        return $entity;
    }
}
