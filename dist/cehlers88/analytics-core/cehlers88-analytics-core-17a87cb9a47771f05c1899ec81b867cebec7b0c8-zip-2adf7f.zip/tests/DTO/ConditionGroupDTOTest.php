<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\DTO;

use Cehlers88\AnalyticsCore\DTO\ConditionGroupDTO;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use PHPUnit\Framework\TestCase;

class ConditionGroupDTOTest extends TestCase
{
    public function test_is_written_back_with_an_operator_that_can_be_read_again(): void
    {
        $group = ConditionGroupDTO::create([1, 2], eConditionType::NOT_EQUALS);

        $this->assertSame('!=', $group->typeName);
        $this->assertSame(eConditionType::NOT_EQUALS, eConditionType::tryFromOperator($group->typeName));
    }

    public function test_recognises_a_group_the_way_a_definition_writes_it(): void
    {
        $this->assertTrue(ConditionGroupDTO::isDefinition(['==', [1, 2]]));
        $this->assertTrue(ConditionGroupDTO::isDefinition(['&&', [['<', [1, 2]], true]]));
    }

    public function test_a_command_or_a_plain_list_is_no_group(): void
    {
        $this->assertFalse(ConditionGroupDTO::isDefinition(['if', ['conditions' => true]]));
        $this->assertFalse(ConditionGroupDTO::isDefinition(['==', 'x']));
        $this->assertFalse(ConditionGroupDTO::isDefinition(['==', [1], 'more']));
        $this->assertFalse(ConditionGroupDTO::isDefinition(['==', ['left' => 1, 'right' => 2]]));
    }
}
