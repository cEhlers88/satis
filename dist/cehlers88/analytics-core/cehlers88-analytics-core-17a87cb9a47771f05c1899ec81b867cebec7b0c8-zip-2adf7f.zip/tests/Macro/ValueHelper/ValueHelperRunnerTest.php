<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro\ValueHelper;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\DTO\ConditionGroupDTO;
use Cehlers88\AnalyticsCore\Entity\Command;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Macro\DTO\ValueHelperContextDTO;
use Cehlers88\AnalyticsCore\Macro\GetVarMacro;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiResolver;
use Cehlers88\AnalyticsCore\Macro\SetVarMacro;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\SelectVarNameValueHelper;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\ValueHelperRunner;
use Cehlers88\AnalyticsCore\Repository\CommandRepository;
use PHPUnit\Framework\TestCase;

/**
 * The value helper runner together with the command factory it reads the
 * definition through - and what the factory makes of conditions and property
 * infos, which the editors rely on in the same way.
 */
class ValueHelperRunnerTest extends TestCase
{
    private CommandFactory $commandFactory;
    private PropertyUiResolver $propertyUiResolver;

    protected function setUp(): void
    {
        if (!class_exists(\Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository::class)) {
            self::markTestSkipped('Doctrine is not installed; the CommandFactory can only be tested in an application context.');
        }

        $repository = $this->createStub(CommandRepository::class);
        $repository->method('findAll')->willReturn([
            $this->command('get_var', 'getVar', [['string', 'name'], ['string', 'context', 'job'], ['mixed', 'default', '']]),
            $this->command('set_var', 'setVar', [['string', 'name'], ['mixed', 'value'], ['string', 'context', 'job']]),
            $this->command('if', 'if', [['mixed', 'conditions'], ['array', 'whenTrueCommands', []], ['array', 'whenFalseCommands', []]]),
        ]);

        $this->commandFactory = new CommandFactory($repository);
        $this->propertyUiResolver = new PropertyUiResolver([new GetVarMacro(), new SetVarMacro()]);
    }

    public function test_offers_the_variable_names_the_definition_already_knows(): void
    {
        $definition = [
            ['set_var', ['name' => 'counter', 'value' => 1]],
            ['set_var', ['name' => 'shared_name', 'value' => 1, 'context' => 'shared']],
            ['if', [
                'conditions' => ['==', [['get_var', ['name' => 'fromCondition']], 1]],
                'whenTrueCommands' => [['get_var', ['name' => 'nested']]],
            ]],
        ];

        $result = $this->runner()->run(
            SelectVarNameValueHelper::class,
            ValueHelperContextDTO::create('get_var', 'name', ['name' => ''], $definition, [['string', 'argName']]),
            [SelectVarNameValueHelper::OPTION_CONTEXT_PROPERTY => 'context']
        );

        $this->assertSame('select', $result['type']);
        // The names of the context the property is in first, then the others.
        $this->assertSame(
            ['counter', 'fromCondition', 'nested', 'argName', 'shared_name'],
            array_column($result['data']['options'], 'value')
        );
        $this->assertSame('shared', $result['data']['options'][4]['details']['context']);
        $this->assertSame('argument', $result['data']['options'][3]['details']['context']);
    }

    public function test_refuses_a_class_that_is_no_value_helper(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        $this->runner()->run(\stdClass::class, ValueHelperContextDTO::create('get_var', 'name'));
    }

    public function test_reads_nested_condition_groups_with_the_commands_inside(): void
    {
        $group = $this->commandFactory->conditionGroupDtoByDefinition(
            ['&&', [['==', [['get_var', ['name' => 'x']], 'y']], true]]
        );

        $this->assertSame(eConditionType::AND, $group->type);
        $this->assertInstanceOf(ConditionGroupDTO::class, $group->conditionValues[0]);
        $this->assertSame('==', $group->conditionValues[0]->typeName);
        $this->assertInstanceOf(CommandDTO::class, $group->conditionValues[0]->conditionValues[0]);
        $this->assertSame('y', $group->conditionValues[0]->conditionValues[1]);
        $this->assertTrue($group->conditionValues[1]);
    }

    public function test_a_property_holding_a_condition_is_marked_as_one(): void
    {
        $dto = $this->commandFactory->commandDtoByDefinition(['if', ['conditions' => ['!', [true]]]]);

        $this->assertTrue($dto->properties[0]->hasConditionGroups);
        $this->assertSame(eConditionType::NOT, $dto->properties[0]->value->type);
    }

    public function test_puts_the_property_infos_on_the_properties_once_asked_to(): void
    {
        $withoutResolver = $this->commandFactory->commandDtoByDefinition(['get_var', ['name' => 'x']]);
        $this->assertArrayNotHasKey('valueHelper', $withoutResolver->properties[0]->ui);

        $this->commandFactory->setPropertyUiResolver($this->propertyUiResolver);

        $written = $this->commandFactory->commandDtoByDefinition(['get_var', ['name' => 'x']]);
        $this->assertSame(SelectVarNameValueHelper::class, $written->properties[0]->ui['valueHelper']['name']);
        // The defaults an editor relies on are kept.
        $this->assertSame('', $written->properties[0]->ui['class']);

        // A command that is only named - freshly added in an editor - too.
        $named = $this->commandFactory->commandDtoByDefinition(['get_var']);
        $this->assertSame(SelectVarNameValueHelper::class, $named->properties[0]->ui['valueHelper']['name']);
    }

    private function runner(): ValueHelperRunner
    {
        return new ValueHelperRunner($this->commandFactory, $this->propertyUiResolver);
    }

    private function command(string $name, string $macro, array $macroProps): Command
    {
        return new Command()
            ->setName($name)
            ->setMacro($macro)
            ->setMacroProps($macroProps);
    }
}
