<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro\PropertyUi;

use Cehlers88\AnalyticsCore\Entity\Command;
use Cehlers88\AnalyticsCore\Macro\GetVarMacro;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiResolver;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\SelectVarNameValueHelper;
use PHPUnit\Framework\TestCase;

class PropertyUiResolverTest extends TestCase
{
    protected function setUp(): void
    {
        if (!class_exists(\Doctrine\Common\Collections\ArrayCollection::class)) {
            self::markTestSkipped('Doctrine is not installed; a Command entity can only be built in an application context.');
        }
    }

    public function test_asks_the_macro_the_command_runs_by_its_name(): void
    {
        $infos = new PropertyUiResolver([new GetVarMacro()])->resolve($this->command('getVar'), 'name');

        $this->assertSame(SelectVarNameValueHelper::class, $infos[PropertyUi::KEY_VALUE_HELPER]['name']);
        $this->assertSame('context', $infos[PropertyUi::KEY_VALUE_HELPER]['options'][SelectVarNameValueHelper::OPTION_CONTEXT_PROPERTY]);
        $this->assertSame('Specify the variable name', $infos[PropertyUi::KEY_DESCRIPTION]);
    }

    public function test_a_macro_written_out_as_its_class_needs_no_service(): void
    {
        $infos = new PropertyUiResolver([])->resolve($this->command(GetVarMacro::class), 'name');

        $this->assertSame(SelectVarNameValueHelper::class, $infos[PropertyUi::KEY_VALUE_HELPER]['name']);
        $this->assertArrayNotHasKey(PropertyUi::KEY_DESCRIPTION, $infos);
    }

    public function test_still_reads_the_extender_a_command_row_names(): void
    {
        $command = $this->command('somethingUnknown', [
            PropertyUiResolver::SETTINGS_PROPERTY_EXTENDER => GetVarMacro::class . '::getPropertyUiInfos',
        ]);

        $infos = new PropertyUiResolver([])->resolve($command, 'context');

        $this->assertSame(SelectVarNameValueHelper::contextOptions(), $infos[PropertyUi::KEY_OPTIONS]);
    }

    public function test_an_extender_may_only_name_the_method_of_the_contract(): void
    {
        $command = $this->command('somethingUnknown', [
            PropertyUiResolver::SETTINGS_PROPERTY_EXTENDER => GetVarMacro::class . '::generateCommandString',
        ]);

        $this->assertSame([], new PropertyUiResolver([])->resolve($command, 'name'));
    }

    public function test_the_command_row_has_the_last_word_but_cannot_name_a_class_that_is_no_value_helper(): void
    {
        $command = $this->command('getVar', [
            PropertyUiResolver::SETTINGS_PROPERTIES => [
                'name' => ['displayName' => 'Variable', 'valueHelper' => \stdClass::class],
            ],
        ]);

        $infos = new PropertyUiResolver([new GetVarMacro()])->resolve($command, 'name');

        $this->assertSame('Variable', $infos[PropertyUi::KEY_DISPLAY_NAME]);
        $this->assertSame(SelectVarNameValueHelper::class, $infos[PropertyUi::KEY_VALUE_HELPER]['name']);
    }

    public function test_resolves_every_property_that_has_infos(): void
    {
        $all = new PropertyUiResolver([new GetVarMacro()])->resolveAll($this->command('getVar'));

        $this->assertSame(['name', 'context', 'default'], array_keys($all));
        $this->assertArrayHasKey(PropertyUi::KEY_OPTIONS, $all['context']);
        // "default" only carries the description the macro gives it.
        $this->assertSame([PropertyUi::KEY_DESCRIPTION], array_keys($all['default']));
    }

    public function test_describes_the_properties_of_a_macro_without_a_command(): void
    {
        $infos = new PropertyUiResolver([])->resolveForMacro(new GetVarMacro(), 'context');

        $this->assertSame(SelectVarNameValueHelper::contextOptions(), $infos[PropertyUi::KEY_OPTIONS]);
        $this->assertSame('Specify the variable context', $infos[PropertyUi::KEY_DESCRIPTION]);
    }

    public function test_options_written_as_a_list_become_a_value_label_map(): void
    {
        $this->assertSame(
            ['a' => 'a', 'b' => 'b'],
            PropertyUi::create()->options(['a', 'b'])->toArray()[PropertyUi::KEY_OPTIONS]
        );
    }

    private function command(string $macro, ?array $uiSettings = null): Command
    {
        return new Command()
            ->setName('get_var')
            ->setMacro($macro)
            ->setMacroProps([['string', 'name'], ['string', 'context', 'job'], ['mixed', 'default', '']])
            ->setUiSettings($uiSettings);
    }
}
