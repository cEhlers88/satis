<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Support\ConverterUtils;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\Index;

#[ORM\Entity(repositoryClass: TrackingBufferRepository::class)]
#[Index(name: 'created_at_idx', columns: ['created_at'])]
#[Index(name: 'modified_at_idx', columns: ['modified_at'])]
#[Index(name: 'updated_at_idx', columns: ['updated_at'])]
#[Index(name: 'key_value_idx', columns: ['key_value'])]
#[Index(name: 'timestamp_idx', columns: ['timestamp'])]
#[Index(name: 'timestamp_time_idx', columns: ['timestamp_time'])]
#[Index(name: 'handled_at_time_idx', columns: ['handled_at_time'])]
#[Index(name: 'filters_idx', columns: ['filters'], flags: ['fulltext'])]
#[Index(name: 'handler_data_idx', columns: ['handler_data'], flags: ['fulltext'])]
class TrackingBuffer extends AbstractTrackingBuffer
{
    public const string KEY_CAPTURE_ENDPOINT = 'CAPTURE_ENDPOINT';
    public const string KEY_SERVICE_ENDPOINT = 'SERVICE_ENDPOINT';

    #[ORM\ManyToOne(targetEntity: self::class, inversedBy: 'childTrackingBuffers')]
    private ?self $parent = null;

    /**
     * @var Collection<int, self>
     */
    #[ORM\OneToMany(targetEntity: self::class, mappedBy: 'parent')]
    private Collection $childTrackingBuffers;

    public function __construct()
    {
        parent::__construct();
        $this->childTrackingBuffers = new ArrayCollection();
    }

    /**
     * @return Collection<int, self>
     */
    public function getChildTrackingBuffers(): Collection
    {
        return $this->childTrackingBuffers;
    }

    public function addChildTrackingBuffer(self $childTrackingBuffer): static
    {
        if (!$this->childTrackingBuffers->contains($childTrackingBuffer)) {
            $this->childTrackingBuffers->add($childTrackingBuffer);
            $childTrackingBuffer->setParent($this);
        }

        return $this;
    }

    public function removeChildTrackingBuffer(self $childTrackingBuffer): static
    {
        if ($this->childTrackingBuffers->removeElement($childTrackingBuffer)) {
            // set the owning side to null (unless already changed)
            if ($childTrackingBuffer->getParent() === $this) {
                $childTrackingBuffer->setParent(null);
            }
        }

        return $this;
    }

    public function getParent(): ?self
    {
        return $this->parent;
    }

    public function setParent(?self $parent): static
    {
        $this->parent = $parent;

        return $this;
    }
}
