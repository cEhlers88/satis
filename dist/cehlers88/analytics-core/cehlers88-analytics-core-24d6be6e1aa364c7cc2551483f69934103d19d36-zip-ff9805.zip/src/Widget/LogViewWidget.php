<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\Entity\SystemLog;
use Analytics\Repository\SystemLogRepository;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;

class LogViewWidget extends AbstractWidget
{
    public function __construct(
        private readonly SystemLogRepository      $systemLogRepository,
        private readonly TrackingBufferRepository $trackingBufferRepository
    )
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.logView';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]]
        ];
    }


    public function getTemplateName(): string
    {
        return 'logView';
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'source.entity',
                value: null,
                type: 'string',
                label: 'Quelle',
                description: 'Woher die angezeigten Einträge stammen.',
                ui: [
                    'options' => [
                        'SystemLog' => 'Systemprotokoll',
                        'TrackingBuffer' => 'Tracking-Puffer',
                    ],
                ]
            ),
            PropertyDTO::create(
                name: 'source.keyFilter',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Key-Filter',
                description: 'Beschränkt die Einträge auf einen Key - nur für den Tracking-Puffer.'
            ),
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $logs = [];
        // The source arrives as a decoded json object from the widget request
        // and as a plain array when it comes straight out of a dashboard.
        $source = (array)($properties['source'] ?? []);

        switch ($source['entity'] ?? '') {
            case 'SystemLog':
                $systemLogs = $this->systemLogRepository->findBy(
                    [],
                    ['id' => 'desc'],
                    10
                );
                $logs = array_map(function (SystemLog $systemLog) {
                    return [
                        'time' => $systemLog->getCreatedAt()->format('Y-m-d H:i:s'),
                        'levelClass' => 'log',
                        'level' => 'LOG',
                        'msg' => $systemLog->getMapper() . $systemLog->getData()['error']
                    ];
                }, $systemLogs);

                break;
            case 'TrackingBuffer':
                $filters = [];
                if (($source['keyFilter'] ?? '') !== '') {
                    $filters['keyValue'] = $source['keyFilter'];
                }
                $trackingBuffers = $this->trackingBufferRepository->findBy(
                    $filters,
                    ['id' => 'DESC'],
                    10
                );
                $logs = array_map(function (TrackingBuffer $trackingBuffer) {
                    return [
                        'time' => $trackingBuffer->getCreatedAt()->format('Y-m-d H:i:s'),
                        'levelClass' => 'log',
                        'level' => 'LOG',
                        'msg' => $trackingBuffer->getData()['key']
                    ];
                }, $trackingBuffers);
                break;
        }

        return [
            'logs' => $logs
        ];
    }
}