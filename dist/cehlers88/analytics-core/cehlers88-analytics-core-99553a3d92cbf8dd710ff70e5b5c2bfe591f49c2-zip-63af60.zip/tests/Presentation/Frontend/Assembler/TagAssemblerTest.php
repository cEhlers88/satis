<?php

namespace Cehlers88\AnalyticsCore\Tests\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\TagAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\TagView;
use Cehlers88\AnalyticsCore\Entity\Tag;
use PHPUnit\Framework\TestCase;

class TagAssemblerTest extends TestCase
{
    public function testOneMapsTagToView(): void
    {
        $tag = $this->mockTag(7, 'production', '#ff0000');

        $assembler = new TagAssembler();
        $view = $assembler->assembleView($tag);

        $this->assertInstanceOf(TagView::class, $view);
        $this->assertSame(7, $view->id);
        $this->assertSame('production', $view->name);
        $this->assertSame('#ff0000', $view->color);
    }

    private function mockTag(int $id, string $name, string $color): Tag
    {
        $tag = $this->createStub(Tag::class);
        $tag->method('getId')->willReturn($id);
        $tag->method('getName')->willReturn($name);
        $tag->method('getColor')->willReturn($color);

        return $tag;
    }

    public function testManyMapsMultipleTagsToViews(): void
    {
        $tags = [
            $this->mockTag(1, 'staging', '#0000ff'),
            $this->mockTag(2, 'dev', '#00ff00'),
        ];

        $assembler = new TagAssembler();
        $views = $assembler->many($tags);

        $this->assertCount(2, $views);
        $this->assertSame(1, $views[0]->id);
        $this->assertSame('staging', $views[0]->name);
        $this->assertSame(2, $views[1]->id);
        $this->assertSame('dev', $views[1]->name);
    }
}
