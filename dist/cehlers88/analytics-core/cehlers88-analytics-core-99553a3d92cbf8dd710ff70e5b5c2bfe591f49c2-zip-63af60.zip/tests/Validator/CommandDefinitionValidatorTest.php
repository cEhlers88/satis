<?php

namespace Cehlers88\AnalyticsCore\Tests\Validator;

use Cehlers88\AnalyticsCore\Validator\CommandDefinitionValidator;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class CommandDefinitionValidatorTest extends TestCase
{
    private static array $knownCommands = ['setVariable', 'getVariable', 'sendEmail', 'logEvent'];

    private static array $commandArguments = [
        'setVariable' => ['required' => ['var'], 'optional' => ['value']],
        'getVariable' => ['required' => ['var']],
        'sendEmail' => ['required' => ['recipient'], 'optional' => ['subject']],
        'logEvent' => ['optional' => ['event']],
    ];

    /** @var CommandDefinitionValidator Instance under test with default configuration */
    private CommandDefinitionValidator $validator;

    protected function setUp(): void
    {
        $this->validator = new CommandDefinitionValidator(self::$knownCommands);
    }

    public static function provideCommandDefinitions(): array
    {
        return [
            'string: valid command name'
                => ['setVariable', true],

            'string: another valid command name'
                => ['sendEmail', true],

            'string: unknown command name'
                => ['unknownCommand', false],

            'string: empty string'
                => ['', false],

            'string: valid JSON single command def'
                => ['["setVariable",{"var":"test"}]', true],

            'string: valid JSON single command def with empty params'
                => ['["getVariable",[]]', true],

            'string: valid JSON array of command defs'
                => ['[["setVariable",{"var":"a"}],["getVariable",[]]]', true],

            'string: valid JSON-encoded command name (JSON string)'
                => ['"setVariable"', true],

            'string: JSON with unknown command'
                => ['["unknownCommand",{"foo":"bar"}]', false],

            'string: invalid JSON'
                => ['{invalid json}', false],

            'string: non-JSON, non-command text'
                => ['some random text', false],

            'array: valid single command def'
                => [['setVariable', ['var' => 'test']], true],

            'array: valid single command def with empty params'
                => [['logEvent', []], true],

            'array: single command def with unknown command name'
                => [['unknownCommand', ['foo' => 'bar']], false],

            'array: single command def with non-string name'
                => [[123, ['foo' => 'bar']], false],

            'array: count-2 where second element is a non-command string'
                => [['setVariable', 'notAnArray'], false],

            'array: multiple valid command defs (array form)'
                => [[['setVariable', ['var' => 'x']], ['getVariable', []]], true],

            'array: multiple valid command defs (string form)'
                => [['setVariable', 'getVariable'], true],

            'array: mixed – array form and string form'
                => [[['setVariable', []], 'getVariable', 'logEvent'], true],

            'array: one invalid element in list'
                => [[['setVariable', []], ['unknownCommand', []]], false],

            'array: 2-element where second element is a list (looks like a definition list, not params)'
                => [['setVariable', ['unknownCommand', []]], false],

            'array: empty'
                => [[], false],

            'array: single valid command name element'
                => [['setVariable'], true],

            'array: single unknown command name element'
                => [['unknownCommand'], false],
        ];
    }

    #[DataProvider('provideCommandDefinitions')]
    public function testValidate(string|array $input, bool $expected): void
    {
        $this->assertSame($expected, $this->validator->validate($input));
    }

    public function testIsValidCommandNameReturnsTrueForKnownCommand(): void
    {
        $this->assertTrue($this->validator->isValidCommandName('setVariable'));
    }

    public function testIsValidCommandNameReturnsFalseForUnknownCommand(): void
    {
        $this->assertFalse($this->validator->isValidCommandName('doesNotExist'));
    }

    public function testValidatorWithEmptyCommandList(): void
    {
        $emptyValidator = new CommandDefinitionValidator([]);

        $this->assertFalse($emptyValidator->validate('setVariable'));
        $this->assertFalse($emptyValidator->validate(['setVariable', []]));
    }

    public function testValidatorRejectsAssociativeArrayShape(): void
    {
        $this->assertFalse($this->validator->validate(['command' => 'setVariable', 'params' => []]));
    }

    public function testValidatorRejectsCommandNameStringsWhenDisabled(): void
    {
        $validator = new CommandDefinitionValidator(
            self::$knownCommands,
            allowCommandNameString: false,
        );

        $this->assertFalse($validator->validate('setVariable'));
        $this->assertFalse($validator->validate('"setVariable"'));
        $this->assertFalse($validator->validate(['setVariable']));
        $this->assertFalse($validator->validate(['command' => 'setVariable', 'params' => []]));
        $this->assertTrue($validator->validate(['setVariable', []]));
    }

    public function testValidatorChecksRequiredAndUnknownArgumentsWhenEnabled(): void
    {
        $validator = new CommandDefinitionValidator(
            self::$knownCommands,
            validateArguments: true,
            commandArgumentsByName: self::$commandArguments,
        );

        $this->assertTrue($validator->validate(['setVariable', ['var' => 'test']]));
        $this->assertFalse($validator->validate(['setVariable', ['value' => 'test']]));
        $this->assertFalse($validator->validate(['setVariable', ['var' => 'test', 'extra' => true]]));
        $this->assertFalse($validator->validate('setVariable'));
        $this->assertTrue($validator->validate(['logEvent', []]));
    }

    public function testValidatorRejectsCommandsWithoutArgumentMetadataWhenArgumentValidationIsEnabled(): void
    {
        $validator = new CommandDefinitionValidator(
            self::$knownCommands,
            validateArguments: true,
            commandArgumentsByName: ['setVariable' => ['required' => ['var']]],
        );

        $this->assertFalse($validator->validate(['getVariable', ['var' => 'test']]));
    }

    public function testValidatorRejectsAssociativeArrayShapeWhenArgumentValidationIsEnabled(): void
    {
        $validator = new CommandDefinitionValidator(
            self::$knownCommands,
            validateArguments: true,
            commandArgumentsByName: self::$commandArguments,
        );

        $this->assertFalse($validator->validate(['command' => 'setVariable', 'params' => []]));
    }

    public function testValidatorRejectsTwoElementArrayWhenSecondElementLooksLikeADefinitionList(): void
    {
        $this->assertFalse($this->validator->validate(['setVariable', ['unknownCommand', []]]));
    }

    public function testValidatorRejectsListStyleParametersForSingleCommandDefinition(): void
    {
        $this->assertFalse($this->validator->validate(['setVariable', ['value']]));
    }

    public function testValidatorRejectsIntegerKeyedParametersForSingleCommandDefinition(): void
    {
        $this->assertFalse($this->validator->validate(['setVariable', [1 => 'value']]));
    }

    public function testValidatorRejectsMetadataWithUnknownKeysWhenArgumentValidationIsEnabled(): void
    {
        $validator = new CommandDefinitionValidator(
            self::$knownCommands,
            validateArguments: true,
            // 'requried' is an intentional typo to simulate an unknown metadata key
            commandArgumentsByName: ['setVariable' => ['requried' => ['var']]],
        );

        $this->assertFalse($validator->validate(['setVariable', ['var' => 'test']]));
    }
}
