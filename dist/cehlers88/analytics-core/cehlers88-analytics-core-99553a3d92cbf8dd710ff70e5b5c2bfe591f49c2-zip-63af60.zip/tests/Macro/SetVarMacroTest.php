<?php

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\SetVarMacro;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use PHPUnit\Framework\TestCase;

class SetVarMacroTest extends TestCase
{
    public function test_set_dummy_variable(): void
    {
        /**
         * @var MacroEnvironment $environmentMock
         */
        $environmentMock = $this->createMock(MacroEnvironment::class);
        /**
         * @var VariablesProvider $variablesStoreProviderMock
         */
        $variablesStoreProviderMock = $this->createMock(VariablesProvider::class);

        $environmentMock
            ->expects($this->once())
            ->method('getVariablesStoreProvider')
            ->willReturn($variablesStoreProviderMock);

        $variablesStoreProviderMock
            ->expects($this->once())
            ->method('setVariable')
            ->with('foo', 'bar', eMacroVariableContext::JOB);

        $macro = new SetVarMacro();
        $macro
            ->setMacroEnvironment($environmentMock)
            ->init();
        $macro->execute(['name' => 'foo', 'value' => 'bar']);
    }

    public function test_set_dummy_variable_using_context(): void
    {
        /**
         * @var MacroEnvironment $environmentMock
         */
        $environmentMock = $this->createMock(MacroEnvironment::class);
        /**
         * @var VariablesProvider $variablesStoreProviderMock
         */
        $variablesStoreProviderMock = $this->createMock(VariablesProvider::class);

        $environmentMock
            ->expects($this->once())
            ->method('getVariablesStoreProvider')
            ->willReturn($variablesStoreProviderMock);

        $variablesStoreProviderMock
            ->expects($this->once())
            ->method('setVariable')
            ->with('foo', 'bar', 'local');

        $macro = new SetVarMacro();
        $macro
            ->setMacroEnvironment($environmentMock)
            ->init();
        $macro->execute(['name' => 'foo', 'value' => 'bar', 'context' => 'local']);
    }
}
