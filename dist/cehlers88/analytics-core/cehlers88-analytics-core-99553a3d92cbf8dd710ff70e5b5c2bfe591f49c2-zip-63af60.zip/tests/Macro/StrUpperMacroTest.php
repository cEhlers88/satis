<?php

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Macro\StrUpperMacro;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class StrUpperMacroTest extends TestCase
{
    private MockObject $commandPlayerMock;
    private MockObject $environmentMock;

    public static function dataProviderForSimpleExecution(): array
    {
        return [
            ['test', 'TEST'],
            ['test test', 'TEST TEST'],
            ['test test test', 'TEST TEST TEST'],
            ['123', '123'],
            ['123 456', '123 456'],
            ['123 TeSt 456', '123 TEST 456'],
        ];
    }

    #[DataProvider('dataProviderForSimpleExecution')]
    public function test_simple_execution(
        string $value,
        string $expectedResult
    ): void
    {
        $macro = new StrUpperMacro();
        $macro->setMacroEnvironment($this->environmentMock);

        $result = $macro->execute(['value' => $value])['returnValue'];

        $this->assertEquals($expectedResult, $result);
    }

    protected function setUp(): void
    {
        parent::setUp();

        $this->commandPlayerMock = $this->createMock(CommandPlayer::class);
        $this->environmentMock = $this->createMock(MacroEnvironment::class);
    }
}
