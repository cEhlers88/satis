<?php

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\GetVarMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use PHPUnit\Framework\TestCase;

class GetVarMacroTest extends TestCase
{
    public function test_dummy(): void
    {
        /**
         * @var MacroEnvironment $environmentMock
         */
        $environmentMock = $this->createMock(MacroEnvironment::class);
        /**
         * @var VariablesProvider $variablesStoreProviderMock
         */
        $variablesStoreProviderMock = $this->createMock(VariablesProvider::class);

        $environmentMock
            ->expects($this->once())
            ->method('getVariablesStoreProvider')
            ->willReturn($variablesStoreProviderMock);

        $variablesStoreProviderMock
            ->expects($this->once())
            ->method('getVariableValue')
            ->with('foo')
            ->willReturn('bar');

        $macro = new GetVarMacro();
        $macro
            ->setMacroEnvironment($environmentMock)
            ->init();

        $response = $macro->execute(['name' => 'foo']);
        $foo = 'bar';
    }
}
