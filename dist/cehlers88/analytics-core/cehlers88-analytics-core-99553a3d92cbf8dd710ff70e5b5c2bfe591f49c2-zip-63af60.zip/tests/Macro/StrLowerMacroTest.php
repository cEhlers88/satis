<?php

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Macro\StrLowerMacro;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class StrLowerMacroTest extends TestCase
{
    private MockObject $commandPlayerMock;
    private MockObject $environmentMock;

    public static function dataProviderForSimpleExecution(): array
    {
        return [
            ['test', 'test'],
            ['TEST', 'test'],
            ['Test', 'test'],
            ['TEST TEST', 'test test'],
            ['Test Test', 'test test'],
            ['123', '123'],
            ['123 456', '123 456'],
            ['123 TeSt 456', '123 test 456'],
            ['Test Test Test', 'test test test']
        ];
    }

    #[DataProvider('dataProviderForSimpleExecution')]
    public function test_simple_execution(
        string $value,
        string $expectedResult
    ): void
    {
        $macro = new StrLowerMacro();
        $macro->setMacroEnvironment($this->environmentMock);

        $result = $macro->execute(['value' => $value])['returnValue'];

        $this->assertEquals($expectedResult, $result);
    }

    protected function setUp(): void
    {
        parent::setUp();

        $this->commandPlayerMock = $this->createMock(CommandPlayer::class);
        $this->environmentMock = $this->createMock(MacroEnvironment::class);
    }
}
