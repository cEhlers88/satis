<?php

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;

class EndpointDefinitionDTO
{
    public string $description = '';
    public string $name = '';
    public array $aliases = [];

    /** @var string[] */
    public array $methods = [];

    /** @var PropertyDTO[] */
    public array $parameters = [];

    /** @var string[] */
    public array $requiredRoles = [];

    public mixed $handler = null;

    public static function create(
        string $name,
        array  $methods,
        array  $parameters = [],
        array  $requiredRoles = [],
        string $description = '',
        mixed  $handler = null
    ): EndpointDefinitionDTO
    {
        $dto = new self();

        $dto->name = $name;
        $dto->methods = $methods;
        $dto->parameters = $parameters;
        $dto->requiredRoles = $requiredRoles;
        $dto->description = $description;
        $dto->handler = $handler;

        return $dto;
    }
}