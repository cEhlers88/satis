<?php

namespace Cehlers88\AnalyticsCore\Command\DTO;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class CommandDTO extends DTO
{
    public string $address = '';
    public string $commandName = '';
    public string $comment = '';
    /**
     * @var PropertyDTO[]
     */
    public array $properties = [];

    public array $unknownProperties = [];
    public string $quickView = "";

    public function toArray(): array
    {
        $properties = [];
        foreach ($this->properties as $property) {
            $properties[] = $property->toArray();
        }
        return [$this->commandName, $properties];
    }
}