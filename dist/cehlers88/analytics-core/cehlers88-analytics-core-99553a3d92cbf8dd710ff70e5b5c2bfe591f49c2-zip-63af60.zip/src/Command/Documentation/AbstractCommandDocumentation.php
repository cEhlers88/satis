<?php

namespace Cehlers88\AnalyticsCore\Command\Documentation;

abstract class AbstractCommandDocumentation implements DocumentationInterface
{
    public function getPropertyDescription(string $propertyName, string $defaultDescription = ''): string
    {
        return 'not implemented yet';
    }
}