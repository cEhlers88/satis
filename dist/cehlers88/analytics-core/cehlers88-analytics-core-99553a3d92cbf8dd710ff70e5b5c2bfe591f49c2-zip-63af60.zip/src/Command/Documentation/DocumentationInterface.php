<?php

namespace Cehlers88\AnalyticsCore\Command\Documentation;

interface DocumentationInterface
{
    public function getPropertyDescription(string $propertyName, string $defaultDescription = ''): string;
}