<?php

namespace Cehlers88\AnalyticsCore\Command\Documentation;

class StrLowerDocumentation extends AbstractCommandDocumentation
{

}