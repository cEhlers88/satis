<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\ServiceEndpointRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ServiceEndpointRepository::class)]
class ServiceEndpoint extends AbstractEndpointEntity
{
    #[ORM\Column]
    private array $commands = [];

    #[ORM\ManyToOne(inversedBy: 'serviceEndpoints')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Application $application = null;

    #[ORM\Column]
    private array $comments = [];

    public function getCommands(): array
    {
        return $this->commands;
    }

    public function setCommands(array $commands): static
    {
        $this->commands = $commands;

        return $this;
    }

    public function getApplication(): ?Application
    {
        return $this->application;
    }

    public function setApplication(?Application $application): static
    {
        $this->application = $application;

        return $this;
    }

    public function getComments(): array
    {
        return $this->comments;
    }

    public function setComments(array $comments): static
    {
        $this->comments = $comments;

        return $this;
    }
}
