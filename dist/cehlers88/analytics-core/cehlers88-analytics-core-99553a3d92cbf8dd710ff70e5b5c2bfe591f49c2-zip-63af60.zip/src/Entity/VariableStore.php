<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: VariableStore::class)]
class VariableStore
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 200)]
    private string $name = '';

    #[ORM\Column]
    private eMacroVariableContext $context = eMacroVariableContext::APPLICATION;

    #[ORM\ManyToOne(inversedBy: 'variableStores')]
    private ?Application $application = null;

    #[ORM\Column]
    private array $value = [];

    public function getId(): ?int
    {
        return $this->id;
    }


    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getContext(): eMacroVariableContext
    {
        return $this->context;
    }

    public function setContext(eMacroVariableContext $context): static
    {
        $this->context = $context;
        return $this;
    }

    public function getApplication(): ?Application
    {
        return $this->application;
    }

    public function setApplication(?Application $application): static
    {
        $this->application = $application;

        return $this;
    }

    public function getValue(): array
    {
        return $this->value;
    }

    public function setValue(array $value): static
    {
        $this->value = $value;

        return $this;
    }

}
