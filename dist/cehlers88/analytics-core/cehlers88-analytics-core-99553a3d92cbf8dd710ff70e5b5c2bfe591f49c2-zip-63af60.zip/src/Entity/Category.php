<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\CategoryRepository;
use Cehlers88\AnalyticsDocumentsBundle\Entity\Document;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CategoryRepository::class)]
class Category
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    #[ORM\ManyToMany(targetEntity: Command::class, mappedBy: 'categories')]
    private Collection $commands;

    #[ORM\ManyToOne(inversedBy: 'categories')]
    #[ORM\JoinColumn(nullable: true)]
    private ?Application $application = null;

    #[ORM\ManyToMany(targetEntity: ApplicationAction::class, mappedBy: 'categories')]
    private Collection $applicationActions;

    #[ORM\ManyToMany(targetEntity: CategoryGroup::class, mappedBy: 'categories')]
    private Collection $categoryGroups;

    /**
     * @var Collection<int, Document>
     */
    #[ORM\ManyToMany(targetEntity: Document::class, mappedBy: 'categories')]
    private Collection $documents;

    /**
     * @var Collection<int, Procedure>
     */
    #[ORM\ManyToMany(targetEntity: Procedure::class, mappedBy: 'categories')]
    private Collection $procedures;

    /**
     * @var Collection<int, AnalyticsHeader>
     */
    #[ORM\ManyToMany(targetEntity: AnalyticsHeader::class, mappedBy: 'categories')]
    private Collection $analyticsHeaders;

    public function __construct()
    {
        $this->commands = new ArrayCollection();
        $this->applicationActions = new ArrayCollection();
        $this->categoryGroups = new ArrayCollection();
        $this->documents = new ArrayCollection();
        $this->procedures = new ArrayCollection();
        $this->analyticsHeaders = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    /**
     * @return Collection<int, Command>
     */
    public function getCommands(): Collection
    {
        return $this->commands;
    }

    public function addCommand(Command $command): static
    {
        if (!$this->commands->contains($command)) {
            $this->commands->add($command);
            $command->addCategory($this);
        }

        return $this;
    }

    public function removeCommand(Command $command): static
    {
        if ($this->commands->removeElement($command)) {
            $command->removeCategory($this);
        }

        return $this;
    }

    public function getApplication(): ?Application
    {
        return $this->application;
    }

    public function setApplication(?Application $application): static
    {
        $this->application = $application;

        return $this;
    }

    /**
     * @return Collection<int, ApplicationAction>
     */
    public function getApplicationActions(): Collection
    {
        return $this->applicationActions;
    }

    public function addApplicationAction(ApplicationAction $applicationAction): static
    {
        if (!$this->applicationActions->contains($applicationAction)) {
            $this->applicationActions->add($applicationAction);
            $applicationAction->addCategory($this);
        }

        return $this;
    }

    public function removeApplicationAction(ApplicationAction $applicationAction): static
    {
        if ($this->applicationActions->removeElement($applicationAction)) {
            $applicationAction->removeCategory($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, CategoryGroup>
     */
    public function getCategoryGroups(): Collection
    {
        return $this->categoryGroups;
    }

    public function addCategoryGroup(CategoryGroup $categoryGroup): static
    {
        if (!$this->categoryGroups->contains($categoryGroup)) {
            $this->categoryGroups->add($categoryGroup);
            $categoryGroup->addCategory($this);
        }

        return $this;
    }

    public function removeCategoryGroup(CategoryGroup $categoryGroup): static
    {
        if ($this->categoryGroups->removeElement($categoryGroup)) {
            $categoryGroup->removeCategory($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, Document>
     */
    public function getDocuments(): Collection
    {
        return $this->documents;
    }

    public function addDocument(Document $document): static
    {
        if (!$this->documents->contains($document)) {
            $this->documents->add($document);
            $document->addCategory($this);
        }

        return $this;
    }

    public function removeDocument(Document $document): static
    {
        if ($this->documents->removeElement($document)) {
            $document->removeCategory($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, Procedure>
     */
    public function getProcedures(): Collection
    {
        return $this->procedures;
    }

    public function addProcedure(Procedure $procedure): static
    {
        if (!$this->procedures->contains($procedure)) {
            $this->procedures->add($procedure);
            $procedure->addCategory($this);
        }

        return $this;
    }

    public function removeProcedure(Procedure $procedure): static
    {
        if ($this->procedures->removeElement($procedure)) {
            $procedure->removeCategory($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, AnalyticsHeader>
     */
    public function getAnalyticsHeaders(): Collection
    {
        return $this->analyticsHeaders;
    }

    public function addAnalyticsHeader(AnalyticsHeader $analyticsHeader): static
    {
        if (!$this->analyticsHeaders->contains($analyticsHeader)) {
            $this->analyticsHeaders->add($analyticsHeader);
            $analyticsHeader->addCategory($this);
        }

        return $this;
    }

    public function removeAnalyticsHeader(AnalyticsHeader $analyticsHeader): static
    {
        if ($this->analyticsHeaders->removeElement($analyticsHeader)) {
            $analyticsHeader->removeCategory($this);
        }

        return $this;
    }
}
