<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\SharedDataValueRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: SharedDataValueRepository::class)]
class SharedDataValue
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'sharedDataValues')]
    #[ORM\JoinColumn(nullable: false)]
    private ?SharedData $sharedData = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $strValue = null;

    #[ORM\Column(nullable: true)]
    private ?float $numValue = null;

    #[ORM\Column(length: 255)]
    private ?string $type = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSharedData(): ?SharedData
    {
        return $this->sharedData;
    }

    public function setSharedData(?SharedData $sharedData): static
    {
        $this->sharedData = $sharedData;

        return $this;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function setType(string $type): static
    {
        $this->type = $type;

        return $this;
    }

    public function getValue(): mixed
    {
        if ($this->type === 'string') {
            return $this->getStrValue();
        }

        if ($this->type === 'boolean') {
            return (int)$this->numValue === 1;
        }

        return $this->numValue;
    }

    public function getStrValue(): ?string
    {
        return $this->strValue;
    }

    public function setStrValue(?string $strValue): static
    {
        $this->strValue = $strValue;

        return $this;
    }

    public function getNumValue(): ?float
    {
        return $this->numValue;
    }

    public function setNumValue(?float $numValue): static
    {
        $this->numValue = $numValue;

        return $this;
    }

    public function setValue(mixed $value): static
    {
        $this->setType(gettype($value));

        $this->setStrValue($value);

        if (is_numeric($value)) {
            $this->setNumValue($value);
        } else if (is_bool($value)) {
            $this
                ->setNumValue($value ? 1 : 0)
                ->setStrValue($value ? 'true' : 'false');
        }

        return $this;
    }
}
