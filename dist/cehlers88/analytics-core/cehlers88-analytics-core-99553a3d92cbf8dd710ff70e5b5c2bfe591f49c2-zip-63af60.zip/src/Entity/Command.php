<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\CommandRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CommandRepository::class)]
class Command extends AbstractTaggedEntity
{
    public const int MACRO_PROPS_INDEX_TYPES = 0;
    public const int MACRO_PROPS_INDEX_NAMES = 1;
    public const int MACRO_PROPS_INDEX_DEFAULT_VALUE = 2;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(length: 255)]
    private ?string $macro = null;

    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $macroProps = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    #[ORM\ManyToMany(targetEntity: Category::class, inversedBy: 'commands')]
    private Collection $categories;

    #[ORM\Column(length: 255)]
    private ?string $resultType = null;

    #[ORM\Column]
    private ?bool $needPrecompiledArguments = null;

    #[ORM\Column]
    private array $macroPropsOverwrites = [];

    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $quickViewFormat = null;

    #[ORM\Column(nullable: true)]
    private ?array $uiSettings = null;

    #[ORM\Column(nullable: true)]
    private ?array $requiredServerVars = null;

    public function __construct()
    {
        parent::__construct();
        $this->categories = new ArrayCollection();
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getMacro(): ?string
    {
        return $this->macro;
    }

    public function setMacro(string $macro): static
    {
        $this->macro = $macro;

        return $this;
    }

    public function getMacroProps(): ?array
    {
        return $this->macroProps;
    }

    public function setMacroProps(?array $macroProps): static
    {
        $this->macroProps = $macroProps;

        return $this;
    }

    public function getMacroPropsPrettyHtml(): ?string
    {
        $html = '';

        foreach ($this->macroProps as $propDefinition) {
            $optional = isset($propDefinition[2]) ? 1 : 0;

            $html .= '<li>';
            $html .= "<nobr>" . $propDefinition[1] . ($optional ? '?' : '') . ': ' . $propDefinition[0] . "</nobr>";
            $html .= '</li>';
        }

        foreach ($this->macroPropsOverwrites as $key => $value) {
            $html .= '<li style="color:red;">';
            $html .= "<nobr>" . $key . ': ' . $value . "</nobr>";
            $html .= '</li>';
        }
        $html .= '';

        return $html;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    /**
     * @return Collection<int, Category>
     */
    public function getCategories(): Collection
    {
        return $this->categories;
    }

    public function addCategory(Category $category): static
    {
        if (!$this->categories->contains($category)) {
            $this->categories->add($category);
        }

        return $this;
    }

    public function removeCategory(Category $category): static
    {
        $this->categories->removeElement($category);

        return $this;
    }

    public function getResultType(): ?string
    {
        return $this->resultType;
    }

    public function setResultType(string $resultType): static
    {
        $this->resultType = $resultType;

        return $this;
    }

    public function isNeedPrecompiledArguments(): ?bool
    {
        return $this->needPrecompiledArguments;
    }

    public function setNeedPrecompiledArguments(bool $needPrecompiledArguments): static
    {
        $this->needPrecompiledArguments = $needPrecompiledArguments;

        return $this;
    }

    public function getMacroPropsOverwrites(): array
    {
        return $this->macroPropsOverwrites;
    }

    public function setMacroPropsOverwrites(array $macroPropsOverwrites): static
    {
        $this->macroPropsOverwrites = $macroPropsOverwrites;

        return $this;
    }

    public function getQuickViewFormat(): ?array
    {
        return $this->quickViewFormat;
    }

    public function setQuickViewFormat(array $quickViewFormat): static
    {
        $this->quickViewFormat = $quickViewFormat;

        return $this;
    }

    public function getUiSettings(): ?array
    {
        return $this->uiSettings;
    }

    public function setUiSettings(?array $uiSettings): static
    {
        $this->uiSettings = $uiSettings;

        return $this;
    }

    public function getRequiredServerVars(): ?array
    {
        return $this->requiredServerVars;
    }

    public function setRequiredServerVars(?array $requiredServerVars): static
    {
        $this->requiredServerVars = $requiredServerVars;

        return $this;
    }
}
