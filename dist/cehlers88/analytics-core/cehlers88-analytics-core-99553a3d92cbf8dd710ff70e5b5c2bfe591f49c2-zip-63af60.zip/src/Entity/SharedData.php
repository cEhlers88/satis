<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\SharedDataRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: SharedDataRepository::class)]
class SharedData
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    #[ORM\OneToMany(targetEntity: SharedDataValue::class, mappedBy: 'sharedData')]
    private Collection $sharedDataValues;

    public function __construct()
    {
        $this->sharedDataValues = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function removeSharedDataValue(SharedDataValue $sharedDataValue): static
    {
        if ($this->sharedDataValues->removeElement($sharedDataValue)) {
            // set the owning side to null (unless already changed)
            if ($sharedDataValue->getSharedData() === $this) {
                $sharedDataValue->setSharedData(null);
            }
        }

        return $this;
    }

    public function getValue(): mixed
    {
        if ($this->sharedDataValues->count() === 1) {
            return $this->sharedDataValues->first()->getValue();
        }

        $result = [];
        foreach ($this->getSharedDataValues() as $sharedDataValue) {
            $result[] = $sharedDataValue->getValue();
        }

        return $result;
    }

    /**
     * @return Collection<int, SharedDataValue>
     */
    public function getSharedDataValues(): Collection
    {
        return $this->sharedDataValues;
    }

    public function setValue(mixed $value): static
    {
        if ($this->sharedDataValues->count() === 0) {
            $this->addSharedDataValue(new SharedDataValue());
        }

        if (is_array($value)) {
            $this->sharedDataValues->clear();
            foreach ($value as $v) {
                $tmp = new SharedDataValue();
                $tmp->setValue($v);
                $this->addSharedDataValue($tmp);
            }
            return $this;
        }

        $this->sharedDataValues->first()->setValue($value);

        return $this;
    }

    public function addSharedDataValue(SharedDataValue $sharedDataValue): static
    {
        if (!$this->sharedDataValues->contains($sharedDataValue)) {
            $this->sharedDataValues->add($sharedDataValue);
            $sharedDataValue->setSharedData($this);
        }

        return $this;
    }
}
