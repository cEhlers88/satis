<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Support\ConverterUtils;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\Index;

abstract class AbstractTrackingBuffer extends AbstractTaggedEntity
{
    #[ORM\Column]
    protected ?int $state = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    protected ?\DateTimeInterface $timestamp = null;

    #[ORM\Column(
        name: 'timestamp_time',
        type: Types::TIME_MUTABLE,
        nullable: true,
        insertable: false,
        updatable: false,
        columnDefinition: 'TIME GENERATED ALWAYS AS (TIME(`timestamp`)) STORED',
        generated: 'ALWAYS'
    )]
    protected ?\DateTimeInterface $timestampTime = null;

    #[ORM\Column(type: Types::JSON)]
    protected ?array $data = null;

    #[ORM\Column(
        name: 'key_value',
        type: 'string',
        length: 255,
        nullable: true,
        insertable: false,
        updatable: false,
        columnDefinition: "VARCHAR(255) GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(data, '$.key'))) STORED",
        generated: 'ALWAYS'
    )]
    protected ?string $keyValue = null;

    #[ORM\ManyToOne(inversedBy: 'trackingBuffers')]
    #[ORM\JoinColumn(nullable: false)]
    protected ?Application $application = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    protected ?\DateTimeInterface $handledAt = null;

    #[ORM\Column(
        name: 'handled_at_time',
        type: Types::TIME_MUTABLE,
        nullable: true,
        insertable: false,
        updatable: false,
        columnDefinition: 'TIME GENERATED ALWAYS AS (TIME(handled_at)) STORED',
        generated: 'ALWAYS'
    )]
    protected ?\DateTimeInterface $handledAtTime = null;

    #[ORM\Column(nullable: true)]
    protected ?array $handlerData = null;

    #[ORM\Column(length: 255)]
    protected string $note = '';

    #[ORM\Column(type: Types::TEXT)]
    protected string $filters = '';

    public function getState(): ?eTrackingBufferState
    {
        return eTrackingBufferState::from($this->state);
    }

    public function setState(eTrackingBufferState $state): static
    {
        $this->state = $state->value;

        return $this;
    }

    public function getTimestamp(): ?\DateTimeInterface
    {
        return $this->timestamp;
    }

    public function setTimestamp(\DateTimeInterface $timestamp): static
    {
        $this->timestamp = $timestamp;

        return $this;
    }

    public function getData(): ?array
    {
        return $this->data;
    }

    public function setData(array $data): static
    {
        $this->data = $data;
        if (isset($this->data['clientInfos']) && is_string($this->data['clientInfos'])) {
            $this->data['clientInfos'] = json_decode($this->data['clientInfos'], true);
        }

        return $this;
    }

    /*public function getDataOverview(int $maxLength = 300): ?string
{
if (isset($this->handlerData['ui_overview'])) {
    return json_encode([
        'message' => substr($this->handlerData['ui_overview']['message'], 0, $maxLength) . '...'
    ]);
}
return json_encode($this->data);

}*/

    public function getApplication(): ?Application
    {
        return $this->application;
    }

    public function setApplication(?Application $application): static
    {
        $this->application = $application;

        return $this;
    }

    public function getIp(): ?string
    {
        return $this->data['ip'] ?? null;
    }

    public function getHandledAt(): ?\DateTimeInterface
    {
        return $this->handledAt;
    }

    public function setHandledAt(?\DateTimeInterface $handledAt): static
    {
        $this->handledAt = $handledAt;

        return $this;
    }

    public function getHandlerData(): ?array
    {
        return $this->handlerData;
    }

    public function setHandlerData(?array $handlerData): static
    {
        $this->handlerData = $handlerData;

        return $this;
    }

    public function getNote(): ?string
    {
        return $this->note;
    }

    public function setNote(string $note): static
    {
        $this->note = $note;

        return $this;
    }

    public function getTimestampTime(): ?\DateTimeInterface
    {
        return $this->timestampTime;
    }

    public function getHandledAtTime(): ?\DateTimeInterface
    {
        return $this->handledAtTime;
    }

    public function getFilters(): ?string
    {
        return $this->filters;
    }

    public function setFilters(string $filters): static
    {
        $this->filters = $filters;

        return $this;
    }

    public function getKeyValue(): string
    {
        return $this->keyValue ?? '';
    }
}
