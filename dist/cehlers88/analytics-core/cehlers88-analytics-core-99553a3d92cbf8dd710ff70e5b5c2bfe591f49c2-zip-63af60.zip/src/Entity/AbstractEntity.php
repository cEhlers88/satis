<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * Base class for all entities providing common fields and tag management.
 */
abstract class AbstractEntity implements EntityInterface
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    protected ?int $id = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    protected ?\DateTimeInterface $created_at = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    protected ?\DateTimeInterface $modified_at = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    protected ?\DateTimeInterface $updated_at = null;

    /**
     * Returns the entity ID.
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Returns the creation timestamp.
     */
    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->created_at;
    }

    /**
     * Sets the creation timestamp.
     */
    public function setCreatedAt(\DateTimeInterface $createdAt): static
    {
        $this->created_at = $createdAt;
        return $this;
    }

    /**
     * Get the date-time when the entity was last modified.
     */
    public function getModifiedAt(): ?\DateTimeInterface
    {
        return $this->modified_at;
    }

    /**
     * Sets the last modification timestamp.
     */
    public function setModifiedAt(\DateTimeInterface $modifiedAt): static
    {
        $this->modified_at = $modifiedAt;
        return $this;
    }

    /**
     * Returns the last update timestamp.
     */
    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updated_at;
    }

    /**
     * Sets the last update timestamp.
     */
    public function setUpdatedAt(\DateTimeInterface $updatedAt): static
    {
        $this->updated_at = $updatedAt;
        return $this;
    }

    /**
     * Returns the list of fields observed for modification.
     *
     * @return array
     */
    public function getModificationObservedFields(): array
    {
        return [];
    }
}