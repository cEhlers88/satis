<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\AnalyticsHeaderRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: AnalyticsHeaderRepository::class)]
class AnalyticsHeader extends AbstractTaggedEntity
{
    #[ORM\OneToMany(targetEntity: AnalyticsDetails::class, mappedBy: 'analyticsHeader')]
    private Collection $analyticsDetails;

    #[ORM\ManyToOne(inversedBy: 'analyticsHeaders')]
    private ?Client $client = null;

    #[ORM\Column(length: 255)]
    private ?string $title = null;

    #[ORM\Column]
    private array $requiredPermissions = [];

    /**
     * @var Collection<int, Category>
     */
    #[ORM\ManyToMany(targetEntity: Category::class, inversedBy: 'analyticsHeaders')]
    private Collection $categories;

    public function __construct()
    {
        parent::__construct();
        $this->analyticsDetails = new ArrayCollection();
        $this->categories = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection<int, AnalyticsDetails>
     */
    public function getAnalyticsDetails(): Collection
    {
        return $this->analyticsDetails;
    }

    public function addAnalyticsDetail(AnalyticsDetails $analyticsDetail): static
    {
        if (!$this->analyticsDetails->contains($analyticsDetail)) {
            $this->analyticsDetails->add($analyticsDetail);
            $analyticsDetail->setAnalyticsHeader($this);
        }

        return $this;
    }

    public function removeAnalyticsDetail(AnalyticsDetails $analyticsDetail): static
    {
        if ($this->analyticsDetails->removeElement($analyticsDetail)) {
            // set the owning side to null (unless already changed)
            if ($analyticsDetail->getAnalyticsHeader() === $this) {
                $analyticsDetail->setAnalyticsHeader(null);
            }
        }

        return $this;
    }

    public function getClient(): ?Client
    {
        return $this->client;
    }

    public function setClient(?Client $client): static
    {
        $this->client = $client;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): static
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getTitle(): ?string
    {
        return $this->title;
    }

    public function setTitle(string $title): static
    {
        $this->title = $title;

        return $this;
    }

    public function getRequiredPermissions(): array
    {
        return $this->requiredPermissions;
    }

    public function setRequiredPermissions(array $requiredPermissions): static
    {
        $this->requiredPermissions = $requiredPermissions;

        return $this;
    }

    /**
     * @return Collection<int, Category>
     */
    public function getCategories(): Collection
    {
        return $this->categories;
    }

    public function addCategory(Category $category): static
    {
        if (!$this->categories->contains($category)) {
            $this->categories->add($category);
        }

        return $this;
    }

    public function removeCategory(Category $category): static
    {
        $this->categories->removeElement($category);

        return $this;
    }
}
