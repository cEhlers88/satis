<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 17:12
 */

namespace Cehlers88\AnalyticsCore\ENUM;

enum eInstructionType
{
    case COMMAND;
    case MACRO;
    case PROCEDURE;
}
