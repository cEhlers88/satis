<?php

namespace Cehlers88\AnalyticsCore\ENUM;

enum eSelfCheckResult
{
    case Passed;
    case Failed;
    case NotChecked;
}
