<?php

namespace Cehlers88\AnalyticsCore\ENUM;

enum eConditionType: int
{
    case EQUALS = 1;
    case NOT_EQUALS = 2;
    case GREATER_THAN = 3;
    case GREATER_THAN_OR_EQUALS = 4;
    case LESS_THAN = 5;
    case LESS_THAN_OR_EQUALS = 6;
    case CONTAINS = 7;
    case NOT_CONTAINS = 8;
    case STARTS_WITH = 9;
    case ENDS_WITH = 10;
    case OR = 11;
    case AND = 12;
    case XOR = 13;

    public static function toString(int $value): string
    {
        switch ($value) {
            case self::EQUALS->value:
                return '===';
            case self::NOT_EQUALS->value:
                return '!==';
            case self::GREATER_THAN->value:
                return '>';
            case self::GREATER_THAN_OR_EQUALS->value:
                return '>=';
            case self::LESS_THAN->value:
                return '<';
            case self::LESS_THAN_OR_EQUALS->value:
                return '<=';
            case self::CONTAINS->value:
                return 'contains';
            case self::NOT_CONTAINS->value:
                return 'not contains';
            case self::STARTS_WITH->value:
                return 'starts with';
            case self::ENDS_WITH->value:
                return 'ends with';
            case self::OR->value:
                return 'or';
            case self::AND->value:
                return 'and';
            case self::XOR->value:
                return 'xor';
            default:
                return 'unknown';
        }
    }

    public function value(): int
    {
        return $this->value;
    }
}
