<?php

namespace Cehlers88\AnalyticsCore\Validator;

/**
 * Validates whether a given input represents a valid command definition.
 *
 * A command definition can be provided as:
 *  - A string containing a valid command name.
 *  - A JSON-encoded string that is decoded and validated recursively.
 *  - An array in the form [commandName, paramsArray] (single command definition).
 *  - An array of command definitions, where each element is itself a valid
 *    command definition (array form or string form).
 */
class CommandDefinitionValidator
{
    /**
     * @param string[] $validCommandNames List of known/registered command names.
     * @param array<string, array<string, string[]>|list<string>> $commandArgumentsByName
     *   Command argument metadata keyed by command name. Each entry may be an
     *   empty array, a flat list of allowed argument names, or an associative
     *   array with "required" and/or "optional" string lists.
     */
    public function __construct(
        private readonly array $validCommandNames,
        private readonly bool $allowCommandNameString = true,
        private readonly bool $validateArguments = false,
        private readonly array $commandArgumentsByName = [],
    ) {
    }

    /**
     * Returns whether the given input is a valid command definition.
     *
     * @param string|array $input The definition to validate.
     */
    public function validate(string|array $input): bool
    {
        if (is_string($input)) {
            return $this->validateString($input);
        }

        return $this->validateArray($input);
    }

    /**
     * Returns whether the given command name is registered.
     */
    public function isValidCommandName(string $name): bool
    {
        return in_array($name, $this->validCommandNames, true);
    }

    private function validateString(string $input): bool
    {
        if ($this->allowCommandNameString && $this->isValidCommandNameString($input)) {
            return true;
        }

        $decoded = json_decode($input, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return false;
        }

        if (is_array($decoded)) {
            return $this->validateArray($decoded);
        }

        if ($this->allowCommandNameString && is_string($decoded)) {
            return $this->isValidCommandNameString($decoded);
        }

        return false;
    }

    private function validateArray(array $input): bool
    {
        if (empty($input)) {
            return false;
        }

        if ($this->isSingleCommandDefinitionArray($input)) {
            return $this->validateCommandDefinition($input[0], $input[1]);
        }

        if (!array_is_list($input)) {
            return false;
        }

        foreach ($input as $element) {
            if (!$this->isValidCommandDefinitionElement($element)) {
                return false;
            }
        }

        return true;
    }

    private function isValidCommandDefinitionElement(mixed $element): bool
    {
        if (is_string($element)) {
            return $this->allowCommandNameString && $this->isValidCommandNameString($element);
        }

        if (!$this->isSingleCommandDefinitionArray($element)) {
            return false;
        }

        return $this->validateCommandDefinition($element[0], $element[1]);
    }

    private function isSingleCommandDefinitionArray(mixed $input): bool
    {
        return is_array($input)
            && array_is_list($input)
            && count($input) === 2
            && is_string($input[0])
            && is_array($input[1])
            && $this->isValidParametersArray($input[1]);
    }

    /**
     * Command parameters must be empty or associative.
     *
     * List-style arrays are treated as nested definition lists and therefore
     * are not valid parameter payloads for a single command definition.
     */
    private function isValidParametersArray(array $parameters): bool
    {
        if ($parameters === []) {
            return true;
        }

        if (array_is_list($parameters)) {
            return false;
        }

        foreach (array_keys($parameters) as $key) {
            if (!is_string($key)) {
                return false;
            }
        }

        return true;
    }

    private function isValidCommandNameString(string $name): bool
    {
        return $this->validateCommandDefinition($name, []);
    }

    private function validateCommandDefinition(string $commandName, array $parameters): bool
    {
        if (!$this->isValidCommandName($commandName)) {
            return false;
        }

        if (!$this->validateArguments) {
            return true;
        }

        return $this->validateCommandArguments($commandName, $parameters);
    }

    private function validateCommandArguments(string $commandName, array $parameters): bool
    {
        if (!array_key_exists($commandName, $this->commandArgumentsByName)) {
            return false;
        }

        $allowedArguments = $this->getAllowedArguments($commandName);
        if ($allowedArguments === null) {
            return false;
        }

        foreach (array_keys($parameters) as $parameterName) {
            if (!is_string($parameterName) || !in_array($parameterName, $allowedArguments['allowed'], true)) {
                return false;
            }
        }

        foreach ($allowedArguments['required'] as $requiredArgument) {
            if (!array_key_exists($requiredArgument, $parameters)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @return array{required: string[], allowed: string[]}|null
     */
    private function getAllowedArguments(string $commandName): ?array
    {
        $definition = $this->commandArgumentsByName[$commandName];

        if ($definition === []) {
            return ['required' => [], 'allowed' => []];
        }

        if (array_is_list($definition)) {
            if (!$this->containsOnlyStrings($definition)) {
                return null;
            }

            return ['required' => [], 'allowed' => $definition];
        }

        foreach (array_keys($definition) as $key) {
            if (!is_string($key) || !in_array($key, ['required', 'optional'], true)) {
                return null;
            }
        }

        $requiredArguments = $definition['required'] ?? [];
        $optionalArguments = $definition['optional'] ?? [];

        if (!is_array($requiredArguments) || !is_array($optionalArguments)) {
            return null;
        }

        if (
            count($requiredArguments) !== count(array_unique($requiredArguments))
            || count($optionalArguments) !== count(array_unique($optionalArguments))
            || array_intersect($requiredArguments, $optionalArguments) !== []
        ) {
            return null;
        }

        if (
            !$this->containsOnlyStrings($requiredArguments)
            || !$this->containsOnlyStrings($optionalArguments)
        ) {
            return null;
        }

        return [
            'required' => $requiredArguments,
            'allowed' => array_merge($requiredArguments, $optionalArguments),
        ];
    }

    private function containsOnlyStrings(array $values): bool
    {
        foreach ($values as $value) {
            if (!is_string($value)) {
                return false;
            }
        }

        return true;
    }
}
