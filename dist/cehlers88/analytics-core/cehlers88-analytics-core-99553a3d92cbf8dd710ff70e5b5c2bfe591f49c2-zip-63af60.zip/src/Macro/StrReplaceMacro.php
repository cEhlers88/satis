<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class StrReplaceMacro extends AbstractMacro
{
    private const string PROPERTY_SEARCH = 'search';
    private const string PROPERTY_REPLACE = 'replace';
    private const string PROPERTY_SUBJECT = 'subject';

    public function init(): StrReplaceMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_REPLACE, 'string', 'Specify the replacement string'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_SEARCH, 'string', 'Specify the string to search for'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_SUBJECT, 'string', 'Specify the string to search in'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Replace a string with another string in a string.';
    }

    public function getName(): string
    {
        return 'strReplace';
    }

    protected function run(): ?array
    {
        return $this->_createRunResult(str_replace(
            $this->getPropertyValue(self::PROPERTY_SEARCH),
            $this->getPropertyValue(self::PROPERTY_REPLACE),
            $this->getPropertyValue(self::PROPERTY_SUBJECT)
        ));
    }
}