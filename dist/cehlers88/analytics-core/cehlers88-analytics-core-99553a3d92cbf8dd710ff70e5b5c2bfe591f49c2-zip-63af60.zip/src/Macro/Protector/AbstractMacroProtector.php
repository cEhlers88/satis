<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 18.08.2024
 * Time: 21:26
 */

namespace Cehlers88\AnalyticsCore\Macro\Protector;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroProtectorResultDTO;

abstract class AbstractMacroProtector implements MacroProtectorInterface
{
    protected array $authInfos = [];

    public function setAuthInfos(array $authInfos): void
    {
        $this->authInfos = $authInfos;
    }

    public function isAllowed(string $macroName, array $macroProps = []): MacroProtectorResultDTO
    {
        return MacroProtectorResultDTO::create($this->checkMacroPermission($macroName, $macroProps));
    }

    abstract public function checkMacroPermission(string $macroName, array $macroProps): bool;

    abstract public function getName(): string;
}