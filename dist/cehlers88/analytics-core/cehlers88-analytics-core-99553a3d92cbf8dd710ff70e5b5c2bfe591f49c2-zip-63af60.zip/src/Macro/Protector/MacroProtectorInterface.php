<?php

namespace Cehlers88\AnalyticsCore\Macro\Protector;

interface MacroProtectorInterface
{

}