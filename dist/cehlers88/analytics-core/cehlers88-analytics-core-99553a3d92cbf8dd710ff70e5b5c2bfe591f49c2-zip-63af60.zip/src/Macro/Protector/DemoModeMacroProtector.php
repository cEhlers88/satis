<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 18.08.2024
 * Time: 21:35
 */

namespace Cehlers88\AnalyticsCore\Macro\Protector;

class DemoModeMacroProtector extends AbstractMacroProtector
{
    private const array NOT_ALLOWED_MACROS = [
        'Analytics\\Macro\\AiRequestMacro',
        'Analytics\\Macro\\BanMacro',
    ];

    public function getName(): string
    {
        return "demo-mode";
    }

    public function checkMacroPermission(string $macroName, array $macroProps): bool
    {
        if (in_array($macroName, self::NOT_ALLOWED_MACROS)) {
            return false;
        }
        return true;
    }
}