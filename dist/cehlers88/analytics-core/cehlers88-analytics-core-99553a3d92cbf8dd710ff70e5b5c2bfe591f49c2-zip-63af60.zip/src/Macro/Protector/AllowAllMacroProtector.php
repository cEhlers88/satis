<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 18.08.2024
 * Time: 21:35
 */

namespace Cehlers88\AnalyticsCore\Macro\Protector;

class AllowAllMacroProtector extends AbstractMacroProtector
{
    public function getName(): string
    {
        return "allow-all";
    }

    public function checkMacroPermission(string $macroName, array $macroProps): bool
    {
        return true;
    }
}