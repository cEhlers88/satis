<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;

interface MacroInterface
{
    public function getName(): string;

    public function setLogger(?LoggerInterface $logger): static;
}