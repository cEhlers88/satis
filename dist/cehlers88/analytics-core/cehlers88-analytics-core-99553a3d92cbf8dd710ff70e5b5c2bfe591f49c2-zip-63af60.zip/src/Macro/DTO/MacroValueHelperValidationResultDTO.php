<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 24.08.2024
 * Time: 00:31
 */

namespace Cehlers88\AnalyticsCore\Macro\DTO;

use Cehlers88\AnalyticsCore\DTO\ValidationResultDTO;

class MacroValueHelperValidationResultDTO extends ValidationResultDTO
{
    private function __construct()
    {
    }

    public static function create(bool $isValid, string $message = ''): MacroValueHelperValidationResultDTO
    {
        $dto = new self();
        $dto->isValid = $isValid;
        $dto->message = $message;

        return $dto;
    }
}