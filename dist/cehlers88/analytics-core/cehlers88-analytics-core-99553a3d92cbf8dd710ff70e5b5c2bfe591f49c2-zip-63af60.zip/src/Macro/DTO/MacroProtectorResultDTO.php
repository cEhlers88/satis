<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 18.08.2024
 * Time: 21:29
 */

namespace Cehlers88\AnalyticsCore\Macro\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class MacroProtectorResultDTO extends DTO
{
    public bool $isAllowed = false;
    public string $message = '';

    private function __construct()
    {
    }

    public static function create(bool $isAllowed, string $message = ''): MacroProtectorResultDTO
    {
        $dto = new MacroProtectorResultDTO();
        $dto->isAllowed = $isAllowed;
        $dto->message = $message;
        return $dto;
    }
}