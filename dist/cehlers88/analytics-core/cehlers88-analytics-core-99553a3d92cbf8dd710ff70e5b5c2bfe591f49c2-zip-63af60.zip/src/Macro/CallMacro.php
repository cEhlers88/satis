<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class CallMacro extends AbstractMacro
{
    private const string PROPERTY_ARGUMENTS = 'arguments';
    private const string PROPERTY_NAME = 'name';

    public function init(): CallMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME, 'string', 'Specify the function'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ARGUMENTS, 'Command[]|string', 'Specify the function-arguments'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Call a function.';
    }

    public function getName(): string
    {
        return 'call';
    }

    protected function run(): ?array
    {
        return $this->_createRunResult($this->getPropertyValue(self::PROPERTY_NAME));
    }
}