<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 17:08
 */

namespace Cehlers88\AnalyticsCore\Macro\Debugger;

use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\ENUM\eInstructionType;

interface IMacroDebugger
{
    public function attachLog(eDebuggerLogType $logType, string $message, array $additionalInfos): IMacroDebugger;

    public function logStart(eInstructionType $instructionType, int $instructionId, string $instructionName, mixed $instructionArgs): IMacroDebugger;

    public function logEnd(eInstructionType $instructionType, int $instructionId, mixed $instructionResult): IMacroDebugger;

    public function log(eDebuggerLogType $logType, string $message, array $additionalInfos): IMacroDebugger;

    public function getLog(): array;

    public function setOption(string $name, mixed $value): IMacroDebugger;

    public function getOptions(): array;
}