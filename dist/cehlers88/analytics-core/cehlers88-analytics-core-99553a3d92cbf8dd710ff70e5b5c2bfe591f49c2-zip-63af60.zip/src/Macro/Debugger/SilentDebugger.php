<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 17:37
 */

namespace Cehlers88\AnalyticsCore\Macro\Debugger;

use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\ENUM\eInstructionType;

class SilentDebugger implements IMacroDebugger
{
    public function logStart(eInstructionType $instructionType, int $instructionId, string $instructionName, mixed $instructionArgs): IMacroDebugger
    {
        return $this;
    }

    public function logEnd(eInstructionType $instructionType, int $instructionId, mixed $instructionResult): IMacroDebugger
    {
        return $this;
    }

    public function log(eDebuggerLogType $logType, string $message, array $additionalInfos = []): IMacroDebugger
    {
        return $this;
    }

    public function getLog(): array
    {
        return [];
    }

    public function attachLog(eDebuggerLogType $logType, string $message, array $additionalInfos): IMacroDebugger
    {
        // TODO: Implement attachLog() method.
        return $this;
    }

    public function getOptions(): array
    {
        return [];
    }

    public function setOption(string $name, mixed $value): IMacroDebugger
    {
        return $this;
    }
}