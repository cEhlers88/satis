<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 17:37
 */

namespace Cehlers88\AnalyticsCore\Macro\Debugger;

use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogReason;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\ENUM\eInstructionType;
use Symfony\Component\Mercure\HubInterface;
use Symfony\Component\Mercure\Update;

class DevDebugger implements IMacroDebugger
{
    private int $_currentInstructionId = -1;
    private array $_log;
    private array $_runningInstructions;
    private array $_options = [
        'liveLog' => false,
    ];

    public function __construct(
        private HubInterface $hub
    )
    {
        $this->_runningInstructions = [];
        $this->_log = [];

        $this->log(eDebuggerLogType::INFO, "Debugger initialized");
    }

    public function log(eDebuggerLogType $logType, string $message, array $additionalInfos = []): IMacroDebugger
    {
        $parentInstruction = count($this->_runningInstructions) > 0 ? end($this->_runningInstructions)['id'] : null;
        $logProps = [
            'parentInstruction' => $parentInstruction,
            'type' => $logType->name,
            'message' => $message,
            ...$additionalInfos,
        ];

        if ($this->_options['liveLog'] === true) {
            if ($parentInstruction === null) {
                $this->_log = []; // clear buffer only in live mode
            }
            $this->hub->publish(new Update(
                'debugger/log',
                json_encode($logProps)
            ));
        }
        $this->_log[] = $logProps;

        return $this;
    }

    public function logStart(eInstructionType $instructionType, int $instructionId, string $instructionName, mixed $instructionArgs): IMacroDebugger
    {
        $startTime = microtime(true);
        $this->log(eDebuggerLogType::DEBUG, sprintf("Start %s '%s'", $instructionType->name, $instructionName), [
            'args' => $instructionArgs,
            'parentInstruction' => count($this->_runningInstructions) > 0 ? end($this->_runningInstructions)['id'] : null,
            'start' => $startTime,
            'name' => $instructionName,
            'instructionType' => $instructionType->name,
            'id' => $instructionId,
            'reason' => eDebuggerLogReason::INSTRUCTION_START
        ]);
        $this->_currentInstructionId = $instructionId;
        $this->_runningInstructions[] = [
            'id' => $instructionId,
            'logIndex' => count($this->_log) - 1,
            'logBuffer' => []
        ];
        return $this;
    }

    public function logEnd(eInstructionType $instructionType, int $instructionId, mixed $instructionResult): IMacroDebugger
    {
        $endTime = microtime(true);
        $lastRunningInstruction = array_pop($this->_runningInstructions);

        if ($lastRunningInstruction['id'] !== $instructionId) {
            $this->log(eDebuggerLogType::ERROR, sprintf('End instruction %d does not match last started instruction %d', $instructionId, $lastRunningInstruction['id']));
            return $this;
        }

        $startLogEntry = $this->_log[$lastRunningInstruction['logIndex']];
        $logAdditionals = [
            'duration' => $endTime - $startLogEntry['start'],
            'end' => $endTime,
            'instructionType' => $instructionType->name,
            'id' => $instructionId,
            'reason' => eDebuggerLogReason::INSTRUCTION_END
        ];
        if (count($lastRunningInstruction['logBuffer']) > 0) {
            $logAdditionals['attachments'] = $lastRunningInstruction['logBuffer'];
        }
        $this->log(eDebuggerLogType::DEBUG, sprintf('End %s "%s"', $instructionType->name, $startLogEntry['name']), $logAdditionals);

        return $this;
    }

    public function getLog(): array
    {
        return $this->_log;
    }

    public function attachLog(eDebuggerLogType $logType, string $message, array $additionalInfos): IMacroDebugger
    {
        $logProps = [
            'id' => $this->_currentInstructionId,
            'type' => $logType->name,
            'message' => $message,
            'reason' => $logType === eDebuggerLogType::ERROR ? eDebuggerLogReason::ERROR : eDebuggerLogReason::INFO,
            'time' => microtime(true),
            ...$additionalInfos,
        ];

        $this->_runningInstructions[count($this->_runningInstructions) - 1]['logBuffer'][] = $logProps;

        if ($this->_options['liveLog'] === true) {
            $this->hub->publish(new Update(
                'debugger/log',
                json_encode($logProps)
            ));
        }

        return $this;
    }

    public function getOptions(): array
    {
        return $this->_options;
    }

    public function setOption(string $name, mixed $value): IMacroDebugger
    {
        $this->_options[$name] = $value;
        return $this;
    }

}