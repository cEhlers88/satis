<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\AbstractMacro;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class ChangeApplicationMacro extends AbstractMacro
{
    private const string PROPERTY_APPLICATION = 'application';

    public function init(): ChangeApplicationMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_APPLICATION, 'mixed', 'Specify the application name or id'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Change the application.';
    }

    public function getName(): string
    {
        return 'changeApplication';
    }

    protected function run(): ?array
    {
        return $this->_createRunResult(implode(
            $this->getPropertyValue(self::PROPERTY_APPLICATION),
        ));
    }
}