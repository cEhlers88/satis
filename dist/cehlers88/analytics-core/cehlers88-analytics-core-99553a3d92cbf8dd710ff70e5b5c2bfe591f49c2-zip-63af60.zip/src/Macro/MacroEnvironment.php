<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Macro\Debugger\IMacroDebugger;
use Cehlers88\AnalyticsCore\Macro\Debugger\SilentDebugger;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroEnvironmentDTO;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Player\MacroPlayer;
use Cehlers88\AnalyticsCore\Process\ProcessProvider;
use Cehlers88\AnalyticsCore\Process\Runner\CommandsPlayerProcessRunner;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\ProcessRepository;

class MacroEnvironment
{
    private ?Application $_application = null;
    private int $_lastInstructionId = 0;
    private array $_configurations = [];
    private bool $_simulationMode = false;

    public function __construct(
        private ApplicationRepository $applicationRepository,
        private VariablesProvider     $variablesStoreProvider,
        private MacroPlayer           $macroPlayer,
        private CommandPlayer         $commandPlayer,
        private ProcessProvider       $processProvider,
        private ProcessRepository     $processRepository,
        private IMacroDebugger        $_debugger = new SilentDebugger()
    )
    {
        $this->macroPlayer->setMacroEnvironment($this);
        $this->commandPlayer->setMacroEnvironment($this);
        $this->variablesStoreProvider->setMacroEnvironment($this);
    }

    public function getApplication(): ?Application
    {
        return $this->_application;
    }

    public function setApplication(Application $application): MacroEnvironment
    {
        $this->_application = $application;
        return $this;
    }

    public function getConfigurations(): array
    {
        return $this->_configurations;
    }

    public function getDebugger(): IMacroDebugger
    {
        return $this->_debugger;
    }

    public function getVariablesStoreProvider(): VariablesProvider
    {
        return $this->variablesStoreProvider;
    }

    public function getMacroPlayer(): MacroPlayer
    {
        return $this->macroPlayer;
    }

    public function getCommandPlayer(): CommandPlayer
    {
        return $this->commandPlayer;
    }

    public function getNextInstructionId(): int
    {
        return ++$this->_lastInstructionId;
    }

    public function getProcessId(): string
    {
        return $this->_configurations['processId'];
    }

    public function getProcessProvider(): ProcessProvider
    {
        return $this->processProvider;
    }

    public function hasValidApplication(): bool
    {
        return !is_null($this->_application);
    }

    public function isSimulationMode(): bool
    {
        return $this->_simulationMode;
    }

    public function setSimulationMode(bool $simulationMode): MacroEnvironment
    {
        $this->_simulationMode = $simulationMode;
        $this->variablesStoreProvider->setReadonly($simulationMode);
        return $this;
    }

    public function setDebugger(IMacroDebugger $debugger): MacroEnvironment
    {
        $this->_debugger = $debugger;
        return $this;
    }

    public function setVariablesStoreProvider(VariablesProvider $variablesStoreProvider): MacroEnvironment
    {
        $this->variablesStoreProvider = $variablesStoreProvider;
        return $this;
    }

    public function setMacroPlayer(MacroPlayer $macroPlayer): MacroEnvironment
    {
        $this->macroPlayer = $macroPlayer;
        return $this;
    }

    public function setCommandPlayer(CommandPlayer $commandPlayer): MacroEnvironment
    {
        $this->commandPlayer = $commandPlayer;
        return $this;
    }

    public function setExecutorInfos(string $executorName, string $executorIP, string $processId = ''): MacroEnvironment
    {
        $this->_configurations['executor'] = [
            'name' => $executorName,
            'ip' => $executorIP
        ];

        if ($processId === '') {
            $process = $this->processRepository->createNew(
                'MacroExecution',
                'Running MacroExecutor by ' . $executorName,
                CommandsPlayerProcessRunner::class
            );
            
            $processId = $this->processRepository->save($process)->getId();
        }
        $this->_configurations['processId'] = $processId;

        return $this;
    }

    public function load(MacroEnvironmentDTO $macroEnvironmentDTO): MacroEnvironment
    {
        $this->setApplication($this->applicationRepository->find($macroEnvironmentDTO->applicationId));

        $lastArgumentContext = '';
        foreach ($macroEnvironmentDTO->arguments as $argument) {
            if ($argument->context !== $lastArgumentContext) {
                $this->variablesStoreProvider->startArgumentsContext();
                $lastArgumentContext = $argument->context;
            }
            $this->variablesStoreProvider->setArgument($argument->name, $argument->value);
        }

        foreach ($macroEnvironmentDTO->variables as $variable) {
            $this->variablesStoreProvider->setVariable($variable->context, $variable->name, $variable->value);
        }

        return $this;
    }
}