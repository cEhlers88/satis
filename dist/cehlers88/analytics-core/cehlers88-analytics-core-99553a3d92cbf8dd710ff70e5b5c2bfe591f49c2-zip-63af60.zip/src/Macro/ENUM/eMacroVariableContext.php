<?php

namespace Cehlers88\AnalyticsCore\Macro\ENUM;
enum eMacroVariableContext: string
{
    case ARGUMENT = "argument";
    case GET = "get";
    case POST = "post";
    case LOCAL = "local"; // Gültig innerhalb des aktuellen makros
    case JOB = "job"; // Gültig innerhalb des aktuellen jobs
    case WORKER = "worker"; // Gültig innerhalb des aktuellen workers
    case APPLICATION = "application"; // Gültig innerhalb der aktuellen Anwendung (bleibt bis zum löschen bestehen)
    case SERVER = "server"; // Gültig auf dem kompletten Server (bleibt bis zum löschen bestehen)
    case SHARED = "shared"; // Anwendungsübergreifender, globaler Kontext
    case ENVIRONMENT = "env";

    public static function fromString(string $value): eMacroVariableContext
    {
        return match (strtolower($value)) {
            'argument' => self::ARGUMENT,
            'env' => self::ENVIRONMENT,
            'get' => self::GET,
            'post' => self::POST,
            'local' => self::LOCAL,
            'job' => self::JOB,
            'worker' => self::WORKER,
            'application' => self::APPLICATION,
            'server' => self::SERVER,
            'shared' => self::SHARED,
            default => throw new \InvalidArgumentException("Unknown value: $value"),
        };
    }
}