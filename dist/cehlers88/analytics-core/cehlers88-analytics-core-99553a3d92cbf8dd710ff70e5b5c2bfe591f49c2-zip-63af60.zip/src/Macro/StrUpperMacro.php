<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class StrUpperMacro extends AbstractMacro
{
    private const string PROPERTY_VALUE = 'value';

    public function init(): StrUpperMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'string', 'Specify the value to be upper cased'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Convert the given value to upper case.';
    }

    public function getName(): string
    {
        return 'strUpper';
    }

    protected function run(): ?array
    {
        return $this->_createRunResult(strtoupper($this->getPropertyValue(self::PROPERTY_VALUE)));
    }
}