<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogReason;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\SelectVarNameValueHelper;

class GetVarMacro extends AbstractMacro
{
    private const DEFAULT_CONTEXT = eMacroVariableContext::JOB;
    private const PROPERTY_CONTEXT = 'context';
    private const PROPERTY_DEFAULT = 'default';
    private const PROPERTY_NAME = 'name';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?array
    {
        // must be specified in the command-definition (tablefield 'ui_settings')
        switch ($property->name) {
            case self::PROPERTY_NAME:
                return [
                    'displayName' => 'name',
                    /*'class' => ''*/
                    'valueHelper' => SelectVarNameValueHelper::class
                ];
        }
        return null;
    }

    public function init(): GetVarMacro
    {
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME, 'string', 'Specify the variable name'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CONTEXT, 'string', 'Specify the variable context', self::DEFAULT_CONTEXT))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DEFAULT, 'mixed', 'Specify the default result', null));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Retrieve the value of a variable.';
    }

    public function getName(): string
    {
        return 'getVar';
    }

    protected function run(): ?array
    {
        $this->log(eDebuggerLogType::INFO,
            sprintf("Get value of variable '%s'", $this->getPropertyValue(self::PROPERTY_NAME)),
            ['name' => $this->getPropertyValue(self::PROPERTY_NAME)]
        );

        $result = $this->getVariablesStoreProvider()->getVariableValue(
            $this->getPropertyValue(self::PROPERTY_NAME),
            $this->getPropertyValue(self::PROPERTY_CONTEXT),
            $this->getPropertyValue(self::PROPERTY_DEFAULT)
        );

        $this->log(eDebuggerLogType::INFO,
            sprintf("Received '%s'", json_encode($result)),
            [
                'name' => $this->getPropertyValue(self::PROPERTY_NAME),
                'context' => $this->getPropertyValue(self::PROPERTY_CONTEXT),
                'default' => $this->getPropertyValue(self::PROPERTY_DEFAULT),
                'reason' => eDebuggerLogReason::INFO,
                'result' => $result
            ]
        );

        return $this->_createRunResult($result);
    }
}