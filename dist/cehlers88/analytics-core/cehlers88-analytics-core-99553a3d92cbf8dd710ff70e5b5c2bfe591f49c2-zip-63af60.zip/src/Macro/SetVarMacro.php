<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogReason;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;

class SetVarMacro extends AbstractMacro
{
    private const DEFAULT_CONTEXT = eMacroVariableContext::JOB;
    private const PROPERTY_CONTEXT = "context";
    private const PROPERTY_NAME = "name";
    private const PROPERTY_VALUE = "value";

    public function init(): SetVarMacro
    {
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME, 'string', 'Specify the variable name'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'mixed', 'Specify the variable value'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CONTEXT, 'string', 'Specify the variable context', self::DEFAULT_CONTEXT));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Define a variable.';
    }

    public function getName(): string
    {
        return 'setVar';
    }

    protected function run(): ?array
    {
        $varContext = $this->getPropertyValue(self::PROPERTY_CONTEXT);
        $varName = $this->getPropertyValue(self::PROPERTY_NAME);
        $varValue = $this->getPropertyValue(self::PROPERTY_VALUE);

        $this->getVariablesStoreProvider()->setVariable($varName, $varValue, $varContext);

        $this->log(eDebuggerLogType::INFO,
            sprintf("set %s='%s'", $varName, json_encode($varValue)),
            [
                'name' => $varName,
                'context' => $varContext,
                'value' => $varValue,
                'reason' => eDebuggerLogReason::UPDATE_VARIABLE
            ]
        );

        return $this->_createRunResult(["__void" => true]);
    }
}