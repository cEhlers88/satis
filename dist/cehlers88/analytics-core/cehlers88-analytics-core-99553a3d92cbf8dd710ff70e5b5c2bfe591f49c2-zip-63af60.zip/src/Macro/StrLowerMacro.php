<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class StrLowerMacro extends AbstractMacro
{
    private const string PROPERTY_VALUE = 'value';

    public function init(): StrLowerMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'string', 'Specify the value to be lower cased'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Convert the given value to lower case.';
    }

    public function getName(): string
    {
        return 'strLower';
    }

    protected function run(): ?array
    {
        return $this->_createRunResult(strtolower($this->getPropertyValue(self::PROPERTY_VALUE)));
    }
}