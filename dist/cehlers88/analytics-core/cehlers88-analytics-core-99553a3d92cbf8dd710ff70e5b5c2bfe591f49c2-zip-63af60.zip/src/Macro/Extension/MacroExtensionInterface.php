<?php

namespace Cehlers88\AnalyticsCore\Macro\Extension;

interface MacroExtensionInterface
{

}