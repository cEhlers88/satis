<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 18.08.2024
 * Time: 09:55
 */

namespace Cehlers88\AnalyticsCore\Macro\Extension\validator;

use Cehlers88\AnalyticsCore\Macro\Extension\AbstractMacroExtension;

class MailAddressValidator extends AbstractMacroExtension
{

    public function getName(): string
    {
        return 'MailAddressValidator';
    }

    public function getTags(): array
    {
        return ['validator', 'mail'];
    }

    public function getDescription(): string
    {
        return 'This extension provides the ability to validate mail addresses.';
    }

    public function execute(): mixed
    {
        return json_encode([]);
    }
}