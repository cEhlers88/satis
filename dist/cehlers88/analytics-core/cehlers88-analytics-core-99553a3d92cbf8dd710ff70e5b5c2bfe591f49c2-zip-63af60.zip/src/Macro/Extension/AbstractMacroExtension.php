<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 18.08.2024
 * Time: 09:26
 */

namespace Cehlers88\AnalyticsCore\Macro\Extension;

abstract class AbstractMacroExtension implements MacroExtensionInterface
{
    protected mixed $data = null;

    abstract public function execute(): mixed;

    abstract public function getName(): string;

    abstract public function getTags(): array;

    abstract public function getDescription(): string;

    public function setData(mixed $data): AbstractMacroExtension
    {
        $this->data = $data;
        return $this;
    }
}