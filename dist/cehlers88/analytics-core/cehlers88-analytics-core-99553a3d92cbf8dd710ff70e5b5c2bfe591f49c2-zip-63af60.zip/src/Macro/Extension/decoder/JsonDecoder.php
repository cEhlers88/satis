<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 18.08.2024
 * Time: 09:55
 */

namespace Cehlers88\AnalyticsCore\Macro\Extension\decoder;

use Cehlers88\AnalyticsCore\Macro\Extension\AbstractMacroExtension;

class JsonDecoder extends AbstractMacroExtension
{

    public function getName(): string
    {
        return 'JsonDecoder';
    }

    public function getTags(): array
    {
        return ['decoder', 'json'];
    }

    public function getDescription(): string
    {
        return 'This extension provides the ability to decode json to data.';
    }

    public function execute(): mixed
    {
        return json_decode([]);
    }
}