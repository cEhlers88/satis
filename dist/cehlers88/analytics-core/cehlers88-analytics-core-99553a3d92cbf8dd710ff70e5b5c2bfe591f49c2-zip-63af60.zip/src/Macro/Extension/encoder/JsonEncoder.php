<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 18.08.2024
 * Time: 09:55
 */

namespace Cehlers88\AnalyticsCore\Macro\Extension\encoder;

use Cehlers88\AnalyticsCore\Macro\Extension\AbstractMacroExtension;

class JsonEncoder extends AbstractMacroExtension
{

    public function getName(): string
    {
        return 'JsonEncoder';
    }

    public function getTags(): array
    {
        return ['encoder', 'json'];
    }

    public function getDescription(): string
    {
        return 'This extension provides the ability to encode data to json.';
    }

    public function execute(): mixed
    {
        return json_encode([]);
    }
}