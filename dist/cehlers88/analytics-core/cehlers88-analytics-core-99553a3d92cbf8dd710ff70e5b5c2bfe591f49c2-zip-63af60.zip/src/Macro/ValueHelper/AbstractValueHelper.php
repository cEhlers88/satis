<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 23.08.2024
 * Time: 23:07
 */

namespace Cehlers88\AnalyticsCore\Macro\ValueHelper;

use Cehlers88\AnalyticsCore\Macro\AbstractMacro;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroValueHelperValidationResultDTO;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;

abstract class AbstractValueHelper
{
    protected AbstractMacro $_currentMacro;
    protected MacroEnvironment $_macroEnvironment;

    public function getDescription(): string
    {
        return "This helper has no description";
    }

    public function setMacroEnvironment(MacroEnvironment $macroEnvironment): self
    {
        $this->_macroEnvironment = $macroEnvironment;
        return $this;
    }

    public function setCurrentMacro(AbstractMacro $macro): self
    {
        $this->_currentMacro = $macro;
        return $this;
    }

    /**
     * @param MacroPropertyDTO[] $currentProperties
     * @param array $options
     * @return array
     */
    abstract public function getDefinition(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): array;

    /**
     * @param MacroPropertyDTO[] $currentProperties
     * @param array $options
     * @return array
     */
    abstract public function validate(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): MacroValueHelperValidationResultDTO;

    protected function buildSelectDefinition(array $selectOptions, mixed $selected): array
    {
        return $this->buildDefinition('select', [
            'options' => $selectOptions,
            'selected' => $selected
        ]);
    }

    private function buildDefinition(string $type, array $data): array
    {
        return [
            'type' => $type,
            'data' => $data
        ];
    }

    protected function buildInputDefinition(string $inputType, string $name, string $label, mixed $value): array
    {
        return $this->buildDefinition('input', [
            'type' => $inputType,
            'name' => $name,
            'label' => $label,
            'value' => $value
        ]);
    }
}