<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 23.08.2024
 * Time: 23:10
 */

namespace Cehlers88\AnalyticsCore\Macro\ValueHelper;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroValueHelperValidationResultDTO;

class SelectVarNameValueHelper extends AbstractValueHelper
{
    public function getDescription(): string
    {
        return "This helper helps you to select a variable name";
    }

    public function getDefinition(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): array
    {
        $context = '';
        $selectOptions = [];

        foreach ($currentProperties as $currentProperty) {
            if ($currentProperty->name === 'context') {
                $context = $currentProperty->value;
            }
        }

        if (array_key_exists('context', $options)) {
            $context = $options['context'];
        }

        if ($context === '') {
            foreach ($this->_macroEnvironment->getVariablesStoreProvider()->getAllVariables() as $context => $variables) {
                foreach ($variables as $variableName => $variableValue) {
                    $selectOptions[] = [
                        'details' => [
                            'context' => $context,
                            'currentValue' => $variableValue,
                            'whenSelect' => [
                                'context' => $context
                            ]
                        ],
                        'value' => $variableName,
                        'label' => $variableName,
                    ];
                }
            }
        } else {
            foreach ($this->_macroEnvironment->getVariablesStoreProvider()->getVariables($context) as $variableName => $variableValue) {
                $selectOptions[] = [
                    'details' => [
                        'context' => $context,
                        'currentValue' => $variableValue,
                        'whenSelect' => [
                            'context' => $context
                        ]
                    ],
                    'value' => $variableName,
                    'label' => $variableName,
                ];
            }
        }

        return $this->buildSelectDefinition($selectOptions, '');
    }

    public function validate(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): MacroValueHelperValidationResultDTO
    {
        return MacroValueHelperValidationResultDTO::create(true);
    }
}