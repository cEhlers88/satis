<?php

namespace Cehlers88\AnalyticsCore\Configuration\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class UserInputActionDTO extends DTO
{
    public const ACTION_SET_VALUE = 'set_value';
    public const ACTION_ADD_ITEM = 'add_item';
    public const ACTION_REMOVE_ITEM = 'remove_item';

    public string $action = '';
    public ConfigurationItemDTO $configurationItemDTO;
    public ?int $position = null;

    /**
     * Creates an action that sets the value of an existing configuration item in the frontend.
     */
    public static function createSetValue(
        string $key,
        mixed  $value
    ): static
    {
        $dto = new static();
        $dto->action = self::ACTION_SET_VALUE;
        $dto->configurationItemDTO = ConfigurationItemDTO::create($key);
        $dto->configurationItemDTO->defaultValue = $value;

        return $dto;
    }

    /**
     * Creates an action that adds a new item to a repeatable configuration field in the frontend.
     *
     * @param string $key Key of the repeatable configuration item to extend.
     * @param mixed $value Default value for the new item.
     * @param int|null $position Optional zero-based insertion index. If null, the item is appended at the end.
     */
    public static function createAddItem(
        string $key,
        mixed  $value = null,
        ?int   $position = null
    ): static
    {
        $dto = new static();
        $dto->action = self::ACTION_ADD_ITEM;
        $dto->configurationItemDTO = ConfigurationItemDTO::create($key);
        $dto->configurationItemDTO->defaultValue = $value;
        $dto->position = $position;

        return $dto;
    }

    /**
     * Creates an action that removes an existing item from a repeatable configuration field in the frontend.
     *
     * @param string $key Key of the configuration item to remove.
     * @param int|null $position Zero-based index of the item to remove. If null, the last item is removed.
     */
    public static function createRemoveItem(
        string $key,
        ?int   $position = null
    ): static
    {
        $dto = new static();
        $dto->action = self::ACTION_REMOVE_ITEM;
        $dto->configurationItemDTO = ConfigurationItemDTO::create($key);
        $dto->position = $position;

        return $dto;
    }
}
