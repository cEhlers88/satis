<?php

namespace Cehlers88\AnalyticsCore\Provider;

use Cehlers88\AnalyticsCore\Support\DTO\ContextNameValueDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Repository\SharedDataRepository;
use Cehlers88\AnalyticsCore\Repository\VariableStoreRepository;
use Exception;

class VariablesProvider
{
    public const GET_VAR_WILDCARD = "*";
    public const UNDEFINED_VAR = ">#_-UNDEFINED-_#<";
    private ?MacroEnvironment $_macroEnvironment = null;
    private int $_loadedApplicationId = 0;
    private array $_variablesStore = [];
    private bool $_readonly = false;

    /**
     * @var ContextNameValueDTO[]
     */
    private array $_argumentsStore = [];
    private string $_argumentsContext = "";
    private $_changeLogger;

    public function __construct(
        private VariableStoreRepository $_variableStoreRepository,
        private SharedDataRepository    $_sharedDataRepository
    )
    {
        $this->_resetStore();
        $this->setChangeLogger(function () {
            // dummy
        });

        $this
            ->loadServerContext()
            ->loadSharedContext();
    }

    private function _resetStore(): void
    {
        $this->_variablesStore = [
            eMacroVariableContext::ENVIRONMENT->name => [],
            eMacroVariableContext::LOCAL->name => [],
            eMacroVariableContext::JOB->name => [],
            eMacroVariableContext::WORKER->name => [],
            eMacroVariableContext::APPLICATION->name => [],
            eMacroVariableContext::SERVER->name => [],
        ];
    }

    public function setChangeLogger(callable $changeLogger): VariablesProvider
    {
        $this->_changeLogger = $changeLogger;
        return $this;
    }

    public function loadSharedContext(): VariablesProvider
    {
        foreach ($this->_sharedDataRepository->findAll() as $sharedData) {
            $this->_variablesStore[eMacroVariableContext::SHARED->name][$sharedData->getName()] = $sharedData->getValue();
        }
        return $this;
    }

    public function loadServerContext(): VariablesProvider
    {
        foreach ($this->_variableStoreRepository->findBy([
            'context' => eMacroVariableContext::SERVER->name
        ]) as $variableStore) {
            $this->_variablesStore[eMacroVariableContext::SERVER->name][$variableStore->getName()] = $variableStore->getValue()[1];
        }
        return $this;
    }

    public function setVariable(string $variableName, mixed $variableValue, eMacroVariableContext|string $context = eMacroVariableContext::ENVIRONMENT): VariablesProvider
    {
        $contextName = (is_string($context) ? $context : $context->name);
        $oldValue = isset($this->_variablesStore[$contextName][$variableName]) ? $this->_variablesStore[$contextName][$variableName] : self::UNDEFINED_VAR;

        $this->_variablesStore[$contextName][$variableName] = $variableValue;

        call_user_func($this->_changeLogger, $variableName, $variableValue, $oldValue, $contextName);
        return $this;
    }

    public function clearContext(eMacroVariableContext $context): VariablesProvider
    {
        $this->_variableStoreRepository->deleteBy_applicationAndContext(
            $this->getApplication(),
            $context
        );
        return $this;
    }

    public function getApplication(): ?Application
    {
        return is_null($this->_macroEnvironment) ? null : $this->_macroEnvironment->getApplication();
    }

    public function getConstants(): array
    {
        return $this->_variableStoreRepository->findAllConstants();
    }

    public function getVariables(eMacroVariableContext|string $context = eMacroVariableContext::ENVIRONMENT): array
    {
        $context = (is_string($context) ? $context : $context->name);

        if (strtolower($context) === 'get') return $_GET;
        if (strtolower($context) === 'post') return $_POST;
        if (strtolower($context) === eMacroVariableContext::ARGUMENT->value) return $this->_argumentsStore;

        return $this->_variablesStore[$context];
    }

    /**
     * @param string $variableName
     * @param eMacroVariableContext $context
     * @param mixed $defaultValue
     * @return mixed
     * @throws Exception
     */
    public function getVariableValue(
        string                       $variableName,
        eMacroVariableContext|string $context = eMacroVariableContext::ENVIRONMENT,
        mixed                        $defaultValue = self::UNDEFINED_VAR
    ): mixed
    {
        $context = (is_string($context) ? $context : $context->name);

        $application = $this->getApplication();
        if (!is_null($application) && $this->_loadedApplicationId !== $application->getId()) {
            $this->loadApplicationContext($application->getId());
            $this->_loadedApplicationId = $application->getId();
        }

        if (strtolower($context) === eMacroVariableContext::ARGUMENT->value) {
            if ($variableName === self::GET_VAR_WILDCARD) return $this->_argumentsStore;
            return $this->getArgument($variableName);
        } else if (strtolower($context) === eMacroVariableContext::GET->name) {
            if ($variableName === self::GET_VAR_WILDCARD) return $_GET;
            if (isset($_GET[$variableName])) return $_GET[$variableName];
        } else if (strtolower($context) === eMacroVariableContext::POST->name) {
            if ($variableName === self::GET_VAR_WILDCARD) return $_POST;
            if (isset($_POST[$variableName])) return $_POST[$variableName];
        }

        foreach ($this->_variablesStore as $variableContextName => $contextStore) {
            if (strtolower($variableContextName) !== strtolower($context)) {
                continue;
            }

            if ($variableName === self::GET_VAR_WILDCARD) return $contextStore;

            foreach ($contextStore as $index => $storedVariable) {
                if (is_string($index)) {
                    if ($index === $variableName) {
                        return $storedVariable;
                    }
                    continue;
                }
                if ($storedVariable->getName() !== $variableName) {
                    continue;
                }
                return $storedVariable->getValue()[1];
            }
        }

        $argumentValue = $this->getArgument($variableName);
        if ($argumentValue !== self::UNDEFINED_VAR) return $argumentValue;

        if ($defaultValue !== self::UNDEFINED_VAR) return $defaultValue;

        throw new Exception('Variable ' . $context . '/' . $variableName . ' not found');
    }

    public function loadApplicationContext(int $applicationId): VariablesProvider
    {
        $contextData = $this->_variableStoreRepository->findBy([
            'application' => [
                'id' => $applicationId
            ],
            'context' => eMacroVariableContext::APPLICATION->name
        ]);
        $this->_variablesStore[eMacroVariableContext::APPLICATION->name] = $contextData;
        return $this;
    }

    public function getArgument(string $name, mixed $defaultValue = self::UNDEFINED_VAR): mixed
    {
        for ($i = count($this->_argumentsStore) - 1; $i >= 0; $i--) {
            $argument = $this->_argumentsStore[$i];
            if ($argument->name === $name) return $argument->value;
        }
        return $defaultValue;
    }

    // environment arguments handling start

    public function removeVariable(string $variableName, eMacroVariableContext $context = eMacroVariableContext::ENVIRONMENT): VariablesProvider
    {
        $newVariables = [];

        foreach ($this->_variablesStore[$context->name] as $storedVariableName => $storedVariableValue) {
            if ($storedVariableName !== $variableName) $newVariables[$storedVariableName] = $storedVariableValue;
        }

        $this->_variablesStore[$context->name] = $newVariables;
        return $this;
    }

    public function save(): VariablesProvider
    {
        if ($this->_readonly) return $this;

        $variables = $this->getAllVariables();
        $self = $this;

        $this->_sharedDataRepository->setAutoFlush(false);
        foreach ($variables[eMacroVariableContext::SHARED->name] as $variableName => $variableValue) {
            $this->_sharedDataRepository->set($variableName, $variableValue);
        }
        $this->_sharedDataRepository->flush();

        if ($this->getApplication() === null) return $this; // after this point, an application is required

        array_map(function ($context) use ($variables, $self) {
            foreach ($variables[$context->name] as $variableName => $variableValue) {
                $self->_variableStoreRepository->setVariableValue($context, $variableName, [gettype($variableValue), $variableValue], $this->getApplication());
            }
        }, [
            eMacroVariableContext::SERVER,
            eMacroVariableContext::APPLICATION
        ]);

        return $this;
    }

    public function getAllVariables(): array
    {
        return [
            ...$this->_variablesStore,
            eMacroVariableContext::GET->name => $_GET,
            eMacroVariableContext::POST->name => $_POST
        ];
    }

    public function startArgumentsContext(): VariablesProvider
    {
        $this->_argumentsContext = uniqid();
        return $this;
    }

    // environment arguments handling end

    public function clearArgumentsContext(): VariablesProvider
    {
        $newArguments = [];
        $context = $this->_argumentsContext;
        array_map(function ($argument) use ($context, &$newArguments) {
            if ($argument->context !== $context) $newArguments[] = $argument;
        }, $this->_argumentsStore);

        return $this;
    }

    public function setArgument(string $name, mixed $value): VariablesProvider
    {
        $this->_argumentsStore[] = ContextNameValueDTO::create($this->_argumentsContext, $name, $value);

        call_user_func($this->_changeLogger, $name, $value, null, $this->_argumentsContext);

        return $this;
    }

    public function setReadonly(bool $readonly): VariablesProvider
    { // prevent saving variables to database
        $this->_readonly = $readonly;
        return $this;
    }

    public function setMacroEnvironment(MacroEnvironment $macroEnvironment): VariablesProvider
    {
        $this->_macroEnvironment = $macroEnvironment;
        return $this;
    }
}