<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 18.08.2024
 * Time: 09:33
 */

namespace Cehlers88\AnalyticsCore\Provider;

use Cehlers88\AnalyticsCore\Macro\Extension\AbstractMacroExtension;

class MacroExtensionProvider
{
    public function __construct(
        private iterable $extensions
    )
    {
    }

    /**
     * @return AbstractMacroExtension[]
     */
    public function getExtensions(): iterable
    {
        return $this->extensions;
    }

    /**
     * @param array $tags
     * @return AbstractMacroExtension[]
     */
    public function getExtensionsByTags(array $tags): array
    {
        $extensions = [];
        foreach ($this->extensions as $extension) {
            if (count(array_intersect($tags, $extension->getTags())) > 0) {
                $extensions[] = $extension;
            }

        }
        return $extensions;
    }
}