<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 20.05.2024
 * Time: 10:10
 */

namespace Cehlers88\AnalyticsCore\Support\DTO\UI;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class MenuItemDTO extends DTO
{
    public string $label = '';
    public string $icon = '';
    public string $routeName = '';
    public array $routeParameters = [];
    public string $url = '';
    public array $subItems = [];
    public array $permissions = [];

    private function __construct()
    {
    }

    public static function create(
        string $label,
        string $routeName = "",
        array  $routeParameters = [],
        string $icon = "",
        array  $subItems = [],
        array  $permissions = []
    ): MenuItemDTO
    {
        $instance = new self();
        $instance->label = $label;
        $instance->icon = $icon;
        $instance->routeName = $routeName;
        $instance->routeParameters = $routeParameters;
        $instance->subItems = $subItems;
        $instance->permissions = $permissions;

        return $instance;
    }

    public static function createExternal(
        string $label,
        string $url,
        string $icon = "",
        array  $permissions = []
    ): MenuItemDTO
    {
        $instance = new self();
        $instance->label = $label;
        $instance->icon = $icon;
        $instance->url = $url;
        $instance->permissions = $permissions;

        return $instance;
    }
}