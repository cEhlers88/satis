<?php

namespace Cehlers88\AnalyticsCore\Support\DTO;

class CurlResponseDTO extends DTO
{
    public function __construct(
        public readonly int   $statusCode,
        public readonly mixed $body,
        public readonly array $headers = [],
    )
    {
    }
}