<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 16.08.2024
 * Time: 20:02
 */

namespace Cehlers88\AnalyticsCore\Support\DTO;

class ContextNameValueDTO extends DTO
{
    public string $context;
    public string $name;
    public mixed $value;

    private function __construct()
    {
    }

    public static function create(string $context, string $name, mixed $value): ContextNameValueDTO
    {
        $dto = new self();
        $dto->context = $context;
        $dto->name = $name;
        $dto->value = $value;

        return $dto;
    }
}