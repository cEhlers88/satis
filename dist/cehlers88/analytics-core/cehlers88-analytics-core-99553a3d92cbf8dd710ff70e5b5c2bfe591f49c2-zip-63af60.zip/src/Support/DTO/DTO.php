<?php

namespace Cehlers88\AnalyticsCore\Support\DTO;

/**
 * Base class for data transfer objects.
 */
abstract class DTO
{

}