<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 07.05.2024
 * Time: 21:45
 */

namespace Cehlers88\AnalyticsCore\Support;

interface BundlePluginInterface
{
    public function getMenuItems();

    public function getDescription(): string;

    public function getPermissions(): array;

    public function getVersion(): string;

    public function handleInstall(): array;

    public function handleUpdate(string $previousVersion): array;

    public function getTrackingBufferKeys(): array;
}