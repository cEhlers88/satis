<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.09.2024
 * Time: 01:50
 */

namespace Cehlers88\AnalyticsCore\Support\Logging;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;

/** Interface for logger implementations. */
interface LoggerInterface
{
    public function configure(array $config): static;

    /**
     * @return PropertyDTO[]
     */
    public function getProperties(): array;

    public function getPropertyValue(string $name, mixed $defaultValue = null): mixed;

    public function setPropertyValue(string $name, mixed $value): static;

    public function log(eDebuggerLogType $logType, string $message, array $additionalInfos = []);

    public function addDateTimeToLogMessage(bool $addDateTime): static;

    public function addTypeToLogMessage(bool $addType): static;

    public function addTabSpace(int $tabSpaceCount = 1): static;

    public function removeTabSpace(int $tabSpaceCount = 1): static;

    public function error(string $message): void;

    public function info(string $message): void;

    public function progressAdvance(int $step = 1, string $name = ''): void;

    public function progressStart(int $max, string $name = ''): void;

    public function warning(string $message): void;

    public function setIgnoreInfoLog(bool $ignoreInfoLog = true): static;

    public function getName(): string;

    public function startGroup(string $name, array $data = []): static;

    public function endGroup(string $name): static;

    public function finalize(): static;
}