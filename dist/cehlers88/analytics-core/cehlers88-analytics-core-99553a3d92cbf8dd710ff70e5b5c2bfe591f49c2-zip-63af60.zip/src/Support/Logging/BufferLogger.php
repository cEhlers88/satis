<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.09.2024
 * Time: 02:02
 */

namespace Cehlers88\AnalyticsCore\Support\Logging;

class BufferLogger extends AbstractLogger implements LoggerInterface
{
    private bool $ignoreInfoLog = false;
    private array $buffer = [];

    public function info(string $message): void
    {
        if ($this->ignoreInfoLog) return;
        $this->_bufferMessage(' [I] ' . $message);
    }

    private function _bufferMessage($message)
    {
        $this->dispatchWillCreateLogHandler();
        $this->buffer[] = (new \DateTime())->format('Y-m-d H:i:s') . str_pad(' ', $this->tabSpaces) . $message;
    }

    public function warning(string $message): void
    {
        $this->_bufferMessage(' [W] ' . $message);
    }

    public function setIgnoreInfoLog(bool $ignoreInfoLog = true): static
    {
        $this->ignoreInfoLog = $ignoreInfoLog;
        return $this;
    }

    public function getBuffer(): array
    {
        return $this->buffer;
    }

    public function error(string $message): void
    {
        $this->_bufferMessage(' [E] ' . $message);
    }
}