<?php

namespace Cehlers88\AnalyticsCore\Support\Logging;

class LoggerProvider
{
    /**
     * @param LoggerInterface[] $loggers
     */
    public function __construct(
        private iterable $loggers
    )
    {

    }

    /**
     * Get a list of logger definitions.
     *
     * @return array 2D array of logger definitions.
     */
    public function getLoggerDefinitions(): array
    {
        $buffer = [];
        foreach ($this->loggers as $logger) {
            $buffer[] = [
                'name' => $logger->getName(),
                'class' => $logger::class,
                'properties' => $logger->getProperties(),
            ];
        }
        return $buffer;
    }

    /**
     * Get a logger by name.
     *
     * @param string $name
     * @return LoggerInterface|null
     */
    public function getLoggerByName(string $name): ?LoggerInterface
    {
        foreach ($this->loggers as $logger) {
            if ($logger->getName() === $name) {
                return $logger;
            }
        }
        return null;
    }
}