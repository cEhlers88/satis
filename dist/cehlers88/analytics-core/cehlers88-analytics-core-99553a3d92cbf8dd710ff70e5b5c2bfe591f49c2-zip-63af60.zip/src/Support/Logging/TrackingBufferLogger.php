<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.09.2024
 * Time: 02:02
 */

namespace Cehlers88\AnalyticsCore\Support\Logging;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Recorder\TrackingRecorder;

/** Logger that creates a new TrackingBuffer to store log messages. */
class TrackingBufferLogger extends AbstractLogger
{
    private array $buffer = [];

    public function __construct(
        private TrackingRecorder $trackingRecorder
    )
    {
        $this->properties = [
            PropertyDTO::create('applicationId', null),
            PropertyDTO::create('key', 'logger', 'string', true),
            PropertyDTO::create('note', '', 'string', true),
        ];
    }

    public function info(string $message): void
    {
        $this->buffer[] = ['info', $message];
    }

    public function error($message): void
    {
        $this->buffer[] = ['error', $message];
    }

    public function warning(string $message): void
    {
        $this->buffer[] = ['warning', $message];
    }

    public function finalize(): static
    {
        $this->trackingRecorder->track(
            $this->getPropertyValue('applicationId'),
            [
                'key' => $this->getPropertyValue('key'),
                'data' => $this->getBuffer(),
            ]
        );
        return $this;
    }

    public function getBuffer(): array
    {
        return $this->buffer;
    }
}