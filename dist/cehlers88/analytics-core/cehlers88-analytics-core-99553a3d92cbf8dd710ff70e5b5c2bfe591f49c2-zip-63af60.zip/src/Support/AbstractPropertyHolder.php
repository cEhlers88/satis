<?php

namespace Cehlers88\AnalyticsCore\Support;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Support\Error\AbstractErrorBag;

abstract class AbstractPropertyHolder extends AbstractErrorBag
{
    protected array $propertyLoads = [];
    /**
     * @var PropertyDTO[] $properties
     */
    private array $properties = [];

    public function getProperties(): array
    {
        return $this->properties;
    }

    public function getPropertyValue(string $name, mixed $defaultValue = null): mixed
    {
        $property = $this->getProperty($name);

        if ($property === null) {
            return $defaultValue;
        }

        if ($property->isDefaultValue) {
            return $defaultValue ?? $property->value;
        }

        return $property->value;
    }

    public function getProperty(string $name): ?PropertyDTO
    {
        foreach ($this->properties as $property) {
            if ($property->name === $name) {
                return $property;
            }
        }
        return null;
    }

    public function loadPropertyValues(array $properties, bool $allowCreation = false): static
    {
        $this->propertyLoads = $properties;
        foreach ($properties as $key => $valueDef) {
            try {
                $this->setPropertyValue($valueDef[1], $valueDef[2]);
            } catch (\InvalidArgumentException $e) {
                if (!$allowCreation) {
                    throw $e;
                }
                $property = PropertyDTO::create($valueDef[1], $valueDef[2], $valueDef[0]);
                $property->isDefaultValue = false;
                $this->addProperty($property);
            }
        }

        return $this;
    }

    /**
     * @param string $name
     * @param mixed $value
     * @return $this
     * @throws \InvalidArgumentException
     */
    public function setPropertyValue(string $name, mixed $value): static
    {
        foreach ($this->properties as $property) {
            if ($property->name === $name) {
                $property->isDefaultValue = $property->isDefaultValue && ($property->value === $value);
                $property->value = $value;
                return $this;
            }
        }

        throw new \InvalidArgumentException(sprintf('Property "%s" does not exist', $name));
    }

    /**
     * @param PropertyDTO $property
     * @return $this
     * @throws \InvalidArgumentException
     */
    public function addProperty(PropertyDTO $property): static
    {
        if ($this->hasProperty($property->name)) {
            throw new \InvalidArgumentException(sprintf('Property "%s" already exists', $property->name));
        }

        $this->properties[] = $property;
        return $this;
    }

    public function hasProperty(string $name): bool
    {
        return $this->getProperty($name) !== null;
    }

    public function validateProperties(): bool
    {
        foreach ($this->properties as $property) {
            if ($property->isDefaultValue && $property->isOptional === false) {
                $this->setError('Property "' . $property->name . '" is required');
                return false;
            }
        }
        return true;
    }
}