<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\Presentation\Assembler\AssembledInterface;

/** Interface for entity view representations. */
interface ViewInterface extends AssembledInterface
{

}