<?php

namespace Cehlers88\AnalyticsCore\Presentation\Service;

use Cehlers88\AnalyticsCore\Presentation\Assembler\AssemblerInterface;

class AssemblerProvider
{
    public function __construct(
        /** @var AssemblerInterface[] $assemblers */
        private iterable $assemblers
    )
    {

    }

    public function getAssemblerForClass(string $class, string $for = 'view'): ?AssemblerInterface
    {
        $test = [];
        foreach ($this->assemblers as $assembler) {
            $test[] = $assembler;
            if ($assembler->canHandle($class) && $assembler->getUseFor() === $for) {
                return $assembler;
            }
        }
        return null;
    }
}