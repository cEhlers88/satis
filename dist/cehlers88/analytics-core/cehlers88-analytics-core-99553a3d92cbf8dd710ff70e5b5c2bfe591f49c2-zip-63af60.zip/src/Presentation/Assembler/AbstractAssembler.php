<?php

namespace Cehlers88\AnalyticsCore\Presentation\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;

abstract class AbstractAssembler implements AssemblerInterface
{
    /** @var array<int, callable(AssembledInterface, EntityInterface): AssembledInterface> */
    protected array $extenders = [];

    /**
     * @param array{extenders?: array<int, callable(AssembledInterface, EntityInterface): AssembledInterface>} $config
     */
    public function configure(array $config): static
    {
        $this->extenders = $config['extenders'] ?? [];

        return $this;
    }

    public function many(iterable $entities): array
    {
        $buffer = [];
        foreach ($entities as $entity) {
            $buffer[] = $this->one($entity);
        }
        return $buffer;
    }

    final public function one(EntityInterface $entity): AssembledInterface
    {
        $view = $this->assemble($entity);

        foreach ($this->extenders as $extender) {
            $view = $extender($view, $entity);
        }

        return $view;
    }

    public abstract function assemble(EntityInterface $entity): AssembledInterface;

    abstract public function canHandle(string $className): bool;

    abstract public function getUseFor(): string;
}