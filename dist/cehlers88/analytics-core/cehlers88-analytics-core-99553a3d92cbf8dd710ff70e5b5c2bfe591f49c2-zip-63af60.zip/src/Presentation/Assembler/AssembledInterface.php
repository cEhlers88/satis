<?php

namespace Cehlers88\AnalyticsCore\Presentation\Assembler;

interface AssembledInterface
{

}