<?php

namespace Cehlers88\AnalyticsCore\Presentation\Backend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Assembler\AssembledInterface;
use Cehlers88\AnalyticsCore\Presentation\Assembler\AssemblerInterface;

/** Base class for assemblers that convert entities to views. */
abstract class AbstractAssembler extends \Cehlers88\AnalyticsCore\Presentation\Assembler\AbstractAssembler implements AssemblerInterface
{
    public function assemble(EntityInterface $entity): AssembledInterface
    {
        return $this->assembleJson($entity);
    }

    abstract public function assembleJson(EntityInterface $entity): AssembledInterface;

    public function getUseFor(): string
    {
        return 'backend';
    }
}