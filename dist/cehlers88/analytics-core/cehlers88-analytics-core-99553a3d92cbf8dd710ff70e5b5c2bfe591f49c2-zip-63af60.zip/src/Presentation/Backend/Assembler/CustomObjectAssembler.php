<?php

namespace Cehlers88\AnalyticsCore\Presentation\Backend\Assembler;

use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Assembler\AssembledInterface;
use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectJson;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;

class CustomObjectAssembler extends AbstractAssembler
{
    public function __construct(
        private ClientRepository  $clientRepository,
        private AssemblerProvider $assemblerProvider
    )
    {

    }

    /**
     * @param CustomEntity $entity
     */
    public function assembleJson(EntityInterface $entity): AssembledInterface
    {
        $attributes = [];

        foreach ($entity->getAttributes() as $attribute) {
            switch ($attribute->getName()) {
                case 'client_id':
                    $client = $this->clientRepository->find($attribute->getValue());
                    if (empty($client)) break;
                    $attributes['client'] = $this->assemblerProvider
                        ->getAssemblerForClass($client::class)
                        ->one($client);
                    break;
                default:
                    $attributes[$attribute->getName()] = $attribute->getValue();
            }
        }

        $assembledCustomObject = new CustomObjectJson(
            $entity->getId(),
            $entity->getClassName(),
            $entity->getName(),
            $attributes
        );
        return $assembledCustomObject;
    }

    public function canHandle(string $className): bool
    {
        return $className === CustomEntity::class;
    }
}