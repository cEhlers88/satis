<?php

namespace Cehlers88\AnalyticsCore\Presentation\Backend\JSON;

use Cehlers88\AnalyticsCore\Presentation\Assembler\AssembledInterface;

class CustomObjectJson implements AssembledInterface
{
    public function __construct(
        public int    $id,
        public string $className,
        public string $name,
        public array  $attributes
    )
    {
    }
}