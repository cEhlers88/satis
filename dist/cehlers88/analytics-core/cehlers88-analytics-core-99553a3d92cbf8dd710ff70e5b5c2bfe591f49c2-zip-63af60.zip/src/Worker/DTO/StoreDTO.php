<?php

namespace Cehlers88\AnalyticsCore\Worker\DTO;

use Cehlers88\AnalyticsCore\DTO\NotificationDTO;
use Cehlers88\AnalyticsCore\Support\DTO\DTO;

/** Data transfer object for worker store data. */
class StoreDTO extends DTO
{
    /** @var NotificationDTO[] $alerts */
    public array $alerts = [];

    /** @var string|null */
    public ?string $message = null;
    /** @var array */
    public array $currentData = [];
    /** @var array */
    public array $lastData = [];

    /**
     * Create a StoreDTO from an array.
     *
     * @param array $data Input data.
     * @return static
     */
    public static function fromArray(array $data): static
    {
        $dto = new static();

        if (isset($data['message'])) {
            $dto->message = $data['message'];
        }
        if (isset($data['alerts'])) {
            $dto->alerts = $data['alerts'];
        }
        if (isset($data['currentData'])) {
            $dto->currentData = $data['currentData'];
        }
        if (isset($data['lastData'])) {
            $dto->lastData = $data['lastData'];
        }

        return $dto;
    }

    /** Convert the DTO to an array. */
    public function toArray(): array
    {
        return get_object_vars($this);
    }
}