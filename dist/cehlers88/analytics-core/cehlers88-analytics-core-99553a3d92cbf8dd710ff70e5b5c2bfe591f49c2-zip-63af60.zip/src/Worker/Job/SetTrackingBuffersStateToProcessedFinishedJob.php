<?php

namespace Cehlers88\AnalyticsCore\Worker\Job;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;

class SetTrackingBuffersStateToProcessedFinishedJob extends AbstractWorkerJob
{
    public function __construct()
    {
        $this->setType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_END);
    }

    public function getDescription(): string
    {
        return 'Set all TrackingBuffers to state PROCESSED_FINISHED';
    }

    /**
     * @param TrackingBuffer $object
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $object->setState(eTrackingBufferState::PROCESSED_FINISHED);
        $object->setHandledAt(new \DateTime());
        return $this;
    }
}