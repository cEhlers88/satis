<?php

namespace Cehlers88\AnalyticsCore\Player;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\Procedure;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Repository\ProcedureRepository;

class ProcedurePlayer
{
    private const MISSING_PROPERTY = '321<>-missing_property-<>123';
    private array $_startProps = [];

    public function __construct(
        private MacroEnvironment    $_macroEnvironment,
        private ProcedureRepository $_procedureRepository
    )
    {
    }

    public function startProcedure(string $name, $props): mixed
    {
        /**
         * @var Procedure $procedure
         */
        $procedure = $this->_procedureRepository->findOneBy(['name' => $name]);
        $propertyBuffer = [];

        if (!$procedure->isEnabled()) {
            return ErrorDTO::create(404, 'Procedure "' . $name . '" is disabled.');
        }

        if (count($procedure->getProperties()) > 0) {
            foreach ($procedure->getProperties() as $property) {
                $propertyBuffer[$property[1]] = isset($property[2]) ? $property[2] : self::MISSING_PROPERTY;
            }
        }

        if (is_array($props) && count($props) > 0) {
            foreach ($props as $key => $value) {
                $propertyBuffer[$key] = $value;
            }
        }

        foreach ($propertyBuffer as $key => $value) {
            if ($value === self::MISSING_PROPERTY) {
                return ErrorDTO::create(404, 'Missing property "' . $key . '" for procedure "' . $name . '".');
            }
        }

        $this->_macroEnvironment->getVariablesStoreProvider()->startArgumentsContext();
        foreach ($propertyBuffer as $key => $value) {
            $this->_macroEnvironment->getVariablesStoreProvider()->setArgument($key, $value);
        }
        $result = $this->_macroEnvironment->getCommandPlayer()->run($procedure->getContent());
        $this->_macroEnvironment->getVariablesStoreProvider()->clearArgumentsContext();

        return $result;
    }
}