<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class ConditionGroupDTO extends DTO
{
    public array $conditionValues = [];
    public eConditionType $type = eConditionType::EQUALS;
    public string $typeName = '===';

    public static function create(array $conditionValues, eConditionType $type = eConditionType::EQUALS): ConditionGroupDTO
    {
        $dto = new self();
        $dto->conditionValues = $conditionValues;
        $dto->type = $type;
        $dto->typeName = eConditionType::toString($type->value());

        return $dto;
    }
}