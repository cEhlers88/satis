<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class AddressDTO extends DTO
{
    public string $name = '';
    public string $street = '';
    public string $zip = '';
    public string $city = '';
    public string $country = '';
    public string $state = '';
    public string $latitude = '';
    public string $longitude = '';
    public string $formattedAddress = '';
    public string $googleMapsUrl = '';
    public string $googleMapsEmbedUrl = '';
    public string $googleMapsEmbedWidth = '';
    public string $googleMapsEmbedHeight = '';
}