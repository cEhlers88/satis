<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class QuickActionDTO extends DTO
{
    public string $name;
    public string $label;
    public string $icon;
    public string $callback;

    public static function create(
        string $label,
        string $callback,
        string $name = '',
        string $icon = ''
    ): QuickActionDTO
    {
        $dto = new self();
        $dto->name = $name;
        $dto->label = $label;
        $dto->icon = $icon;
        $dto->callback = $callback;
        return $dto;
    }
}