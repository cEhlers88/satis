<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

/**
 * Data transfer object representing a notification.
 */
class NotificationDTO extends DTO
{

}