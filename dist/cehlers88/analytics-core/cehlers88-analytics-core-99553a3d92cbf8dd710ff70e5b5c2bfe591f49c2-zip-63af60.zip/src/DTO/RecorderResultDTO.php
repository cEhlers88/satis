<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class RecorderResultDTO extends DTO
{
    public bool $hasError = false;
    public string $message = '';
    public array $data = [];

    private function __construct()
    {
    }

    public static function createError(string $message): RecorderResultDTO
    {
        $result = new RecorderResultDTO();
        $result->hasError = true;
        $result->message = $message;
        return $result;
    }

    public static function createSuccess(array $data, string $message = ''): RecorderResultDTO
    {
        $result = new RecorderResultDTO();
        $result->data = $data;
        $result->message = $message;
        return $result;
    }
}