<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

final class ApiLazyLoadEntityDTO extends DTO
{
    public function __construct(
        public string     $entityClass,
        public string     $parentEntityClass,
        public int|string $parentId,
        public string     $relation,
        public string     $loadAction = 'fetch',
        public string     $namespace = '',
    )
    {
    }

    public static function create(
        string     $entityClass,
        string     $parentEntityClass,
        int|string $parentId,
        string     $relation
    ): self
    {
        return new self(
            entityClass: $entityClass,
            parentEntityClass: $parentEntityClass,
            parentId: $parentId,
            relation: $relation,
        );
    }
}