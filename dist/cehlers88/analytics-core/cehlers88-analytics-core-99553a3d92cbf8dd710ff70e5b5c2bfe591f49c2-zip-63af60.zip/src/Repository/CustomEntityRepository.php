<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectInterface;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * Repository for CustomEntity entities.
 *
 * @extends ServiceEntityRepository<CustomEntity>
 */
class CustomEntityRepository extends ServiceEntityRepository
{
    public function __construct(
        private EntityManagerInterface $_em,
        ManagerRegistry                $registry
    )
    {
        parent::__construct($registry, CustomEntity::class);
    }

    public function save(CustomEntity $customEntity): CustomEntityRepository
    {
        $this->_em->persist($customEntity);
        $this->_em->flush();
        return $this;
    }

    /**
     * @param string $class
     * @return CustomEntity[]
     */
    public function findAllByClass(string $class): array
    {
        return $this->findBy(['className' => $class]);
    }

    public function findAttributeNamesByClass(string $class): array
    {
        $qb = $this->createQueryBuilder('e');
        $qb->select('DISTINCT a.name')
            ->innerJoin('e.attributes', 'a')
            ->andWhere('e.className = :class')
            ->setParameter('class', $class);

        return $qb->getQuery()->getSingleColumnResult();
    }

    /**
     * @param string $class
     * @param string $attributeName
     * @param string $attributeValue
     * @return CustomObjectInterface[]
     */
    public function findByClassAndAttribute(string $class, string $attributeName, string $attributeValue): array
    {
        return $this->createQueryBuilder('e')
            ->select('DISTINCT e')
            ->innerJoin('e.attributes', 'a')
            ->andWhere('e.className = :class')
            ->andWhere('a.name = :name')
            ->andWhere('a.value = :value')
            ->setParameter('class', $class)
            ->setParameter('name', $attributeName)
            ->setParameter('value', $attributeValue)
            ->getQuery()
            ->getResult();
    }
}
