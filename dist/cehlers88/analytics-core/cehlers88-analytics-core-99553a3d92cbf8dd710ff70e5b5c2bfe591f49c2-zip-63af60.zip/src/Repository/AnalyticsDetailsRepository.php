<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Analytics\DTO\Filter\AnalyticsDetailsFilterDTO;
use Cehlers88\AnalyticsCore\Entity\AnalyticsDetails;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<AnalyticsDetails>
 *
 * @method AnalyticsDetails|null find($id, $lockMode = null, $lockVersion = null)
 * @method AnalyticsDetails|null findOneBy(array $criteria, array $orderBy = null)
 * @method AnalyticsDetails[]    findAll()
 * @method AnalyticsDetails[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class AnalyticsDetailsRepository extends AbstractRepository
{
    public function __construct(
        ManagerRegistry                $registry,
        private EntityManagerInterface $_em
    )
    {
        parent::__construct($registry, AnalyticsDetails::class);
    }

    /**
     * @param AnalyticsDetailsFilterDTO $analyticsDetailsFilterDTO
     * @return AnalyticsDetails[]
     */
    public function findByFilterDTO(AnalyticsDetailsFilterDTO $analyticsDetailsFilterDTO): array
    {
        $queryBuilder = $this->createQueryBuilder('ad');
        $hasWhere = false;
        $joinedHeaderTable = false;

        if (!empty($analyticsDetailsFilterDTO->categoryIds)) {
            if (!$joinedHeaderTable) {
                $queryBuilder->join('ad.analyticsHeader', 'ah');
                $joinedHeaderTable = true;
            }
            if ($hasWhere) {
                $queryBuilder->andWhere('ah.categoryId IN (:categoryIds)');
            } else {
                $queryBuilder->where('ah.categoryId IN (:categoryIds)');
                $hasWhere = true;
            }
            $queryBuilder->setParameter('categoryIds', $analyticsDetailsFilterDTO->categoryIds);
        }
        if (!is_null($analyticsDetailsFilterDTO->clientId)) {
            if ($hasWhere) {
                $queryBuilder->andWhere('ad.clientId = :clientId');
            } else {
                $queryBuilder->where('ad.clientId = :clientId');
                $hasWhere = true;
            }
            $queryBuilder->setParameter('clientId', $analyticsDetailsFilterDTO->clientId);
        }
        if (!is_null($analyticsDetailsFilterDTO->fromDate)) {
            if (!$joinedHeaderTable) {
                $queryBuilder->join('ad.analyticsHeader', 'ah');
                $joinedHeaderTable = true;
            }
            if ($hasWhere) {
                $queryBuilder->andWhere('ah.date >= :fromDate');
            } else {
                $queryBuilder->where('ah.date >= :fromDate');
                $hasWhere = true;
            }
            $queryBuilder->setParameter('fromDate', $analyticsDetailsFilterDTO->fromDate);
        }
        if (!is_null($analyticsDetailsFilterDTO->toDate)) {
            if (!$joinedHeaderTable) {
                $queryBuilder->join('ad.analyticsHeader', 'ah');
                $joinedHeaderTable = true;
            }
            if ($hasWhere) {
                $queryBuilder->andWhere('ah.date <= :toDate');
            } else {
                $queryBuilder->where('ah.date <= :toDate');
                $hasWhere = true;
            }
            $queryBuilder->setParameter('toDate', $analyticsDetailsFilterDTO->toDate);
        }
        if (!empty($analyticsDetailsFilterDTO->tags)) {
            if ($hasWhere) {
                $queryBuilder->andWhere('ad.tags IN (:tags)');
            } else {
                $queryBuilder->where('ad.tagId IN (:tags)');
                $hasWhere = true;
            }
            $queryBuilder->setParameter('tags', $analyticsDetailsFilterDTO->tags);
        }

        return $queryBuilder->getQuery()->getResult();
    }

    public function save(AnalyticsDetails $analyticsDetails): AnalyticsDetails
    {
        $this->_em->persist($analyticsDetails);
        $this->_em->flush();
        return $analyticsDetails;
    }
}
