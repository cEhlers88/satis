<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\AnalyticsHeader;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<AnalyticsHeader>
 *
 * @method AnalyticsHeader|null find($id, $lockMode = null, $lockVersion = null)
 * @method AnalyticsHeader|null findOneBy(array $criteria, array $orderBy = null)
 * @method AnalyticsHeader[]    findAll()
 * @method AnalyticsHeader[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class AnalyticsHeaderRepository extends AbstractRepository
{
    public function __construct(
        ManagerRegistry                $registry,
        private EntityManagerInterface $_em
    )
    {
        parent::__construct($registry, AnalyticsHeader::class);
    }

    public function save(AnalyticsHeader $analyticsHeader): AnalyticsHeaderRepository
    {
        $this->_em->persist($analyticsHeader);
        $this->_em->flush();

        return $this;
    }
}
