<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\ServiceEndpoint;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<ServiceEndpoint>
 *
 * @method ServiceEndpoint|null find($id, $lockMode = null, $lockVersion = null)
 * @method ServiceEndpoint|null findOneBy(array $criteria, array $orderBy = null)
 * @method ServiceEndpoint[]    findAll()
 * @method ServiceEndpoint[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ServiceEndpointRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, ServiceEndpoint::class);
    }

    public function add(ServiceEndpoint $serviceEndpoint): ServiceEndpoint
    {
        $this->getEntityManager()->persist($serviceEndpoint);
        $this->getEntityManager()->flush();
        return $serviceEndpoint;
    }

    public function findByApplications(array $applications): array
    {
        return $this->createQueryBuilder('se')
            ->where('se.application IN (:applications)')
            ->setParameter('applications', $applications)
            ->getQuery()
            ->getResult();
    }
}
