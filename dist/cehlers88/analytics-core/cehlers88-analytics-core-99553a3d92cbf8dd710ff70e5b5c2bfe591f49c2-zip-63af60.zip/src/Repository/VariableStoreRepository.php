<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\VariableStore;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<VariableStore>
 *
 * @method VariableStore|null find($id, $lockMode = null, $lockVersion = null)
 * @method VariableStore|null findOneBy(array $criteria, array $orderBy = null)
 * @method VariableStore[]    findAll()
 * @method VariableStore[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class VariableStoreRepository extends ServiceEntityRepository
{
    private bool $_autoFlush = false;

    public function __construct(
        private ApplicationRepository $applicationRepository,
        ManagerRegistry               $registry
    )
    {
        parent::__construct($registry, VariableStore::class);
    }

    public function deleteBy_applicationAndContext(Application $application, eMacroVariableContext $context): VariableStoreRepository
    {
        $this->createQueryBuilder('t')
            ->delete()
            ->where('t.application = :applicationId')
            ->andWhere('t.context = :context')
            ->setParameter('applicationId', $application->getId())
            ->setParameter('context', $context->name)
            ->getQuery()
            ->execute();
        return $this;
    }

    public function getVariableValue(
        string                $variableName,
        eMacroVariableContext $context = eMacroVariableContext::SERVER,
        Application|int       $application = -1,
        bool                  $evaluate = true,
        mixed                 $defaultValue = null
    )
    {
        $applicationId = null;

        $queryBuilder = $this->createQueryBuilder('t')
            ->andWhere('t.context = :context')
            ->andWhere('t.name = :name');

        if (is_numeric($application) && $application !== -1) {
            $queryBuilder->andWhere('t.application = :applicationId');
            $applicationId = $application;
        } else if ($application instanceof Application) {
            $applicationId = $application->getId();
        }


        if (!is_null($applicationId)) {
            $queryBuilder->setParameter('applicationId', $applicationId);
        }

        $queryBuilder
            ->setParameter('context', $context->name)
            ->setParameter('name', $variableName);

        $variableStore = $queryBuilder->getQuery()->getOneOrNullResult();

        if (is_null($variableStore)) {
            return $defaultValue;
        }

        if (!$evaluate) {
            return $variableStore->getValue();
        }

        switch ($variableStore->getValue()[0]) {
            case 'array':
                return json_decode($variableStore->getValue()[1]);
        }
        return $variableStore->getValue()[1];
    }

    public function setVariableValue(
        eMacroVariableContext $context,
        string                $variableName,
        mixed                 $value,
        Application|int       $application = -1
    ): bool
    {
        $changed = false;
        $filter = [
            'context' => $context->name,
            'name' => $variableName
        ];
        if (is_numeric($application) && $application !== -1) {
            $application = $this->applicationRepository->find($application);
        }
        if ($application instanceof Application) {
            $filter['application'] = $application;
        }
        $existingVariable = $this->findOneBy($filter);

        if (!is_array($value)) {
            $value = [
                is_numeric($value) ? 'numeric' : gettype($value),
                $value
            ];
        }

        if ($value[0] === 'numeric') {
            $value[1] = (strpos($value[1], '.') > -1 ? floatval($value[1]) : intval($value[1]));
        }

        if ($existingVariable) {
            $changed = $existingVariable->getValue() !== $value;
            $existingVariable->setValue($value);

            $this->getEntityManager()->persist($existingVariable);
        } else {
            $changed = true;
            $newVariable = new VariableStore();
            if ($application instanceof Application) {
                $newVariable->setApplication($application);
            }
            $newVariable->setContext($context);
            $newVariable->setName($variableName);
            $newVariable->setValue($value);

            $this->getEntityManager()->persist($newVariable);
        }

        if ($this->_autoFlush) {
            $this->flush();
        }

        return $changed;
    }

    public function flush(): static
    {
        $this->getEntityManager()->flush();
        return $this;
    }

    public function findAllConstants(?int $applicationIdFilter = null): array
    {
        $queryBuilder = $this->createQueryBuilder('t')
            ->andWhere('t.context = :context');

        if (is_null($applicationIdFilter)) {
            $queryBuilder
                ->andWhere('t.application IS NULL');
        } else {
            $queryBuilder->andWhere('t.application = :applicationId');
        }

        $queryBuilder
            ->andWhere('t.name LIKE :name')
            ->setParameter('name', 'CONSTANT.%');

        if (is_null($applicationIdFilter)) {
            $queryBuilder->setParameter('context', eMacroVariableContext::SERVER);
        } else {
            $queryBuilder
                ->setParameter('applicationId', $applicationIdFilter)
                ->setParameter('context', eMacroVariableContext::APPLICATION);
        }

        return $queryBuilder
            ->getQuery()
            ->getResult();
    }

    public function findAll_groupByName(): array
    {
        // return all fields grouped by name
        return $this->createQueryBuilder('t')
            ->select('t.name, t.context, COUNT(t.id) as anzahl')
            ->groupBy('t.name, t.context')
            ->getQuery()
            ->getResult();
    }

    public function setAutoFlush(bool $autoFlush): static
    {
        $this->_autoFlush = $autoFlush;
        return $this;
    }
}
