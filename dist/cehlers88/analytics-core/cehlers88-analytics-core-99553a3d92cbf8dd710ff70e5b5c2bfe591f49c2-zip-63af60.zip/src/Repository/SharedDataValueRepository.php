<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\SharedDataValue;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<SharedDataValue>
 *
 * @method SharedDataValue|null find($id, $lockMode = null, $lockVersion = null)
 * @method SharedDataValue|null findOneBy(array $criteria, array $orderBy = null)
 * @method SharedDataValue[]    findAll()
 * @method SharedDataValue[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class SharedDataValueRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, SharedDataValue::class);
    }

    //    /**
    //     * @return SharedDataValue[] Returns an array of SharedDataValue objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('s')
    //            ->andWhere('s.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('s.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?SharedDataValue
    //    {
    //        return $this->createQueryBuilder('s')
    //            ->andWhere('s.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }
}
