<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\SharedData;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<SharedData>
 *
 * @method SharedData|null find($id, $lockMode = null, $lockVersion = null)
 * @method SharedData|null findOneBy(array $criteria, array $orderBy = null)
 * @method SharedData[]    findAll()
 * @method SharedData[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class SharedDataRepository extends ServiceEntityRepository
{
    private bool $autoFlush = false;

    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, SharedData::class);
    }

    public function set(string $name, mixed $value): static
    {
        $sharedData = $this->findOneBy(['name' => $name]);
        if (is_null($sharedData)) {
            $sharedData = new SharedData();
            $sharedData->setName($name);
        }

        $sharedData->setValue($value);
        $this->getEntityManager()->persist($sharedData);
        if ($this->autoFlush) {
            $this->flush();
        }

        return $this;
    }

    public function flush(): static
    {
        $this->getEntityManager()->flush();

        return $this;
    }

    public function setAutoFlush(bool $autoFlush): static
    {
        $this->autoFlush = $autoFlush;
        return $this;
    }
}
