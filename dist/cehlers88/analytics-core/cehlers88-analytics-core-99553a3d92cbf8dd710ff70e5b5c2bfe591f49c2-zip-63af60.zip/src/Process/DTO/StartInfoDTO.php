<?php

namespace Cehlers88\AnalyticsCore\Process\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

/** Data transfer object containing process start information. */
class StartInfoDTO extends DTO
{
    public const KEY_RUNNER = 'runner';
    public const KEY_RUNNER_ARGUMENTS = 'runner_arguments';

    /** @var string */
    public string $runner = '';
    /** @var array<string, mixed> */
    public array $runner_arguments = [];

    /**
     * @param array<string, mixed> $data
     * @return static
     */
    public static function createFromArray(array $data): static
    {
        return self::create(
            $data[self::KEY_RUNNER] ?? '',
            $data[self::KEY_RUNNER_ARGUMENTS] ?? []
        );
    }

    /**
     * @param string $runner
     * @param array<string, mixed> $runnerArguments
     * @return static
     */
    public static function create(string $runner, array $runnerArguments = []): static
    {
        $dto = new static();
        $dto->runner = $runner;
        $dto->runner_arguments = $runnerArguments;

        return $dto;
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return get_object_vars($this);
    }
}