# Validator

The `Cehlers88\AnalyticsCore\Validator` namespace provides standalone validation components that can be used independently of the rest of the library.

## `CommandDefinitionValidator`

Validates whether a given input represents a valid command definition. The validator is constructed with a list of known command names and optional argument metadata — it has no dependency on `CommandFactory` or `CommandRepository`.

### Constructor

```php
use Cehlers88\AnalyticsCore\Validator\CommandDefinitionValidator;

$validator = new CommandDefinitionValidator(
    validCommandNames: ['setVariable', 'getVariable', 'logEvent'],
    allowCommandNameString: true,   // default — plain strings may be treated as command names
    validateArguments: false,       // default — parameter contents are not checked
    commandArgumentsByName: [],     // required when validateArguments is true
);
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `$validCommandNames` | `string[]` | _(required)_ | List of known/registered command names. |
| `$allowCommandNameString` | `bool` | `true` | When `true`, a plain string is checked against the registered command names. When `false`, plain strings are never treated as command names (JSON-encoded definitions are still accepted). |
| `$validateArguments` | `bool` | `false` | When `true`, the provided parameters are verified against the argument metadata supplied in `$commandArgumentsByName`. |
| `$commandArgumentsByName` | `array` | `[]` | Argument metadata keyed by command name. See [Argument metadata format](#argument-metadata-format) below. Required when `$validateArguments` is `true`. |

---

### Accepted input forms

A command definition can be provided as a `string` or an `array`.

#### String inputs

| Input | `allowCommandNameString` | Result | Reason |
|---|---|---|---|
| `'setVariable'` | `true` | ✅ valid | Plain string matches a known command name. |
| `'setVariable'` | `false` | ❌ invalid | Plain command-name strings are disabled. |
| `'"setVariable"'` | `true` | ✅ valid | JSON-encoded command name, decoded to a known command name. |
| `'"setVariable"'` | `false` | ❌ invalid | JSON-decoded result is a plain string, and `allowCommandNameString` is `false`. |
| `'["setVariable",{"var":"x"}]'` | `true`/`false` | ✅ valid | JSON-encoded single command definition — decoded and re-validated. |
| `'[["setVariable",{}],["logEvent",{}]]'` | `true`/`false` | ✅ valid | JSON-encoded list of command definitions — decoded and re-validated. |
| `'["unknownCommand",{}]'` | `true`/`false` | ❌ invalid | Command name is not registered. |
| `'{invalid json}'` | `true`/`false` | ❌ invalid | Not valid JSON. |
| `'some random text'` | `true` | ❌ invalid | Not a known command name and not valid JSON. |
| `''` | `true`/`false` | ❌ invalid | Empty string. |

#### Array inputs — single command definition

A single command definition is an indexed 2-element array `[commandName, params]` where `params` is either an empty array or an associative array with string keys.

| Input | Result | Reason |
|---|---|---|
| `['setVariable', ['var' => 'x']]` | ✅ valid | Known command name with valid associative params. |
| `['logEvent', []]` | ✅ valid | Known command name with empty params. |
| `['unknownCommand', ['foo' => 'bar']]` | ❌ invalid | Command name is not registered. |
| `['setVariable', 'notAnArray']` | ❌ invalid | Second element must be an array. |
| `['setVariable', ['value']]` | ❌ invalid | Params must not be a list (indexed array). |
| `['setVariable', [1 => 'value']]` | ❌ invalid | Params must have string keys. |
| `['setVariable', ['unknownCommand', []]]` | ❌ invalid | Second element is a list — not a valid params array. |
| `[123, ['foo' => 'bar']]` | ❌ invalid | First element must be a string. |
| `['command' => 'setVariable', 'params' => []]` | ❌ invalid | Top-level associative arrays are not a valid form. |

#### Array inputs — list of command definitions

When the input is not a recognized single command definition (2-element `[name, params]` shape), the array is treated as a list where each element must itself be a valid command definition.

| Input | Result | Reason |
|---|---|---|
| `[['setVariable', ['var' => 'x']], ['logEvent', []]]` | ✅ valid | Two valid single definitions. |
| `['setVariable', 'logEvent']` | ✅ valid | Two known command names (`allowCommandNameString: true`). |
| `[['setVariable', []], 'logEvent', 'getVariable']` | ✅ valid | Mixed array form and string form. |
| `['setVariable']` | ✅ valid | Single known command name in a list. |
| `[['setVariable', []], ['unknownCommand', []]]` | ❌ invalid | Second element contains an unknown command. |
| `['unknownCommand']` | ❌ invalid | Unknown command name in a list. |
| `[]` | ❌ invalid | Empty array. |

---

### Argument validation

When `validateArguments: true`, each command's parameters are verified against the metadata provided in `$commandArgumentsByName`. The validator rejects:

- commands not present in `$commandArgumentsByName`,
- parameters that are not listed as `required` or `optional`,
- definitions where a `required` parameter is missing,
- metadata entries with unknown keys (e.g. typos like `'requried'`).

```php
$validator = new CommandDefinitionValidator(
    validCommandNames: ['setVariable', 'logEvent'],
    validateArguments: true,
    commandArgumentsByName: [
        'setVariable' => ['required' => ['var'], 'optional' => ['value']],
        'logEvent'    => ['optional' => ['event']],
    ],
);

$validator->validate(['setVariable', ['var' => 'x']]);               // true  — required arg present
$validator->validate(['setVariable', ['var' => 'x', 'value' => 1]]); // true  — required + optional
$validator->validate(['setVariable', []]);                            // false — 'var' is required
$validator->validate(['setVariable', ['value' => 'x']]);             // false — 'var' is missing
$validator->validate(['setVariable', ['var' => 'x', 'extra' => 1]]); // false — unknown arg
$validator->validate(['logEvent', []]);                               // true  — no required args
$validator->validate('setVariable');                                  // false — plain command-name strings pass no params; required arg missing
```

#### Argument metadata format

Each entry in `$commandArgumentsByName` may be one of:

| Format | Example | Meaning |
|---|---|---|
| Empty array | `[]` | Command takes no arguments. |
| Flat list of strings | `['var', 'value']` | All listed arguments are optional (no required). |
| Associative with `required`/`optional` | `['required' => ['var'], 'optional' => ['value']]` | Explicit required/optional split. |

Any entry containing keys other than `'required'` and `'optional'` is treated as malformed and causes validation to fail for that command.

---

### Basic usage example

```php
use Cehlers88\AnalyticsCore\Validator\CommandDefinitionValidator;

$validator = new CommandDefinitionValidator(['setVariable', 'getVariable', 'logEvent']);

// String inputs
$validator->validate('setVariable');                            // true
$validator->validate('unknownCommand');                         // false
$validator->validate('"setVariable"');                          // true  (JSON-encoded name)
$validator->validate('["setVariable",{"var":"x"}]');            // true  (JSON-encoded definition)

// Array inputs — single definition
$validator->validate(['setVariable', ['var' => 'x']]);          // true
$validator->validate(['setVariable', []]);                      // true
$validator->validate(['unknownCommand', []]);                   // false

// Array inputs — list of definitions
$validator->validate([['setVariable', []], ['logEvent', []]]);  // true
$validator->validate(['setVariable', 'logEvent']);              // true  (string-form list)
$validator->validate([['setVariable', []], ['unknown', []]]);   // false
```
