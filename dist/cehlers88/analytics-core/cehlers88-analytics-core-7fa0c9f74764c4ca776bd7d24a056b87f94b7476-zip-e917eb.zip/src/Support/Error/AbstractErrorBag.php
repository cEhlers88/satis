<?php

namespace Cehlers88\AnalyticsCore\Support\Error;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Support\Logging\VoidLogger;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;

/** Base class for error bag implementations. */
abstract class AbstractErrorBag implements ErrorBagInterface
{
    /**
     * @var ErrorDTO[] $errors
     */
    public array $errors = [];

    protected ?LoggerInterface $_logger = null;

    private bool $_debugMode = false;

    /** Check whether any errors have been recorded. */
    public function hasError(): bool
    {
        return !empty($this->errors);
    }

    /**
     * @param string $message
     * @param int $code
     * @param array $data
     * @return ErrorDTO
     */
    public function setError(string $message, int $code = -1, array $data = []): ErrorDTO
    {
        $result = ErrorDTO::create($code, $message, $data);
        $this->errors[] = $result;

        $this->onError($result);

        return $result;
    }

    public function onError(ErrorDTO $error): void
    {
    }

    public function getErrorsAsString(string $separator = PHP_EOL): string
    {
        $messages = [];
        foreach ($this->errors as $error) {
            $messages[] = $error->message;
        }
        //$messages[] = array_map('strval', $this->errors);

        return implode($separator, $messages);
    }

    /** Enable or disable debug mode. */
    public function enableDebugMode(bool $enable): static
    {
        $this->_debugMode = $enable;
        return $this;
    }

    /**
     * @param string $message
     * @param bool $onlyInDebugMode
     * @return static
     */
    public function logInfo(string $message, bool $onlyInDebugMode = false): static
    {
        if ($onlyInDebugMode && !$this->_debugMode) {
            return $this;
        }

        $this->getLogger()->info($message);
        return $this;
    }

    /** Get the logger instance. */
    public function getLogger(): LoggerInterface
    {
        return $this->_logger ?? new VoidLogger();
    }

    /** Set the logger instance. */
    public function setLogger(LoggerInterface $logger): static
    {
        $this->_logger = $logger;
        return $this;
    }

    /** Get the current debug mode state. */
    public function getDebugMode(): bool
    {
        return $this->_debugMode;
    }

    /**
     * @param string $message
     * @param bool $onlyInDebugMode
     * @return static
     */
    public function logWarning(string $message, bool $onlyInDebugMode = false): static
    {
        if ($onlyInDebugMode && !$this->_debugMode) {
            return $this;
        }

        $this->getLogger()->warning($message);
        return $this;
    }

    /**
     * @param string $message
     * @param bool $onlyInDebugMode
     * @return static
     */
    public function logError(string $message, bool $onlyInDebugMode = false): static
    {
        if ($onlyInDebugMode && !$this->_debugMode) {
            return $this;
        }

        $this->getLogger()->error($message);
        return $this;
    }
}