<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

use Analytics\Abstract\AbstractPropertyHolder;
use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

/** Base class for process result workers. */
abstract class AbstractProcessResultWorker extends AbstractPropertyHolder implements ProcessResultWorkerInterface
{
    /** @var Process */
    protected Process $process;

    /** Set the process entity. */
    public function setProcess(Process $process): static
    {
        $this->process = $process;
        return $this;
    }

    /**
     * Run the result worker for the given process.
     *
     * @param Process $process
     * @param mixed $result
     * @return static
     */
    public function run(Process $process, mixed $result): static
    {
        $this->process = $process;
        $process->addState(eRunningState::ProcessingResult);
        $this->handleResult($result);
        $process
            ->removeState(eRunningState::ProcessingResult)
            ->addState(eRunningState::ResultProcessed);

        return $this;
    }
}