<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Presentation\QuickStatusInfoDTO;

/** View representation of a Worker entity. */
class WorkerView implements ViewInterface
{
    public QuickStatusInfoDTO $quickInfo;
    public string $counters = ''; //todo: remove
    public array $badges = []; // todo: remove
    public array $properties = [];
    public string $stateString = '';
    public string $readableRunInterval = ''; // todo: remove
    public ?float $maxRuntime = null; //todo: remove
    public string $runIntervalHms = ''; //todo: remove
    public array $runChains = [];

    /**
     * WorkerView constructor.
     *
     * @param int $id
     * @param string $name
     * @param bool $enabled
     * @param string $formatedLastRun
     * @param string $formatedNextRun
     * @param int $priority
     * @param eRunningState[] $state
     * @param string $workerClass
     */
    public function __construct(
        public int             $id,
        public string          $name,
        public string          $description,
        public bool            $enabled,
        public string          $formatedLastRun,
        public string          $formatedNextRun,
        public int             $priority,
        public array           $state,
        public string          $workerClass,
        public ApplicationView $application
    )
    {
        $this->quickInfo = new QuickStatusInfoDTO();
        $this->stateString = implode(', ', array_map(fn($e) => $e->name, $this->state));
    }
}