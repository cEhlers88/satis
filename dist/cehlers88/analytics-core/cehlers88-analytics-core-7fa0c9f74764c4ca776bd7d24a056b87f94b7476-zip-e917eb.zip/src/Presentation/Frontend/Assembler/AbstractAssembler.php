<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

/** Base class for assemblers that convert entities to views. */
abstract class AbstractAssembler implements AssemblerInterface
{
    public function many(iterable $entities): array
    {
        $buffer = [];
        foreach ($entities as $entity) {
            $buffer[] = $this->one($entity);
        }
        return $buffer;
    }
}