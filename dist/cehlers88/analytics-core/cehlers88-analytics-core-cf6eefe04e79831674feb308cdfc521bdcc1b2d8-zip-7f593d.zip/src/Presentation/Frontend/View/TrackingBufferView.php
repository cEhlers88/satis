<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

/** View representation of a TrackingBuffer entity. */
class TrackingBufferView implements ViewInterface
{
    public function __construct(
        public int             $id,
        public array           $data,
        public array           $handlerData,
        public \DateTime       $timestamp,
        public \DateTime       $createdAt,
        public \DateTime       $handledAt,
        public int             $stateValue,
        public ApplicationView $application
    )
    {

    }

    public function getDataOverview(int $maxLength = 300): string
    {
        if (isset($this->handlerData['ui_overview'])) {
            return json_encode([
                'message' => substr($this->handlerData['ui_overview']['message'], 0, $maxLength) . '...'
            ]);
        }
        return json_encode($this->data);
    }
}
