<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

/** View representation of a Tag entity. */
class TagView implements ViewInterface
{
    public function __construct(
        public int    $id,
        public string $name,
        public string $color
    )
    {
    }
}
