<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

/** View representation of a RunChain entity. */
class RunChainView implements ViewInterface
{
    public string $stateString = '';

    /**
     * RunChainView constructor.
     *
     * @param int $id
     * @param string $name
     * @param string|null $description
     * @param string $color
     * @param eRunningState[] $status
     * @param int|null $maxRuntime
     */
    public function __construct(
        public int     $id,
        public string  $name,
        public ?string $description,
        public string  $color,
        public array   $status,
        public ?int    $maxRuntime
    )
    {
        $this->stateString = implode(', ', array_map(fn($e) => $e->name, $this->status));
    }
}
