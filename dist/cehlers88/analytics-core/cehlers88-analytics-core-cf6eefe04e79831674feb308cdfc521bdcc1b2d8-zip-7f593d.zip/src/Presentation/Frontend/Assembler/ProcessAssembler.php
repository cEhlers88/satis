<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Service\QuickStatusInfoProvider;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ProcessView;

/** Assembler for converting Process entities to views. */
class ProcessAssembler extends AbstractAssembler
{
    public function one(EntityInterface|Process $entity): ProcessView
    {
        $buffer = new ProcessView(
            id: $entity->getId(),
            name: $entity->getName(),
            resultWorkerName: $entity->getResultWorkerDefinition()?->worker ?? '',
            runnerName: $entity->getStartInfo()?->runner ?? '',
            state: $entity->getState()
        );

        $buffer->quickInfo = (new QuickStatusInfoProvider())->generateByProcess($entity);

        return $buffer;
    }
}