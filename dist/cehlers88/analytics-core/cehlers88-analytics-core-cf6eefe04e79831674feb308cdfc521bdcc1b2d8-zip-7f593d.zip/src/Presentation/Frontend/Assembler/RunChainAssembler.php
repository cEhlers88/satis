<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Entity\RunChain;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\RunChainView;

/** Assembler for converting RunChain entities to views. */
class RunChainAssembler extends AbstractAssembler
{
    public function one(RunChain|EntityInterface $entity): RunChainView
    {
        return new RunChainView(
            id: $entity->getId(),
            name: $entity->getName(),
            description: $entity->getDescription(),
            color: $entity->getColor(),
            status: $entity->getStatus() ?? [],
            maxRuntime: $entity->getMaxRuntime()
        );
    }
}
