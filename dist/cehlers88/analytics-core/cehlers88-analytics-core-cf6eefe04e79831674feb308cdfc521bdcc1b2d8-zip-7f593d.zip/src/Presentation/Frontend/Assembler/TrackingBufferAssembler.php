<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\TrackingBufferView;

/** Assembler for converting Tag entities to views. */
class TrackingBufferAssembler extends AbstractAssembler
{
    public function one(TrackingBuffer|EntityInterface $entity): TrackingBufferView
    {
        return new TrackingBufferView(
            id: $entity->getId(),
            data: $entity->getData(),
            handlerData: $entity->getHandlerData(),
            timestamp: $entity->getTimestamp(),
            createdAt: $entity->getCreatedAt(),
            handledAt: $entity->getHandledAt(),
            stateValue: $entity->getStateValue(),
            application: new ApplicationAssembler()->one($entity->getApplication())
        );
    }
}
