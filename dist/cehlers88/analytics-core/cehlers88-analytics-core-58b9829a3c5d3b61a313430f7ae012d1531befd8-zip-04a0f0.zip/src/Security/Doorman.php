<?php

namespace Cehlers88\AnalyticsCore\Security;

use Cehlers88\AnalyticsCore\DTO\ExtendedRoleDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\Security\MagicRole\MagicRoleInterface;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\Security\Core\User\UserInterface;

class Doorman
{
    private int $httpStatusCode = -1;

    /** @var RoleDTO[]|ExtendedRoleDTO[] $requiredRoles */
    private array $requiredRoles = [];
    private ?UserInterface $user = null;

    /** @var string[] $reasons */
    private array $reasons = [];

    /** @var string[] $messages */
    private array $messages = [];
    private ?string $clientIp = null;

    /**
     * @param MagicRoleInterface[] $magicRoles
     */
    public function __construct(
        private iterable $magicRoles,
        private Security $security,
    )
    {
        $this->user = $this->security->getUser();
    }

    /**
     * @param string[]|RoleDTO[]|ExtendedRoleDTO[] $roles
     */
    public function setRequiredRoles(array $roles): self
    {
        $this->requiredRoles = array_map(fn($tmp) => ($tmp instanceof RoleDTO ? $tmp : RoleDTO::create($tmp)), $roles);
        return $this;
    }

    public function checkPermission(?array $roles = null): bool
    {
        if (is_null($roles)) {
            $roles = $this->requiredRoles;
        }

        if (empty($roles)) {
            $this->messages = ['No roles required'];
            $this->reasons = ['No roles required'];

            return true;
        }

        $roles = array_map(fn($tmp) => ($tmp instanceof RoleDTO ? $tmp : RoleDTO::create($tmp)), $roles);

        $isAllowed = (count($this->_resolveRoles($roles)) === 0);

        if ($isAllowed) {
            $this->httpStatusCode = 200;
        }
        return $isAllowed;
    }

    private function _resolveRoles(?array $unresolved = null): array
    {
        if (is_null($unresolved)) {
            $unresolved = $this->requiredRoles;
        }

        $unresolved = $this->_resolveMagicRoles($unresolved);

        if (!empty($unresolved)) {
            if (!empty($this->user)) {
                $buffer = [];
                foreach ($unresolved as $role) {
                    if (!$this->_userHasRole($role->name)) {
                        $this->reasons[] = 'User does not have role: ' . $role->name;
                        $buffer[] = $role;
                    }
                }
                if (count($buffer) > 0) {
                    $this->httpStatusCode = 403;
                    $this->messages[] = 'User does not have all required roles';
                }
                $unresolved = $buffer;
            }
        }

        return $unresolved;
    }

    /**
     * @return RoleDTO[]|ExtendedRoleDTO[]
     */
    private function _resolveMagicRoles(array $requiredRoles): array
    {
        $buffer = [];

        foreach ($requiredRoles as $role) {
            $resolved = false;
            foreach ($this->magicRoles as $magicRole) {
                if (!$resolved &&
                    $magicRole->canHandle($role->name)) {
                    $magicRole
                        ->setUser($this->user)
                        ->setClientIp($this->clientIp)
                        ->setRoleResolver([$this, 'checkPermission']);

                    $resolved = $magicRole->checkRole($role);
                }
            }

            if ($resolved) continue;

            $buffer[] = $role;
        }

        return $buffer;
    }

    public function setClientIp(string $clientIp): self
    {
        $this->clientIp = $clientIp;
        return $this;
    }

    private function _userHasRole(string $role): bool
    {
        if (empty($this->user)) return false;

        return array_key_exists($role, $this->user->getRoles());
    }

    public function getReasons(): array
    {
        return $this->reasons;
    }

    public function getMessages(): array
    {
        return $this->messages;
    }
}