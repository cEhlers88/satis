<?php

namespace Cehlers88\AnalyticsCore\ENUM;

enum eExternalServiceType: int
{
    case CURL_REQUEST = 1;
    case BASH_COMMAND = 2;
}