<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class GetCustomObjectStatisticsMacro extends AbstractMacro
{
    private const string PROPERTY_NAME_OR_ID = 'nameOrId';

    public function __construct(
        private CustomObjectProvider $_customObjectProvider
    )
    {
    }

    public function init(): GetCustomObjectStatisticsMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME_OR_ID, [
                MacroPropertyDTO::TYPE_INT,
                MacroPropertyDTO::TYPE_STRING
            ], 'Specify the name or id of the custom object'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Retrieve a custom object by name or id.';
    }

    public function getName(): string
    {
        return 'getCustomObjectStatistics';
    }

    protected function run(): ?array
    {
        $nameOrId = $this->getPropertyValue(self::PROPERTY_NAME_OR_ID);

        if (is_numeric($nameOrId)) {
            $result = $this->_customObjectProvider->getCustomObjectById($nameOrId);
        } else {
            $result = $this->_customObjectProvider->getCustomEntitiesBy([
                'name' => $nameOrId
            ])[0] ?? null;
        }

        return $this->_createRunResult($result);
    }
}