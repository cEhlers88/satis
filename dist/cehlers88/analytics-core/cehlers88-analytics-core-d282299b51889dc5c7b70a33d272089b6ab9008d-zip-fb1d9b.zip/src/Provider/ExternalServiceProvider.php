<?php

namespace Cehlers88\AnalyticsCore\Provider;

use Analytics\Interface\ExternalService\IExecutionAdapter;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\ExternalService;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\ExternalServiceRepository;
use Exception;

class ExternalServiceProvider
{
    /**
     * @param IExecutionAdapter[] $executionAdapters
     * @param ExternalServiceRepository $externalServiceRepository
     */
    public function __construct(
        private iterable                  $executionAdapters,
        private ApplicationRepository     $applicationRepository,
        private ExternalServiceRepository $externalServiceRepository,
        private CommandPlayer             $commandPlayer,
        private CommandFactory            $commandFactory,
        private MacroEnvironment          $macroEnvironment
    )
    {
        $this->macroEnvironment->setApplication($this->applicationRepository->findOneBy(['name' => 'System']));
        $this->commandPlayer->setMacroEnvironment($this->macroEnvironment);
    }

    /**
     * @param string $name
     * @return IExecutionAdapter
     * @throws Exception
     */
    public function getExecutionAdapterByName(string $name): IExecutionAdapter
    {
        $externalService = $this->externalServiceRepository->findOneBy(['name' => $name]);
        return $this->getExecutionAdapter($externalService);
    }

    /**
     * @param ExternalService $externalService
     * @return IExecutionAdapter
     * @throws Exception
     */
    public function getExecutionAdapter(ExternalService $externalService): IExecutionAdapter
    {
        foreach ($this->executionAdapters as $executionAdapter) {
            if ($executionAdapter->getType() === $externalService->getType()) {
                return $this->enrichExecutionAdapter($executionAdapter, $externalService);
            }
        }
        throw new Exception('Type could not be found');
    }

    private function enrichExecutionAdapter(IExecutionAdapter $executionAdapter, ExternalService $externalService): IExecutionAdapter
    {
        $initialApplication = $externalService->getDefaultApplication() ?? $this->commandPlayer->getApplication();
        if ($externalService->getDefaultApplication() !== null) {
            $this->commandPlayer->setApplication($externalService->getDefaultApplication());
        }
        foreach ($externalService->getFunctions() as $function) {
            $properties = [];
            foreach ($function->getArguments() as $argument) {
                $property = PropertyDTO::createFromArray($argument);
                /*$this->commandPlayer->getVariablesStoreProvider()->setArgument(
                    $property->name,
                    $property->value
                );*/
                $properties[] = $property;
            }

            $optionsBuffer = [];
            $options = [];

            foreach ([
                         ...$externalService->getOptions(),
                         ...$function->getOptions()
                     ] as $option) {
                if (strtolower(json_encode($option[2])) === '"null"') {
                    continue;
                }

                $optionsBuffer[$option[1]] = $option;
            }

            foreach ($optionsBuffer as $option) {
                $option[2] = $this->commandPlayer->run($option[2]);
                $options[] = $option;
            }

            $executionAdapter->registerFunction($function->getName(), $properties, $this->commandPlayer->run($options));
        }

        foreach ($externalService->getEntries() as $entry) {
            $executionAdapter->registerEntry($entry->getName(), $entry->getAllowedMethods(), $entry->getOptions());
        }

        $this->commandPlayer->setApplication($initialApplication);
        return $executionAdapter;
    }

    public function getCommandPlayer(): CommandPlayer
    {
        return $this->commandPlayer;
    }
}