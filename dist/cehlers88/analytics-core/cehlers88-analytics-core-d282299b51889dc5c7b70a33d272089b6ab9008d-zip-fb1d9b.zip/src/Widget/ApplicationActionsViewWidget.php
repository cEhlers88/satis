<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\Entity\SystemLog;
use Analytics\Repository\SystemLogRepository;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionClauseDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;

class ApplicationActionsViewWidget extends AbstractWidget
{
    public function __construct()
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.applicationActionsView';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]]
        ];
    }


    public function getTemplateName(): string
    {
        return 'applicationActionsView';
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'filterType',
                value: null,
                type: 'string',
                label: 'View type',
                description: 'Specify the view type (e.g. \'single\', \'multi\', \'or \'other\') to view the data in the dashboard. ',
                ui: [
                    'options' => [
                        'showAll' => 'No Filter',
                        'filterApplication' => 'Filter by application',
                    ],
                ]
            ),
            PropertyDTO::create(
                name: 'application',
                value: '',
                type: 'string',
                isOptional: true,
                conditions: [
                    PropertyConditionDTO::when('filterType', 'showAll')->then([
                        PropertyConditionDTO::EFFECT_VISIBLE => false,
                    ]),
                    PropertyConditionDTO::whenAll([
                        PropertyConditionClauseDTO::create('viewType', 'filterApplication'),
                    ])->then([
                        PropertyConditionDTO::EFFECT_LABEL => 'Application ID',
                        PropertyConditionDTO::EFFECT_DESCRIPTION => 'Specify the ID of the Application to view the data in the dashboard.'
                    ]),
                ]
            )
        ];
    }

    public function enrichProperties(array $properties): array
    {
        return $properties;
    }
}