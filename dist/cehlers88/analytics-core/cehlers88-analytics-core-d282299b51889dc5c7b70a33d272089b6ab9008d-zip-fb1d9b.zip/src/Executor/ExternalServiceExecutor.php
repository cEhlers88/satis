<?php


namespace Cehlers88\AnalyticsCore\Executor;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Provider\ExternalServiceProvider;
use Cehlers88\AnalyticsCore\Repository\ExternalServiceFunctionRepository;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerProvider;

class ExternalServiceExecutor extends AbstractExecutor
{
    public const string KEY_SERVICE_NAME = 'serviceName';
    public const string KEY_ENTRY_NAME = 'entryName';
    public const string KEY_FUNCTION_NAME = 'functionName';
    public const string KEY_ARGUMENTS = 'arguments';
    public const string KEY_OPTIONS = 'options';
    public const string KEY_LOGGER = 'logger';

    public function __construct(
        private ExternalServiceProvider           $externalServiceProvider,
        private ExternalServiceFunctionRepository $externalServiceFunctionRepository,
        private LoggerProvider                    $loggerProvider
    )
    {
        $this
            ->addProperty(PropertyDTO::create(self::KEY_SERVICE_NAME, null))
            ->addProperty(PropertyDTO::create(self::KEY_ARGUMENTS, null))
            ->addProperty(PropertyDTO::create(self::KEY_OPTIONS, null))
            ->addProperty(PropertyDTO::create(self::KEY_FUNCTION_NAME, null, 'string', true))
            ->addProperty(PropertyDTO::create(self::KEY_ENTRY_NAME, null, 'string', true))
            ->addProperty(PropertyDTO::create(self::KEY_LOGGER, null, 'array', true));
    }

    public function isValid(): bool
    {
        return parent::isValid()
            && $this->getPropertyValue(self::KEY_SERVICE_NAME) !== null
            && $this->getPropertyValue(self::KEY_FUNCTION_NAME) !== null;
    }

    public function isRunning(): bool
    {
        return false;
    }

    public function wantsToReRun(): bool
    {
        return false;
    }

    protected function execute(): void
    {
        echo "start";
        $loggerData = $this->getPropertyValue(self::KEY_LOGGER);
        if (is_array($loggerData)) {
            $logger = $this->_buildLogger($loggerData);
            if ($logger !== null) {
                $this->setLogger($logger);
            }
        }

        $arguments = $this->getPropertyValue(self::KEY_ARGUMENTS, []);
        $optionOverrides = $this->getPropertyValue(self::KEY_OPTIONS, []);
        $commandPlayer = $this->externalServiceProvider->getCommandPlayer();

        $variableStoreProvider = $commandPlayer->getVariablesStoreProvider();

        foreach ($arguments as $key => $value) {
            $variableStoreProvider->setArgument($key, $value);
        }

        try {
            $adapter = $this->externalServiceProvider->getExecutionAdapterByName(
                $this->getPropertyValue(self::KEY_SERVICE_NAME)
            );
        } catch (\Exception $e) {
            $this->setError($e->getMessage());
            $this->lastResult = $e;
            return;
        }

        foreach ($optionOverrides as $key => $value) {
            $optionOverrides[$key] = $commandPlayer->run($value);
        }
        $this->logInfo(json_encode([
            'function' => $this->getPropertyValue(self::KEY_FUNCTION_NAME),
            'args' => $arguments,
            'options' => $optionOverrides,
        ]));

        $this->lastResult = $adapter->callFunction(
            $this->getPropertyValue(self::KEY_FUNCTION_NAME),
            $arguments,
            $optionOverrides
        );
    }

    /**
     * @param array<string, mixed> $loggerData
     */
    private function _buildLogger(array $loggerData): ?LoggerInterface
    {
        if (!isset($loggerData['loggerClass']) || !is_string($loggerData['loggerClass'])) {
            return null;
        }

        $loggerClass = $loggerData['loggerClass'];
        $knownClasses = array_column($this->loggerProvider->getLoggerDefinitions(), 'class');

        if (!in_array($loggerClass, $knownClasses, true) || !class_exists($loggerClass)) {
            return null;
        }

        $logger = $this->loggerProvider->getLoggerByName($loggerClass);

        if (!($logger instanceof LoggerInterface)) {
            return null;
        }

        $properties = $loggerData['properties'] ?? [];
        if (is_array($properties)) {
            foreach ($properties as $name => $value) {
                if (!is_string($name) || $name === '') {
                    continue;
                }
                try {
                    $logger->setPropertyValue($name, $value);
                } catch (\InvalidArgumentException) {
                    // Property doesn't exist on this logger; skip it
                }
            }
        }

        return $logger;
    }
}