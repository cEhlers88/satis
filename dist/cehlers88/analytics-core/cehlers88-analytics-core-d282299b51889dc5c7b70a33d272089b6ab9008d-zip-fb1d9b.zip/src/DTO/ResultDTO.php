<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class ResultDTO extends DTO
{
    /** @var ErrorDTO[] $errors */
    public mixed $errors = [];

    public bool $isValid = true;

    public string $message = '';

    public mixed $data = [];

    public int $statusCode = 200;

    public static function createError(
        string $message,
        int    $statusCode = 500,
        mixed  $errors = [],
        mixed  $data = []
    ): static
    {
        $dto = new self();

        $dto->message = $message;
        $dto->statusCode = $statusCode;
        $dto->errors = $errors;
        $dto->data = $data;
        $dto->isValid = false;

        return $dto;
    }

    public static function createSuccess(
        string $message,
        mixed  $data = [],
        int    $statusCode = 200,
        bool   $isValid = true
    ): static
    {
        $dto = new self();

        $dto->message = $message;
        $dto->statusCode = $statusCode;
        $dto->data = $data;
        $dto->isValid = $isValid;

        return $dto;
    }

    public function hasError(): bool
    {
        return !empty($this->errors);
    }
}