<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\ExternalServiceFunctionRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ExternalServiceFunctionRepository::class)]
class ExternalServiceFunction implements EntityInterface
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column]
    private array $arguments = [];

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $description = null;

    #[ORM\Column]
    private array $options = [];

    #[ORM\Column]
    private array $state = [];

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $periodeStartedAt = null;

    #[ORM\Column(length: 20)]
    private ?string $periodeInterval = null;

    #[ORM\Column]
    private ?\DateTimeImmutable $createdAt = null;

    #[ORM\Column]
    private ?\DateTimeImmutable $modifiedAt = null;

    #[ORM\ManyToOne(inversedBy: 'functions')]
    #[ORM\JoinColumn(nullable: false)]
    private ?ExternalService $externalService = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getArguments(): array
    {
        return $this->arguments;
    }

    public function setArguments(array $arguments): static
    {
        $this->arguments = $arguments;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getOptions(): array
    {
        return $this->options;
    }

    public function setOptions(array $options): static
    {
        $this->options = $options;

        return $this;
    }

    public function getState(): array
    {
        return $this->state;
    }

    public function setState(array $state): static
    {
        $this->state = $state;

        return $this;
    }

    public function getPeriodeStartedAt(): ?\DateTimeImmutable
    {
        return $this->periodeStartedAt;
    }

    public function setPeriodeStartedAt(?\DateTimeImmutable $periodeStartedAt): static
    {
        $this->periodeStartedAt = $periodeStartedAt;

        return $this;
    }

    public function getPeriodeInterval(): ?string
    {
        return $this->periodeInterval;
    }

    public function setPeriodeInterval(string $periodeInterval): static
    {
        $this->periodeInterval = $periodeInterval;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeImmutable
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeImmutable $createdAt): static
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getModifiedAt(): ?\DateTimeImmutable
    {
        return $this->modifiedAt;
    }

    public function setModifiedAt(\DateTimeImmutable $modifiedAt): static
    {
        $this->modifiedAt = $modifiedAt;

        return $this;
    }

    public function getExternalService(): ?ExternalService
    {
        return $this->externalService;
    }

    public function setExternalService(?ExternalService $externalService): static
    {
        $this->externalService = $externalService;

        return $this;
    }
}
