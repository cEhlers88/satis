<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\ENUM\eExternalServiceType;
use Cehlers88\AnalyticsCore\Repository\ExternalServiceRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ExternalServiceRepository::class)]
class ExternalService extends AbstractTaggedEntity
{
    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column]
    private ?int $type = null;

    #[ORM\Column]
    private array $options = [];

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $description = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $lastRunAt = null;

    /**
     * @var Collection<int, ExternalServiceFunction>
     */
    #[ORM\OneToMany(targetEntity: ExternalServiceFunction::class, mappedBy: 'externalService')]
    private Collection $functions;

    /**
     * @var Collection<int, ExternalServiceEntry>
     */
    #[ORM\OneToMany(targetEntity: ExternalServiceEntry::class, mappedBy: 'externalService', orphanRemoval: true)]
    private Collection $entries;

    #[ORM\ManyToOne]
    private ?Application $defaultApplication = null;

    public function __construct()
    {
        parent::__construct();
        $this->functions = new ArrayCollection();
        $this->entries = new ArrayCollection();
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getType(): ?eExternalServiceType
    {
        return eExternalServiceType::from($this->type);
    }

    public function setType(eExternalServiceType $type): static
    {
        $this->type = $type->value;
        return $this;
    }

    public function getOptions(): array
    {
        return $this->options;
    }

    public function setOptions(array $options): static
    {
        $this->options = $options;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getLastRunAt(): ?\DateTimeImmutable
    {
        return $this->lastRunAt;
    }

    public function setLastRunAt(?\DateTimeImmutable $lastRunAt): static
    {
        $this->lastRunAt = $lastRunAt;

        return $this;
    }

    /**
     * @return Collection<int, ExternalServiceFunction>
     */
    public function getFunctions(): Collection
    {
        return $this->functions;
    }

    public function addFunction(ExternalServiceFunction $function): static
    {
        if (!$this->functions->contains($function)) {
            $this->functions->add($function);
            $function->setExternalService($this);
        }

        return $this;
    }

    public function removeFunction(ExternalServiceFunction $function): static
    {
        if ($this->functions->removeElement($function)) {
            // set the owning side to null (unless already changed)
            if ($function->getExternalService() === $this) {
                $function->setExternalService(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, ExternalServiceEntry>
     */
    public function getEntries(): Collection
    {
        return $this->entries;
    }

    public function addEntry(ExternalServiceEntry $entry): static
    {
        if (!$this->entries->contains($entry)) {
            $this->entries->add($entry);
            $entry->setExternalService($this);
        }

        return $this;
    }

    public function removeEntry(ExternalServiceEntry $entry): static
    {
        if ($this->entries->removeElement($entry)) {
            // set the owning side to null (unless already changed)
            if ($entry->getExternalService() === $this) {
                $entry->setExternalService(null);
            }
        }

        return $this;
    }

    public function getDefaultApplication(): ?Application
    {
        return $this->defaultApplication;
    }

    public function setDefaultApplication(?Application $defaultApplication): static
    {
        $this->defaultApplication = $defaultApplication;

        return $this;
    }
}
