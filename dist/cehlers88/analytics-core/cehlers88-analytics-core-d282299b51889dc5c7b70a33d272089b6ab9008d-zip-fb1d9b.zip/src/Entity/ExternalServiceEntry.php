<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\ExternalServiceEntryRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ExternalServiceEntryRepository::class)]
class ExternalServiceEntry extends AbstractEndpointEntity
{

    #[ORM\ManyToOne(inversedBy: 'entries')]
    #[ORM\JoinColumn(nullable: false)]
    private ?ExternalService $externalService = null;

    public function getExternalService(): ?ExternalService
    {
        return $this->externalService;
    }

    public function setExternalService(?ExternalService $externalService): static
    {
        $this->externalService = $externalService;

        return $this;
    }
}
