# Dashboard Tools

A tool is a tile on the `/dashboard/tools` page of the host application that opens a dialog. The
bundle only ships the templates of a tool; the host application lists it and renders it — see
`DashboardController::tools()` there.

## Templates of a tool

Every tool consists of up to three templates below `templates/tool/`, addressed by the host as
`tool/<file>`:

| Template | Purpose |
|---|---|
| `<name>.html.twig` | the content of the dialog, including its `<style>` |
| `teaser/<name>.html.twig` | SVG illustration used as the background of the tile (optional) |
| `script/<name>.js.twig` | the behaviour, inlined into a `<script>` of the tools page (optional) |

All three receive `toolName`, which is the name the host registered. Element ids are prefixed with
it (`id="{{ toolName ~ '-field--x' }}"`), so several tools can live on the same page. A tool that
needs server-side data gets it from the `templateData` of its registration.

The host application registers it like this:

```php
[
    'description' => 'Enter commands and debug them right away',
    'name' => 'commandConsole',
    'title' => 'Command Console',
    'teaser' => 'teaser/commandConsole.html.twig',
    'template' => 'commandConsole.html.twig',
    'scripts' => ['script/commandConsole.js.twig'],
    'styles' => [],
    'templateData' => [],
]
```

## Command Console

`templates/tool/commandConsole.html.twig` lets commands be entered and debugged without storing a
procedure first. The tool itself runs nothing: it only prepares a command definition — an empty one
or the one pasted into its field — and hands it to the debugger of the host application:

```js
window.application.execDebugger({
    runType: 'commands',
    editable: true,
    commands: [['log', {message: 'hello'}]],
});
```

`editable` makes the commands run type of the debugger an editor instead of a read only preview, so
the commands are entered, run, corrected and run again inside the debugger. Breakpoints, single
steps, the instruction tree and the result view are the ones of that debugger — there is deliberately
no second thing that runs commands. Without `editable` the debugger behaves exactly as before, which
is how the procedure overview and `<exec-viewer>` open it.

A definition is a list of commands, each of them the command name and its properties, which is what
`CommandDefinitionValidator` accepts and `CommandFactory::evalDefinitionArray()` evaluates:

```json
[["setVar", {"name": "x", "value": 5}], ["log", {"message": "done"}]]
```

The field content and the definitions last handed over are kept in `localStorage` under
`analytics.tool.commandConsole.state`, so the tool comes back the way it was left.

## JSON Workbench

`templates/tool/jsonWorkbench.html.twig` is an editor for json documents. It is built around
`<json-viewer>` in its editable mode — that element already brings the editing, the shared clipboard
and the keyboard flow — and adds the way in, the way out and a few operations on the whole document.
Everything happens in the browser; the tool has no service endpoint behind it.

```php
[
    'description' => 'Edit json, feed it in as text or base64 and generate it back',
    'name' => 'jsonWorkbench',
    'title' => 'JSON Workbench',
    'teaser' => 'teaser/jsonWorkbench.html.twig',
    'template' => 'jsonWorkbench.html.twig',
    'scripts' => ['script/jsonWorkbench.js.twig'],
    'styles' => [],
    'templateData' => [],
]
```

### Feeding it

The field takes a json string; with the `Base64` option the text is decoded first, which is what an
encoded payload out of a log or a request needs. *Load* replaces what the editor holds, *Merge*
merges into it — objects key by key, arrays appended, everything else replaced. A parse error names
the position the browser reports, and a text that looks like base64 says so instead of only failing.
*Take over from the editor* writes the generated string back into the field.

### The editor

`<json-viewer readonly="false" data-clipboard="true">`. Values and keys are edited in place, entries
are added and removed, and the clipboard of the viewer carries whole documents or single attributes
between viewers — also the ones on other pages, since it lives in the local storage.

Four operations work on the whole document, each of them undoable with *Undo*:

| Operation | What it does |
|---|---|
| Sort keys | sorts the keys of every object alphabetically, recursively |
| Remove empty | drops `null`, `""`, `[]` and `{}`, recursively |
| Flatten | turns the structure into one level of dotted paths (`rows.0.id`) |
| Unflatten | builds it back up; a path step that is a number becomes an array |

*Extract* keeps only what sits at the given path — `filters.tags[0]` and `filters.tags.0` are both
read. Flatten and unflatten are each other's inverse, empty containers included.

### Generating

The generated json follows every change of the editor, there is nothing to press. Indent is 2, 4,
tabs or one line; the encoding is plain, base64 (of the utf-8 bytes) or a json string literal — the
last one is what a json that has to sit inside another json needs. *Copy* uses the clipboard of the
browser, *Download* hands the text over as a file.

The input, the options and the document itself are kept in `localStorage` under
`analytics.tool.jsonWorkbench.state`, so the tool comes back the way it was left. A document larger
than 200 000 characters is left behind rather than taking the remembered options with it.
