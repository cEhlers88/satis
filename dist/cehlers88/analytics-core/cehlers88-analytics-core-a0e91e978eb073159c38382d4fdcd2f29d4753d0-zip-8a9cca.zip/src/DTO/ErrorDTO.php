<?php

namespace Cehlers88\AnalyticsCore\DTO;

class ErrorDTO extends DTO
{
    public int $number = 0;
    public string $message = "";
    public mixed $data = null;

    public static function create(int $errNumber, string $errMessage = "", mixed $data = null): ErrorDTO
    {
        $dto = new self();
        $dto->number = $errNumber;
        $dto->message = $errMessage;
        $dto->data = $data;

        return $dto;
    }

    public function toArray(): array
    {
        return [
            // 'hasError' => ($this->number > 0), // Blödsinn ! Checken ob irgendwo verwendet wird
            'number' => $this->number,
            'error' => $this->message,
            'data' => $this->data
        ];
    }

    public function __toString(): string
    {
        return $this->number > 0 ? sprintf("#%d: %s", $this->number, $this->message) : '';
    }
}