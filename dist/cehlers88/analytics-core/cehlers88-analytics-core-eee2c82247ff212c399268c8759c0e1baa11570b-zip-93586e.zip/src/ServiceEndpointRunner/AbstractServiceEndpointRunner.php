<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 06.09.2024
 * Time: 03:25
 */

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\DTO\ValidationResultDTO;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Security\Doorman;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Symfony\Component\HttpFoundation\Request;

abstract class AbstractServiceEndpointRunner implements ServiceEndpointRunnerInterface
{
    protected bool $_hasError = false;
    protected ?string $errorMessage = null;
    protected ?User $user = null;
    protected ?Doorman $doorman = null;

    private array $rawEndpoints = [];

    /** @var EndpointDefinitionDTO[]|null */
    private ?array $endpointDefinitions = null;

    public function canHandle(string $endpoint, Request $request): bool
    {
        foreach ($this->getEndpointDefinitions() as $endpointDefinition) {
            if (
                ($endpointDefinition->name === $endpoint || in_array($endpoint, $endpointDefinition->aliases))
                && in_array($request->getMethod(), $endpointDefinition->methods)
            ) {
                return true;
            }
        }

        return false;
    }

    final public function getEndpointDefinitions(): array
    {
        if (is_null($this->endpointDefinitions)) {
            $this->_generateEndpointDefinitions();
        }
        return $this->endpointDefinitions;
    }

    private function _generateEndpointDefinitions(): void
    {
        $this->endpointDefinitions = [];

        $endpoints = $this->getEndpoints();
        if (is_string($endpoints)) {
            $endpoints = [$endpoints];
        }

        $namePrefix = empty($this->getBundleName()) ? '' : $this->getBundleName() . '.';

        foreach ($endpoints as $endpoint) {
            if (is_string($endpoint)) {
                $dto = new EndpointDefinitionDTO();
                $dto->name = $endpoint;
                $dto->methods = ['GET', 'POST'];
            } else if ($endpoint instanceof EndpointDefinitionDTO) {
                $dto = $endpoint;
            } else {
                throw new \InvalidArgumentException('Invalid endpoint definition');
            }

            $dto->name = $namePrefix . $dto->name;

            $this->endpointDefinitions[] = $dto;
        }
    }

    public function getEndpoints(): mixed
    {
        $namespaceSplit = explode('\\', static::class);
        $selfName = end($namespaceSplit);

        return empty($this->rawEndpoints) ? [$selfName] : $this->rawEndpoints;
    }

    public function getBundleName(): string
    {
        return 'AnalyticsCore';
    }

    public function runEndpoint(string $endpointName, Request $request): ServiceEndpointRunnerResultDTO
    {
        $endpointDefinition = $this->getEndpointDefinition($endpointName, $request->getMethod());
        $permissionInfo = $this->checkUserIsAllowedToRunEndpoint([
            ...$this->getRequiredRoles(),
            ...$endpointDefinition->requiredRoles ?? []
        ]);

        if (!$permissionInfo['isAllowed']) {
            $errorMessage = 'Permission denied';
            if (!empty($permissionInfo['message'])) {
                $errorMessage .= ': ' . $permissionInfo['message'];
            }

            $this->setError($errorMessage);
            return ServiceEndpointRunnerResultDTO::createError($errorMessage, 401);
        }

        $validationResult = $this->validate($endpointName, $request);
        if (!$validationResult->isValid) {
            return ServiceEndpointRunnerResultDTO::createError(
                'Invalid' . (!empty($validationResult->message) ? ': ' . $validationResult->message : '')
            );
        }

        try {
            $runnerResult = $this->handleRequest($endpointName, $request);
            return $runnerResult;
        } catch (\Exception $e) {
            $this->setError($e->getMessage());
        }

        return ServiceEndpointRunnerResultDTO::createError('Internal Server Error', 500);
    }

    private function getEndpointDefinition(string $nameOrAlias, string $method): ?EndpointDefinitionDTO
    {
        foreach ($this->getEndpointDefinitions() as $endpointDefinition) {
            if ($endpointDefinition->name === $nameOrAlias || in_array($nameOrAlias, $endpointDefinition->aliases)) {
                if (in_array($method, $endpointDefinition->methods)) {
                    return $endpointDefinition;
                }
            }
        }
        return null;
    }

    private function checkUserIsAllowedToRunEndpoint(array $requiredRoles): array
    {
        $resultInfo = [
            //'isAllowed' => false,
            'message' => '',
            'reason' => ''
        ];

        if (count($requiredRoles) === 0) {
            $resultInfo['isAllowed'] = true;
            return $resultInfo;
        }

        $resultInfo['isAllowed'] = $this->doorman->checkPermission($requiredRoles);
        $resultInfo['message'] = implode(', ', $this->doorman->getMessages());
        $resultInfo['reason'] = implode(', ', $this->doorman->getReasons());

        return $resultInfo;
    }

    public function getRequiredRoles(): array
    {
        return [
            RoleDTO::create('AUTHENTICATED_USER')
        ];
    }

    public function setError(?string $errorMessage = null): AbstractServiceEndpointRunner
    {
        $this->_hasError = !is_null($errorMessage);
        $this->errorMessage = $errorMessage;
        return $this;
    }

    public function validate(string $endpointName, Request $request): ValidationResultDTO
    {
        $requestData = $request->isMethod('GET')
            ? $request->query->all()
            : ($request->getContent() !== '' ? $request->toArray() : $request->request->all());

        foreach ($this->getEndpointDefinitions() as $endpointDefinition) {
            if ($endpointDefinition->name === $endpointName || in_array($endpointName, $endpointDefinition->aliases)) {
                foreach ($endpointDefinition->parameters as $parameter) {
                    if ($parameter->isOptional) continue;
                    if (!array_key_exists($parameter->name, $requestData)) return ValidationResultDTO::create(false, 'Missing parameter \'' . $parameter->name . '\'');
                }
                return ValidationResultDTO::create(true);
            }
        }
        return ValidationResultDTO::create(false, 'Endpoint not found');
    }

    public function handleRequest(string $endpointName, Request $request): ServiceEndpointRunnerResultDTO
    {
        $requestData = $request->isMethod('GET')
            ? $request->query->all()
            : ($request->getContent() !== '' ? $request->toArray() : $request->request->all());

        foreach ($this->getEndpointDefinitions() as $endpointDefinition) {
            if (
                ($endpointDefinition->name === $endpointName ||
                    in_array($endpointName, $endpointDefinition->aliases))
                &&
                in_array($request->getMethod(), $endpointDefinition->methods)
            ) {
                return call_user_func($endpointDefinition->handler, $requestData);
            }
        }
        return ServiceEndpointRunnerResultDTO::createError('Not implemented');
    }

    public function setDoorman(Doorman $doorman): ServiceEndpointRunnerInterface
    {
        $this->doorman = $doorman;
        $this->setUser($doorman->getUser());
        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): AbstractServiceEndpointRunner
    {
        $this->user = $user;
        return $this;
    }

    public function getDescription(string $endpointName, array $methods): string
    {
        foreach ($this->getEndpointDefinitions() as $endpointDefinition) {
            if ($endpointDefinition->name === $endpointName) {
                foreach ($methods as $method) {
                    if (in_array($method, $endpointDefinition->methods)) {
                        return $endpointDefinition->description;
                    }
                }
            }
        }
        return '';
    }

    public function getErrorMessage(): ?string
    {
        return $this->errorMessage;
    }

    public function hasError(): bool
    {
        return $this->_hasError;
    }

    protected function registerEndpoint(EndpointDefinitionDTO $endpointDefinition): AbstractServiceEndpointRunner
    {
        $this->rawEndpoints[] = $endpointDefinition;
        return $this;
    }
}