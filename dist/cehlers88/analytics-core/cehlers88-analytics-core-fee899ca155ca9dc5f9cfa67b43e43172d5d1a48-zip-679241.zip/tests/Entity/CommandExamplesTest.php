<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Entity;

use Cehlers88\AnalyticsCore\Entity\Command;
use PHPUnit\Framework\TestCase;

class CommandExamplesTest extends TestCase
{
    public function test_a_command_without_examples_has_an_empty_list(): void
    {
        $this->assertSame([], (new Command())->getExamples());
        $this->assertSame([], (new Command())->setExamples([])->getExamples());
    }

    public function test_examples_keep_a_result_of_null(): void
    {
        $examples = [['title' => 'Nichts', 'description' => '', 'commands' => [['get_var', ['name' => 'x']]], 'result' => null]];

        $stored = (new Command())->setExamples($examples)->getExamples();

        $this->assertSame($examples, $stored);
        $this->assertArrayHasKey('result', $stored[0]);
    }
}
