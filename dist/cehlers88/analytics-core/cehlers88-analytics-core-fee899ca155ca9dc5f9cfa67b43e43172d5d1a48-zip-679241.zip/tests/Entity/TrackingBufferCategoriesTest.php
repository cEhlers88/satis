<?php

namespace Cehlers88\AnalyticsCore\Tests\Entity;

use Cehlers88\AnalyticsCore\Entity\Category;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Doctrine\Common\Collections\ArrayCollection;
use PHPUnit\Framework\TestCase;

class TrackingBufferCategoriesTest extends TestCase
{
    protected function setUp(): void
    {
        if (!class_exists(ArrayCollection::class)) {
            $this->markTestSkipped('doctrine/collections is not installed');
        }
    }

    private function category(string $name): Category
    {
        return (new Category())->setName($name);
    }

    public function testACategoryIsAssignedOnlyOnce(): void
    {
        $food = $this->category('Lebensmittel');
        $trackingBuffer = (new TrackingBuffer())->addCategory($food)->addCategory($food);

        $this->assertSame([$food], $trackingBuffer->getCategories()->toArray());
    }

    public function testSetCategoriesReplacesTheAssignedOnes(): void
    {
        $food = $this->category('Lebensmittel');
        $family = $this->category('Familie');
        $car = $this->category('Auto');
        $trackingBuffer = (new TrackingBuffer())->addCategory($food)->addCategory($family);

        $trackingBuffer->setCategories([$family, $car]);

        $this->assertSame([$family, $car], array_values($trackingBuffer->getCategories()->toArray()));
    }

    public function testSetCategoriesWithNothingRemovesAll(): void
    {
        $trackingBuffer = (new TrackingBuffer())->addCategory($this->category('Lebensmittel'));

        $trackingBuffer->setCategories([]);

        $this->assertCount(0, $trackingBuffer->getCategories());
    }
}
