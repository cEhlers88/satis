<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Entity;

use Cehlers88\AnalyticsCore\Entity\ApplicationAction;
use Doctrine\Common\Collections\ArrayCollection;
use PHPUnit\Framework\TestCase;

class ApplicationActionReasonTest extends TestCase
{
    protected function setUp(): void
    {
        if (!class_exists(ArrayCollection::class)) {
            $this->markTestSkipped('doctrine/collections is not installed');
        }
    }

    public function testANewActionHasAnEmptyReason(): void
    {
        $this->assertSame('', (new ApplicationAction())->getReason());
    }

    public function testNoReasonIsStoredAsAnEmptyOne(): void
    {
        $action = (new ApplicationAction())->setReason('vacation');

        $this->assertSame('', $action->setReason(null)->getReason());
    }

    public function testTheReasonIsStoredWithoutSurroundingWhitespace(): void
    {
        $this->assertSame('away for two weeks', (new ApplicationAction())->setReason("  away for two weeks\n")->getReason());
    }
}
