<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Entity;

use Cehlers88\AnalyticsCore\Entity\Worker;
use Doctrine\Common\Collections\ArrayCollection;
use PHPUnit\Framework\TestCase;

/**
 * Every property of a worker is stored once - setPropertyValue() used to append
 * a new entry on every save.
 */
class WorkerPropertiesTest extends TestCase
{
    protected function setUp(): void
    {
        if (!class_exists(ArrayCollection::class)) {
            $this->markTestSkipped('doctrine/collections is not installed');
        }
    }

    public function testSettingAValueTwiceKeepsOneEntry(): void
    {
        $worker = new Worker()
            ->setPropertyValue('limit', '5')
            ->setPropertyValue('limit', 10);

        self::assertSame([['integer', 'limit', 10]], $worker->getProperties());
        self::assertSame(10, $worker->getProperty('limit'));
    }

    public function testSetPropertyUpdatesTheExistingEntry(): void
    {
        $worker = new Worker()->setProperties([['integer', 'allowed_retries', 3]]);

        $worker->setProperty('allowed_retries', 5);

        self::assertSame([['integer', 'allowed_retries', 5]], $worker->getProperties());
    }

    public function testOtherPropertiesKeepTheirPlace(): void
    {
        $worker = new Worker()->setProperties([
            ['string', 'source', 'bank'],
            ['integer', 'limit', 5],
        ]);

        $worker->setPropertyValue('source', 'card')->setPropertyValue('mode', 'full');

        self::assertSame([
            ['string', 'source', 'card'],
            ['integer', 'limit', 5],
            ['string', 'mode', 'full'],
        ], $worker->getProperties());
    }

    public function testDuplicatesKeepTheFirstPlaceAndTheLastValue(): void
    {
        $worker = new Worker()->setProperties([
            ['string', 'limit', '5'],
            ['string', 'source', 'bank'],
            ['string', 'limit', '7'],
            ['string', 'limit', '9'],
        ]);

        self::assertSame([
            ['string', 'limit', '9'],
            ['string', 'source', 'bank'],
        ], $worker->getProperties());
        self::assertSame('9', $worker->getProperty('limit'));
    }

    public function testDuplicatesOfALoadedWorkerAreRemoved(): void
    {
        $worker = new Worker();
        // Doctrine hydrates the column directly, past setProperties().
        (fn() => $this->properties = [
            ['string', 'limit', '5'],
            ['string', 'limit', '5'],
            ['string', 'ignore_no_error_logs', 'true'],
        ])->call($worker);

        $worker->removeDuplicateProperties();

        self::assertSame([
            ['string', 'limit', '5'],
            ['string', 'ignore_no_error_logs', 'true'],
        ], (fn() => $this->properties)->call($worker));
    }

    public function testEntriesOfAnotherShapeAreKept(): void
    {
        $worker = new Worker()->setProperties(['source' => 'bank']);

        self::assertSame(['source' => 'bank'], $worker->getProperties());
    }

    public function testAnIncompleteEntryNeitherReplacesNorIsReadAsAProperty(): void
    {
        $worker = new Worker()->setProperties([
            ['string', 'limit', '5'],
            ['string', 'limit'],
        ]);

        self::assertSame([['string', 'limit', '5'], ['string', 'limit']], $worker->getProperties());
        self::assertSame('5', $worker->getProperty('limit'));
    }

    public function testANullValueIsStillAProperty(): void
    {
        $worker = new Worker()->setPropertyValue('limit', 5)->setPropertyValue('limit', null);

        self::assertSame([['NULL', 'limit', null]], $worker->getProperties());
    }

    public function testAMissingPropertyYieldsTheDefault(): void
    {
        self::assertSame('none', new Worker()->getProperty('limit', 'none'));
    }
}
