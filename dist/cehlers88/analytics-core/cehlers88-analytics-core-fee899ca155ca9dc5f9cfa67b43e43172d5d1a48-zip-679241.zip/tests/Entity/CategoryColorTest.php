<?php

namespace Cehlers88\AnalyticsCore\Tests\Entity;

use Cehlers88\AnalyticsCore\Entity\Category;
use Doctrine\Common\Collections\ArrayCollection;
use PHPUnit\Framework\TestCase;

class CategoryColorTest extends TestCase
{
    protected function setUp(): void
    {
        if (!class_exists(ArrayCollection::class)) {
            $this->markTestSkipped('doctrine/collections is not installed');
        }
    }

    public function testACategoryHasNoColorByDefault(): void
    {
        $this->assertNull((new Category())->getColor());
    }

    public function testTheColorIsStoredAsLowerCaseLongHex(): void
    {
        $this->assertSame('#1a2b3c', (new Category())->setColor(' #1A2B3C ')->getColor());
        $this->assertSame('#aabbcc', (new Category())->setColor('#abc')->getColor());
    }

    public function testAnythingButAHexColorClearsIt(): void
    {
        foreach ([null, '', 'red', '#12345', '1a2b3c', '#1a2b3c;background:url(x)', '#ggg'] as $color) {
            $this->assertNull((new Category())->setColor('#000000')->setColor($color)->getColor(), var_export($color, true));
        }
    }
}
