<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Entity;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Doctrine\Common\Collections\ArrayCollection;
use PHPUnit\Framework\TestCase;

class WorkerReferenceCopyTest extends TestCase
{
    protected function setUp(): void
    {
        if (!class_exists(ArrayCollection::class)) {
            $this->markTestSkipped('doctrine/collections is not installed');
        }
    }

    private function original(): Worker
    {
        return (new Worker())
            ->setName('Import')
            ->setWorkerClass('ImportWorker')
            ->setApplication($this->createStub(Application::class))
            ->setRunInterval('PT5M')
            ->setPriority(3)
            ->setDescription('imports')
            ->setProperties([['integer', 'limit', 10], ['string', 'source', 'bank']]);
    }

    public function testAHardCopyTakesTheSettingsAndKeepsNoRelation(): void
    {
        $original = $this->original();

        $copy = $original->createCopy('Import 2', false);

        $this->assertSame('Import 2', $copy->getName());
        $this->assertSame('ImportWorker', $copy->getWorkerClass());
        $this->assertSame($original->getApplication(), $copy->getApplication());
        $this->assertSame(['PT5M', 3, 'imports'], [$copy->getRunInterval(), $copy->getPriority(), $copy->getDescription()]);
        $this->assertSame($original->getProperties(), $copy->getProperties());
        $this->assertNull($copy->getParent());

        $original->setPropertyValue('limit', 99);
        $this->assertSame(10, $copy->getProperty('limit'), 'later changes do not reach it');
    }

    public function testAReferenceCopyFollowsItsParent(): void
    {
        $original = $this->original();
        $copy = $original->createCopy('Import 2', true);

        $this->assertSame($original, $copy->getParent());
        $this->assertTrue($original->getReferenceCopies()->contains($copy));

        $original->setRunInterval('PT1H')->setPriority(9)->setPropertyValue('limit', 50)->setPropertyValue('mode', 'full');
        $copy->applyInheritedSettings();

        $this->assertSame(['PT1H', 9], [$copy->getRunInterval(), $copy->getPriority()]);
        $this->assertSame([['integer', 'limit', 50], ['string', 'source', 'bank'], ['string', 'mode', 'full']], $copy->getProperties());
    }

    public function testOverriddenSettingsStayTheCopysOwn(): void
    {
        $original = $this->original();
        $copy = $original->createCopy('Import 2', true);
        $copy->setRunInterval('P1D')->setSettingOverridden(Worker::SETTING_RUN_INTERVAL, true);
        $copy->setPropertyValue('source', 'card')->setPropertyOverridden('source', true);
        $copy->setPropertyValue('only_here', true)->setPropertyOverridden('only_here', true);

        $original->setRunInterval('PT1H')->setPropertyValue('source', 'cash')->setPropertyValue('limit', 20);
        $copy->applyInheritedSettings();

        $this->assertSame('P1D', $copy->getRunInterval());
        $this->assertSame(
            [['integer', 'limit', 20], ['string', 'source', 'card'], ['boolean', 'only_here', true]],
            $copy->getProperties(),
            'the parent order, an overridden property in its place, the copy\'s own after them',
        );
        $this->assertSame([Worker::SETTING_RUN_INTERVAL, 'property:source', 'property:only_here'], $copy->getOverriddenSettings());
    }

    public function testTakingAnOverrideBackInheritsTheParentsValueAgain(): void
    {
        $original = $this->original();
        $copy = $original->createCopy('Import 2', true);
        $copy->setPropertyValue('limit', 1)->setPropertyOverridden('limit', true);
        $copy->setPriority(1)->setSettingOverridden(Worker::SETTING_PRIORITY, true);

        $copy->setPropertyOverridden('limit', false)->setSettingOverridden(Worker::SETTING_PRIORITY, false)->applyInheritedSettings();

        $this->assertSame(10, $copy->getProperty('limit'));
        $this->assertSame(3, $copy->getPriority());
        $this->assertSame([], $copy->getOverriddenSettings());
    }

    public function testAChainOfReferencesIsUpdatedFromTheTop(): void
    {
        $original = $this->original();
        $child = $original->createCopy('child', true);
        $grandchild = $child->createCopy('grandchild', true);

        $original->setPriority(7);
        $child->applyInheritedSettings();
        $grandchild->applyInheritedSettings();

        $this->assertSame(7, $grandchild->getPriority());
    }

    public function testAWorkerCanNotReferToItselfOrItsCopies(): void
    {
        $original = $this->original();
        $child = $original->createCopy('child', true);

        $this->expectException(\InvalidArgumentException::class);
        $original->setParent($child);
    }

    public function testDetachingKeepsTheValuesAndEndsTheRelation(): void
    {
        $original = $this->original();
        $copy = $original->createCopy('copy', true);
        $copy->setPriority(1)->setSettingOverridden(Worker::SETTING_PRIORITY, true);

        $copy->detachFromParent();

        $this->assertNull($copy->getParent());
        $this->assertFalse($original->getReferenceCopies()->contains($copy));
        $this->assertSame([], $copy->getOverriddenSettings());
        $this->assertSame(1, $copy->getPriority());
        $this->assertSame(10, $copy->getProperty('limit'));
    }

    public function testCommandProperties(): void
    {
        $worker = $this->original()->setPropertyCommand('limit', [['getVar', ['name' => 'limit']]]);

        $this->assertTrue($worker->isPropertyCommand('limit'));
        $this->assertFalse($worker->isPropertyCommand('source'));
        $this->assertSame([['command', 'limit', [['getVar', ['name' => 'limit']]]], ['string', 'source', 'bank']], $worker->getProperties());

        $worker->setPropertyValue('limit', 5);
        $this->assertFalse($worker->isPropertyCommand('limit'), 'a plain value replaces the command');
    }
}
