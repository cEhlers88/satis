<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\DeleteCustomObjectsMacro;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Event\CustomObject\CustomObjectsDeletedEvent;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use PHPUnit\Framework\TestCase;
use Psr\EventDispatcher\EventDispatcherInterface;

class DeleteCustomObjectsMacroTest extends TestCase
{
    private const string METER = 'Cehlers88\\AnalyticsInfrastructureBundle\\CustomObject\\Meter';

    /** @var list<array> what the repository was asked for */
    private array $lookups = [];
    /** @var list<CustomEntity> */
    private array $removed = [];
    private int $flushes = 0;
    /** @var list<object> */
    private array $events = [];

    private static function customObject(int $id, string $name, array $attributes): object
    {
        return new class($id, $name, $attributes) {
            public function __construct(private int $id, private string $name, private array $attributes)
            {
            }

            public function getId(): int
            {
                return $this->id;
            }

            public function getName(): string
            {
                return $this->name;
            }

            public function getParentId(): ?int
            {
                return null;
            }

            public function getAttributes(): array
            {
                return $this->attributes;
            }
        };
    }

    private function macro(bool $protectedMode = false): DeleteCustomObjectsMacro
    {
        $provider = $this->createStub(CustomObjectProvider::class);
        $provider->method('getCustomClasses')->willReturn([['className' => self::METER]]);
        $provider->method('getAttributesOfCustomEntityClass')->willReturn(['room']);
        $provider->method('getCustomEntitiesByClassName')->willReturn([
            self::customObject(1, 'Stromzähler', ['room' => 'Keller']),
            self::customObject(2, 'Wasserzähler', ['room' => 'Keller']),
            self::customObject(3, 'Gaszähler', ['room' => 'Garage']),
        ]);

        $repository = $this->createStub(EntityRepository::class);
        $repository->method('findOneBy')->willReturnCallback(function (array $criteria): CustomEntity {
            $this->lookups[] = $criteria;

            return $this->createStub(CustomEntity::class);
        });
        $entityManager = $this->createStub(EntityManagerInterface::class);
        $entityManager->method('getRepository')->willReturn($repository);
        $entityManager->method('remove')->willReturnCallback(function (object $entity): void {
            $this->removed[] = $entity;
        });
        $entityManager->method('flush')->willReturnCallback(function (): void {
            $this->flushes++;
        });

        $eventDispatcher = $this->createStub(EventDispatcherInterface::class);
        $eventDispatcher->method('dispatch')->willReturnCallback(function (object $event): object {
            $this->events[] = $event;

            return $event;
        });

        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('isProtectedMode')->willReturn($protectedMode);

        $macro = new DeleteCustomObjectsMacro($provider, $entityManager, $eventDispatcher);
        $macro->setMacroEnvironment($environment);

        return $macro;
    }

    public function testDeletesWhatWhereFindsAndTellsAboutIt(): void
    {
        $result = $this->macro()->execute(['className' => 'meter', 'where' => ['room' => 'Keller']]);

        $this->assertFalse($result['hasError']);
        $this->assertSame(['Stromzähler', 'Wasserzähler'], array_column($result['returnValue'], 'name'));
        $this->assertSame([['id' => 1, 'className' => self::METER], ['id' => 2, 'className' => self::METER]], $this->lookups, 'the row is looked up together with its class');
        $this->assertCount(2, $this->removed);
        $this->assertSame(1, $this->flushes);
        $this->assertCount(1, $this->events, 'one event for the whole delete');
        $this->assertInstanceOf(CustomObjectsDeletedEvent::class, $this->events[0]);
        $this->assertSame(self::METER, $this->events[0]->className);
        $this->assertSame([1, 2], $this->events[0]->ids);
    }

    public function testDryRunOnlyTellsWhatWouldGo(): void
    {
        $result = $this->macro()->execute(['className' => self::METER, 'where' => ['id' => [1, 3]], 'dryRun' => true]);

        $this->assertSame(['Stromzähler', 'Gaszähler'], array_column($result['returnValue'], 'name'));
        $this->assertSame([], $this->removed);
        $this->assertSame(0, $this->flushes);
        $this->assertSame([], $this->events);
    }

    public function testTheProtectedModeOnlyActsAsIf(): void
    {
        $result = $this->macro(protectedMode: true)->execute(['className' => self::METER, 'where' => ['room' => 'Garage']]);

        $this->assertSame(['Gaszähler'], array_column($result['returnValue'], 'name'));
        $this->assertSame([], $this->removed);
        $this->assertSame([], $this->events);
    }

    public function testAnEmptyWhereDeletesNothing(): void
    {
        $result = $this->macro()->execute(['className' => self::METER]);

        $this->assertTrue($result['hasError']);
        $this->assertSame(400, $result['error']->number);
        $this->assertSame([], $this->removed);
    }

    public function testNothingMatchingIsNoError(): void
    {
        $result = $this->macro()->execute(['className' => self::METER, 'where' => ['room' => 'Dach']]);

        $this->assertFalse($result['hasError']);
        $this->assertSame([], $result['returnValue']);
        $this->assertSame(0, $this->flushes);
    }

    public function testAnUnknownClassIsAnError(): void
    {
        $result = $this->macro()->execute(['className' => 'Sensor', 'where' => ['id' => 1]]);

        $this->assertTrue($result['hasError']);
        $this->assertSame(404, $result['error']->number);
    }

    public function testWhereSuggestsTheFieldsOfTheClass(): void
    {
        $this->assertSame(
            ['id' => 'own field', 'name' => 'own field', 'parentId' => 'own field', 'room' => 'attribute'],
            $this->macro()->suggestMapKeys('where', ['className' => 'Meter'])
        );
    }
}
