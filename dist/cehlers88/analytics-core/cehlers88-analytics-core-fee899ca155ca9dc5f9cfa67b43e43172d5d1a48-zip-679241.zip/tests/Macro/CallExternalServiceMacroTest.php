<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\CallExternalServiceMacro;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\MapPropertyUi;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\MapKeysValueHelper;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\ExternalServiceFunction;
use Cehlers88\AnalyticsCore\Executor\ExecutorProvider;
use Cehlers88\AnalyticsCore\Executor\ExternalServiceExecutor;
use Cehlers88\AnalyticsCore\Interface\Repository\IExternalServiceFunctionRepository;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\ValueMapper\MappingSubject;
use Cehlers88\AnalyticsCore\ValueMapper\ValueMapperResultDTO;
use PHPUnit\Framework\TestCase;

class CallExternalServiceMacroTest extends TestCase
{
    /** What the executor was configured with, by property. */
    private array $configured = [];

    private function executor(mixed $lastResult = null, array $errors = []): ExternalServiceExecutor
    {
        $executor = $this->createStub(ExternalServiceExecutor::class);
        $executor->method('setPropertyValue')->willReturnCallback(function (string $key, mixed $value) use ($executor, $errors) {
            $this->configured[$key] = $value;
            // run() is final and does nothing on a stub: the errors appear while the call is set up instead.
            $executor->errors = $errors;

            return $executor;
        });
        $executor->method('hasError')->willReturn($errors !== []);
        $executor->method('getErrorsAsString')->willReturn(implode('; ', array_map(static fn(ErrorDTO $error) => $error->message, $errors)));
        $executor->method('getLastResult')->willReturn($lastResult);
        $executor->errors = [ErrorDTO::create(-1, 'of a call before')];

        return $executor;
    }

    private function macro(
        ?ExternalServiceExecutor $executor = null,
        ?ExternalServiceFunction $function = null,
        ?CommandPlayer           $commandPlayer = null,
    ): CallExternalServiceMacro
    {
        $executorProvider = $this->createStub(ExecutorProvider::class);
        $executorProvider->method('getExecutor')->willReturn($executor);
        $repository = $this->createStub(IExternalServiceFunctionRepository::class);
        $repository->method('findOneByServiceAndName')->willReturn($function);

        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('getCommandPlayer')->willReturn($commandPlayer ?? $this->createStub(CommandPlayer::class));

        $macro = new CallExternalServiceMacro($executorProvider, $repository);
        $macro->setMacroEnvironment($environment);

        return $macro;
    }

    public function testTheResponseOfTheFunctionIsReturned(): void
    {
        $result = $this->macro($this->executor(['id' => 7]))->execute([
            'service' => ' github ',
            'function' => 'repository',
            'arguments' => ['name' => 'analytics'],
            'options' => ['method' => 'GET'],
        ]);

        $this->assertFalse($result['hasError']);
        $this->assertSame(['id' => 7], $result['returnValue']);
        $this->assertSame([
            ExternalServiceExecutor::KEY_SERVICE_NAME => 'github',
            ExternalServiceExecutor::KEY_FUNCTION_NAME => 'repository',
            ExternalServiceExecutor::KEY_ARGUMENTS => ['name' => 'analytics'],
            ExternalServiceExecutor::KEY_OPTIONS => ['method' => 'GET'],
        ], $this->configured);
    }

    public function testAMappedResponseReturnsWhatTheMappingsMadeOfIt(): void
    {
        $mapped = new ValueMapperResultDTO(['stars' => 3], '2xx', new MappingSubject(['stargazers_count' => 3], 200));

        $result = $this->macro($this->executor($mapped))->execute(['service' => 'github', 'function' => 'repository']);

        $this->assertSame(['stars' => 3], $result['returnValue']);
        $this->assertSame([], $this->configured[ExternalServiceExecutor::KEY_ARGUMENTS], 'without arguments the function gets none');
    }

    public function testErrorsOfTheCallAreTheErrorOfTheMacro(): void
    {
        $result = $this->macro($this->executor(null, [
            ErrorDTO::create(500120, 'Response mapping failed: no match', ['statusCode' => 404]),
            ErrorDTO::create(-1, 'second'),
        ]))->execute(['service' => 'github', 'function' => 'repository']);

        $this->assertTrue($result['hasError']);
        $this->assertNull($result['returnValue']);
        $this->assertSame(500120, $result['error']->number);
        $this->assertSame('Response mapping failed: no match; second', $result['error']->message);
        $this->assertSame(['statusCode' => 404], $result['error']->data);
    }

    public function testWithoutServiceOrFunctionNothingIsCalled(): void
    {
        $result = $this->macro($this->executor())->execute(['service' => 'github', 'function' => ' ']);

        $this->assertTrue($result['hasError']);
        $this->assertSame(400, $result['error']->number);
        $this->assertSame([], $this->configured);
    }

    public function testWithoutExecutorTheMacroFails(): void
    {
        $result = $this->macro(null)->execute(['service' => 'github', 'function' => 'repository']);

        $this->assertTrue($result['hasError']);
        $this->assertSame(500, $result['error']->number);
    }

    public function testArgumentsGivenAsAnObjectArePassedOnByName(): void
    {
        $commandPlayer = $this->createStub(CommandPlayer::class);
        $commandPlayer->method('describesCommands')->willReturnCallback(static fn(array $value): bool => ($value[0] ?? null) === 'get_var');
        $commandPlayer->method('run')->willReturn('from a command');

        $this->macro($this->executor(), null, $commandPlayer)->execute([
            'service' => 'github',
            'function' => 'repository',
            'arguments' => (object)['name' => 'analytics', 'owner' => ['get_var', (object)['name' => 'x']]],
        ]);

        $this->assertSame(['name' => 'analytics', 'owner' => 'from a command'], $this->configured[ExternalServiceExecutor::KEY_ARGUMENTS]);
    }

    public function testArgumentsAndOptionsAreEditedAsMaps(): void
    {
        $arguments = CallExternalServiceMacro::getPropertyUiInfos(MacroPropertyDTO::create('arguments'))?->toArray();
        $options = CallExternalServiceMacro::getPropertyUiInfos(MacroPropertyDTO::create('options'))?->toArray();

        $this->assertSame(MapPropertyUi::EDITOR_MAP, $arguments['editor'] ?? null);
        $this->assertSame(MapKeysValueHelper::class, $arguments['keyValueHelper']['name'] ?? null);
        $this->assertSame(MapPropertyUi::EDITOR_MAP, $options['editor'] ?? null);
        $this->assertNull(CallExternalServiceMacro::getPropertyUiInfos(MacroPropertyDTO::create('service')));
    }

    public function testTheArgumentsOfTheNamedFunctionAreTheKeys(): void
    {
        $function = (new ExternalServiceFunction())->setName('repository')->setArguments([
            ['string', 'name'],
            ['string', 'owner', 'cEhlers88'],
        ]);

        $this->assertSame([
            'name' => 'string · required',
            'owner' => 'string · optional',
        ], $this->macro(null, $function)->suggestMapKeys('arguments', ['service' => 'github', 'function' => 'repository']));
    }

    public function testWithoutAFunctionNamedDirectlyThereAreNoKeys(): void
    {
        $macro = $this->macro(null, null);

        $this->assertSame([], $macro->suggestMapKeys('arguments', ['service' => 'github', 'function' => 'missing']));
        $this->assertSame([], $macro->suggestMapKeys('arguments', ['service' => 'github', 'function' => ['get_var', ['name' => 'x']]]));
        $this->assertSame([], $macro->suggestMapKeys('options', ['service' => 'github', 'function' => 'repository']));
    }
}
