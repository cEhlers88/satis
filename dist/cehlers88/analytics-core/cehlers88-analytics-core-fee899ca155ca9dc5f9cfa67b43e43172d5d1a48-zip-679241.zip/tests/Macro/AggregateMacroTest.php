<?php

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\AggregateMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class AggregateMacroTest extends TestCase
{
    private const array BOOKINGS = [
        ['category' => 'rent', 'amount' => 800, 'meta' => ['hours' => 1]],
        ['category' => 'food', 'amount' => '45.5', 'meta' => ['hours' => 2]],
        ['category' => 'food', 'amount' => 14.5],
        ['category' => 'misc', 'amount' => 'n/a'],
    ];

    public static function dataProviderForOperations(): array
    {
        return [
            'count of entries' => [['data' => self::BOOKINGS], 4],
            'count of a field skips missing values' => [['data' => self::BOOKINGS, 'field' => 'meta.hours'], 2],
            'sum ignores what is no number' => [['data' => self::BOOKINGS, 'operation' => 'sum', 'field' => 'amount'], 860.0],
            'avg' => [['data' => self::BOOKINGS, 'operation' => 'avg', 'field' => 'amount'], 860 / 3],
            'min' => [['data' => self::BOOKINGS, 'operation' => 'min', 'field' => 'amount'], 14.5],
            'max' => [['data' => self::BOOKINGS, 'operation' => 'MAX', 'field' => 'amount'], 800],
            'nested field' => [['data' => self::BOOKINGS, 'operation' => 'sum', 'field' => 'meta.hours'], 3],
            'plain values' => [['data' => [3, 4, 5], 'operation' => 'sum'], 12],
            'keyed values' => [['data' => ['jan' => 5, 'feb' => 7], 'operation' => 'sum'], 12],
            'single entry reaches the macro unwrapped' => [['data' => [['amount' => 7]], 'operation' => 'sum', 'field' => 'amount'], 7],
            'avg of nothing' => [['data' => [], 'operation' => 'avg'], null],
            'sum of nothing' => [['data' => [], 'operation' => 'sum'], 0],
            'decimals are summed without binary noise' => [['data' => [0.1, 0.2], 'operation' => 'sum'], 0.3],
            'avg of decimals without binary noise' => [['data' => [0.1, 0.2], 'operation' => 'avg'], 0.15],
            'precision rounds the figure' => [['data' => [1, 2, 7], 'operation' => 'avg', 'precision' => 2], 3.33],
            'nested fields of objects' => [['data' => [
                (object)['attributes' => (object)['stand' => '1520.4']],
                (object)['attributes' => (object)['stand' => '87']],
            ], 'operation' => 'sum', 'field' => 'attributes.stand'], 1607.4],
        ];
    }

    #[DataProvider('dataProviderForOperations')]
    public function test_operation(array $arguments, int|float|null $expected): void
    {
        $result = $this->createMacro()->execute($arguments);

        $this->assertFalse($result['hasError']);
        $this->assertSame($expected, $result['returnValue']);
    }

    public function test_groups_get_a_figure_each(): void
    {
        $grouped = [
            'rent' => [['amount' => 800]],
            'food' => [['amount' => 45.5], ['amount' => 14.5]],
        ];

        $result = $this->createMacro()->execute([
            'data' => $grouped,
            'operation' => 'sum',
            'field' => 'amount',
            'groups' => true,
        ]);

        $this->assertSame(['rent' => 800, 'food' => 60.0], $result['returnValue']);
    }

    public function test_group_by_gives_a_figure_per_value_in_the_order_they_appear(): void
    {
        $bookings = [
            ['konto' => 'Bank', 'betrag' => '120.50'],
            ['konto' => 'Kasse', 'betrag' => 30],
            ['konto' => 'Bank', 'betrag' => -20.5],
            ['konto' => 'Kasse', 'betrag' => null],
            ['betrag' => 4],
        ];

        $sums = $this->createMacro()->execute(['data' => $bookings, 'operation' => 'sum', 'field' => 'betrag', 'groupBy' => 'konto']);
        $counts = $this->createMacro()->execute(['data' => $bookings, 'groupBy' => 'konto']);

        $this->assertSame(['Bank' => 100.0, 'Kasse' => 30, '' => 4], $sums['returnValue']);
        $this->assertSame(['Bank' => 2, 'Kasse' => 2, '' => 1], $counts['returnValue']);

        $single = $this->createMacro()->execute(['data' => [['konto' => 'Bank', 'betrag' => 5]], 'groupBy' => 'konto']);
        $this->assertSame(['Bank' => 1], $single['returnValue'], 'a list of one entry reaches the macro unwrapped');
    }

    public function test_groups_and_group_by_together_are_an_error(): void
    {
        $result = $this->createMacro()->execute(['data' => [['a' => 1]], 'groups' => true, 'groupBy' => 'a']);

        $this->assertTrue($result['hasError']);
        $this->assertSame(422, $result['error']->number);
    }

    public function test_unknown_operation_is_an_error(): void
    {
        $result = $this->createMacro()->execute(['data' => [1, 2], 'operation' => 'median']);

        $this->assertTrue($result['hasError']);
        $this->assertSame(422, $result['error']->number);
    }

    private function createMacro(): AggregateMacro
    {
        $macro = new AggregateMacro();
        $macro->setMacroEnvironment($this->createMock(MacroEnvironment::class));

        return $macro;
    }
}
