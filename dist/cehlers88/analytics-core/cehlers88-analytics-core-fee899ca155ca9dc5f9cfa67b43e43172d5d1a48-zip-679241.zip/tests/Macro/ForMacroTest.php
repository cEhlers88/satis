<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\ForMacro;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Macro\AbstractMacro;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use PHPUnit\Framework\TestCase;

class ForMacroTest extends TestCase
{
    /** The job context, as the variables provider of the test holds it. */
    private array $job = [];

    public function testTheLoopVariablesExistOnlyWhileTheCommandsRun(): void
    {
        $seen = [];
        $macro = $this->forMacro(function () use (&$seen): array {
            $seen[] = [$this->job['item'] ?? null, $this->job['i'] ?? null];
            return [];
        });

        $macro->execute(['items' => ['a', 'b'], 'as' => 'item', 'counterVar' => 'i', 'commands' => [['get_var', ['name' => 'item']]]]);

        $this->assertSame([['a', 0], ['b', 1]], $seen);
        $this->assertArrayNotHasKey('item', $this->job, 'gone after the loop');
        $this->assertArrayNotHasKey('i', $this->job);
    }

    public function testAVariableOfTheSameNameFromBeforeTheLoopIsBackAfterIt(): void
    {
        $this->job = ['item' => 'outer', 'other' => 1];
        $macro = $this->forMacro(fn(): array => []);

        $macro->execute(['items' => ['a', 'b'], 'as' => 'item', 'commands' => [['get_var', ['name' => 'item']]]]);

        $this->assertSame(['item' => 'outer', 'other' => 1], $this->job);
    }

    public function testTheLoopVariablesAreClearedWhenACommandFails(): void
    {
        $macro = $this->forMacro(function (): array {
            throw new \RuntimeException('failed');
        });

        try {
            $macro->execute(['items' => ['a', 'b'], 'as' => 'item', 'commands' => [['get_var', ['name' => 'item']]]]);
            $this->fail('the failure is passed on');
        } catch (\RuntimeException) {
        }

        $this->assertArrayNotHasKey('item', $this->job);
    }

    /** A for whose setVar writes into $this->job and whose commands run the callback. */
    private function forMacro(callable $runCommands): ForMacro
    {
        $variables = $this->createMock(VariablesProvider::class);
        $variables->method('getVariableValue')->willReturnCallback(
            fn(string $name, mixed $context, mixed $default = null): mixed => $name === VariablesProvider::GET_VAR_WILDCARD ? $this->job : ($this->job[$name] ?? $default)
        );
        $variables->method('setVariable')->willReturnCallback(function (string $name, mixed $value) use ($variables): VariablesProvider {
            $this->job[$name] = $value;
            return $variables;
        });
        $variables->method('removeVariable')->willReturnCallback(function (string $name, eMacroVariableContext $context) use ($variables): VariablesProvider {
            $this->assertSame(eMacroVariableContext::JOB, $context);
            unset($this->job[$name]);
            return $variables;
        });

        $commandFactory = $this->createMock(CommandFactory::class);
        $commandFactory->method('evalDefinitionArray')->willReturnArgument(0);

        return new class($commandFactory, $variables, \Closure::fromCallable($runCommands)) extends ForMacro {
            public function __construct(
                CommandFactory                     $commandFactory,
                private readonly VariablesProvider $variables,
                private readonly \Closure          $runCommands
            )
            {
                parent::__construct($commandFactory);
            }

            public function getVariablesStoreProvider(): VariablesProvider
            {
                return $this->variables;
            }

            protected function _executeMacro(string $name, array $arguments = []): ?array
            {
                // setVar writes into the job context by default
                $this->variables->setVariable($arguments['name'], $arguments['value'], eMacroVariableContext::JOB);
                return null;
            }

            protected function _runCommandDefinition($definition): mixed
            {
                return ($this->runCommands)();
            }

            protected function log(eDebuggerLogType $logType, string $message, array $additionalInfos = []): AbstractMacro
            {
                return $this;
            }
        };
    }
}
