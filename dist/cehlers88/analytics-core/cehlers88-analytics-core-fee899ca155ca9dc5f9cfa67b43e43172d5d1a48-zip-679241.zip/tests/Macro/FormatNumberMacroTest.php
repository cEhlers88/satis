<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\FormatNumberMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class FormatNumberMacroTest extends TestCase
{
    private const string NBSP = "\u{00A0}";

    public static function dataProviderForFormats(): array
    {
        return [
            'german number' => [['value' => 1234.5], '1.234,50'],
            'english number' => [['value' => 1234.5, 'locale' => 'en'], '1,234.50'],
            'numeric text' => [['value' => ' 1234.567 ', 'decimals' => 1], '1.234,6'],
            'no decimals' => [['value' => 1234.5, 'decimals' => 0], '1.235'],
            'german amount' => [['value' => 1234.5, 'style' => 'currency'], '1.234,50' . self::NBSP . '€'],
            'english amount' => [['value' => -5, 'style' => 'currency', 'currency' => 'usd', 'locale' => 'en'], '-$5.00'],
            'unknown currency is its code' => [['value' => 3, 'style' => 'currency', 'currency' => 'SEK'], '3,00' . self::NBSP . 'SEK'],
            'german percent' => [['value' => 12.5, 'style' => 'percent', 'decimals' => 1], '12,5' . self::NBSP . '%'],
            'english percent' => [['value' => 12.5, 'style' => 'percent', 'decimals' => 1, 'locale' => 'en'], '12.5%'],
            'no negative zero' => [['value' => -0.001], '0,00'],
            'unknown locale is german' => [['value' => 1000, 'locale' => 'fr'], '1.000,00'],
        ];
    }

    #[DataProvider('dataProviderForFormats')]
    public function test_format(array $arguments, string $expected): void
    {
        $result = $this->createMacro()->execute($arguments);

        $this->assertFalse($result['hasError']);
        $this->assertSame($expected, $result['returnValue']);
    }

    public function test_a_list_is_formatted_entry_by_entry(): void
    {
        $result = $this->createMacro()->execute(['value' => ['jan' => 1000, 'feb' => 2.5], 'decimals' => 1]);

        $this->assertSame(['jan' => '1.000,0', 'feb' => '2,5'], $result['returnValue']);
    }

    public function test_no_number_and_unknown_style_are_errors(): void
    {
        $this->assertSame(422, $this->createMacro()->execute(['value' => 'n/a'])['error']->number);
        $this->assertSame(422, $this->createMacro()->execute(['value' => 1, 'style' => 'roman'])['error']->number);
    }

    private function createMacro(): FormatNumberMacro
    {
        $macro = new FormatNumberMacro();
        $macro->setMacroEnvironment($this->createMock(MacroEnvironment::class));

        return $macro;
    }
}
