<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\DateDiffMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use PHPUnit\Framework\TestCase;

class DateDiffMacroTest extends TestCase
{
    public function test_whole_units_between_two_dates(): void
    {
        $diff = fn(string $unit): mixed => $this->runMacro(['from' => '2026-01-15 08:00', 'to' => '2026-03-01 07:00', 'unit' => $unit, 'timezone' => 'UTC'])['returnValue'];

        $this->assertSame(44, $diff('days'));
        $this->assertSame(6, $diff('weeks'));
        $this->assertSame(1, $diff('months'));
        $this->assertSame(0, $diff('years'));
        $this->assertSame(1079, $diff('hours'));
        $this->assertSame(1079 * 60, $diff('minutes'));
    }

    public function test_only_whole_calendar_months_count(): void
    {
        // 31.01. plus a month would be 03.03. - so there is none yet on 01.03.
        $this->assertSame(0, $this->runMacro(['from' => '2026-01-31', 'to' => '2026-03-01', 'unit' => 'months', 'timezone' => 'UTC'])['returnValue']);
        $this->assertSame(1, $this->runMacro(['from' => '2026-01-31', 'to' => '2026-03-03', 'unit' => 'months', 'timezone' => 'UTC'])['returnValue']);
    }

    public function test_negative_when_to_lies_before_from_unless_absolute(): void
    {
        $this->assertSame(-10, $this->runMacro(['from' => '2026-10-11', 'to' => '2026-10-01', 'timezone' => 'UTC'])['returnValue']);
        $this->assertSame(10, $this->runMacro(['from' => '2026-10-11', 'to' => '2026-10-01', 'absolute' => true, 'timezone' => 'UTC'])['returnValue']);
    }

    public function test_timestamps_and_now(): void
    {
        $this->assertSame(1, $this->runMacro(['from' => 1767225600, 'to' => 1767312000, 'timezone' => 'UTC'])['returnValue']);
        $this->assertSame(1, $this->runMacro(['from' => (new \DateTimeImmutable('-1 day -1 hour'))->format(DATE_ATOM)])['returnValue']);
    }

    public function test_errors(): void
    {
        $this->assertSame(422, $this->runMacro(['from' => '', 'to' => '2026-01-01'])['error']->number);
        $this->assertSame(422, $this->runMacro(['from' => 'kein Datum'])['error']->number);
        $this->assertSame(422, $this->runMacro(['from' => '2026-01-01', 'unit' => 'fortnights'])['error']->number);
    }

    private function runMacro(array $arguments): array
    {
        $macro = new DateDiffMacro();
        $macro->setMacroEnvironment($this->createMock(MacroEnvironment::class));

        return $macro->execute($arguments);
    }
}
