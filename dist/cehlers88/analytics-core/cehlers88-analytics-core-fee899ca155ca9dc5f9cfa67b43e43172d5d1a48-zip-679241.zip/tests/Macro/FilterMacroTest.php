<?php

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\FilterMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class FilterMacroTest extends TestCase
{
    private const array CLIENTS = [
        ['name' => 'item 10', 'visits' => 12, 'state' => 'open', 'geo' => ['country' => 'DE']],
        ['name' => 'item 9', 'visits' => '40', 'state' => 'closed', 'geo' => ['country' => 'AT']],
        ['name' => 'Alpha', 'visits' => 3, 'state' => 'open'],
        ['name' => 'beta', 'visits' => 25, 'state' => 'open', 'geo' => ['country' => 'DE']],
    ];

    public static function dataProviderForFilters(): array
    {
        return [
            'nothing to do' => [['data' => self::CLIENTS], ['item 10', 'item 9', 'Alpha', 'beta']],
            'equals' => [['data' => self::CLIENTS, 'field' => 'state', 'operator' => '==', 'value' => 'open'], ['item 10', 'Alpha', 'beta']],
            'numbers compare as numbers' => [['data' => self::CLIENTS, 'field' => 'visits', 'operator' => '>', 'value' => '20'], ['item 9', 'beta']],
            'one of a list' => [['data' => self::CLIENTS, 'field' => 'name', 'operator' => '==', 'value' => ['Alpha', 'beta']], ['Alpha', 'beta']],
            'nested field' => [['data' => self::CLIENTS, 'field' => 'geo.country', 'operator' => '!=', 'value' => 'DE'], ['item 9', 'Alpha']],
            'starts with' => [['data' => self::CLIENTS, 'field' => 'name', 'operator' => 'startsWith', 'value' => 'item'], ['item 10', 'item 9']],
            'sorted by number, descending' => [['data' => self::CLIENTS, 'sortBy' => 'visits', 'sortDirection' => 'desc'], ['item 9', 'beta', 'item 10', 'Alpha']],
            'sorted by text, naturally' => [['data' => self::CLIENTS, 'sortBy' => 'name'], ['Alpha', 'beta', 'item 9', 'item 10']],
            'missing values go last' => [['data' => self::CLIENTS, 'sortBy' => 'geo.country', 'sortDirection' => 'desc'], ['item 10', 'beta', 'item 9', 'Alpha']],
            'top two open' => [['data' => self::CLIENTS, 'field' => 'state', 'operator' => '==', 'value' => 'open', 'sortBy' => 'visits', 'sortDirection' => 'desc', 'limit' => 2], ['beta', 'item 10']],
        ];
    }

    #[DataProvider('dataProviderForFilters')]
    public function test_filter(array $arguments, array $expectedNames): void
    {
        $result = $this->createMacro()->execute($arguments);

        $this->assertFalse($result['hasError']);
        $this->assertSame($expectedNames, array_column($result['returnValue'], 'name'));
    }

    public function test_plain_values(): void
    {
        $result = $this->createMacro()->execute([
            'data' => [5, 1, 12, 7],
            'operator' => '>=',
            'value' => 5,
            'sortBy' => '.',
        ]);

        $this->assertSame([5, 7, 12], $result['returnValue']);
    }

    public function test_a_single_entry_reaches_the_macro_unwrapped(): void
    {
        $result = $this->createMacro()->execute([
            'data' => [['name' => 'only', 'state' => 'open']],
            'field' => 'state',
            'operator' => '==',
            'value' => 'open',
        ]);

        $this->assertSame([['name' => 'only', 'state' => 'open']], $result['returnValue']);
    }

    public static function dataProviderForInvalidOperators(): array
    {
        return [['~~'], ['&&']];
    }

    #[DataProvider('dataProviderForInvalidOperators')]
    public function test_invalid_operator_is_an_error(string $operator): void
    {
        $result = $this->createMacro()->execute(['data' => self::CLIENTS, 'field' => 'state', 'operator' => $operator, 'value' => 'open']);

        $this->assertTrue($result['hasError']);
        $this->assertSame(422, $result['error']->number);
    }

    private function createMacro(): FilterMacro
    {
        $macro = new FilterMacro();
        $macro->setMacroEnvironment($this->createMock(MacroEnvironment::class));

        return $macro;
    }
}
