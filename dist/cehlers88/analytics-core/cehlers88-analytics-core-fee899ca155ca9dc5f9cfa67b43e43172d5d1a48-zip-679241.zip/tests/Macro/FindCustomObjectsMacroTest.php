<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\FindCustomObjectsMacro;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\MapPropertyUi;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\MapKeysValueHelper;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use PHPUnit\Framework\TestCase;

class FindCustomObjectsMacroTest extends TestCase
{
    private const string METER = 'Cehlers88\\AnalyticsInfrastructureBundle\\CustomObject\\Meter';

    /** The class the provider was asked for the objects of. */
    private ?string $askedClassName = null;

    private static function customObject(int $id, string $name, array $attributes, ?int $parentId = null): object
    {
        return new class($id, $name, $attributes, $parentId) {
            public function __construct(private int $id, private string $name, private array $attributes, private ?int $parentId)
            {
            }

            public function getId(): int
            {
                return $this->id;
            }

            public function getName(): string
            {
                return $this->name;
            }

            public function getParentId(): ?int
            {
                return $this->parentId;
            }

            public function getAttributes(): array
            {
                return $this->attributes;
            }
        };
    }

    private function macro(?CommandPlayer $commandPlayer = null): FindCustomObjectsMacro
    {
        $provider = $this->createStub(CustomObjectProvider::class);
        $provider->method('getCustomClasses')->willReturn([['className' => self::METER], ['className' => 'Analytics\\CustomObject\\Client']]);
        $provider->method('getAttributesOfCustomEntityClass')->willReturn(['value', 'unit', 'name']);
        $provider->method('getCustomEntitiesByClassName')->willReturnCallback(function (string $className): array {
            $this->askedClassName = $className;

            return [
                self::customObject(1, 'Stromzähler', ['value' => '1520.4', 'unit' => 'kWh', 'room' => 'Keller']),
                self::customObject(2, 'Wasserzähler', ['value' => '87', 'unit' => 'm³', 'room' => 'Keller'], 1),
                self::customObject(3, 'Gaszähler', ['value' => '310', 'unit' => 'm³', 'room' => 'Garage']),
            ];
        });

        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('getCommandPlayer')->willReturn($commandPlayer ?? $this->createStub(CommandPlayer::class));

        $macro = new FindCustomObjectsMacro($provider);
        $macro->setMacroEnvironment($environment);

        return $macro;
    }

    private static function namesOf(array $result): array
    {
        return array_column($result['returnValue'], 'name');
    }

    public function testAllObjectsOfTheClassComeBackWithTheirFieldsAndAttributes(): void
    {
        $result = $this->macro()->execute(['className' => self::METER]);

        $this->assertFalse($result['hasError']);
        $this->assertSame(self::METER, $this->askedClassName);
        $this->assertCount(3, $result['returnValue']);
        $this->assertSame([
            'id' => 2,
            'name' => 'Wasserzähler',
            'parentId' => 1,
            'attributes' => ['value' => '87', 'unit' => 'm³', 'room' => 'Keller'],
        ], $result['returnValue'][1]);
    }

    public function testTheShortClassNameIsEnoughInAnyCase(): void
    {
        $this->macro()->execute(['className' => 'meter']);

        $this->assertSame(self::METER, $this->askedClassName);
    }

    public function testAnUnknownClassIsAnError(): void
    {
        $result = $this->macro()->execute(['className' => 'Sensor']);

        $this->assertTrue($result['hasError']);
        $this->assertSame(404, $result['error']->number);
        $this->assertNull($this->askedClassName, 'nothing is loaded for it');
    }

    public function testWhereMatchesAttributesAndOwnFields(): void
    {
        $this->assertSame(['Stromzähler', 'Wasserzähler'], self::namesOf($this->macro()->execute([
            'className' => self::METER,
            'where' => ['room' => 'Keller'],
        ])));
        $this->assertSame(['Wasserzähler'], self::namesOf($this->macro()->execute([
            'className' => self::METER,
            'where' => ['room' => 'Keller', 'parentId' => 1],
        ])));
        $this->assertSame(['Gaszähler'], self::namesOf($this->macro()->execute([
            'className' => self::METER,
            'where' => ['value' => 310],
        ])), 'a number is equal to the text it is stored as');
    }

    public function testAListInWhereMeansOneOfItsValues(): void
    {
        $this->assertSame(['Stromzähler', 'Gaszähler'], self::namesOf($this->macro()->execute([
            'className' => self::METER,
            'where' => ['id' => [1, 3]],
        ])));
    }

    public function testWhereGivenAsAnObjectRunsTheCommandsAmongItsValues(): void
    {
        $commandPlayer = $this->createStub(CommandPlayer::class);
        $commandPlayer->method('describesCommands')->willReturnCallback(static fn(array $value): bool => ($value[0] ?? null) === 'get_var');
        $commandPlayer->method('run')->willReturn('Garage');

        $result = $this->macro($commandPlayer)->execute([
            'className' => self::METER,
            'where' => (object)['room' => ['get_var', (object)['name' => 'room']]],
        ]);

        $this->assertSame(['Gaszähler'], self::namesOf($result));
    }

    public function testOrderByAndLimit(): void
    {
        $this->assertSame(['Wasserzähler', 'Gaszähler'], self::namesOf($this->macro()->execute([
            'className' => self::METER,
            'orderBy' => 'value',
            'limit' => 2,
        ])), 'numbers sort by value, not as text');
        $this->assertSame(['Wasserzähler', 'Stromzähler', 'Gaszähler'], self::namesOf($this->macro()->execute([
            'className' => self::METER,
            'orderBy' => '-name',
        ])));
    }

    public function testFirstReturnsOneObjectOrNull(): void
    {
        $found = $this->macro()->execute(['className' => self::METER, 'where' => ['unit' => 'm³'], 'orderBy' => '-value', 'first' => true]);
        $this->assertSame('Gaszähler', $found['returnValue']['name']);

        $missing = $this->macro()->execute(['className' => self::METER, 'where' => ['room' => 'Dach'], 'first' => true]);
        $this->assertFalse($missing['hasError']);
        $this->assertNull($missing['returnValue']);
    }

    public function testWhereIsEditedAsAMapWhoseKeysAreTheFieldsOfTheClass(): void
    {
        $ui = FindCustomObjectsMacro::getPropertyUiInfos(MacroPropertyDTO::create('where'))?->toArray();
        $this->assertSame(MapPropertyUi::EDITOR_MAP, $ui['editor'] ?? null);
        $this->assertSame(MapKeysValueHelper::class, $ui['keyValueHelper']['name'] ?? null);
        $this->assertNull(FindCustomObjectsMacro::getPropertyUiInfos(MacroPropertyDTO::create('className')));

        $this->assertSame(
            ['id' => 'own field', 'name' => 'own field', 'parentId' => 'own field', 'value' => 'attribute', 'unit' => 'attribute'],
            $this->macro()->suggestMapKeys('where', ['className' => 'Meter'])
        );
        $this->assertSame([], $this->macro()->suggestMapKeys('where', ['className' => ['get_var', ['name' => 'x']]]));
        $this->assertSame([], $this->macro()->suggestMapKeys('orderBy', ['className' => 'Meter']));
    }
}
