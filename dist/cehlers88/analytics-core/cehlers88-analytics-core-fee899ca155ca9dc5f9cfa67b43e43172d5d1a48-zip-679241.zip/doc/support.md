# Support Utilities

The `Cehlers88\AnalyticsCore\Support` namespace provides cross-cutting utilities used throughout the library.

## Error Handling — `AbstractErrorBag`

`AbstractErrorBag` is the base for all classes that need structured error accumulation (workers, executors, process
runners, etc.).

```php
use Cehlers88\AnalyticsCore\Support\Error\AbstractErrorBag;

class MyService extends AbstractErrorBag
{
    public function process(): void
    {
        if ($somethingWrong) {
            $this->setError('Validation failed', 422, ['field' => 'email']);
        }
    }
}

$service = new MyService();
$service->process();

$service->hasError();          // bool
$service->getErrorsAsString(); // "422: Validation failed"
$service->errors;              // ErrorDTO[]
```

### `ErrorDTO`

| Field     | Type   | Description                          |
|-----------|--------|--------------------------------------|
| `number`  | int    | Error code                           |
| `message` | string | Human-readable error message         |
| `data`    | mixed  | Additional context (e.g. field name) |

```php
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;

$error = ErrorDTO::create(422, 'Validation failed', ['field' => 'email']);
echo $error->toArray()['error']; // "Validation failed"
echo (string) $error;            // "#422: Validation failed"
```

### Debug Mode

```php
$service->enableDebugMode(true);

// These only log in debug mode when the second argument is true
$this->logInfo('Verbose detail', true);
$this->logWarning('Verbose warning', true);
```

## Profiling — `Profiler`

`Profiler` measures runtime and memory usage of any callable or code block:

```php
use Cehlers88\AnalyticsCore\Support\Profiler;

// Profile a callable
$result = Profiler::run(function () {
    // ... expensive operation ...
    return 42;
});

echo $result['profiler']->getReadableDuration(); // e.g. "120ms"
echo $result['result'];                           // 42
echo $result['hasError'] ? 'error' : 'ok';
// $result['exception'] contains the Throwable if hasError is true

// Manual start/stop
$profiler = new Profiler();
$profiler->start();
// ... work ...
$profiler->stop();

echo $profiler->getDurationMilliseconds();  // float — ms
echo $profiler->getDurationSeconds();       // float — seconds
echo $profiler->getUsedMemoryBytes();       // int — memory delta
echo $profiler->getPeakMemoryBytes();       // int — peak memory since script start
echo $profiler->getStartedAt()->format('Y-m-d H:i:s');
```

## Property Management — `AbstractPropertyBag`

`AbstractPropertyBag` provides typed, validated properties for configurable components (workers, jobs, etc.):

```php
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Support\AbstractPropertyBag;

class MyComponent extends AbstractPropertyBag
{
    public function __construct()
    {
        // Register a required property with a default of 30
        $this->addProperty(PropertyDTO::create('timeout', 30));
    }
}

$component = new MyComponent();

// Set a value
$component->setPropertyValue('timeout', 60);

// Get a value (returns default if still default)
$timeout = $component->getPropertyValue('timeout'); // 60

// Validate — ensures all required (non-optional) properties have been set
if (!$component->validate()) {
    echo $component->getErrorsAsString();
}

// Load values in bulk (e.g. from database)
$component->loadPropertyValues([
    [PropertyType::INT, 'timeout', 60],
]);
```

## Converter Utilities — `ConverterUtils`

```php
use Cehlers88\AnalyticsCore\Support\ConverterUtils;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

// Combine enum cases into a single bitmask integer
$mask = ConverterUtils::arrayToBitmask([eRunningState::Running, eRunningState::Buffering]);

// Also works with plain integers
$mask = ConverterUtils::arrayToBitmask([1024, 1048576]);

// Flatten an associative array into a comma-separated key:value string
$str = ConverterUtils::associativeArrayToString(['host' => 'localhost', 'port' => 80]);
// Result: "host:localhost,port:80"
```

## Custom Objects — `AbstractCustomObject` / `CustomObjectProvider`

Dynamic entity classes that are stored in the database and resolved at runtime. See [
`custom-objects.md`](custom-objects.md).

## Function Arguments — `FunctionArguments`

The macro `function` defines a function for the rest of the run; `call` runs it. Its
`arguments` are declared like the arguments of a procedure (`ProcedureArguments`):

```json
["function", {
  "name": "greet",
  "arguments": [
    ["string", "name"],
    ["integer", "times", 1],
    {"name": "loud", "type": "boolean", "default": false, "description": "shout"}
  ],
  "content": [["echo", {"value": ["get_var", {"name": "name", "context": "argument"}]}]]
}]
["call", {"name": "greet", "arguments": {"name": "Ada", "times": "3"}}]
```

Types are `string`, `integer`, `float`, `boolean`, `array` and `mixed`; an argument without
a default is required (or `required` says so). Before any command of the function runs, the
call is checked and **every** problem is reported at once (error 422):

- a required argument that is missing (a variable `get_var` did not find counts as missing),
- a value - or a default - that is not of the declared type; text that reads as the type
  (`"3"` for an integer, `"yes"` for a boolean, JSON for an array) is converted,
- a name the function does not declare (a typo would otherwise fall back to the default).

A function that declares no arguments takes whatever the call hands over. The arguments are
readable in the variable context `argument` while the function runs and gone afterwards.
