# Worker System

The worker system orchestrates background processing against collections of working objects (typically `TrackingBuffer` records). It lives in the `Cehlers88\AnalyticsCore\Worker` namespace.

## Overview

```
AbstractWorker          — base worker; implement getWorkingObjects() and register jobs
  └── WorkerInterface
AbstractWorkerJob       — processes individual working objects
  └── JobInterface
WorkerProvider          — DI-managed registry; executes workers by ID or priority
WorkerResultDTO         — captures the outcome of a single worker execution
```

## Implementing a Worker

Extend `AbstractWorker`, implement `getWorkingObjects()`, and register the service with the `analytics.worker` tag:

```php
use Cehlers88\AnalyticsCore\Worker\AbstractWorker;

class MyWorker extends AbstractWorker
{
    public function getWorkingObjects(): array
    {
        // Return the set of objects to process (e.g. TrackingBuffer records)
        return $this->trackingBufferRepository->findUnprocessed();
    }

    // Optional: override to filter which objects are processed
    public function handleWorkingObjectStart(mixed $workingObject): bool
    {
        return true;
    }

    // Optional: react after each object is handled
    public function handleWorkingObjectEnd(mixed $workingObject, array $jobResults): void
    {
    }
}
```

`services.yaml`:
```yaml
MyWorker:
    tags:
        - { name: analytics.worker }
```

## Implementing a Worker Job

Worker jobs perform the actual logic on each working object:

```php
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Analytics\ENUM\eWorkerJobType;

class MyJob extends AbstractWorkerJob
{
    public eWorkerJobType $type = eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION;

    public function workOnObject(object $object): static
    {
        // Act on $object (typically a TrackingBuffer)
        return $this;
    }

    protected function willHandle(object $workingObject): bool
    {
        // Optional: return false to skip this object
        return true;
    }
}
```

Jobs are attached to workers before execution:

```php
$worker->addJob(new MyJob());
```

## WorkerProvider

`WorkerProvider` is the DI service used to look up and execute workers:

```php
// Fetch a worker instance by its database entity ID
$worker = $workerProvider->getWorkerInstanceByEntityId($workerId);

// Fetch a worker instance by its class name
$worker = $workerProvider->getWorkerInstanceByName(MyWorker::class);

// Execute a single worker by entity ID
$workerProvider->executeWorker($workerId, $logger);

// Execute all waiting workers (respects RunChain ordering and priority)
/** @var Worker[] $executed */
$executed = $workerProvider->executeWaitingWorkers();

// Execute all workers at a given priority level
$workerProvider->executeWorkersByPriorityLevel(1, $logger);

// Change the state of a worker entity
$workerProvider->setWorkerState($workerId, eRunningState::Idle);

// Scope execution to a specific RunChain
$workerProvider->setActiveRunChain($runChainEntity);

// List workers whose entity/class mapping is broken
$unrelated = $workerProvider->getUnrelatedWorkers();

// Resolve a worker's configurable property definitions
$properties = $workerProvider->resolveWorkerPropertyDefinition($workerEntity);
```

## WorkerResultDTO

Returned by `AbstractWorker::execute()` and stored in `WorkerJournal`:

| Field | Type | Description |
|-------|------|-------------|
| `error` | `string\|null` | Error message(s) if any |
| `startedAt` | `int` | Unix timestamp of execution start |
| `endedAt` | `int` | Unix timestamp of execution end |
| `runtime` | `float` | Total runtime in seconds |
| `timedOut` | `bool` | Whether the timeout was reached |
| `jobResults` | `array` | Per-job results |
| `workerInfos` | `array` | Benchmark metadata and working object counts |

```php
// Serialize / deserialize
$serialized = (string) $result;                           // JSON
$restored   = WorkerResultDTO::createFromString($serialized);

// Create from an exception
$result = WorkerResultDTO::createFromException($exception);

// Human-readable timestamps
echo $result->getFormatedStartedAt();   // "20.03.2025 | 12:00:00"
echo $result->getFormattedEndedAt();
```

## Timeout Handling

Set the maximum runtime on the `Worker` entity. The worker checks elapsed time between objects and jobs and stops gracefully when the limit is reached:

```php
$workerEntity->setMaxRuntime(60); // seconds; -1 means no limit
```

When a timeout is detected, `reachedTimeout()` returns `true` and `WorkerResultDTO::$timedOut` is set.

## Worker Properties

The `Worker` entity stores its properties as `[type, name, value]` entries. **Every property is
stored once**: `setPropertyValue()` and `setProperty()` update the entry that holds the property
and only add one for a property the worker does not have yet. Workers saved before this held some
properties several times; such duplicates are dropped when the worker is loaded (the first entry
keeps its place, the last value wins) and the cleaned list is written with the next flush.

`AbstractWorker::configure()` declares two properties every worker has:

| Property               | Default | Meaning                                                                 |
|------------------------|---------|-------------------------------------------------------------------------|
| `allowed_runtime`      | `-1`    | maximum runtime in seconds, `-1` = no limit                             |
| `ignore_no_error_logs` | `false` | when true, the journal of a run is only written if it ended with warnings or errors |

`ignoresNoErrorLogs()` reads `ignore_no_error_logs`; a worker without the property counts as
`false`. Values saved through the worker card are strings, so `"true"`/`"1"` switch it on and
`"false"`, `"0"` or an empty field leave it off.

## Command properties

A property can hold a **command** instead of a value: its entry is `['command', name, definition]`
(`Worker::setPropertyCommand()`, `Worker::PROPERTY_TYPE_COMMAND`). `AbstractWorker::configure()` notes
these properties (`getCommandProperties()`) and keeps the definition as the value, so a mask shows what is
configured. At the start of every run `execute()` runs each command with the command player of the
worker's macro environment (in the worker's application) and takes the result as the value of the
property - the run works with what the command says right then. The definition may be a command list, a
`[name, arguments]` pair, JSON text of either or a bare command name; anything the command player does
not recognise as registered commands (`CommandPlayer::describesCommands()`) is an error of the run instead
of becoming the value, and so is a command that fails: `Property "<name>": its command failed: …`.

## Copies and reference copies

`Worker::createCopy($name, $asReference)` creates a new worker with the settings of this one - worker
class, application, interval, priority, description and every property; not its state, journal or run
chains.

- A **hard copy** (`$asReference = false`) has no relation to its original afterwards.
- A **reference copy** refers to its original (`getParent()`, the other way round
  `getReferenceCopies()`) and takes the settings of `Worker::INHERITABLE_SETTINGS` and every property
  from it, unless it **overrides** them (`setSettingOverridden()`, `setPropertyOverridden()`; stored in
  `overriddenSettings`, a property as `property:<name>`). Name, enabled, run chains, state and journal are
  always its own.

The inherited values are stored on the reference copy as well, so a run, a repository query or the
scheduler read them like those of any other worker. `applyInheritedSettings()` takes them from the parent
once more - whoever changes a worker calls it on every reference copy below it, from the top down (in the
application `WorkerAdministration` does). The properties keep the order of the parent, an overridden one
in its place, the ones only the copy has after them.

`detachFromParent()` ends the reference: the worker keeps the values it has and goes on as one of its
own. A worker can not become a reference copy of itself or of one of its own reference copies. In the
database the reference is `parent_id` with `ON DELETE SET NULL` - a copy whose original is deleted keeps
its settings.

## Dashboard tile (`AnalyticsCore.workersView`)

`WorkersViewWidget` shows all workers, or the picked ones (setting *Anzeige*, the ids in `source`), of the
applications the signed-in user may read: a status (läuft, Fehler, deaktiviert, wartet, bereit), the last
and the next run and the counters. The tile renders itself again whenever a `Worker` changes.

With the dashboard and the permission `MANAGE_WORKERS` each worker also gets *Starten* (the
`StartWorkerMessage` of the worker page), *Auf Idle*, *Aktivieren*/*Deaktivieren* and *Zähler
zurücksetzen*. They go through `/api/submitWidget` (`submit()`, `id` + `action`), which checks the
permission and the application again - the template only leaves the buttons out.
