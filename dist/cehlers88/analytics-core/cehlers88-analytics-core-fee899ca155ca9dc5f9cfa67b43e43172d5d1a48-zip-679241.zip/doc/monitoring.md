# Monitoring

A `CustomEntityAttributeMonitoring` watches one attribute of a custom object. `Support\Monitoring::run()`
runs every monitoring whose `runInterval` (an ISO-8601 duration or `daily_midnight`) is due:

1. it runs the monitoring's **rule** (`ruleHandler`, the short or fully qualified class name) with the
   monitoring's `ruleArguments`,
2. it appends the attribute value and a timestamp to the monitoring's statistic, keeping `maxLength`
   entries per series.

The rules of a monitoring also run on their own (`Monitoring::runMonitoringRules()`) whenever
`CustomObjectProvider` saves a changed attribute value.

## Rules

A rule implements `Support\MonitoringRule\MonitoringRuleInterface` (usually by extending
`AbstractMonitoringRule`) and is registered by that interface alone - the tag
`analytics.monitoring_rule` is added automatically, and the monitoring modal of the application offers it
with the fields built from `getArgumentDefinitions()`.

### State between runs

Before `execute()` a rule gets the options it left in the previous run (`getStatisticOptions()`); what it
sets with `setStatisticOptions()` is stored in `details.options` of the statistic - by every run of the
rule, the scheduled one and the one on an attribute change. The options are no
series: they are neither cut to `maxLength` nor padded. `monitoredAttribute` is set by `Monitoring` itself.

### `RangeCheckMonitoringRule`

Fires when the value reaches a lower (`min`) or upper (`max`) bound. `onMin`/`onMax` run once when the
bound is reached and again only after the value was back within the bounds.

### `IncreaseCheckMonitoringRule`

Fires when the value **rose by at least a given amount within a given timespan** - for any numeric
attribute: an error counter, a temperature, a queue length, …

| Argument        | Meaning                                                                         |
|-----------------|---------------------------------------------------------------------------------|
| `increase`      | the rise that fires the rule, greater than `0`                                  |
| `timespan`      | ISO-8601 duration the rise has to happen in (`PT15M`, `PT1H`, `P1D`)            |
| `mode`          | `absolute` (default, in the unit of the value) or `percent`                    |
| `applicationId` | application the commands run in (default `1`); if it no longer exists, the commands are skipped |
| `onIncrease`    | commands that run once when the rise is reached                                 |
| `onRecover`     | commands that run once when the rise is no longer reached                       |

- The rise is the current value minus the **lowest** value within the timespan. A counter that is reset in
  between therefore does not hide a new rise, and a falling value is no rise.
- The value the timespan starts with is the last one measured at or before its start, so a timespan as
  long as the run interval still compares two values.
- In `percent` the rise is relative to that lowest value; a lowest value of `0` or below has no
  percentage, so the rule does not fire then.
- The rule measures the values of its runs - the scheduled ones and those on an attribute change - so
  the run interval should be clearly shorter than the timespan.
- Its samples live in `details.options.increaseCheck`, independent of `maxLength`. A sample that is
  followed by one that is not higher can never be the lowest value of a later timespan and is dropped,
  which leaves the measurement unchanged. Only a long steady rise can exceed 1000 samples; then they are
  thinned evenly, keeping the lowest and the current value, so the current rise stays exact.
- A value that is not numeric is skipped and leaves the state as it was.

Example - alarm when the error counter grows by 10 within an hour, checked every 5 minutes:

```json
{"runInterval": "PT5M", "ruleHandler": "IncreaseCheckMonitoringRule",
 "ruleArguments": {"increase": 10, "timespan": "PT1H", "onIncrease": [ … ], "onRecover": [ … ]}}
```
