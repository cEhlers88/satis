<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Analytics\ENUM\eWorkerCounterKey;
use Analytics\Register\BadgeRegister;
use Analytics\Utils\DateUtils;
use Cehlers88\AnalyticsCore\DTO\BadgeDTO;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Repository\WorkerRepository;
use Cehlers88\AnalyticsCore\Worker\DTO\StoreDTO;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: WorkerRepository::class)]
#[ORM\HasLifecycleCallbacks]
/**
 * Entity representing a background worker.
 */
class Worker extends AbstractRunnableEntity
{
    public const ACTION_SET_IDLE = 'set_idle';
    public const ACTION_ENABLE = 'enable';
    public const ACTION_DISABLE = 'disable';
    private const PROPERTY_ALLOW_AUTOMATIC_RE_RUN_AFTER_FAILURE = 'allowAutomaticReRunAfterFailure';

    /**
     * The settings a reference copy takes from the worker it refers to, as long as it does
     * not set them itself - its properties come on top (property by property). Name, enabled,
     * run chains, state and journal are always the worker's own.
     */
    public const SETTING_WORKER_CLASS = 'workerClass';
    public const SETTING_APPLICATION = 'application';
    public const SETTING_RUN_INTERVAL = 'runInterval';
    public const SETTING_PRIORITY = 'priority';
    public const SETTING_DESCRIPTION = 'description';
    public const INHERITABLE_SETTINGS = [
        self::SETTING_WORKER_CLASS,
        self::SETTING_APPLICATION,
        self::SETTING_RUN_INTERVAL,
        self::SETTING_PRIORITY,
        self::SETTING_DESCRIPTION,
    ];
    private const PROPERTY_SETTING_PREFIX = 'property:';

    /**
     * The type of a property entry whose value is a command definition: the worker runs it
     * at the start of every run and works with its result (AbstractWorker).
     */
    public const PROPERTY_TYPE_COMMAND = 'command';

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(length: 255)]
    private ?string $workerClass = null;

    #[ORM\OneToMany(targetEntity: WorkerJournal::class, mappedBy: 'worker')]
    private Collection $journals;

    #[ORM\Column]
    private array $counters = [];

    #[ORM\Column(type: Types::TEXT)]
    private string $lastRunResult = "";

    #[ORM\ManyToOne(inversedBy: 'workers')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Application $application = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $nextRunAt = null;

    #[ORM\Column]
    private array $properties = [];

    #[ORM\Column]
    private ?int $priority = null;

    #[ORM\Column(length: 20, nullable: true)]
    private ?string $runInterval = null;

    /**
     * @var Collection<int, RunChain>
     */
    #[ORM\ManyToMany(targetEntity: RunChain::class, inversedBy: 'workers')]
    private Collection $runChains;

    /**
     * @var Collection<int, WorkerJobOptions>
     */
    #[ORM\OneToMany(targetEntity: WorkerJobOptions::class, mappedBy: 'worker', orphanRemoval: true)]
    private Collection $jobOptions;

    #[ORM\Column(nullable: true)]
    private ?array $store = null;

    /**
     * The worker this one is a reference copy of - null for an independent worker. Its
     * settings are the parent's unless overridden here (applyInheritedSettings()); they are
     * stored on this worker as well, so a run reads them like those of any other worker.
     * Without its parent (deleted in the database) the worker keeps the values it has.
     */
    #[ORM\ManyToOne(targetEntity: self::class, inversedBy: 'referenceCopies')]
    #[ORM\JoinColumn(name: 'parent_id', nullable: true, onDelete: 'SET NULL')]
    private ?Worker $parent = null;

    /**
     * @var Collection<int, Worker>
     */
    #[ORM\OneToMany(targetEntity: self::class, mappedBy: 'parent')]
    private Collection $referenceCopies;

    /**
     * What a reference copy sets itself instead of taking it from its parent: entries of
     * INHERITABLE_SETTINGS and "property:<name>" for single properties.
     *
     * @var list<string>|null
     */
    #[ORM\Column(nullable: true)]
    private ?array $overriddenSettings = null;

    public function __construct()
    {
        parent::__construct();
        $this->journals = new ArrayCollection();
        $this->runChains = new ArrayCollection();
        $this->jobOptions = new ArrayCollection();
        $this->referenceCopies = new ArrayCollection();
    }

    public function getParent(): ?Worker
    {
        return $this->parent;
    }

    /**
     * @throws \InvalidArgumentException when the worker would end up referring to itself
     */
    public function setParent(?Worker $parent): static
    {
        for ($ancestor = $parent; $ancestor !== null; $ancestor = $ancestor->getParent()) {
            if ($ancestor === $this) {
                throw new \InvalidArgumentException('A worker can not be a reference copy of itself or of one of its own reference copies.');
            }
        }

        $this->parent?->referenceCopies->removeElement($this);
        $this->parent = $parent;
        if ($parent !== null && !$parent->referenceCopies->contains($this)) {
            $parent->referenceCopies->add($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, Worker>
     */
    public function getReferenceCopies(): Collection
    {
        return $this->referenceCopies;
    }

    public function isReferenceCopy(): bool
    {
        return $this->parent !== null;
    }

    /**
     * @return list<string> see $overriddenSettings
     */
    public function getOverriddenSettings(): array
    {
        return array_values($this->overriddenSettings ?? []);
    }

    public function isSettingOverridden(string $setting): bool
    {
        return in_array($setting, $this->overriddenSettings ?? [], true);
    }

    public function setSettingOverridden(string $setting, bool $overridden): static
    {
        $settings = array_values(array_diff($this->overriddenSettings ?? [], [$setting]));
        if ($overridden) {
            $settings[] = $setting;
        }
        $this->overriddenSettings = $settings === [] ? null : $settings;

        return $this;
    }

    public function isPropertyOverridden(string $propertyName): bool
    {
        return $this->isSettingOverridden(self::PROPERTY_SETTING_PREFIX . $propertyName);
    }

    public function setPropertyOverridden(string $propertyName, bool $overridden): static
    {
        return $this->setSettingOverridden(self::PROPERTY_SETTING_PREFIX . $propertyName, $overridden);
    }

    /**
     * Takes every setting this reference copy does not override from its parent - the
     * properties one by one: those of the parent in its order, an overridden one in its
     * place, and the ones only this worker has after them. Nothing happens without a parent.
     *
     * The parent's values are what is stored on it, so a chain of reference copies is
     * brought up to date from the top down (WorkerAdministration does that on every change).
     */
    public function applyInheritedSettings(): static
    {
        $parent = $this->parent;
        if ($parent === null) {
            return $this;
        }

        if (!$this->isSettingOverridden(self::SETTING_WORKER_CLASS)) {
            $this->workerClass = $parent->getWorkerClass();
        }
        if (!$this->isSettingOverridden(self::SETTING_APPLICATION)) {
            $this->application = $parent->getApplication();
        }
        if (!$this->isSettingOverridden(self::SETTING_RUN_INTERVAL)) {
            $this->runInterval = $parent->getRunInterval();
        }
        if (!$this->isSettingOverridden(self::SETTING_PRIORITY)) {
            $this->priority = $parent->getPriority();
        }
        if (!$this->isSettingOverridden(self::SETTING_DESCRIPTION)) {
            $this->description = $parent->getDescription();
        }

        $own = [];
        foreach ($this->getProperties() as $property) {
            $name = self::propertyName($property);
            if ($name !== null && $this->isPropertyOverridden($name)) {
                $own[$name] = $property;
            }
        }
        $properties = [];
        foreach ($parent->getProperties() as $property) {
            $name = self::propertyName($property);
            if ($name !== null && isset($own[$name])) {
                $properties[] = $own[$name];
                unset($own[$name]);
                continue;
            }
            $properties[] = $property;
        }
        $this->properties = self::uniqueProperties([...$properties, ...array_values($own)]);

        return $this;
    }

    /**
     * A new worker with the settings of this one under another name - its properties
     * included, its state, journal and run chains not. A reference copy refers to this
     * worker and follows its settings from then on; a hard copy has no relation to it.
     */
    public function createCopy(string $name, bool $asReference): Worker
    {
        $copy = (new self())
            ->setName($name)
            ->setDescription($this->description)
            ->setRunInterval($this->runInterval)
            ->setPriority((int)$this->priority)
            ->setApplication($this->application)
            ->setProperties($this->getProperties());
        $copy->workerClass = $this->workerClass;

        if ($asReference) {
            $copy->setParent($this);
        }

        return $copy;
    }

    /**
     * Ends the reference: the worker keeps the values it has right now and goes on as an
     * independent one.
     */
    public function detachFromParent(): static
    {
        $this->setParent(null);
        $this->overriddenSettings = null;

        return $this;
    }


    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return Collection<int, WorkerJournal>
     */
    public function getJournals(): Collection
    {
        return $this->journals;
    }

    public function addJournal(WorkerJournal $journal): static
    {
        if (!$this->journals->contains($journal)) {
            $this->journals->add($journal);
            $journal->setWorker($this);
        }

        return $this;
    }

    public function allowAutomaticReRunAfterFailure(): bool
    {
        return $this->getProperty(self::PROPERTY_ALLOW_AUTOMATIC_RE_RUN_AFTER_FAILURE, false) === true;
    }

    public function getProperty(string $key, mixed $default = null): mixed
    {
        $result = array_find(self::uniqueProperties($this->properties), fn($property) => self::propertyName($property) === $key);
        return $result ? $result[2] : $default;
    }

    public function setAllowAutomaticReRunAfterFailure(bool $isAllowed): static
    {
        return $this->setProperty(self::PROPERTY_ALLOW_AUTOMATIC_RE_RUN_AFTER_FAILURE, $isAllowed);
    }

    public function setProperty(string $key, mixed $value): static
    {
        return $this->setPropertyValue($key, $value);
    }

    public function removeJournal(WorkerJournal $journal): static
    {
        if ($this->journals->removeElement($journal)) {
            // set the owning side to null (unless already changed)
            if ($journal->getWorker() === $this) {
                $journal->setWorker(null);
            }
        }

        return $this;
    }

    public function addCounterEntry(mixed $entry, eWorkerCounterKey $counterKey): static
    {
        if (!isset($this->counters[$counterKey->value])) {
            $this->counters[$counterKey->value] = [];
        }
        $this->counters[$counterKey->value][] = $entry;
        return $this;
    }

    public function getCounters(): array
    {
        return $this->counters;
    }

    public function setCounters(array $counters): static
    {
        $this->counters = $counters;

        return $this;
    }

    /**
     * Finalizes the worker process by updating the state, timestamps, and result counters
     * based on the provided result data and next run time.
     *
     * @param WorkerResultDTO $workerResultDTO The worker result data transfer object containing
     *                                             details of the worker execution result.
     * @param \DateTimeInterface|null $nextRunAt The next scheduled execution time. Can be null.
     * @param eRunningState $state The state to be applied to the worker.
     *
     * @return static Returns the updated instance of the object.
     */
    public function finishWorker(
        WorkerResultDTO $workerResultDTO,
        int             $state
    ): static
    {
        $this
            ->setLastRunResult($workerResultDTO)
            ->setFinishedAt(new \DateTime())
            ->setStateValue($state);

        if ($workerResultDTO->timedOut) {
            $this->incrementCounter(eWorkerCounterKey::TIMEOUT);
        } elseif (!empty($workerResultDTO->error)) {
            $this->incrementCounter(eWorkerCounterKey::FAILED);
        } else {
            $this->incrementCounter(eWorkerCounterKey::SUCCESS);
        }

        return $this;
    }

    public function incrementCounter(eWorkerCounterKey $counterKey): static
    {
        $this->counters[$counterKey->value] = ($this->counters[$counterKey->value] ?? 0) + 1;
        return $this;
    }

    public function resetCounters(): static
    {
        foreach ($this->counters as $counterKey => $counterValue) {
            $this->counters[$counterKey] = 0;
        }
        return $this;
    }

    public function setStarted(): static
    {
        $this
            ->setStartedAt(new \DateTime())
            ->setFinishedAt(null)
            ->setNextRunAt((new \DateTime())->add(new \DateInterval($this->getRunInterval())))
            ->incrementCounter(eWorkerCounterKey::STARTED)
            ->removeState(eRunningState::Finished, eRunningState::Idle, eRunningState::Timeout, eRunningState::Error, eRunningState::New)
            ->addState(eRunningState::Running);

        return $this;
    }

    public function getRunInterval(): ?string
    {
        return $this->runInterval;
    }

    public function setRunInterval(?string $runInterval): static
    {
        $this->runInterval = $runInterval;

        return $this;
    }

    public function setIdle(): static
    {
        $this
            ->setState(eRunningState::Idle);
        return $this;
    }

    public function getApplication(): ?Application
    {
        return $this->application;
    }

    public function setApplication(?Application $application): static
    {
        $this->application = $application;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getFormatedNextRunAt(): \DateTimeInterface
    {
        return $this->getNextRunAt();
    }

    public function getNextRunAt(): ?\DateTimeInterface
    {
        return $this->nextRunAt;
    }

    public function setNextRunAt(?\DateTimeInterface $nextRunAt): static
    {
        $this->nextRunAt = $nextRunAt;

        return $this;
    }

    public function getProperties(): array
    {
        return self::uniqueProperties($this->properties);
    }

    public function setProperties(array $properties): static
    {
        $this->properties = self::uniqueProperties($properties);

        return $this;
    }

    /**
     * Sets the value of a property - the entry that already holds it is
     * updated, a new one is only added for a property the worker does not have.
     */
    public function setPropertyValue(string $propertyName, mixed $propertyValue): static
    {
        $this->properties = self::uniqueProperties([
            ...$this->properties,
            [gettype($propertyValue), $propertyName, $propertyValue],
        ]);

        return $this;
    }

    /**
     * Sets a property to a command definition - the worker runs it at the start of every
     * run and works with its result (AbstractWorker::resolveCommandProperties()).
     */
    public function setPropertyCommand(string $propertyName, array|string $definition): static
    {
        $this->properties = self::uniqueProperties([
            ...$this->properties,
            [self::PROPERTY_TYPE_COMMAND, $propertyName, $definition],
        ]);

        return $this;
    }

    public function isPropertyCommand(string $propertyName): bool
    {
        $entry = array_find($this->getProperties(), static fn($property) => self::propertyName($property) === $propertyName);

        return is_array($entry) && $entry[0] === self::PROPERTY_TYPE_COMMAND;
    }

    /**
     * Workers saved before setPropertyValue() updated in place hold some
     * properties several times. Removing them on load lets the next flush of
     * the worker write the cleaned list back.
     */
    #[ORM\PostLoad]
    public function removeDuplicateProperties(): void
    {
        $this->properties = self::uniqueProperties($this->properties);
    }

    /**
     * Every property once: a property found several times keeps the place of
     * its first entry and the value of its last one, the value that was set
     * most recently. Entries that are not [type, name, value] stay as they are.
     */
    private static function uniqueProperties(array $properties): array
    {
        $result = [];
        $positions = [];
        foreach ($properties as $key => $property) {
            $name = self::propertyName($property);
            if ($name === null) {
                $result[$key] = $property;
                continue;
            }
            if (array_key_exists($name, $positions)) {
                $result[$positions[$name]] = $property;
                continue;
            }
            $positions[$name] = $key;
            $result[$key] = $property;
        }

        return array_is_list($properties) ? array_values($result) : $result;
    }

    private static function propertyName(mixed $property): ?string
    {
        return is_array($property)
            && array_key_exists(1, $property)
            && array_key_exists(2, $property)
            && is_string($property[1])
            ? $property[1]
            : null;
    }

    public function getPriority(): ?int
    {
        return $this->priority;
    }

    public function setPriority(int $priority): static
    {
        $this->priority = $priority;

        return $this;
    }

    public function getReadableRunInterval(): ?string
    {
        return DateUtils::readableInterval($this->runInterval);
    }

    public function getRunIntervalHms(): ?string
    {
        return DateUtils::durationToHms($this->runInterval);
    }

    public function getRunIntervalInt(): ?int
    {

        return DateUtils::readableInterval($this->runInterval, 'array')['int'];
    }

    public function getRunIntervalUnit(bool $checkSingularPlural = true): ?string
    {
        return DateUtils::readableInterval($this->runInterval, 'array', $checkSingularPlural)['unit'];
    }

    public function getAvailableActions(): array
    {
        $actions = [];

        if (!$this->hasState(eRunningState::Idle)) {
            $actions[] = self::ACTION_SET_IDLE;
        }

        if ($this->isEnabled()) {
            $actions[] = self::ACTION_DISABLE;
        } else {
            $actions[] = self::ACTION_ENABLE;
        }

        return $actions;
    }

    /**
     * @return BadgeDTO[]
     */
    public function getBadges(BadgeRegister $badgeRegister): array
    {
        $resultBadges = [];
        $valid = !empty($this->getWorkerClass()) && class_exists($this->getWorkerClass()) && $this->getRunChains()->count() > 0;
        $isWaiting = false;
        $isWorking = false;

        if ($this->hasState(eRunningState::NoWork)) {
            $resultBadges[] = $badgeRegister->getBadge('no_work');
        }

        if ($this->hasState(eRunningState::Error) || !empty($this->getLastRunResult()->error)) {
            $resultBadges[] = $badgeRegister->getBadge('error');
        }

        if ($this->getLastRunResult()->startedAt === -1) {
            $resultBadges[] = $badgeRegister->getBadge('new');
        }

        if ($valid && $this->isWaiting()) {
            $isWaiting = true;
        }

        if ($this->hasState(eRunningState::Timeout)) {
            $resultBadges[] = $badgeRegister->getBadge('timeout');
        }

        if ($this->hasState(eRunningState::Running)) {
            $isWorking = true;
        }

        if ($valid && $this->hasState(eRunningState::Idle) || $this->hasState(eRunningState::Finished)) {
            $resultBadges[] = $badgeRegister->getBadge('idle');
        }

        if (!$this->isEnabled()) {
            $resultBadges[] = $badgeRegister->getBadge('disabled');
        }

        if (!$valid) {
            $resultBadges[] = $badgeRegister->getBadge('invalid');
        } else {
            if ($isWaiting) {
                if ($isWorking) {
                    $resultBadges[] = $badgeRegister->getBadge('to_slow');
                } else {
                    $resultBadges[] = $badgeRegister->getBadge('waiting');
                }
            } else {
                if ($isWorking) {
                    $resultBadges[] = $badgeRegister->getBadge('working');
                }
            }
        }

        return $resultBadges;
    }

    public function getWorkerClass(): ?string
    {
        return $this->workerClass;
    }

    public function setWorkerClass(string $workerClass): static
    {
        $this->workerClass = $workerClass;

        return $this;
    }

    /**
     * @return Collection<int, RunChain>
     */
    public function getRunChains(): Collection
    {
        return $this->runChains;
    }

    public function getLastRunResult(): WorkerResultDTO
    {
        return WorkerResultDTO::createFromString($this->lastRunResult);
    }

    public function setLastRunResult(WorkerResultDTO $lastRunResult): static
    {
        $this->lastRunResult = $lastRunResult->__toString();

        return $this;
    }

    public function addRunChain(RunChain $runChain): static
    {
        if (!$this->runChains->contains($runChain)) {
            $this->runChains->add($runChain);
        }

        return $this;
    }

    public function removeRunChain(RunChain $runChain): static
    {
        $this->runChains->removeElement($runChain);

        return $this;
    }

    /**
     * @return Collection<int, WorkerJobOptions>
     */
    public function getJobOptions(): Collection
    {
        return $this->jobOptions;
    }

    public function addJobOption(WorkerJobOptions $jobOption): static
    {
        if (!$this->jobOptions->contains($jobOption)) {
            $this->jobOptions->add($jobOption);
            $jobOption->setWorker($this);
        }

        return $this;
    }

    public function removeJobOption(WorkerJobOptions $jobOption): static
    {
        if ($this->jobOptions->removeElement($jobOption)) {
            // set the owning side to null (unless already changed)
            if ($jobOption->getWorker() === $this) {
                $jobOption->setWorker(null);
            }
        }

        return $this;
    }

    public function getRestRetries(bool $createIfNotExist = true, int $defaultRetryCounter = 3): int
    {
        $allowedRetries = $this->getProperty('allowed_retries', null);
        if (is_null($allowedRetries)) {
            $allowedRetries = $defaultRetryCounter;
            if ($createIfNotExist) {
                $this->setProperty('allowed_retries', $defaultRetryCounter);
            }
        }
        return $allowedRetries - $this->getCounter(eWorkerCounterKey::RETRY->value);
    }

    /**
     * @param eWorkerCounterKey $counterKey
     * @return int
     */
    public function getCounter(string $counterKey): int
    {
        return $this->counters[gettype($counterKey) === 'string' ? $counterKey : $counterKey->value] ?? 0;
    }

    public function getStore(): ?StoreDTO
    {
        return StoreDTO::fromArray($this->store ?? []);
    }

    public function setStore(?StoreDTO $store): static
    {
        $this->store = $store?->toArray();

        return $this;
    }

    public function getMaxRuntime(): ?int
    {
        return $this->getProperty('allowed_runtime', null);
    }
}
