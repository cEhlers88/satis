<?php

namespace Cehlers88\AnalyticsCore\Worker;

use Analytics\ENUM\eWorkerJobType;
use Analytics\Utils\UnitUtils;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Player\MacroPlayer;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Repository\WorkerRepository;
use Cehlers88\AnalyticsCore\Support\AbstractPropertyBag;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
use Cehlers88\AnalyticsCore\Support\Profiler;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Cehlers88\AnalyticsCore\Worker\Job\JobInterface;

/** Base class for background worker implementations. */
abstract class AbstractWorker extends AbstractPropertyBag implements WorkerInterface
{
    /**
     * When set, the journal of a run is only written if the run ended with
     * warnings or errors - successful runs leave no entry.
     */
    public const string PROPERTY_IGNORE_NO_ERROR_LOGS = 'ignore_no_error_logs';

    public array $environment = [];
    protected ?int $entityId = null;
    protected Application $_application;
    protected MacroPlayer $macroPlayer;
    protected bool $_jobsFinished = false;
    protected WorkerRepository $workerRepository;
    protected TrackingBufferRepository $trackingBufferRepository;
    private array $benchmark = [

    ];
    private int $_entityState;
    /**
     * @var $_jobs JobInterface[]
     */
    private array $_jobs = [];
    private float $startTime;
    private bool $_timeoutReached = false;

    private array $warnings = [];
    private array $resultMessages = [];
    private array $_sharedData = [];
    private bool $_wantToReRun = false;

    /**
     * The properties whose value is a command (Worker::PROPERTY_TYPE_COMMAND), with their
     * definitions - run at the start of every run, see resolveCommandProperties().
     *
     * @var array<string, mixed>
     */
    private array $commandProperties = [];

    /**
     * Configure the worker with the given properties.
     *
     * @param array $properties Configuration properties.
     * @return static
     */
    public function configure(array $properties): static
    {
        if (!$this->hasProperty('allowed_runtime')) {
            $this->addProperty(PropertyDTO::create('allowed_runtime', -1));
        }
        if (!$this->hasProperty(self::PROPERTY_IGNORE_NO_ERROR_LOGS)) {
            $this->addProperty(PropertyDTO::create(
                self::PROPERTY_IGNORE_NO_ERROR_LOGS,
                false,
                'bool',
                true,
                description: 'Write the journal only for runs with warnings or errors.'
            ));
        }

        $this->commandProperties = [];
        foreach ($properties as $property) {
            if (is_array($property) && ($property[0] ?? null) === Worker::PROPERTY_TYPE_COMMAND && is_string($property[1] ?? null)) {
                $this->commandProperties[$property[1]] = $property[2] ?? null;
            }
        }

        // a command property holds its definition until a run resolves it, so a mask
        // shows what is configured rather than what it came to last time
        $this->loadPropertyValues($properties, true);
        return $this;
    }

    /**
     * The properties whose value is a command, with their definitions.
     *
     * @return array<string, mixed>
     */
    public function getCommandProperties(): array
    {
        return $this->commandProperties;
    }

    /**
     * Runs the command of every command property and takes its result as the value of
     * the property - at the start of every run, so the run works with what the command
     * says right now. A command that fails is an error of the run.
     */
    protected function resolveCommandProperties(): void
    {
        if ($this->commandProperties === []) {
            return;
        }

        $commandPlayer = $this->macroPlayer->getMacroEnvironment()->getCommandPlayer();
        if (isset($this->_application)) {
            $commandPlayer->setApplication($this->_application);
        }

        foreach ($this->commandProperties as $name => $definition) {
            // run() hands back whatever is no command - a definition must never become the
            // value of a property unnoticed
            $definition = self::normalizeCommandDefinition($definition);
            if ($definition === null || !$commandPlayer->describesCommands($definition)) {
                $this->setError(sprintf('Property "%s": its value is no command definition.', $name));
                continue;
            }
            try {
                $this->setPropertyValue($name, $commandPlayer->run($definition), true);
            } catch (\Throwable $exception) {
                $this->setError(sprintf('Property "%s": its command failed: %s', $name, $exception->getMessage()));
            }
        }
    }

    /**
     * A command definition as the command player takes it: a list or a [name, arguments]
     * pair as it is, JSON text decoded, a bare command name as a call without arguments.
     */
    private static function normalizeCommandDefinition(mixed $definition): ?array
    {
        if (is_array($definition)) {
            return $definition === [] ? null : $definition;
        }
        if (!is_string($definition) || trim($definition) === '') {
            return null;
        }

        $decoded = json_decode(trim($definition), true);
        if (is_array($decoded)) {
            return $decoded === [] ? null : $decoded;
        }

        return [is_string($decoded) ? $decoded : trim($definition), []];
    }

    /**
     * Whether successful runs leave no journal entry. A worker that never had
     * the property set does log them; values saved through the worker card
     * arrive as strings, so "false", "0" and "" count as not set.
     */
    public function ignoresNoErrorLogs(): bool
    {
        $value = $this->getPropertyValue(self::PROPERTY_IGNORE_NO_ERROR_LOGS, false);

        return is_bool($value) ? $value : filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }

    public function addResultMessage(string $message): self
    {
        $this->resultMessages[] = $message;
        return $this;
    }

    public function clearResultMessages(): self
    {
        $this->resultMessages = [];
        return $this;
    }

    /**
     * @return array<string>
     */
    public function getRequiredJobs(): array
    {
        return [];
    }

    /**
     * Handle a worker error.
     *
     * @param string $error Error message.
     * @param array $data Additional error data.
     */
    public function handleError(string $error, array $data): void
    {
        $workerEntity = $this->workerRepository->find($this->entityId);
        $workerEntity->setState(eRunningState::FatalError, eRunningState::Error);
        $this->workerRepository->save($workerEntity, true);

        $trackingBuffer = new TrackingBuffer();
        $trackingBuffer
            ->setData([
                'key' => 'Worker.error',
                'error' => $error,
                'data' => $data
            ])
            ->setTimestamp(new \DateTime())
            ->setState(eTrackingBufferState::NEW)
            ->setNote('Unknown error occurred: ' . $error . ' set state to Fatal')
            ->setApplication($workerEntity->getApplication());

        $this->trackingBufferRepository->save($trackingBuffer, true);
    }

    /**
     * Add a job to the worker.
     *
     * @param AbstractWorkerJob $job The job to add.
     * @return AbstractWorker
     */
    public function addJob(AbstractWorkerJob $job): AbstractWorker
    {
        $this->_jobs[] = $job;
        return $this;
    }

    /** Check whether the worker is allowed to run. */
    public function allowRun(): bool
    {
        return $this->_entityState !== eRunningState::Error;
    }

    /** Get the number of registered jobs. */
    public function countJobs(): int
    {
        return count($this->_jobs);
    }

    /**
     * Execute the worker and all registered jobs.
     *
     * @return WorkerResultDTO
     */
    final public function execute(): WorkerResultDTO
    {
        $this->onExecutionStart();
        $this->resolveCommandProperties();

        $result = new WorkerResultDTO([
            'allowed_runtime' => $this->getPropertyValue('allowed_runtime'),
            'environment' => $this->environment,
            'properties' => $this->getProperties(),
        ]);

        if (!$this->validate() && !$this->hasError()) {
            $this->setError('Invalid properties');
        }

        $workingObjects = [];

        if (!$this->hasError()) {
            $profiler = Profiler::run(function () use (&$workingObjects) {
                try {
                    $workingObjects = $this->getWorkingObjects();
                } catch (\Exception $e) {
                    $this->setError($e->getMessage());
                }
            })['profiler'];

            $this->setBenchmarkValue('fetch_working_objects_duration', $profiler->getReadableDuration());
        }

        if (empty($workingObjects)) {
            $this->logInfo('No working objects found. Skipping working.', true);
        }

        $result->workerInfos['working_objects_count'] = count($workingObjects);

        if (!$this->checkTimeoutReached() && !$this->hasError()) {
            $this->logInfo('Start handle working objects.', true);

            $profiler = new Profiler();
            $profiler->start();
            try {
                $workingObjectResult = $this->handleWorkingObjects($workingObjects);
            } catch (\Exception $e) {
                $this->setError('Error while handle working objects: ' . $e->getMessage());
            }
            $profiler->stop();

            $this->setBenchmarkValue('handle_working_objects_duration', $profiler->getReadableDuration());
        }

        $result->runtime = microtime(true) - $this->startTime;
        $this->logInfo('Finished working after ' . UnitUtils::formatDuration($result->runtime, 's') . '.', true);
        $result->timedOut = $this->reachedTimeout();
        $result->error = [];
        $result->warnings = $this->getWarnings();
        $result->messages = $this->getResultMessages();
        foreach ($this->errors as $error) {
            $result->error[] = $error->message;
        }

        $result->endedAt = (new \DateTime())->getTimestamp();

        $this->onExecutionEnd();

        $result->workerInfos[WorkerResultDTO::KEY_BENCHMARK] = $this->getBenchmark();

        return $result;
    }

    public function onExecutionStart(): static
    {
        $this->macroPlayer->getMacroEnvironment()->getVariablesStoreProvider()->clearContext(eMacroVariableContext::WORKER);

        $this->startTime = microtime(true);
        $this->_timeoutReached = false;
        $this->_sharedData = [];
        $this->_logger->addTabSpace(3);
        $this->getLogger()->startGroup('Execution', [
            'jobs-count' => count($this->_jobs),
            'start-time' => $this->startTime,
        ]);
        return $this;
    }

    /** Get the objects to work on. */
    abstract public function getWorkingObjects(): array;

    /** Set a benchmark value. */
    public function setBenchmarkValue(string $key, mixed $value): static
    {
        $this->benchmark[$key] = $value;
        return $this;
    }

    private function checkTimeoutReached(): bool
    {
        if ($this->_timeoutReached) {
            return true;
        }

        $runtime = microtime(true) - $this->startTime;
        $this->_timeoutReached = $runtime > $this->getPropertyValue('allowed_runtime');

        if ($this->_timeoutReached) {
            $this->logInfo(sprintf('Timeout (max %d) reached. Stop working.', $this->getPropertyValue('allowed_runtime')), true);
        }

        return $this->_timeoutReached;
    }

    /**
     * Process all working objects through registered jobs.
     *
     * @param array $workingObjects The objects to process.
     * @return array
     */
    public function handleWorkingObjects(array $workingObjects): array
    {
        $this->_jobsFinished = false;
        $results = [];

        if (count($workingObjects) === 0) {
            return $results;
        }

        $validJobsCount = 0;
        foreach ($this->_jobs as $job) {
            if ($job->getType() === eWorkerJobType::UNKNOWN) {
                $this->logWarning(sprintf('Job "%s" has type "%s". Jobs with this type will be ignored.', $job->getName(), eWorkerJobType::UNKNOWN->name));
                continue;
            }
            $validJobsCount++;
        }

        if ($validJobsCount === 0) {
            $this->logInfo('No valid jobs found. Skipping working objects.');
            return $results;
        }

        try {
            $jobsResults = $this->handleJobsByType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_START, $workingObjects);
        } catch (\Exception $e) {
            $this->setError('Fehler: ' . $e->getMessage());
        }

        if ($this->hasError()) {
            $this->onJobsComplete();
            return $results;
        }

        if ($this->checkTimeoutReached()) {
            if ($this->handleTimeoutReached('Before start working on each object.') === false) {
                return $results;
            }
        }

        foreach ($workingObjects as $workingObject) {
            if ($this->checkTimeoutReached()) {
                $this->handleTimeoutReached('Timeout reached while working on objects.');
                break;
            }
            if ($this->handleWorkingObjectStart($workingObject) === false) {
                continue;
            }

            try {
                foreach ($this->handleJobsByType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION, $workingObject) as $handleResult) {
                    $jobsResults[] = $handleResult;

                    if ($this->hasError()) {
                        $this->onJobsComplete();
                        return $jobsResults;
                    }
                }
            } catch (\Exception $e) {
                $this->setError($e->getMessage());
            }
            if ($this->checkTimeoutReached()) {
                $this->handleTimeoutReached('Timeout reached while working on objects.');
                break;
            }
            $this->handleWorkingObjectEnd($workingObject, $jobsResults);
        }

        if ($this->checkTimeoutReached()) {
            $this->handleTimeoutReached(sprintf('Timeout (max %d) reached after working on all objects but before finishing. Stop worker.', $this->getPropertyValue('allowed_runtime')));
        } else {
            $this->handleJobsByType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_END, $workingObjects);
        }
        $this->logInfo('Jobs finished', true);

        $this->checkTimeoutReached();
        $this->onJobsComplete();

        return $results;
    }

    public function logWarning(string $message, bool $onlyInDebugMode = false): static
    {
        $this->warnings[] = $message;
        return parent::logWarning($message, $onlyInDebugMode);
    }

    /** Get the worker name. */
    public function getName(): string
    {
        return static::class;
    }

    private function handleJobsByType(eWorkerJobType $type, mixed $workingData): array
    {
        $jobsResults = [];
        foreach ($this->_jobs as $job) {
            if ($this->checkTimeoutReached()) {
                $this->handleTimeoutReached(sprintf('Timeout (max %d) reached. Stop working on jobs.', $this->getPropertyValue('allowed_runtime')));
                return $jobsResults;
            }
            if ($job->getType() !== $type) {
                continue;
            }

            $this->macroPlayer->getMacroEnvironment()->getVariablesStoreProvider()->clearContext(eMacroVariableContext::JOB);
            $job
                ->setWorker($this)
                ->setLogger($this->_logger)
                ->setMacroProvider($this->macroPlayer);

            if (is_array($workingData)) {
                $job->setWorkingObjects($workingData);
            } else {
                $job->setWorkingObject($workingData);
            }

            try {
                $job->setMaxRuntime($this->getPropertyValue('allowed_runtime') - (microtime(true) - $this->startTime));
                $runResult = $job->run();
                $jobsResults[] = $runResult;

            } catch (\Exception $e) {
                $this->setError($e->getMessage());
                return $jobsResults;
            }

            if ($job->hasError()) {
                $this->setError($job->getError());
                return $jobsResults;
            }
        }
        return $jobsResults;
    }

    /**
     * Handle timeout reached.
     *
     * @param string $logMessage The log message to log.
     * @return bool Return true if the worker should continue working.
     */
    protected function handleTimeoutReached(string $logMessage): bool
    {
        $this->logWarning(sprintf('Timeout (%d max) reached. ', $this->getPropertyValue('allowed_runtime')) . $logMessage);
        return false;
    }

    /** Called when all jobs have completed. */
    protected function onJobsComplete(): void
    {
        $this->_jobsFinished = true;
    }

    /**
     * Called before processing a single working object.
     *
     * @param mixed $workingObject The object about to be processed.
     * @return bool False to skip this object.
     */
    public function handleWorkingObjectStart(mixed $workingObject): bool
    {
        return true;
    }

    /**
     * Called after processing a single working object.
     *
     * @param mixed $workingObject The object that was processed.
     * @param array $jobResults Results from the jobs that ran.
     */
    public function handleWorkingObjectEnd(mixed $workingObject, array $jobResults): void
    {
    }

    /** Check whether the worker reached its timeout. */
    public function reachedTimeout(): bool
    {
        return $this->_timeoutReached;
    }

    public function getWarnings(): array
    {
        return $this->warnings;
    }

    public function getResultMessages(): array
    {
        return $this->resultMessages;
    }

    public function onExecutionEnd(): static
    {
        $this->getLogger()->endGroup('Execution');
        return $this;
    }

    /** Get all benchmark data. */
    public function getBenchmark(): array
    {
        return $this->benchmark;
    }

    public function hasWarnings(): bool
    {
        return count($this->warnings) > 0;
    }

    /**
     * Build an initial WorkerResultDTO for the given working objects.
     *
     * @param array $workingObjects The objects to work on.
     * @return WorkerResultDTO
     */
    public function buildWorkerResultPrototype(array $workingObjects): WorkerResultDTO
    {
        $result = new WorkerResultDTO();
        $result->workerInfos['working_objects_count'] = count($workingObjects);

        return $result;
    }

    /** Get the application ID. */
    public function getApplicationId(): int
    {
        return $this->_application->getId();
    }

    /** Get the worker version. */
    public function getVersion(): string
    {
        return '0.0.1';
    }

    /**
     * Initialize the worker from a Worker entity.
     *
     * @param Worker $workerEntity The worker entity.
     * @param LoggerInterface|null $logger Optional logger instance.
     * @param bool $debugMode Whether to enable debug mode.
     * @return AbstractWorker
     */
    public function init(Worker $workerEntity, ?LoggerInterface $logger = null, bool $debugMode = false): AbstractWorker
    {
        $this->entityId = $workerEntity->getId();
        $this->enableDebugMode($debugMode);
        $this->_application = $workerEntity->getApplication();
        $this->_entityState = $workerEntity->getStateValue();

        if ($logger !== null) {
            $this->setLogger($logger);
        }

        // Only now debug mode and logger belong to this run.
        $this->logInfo(sprintf('Initializing worker "%s" (id=%d)', $workerEntity->getName(), $workerEntity->getId()), true);

        return $this;
    }

    /** Set the macro player instance. */
    public function setMacroPlayer(MacroPlayer $macroPlayer): AbstractWorker
    {
        $this->macroPlayer = $macroPlayer;
        return $this;
    }

    /** Get all registered jobs. */
    public function getJobs(): array
    {
        return $this->_jobs;
    }

    public function setTrackingBufferRepository(TrackingBufferRepository $trackingBufferRepository): static
    {
        $this->trackingBufferRepository = $trackingBufferRepository;
        return $this;
    }

    public function setWorkerRepository(WorkerRepository $workerRepository): AbstractWorker
    {
        $this->workerRepository = $workerRepository;
        return $this;
    }

    public function getJobByClassName(string $className): ?JobInterface
    {
        foreach ($this->_jobs as $job) {
            if ($job instanceof $className) {
                return $job;
            }
        }
        return null;
    }

    /**
     * Retrieve a value from the temporary shared data store.
     *
     * @param string $key The key to retrieve.
     * @param mixed $default Default value when the key does not exist.
     * @return mixed
     */
    public function getSharedData(string $key, mixed $default = null): mixed
    {
        if (array_key_exists($key, $this->_sharedData)) {
            return $this->_sharedData[$key];
        }

        return $default;
    }

    /**
     * Store a value in the temporary shared data store for the duration of the worker run.
     *
     * @param string $key The key to store the value under.
     * @param mixed $value The value to store.
     * @return static
     */
    public function setSharedData(string $key, mixed $value): static
    {
        $this->_sharedData[$key] = $value;
        return $this;
    }

    /**
     * Check whether the temporary shared data store contains the given key.
     *
     * @param string $key The key to check.
     * @return bool
     */
    public function hasSharedData(string $key): bool
    {
        return array_key_exists($key, $this->_sharedData);
    }

    /**
     * Remove a single entry from the temporary shared data store.
     *
     * @param string $key The key to remove.
     * @return static
     */
    public function removeSharedData(string $key): static
    {
        unset($this->_sharedData[$key]);
        return $this;
    }

    /**
     * Clear the entire temporary shared data store.
     *
     * @return static
     */
    public function clearSharedData(): static
    {
        $this->_sharedData = [];
        return $this;
    }

    public function wantToReRun(): bool
    {
        return $this->_wantToReRun;
    }

    public function setWantToReRun(bool $wantToReRun): static
    {
        $this->_wantToReRun = $wantToReRun;
        return $this;
    }

    private function getBenchmarkAttributes(): string
    {
        $result = '';
        foreach ($this->benchmark as $key => $value) {
            $result .= sprintf('%s="%s" ', $key, $value);
        }
        return $result;
    }
}