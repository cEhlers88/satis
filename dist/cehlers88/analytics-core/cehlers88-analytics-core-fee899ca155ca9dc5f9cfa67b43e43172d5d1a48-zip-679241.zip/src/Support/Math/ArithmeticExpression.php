<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Support\Math;

/**
 * Evaluates an arithmetic expression such as `(ist - soll) / soll * 100` or
 * `round({netto} * 1.19, 2)` - without eval(): a small recursive descent parser
 * that knows numbers, names, + - * / % ^, parentheses and a few functions.
 *
 * Names are handed to the resolver, which returns their value; `{name}` is the
 * same as `name` and allows names a bare word could not hold. Every value has to
 * be a number - "12.5" from a form is one, "n/a" is not.
 */
final class ArithmeticExpression
{
    /** @var array<string, array{0: int, 1: int|null}> name => [min arguments, max arguments (null: any)] */
    private const array FUNCTIONS = [
        'abs' => [1, 1],
        'ceil' => [1, 1],
        'floor' => [1, 1],
        'max' => [1, null],
        'min' => [1, null],
        'round' => [1, 2],
        'sqrt' => [1, 1],
    ];

    /** @var list<array{type: string, value: string, position: int}> */
    private array $tokens = [];
    private int $index = 0;
    /** @var callable(string): mixed */
    private $resolver;

    private function __construct(callable $resolver)
    {
        $this->resolver = $resolver;
    }

    /**
     * @param callable(string): mixed $resolver the value of a name - throws when there is none
     *
     * @throws \InvalidArgumentException when the expression cannot be read or calculated
     */
    public static function evaluate(string $expression, callable $resolver): int|float
    {
        $calculator = new self($resolver);
        $calculator->tokens = self::tokenize($expression);
        if ($calculator->tokens === []) {
            throw new \InvalidArgumentException('The expression is empty.');
        }

        $result = $calculator->parseSum();
        $rest = $calculator->tokens[$calculator->index] ?? null;
        if ($rest !== null) {
            throw new \InvalidArgumentException(sprintf('Unexpected "%s" at position %d.', $rest['value'], $rest['position'] + 1));
        }

        return $result;
    }

    /**
     * The names an expression uses, in order of appearance - without the functions.
     *
     * @return list<string>
     */
    public static function namesOf(string $expression): array
    {
        $tokens = self::tokenize($expression);
        $names = [];
        foreach ($tokens as $position => $token) {
            $next = $tokens[$position + 1] ?? null;
            if ($token['type'] === 'name' && !($next !== null && $next['type'] === 'operator' && $next['value'] === '(')) {
                $names[] = $token['value'];
            }
        }

        return array_values(array_unique($names));
    }

    /**
     * @return list<array{type: string, value: string, position: int}>
     */
    private static function tokenize(string $expression): array
    {
        $tokens = [];
        $length = strlen($expression);
        $position = 0;

        while ($position < $length) {
            $char = $expression[$position];

            if (ctype_space($char)) {
                $position++;
                continue;
            }
            if (preg_match('/\G(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/', $expression, $match, 0, $position) === 1) {
                $tokens[] = ['type' => 'number', 'value' => $match[0], 'position' => $position];
                $position += strlen($match[0]);
                continue;
            }
            if ($char === '{') {
                $end = strpos($expression, '}', $position);
                $name = $end === false ? '' : trim(substr($expression, $position + 1, $end - $position - 1));
                if ($name === '') {
                    throw new \InvalidArgumentException(sprintf('Unclosed or empty "{" at position %d.', $position + 1));
                }
                $tokens[] = ['type' => 'name', 'value' => $name, 'position' => $position];
                $position = $end + 1;
                continue;
            }
            if (preg_match('/\G[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z0-9_]+)*/', $expression, $match, 0, $position) === 1) {
                $tokens[] = ['type' => 'name', 'value' => $match[0], 'position' => $position];
                $position += strlen($match[0]);
                continue;
            }
            if (str_contains('+-*/%^(),', $char)) {
                $tokens[] = ['type' => 'operator', 'value' => $char, 'position' => $position];
                $position++;
                continue;
            }

            throw new \InvalidArgumentException(sprintf('Unexpected "%s" at position %d.', $char, $position + 1));
        }

        return $tokens;
    }

    private function parseSum(): int|float
    {
        $result = $this->parseProduct();
        while (in_array($this->peek(), ['+', '-'], true)) {
            $operator = $this->next()['value'];
            $operand = $this->parseProduct();
            $result = $operator === '+' ? $result + $operand : $result - $operand;
        }

        return $result;
    }

    private function parseProduct(): int|float
    {
        $result = $this->parseUnary();
        while (in_array($this->peek(), ['*', '/', '%'], true)) {
            $operator = $this->next()['value'];
            $operand = $this->parseUnary();
            if ($operator === '*') {
                $result *= $operand;
                continue;
            }
            if ((float)$operand === 0.0) {
                throw new \InvalidArgumentException('Division by zero.');
            }
            $result = match ($operator) {
                '/' => $result / $operand,
                // % of PHP cuts floats to integers - 7.5 % 2 is 1.5, not 1
                default => is_int($result) && is_int($operand) ? $result % $operand : fmod($result, $operand),
            };
        }

        return $result;
    }

    /** A sign binds weaker than a power: -2^2 is -4. */
    private function parseUnary(): int|float
    {
        if (in_array($this->peek(), ['+', '-'], true)) {
            $operator = $this->next()['value'];
            $operand = $this->parseUnary();

            return $operator === '-' ? -$operand : $operand;
        }

        return $this->parsePower();
    }

    private function parsePower(): int|float
    {
        $base = $this->parsePrimary();
        if ($this->peek() !== '^') {
            return $base;
        }
        $this->next();
        // right-associative: 2^3^2 is 2^9
        $exponent = $this->parseUnary();
        $result = $base ** $exponent;
        if (is_float($result) && (is_nan($result) || is_infinite($result))) {
            throw new \InvalidArgumentException('The power cannot be calculated.');
        }

        return $result;
    }

    private function parsePrimary(): int|float
    {
        $token = $this->next();
        if ($token === null) {
            throw new \InvalidArgumentException('The expression ends too early.');
        }

        if ($token['type'] === 'number') {
            return self::toNumber($token['value'], $token['value']);
        }

        if ($token['type'] === 'operator' && $token['value'] === '(') {
            $result = $this->parseSum();
            $this->expect(')');

            return $result;
        }

        if ($token['type'] === 'name') {
            if ($this->peek() === '(') {
                return $this->parseFunction($token);
            }

            return self::toNumber(($this->resolver)($token['value']), $token['value']);
        }

        throw new \InvalidArgumentException(sprintf('Unexpected "%s" at position %d.', $token['value'], $token['position'] + 1));
    }

    /**
     * @param array{type: string, value: string, position: int} $token
     */
    private function parseFunction(array $token): int|float
    {
        $name = strtolower($token['value']);
        if (!isset(self::FUNCTIONS[$name])) {
            throw new \InvalidArgumentException(sprintf(
                'Unknown function "%s" - known are %s.', $token['value'], implode(', ', array_keys(self::FUNCTIONS))
            ));
        }

        $this->expect('(');
        $arguments = [];
        if ($this->peek() !== ')') {
            $arguments[] = $this->parseSum();
            while ($this->peek() === ',') {
                $this->next();
                $arguments[] = $this->parseSum();
            }
        }
        $this->expect(')');

        [$min, $max] = self::FUNCTIONS[$name];
        if (count($arguments) < $min || ($max !== null && count($arguments) > $max)) {
            throw new \InvalidArgumentException(sprintf('Wrong number of arguments for %s().', $name));
        }

        return match ($name) {
            'abs' => abs($arguments[0]),
            'ceil' => ceil($arguments[0]),
            'floor' => floor($arguments[0]),
            'max' => max($arguments),
            'min' => min($arguments),
            'round' => round($arguments[0], (int)($arguments[1] ?? 0)),
            'sqrt' => $arguments[0] < 0
                ? throw new \InvalidArgumentException('The square root of a negative number cannot be calculated.')
                : sqrt($arguments[0]),
        };
    }

    private static function toNumber(mixed $value, string $name): int|float
    {
        if (is_int($value) || is_float($value)) {
            return $value;
        }
        if (is_string($value) && is_numeric(trim($value))) {
            return trim($value) + 0;
        }
        if (is_bool($value)) {
            return (int)$value;
        }

        throw new \InvalidArgumentException(sprintf(
            '"%s" is no number (%s).', $name, is_scalar($value) ? var_export($value, true) : get_debug_type($value)
        ));
    }

    /** The operator that comes next - null for a number, a name or the end. */
    private function peek(): ?string
    {
        $token = $this->tokens[$this->index] ?? null;

        return $token !== null && $token['type'] === 'operator' ? $token['value'] : null;
    }

    /** @return array{type: string, value: string, position: int}|null */
    private function next(): ?array
    {
        return $this->tokens[$this->index++] ?? null;
    }

    private function expect(string $value): void
    {
        $token = $this->next();
        if ($token === null || $token['value'] !== $value || $token['type'] !== 'operator') {
            throw new \InvalidArgumentException($token === null
                ? sprintf('"%s" is missing at the end.', $value)
                : sprintf('Expected "%s" at position %d.', $value, $token['position'] + 1));
        }
    }
}
