<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Support;

use Cehlers88\AnalyticsCore\Provider\VariablesProvider;

/**
 * The arguments of a function (the `arguments` of the macro "function") and the check of what a
 * call (the macro "call") hands over.
 *
 * They are declared the way procedures declare theirs (ProcedureArguments): tuples
 * `[type, name, default?, meta?]` or objects `{name, type, required, default, command, description}`.
 * A call has to give every required argument, each value has to be of the declared type - text
 * that reads as one ("5" for an integer) is taken as that type - and, as soon as a function
 * declares arguments, a call may not hand over names it does not know: a typo would otherwise
 * pass silently and the argument take its default.
 */
final class FunctionArguments
{
    /**
     * The declared arguments, each with everything spelled out.
     *
     * @return list<array{name: string, type: string, required: bool, default: mixed, command: bool, description: string}>
     *
     * @throws \InvalidArgumentException when the declaration cannot be read
     */
    public static function declare(string $function, mixed $stored): array
    {
        if (is_string($stored)) {
            $stored = trim($stored) === '' ? [] : json_decode($stored, true);
            if (!is_array($stored)) {
                throw new \InvalidArgumentException(sprintf('Function "%s": the arguments are no list.', $function));
            }
        }
        if ($stored === null) {
            return [];
        }
        if (is_object($stored)) {
            $stored = json_decode((string)json_encode($stored), true);
        }
        if (!is_array($stored)) {
            throw new \InvalidArgumentException(sprintf('Function "%s": the arguments are no list.', $function));
        }
        // a list of one is handed to the macro as its only entry (AbstractMacro::execute)
        if (self::isSingleDeclaration($stored)) {
            $stored = [$stored];
        }

        $arguments = ProcedureArguments::read($stored);
        $names = [];
        foreach ($arguments as $argument) {
            $key = mb_strtolower($argument['name']);
            if (in_array($key, $names, true)) {
                throw new \InvalidArgumentException(sprintf('Function "%s": the argument "%s" is declared twice.', $function, $argument['name']));
            }
            $names[] = $key;
        }

        return $arguments;
    }

    /**
     * The values the function starts with: every declared argument - given, or its default -
     * and, when nothing is declared, whatever the call handed over.
     *
     * @param list<array{name: string, type: string, required: bool, default: mixed, command: bool, description: string}> $declared
     * @param array<string|int, mixed> $given
     * @param callable(mixed): mixed $runCommands runs a command default
     * @return array<string, mixed>
     *
     * @throws \InvalidArgumentException naming every argument that is missing or invalid
     */
    public static function resolve(string $function, array $declared, array $given, callable $runCommands): array
    {
        if ($declared === []) {
            return array_filter($given, static fn($value): bool => !self::isUnset($value));
        }

        $values = [];
        $problems = [];
        foreach ($declared as $argument) {
            $name = $argument['name'];
            $isGiven = array_key_exists($name, $given) && !self::isUnset($given[$name]);
            $value = $isGiven ? $given[$name] : null;
            unset($given[$name]);

            if (!$isGiven) {
                if ($argument['required']) {
                    $problems[] = sprintf('the argument "%s" (%s) is required but not given', $name, $argument['type']);
                    continue;
                }
                $value = $argument['command'] ? $runCommands($argument['default']) : $argument['default'];
            }

            $typed = self::typed($argument['type'], $value);
            if ($typed === self::INVALID) {
                $problems[] = sprintf(
                    'the %s "%s" has to be %s, %s is not',
                    $isGiven ? 'argument' : 'default of',
                    $name,
                    self::article($argument['type']),
                    self::describe($value)
                );
                continue;
            }
            $values[$name] = $typed;
        }

        foreach (array_keys($given) as $name) {
            $problems[] = sprintf(
                'there is no argument "%s" (declared: %s)',
                $name,
                implode(', ', array_column($declared, 'name'))
            );
        }

        if ($problems !== []) {
            throw new \InvalidArgumentException(sprintf('Function "%s": %s.', $function, implode('; ', $problems)));
        }

        return $values;
    }

    private const INVALID = "\0invalid\0";

    /** The value as the declared type, INVALID when it is none. */
    private static function typed(string $type, mixed $value): mixed
    {
        $text = is_string($value) ? trim($value) : null;

        switch ($type) {
            case 'string':
                return is_string($value) || is_int($value) || is_float($value) ? (string)$value : self::INVALID;
            case 'integer':
                if (is_int($value)) {
                    return $value;
                }
                if (is_float($value) && floor($value) === $value) {
                    return (int)$value;
                }
                return $text !== null && preg_match('/^-?\d+$/', $text) === 1 ? (int)$text : self::INVALID;
            case 'float':
                if (is_int($value) || is_float($value)) {
                    return (float)$value;
                }
                return $text !== null && is_numeric($text) ? (float)$text : self::INVALID;
            case 'boolean':
                if (is_bool($value)) {
                    return $value;
                }
                if ($value === 0 || $value === 1) {
                    return $value === 1;
                }
                $flag = $text === null || $text === '' ? null : filter_var($text, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                return $flag ?? self::INVALID;
            case 'array':
                if (is_array($value)) {
                    return $value;
                }
                if (is_object($value)) {
                    return json_decode((string)json_encode($value), true);
                }
                $decoded = $text === null || $text === '' ? null : json_decode($text, true);
                return is_array($decoded) ? $decoded : self::INVALID;
            default:
                return $value;
        }
    }

    /** Not given: missing, null, or a variable get_var did not find. */
    private static function isUnset(mixed $value): bool
    {
        return $value === null || $value === VariablesProvider::UNDEFINED_VAR;
    }

    /** One declaration on its own - `[type, name, ...]` or `{name, ...}` - rather than a list of them. */
    private static function isSingleDeclaration(array $stored): bool
    {
        return array_is_list($stored)
            ? isset($stored[0], $stored[1]) && is_string($stored[0]) && is_string($stored[1])
            : array_key_exists('name', $stored);
    }

    private static function article(string $type): string
    {
        return ($type === 'integer' || $type === 'array' ? 'an ' : 'a ') . $type;
    }

    private static function describe(mixed $value): string
    {
        return match (true) {
            $value === null => 'nothing',
            is_bool($value) => $value ? 'true' : 'false',
            is_string($value) => '"' . (mb_strlen($value) > 40 ? mb_substr($value, 0, 40) . '…' : $value) . '"',
            is_int($value), is_float($value) => (string)$value,
            is_array($value) => 'a list',
            default => 'a ' . get_debug_type($value),
        };
    }
}
