<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Support\MonitoringRule;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;

/**
 * Fires when the monitored value rose by at least a given amount within a
 * given timespan - an error counter that grows by 10 within an hour, a
 * temperature that climbs 5 degrees within 15 minutes.
 *
 * The rise is the current value minus the lowest value seen within the
 * timespan, so a counter that is reset in between does not hide a new rise.
 * The value at the start of the timespan is the last one measured at or before
 * it; the samples live in the statistic options of the monitoring, so the
 * timespan does not depend on the length of the statistic history, and only
 * the samples that can still be the lowest value are kept.
 *
 * Like RangeCheckMonitoringRule the commands run once per crossing: onIncrease
 * when the rise is reached, onRecover when it is no longer.
 */
class IncreaseCheckMonitoringRule extends AbstractMonitoringRule
{
    public const string MODE_ABSOLUTE = 'absolute';
    public const string MODE_PERCENT = 'percent';

    /** Key of the rule's state inside the statistic options. */
    public const string OPTIONS_KEY = 'increaseCheck';

    /** Bounds the stored samples of a short run interval with a long timespan. */
    public const int MAX_SAMPLES = 1000;

    private ?float $increase = null;
    private bool $triggered = false;
    private string $reason = 'unbekannt';

    public function __construct(
        private CommandPlayer         $player,
        private MacroEnvironment      $macroEnvironment,
        private ApplicationRepository $applicationRepository,
    )
    {
    }

    public function execute(): self
    {
        $options = $this->getStatisticOptions();
        $state = $options[self::OPTIONS_KEY] ?? [];
        $wasTriggered = (bool)($state['triggered'] ?? false);
        $this->triggered = $wasTriggered;

        $value = $this->_attributeToCheck->getValue();
        if (!is_numeric($value)) {
            $this->reason = sprintf('self(%s) kein Zahlenwert', (string)$value);
            return $this;
        }

        $now = $this->now();
        $samples = self::keepSamples(
            [...self::validSamples($state['samples'] ?? []), [$now, (float)$value]],
            $now - self::timespanSeconds((string)$this->_arguments['timespan'])
        );

        $this->increase = self::measureIncrease($samples, $this->mode());
        $this->triggered = $this->increase !== null && $this->increase >= (float)$this->_arguments['increase'];
        $this->reason = sprintf(
            'self(%s) %s (+%s%s in %s, Schwelle %s)',
            $value,
            $this->triggered ? 'increase' : 'normal',
            $this->increase === null ? '?' : round($this->increase, 4),
            $this->mode() === self::MODE_PERCENT ? '%' : '',
            $this->_arguments['timespan'],
            $this->_arguments['increase']
        );

        $options[self::OPTIONS_KEY] = ['samples' => $samples, 'triggered' => $this->triggered];
        $this->setStatisticOptions($options);

        if ($this->triggered !== $wasTriggered) {
            $this->runCommands($this->_arguments[$this->triggered ? 'onIncrease' : 'onRecover'] ?? []);
        }

        return $this;
    }

    /**
     * The required arguments come from the definitions; the timespan has to be
     * a duration DateInterval understands as well.
     */
    public function validateArguments(array $arguments): bool
    {
        if (!parent::validateArguments($arguments)) {
            return false;
        }

        // A rise of at least zero would always be reached.
        if (!is_numeric($arguments['increase'] ?? null) || (float)$arguments['increase'] <= 0) {
            return false;
        }
        if (!in_array($arguments['mode'] ?? self::MODE_ABSOLUTE, [self::MODE_ABSOLUTE, self::MODE_PERCENT, null, ''], true)) {
            return false;
        }
        foreach (['onIncrease', 'onRecover'] as $commands) {
            // What the command player can run - a command list or a definition string.
            if (!in_array(gettype($arguments[$commands] ?? null), ['NULL', 'array', 'string'], true)) {
                return false;
            }
        }

        try {
            return self::timespanSeconds((string)($arguments['timespan'] ?? '')) > 0;
        } catch (\Exception) {
            return false;
        }
    }

    public function getStatisticDetails(): array
    {
        return [
            ...parent::getStatisticDetails(),
            'increase' => $this->increase,
            'triggered' => $this->triggered ? 1 : 0,
            'reason' => $this->reason,
        ];
    }

    public function getArgumentDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'increase',
                value: null,
                type: 'float',
                label: 'Mindestanstieg',
                description: 'Steigt der Wert innerhalb der Zeitspanne um mindestens so viel, schlägt die Regel an.'
            ),
            PropertyDTO::create(
                name: 'timespan',
                value: null,
                type: 'string',
                label: 'Zeitspanne',
                description: 'ISO-8601-Dauer, in der der Anstieg erreicht sein muss, z. B. PT15M, PT1H oder P1D.'
            ),
            PropertyDTO::create(
                name: 'mode',
                value: self::MODE_ABSOLUTE,
                type: 'string',
                isOptional: true,
                label: 'Anstieg in',
                description: 'Absolut in der Einheit des Werts oder in Prozent des niedrigsten Werts der Zeitspanne.',
                ui: ['options' => [self::MODE_ABSOLUTE => 'Absolut', self::MODE_PERCENT => 'Prozent']]
            ),
            PropertyDTO::create(
                name: 'applicationId',
                value: 1,
                type: 'int',
                isOptional: true,
                label: 'Application-ID',
                description: 'Anwendung, in deren Kontext die Kommandos laufen.',
                ui: ['min' => 1]
            ),
            PropertyDTO::create(
                name: 'onIncrease',
                value: [],
                type: 'array',
                isOptional: true,
                label: 'Kommandos bei Anstieg',
                description: 'Macro-Kommandos, die einmalig laufen, sobald der Anstieg erreicht ist.'
            ),
            PropertyDTO::create(
                name: 'onRecover',
                value: [],
                type: 'array',
                isOptional: true,
                label: 'Kommandos bei Entwarnung',
                description: 'Macro-Kommandos, die einmalig laufen, sobald der Anstieg nicht mehr erreicht ist.'
            ),
        ];
    }

    /**
     * The rise across the samples: the newest value minus the lowest one, so
     * a single sample is no rise. In percent of the lowest value - null when
     * that is not positive, since a rise from zero has no percentage.
     *
     * @param list<array{0: int, 1: float, 2?: int}> $samples oldest first
     */
    public static function measureIncrease(array $samples, string $mode = self::MODE_ABSOLUTE): ?float
    {
        if ($samples === []) {
            return null;
        }

        $current = $samples[array_key_last($samples)][1];
        $lowest = min(array_column($samples, 1));
        $increase = $current - $lowest;

        if ($mode !== self::MODE_PERCENT) {
            return $increase;
        }

        return $lowest > 0 ? $increase / $lowest * 100 : null;
    }

    /**
     * The samples the measurement needs: those within the timespan plus the
     * value the timespan started with - the last one measured at or before it.
     *
     * A sample followed by one that is not higher can never be the lowest
     * value of a later timespan, so it is dropped - the measurement stays the
     * same while a falling or fluctuating value keeps few samples. The sample
     * that drops others notes from when it stands in for them (third element),
     * so a start value that was dropped is not mistaken for an older, lower
     * sample that was kept. Only a long steady rise can exceed MAX_SAMPLES;
     * then the samples are thinned evenly, keeping the lowest (first) and the
     * current (last) one, so the current rise stays exact and only later
     * timespans lose resolution.
     *
     * @param list<array{0: int, 1: float, 2?: int}> $samples oldest first; [timestamp, value, stands in since]
     * @return list<array{0: int, 1: float, 2: int}>
     */
    public static function keepSamples(array $samples, int $windowStart): array
    {
        $rising = [];
        foreach ($samples as $sample) {
            $since = $sample[2] ?? $sample[0];
            while ($rising !== [] && $rising[array_key_last($rising)][1] >= $sample[1]) {
                $since = min($since, array_pop($rising)[2]);
            }
            $rising[] = [$sample[0], $sample[1], $since];
        }

        // Only the last sample at or before the start can be the start value,
        // and only if no sample after it that was dropped came before the start.
        $first = 0;
        foreach ($rising as $index => $sample) {
            if ($sample[0] <= $windowStart) {
                $first = $index;
            }
        }
        $kept = array_slice($rising, $first);
        if (count($kept) > 1 && $kept[0][0] <= $windowStart && $kept[1][2] <= $windowStart) {
            array_shift($kept);
        }

        return self::thin($kept, self::MAX_SAMPLES);
    }

    /**
     * @param list<array{0: int, 1: float, 2: int}> $samples
     * @return list<array{0: int, 1: float, 2: int}> at most $max samples, first and last kept
     */
    private static function thin(array $samples, int $max): array
    {
        $count = count($samples);
        if ($count <= $max) {
            return $samples;
        }

        $thinned = [];
        $since = PHP_INT_MAX;
        $next = 0;
        foreach ($samples as $index => $sample) {
            $since = min($since, $sample[2]);
            if ($index === (int)round($next * ($count - 1) / ($max - 1))) {
                $thinned[] = [$sample[0], $sample[1], $since];
                $since = PHP_INT_MAX;
                $next++;
            }
        }

        return $thinned;
    }

    public static function timespanSeconds(string $timespan): int
    {
        $start = new \DateTimeImmutable('@0');

        return $start->add(new \DateInterval(trim($timespan)))->getTimestamp() - $start->getTimestamp();
    }

    protected function now(): int
    {
        return time();
    }

    private function mode(): string
    {
        return ($this->_arguments['mode'] ?? '') === self::MODE_PERCENT ? self::MODE_PERCENT : self::MODE_ABSOLUTE;
    }

    /**
     * Stored samples come back from JSON; anything that is no [timestamp, value]
     * pair is dropped instead of breaking the measurement.
     *
     * @return list<array{0: int, 1: float, 2: int}>
     */
    private static function validSamples(mixed $samples): array
    {
        if (!is_array($samples)) {
            return [];
        }

        $valid = [];
        foreach ($samples as $sample) {
            if (is_array($sample) && is_numeric($sample[0] ?? null) && is_numeric($sample[1] ?? null)) {
                $valid[] = [
                    (int)$sample[0],
                    (float)$sample[1],
                    is_numeric($sample[2] ?? null) ? (int)$sample[2] : (int)$sample[0],
                ];
            }
        }

        return $valid;
    }

    private function runCommands(mixed $commands): void
    {
        if (empty($commands)) {
            return;
        }

        // Without its application a command would run in whatever context the
        // shared environment holds - so the commands are skipped instead.
        $application = $this->applicationRepository->find($this->_arguments['applicationId'] ?? 1);
        if ($application === null) {
            $this->reason .= sprintf(' - Application %s nicht gefunden, Kommandos übersprungen', $this->_arguments['applicationId'] ?? 1);
            return;
        }

        $this->macroEnvironment->setApplication($application);
        $this->player
            ->setMacroEnvironment($this->macroEnvironment)
            ->run($commands);
    }
}
