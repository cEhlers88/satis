<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Support;

/**
 * A short, readable label for the run interval of a monitoring.
 *
 * Run intervals are ISO 8601 durations as \DateInterval understands them
 * ("PT1M", "PT5M", "PT1H30M", "P1D", "P1M" ...) or one of the named
 * intervals the monitoring handles itself ("daily_midnight"). Every part of
 * the duration is shown, so "PT1H30M" reads "1 h 30 min" - and "P1M" (a
 * month) is never mistaken for "PT1M" (a minute).
 */
final class IntervalLabel
{
    /** Named intervals that are no \DateInterval. */
    private const array NAMED = [
        'daily_midnight' => '00:00',
    ];

    /** The parts of a duration in the order they are shown, with their unit. */
    private const array UNITS = [
        'y' => 'y',
        'm' => 'mo',
        'd' => 'd',
        'h' => 'h',
        'i' => 'min',
        's' => 's',
    ];

    public static function of(?string $interval): string
    {
        $interval = trim((string)$interval);
        if ($interval === '') {
            return '';
        }
        if (isset(self::NAMED[$interval])) {
            return self::NAMED[$interval];
        }

        try {
            $duration = new \DateInterval($interval);
        } catch (\Throwable) {
            // Something the monitoring would not run either - shown as it is.
            return $interval;
        }

        $parts = [];
        foreach (self::UNITS as $property => $unit) {
            $amount = (int)$duration->{$property};
            // Weeks are stored as days ("P2W" is 14 days); a whole number of
            // them reads better as such.
            if ($property === 'd' && $amount > 0 && $amount % 7 === 0 && str_contains($interval, 'W')) {
                $parts[] = ($amount / 7) . ' w';
                continue;
            }
            if ($amount > 0) {
                $parts[] = $amount . ' ' . $unit;
            }
        }

        // A valid duration without any part ("PT0S") is no duration at all.
        return $parts === [] ? '0 s' : implode(' ', $parts);
    }
}
