<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Support;

/**
 * The arguments of a procedure (Procedure::$properties): what startProcedure hands over and
 * the procedure reads in the variable context "argument".
 *
 * Stored as a list of tuples, the shape procedures have always had:
 *
 *   [type, name]                     required, no default (the old form)
 *   [type, name, default]            optional, `default` when it is not given
 *   [type, name, default, meta]      meta = {required, command, description}
 *
 * With `command` the default is a command definition that is run when the procedure starts
 * without the argument - its result is the value. A `type` of "command" (the form workers use,
 * Worker::PROPERTY_TYPE_COMMAND) is read the same way.
 */
final class ProcedureArguments
{
    public const TYPE_MIXED = 'mixed';
    public const TYPES = ['string', 'integer', 'float', 'boolean', 'array', self::TYPE_MIXED];

    private const LEGACY_COMMAND_TYPE = 'command';
    private const NAME_PATTERN = '/^[A-Za-z_][A-Za-z0-9_.-]{0,63}$/D';

    /**
     * The stored arguments, each with everything spelled out. Entries without a name are left
     * out - nothing could read them.
     *
     * @return list<array{name: string, type: string, required: bool, default: mixed, command: bool, description: string}>
     */
    public static function read(mixed $stored): array
    {
        $arguments = [];
        foreach (is_array($stored) ? $stored : [] as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $isTuple = array_is_list($entry);
            $name = $isTuple ? ($entry[1] ?? null) : ($entry['name'] ?? null);
            if (!is_string($name) || trim($name) === '') {
                continue;
            }
            $type = strtolower((string)($isTuple ? ($entry[0] ?? '') : ($entry['type'] ?? '')));
            $hasDefault = $isTuple ? array_key_exists(2, $entry) : array_key_exists('default', $entry);
            $meta = $isTuple ? ($entry[3] ?? []) : $entry;
            $meta = is_array($meta) ? $meta : [];
            $command = (bool)($meta['command'] ?? false) || $type === self::LEGACY_COMMAND_TYPE;

            $arguments[] = [
                'name' => trim($name),
                'type' => in_array($type, self::TYPES, true) ? $type : self::TYPE_MIXED,
                'required' => array_key_exists('required', $meta) ? (bool)$meta['required'] : !$hasDefault,
                'default' => $hasDefault ? ($isTuple ? $entry[2] : $entry['default']) : null,
                'command' => $command,
                'description' => trim((string)($meta['description'] ?? '')),
            ];
        }

        return $arguments;
    }

    /**
     * The arguments as an editor sends them - a list of {name, type, required, default,
     * command, description} - checked and with each default in the type it was declared with.
     *
     * @return list<array{name: string, type: string, required: bool, default: mixed, command: bool, description: string}>
     *
     * @throws \InvalidArgumentException naming the first argument that cannot be stored
     */
    public static function fromInput(mixed $input): array
    {
        if (!is_array($input) || !array_is_list($input)) {
            throw new \InvalidArgumentException('The arguments have to be a list.');
        }

        $arguments = [];
        $names = [];
        foreach ($input as $position => $entry) {
            if (!is_array($entry)) {
                throw new \InvalidArgumentException(sprintf('Argument %d is no argument.', $position + 1));
            }
            $name = trim((string)($entry['name'] ?? ''));
            if (preg_match(self::NAME_PATTERN, $name) !== 1) {
                throw new \InvalidArgumentException(sprintf(
                    'Argument %d: "%s" is no name - letters, digits, "_", "." and "-", starting with a letter or "_", at most 64 characters.',
                    $position + 1,
                    $name
                ));
            }
            // read by get_var - two names that differ in case only are a slip
            if (in_array(mb_strtolower($name), $names, true)) {
                throw new \InvalidArgumentException(sprintf('There is an argument "%s" already.', $name));
            }
            $names[] = mb_strtolower($name);

            $type = strtolower(trim((string)($entry['type'] ?? self::TYPE_MIXED)));
            if (!in_array($type, self::TYPES, true)) {
                throw new \InvalidArgumentException(sprintf('Argument "%s": unknown type "%s".', $name, $type));
            }
            $required = (bool)($entry['required'] ?? false);
            $command = !$required && (bool)($entry['command'] ?? false);
            $default = null;
            if (!$required) {
                $default = $command
                    ? self::commandDefault($name, $entry['default'] ?? null)
                    : self::typed($name, $type, $entry['default'] ?? null);
            }

            $arguments[] = [
                'name' => $name,
                'type' => $type,
                'required' => $required,
                'default' => $default,
                'command' => $command,
                'description' => trim((string)($entry['description'] ?? '')),
            ];
        }

        return $arguments;
    }

    /**
     * What a procedure stores for the arguments (see the class comment).
     *
     * @param list<array{name: string, type: string, required: bool, default: mixed, command: bool, description: string}> $arguments
     * @return list<array{0: string, 1: string, 2: mixed, 3: array{required: bool, command: bool, description: string}}>
     */
    public static function toStored(array $arguments): array
    {
        return array_map(static fn(array $argument): array => [
            $argument['type'],
            $argument['name'],
            $argument['required'] ? null : $argument['default'],
            [
                'required' => $argument['required'],
                'command' => $argument['command'],
                'description' => $argument['description'],
            ],
        ], array_values($arguments));
    }

    /**
     * The default of an argument as the type it is declared with. An editor sends text; a
     * value that is already of the type is taken as it is.
     */
    private static function typed(string $name, string $type, mixed $value): mixed
    {
        $text = is_string($value) ? trim($value) : null;

        switch ($type) {
            case 'integer':
                if (is_int($value)) {
                    return $value;
                }
                if ($text !== null && preg_match('/^-?\d+$/', $text) === 1) {
                    return (int)$text;
                }
                break;
            case 'float':
                if (is_int($value) || is_float($value)) {
                    return (float)$value;
                }
                if ($text !== null && is_numeric($text)) {
                    return (float)$text;
                }
                break;
            case 'boolean':
                if (is_bool($value)) {
                    return $value;
                }
                $flag = filter_var($text ?? $value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                if ($flag !== null) {
                    return $flag;
                }
                break;
            case 'array':
                if (is_array($value)) {
                    return $value;
                }
                if ($text === '') {
                    return [];
                }
                $decoded = $text === null ? null : json_decode($text, true);
                if (is_array($decoded)) {
                    return $decoded;
                }
                break;
            case 'string':
                if ($value === null || is_scalar($value)) {
                    return (string)$value;
                }
                break;
            default:
                // mixed: JSON when the text is JSON (a number, a list ...), the text otherwise
                if ($text === null || $text === '') {
                    return $value ?? '';
                }
                try {
                    return json_decode($text, true, 512, JSON_THROW_ON_ERROR);
                } catch (\JsonException) {
                    return $value;
                }
        }

        throw new \InvalidArgumentException(sprintf('Argument "%s": the default is no %s.', $name, $type));
    }

    /** A command definition as the exec-viewer holds it - a list, or its JSON. */
    private static function commandDefault(string $name, mixed $value): array
    {
        if (is_string($value)) {
            $value = json_decode($value, true);
        }
        if (!is_array($value) || $value === []) {
            throw new \InvalidArgumentException(sprintf('Argument "%s": the default is to come from commands, but there are none.', $name));
        }

        return $value;
    }
}
