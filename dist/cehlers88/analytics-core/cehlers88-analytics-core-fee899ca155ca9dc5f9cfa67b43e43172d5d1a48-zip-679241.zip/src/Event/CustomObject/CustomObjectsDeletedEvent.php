<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Event\CustomObject;

/**
 * Custom objects were deleted by a macro (deleteCustomObjects). What the application keeps
 * next to an object - its settings, say - is not known here, so whoever keeps such data
 * listens to this and removes it.
 */
final class CustomObjectsDeletedEvent
{
    /**
     * @param class-string $className
     * @param list<int> $ids
     */
    public function __construct(
        public readonly string $className,
        public readonly array $ids,
    ) {
    }
}
