<?php

namespace Cehlers88\AnalyticsCore\Player;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\Procedure;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Repository\ProcedureRepository;
use Cehlers88\AnalyticsCore\Support\ProcedureArguments;

/**
 * Runs a stored procedure. Its properties are its arguments (ProcedureArguments): what the
 * caller hands over, the default otherwise - and a value that is a command is run first, in
 * the scope of the caller, so it reads what the caller sees. The procedure then reads them in
 * the variable context "argument"; they are gone again once it has run.
 */
class ProcedurePlayer
{
    public function __construct(
        private MacroEnvironment    $_macroEnvironment,
        private ProcedureRepository $_procedureRepository
    )
    {
    }

    public function startProcedure(string $name, $props): mixed
    {
        $procedure = $this->_procedureRepository->findOneBy(['name' => $name]);

        if (!$procedure instanceof Procedure) {
            return ErrorDTO::create(404, 'Procedure "' . $name . '" not found.');
        }
        if (!$procedure->isEnabled()) {
            return ErrorDTO::create(404, 'Procedure "' . $name . '" is disabled.');
        }

        $arguments = $this->resolveArguments($procedure, is_array($props) ? $props : []);
        if ($arguments instanceof ErrorDTO) {
            return $arguments;
        }

        $variables = $this->_macroEnvironment->getVariablesStoreProvider();
        $variables->startArgumentsContext();
        try {
            foreach ($arguments as $key => $value) {
                $variables->setArgument((string)$key, $value);
            }

            return $this->_macroEnvironment->getCommandPlayer()->run($procedure->getContent());
        } finally {
            // also when a command fails: the arguments must not outlive the procedure
            $variables->clearArgumentsContext();
        }
    }

    /**
     * The values the procedure starts with: every declared argument - given, or its default -
     * and whatever else the caller handed over. Commands among them are run here, before the
     * procedure's own arguments exist.
     *
     * @param array<string|int, mixed> $given
     * @return array<string|int, mixed>|ErrorDTO
     */
    public function resolveArguments(Procedure $procedure, array $given): array|ErrorDTO
    {
        $commandPlayer = $this->_macroEnvironment->getCommandPlayer();
        $values = [];

        foreach (ProcedureArguments::read($procedure->getProperties()) as $argument) {
            $name = $argument['name'];
            if (array_key_exists($name, $given)) {
                $values[$name] = $given[$name];
                unset($given[$name]);
            } elseif ($argument['required']) {
                return ErrorDTO::create(422, 'Missing argument "' . $name . '" for procedure "' . $procedure->getName() . '".');
            } else {
                $values[$name] = $argument['command']
                    ? $commandPlayer->run($argument['default'])
                    : $argument['default'];
                continue;
            }
            $values[$name] = $this->runIfCommand($values[$name]);
        }

        // handed over without being declared - passed on as before
        foreach ($given as $name => $value) {
            $values[$name] = $this->runIfCommand($value);
        }

        return $values;
    }

    /**
     * A value that arrives as a command - startProcedure usually runs those already, a caller
     * in PHP may not - is run; anything else is a value, even a list that looks like one.
     */
    private function runIfCommand(mixed $value): mixed
    {
        if ($value instanceof CommandDTO || $value instanceof CommandGroupDTO) {
            return $this->_macroEnvironment->getCommandPlayer()->run($value);
        }

        return $value;
    }
}
