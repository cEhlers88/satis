<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Notification;

/**
 * Delivers push notifications on behalf of the core - the macro
 * `sendPushNotification` sends through it. The core keeps no subscriptions,
 * so the application implements it with its own push service; without an
 * implementation the macro answers with an error instead of sending.
 */
interface PushNotificationSenderInterface
{
    /**
     * Sends a notification to the subscriptions of a channel, of a single user,
     * or of a user on a channel when both are given. An implementation must not
     * reach a user who may not use the channel.
     *
     * @param string|null $channel Key of the push notification channel.
     * @param int|null $userId Id of the user to notify.
     * @param array{url?: string, tag?: string, icon?: string} $options
     *
     * @return array{sent: int, failed: int}
     */
    public function send(string $title, string $body, ?string $channel = null, ?int $userId = null, array $options = []): array;
}
