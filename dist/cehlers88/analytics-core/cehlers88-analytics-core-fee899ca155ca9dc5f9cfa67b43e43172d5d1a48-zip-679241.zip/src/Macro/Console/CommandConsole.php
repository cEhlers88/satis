<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\Console;

use Symfony\Contracts\Service\ResetInterface;

/**
 * The console of a command run: what the `log` macro writes (LogMacro), kept apart from
 * the output (`echo`) and the debugger log, so it can be shown as a console - in the
 * debugger - or as plain text lines - in the journal of a worker.
 *
 * One console serves the whole request (or message), and runs nest: a command can start
 * a worker that runs commands itself. Whoever wants the entries of one run therefore
 * notes `mark()` before it and reads `entriesSince()` after it, instead of clearing.
 */
final class CommandConsole implements ResetInterface
{
    public const LEVEL_DEBUG = 'debug';
    public const LEVEL_INFO = 'info';
    public const LEVEL_WARNING = 'warning';
    public const LEVEL_ERROR = 'error';

    public const LEVELS = [self::LEVEL_DEBUG, self::LEVEL_INFO, self::LEVEL_WARNING, self::LEVEL_ERROR];

    /** A loop that logs forever must not take the memory of the process with it. */
    public const MAX_ENTRIES = 1000;

    private const LEVEL_ALIASES = ['warn' => self::LEVEL_WARNING, 'err' => self::LEVEL_ERROR, 'notice' => self::LEVEL_INFO];

    /** @var list<array{level: string, value: mixed, time: float}> */
    private array $entries = [];
    /** Entries written before the oldest one kept - they still count for the marks. */
    private int $dropped = 0;

    /** One line of text - for whoever shows text only, like the journal of a worker. */
    public static function toText(array $entry): string
    {
        $value = $entry['value'] ?? null;
        $text = match (true) {
            $value === null => 'null',
            is_bool($value) => $value ? 'true' : 'false',
            is_scalar($value) => (string)$value,
            default => (string)json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR),
        };

        return sprintf('[%s] %s', $entry['level'] ?? self::LEVEL_INFO, $text);
    }

    /** @return array{level: string, value: mixed, time: float} the entry as it was kept */
    public function write(mixed $value, string $level = self::LEVEL_INFO): array
    {
        $entry = ['level' => self::normalizeLevel($level), 'value' => self::normalizeValue($value), 'time' => microtime(true)];
        $this->entries[] = $entry;
        if (count($this->entries) > self::MAX_ENTRIES) {
            array_shift($this->entries);
            $this->dropped++;
        }

        return $entry;
    }

    private static function normalizeLevel(string $level): string
    {
        return self::readLevel($level) ?? self::LEVEL_INFO;
    }

    /** `null` when the level is none of LEVELS (or an alias of one). */
    public static function readLevel(mixed $level): ?string
    {
        if (!is_string($level)) {
            return null;
        }
        $level = strtolower(trim($level));
        $level = self::LEVEL_ALIASES[$level] ?? $level;

        return in_array($level, self::LEVELS, true) ? $level : null;
    }

    /**
     * Objects - a definition decoded without `assoc` - are kept as the plain structure they
     * stand for: the console shows data, and a live object could change after it was logged.
     */
    private static function normalizeValue(mixed $value): mixed
    {
        if (is_object($value) || is_array($value)) {
            $encoded = json_encode($value, JSON_PARTIAL_OUTPUT_ON_ERROR);

            return $encoded === false ? null : json_decode($encoded, true);
        }
        if (is_resource($value)) {
            return get_resource_type($value);
        }

        return $value;
    }

    /** Where the console stands - hand it to entriesSince() after the run. */
    public function mark(): int
    {
        return $this->dropped + count($this->entries);
    }

    /** @return list<array{level: string, value: mixed, time: float}> */
    public function entriesSince(int $mark): array
    {
        return array_slice($this->entries, max(0, $mark - $this->dropped));
    }

    public function reset(): void
    {
        $this->entries = [];
        $this->dropped = 0;
    }
}
