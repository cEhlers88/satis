<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class ExplodeMacro extends AbstractMacro
{
    private const string PROPERTY_SEPERATOR = 'separator';
    private const string PROPERTY_VALUE = 'value';
    private const string PROPERTY_LIMIT = 'limit';

    protected function run(): ?array
    {#
        return $this->_createRunResult(explode(
            $this->getPropertyValue(self::PROPERTY_SEPERATOR),
            $this->getPropertyValue(self::PROPERTY_VALUE)/*,
            $this->getPropertyValue(self::PROPERTY_LIMIT)*/
        ));
    }

    public function init(): ExplodeMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'string', 'Specify the value to explode'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_SEPERATOR, 'string', 'Specify the separator to explode'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_LIMIT, 'int', 'Specify the limit of the explode', PHP_INT_MAX));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Use this macro to explode a string.';
    }

    public function getName(): string
    {
        return 'explode';
    }
}