<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class GroupMacro extends AbstractMacro
{
    private const PROPERTY_DATA = 'data';
    private const PROPERTY_GROUP_FIELD = 'groupField';

    protected function run(): ?array
    {
        $groupField = $this->getPropertyValue(self::PROPERTY_GROUP_FIELD);
        $originalData = $this->getPropertyValue(self::PROPERTY_DATA);
        $resultData = [];
        foreach ($originalData as $data) {
            if (array_key_exists($groupField, $data)) {
                $groupName = $data[$groupField];
                unset($data[$groupField]);
            } else {
                $groupName = 'default';
            }

            if (!array_key_exists($groupName, $resultData)) {
                $resultData[$groupName] = [];
            }
            $resultData[$groupName][] = $data;
        }

        return $this->_createRunResult($resultData);
    }

    public function init(): GroupMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DATA, 'array', 'Specify the data to group'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_GROUP_FIELD, 'string', 'Specify the field that is used to group the data'));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Group data by a field.';
    }

    public function getName(): string
    {
        return 'group';
    }
}