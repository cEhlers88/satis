<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class SleepMacro extends AbstractMacro
{
    protected function run(): ?array
    {
        sleep($this->getPropertyValue('s'));
        return $this->_createRunResult($this->getPropertyValue('s'));
    }

    public function init(): SleepMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create('s', 'int', 'Specify the seconds to sleep.'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Use this macro to sleep a specified amount of seconds.';
    }

    public function getName(): string
    {
        return 'sleep';
    }
}