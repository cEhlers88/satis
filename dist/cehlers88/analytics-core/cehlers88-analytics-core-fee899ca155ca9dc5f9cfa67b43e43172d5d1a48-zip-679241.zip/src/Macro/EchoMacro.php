<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogReason;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class EchoMacro extends AbstractMacro
{
    public function init(): EchoMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create('output', 'mixed', 'Specify the output'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Use this macro to output a value.';
    }

    public function getName(): string
    {
        return 'echo';
    }

    protected function run(): ?array
    {
        $outputValue = $this->getPropertyValue('output');

        if (is_array($outputValue) || is_object($outputValue)) {
            $outputValue = json_encode($outputValue);
        }

        $this->log(eDebuggerLogType::INFO, $outputValue, ["reason" => eDebuggerLogReason::OUTPUT_STREAM]);

        echo $outputValue;

        return $this->_createRunResult(["__void" => true]);
    }
}