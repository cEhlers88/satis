<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class SubValueMacro extends AbstractMacro
{
    private const PROPERTY_DATA = 'data';
    private const PROPERTY_KEY = 'key';

    public function init(): SubValueMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DATA, ['array', 'object'], 'Specify the data'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_KEY, ['int', 'string'], 'Specify the sub key'));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Get a sub value of given object/array by key. Allows to get nested values like "data.subdata.subsubdata".';
    }

    public function getName(): string
    {
        return 'subValue';
    }

    protected function run(): ?array
    {
        $errorDto = null;
        $data = $this->getPropertyValue(self::PROPERTY_DATA);
        $keys = explode('.', $this->getPropertyValue(self::PROPERTY_KEY));
        $result = $data;

        foreach ($keys as $key) {
            if (is_object($result)) {
                if (method_exists($result, 'get' . ucfirst($key))) {
                    $result = $result->{'get' . ucfirst($key)}();
                    continue;
                }
                $result = $result->{$key};
                continue;
            }

            if (!array_key_exists($key, $result)) {
                $add = json_encode($result);
                $errorDto = ErrorDTO::create(404, 'Key not "' . $key . '" found ' . $add, $result);
                break;
            }
            $result = $result[$key];
        }

        return $this->_createRunResult($result, $errorDto);
    }
}