<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\Support;

/**
 * Reading the entries of a list the way sort and aggregate do: a definition decoded without
 * `assoc` brings objects where a command written by hand brings arrays, so both are read alike,
 * and a field may reach into nested values with dots ("attributes.betrag").
 */
final class ListValues
{
    /** Arrays stay, objects become arrays - recursively, as JSON would see them. */
    public static function plain(mixed $value): mixed
    {
        if (is_object($value)) {
            $value = json_decode((string)json_encode($value), true);
        }

        return $value;
    }

    /** The value at `path` in an entry; the entry itself for an empty path, null where it ends early. */
    public static function at(mixed $entry, string $path): mixed
    {
        $value = self::plain($entry);
        if ($path === '') {
            return $value;
        }
        foreach (explode('.', $path) as $key) {
            if (!is_array($value) || !array_key_exists($key, $value)) {
                return null;
            }
            $value = $value[$key];
        }

        return $value;
    }

    public static function isEmpty(mixed $value): bool
    {
        return $value === null || $value === '' || $value === [];
    }

    /** A number, or null - numeric texts count, "1.234,50" or a bool does not. */
    public static function number(mixed $value): int|float|null
    {
        if (is_int($value) || is_float($value)) {
            return $value;
        }
        if (is_string($value) && is_numeric(trim($value))) {
            return trim($value) + 0;
        }

        return null;
    }

    public static function text(mixed $value): string
    {
        return match (true) {
            is_bool($value) => $value ? 'true' : 'false',
            is_scalar($value) => (string)$value,
            default => (string)json_encode($value, JSON_UNESCAPED_UNICODE),
        };
    }
}
