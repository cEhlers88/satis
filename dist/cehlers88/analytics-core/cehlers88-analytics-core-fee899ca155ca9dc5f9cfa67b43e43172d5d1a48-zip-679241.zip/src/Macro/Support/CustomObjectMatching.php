<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\Support;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;

/**
 * How findCustomObjects and deleteCustomObjects pick their objects - one place, so a `where`
 * that finds an object is exactly the `where` that deletes it. The using macro has a
 * CustomObjectProvider in `$customObjectProvider`.
 *
 * @property CustomObjectProvider $customObjectProvider
 */
trait CustomObjectMatching
{
    private const array OWN_FIELDS = ['id', 'name', 'parentId'];

    /** The class name as the provider knows it, from its full or its short name in any case. */
    private function resolveClassName(string $className): ?string
    {
        $wanted = strtolower(ltrim(trim($className), '\\'));
        if ($wanted === '') {
            return null;
        }

        foreach ($this->customObjectProvider->getCustomClasses() as $class) {
            $known = self::classNameOf($class);
            if ($known === null) {
                continue;
            }
            $shortName = substr($known, (int)strrpos('\\' . $known, '\\'));
            if (strtolower($known) === $wanted || strtolower($shortName) === $wanted) {
                return $known;
            }
        }

        return null;
    }

    private static function classNameOf(mixed $class): ?string
    {
        $className = match (true) {
            is_string($class) => $class,
            is_array($class) => $class['className'] ?? null,
            is_object($class) && method_exists($class, 'getClassName') => $class->getClassName(),
            is_object($class) => $class->className ?? null,
            default => null,
        };

        return is_string($className) && $className !== '' ? $className : null;
    }

    /**
     * `where` as a list by field. An object - a definition decoded without `assoc` - is taken as
     * one; the command player only looks into arrays for commands, so the commands among its
     * values are run here.
     *
     * @return array<string, mixed>
     */
    private function conditions(mixed $where): array
    {
        if (is_object($where)) {
            $where = json_decode((string)json_encode($where), true);
            if (!is_array($where)) {
                return [];
            }
            $commandPlayer = $this->getMacroEnvironment()->getCommandPlayer();
            foreach ($where as $field => $value) {
                if (is_array($value) && $commandPlayer->describesCommands($value)) {
                    $where[$field] = $commandPlayer->run($value);
                }
            }
        }

        return is_array($where) ? $where : [];
    }

    /**
     * @return array{id: int|null, name: string|null, parentId: int|null, attributes: array<string, mixed>}
     */
    private static function describe(object $customObject): array
    {
        $attributes = method_exists($customObject, 'getAttributes') ? $customObject->getAttributes() : [];
        $id = method_exists($customObject, 'getId') ? $customObject->getId() : null;
        $parentId = method_exists($customObject, 'getParentId') ? $customObject->getParentId() : null;
        $name = method_exists($customObject, 'getName') ? $customObject->getName() : null;

        return [
            'id' => $id === null ? null : (int)$id,
            'name' => $name === null ? null : (string)$name,
            'parentId' => $parentId === null ? null : (int)$parentId,
            'attributes' => is_array($attributes) ? $attributes : [],
        ];
    }

    private static function valueOf(array $entry, string $field): mixed
    {
        return in_array($field, self::OWN_FIELDS, true) ? $entry[$field] : ($entry['attributes'][$field] ?? null);
    }

    private static function matches(array $entry, array $where): bool
    {
        foreach ($where as $field => $expected) {
            $actual = self::valueOf($entry, (string)$field);
            $candidates = is_array($expected) && array_is_list($expected) ? $expected : [$expected];
            $isMatch = false;
            foreach ($candidates as $candidate) {
                if (self::equals($actual, $candidate)) {
                    $isMatch = true;
                    break;
                }
            }
            if (!$isMatch) {
                return false;
            }
        }

        return true;
    }

    private static function equals(mixed $actual, mixed $expected): bool
    {
        if ($actual === null || $expected === null) {
            return $actual === $expected || ($actual ?? $expected) === '';
        }
        if (is_numeric($actual) && is_numeric($expected)) {
            return (float)$actual === (float)$expected;
        }

        return self::text($actual) === self::text($expected);
    }

    private static function text(mixed $value): string
    {
        return match (true) {
            is_bool($value) => $value ? 'true' : 'false',
            is_scalar($value) => (string)$value,
            default => (string)json_encode($value),
        };
    }

    /**
     * What `where` can name for a class: the own fields and the attributes - none for a class
     * that does not exist.
     *
     * @return array<string, string> field => "own field" or "attribute"
     */
    private function fieldsOf(string $className): array
    {
        $resolvedClassName = $this->resolveClassName($className);
        if ($resolvedClassName === null) {
            return [];
        }

        $keys = ['id' => 'own field', 'name' => 'own field', 'parentId' => 'own field'];
        foreach ($this->customObjectProvider->getAttributesOfCustomEntityClass($resolvedClassName) as $attribute) {
            if (is_string($attribute) && $attribute !== '' && !isset($keys[$attribute])) {
                $keys[$attribute] = 'attribute';
            }
        }

        return $keys;
    }

    /**
     * Every object of the class that matches `where`, described.
     *
     * @return list<array{id: int|null, name: string|null, parentId: int|null, attributes: array<string, mixed>}>
     */
    private function findMatching(string $className, array $where): array
    {
        $found = [];
        foreach ($this->customObjectProvider->getCustomEntitiesByClassName($className) as $customObject) {
            if (!is_object($customObject)) {
                continue;
            }
            $entry = self::describe($customObject);
            if (self::matches($entry, $where)) {
                $found[] = $entry;
            }
        }

        return $found;
    }
}
