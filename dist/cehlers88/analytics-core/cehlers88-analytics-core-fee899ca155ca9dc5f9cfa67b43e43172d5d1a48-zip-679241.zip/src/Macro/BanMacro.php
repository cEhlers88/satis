<?php

namespace Cehlers88\AnalyticsCore\Macro;


class BanMacro extends AbstractMacro
{
    protected function run(): ?array
    {
        return [];
    }

    public function init(): BanMacro
    {
        $this->_source = 'CoreBundle';
        /*$this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CONDITIONS,'mixed', 'Specify the condition to check'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_WHEN_TRUE_COMMANDS,'array', '',[]))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_WHEN_FALSE_COMMANDS, 'array','',[]))
        ;*/

        return $this;
    }

    public function getDescription(): string
    {
        return 'Ban a client - not implemented yet, does nothing.';
    }

    public function getName(): string
    {
        return 'ban';
    }
}