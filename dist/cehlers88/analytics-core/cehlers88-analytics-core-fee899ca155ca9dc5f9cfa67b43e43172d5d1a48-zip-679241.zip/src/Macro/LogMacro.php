<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogReason;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\Console\CommandConsole;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

/**
 * Writes a value to the console of the run (CommandConsole): the debugger shows it in its
 * console - texts and numbers as text, lists and objects as a tree - and a worker adds it
 * to its journal as a line of text. Unlike `echo` it does not touch the output.
 */
class LogMacro extends AbstractMacro
{
    private const PROPERTY_VALUE = 'value';
    private const PROPERTY_LEVEL = 'logLevel';

    public function __construct(
        private readonly CommandConsole $console,
    )
    {
    }

    public function init(): LogMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'mixed', 'The value to log - text, a number, a list or an object'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_LEVEL, 'string', 'debug, info, warning or error', CommandConsole::LEVEL_INFO));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Writes a value to the console of the run.';
    }

    public function getName(): string
    {
        return 'log';
    }

    protected function run(): ?array
    {
        $givenLevel = $this->getPropertyValue(self::PROPERTY_LEVEL);
        $entry = $this->console->write($this->getPropertyValue(self::PROPERTY_VALUE), (string)$givenLevel);

        if ($givenLevel !== null && $givenLevel !== '' && CommandConsole::readLevel($givenLevel) === null) {
            $this->log(eDebuggerLogType::WARNING, sprintf('Unknown log level "%s" - logged as "%s".', (string)$givenLevel, $entry['level']), [
                'reason' => eDebuggerLogReason::INFO,
            ]);
        }

        // the debugger reads its console from the log of the session - live, while the run goes on
        $this->log(self::debuggerLogType($entry['level']), CommandConsole::toText($entry), [
            'reason' => eDebuggerLogReason::INFO,
            'console' => $entry,
        ]);

        return $this->_createRunResult(['__void' => true]);
    }

    private static function debuggerLogType(string $level): eDebuggerLogType
    {
        return match ($level) {
            CommandConsole::LEVEL_DEBUG => eDebuggerLogType::DEBUG,
            CommandConsole::LEVEL_WARNING => eDebuggerLogType::WARNING,
            // ERROR would pause a run that breaks on errors - a logged error is no failure
            default => eDebuggerLogType::INFO,
        };
    }
}
