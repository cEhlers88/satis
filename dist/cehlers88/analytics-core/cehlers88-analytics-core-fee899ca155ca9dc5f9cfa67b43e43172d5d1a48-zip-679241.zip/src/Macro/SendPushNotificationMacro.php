<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Notification\PushNotificationSenderInterface;

/**
 * Sends a push notification from a command - a worker or a procedure can
 * report "service does not answer" or "month closed" on its own. Goes to a
 * channel, to a user, or to a user on a channel; never to everybody, so a
 * command cannot reach subscriptions nobody chose for it. In the protected mode
 * nothing is sent and the result counts no notification.
 */
class SendPushNotificationMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    private const string PROPERTY_TITLE = 'title';
    private const string PROPERTY_BODY = 'body';
    private const string PROPERTY_CHANNEL = 'channel';
    private const string PROPERTY_USER_ID = 'userId';
    private const string PROPERTY_URL = 'url';
    private const string PROPERTY_TAG = 'tag';

    public function __construct(
        private readonly ?PushNotificationSenderInterface $sender = null,
    )
    {
    }

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_URL => PropertyUi::create()->placeholder('/dashboard/'),
            self::PROPERTY_USER_ID => PropertyUi::create()->placeholder('0 = alle Abonnenten des Kanals'),
            default => null,
        };
    }

    public function init(): SendPushNotificationMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TITLE, MacroPropertyDTO::TYPE_STRING, 'Title of the notification'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_BODY, MacroPropertyDTO::TYPE_STRING, 'Text of the notification', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CHANNEL, MacroPropertyDTO::TYPE_STRING, 'Key of the push notification channel', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_USER_ID, MacroPropertyDTO::TYPE_INT, 'Id of a single user to notify - everybody on the channel when 0', 0))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_URL, MacroPropertyDTO::TYPE_STRING, 'Page that opens on a click on the notification', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TAG, MacroPropertyDTO::TYPE_STRING, 'Notifications with the same tag replace each other', ''));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Sends a push notification to a channel or a user.';
    }

    public function getName(): string
    {
        return 'sendPushNotification';
    }

    protected function run(): ?array
    {
        if ($this->sender === null) {
            return $this->_createRunResult(null, ErrorDTO::create(501, 'No push notification sender is registered in this application.'));
        }

        $title = trim((string)$this->getPropertyValue(self::PROPERTY_TITLE));
        $channel = trim((string)$this->getPropertyValue(self::PROPERTY_CHANNEL));
        $userId = (int)$this->getPropertyValue(self::PROPERTY_USER_ID);

        if ($title === '') {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'A push notification needs a title.'));
        }
        if ($channel === '' && $userId <= 0) {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'A push notification needs a channel or a user.'));
        }

        $options = array_filter([
            'url' => trim((string)$this->getPropertyValue(self::PROPERTY_URL)),
            'tag' => trim((string)$this->getPropertyValue(self::PROPERTY_TAG)),
        ], static fn(string $value): bool => $value !== '');

        $body = (string)$this->getPropertyValue(self::PROPERTY_BODY);

        try {
            $result = $this->runProtectedFragment(
                fn(): mixed => $this->sender->send(
                    $title,
                    $body,
                    $channel === '' ? null : $channel,
                    $userId > 0 ? $userId : null,
                    $options
                ),
                static fn(): array => ['sent' => 0, 'failed' => 0, 'protectedMode' => true]
            );
        } catch (\Throwable $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(500, $exception->getMessage()));
        }

        return $this->_createRunResult($result);
    }
}
