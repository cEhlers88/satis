<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Macro\Support\ListValues;
use Cehlers88\AnalyticsCore\Support\Property\PropertyValuePath;

/**
 * One figure out of a list: count, sum, average, minimum or maximum, of the
 * entries themselves or of one (dotted) field of them. With `groups` the data
 * is read as the result of `group` - name => entries - and every group gets its
 * own figure, which spares a `for` loop with `setVar` for "sum per category".
 * `groupBy` does the grouping itself: one figure per value of that (dotted) field, in
 * the order the values appear, entries without it under "".
 *
 * A sum of decimals is rounded to 10 places, so 0.1 + 0.2 is 0.3 and not
 * 0.30000000000000004; `precision` rounds the figure further.
 */
class AggregateMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const string OPERATION_COUNT = 'count';
    public const string OPERATION_SUM = 'sum';
    public const string OPERATION_AVG = 'avg';
    public const string OPERATION_MIN = 'min';
    public const string OPERATION_MAX = 'max';

    private const array OPERATIONS = [
        self::OPERATION_COUNT => 'Anzahl',
        self::OPERATION_SUM => 'Summe',
        self::OPERATION_AVG => 'Durchschnitt',
        self::OPERATION_MIN => 'Minimum',
        self::OPERATION_MAX => 'Maximum',
    ];

    private const string PROPERTY_DATA = 'data';
    private const string PROPERTY_OPERATION = 'operation';
    private const string PROPERTY_FIELD = 'field';
    private const string PROPERTY_GROUPS = 'groups';
    private const string PROPERTY_GROUP_BY = 'groupBy';
    private const string PROPERTY_PRECISION = 'precision';

    /** Enough to drop the binary noise of a float sum, few enough to keep every real digit. */
    private const int NOISE_PRECISION = 10;

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_OPERATION => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options(self::OPERATIONS),
            self::PROPERTY_FIELD => PropertyUi::create()->placeholder('amount'),
            self::PROPERTY_GROUPS => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options([
                'false' => 'eine Zahl für alle Einträge',
                'true' => 'eine Zahl je Gruppe (Ergebnis von group)',
            ]),
            self::PROPERTY_GROUP_BY => PropertyUi::create()->placeholder('category'),
            default => null,
        };
    }

    public function init(): AggregateMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DATA, MacroPropertyDTO::TYPE_ARRAY, 'The list to aggregate'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_OPERATION, MacroPropertyDTO::TYPE_STRING, 'count, sum, avg, min or max', self::OPERATION_COUNT))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_FIELD, MacroPropertyDTO::TYPE_STRING, 'Field of the entries to aggregate, dotted for nested values - the entries themselves when empty', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_GROUPS, MacroPropertyDTO::TYPE_BOOLEAN, 'Read the data as groups (name => entries) and aggregate each group', false))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_GROUP_BY, MacroPropertyDTO::TYPE_STRING, 'Field to group the entries by, dotted for nested values - one figure per group; empty aggregates the whole list', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_PRECISION, MacroPropertyDTO::TYPE_INT, 'Round the figure to this many decimals; -1 does not round', -1));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Counts, sums, averages or finds the minimum/maximum of a list, optionally per group.';
    }

    public function getName(): string
    {
        return 'aggregate';
    }

    protected function run(): ?array
    {
        $operation = strtolower(trim((string)$this->getPropertyValue(self::PROPERTY_OPERATION)));
        if ($operation === '') {
            $operation = self::OPERATION_COUNT;
        }
        if (!array_key_exists($operation, self::OPERATIONS)) {
            return $this->_createRunResult(null, ErrorDTO::create(422, sprintf(
                'Unknown operation "%s" - use one of %s.', $operation, implode(', ', array_keys(self::OPERATIONS))
            )));
        }

        $data = $this->getPropertyValue(self::PROPERTY_DATA);
        $field = trim((string)$this->getPropertyValue(self::PROPERTY_FIELD));
        $groupBy = trim((string)$this->getPropertyValue(self::PROPERTY_GROUP_BY));
        $precision = (int)$this->getPropertyValue(self::PROPERTY_PRECISION);
        $readsGroups = self::isTrue($this->getPropertyValue(self::PROPERTY_GROUPS));

        if ($readsGroups && $groupBy !== '') {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'Use either "groups" (data that is already grouped) or "groupBy", not both.'));
        }

        if ($groupBy !== '') {
            $groups = [];
            // grouped by a field, the entries are records - a single one too
            foreach (self::toEntries($data, $groupBy) as $entry) {
                $group = self::readField($entry, $groupBy);
                $groups[ListValues::isEmpty($group) ? '' : ListValues::text($group)][] = $entry;
            }
        } elseif ($readsGroups) {
            if (!is_array($data)) {
                return $this->_createRunResult(null, ErrorDTO::create(422, 'With "groups" the data has to be a list of groups.'));
            }
            $groups = array_map(static fn(mixed $entries): array => self::toEntries($entries, $field), $data);
        } else {
            return $this->_createRunResult(self::aggregate(self::toEntries($data, $field), $operation, $field, $precision));
        }

        $result = [];
        foreach ($groups as $groupName => $entries) {
            $result[$groupName] = self::aggregate($entries, $operation, $field, $precision);
        }

        return $this->_createRunResult($result);
    }

    public static function aggregate(array $entries, string $operation, string $field = '', int $precision = -1): int|float|null
    {
        $values = [];
        foreach ($entries as $entry) {
            $value = $field === '' ? $entry : self::readField($entry, $field);
            if ($value !== null) {
                $values[] = $value;
            }
        }

        if ($operation === self::OPERATION_COUNT) {
            return count($values);
        }

        // only numbers take part in a calculation - "12.5" from a form is one, "n/a" is not
        $numbers = array_map(
            static fn(mixed $value): int|float => $value + 0,
            array_values(array_filter($values, static fn(mixed $value): bool => is_int($value) || is_float($value) || (is_string($value) && is_numeric($value))))
        );

        $sum = self::withoutNoise(array_sum($numbers));
        $result = match ($operation) {
            self::OPERATION_SUM => $sum,
            self::OPERATION_AVG => $numbers === [] ? null : $sum / count($numbers),
            self::OPERATION_MIN => $numbers === [] ? null : min($numbers),
            self::OPERATION_MAX => $numbers === [] ? null : max($numbers),
            default => null,
        };

        return is_float($result) && $precision >= 0 ? round($result, $precision) : $result;
    }

    private static function withoutNoise(int|float $sum): int|float
    {
        return is_float($sum) ? round($sum, self::NOISE_PRECISION) : $sum;
    }

    /**
     * The entries of a list. A list of one entry reaches the macro unwrapped
     * (AbstractMacro::execute()), so a single record - an object, or keyed
     * values when a field is asked for - counts as a list of it. Without a
     * field, keyed values are the entries: {"jan": 5, "feb": 7} sums to 12.
     */
    private static function toEntries(mixed $data, string $field): array
    {
        if ($data === null) {
            return [];
        }
        if (!is_array($data)) {
            return [$data];
        }
        if (array_is_list($data)) {
            return $data;
        }

        return $field === '' ? array_values($data) : [$data];
    }

    private static function readField(mixed $entry, string $field): mixed
    {
        if (is_object($entry)) {
            $entry = (array)$entry;
        }

        return is_array($entry) ? PropertyValuePath::read($entry, $field) : null;
    }

    private static function isTrue(mixed $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }
}
