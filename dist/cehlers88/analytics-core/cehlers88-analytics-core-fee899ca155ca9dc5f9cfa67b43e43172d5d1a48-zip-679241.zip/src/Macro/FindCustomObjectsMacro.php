<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\PropertyUi\MapKeySuggestionsInterface;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\MapPropertyUi;
use Cehlers88\AnalyticsCore\Macro\Support\CustomObjectMatching;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;

/**
 * Reads custom objects - the counterpart to the core macro saveCustomObject. Every object of
 * `className` that matches `where` comes back as {id, name, parentId, attributes}, sorted by
 * `orderBy` and cut to `limit`; with `first` only the first one, or null.
 *
 * `where` is an object, edited key by key (MapPropertyUi): id, name and parentId are the
 * object's own fields, every other key one of its attributes. A value has to be equal - a
 * list means one of its values. Attributes are stored as text, so "5", 5 and 5.0 are equal.
 */
class FindCustomObjectsMacro extends AbstractMacro implements PropertyUiProviderInterface, MapKeySuggestionsInterface
{
    use CustomObjectMatching;

    private const string PROPERTY_CLASS_NAME = 'className';
    private const string PROPERTY_WHERE = 'where';
    private const string PROPERTY_ORDER_BY = 'orderBy';
    private const string PROPERTY_LIMIT = 'limit';
    private const string PROPERTY_FIRST = 'first';

    public function __construct(
        private CustomObjectProvider $customObjectProvider,
    )
    {
    }

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return $property->name === self::PROPERTY_WHERE
            ? MapPropertyUi::suggestKeysFromMacro(MapPropertyUi::create())->displayName('Where')
            : null;
    }

    /** The own fields and the attributes of the class the command names - as long as it names one directly. */
    public function suggestMapKeys(string $propertyName, array $properties): array
    {
        $className = $properties[self::PROPERTY_CLASS_NAME] ?? null;
        if ($propertyName !== self::PROPERTY_WHERE || !is_string($className)) {
            return [];
        }

        return $this->fieldsOf($className);
    }

    public function init(): FindCustomObjectsMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CLASS_NAME, ['string'], 'The full or short name of a custom object class'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_WHERE, ['array'], 'What the objects must match, by field: id, name, parentId or an attribute. A list means one of its values', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ORDER_BY, ['string'], 'The field to sort by - id, name, parentId or an attribute; a leading "-" sorts descending', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_LIMIT, ['int'], 'At most this many objects; 0 means all', 0))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_FIRST, ['bool'], 'Return only the first object (or null) instead of a list', false));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Finds custom objects of a class by their fields and attributes.';
    }

    public function getName(): string
    {
        return 'findCustomObjects';
    }

    protected function run(): ?array
    {
        $className = $this->resolveClassName((string)$this->getPropertyValue(self::PROPERTY_CLASS_NAME));
        if ($className === null) {
            return $this->_createRunResult(null, ErrorDTO::create(
                404,
                sprintf('findCustomObjects: there is no custom object class "%s"', trim((string)$this->getPropertyValue(self::PROPERTY_CLASS_NAME)))
            ));
        }

        $where = $this->conditions($this->getPropertyValue(self::PROPERTY_WHERE));
        $found = $this->findMatching($className, $where);

        $orderBy = trim((string)$this->getPropertyValue(self::PROPERTY_ORDER_BY));
        if ($orderBy !== '') {
            $found = self::sort($found, $orderBy);
        }

        if ((bool)$this->getPropertyValue(self::PROPERTY_FIRST)) {
            return $this->_createRunResult($found[0] ?? null);
        }

        $limit = (int)$this->getPropertyValue(self::PROPERTY_LIMIT);

        return $this->_createRunResult($limit > 0 ? array_slice($found, 0, $limit) : $found);
    }

    /** Numbers by value, everything else naturally and case-insensitively; empty values last. */
    private static function sort(array $entries, string $orderBy): array
    {
        $descending = str_starts_with($orderBy, '-');
        $field = ltrim($orderBy, '-');

        usort($entries, static function (array $left, array $right) use ($field, $descending): int {
            $leftValue = self::valueOf($left, $field);
            $rightValue = self::valueOf($right, $field);
            $leftEmpty = $leftValue === null || $leftValue === '';
            $rightEmpty = $rightValue === null || $rightValue === '';
            if ($leftEmpty || $rightEmpty) {
                return $leftEmpty <=> $rightEmpty;
            }
            $order = is_numeric($leftValue) && is_numeric($rightValue)
                ? (float)$leftValue <=> (float)$rightValue
                : strnatcasecmp(self::text($leftValue), self::text($rightValue));

            return $descending ? -$order : $order;
        });

        return $entries;
    }
}
