<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Support\Math\ArithmeticExpression;
use Cehlers88\AnalyticsCore\Support\Property\PropertyValuePath;

/**
 * One figure out of single values: `netto * 1.19`, `(ist - soll) / soll * 100`.
 * `aggregate` calculates over a whole list - this is for everything in between,
 * which otherwise needed a macro of its own per operation.
 *
 * A name in the expression is looked up in `values` first (dotted for nested
 * values), then among the variables, so `netto * 1.19` works on a variable
 * `netto` without handing it over. See ArithmeticExpression for what an
 * expression may hold.
 */
class CalculateMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    private const string PROPERTY_EXPRESSION = 'expression';
    private const string PROPERTY_VALUES = 'values';
    private const string PROPERTY_PRECISION = 'precision';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_EXPRESSION => PropertyUi::create()->placeholder('round(netto * 1.19, 2)'),
            self::PROPERTY_VALUES => PropertyUi::map(),
            self::PROPERTY_PRECISION => PropertyUi::create()->placeholder('-1 = nicht runden'),
            default => null,
        };
    }

    public function init(): CalculateMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_EXPRESSION, MacroPropertyDTO::TYPE_STRING, 'The calculation: numbers, names, + - * / % ^, parentheses and abs, ceil, floor, max, min, round, sqrt'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUES, MacroPropertyDTO::TYPE_ARRAY, 'Values of the names in the expression (name => value) - a name not given here is read from the variables', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_PRECISION, MacroPropertyDTO::TYPE_INT, 'Decimal places to round the result to - not rounded when -1', -1));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Calculates an arithmetic expression from numbers, values and variables.';
    }

    public function getName(): string
    {
        return 'calculate';
    }

    protected function run(): ?array
    {
        $expression = trim((string)$this->getPropertyValue(self::PROPERTY_EXPRESSION));
        $values = $this->getPropertyValue(self::PROPERTY_VALUES);
        $values = is_object($values) ? (array)$values : (is_array($values) ? $values : []);
        $precision = (int)$this->getPropertyValue(self::PROPERTY_PRECISION);

        try {
            $result = ArithmeticExpression::evaluate($expression, fn(string $name): mixed => $this->valueOf($name, $values));
        } catch (\InvalidArgumentException $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(422, $exception->getMessage()));
        }

        if ($precision >= 0) {
            $result = round($result, $precision);
            // "no decimal places" is a whole number - 3, not 3.0
            if ($precision === 0) {
                $result = (int)$result;
            }
        }

        return $this->_createRunResult($result);
    }

    private function valueOf(string $name, array $values): mixed
    {
        $value = PropertyValuePath::read($values, $name);
        if ($value !== null) {
            return $value;
        }

        [$variableName, $path] = array_pad(explode('.', $name, 2), 2, '');
        $variable = VariablesProvider::UNDEFINED_VAR;
        try {
            $variable = $this->getVariablesStoreProvider()->getVariableValue($variableName, defaultValue: VariablesProvider::UNDEFINED_VAR);
        } catch (\Throwable) {
            // reported below, as every unknown name
        }
        if ($variable !== VariablesProvider::UNDEFINED_VAR && $path !== '') {
            $variable = is_array($variable) || is_object($variable) ? PropertyValuePath::read((array)$variable, $path) : null;
        }
        if ($variable === VariablesProvider::UNDEFINED_VAR || $variable === null) {
            throw new \InvalidArgumentException(sprintf('There is no value "%s" - neither in "values" nor among the variables.', $name));
        }

        return $variable;
    }
}
