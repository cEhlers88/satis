<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\Exception\ThrownByDefinitionException;

/**
 * Ends the run with an error of its own - or, inside the `try` of a tryCatch,
 * hands the message to its `catch`.
 *
 *     ["throw", {"message": "no customer given"}]
 */
class ThrowMacro extends AbstractMacro
{
    public const string DEFAULT_MESSAGE = 'Error thrown by the definition';

    private const PROPERTY_MESSAGE = 'message';

    public function init(): ThrowMacro
    {
        $this->_source = 'CoreBundle';
        $this->setProperty(MacroPropertyDTO::create(self::PROPERTY_MESSAGE, 'mixed', 'Specify the error message', self::DEFAULT_MESSAGE));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Raise an error with a message - caught by a surrounding tryCatch, it ends the run otherwise.';
    }

    public function getName(): string
    {
        return 'throw';
    }

    protected function run(): ?array
    {
        $message = $this->getPropertyValue(self::PROPERTY_MESSAGE);

        if (!is_string($message)) {
            $message = is_scalar($message) ? (string)$message : (json_encode($message, JSON_UNESCAPED_UNICODE) ?: '');
        }

        throw new ThrownByDefinitionException(trim((string)$message) !== '' ? $message : self::DEFAULT_MESSAGE);
    }
}
