<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class StrPosMacro extends AbstractMacro
{
    private const PROPERTY_HAYSTACK = 'haystack';
    private const PROPERTY_NEEDLE = 'needle';
    private const PROPERTY_OFFSET = 'offset';

    protected function run(): ?array
    {
        return $this->_createRunResult(strpos(
            $this->getPropertyValue(self::PROPERTY_HAYSTACK),
            $this->getPropertyValue(self::PROPERTY_NEEDLE),
            $this->getPropertyValue(self::PROPERTY_OFFSET)
        ));
    }

    public function init(): StrPosMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_HAYSTACK, ['string'], 'The string to search in'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NEEDLE, ['string'], 'The string to search for'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_OFFSET, ['int'], 'The offset to start searching from', 0));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Find the position of the first occurrence of a substring in a string';
    }

    public function getName(): string
    {
        return 'strPos';
    }

}