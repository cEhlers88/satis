<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;

/**
 * A number as people read it - `1.234,56 €` instead of `1234.56` in a report,
 * a push notification or the journal. German or English separators, as a plain
 * number, an amount or a percentage (the value is the percentage itself: 12.5
 * is "12,5 %"). A list is formatted entry by entry.
 *
 * Written with number_format() rather than intl, which is not on every server.
 */
class FormatNumberMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const string STYLE_NUMBER = 'number';
    public const string STYLE_CURRENCY = 'currency';
    public const string STYLE_PERCENT = 'percent';

    private const string PROPERTY_VALUE = 'value';
    private const string PROPERTY_DECIMALS = 'decimals';
    private const string PROPERTY_STYLE = 'style';
    private const string PROPERTY_CURRENCY = 'currency';
    private const string PROPERTY_LOCALE = 'locale';

    /** locale => [decimal separator, thousands separator] */
    private const array SEPARATORS = [
        'de' => [',', '.'],
        'en' => ['.', ','],
    ];

    private const array CURRENCY_SYMBOLS = [
        'EUR' => '€',
        'USD' => '$',
        'GBP' => '£',
        'CHF' => 'CHF',
    ];

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_STYLE => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options([
                self::STYLE_NUMBER => 'Zahl (1.234,56)',
                self::STYLE_CURRENCY => 'Betrag (1.234,56 €)',
                self::STYLE_PERCENT => 'Prozent (12,5 %)',
            ]),
            self::PROPERTY_LOCALE => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options([
                'de' => 'Deutsch (1.234,56)',
                'en' => 'Englisch (1,234.56)',
            ]),
            self::PROPERTY_CURRENCY => PropertyUi::create()->options(array_combine(
                array_keys(self::CURRENCY_SYMBOLS),
                array_keys(self::CURRENCY_SYMBOLS)
            )),
            self::PROPERTY_DECIMALS => PropertyUi::create()->placeholder('2'),
            default => null,
        };
    }

    public function init(): FormatNumberMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'mixed', 'The number to format - a list is formatted entry by entry'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DECIMALS, MacroPropertyDTO::TYPE_INT, 'Decimal places', 2))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_STYLE, MacroPropertyDTO::TYPE_STRING, 'number, currency or percent', self::STYLE_NUMBER))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CURRENCY, MacroPropertyDTO::TYPE_STRING, 'Currency code for the style currency (EUR, USD, ...)', 'EUR'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_LOCALE, MacroPropertyDTO::TYPE_STRING, 'de or en', 'de'));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Formats a number as a readable text, an amount or a percentage.';
    }

    public function getName(): string
    {
        return 'formatNumber';
    }

    protected function run(): ?array
    {
        $value = $this->getPropertyValue(self::PROPERTY_VALUE);
        $decimals = max(0, min(10, (int)$this->getPropertyValue(self::PROPERTY_DECIMALS)));
        $style = strtolower(trim((string)$this->getPropertyValue(self::PROPERTY_STYLE)));
        $style = $style === '' ? self::STYLE_NUMBER : $style;
        $locale = strtolower(substr(trim((string)$this->getPropertyValue(self::PROPERTY_LOCALE)), 0, 2));
        $currency = strtoupper(trim((string)$this->getPropertyValue(self::PROPERTY_CURRENCY)));

        if (!in_array($style, [self::STYLE_NUMBER, self::STYLE_CURRENCY, self::STYLE_PERCENT], true)) {
            return $this->_createRunResult(null, ErrorDTO::create(422, sprintf('Unknown style "%s" - use number, currency or percent.', $style)));
        }
        if (!isset(self::SEPARATORS[$locale])) {
            $locale = 'de';
        }

        try {
            $formatted = is_array($value)
                ? array_map(fn(mixed $entry): string => self::format($entry, $decimals, $style, $currency === '' ? 'EUR' : $currency, $locale), $value)
                : self::format($value, $decimals, $style, $currency === '' ? 'EUR' : $currency, $locale);
        } catch (\InvalidArgumentException $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(422, $exception->getMessage()));
        }

        return $this->_createRunResult($formatted);
    }

    /**
     * @throws \InvalidArgumentException when the value is no number
     */
    public static function format(mixed $value, int $decimals, string $style, string $currency, string $locale): string
    {
        if (is_string($value)) {
            $value = trim($value);
        }
        if (!is_int($value) && !is_float($value) && !(is_string($value) && is_numeric($value))) {
            throw new \InvalidArgumentException(sprintf(
                '%s is no number.', is_scalar($value) ? '"' . $value . '"' : get_debug_type($value)
            ));
        }

        [$decimalSeparator, $thousandsSeparator] = self::SEPARATORS[$locale] ?? self::SEPARATORS['de'];
        $number = number_format((float)$value, $decimals, $decimalSeparator, $thousandsSeparator);
        // -0,00 is no amount anybody writes
        if (preg_match('/^-[0.,]+$/', $number) === 1) {
            $number = substr($number, 1);
        }

        return match ($style) {
            self::STYLE_CURRENCY => self::withCurrency($number, $currency, $locale),
            self::STYLE_PERCENT => $locale === 'de' ? $number . "\u{00A0}%" : $number . '%',
            default => $number,
        };
    }

    private static function withCurrency(string $number, string $currency, string $locale): string
    {
        $symbol = self::CURRENCY_SYMBOLS[$currency] ?? $currency;
        if ($locale === 'de') {
            return $number . "\u{00A0}" . $symbol;
        }
        // English puts a sign in front of the symbol: -$5.00
        $sign = str_starts_with($number, '-') ? '-' : '';
        $separator = mb_strlen($symbol) > 1 ? "\u{00A0}" : '';

        return $sign . $symbol . $separator . ltrim($number, '-');
    }
}
