<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Support\Property\PropertyValuePath;

/**
 * Reshapes every entry of a list - the step between `filter` and a report,
 * `implode` or an external service, which otherwise took a `for` with `setVar`.
 *
 * `field` turns the list into the values of one (dotted) field. `fields` keeps
 * only the named ones: as a list under their own names, as an object under new
 * ones ("customer": "customer.name"). Missing values become null, so every entry
 * has the same keys.
 */
class MapMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    private const string PROPERTY_DATA = 'data';
    private const string PROPERTY_FIELD = 'field';
    private const string PROPERTY_FIELDS = 'fields';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_FIELD => PropertyUi::create()->placeholder('customer.name'),
            self::PROPERTY_FIELDS => PropertyUi::create()->placeholder('["id", "amount"] oder {"kunde": "customer.name"}'),
            default => null,
        };
    }

    public function init(): MapMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DATA, MacroPropertyDTO::TYPE_ARRAY, 'The list to reshape'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_FIELD, MacroPropertyDTO::TYPE_STRING, 'Turns every entry into the value of this field, dotted for nested values', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_FIELDS, MacroPropertyDTO::TYPE_ARRAY, 'Keeps only these fields - a list of fields, or new name => field', []));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Turns every entry of a list into one of its values or into a selection of its fields.';
    }

    public function getName(): string
    {
        return 'map';
    }

    protected function run(): ?array
    {
        $entries = self::toEntries($this->getPropertyValue(self::PROPERTY_DATA));
        $field = trim((string)$this->getPropertyValue(self::PROPERTY_FIELD));
        $fields = self::toFieldMap($this->getPropertyValue(self::PROPERTY_FIELDS));

        if ($field !== '' && $fields !== []) {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'Give either "field" or "fields", not both.'));
        }
        if ($field === '' && $fields === []) {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'Name the field to read ("field") or the fields to keep ("fields").'));
        }

        if ($field !== '') {
            return $this->_createRunResult(array_map(static fn(mixed $entry): mixed => self::readField($entry, $field), $entries));
        }

        return $this->_createRunResult(array_map(static function (mixed $entry) use ($fields): array {
            $mapped = [];
            foreach ($fields as $name => $path) {
                $mapped[$name] = self::readField($entry, $path);
            }

            return $mapped;
        }, $entries));
    }

    /**
     * new name => field. A list of one field reaches the macro unwrapped
     * (AbstractMacro::execute()), as a plain text.
     *
     * @return array<string, string>
     */
    private static function toFieldMap(mixed $fields): array
    {
        if (is_object($fields)) {
            $fields = (array)$fields;
        }
        if (is_string($fields)) {
            $fields = trim($fields) === '' ? [] : [$fields];
        }
        if (!is_array($fields)) {
            return [];
        }

        $map = [];
        foreach ($fields as $name => $path) {
            $path = trim((string)$path);
            if ($path === '') {
                continue;
            }
            $map[is_int($name) ? $path : (string)$name] = $path;
        }

        return $map;
    }

    /**
     * The entries of a list. A list of one entry reaches the macro unwrapped
     * (AbstractMacro::execute()), so a single record counts as a list of it.
     */
    private static function toEntries(mixed $data): array
    {
        if ($data === null) {
            return [];
        }

        return is_array($data) && array_is_list($data) ? $data : [$data];
    }

    private static function readField(mixed $entry, string $field): mixed
    {
        if (is_object($entry)) {
            $entry = method_exists($entry, 'jsonSerialize') ? $entry->jsonSerialize() : (array)$entry;
        }

        return is_array($entry) ? PropertyValuePath::read($entry, $field) : null;
    }
}
