<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\ValueHelper;

use Cehlers88\AnalyticsCore\Macro\PropertyUi\MapKeySuggestionsInterface;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroValueHelperValidationResultDTO;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\AbstractValueHelper;

/**
 * Suggests the keys of a map property (MapPropertyUi::suggestKeysFromMacro()) by asking the
 * macro of the command - one helper for every macro, each one knows its own keys
 * (MapKeySuggestionsInterface). A macro that does not answer gets no suggestions.
 */
final class MapKeysValueHelper extends AbstractValueHelper
{
    public function getDescription(): string
    {
        return 'Suggests the keys of a map property - asked of the macro of the command.';
    }

    public function getDefinition(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): array
    {
        $macro = $this->_currentMacro ?? null;
        $keys = $macro instanceof MapKeySuggestionsInterface
            ? $macro->suggestMapKeys($this->getContext()->propertyName, $this->getContext()->properties)
            : [];

        $selectOptions = [];
        foreach ($keys as $key => $label) {
            $selectOptions[] = $this->buildOption((string)$key, (string)$label);
        }

        return $this->buildSelectDefinition($selectOptions, null);
    }

    public function validate(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): MacroValueHelperValidationResultDTO
    {
        // suggestions - any other key may be written as well
        return MacroValueHelperValidationResultDTO::create(true);
    }
}
