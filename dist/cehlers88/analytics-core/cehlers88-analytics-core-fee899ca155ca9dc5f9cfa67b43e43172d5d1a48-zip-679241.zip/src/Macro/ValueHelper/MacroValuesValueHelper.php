<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\ValueHelper;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroValueHelperValidationResultDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\ValueSuggestionsInterface;

/**
 * Suggests the values of a property (PropertyUi::suggestValuesFromMacro()) by asking the macro
 * of the command - the counterpart to MapKeysValueHelper for a single value. A helper is
 * instantiated without services, the macro has them (ValueSuggestionsInterface). A macro that
 * does not answer gets no suggestions.
 */
final class MacroValuesValueHelper extends AbstractValueHelper
{
    public function getDescription(): string
    {
        return 'Suggests the values of a property - asked of the macro of the command.';
    }

    public function getDefinition(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): array
    {
        $macro = $this->_currentMacro ?? null;
        $values = $macro instanceof ValueSuggestionsInterface
            ? $macro->suggestValues($this->getContext()->propertyName, $this->getContext()->properties)
            : [];

        $selectOptions = [];
        foreach ($values as $value => $label) {
            $selectOptions[] = $this->buildOption((string)$value, (string)$label);
        }

        return $this->buildSelectDefinition($selectOptions, $propertyDTO->value ?? null);
    }

    public function validate(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): MacroValueHelperValidationResultDTO
    {
        // suggestions - a value may as well come from a command or be written by hand
        return MacroValueHelperValidationResultDTO::create(true);
    }
}
