<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\PropertyUi\MapKeySuggestionsInterface;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\MapPropertyUi;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\ExternalServiceFunction;
use Cehlers88\AnalyticsCore\Executor\ExecutorProvider;
use Cehlers88\AnalyticsCore\Executor\ExternalServiceExecutor;
use Cehlers88\AnalyticsCore\Interface\Repository\IExternalServiceFunctionRepository;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\ValueMapper\ValueMapperResultDTO;

/**
 * Calls a function of an external service and returns its response - what the response
 * mappings of the function make of it, when it has some. The call goes through
 * ExternalServiceExecutor, so it behaves like "Ausführen" in the dashboard and like
 * `run:external-service`. `arguments` and `options` are objects, edited key by key
 * (MapPropertyUi); the arguments of the function named are suggested as keys.
 */
class CallExternalServiceMacro extends AbstractMacro implements PropertyUiProviderInterface, MapKeySuggestionsInterface
{
    private const PROPERTY_SERVICE = 'service';
    private const PROPERTY_FUNCTION = 'function';
    private const PROPERTY_ARGUMENTS = 'arguments';
    private const PROPERTY_OPTIONS = 'options';

    public function __construct(
        private ExecutorProvider                   $executorProvider,
        private IExternalServiceFunctionRepository $externalServiceFunctionRepository,
    )
    {
    }

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_ARGUMENTS => MapPropertyUi::suggestKeysFromMacro(MapPropertyUi::create())->displayName('Arguments'),
            self::PROPERTY_OPTIONS => MapPropertyUi::create()->displayName('Options'),
            default => null,
        };
    }

    /** The arguments of the function the command names - as long as service and function are named directly. */
    public function suggestMapKeys(string $propertyName, array $properties): array
    {
        $service = $properties[self::PROPERTY_SERVICE] ?? null;
        $function = $properties[self::PROPERTY_FUNCTION] ?? null;
        if ($propertyName !== self::PROPERTY_ARGUMENTS
            || !is_string($service) || trim($service) === ''
            || !is_string($function) || trim($function) === '') {
            return [];
        }
        $externalServiceFunction = $this->externalServiceFunctionRepository->findOneByServiceAndName(trim($service), trim($function));
        if (!$externalServiceFunction instanceof ExternalServiceFunction) {
            return [];
        }

        // Stored as PropertyDTO::createFromArray reads them: [type, name, default]; a default makes it optional.
        $keys = [];
        foreach ($externalServiceFunction->getArguments() as $argument) {
            if (!is_array($argument) || !isset($argument[1]) || !is_string($argument[1]) || $argument[1] === '') {
                continue;
            }
            $keys[$argument[1]] = implode(' · ', array_filter([
                is_string($argument[0] ?? null) ? $argument[0] : null,
                isset($argument[2]) ? 'optional' : 'required',
            ]));
        }

        return $keys;
    }

    public function init(): CallExternalServiceMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_SERVICE, ['string'], 'The name of the external service'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_FUNCTION, ['string'], 'The name of the function to call'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ARGUMENTS, ['array'], 'The arguments of the function by name - read in its options with get_var in the context "argument"', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_OPTIONS, ['array'], 'Options of this call by name; they override the options of the service and the function', []));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Calls a function of an external service and returns its response.';
    }

    public function getName(): string
    {
        return 'callExternalService';
    }

    protected function run(): ?array
    {
        $service = $this->getPropertyValue(self::PROPERTY_SERVICE);
        $function = $this->getPropertyValue(self::PROPERTY_FUNCTION);
        if (!is_string($service) || trim($service) === '' || !is_string($function) || trim($function) === '') {
            return $this->_createRunResult(null, ErrorDTO::create(400, 'callExternalService needs the name of a service and of a function'));
        }

        /** @var ExternalServiceExecutor|null $executor */
        $executor = $this->executorProvider->getExecutor(ExternalServiceExecutor::class);
        if ($executor === null) {
            return $this->_createRunResult(null, ErrorDTO::create(500, 'No executor found for ' . ExternalServiceExecutor::class));
        }

        // The executor is a shared service and keeps its errors: a failed call before this one must not fail it.
        $executor->errors = [];
        $executor
            ->setPropertyValue(ExternalServiceExecutor::KEY_SERVICE_NAME, trim($service))
            ->setPropertyValue(ExternalServiceExecutor::KEY_FUNCTION_NAME, trim($function))
            ->setPropertyValue(ExternalServiceExecutor::KEY_ARGUMENTS, $this->map($this->getPropertyValue(self::PROPERTY_ARGUMENTS)))
            ->setPropertyValue(ExternalServiceExecutor::KEY_OPTIONS, $this->map($this->getPropertyValue(self::PROPERTY_OPTIONS)));
        $executor->run();

        if ($executor->hasError()) {
            $first = $executor->errors[0] ?? null;

            return $this->_createRunResult(null, ErrorDTO::create(
                $first?->number ?? 500,
                $executor->getErrorsAsString('; '),
                $first?->data,
            ));
        }

        $result = $executor->getLastResult();

        return $this->_createRunResult($result instanceof ValueMapperResultDTO ? $result->data : $result);
    }

    /**
     * A map property as a list by name. An object - a definition decoded without `assoc` - is
     * taken as one; the command player only looks into arrays for commands, so the commands
     * among its values are run here (as in startProcedure).
     */
    private function map(mixed $value): array
    {
        if (is_array($value)) {
            return $value;
        }
        if (!is_object($value)) {
            return [];
        }

        $map = json_decode((string)json_encode($value), true);
        if (!is_array($map)) {
            return [];
        }
        $commandPlayer = $this->getMacroEnvironment()->getCommandPlayer();
        foreach ($map as $name => $entry) {
            if (is_array($entry) && $commandPlayer->describesCommands($entry)) {
                $map[$name] = $commandPlayer->run($entry);
            }
        }

        return $map;
    }
}
