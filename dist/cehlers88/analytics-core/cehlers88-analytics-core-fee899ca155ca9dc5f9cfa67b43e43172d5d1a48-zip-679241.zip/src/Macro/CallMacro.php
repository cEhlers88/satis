<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Support\FunctionArguments;

/**
 * Calls a function the macro "function" defined. The arguments are checked against what the
 * function declares (FunctionArguments) before any of its commands runs; they are readable
 * in the variable context "argument" while it runs and gone afterwards.
 */
class CallMacro extends AbstractMacro
{
    private const string PROPERTY_ARGUMENTS = 'arguments';
    private const string PROPERTY_NAME = 'name';

    public function init(): CallMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME, 'string', 'Specify the function'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ARGUMENTS, 'Command[]|string', 'The arguments of the function by name', []));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Call a function.';
    }

    public function getName(): string
    {
        return 'call';
    }

    protected function run(): ?array
    {
        $name = trim((string)$this->getPropertyValue(self::PROPERTY_NAME));
        $function = $this->getMacroEnvironment()->getFunction($name);
        if ($function === null) {
            return $this->_createRunResult(null, ErrorDTO::create(404, 'Function "' . $name . '" is not defined - a function has to be defined before it is called.'));
        }

        $commandPlayer = $this->getMacroEnvironment()->getCommandPlayer();
        try {
            $arguments = FunctionArguments::resolve(
                $name,
                $function['arguments'],
                $this->givenArguments($this->getPropertyValue(self::PROPERTY_ARGUMENTS)),
                static fn(mixed $commands): mixed => $commandPlayer->run($commands)
            );
        } catch (\InvalidArgumentException $e) {
            return $this->_createRunResult(null, ErrorDTO::create(422, $e->getMessage()));
        }

        $variables = $this->getVariablesStoreProvider();
        $variables->startArgumentsContext();
        try {
            foreach ($arguments as $key => $value) {
                $variables->setArgument((string)$key, $value);
            }

            return $this->_createRunResult($commandPlayer->run($function['content']));
        } finally {
            // also when a command fails: the arguments must not outlive the call
            $variables->clearArgumentsContext();
        }
    }

    /**
     * The arguments by name. An object - a definition decoded without `assoc` - or its JSON is
     * taken as one; the command player only looks into arrays for commands, so the commands
     * among the values of an object are run here.
     */
    private function givenArguments(mixed $given): array
    {
        if (is_string($given)) {
            $given = trim($given) === '' ? [] : json_decode($given);
        }
        if (is_array($given)) {
            return $given;
        }
        if (!is_object($given)) {
            return [];
        }

        $arguments = json_decode((string)json_encode($given), true);
        if (!is_array($arguments)) {
            return [];
        }
        $commandPlayer = $this->getMacroEnvironment()->getCommandPlayer();
        foreach ($arguments as $key => $value) {
            if (is_array($value) && $commandPlayer->describesCommands($value)) {
                $arguments[$key] = $commandPlayer->run($value);
            }
        }

        return $arguments;
    }
}
