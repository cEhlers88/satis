<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\PropertyUi;

use Cehlers88\AnalyticsCore\Macro\ValueHelper\MapKeysValueHelper;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;

/**
 * A property that takes keys with a value each - an object such as the `props` of
 * startProcedure: `{"customer": "Ada", "today": ["date", {…}]}`. The command editors show it
 * in a <map-editor> (assets/customElement/MapEditor.ts); every value is a text or a command,
 * and a macro that runs its commands first (the default) gets their results.
 *
 *     public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
 *     {
 *         return $property->name === 'props' ? MapPropertyUi::create() : null;
 *     }
 *
 * The keys can be suggested: fixed ones with keyOptions(), or - when they depend on the
 * definition, say on another property - by the macro itself through MapKeySuggestionsInterface
 * with suggestKeysFromMacro().
 */
final class MapPropertyUi
{
    public const string EDITOR_MAP = 'map';
    public const string KEY_KEY_OPTIONS = 'keyOptions';
    public const string KEY_KEY_VALUE_HELPER = 'keyValueHelper';

    public static function create(): PropertyUi
    {
        return PropertyUi::create()->editor(self::EDITOR_MAP);
    }

    /**
     * @param array<string, string>|list<string> $keys key => label, or plain keys
     */
    public static function keyOptions(PropertyUi $ui, array $keys): PropertyUi
    {
        if (array_is_list($keys)) {
            $keys = array_combine(array_map('strval', $keys), array_map('strval', $keys));
        }

        return $ui->with(self::KEY_KEY_OPTIONS, $keys);
    }

    /** The keys come from the macro (MapKeySuggestionsInterface), asked while the property is edited. */
    public static function suggestKeysFromMacro(PropertyUi $ui): PropertyUi
    {
        return $ui->with(self::KEY_KEY_VALUE_HELPER, ['name' => MapKeysValueHelper::class, 'options' => []]);
    }
}
