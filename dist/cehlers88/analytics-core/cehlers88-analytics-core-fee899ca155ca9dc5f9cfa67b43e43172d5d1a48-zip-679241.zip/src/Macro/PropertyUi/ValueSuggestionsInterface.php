<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\PropertyUi;

/**
 * A macro that suggests the values of one of its properties from what the installation holds -
 * getCustomObject the custom objects for its `nameOrId`. Asked by MacroValuesValueHelper on the
 * instance the container holds, so the macro may use its services; the property names the
 * helper with PropertyUi::suggestValuesFromMacro().
 */
interface ValueSuggestionsInterface
{
    /**
     * @param string $propertyName the property whose values are asked for
     * @param array<string, mixed> $properties the properties of the command as they are written
     *                                         right now - a value may still be a command
     * @return array<string, string> value => what it is (shown next to it)
     */
    public function suggestValues(string $propertyName, array $properties): array;
}
