<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\PropertyUi;

/**
 * A macro that suggests the keys of a map property (MapPropertyUi) from the definition being
 * edited - startProcedure the arguments of the procedure its `name` names. Asked by
 * MapKeysValueHelper on the instance the container holds, so the macro may use its services.
 */
interface MapKeySuggestionsInterface
{
    /**
     * @param string $propertyName the map property whose keys are asked for
     * @param array<string, mixed> $properties the properties of the command as they are written
     *                                         right now - a value may still be a command
     * @return array<string, string> key => what it is (shown next to it)
     */
    public function suggestMapKeys(string $propertyName, array $properties): array;
}
