<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\PropertyUi\MapKeySuggestionsInterface;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\MapPropertyUi;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\Procedure;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Player\ProcedurePlayer;
use Cehlers88\AnalyticsCore\Repository\ProcedureRepository;
use Cehlers88\AnalyticsCore\Support\ProcedureArguments;

/**
 * Starts a stored procedure. `props` are its arguments by name - an object, edited key by key
 * (MapPropertyUi), with the arguments of the procedure `name` names suggested as keys.
 */
class StartProcedureMacro extends AbstractMacro implements PropertyUiProviderInterface, MapKeySuggestionsInterface
{
    private const PROPERTY_NAME = 'name';
    private const PROPERTY_PROPS = 'props';

    public function __construct(
        private ProcedurePlayer     $procedurePlayer,
        private ProcedureRepository $procedureRepository,
    )
    {
    }

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return $property->name === self::PROPERTY_PROPS
            ? MapPropertyUi::suggestKeysFromMacro(MapPropertyUi::create())->displayName('Arguments')
            : null;
    }

    /** The arguments of the procedure the command names - as long as it names one directly. */
    public function suggestMapKeys(string $propertyName, array $properties): array
    {
        $name = $properties[self::PROPERTY_NAME] ?? null;
        if ($propertyName !== self::PROPERTY_PROPS || !is_string($name) || trim($name) === '') {
            return [];
        }
        $procedure = $this->procedureRepository->findOneBy(['name' => trim($name)]);
        if (!$procedure instanceof Procedure) {
            return [];
        }

        $keys = [];
        foreach (ProcedureArguments::read($procedure->getProperties()) as $argument) {
            $keys[$argument['name']] = implode(' · ', array_filter([
                $argument['type'],
                $argument['required'] ? 'required' : ($argument['command'] ? 'default from commands' : null),
                $argument['description'],
            ]));
        }

        return $keys;
    }

    public function init(): StartProcedureMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME, ['string'], 'The name of the procedure to start'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_PROPS, ['array'], 'The arguments of the procedure by name - read there with get_var in the context "argument"; a missing one takes its default', []));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Starts an procedure.';
    }

    public function getName(): string
    {
        return 'startProcedure';
    }

    protected function run(): ?array
    {
        $playerResult = $this->procedurePlayer->startProcedure(
            $this->getPropertyValue(self::PROPERTY_NAME),
            $this->arguments($this->getPropertyValue(self::PROPERTY_PROPS))
        );

        return $this->_createRunResult(
            $playerResult instanceof ErrorDTO ? null : $playerResult,
            $playerResult instanceof ErrorDTO ? $playerResult : null,
        );
    }

    /**
     * The arguments as a list by name. An object - a definition decoded without `assoc` - is
     * taken as one; the command player only looks into arrays for commands, so the commands
     * among its values are run here.
     */
    private function arguments(mixed $props): array
    {
        if (is_array($props)) {
            return $props;
        }
        if (!is_object($props)) {
            return [];
        }

        $arguments = json_decode((string)json_encode($props), true);
        if (!is_array($arguments)) {
            return [];
        }
        $commandPlayer = $this->getMacroEnvironment()->getCommandPlayer();
        foreach ($arguments as $name => $value) {
            if (is_array($value) && $commandPlayer->describesCommands($value)) {
                $arguments[$name] = $commandPlayer->run($value);
            }
        }

        return $arguments;
    }
}
