<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Repository\ApplicationActionRepository;

class GetApplicationActionMacro extends AbstractMacro
{
    private const PROPERTY_ACTION_NAME = 'actionName';
    private const PROPERTY_ACTION_RETURN_STATE_ONLY = 'stateOnly';

    public function __construct(
        private ApplicationActionRepository $_applicationActionRepository
    )
    {

    }

    public function init(): GetApplicationActionMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ACTION_NAME, 'string', 'The name of the Action to find'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ACTION_RETURN_STATE_ONLY, 'boolean', 'Specify whether to return only the state of the action', false));

        return $this;
    }

    protected function run(): ?array
    {
        // action names are unique per application only (like startAction and stopAction,
        // look in the application the macro runs for); without one, any action of that name
        $criteria = ['name' => $this->getPropertyValue(self::PROPERTY_ACTION_NAME)];
        $application = $this->getMacroEnvironment()->getApplication();
        if ($application !== null) {
            $criteria['application'] = $application;
        }
        $applicationAction = $this->_applicationActionRepository->findOneBy($criteria);

        if ($applicationAction === null) {
            $this->getLogger()->error('Application action not found');
            return $this->_createRunResult(null, ErrorDTO::create(
                404,
                // without an application the action was looked for everywhere
                $application === null
                    ? sprintf('Application action "%s" not found', $this->getPropertyValue(self::PROPERTY_ACTION_NAME))
                    : sprintf('Application action "%s" in Application "%s" not found',
                        $this->getPropertyValue(self::PROPERTY_ACTION_NAME),
                        $application->getName()
                    )
            ));
        }
        $stateOnly = $this->getPropertyValue(self::PROPERTY_ACTION_RETURN_STATE_ONLY);

        if ($stateOnly) {
            return $this->_createRunResult($applicationAction->isActive());
        }

        return $this->_createRunResult([
            'actionName' => $applicationAction->getName(),
            'actionDescription' => $applicationAction->getDescription(),
            'categories' => $applicationAction->getCategories()->toArray(),
            'startCommands' => $applicationAction->getStartCommands(),
            'stopCommands' => $applicationAction->getStopCommands(),
            'active' => $applicationAction->isActive(),
            'reason' => $applicationAction->getReason(),
        ]);
    }

    public function getName(): string
    {
        return 'getApplicationAction';
    }

    public function getDescription(): string
    {
        return 'Return a ApplicationAction.';
    }
}