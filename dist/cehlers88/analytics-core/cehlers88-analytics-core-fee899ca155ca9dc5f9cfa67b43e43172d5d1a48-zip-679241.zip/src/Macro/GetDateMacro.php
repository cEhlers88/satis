<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use DateTimeImmutable;
use DateTimeZone;

/**
 * A date as text: now or a given one, moved by a relative expression
 * ("-1 month", "first day of this month") and formatted with a PHP date format.
 * Lets a command work out periods like "last month" itself instead of
 * expecting them as fixed values.
 */
class GetDateMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const string FORMAT_TIMESTAMP = 'U';

    private const string PROPERTY_DATE = 'date';
    private const string PROPERTY_MODIFY = 'modify';
    private const string PROPERTY_FORMAT = 'format';
    private const string PROPERTY_TIMEZONE = 'timezone';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_DATE => PropertyUi::create()->placeholder('now'),
            self::PROPERTY_MODIFY => PropertyUi::create()->options([
                'today' => 'heute, 00:00',
                '-1 day' => 'gestern',
                'monday this week' => 'Montag dieser Woche',
                'first day of this month' => 'Erster dieses Monats',
                'last day of this month' => 'Letzter dieses Monats',
                'first day of last month' => 'Erster des Vormonats',
                'last day of last month' => 'Letzter des Vormonats',
                'first day of january this year' => 'Jahresbeginn',
            ]),
            self::PROPERTY_FORMAT => PropertyUi::create()->options([
                'Y-m-d' => '2026-10-21',
                'Y-m-d H:i:s' => '2026-10-21 07:00:00',
                'd.m.Y' => '21.10.2026',
                'd.m.Y H:i' => '21.10.2026 07:00',
                'Y-m' => '2026-10',
                DATE_ATOM => 'ISO 8601',
                self::FORMAT_TIMESTAMP => 'Unix-Zeitstempel',
            ]),
            self::PROPERTY_TIMEZONE => PropertyUi::create()->placeholder(date_default_timezone_get()),
            default => null,
        };
    }

    public function init(): GetDateMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DATE, [MacroPropertyDTO::TYPE_STRING, MacroPropertyDTO::TYPE_INT], 'The date to start from - a date text or a unix timestamp, now when empty', 'now'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_MODIFY, MacroPropertyDTO::TYPE_STRING, 'Relative change of the date, e.g. "-1 month" or "first day of this month"', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_FORMAT, MacroPropertyDTO::TYPE_STRING, 'PHP date format of the result - "U" returns the unix timestamp as a number', 'Y-m-d H:i:s'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TIMEZONE, MacroPropertyDTO::TYPE_STRING, 'Timezone, e.g. "Europe/Berlin" - the one of the server when empty', ''));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Returns a date, optionally moved by a relative expression and formatted.';
    }

    public function getName(): string
    {
        return 'getDate';
    }

    protected function run(): ?array
    {
        try {
            $timezone = $this->readTimezone();
            $date = $this->readDate($timezone);
            $modify = trim((string)$this->getPropertyValue(self::PROPERTY_MODIFY));

            if ($modify !== '') {
                // PHP 8.3 answers a malformed expression with false and a warning, 8.4 throws
                $modified = @$date->modify($modify);
                if ($modified === false) {
                    throw new \InvalidArgumentException(sprintf('Invalid modification "%s".', $modify));
                }
                $date = $modified;
            }
        } catch (\Throwable $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(422, $exception->getMessage()));
        }

        $format = (string)$this->getPropertyValue(self::PROPERTY_FORMAT);
        if ($format === '') {
            $format = 'Y-m-d H:i:s';
        }

        return $this->_createRunResult(
            $format === self::FORMAT_TIMESTAMP ? $date->getTimestamp() : $date->format($format)
        );
    }

    private function readTimezone(): DateTimeZone
    {
        $timezone = trim((string)$this->getPropertyValue(self::PROPERTY_TIMEZONE));

        try {
            return new DateTimeZone($timezone === '' ? date_default_timezone_get() : $timezone);
        } catch (\Throwable) {
            throw new \InvalidArgumentException(sprintf('Unknown timezone "%s".', $timezone));
        }
    }

    private function readDate(DateTimeZone $timezone): DateTimeImmutable
    {
        $date = $this->getPropertyValue(self::PROPERTY_DATE);

        if ($date === null || $date === '') {
            return new DateTimeImmutable('now', $timezone);
        }

        if (is_int($date) || (is_string($date) && preg_match('/^-?\d{9,}$/', $date) === 1)) {
            // a timestamp is UTC by definition - the timezone only decides how it is shown
            return (new DateTimeImmutable('@' . $date))->setTimezone($timezone);
        }

        try {
            return new DateTimeImmutable((string)$date, $timezone);
        } catch (\Throwable) {
            throw new \InvalidArgumentException(sprintf('Invalid date "%s".', (string)$date));
        }
    }
}
