<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;

/**
 * A text against a regular expression: does it match, what is the first match,
 * all matches, or the groups of the first one. strPos and strReplace only know
 * fixed texts - an invoice number out of a subject needs a pattern.
 *
 * The pattern is a PCRE pattern with delimiters (`/RE-(\d+)/i`, also # ~ % @ ! | +).
 * Written without them (`RE-(\d+)`) it is taken as it is, delimited by `~`.
 */
class RegexMatchMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const string MODE_TEST = 'test';
    public const string MODE_FIRST = 'first';
    public const string MODE_ALL = 'all';
    public const string MODE_GROUPS = 'groups';

    private const string PROPERTY_SUBJECT = 'subject';
    private const string PROPERTY_PATTERN = 'pattern';
    private const string PROPERTY_MODE = 'mode';

    private const array MODES = [
        self::MODE_TEST => 'passt? (true/false)',
        self::MODE_FIRST => 'erster Treffer',
        self::MODE_ALL => 'alle Treffer',
        self::MODE_GROUPS => 'Gruppen des ersten Treffers',
    ];

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_PATTERN => PropertyUi::create()->placeholder('/RE-(?<nr>\d+)/i'),
            self::PROPERTY_MODE => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options(self::MODES),
            default => null,
        };
    }

    public function init(): RegexMatchMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_SUBJECT, MacroPropertyDTO::TYPE_STRING, 'The text to search'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_PATTERN, MacroPropertyDTO::TYPE_STRING, 'Regular expression, e.g. "/RE-(\d+)/i" - without delimiters it is taken as it is'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_MODE, MacroPropertyDTO::TYPE_STRING, 'test: true/false, first: the first match, all: every match, groups: the groups of the first match', self::MODE_TEST));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Matches a text against a regular expression - whether it matches, the first or all matches, or the groups.';
    }

    public function getName(): string
    {
        return 'regexMatch';
    }

    protected function run(): ?array
    {
        $subject = $this->getPropertyValue(self::PROPERTY_SUBJECT);
        $subject = is_scalar($subject) || $subject === null ? (string)$subject : json_encode($subject);
        $pattern = self::delimit((string)$this->getPropertyValue(self::PROPERTY_PATTERN));
        $mode = strtolower(trim((string)$this->getPropertyValue(self::PROPERTY_MODE)));
        if ($mode === '') {
            $mode = self::MODE_TEST;
        }

        if (!array_key_exists($mode, self::MODES)) {
            return $this->_createRunResult(null, ErrorDTO::create(422, sprintf(
                'Unknown mode "%s" - use one of %s.', $mode, implode(', ', array_keys(self::MODES))
            )));
        }
        if ($pattern === '') {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'The pattern is empty.'));
        }

        $matches = [];
        $found = $mode === self::MODE_ALL
            ? @preg_match_all($pattern, $subject, $matches)
            : @preg_match($pattern, $subject, $matches);
        if ($found === false) {
            return $this->_createRunResult(null, ErrorDTO::create(422, sprintf(
                'Invalid pattern "%s": %s', $pattern, preg_last_error_msg()
            )));
        }

        return $this->_createRunResult(match ($mode) {
            self::MODE_TEST => $found > 0,
            self::MODE_FIRST => $found > 0 ? $matches[0] : null,
            self::MODE_ALL => $matches[0],
            self::MODE_GROUPS => $found > 0 ? self::groups($matches) : null,
        });
    }

    /** A pattern written without delimiters gets `~` - a `~` inside is escaped. */
    public static function delimit(string $pattern): string
    {
        $pattern = trim($pattern);
        if ($pattern === '') {
            return '';
        }

        // Bracket delimiters are not taken: "(\d+)" is meant as a group, not as "\d+".
        $delimiter = $pattern[0];
        $isDelimited = str_contains('/#~%@!|+', $delimiter)
            && preg_match('/' . preg_quote($delimiter, '/') . '[a-zA-Z]*$/', substr($pattern, 1)) === 1;

        return $isDelimited ? $pattern : '~' . str_replace('~', '\~', $pattern) . '~';
    }

    /** The named groups when the pattern names any, the numbered ones otherwise - without the whole match. */
    private static function groups(array $matches): array
    {
        $named = array_filter($matches, static fn($key): bool => is_string($key), ARRAY_FILTER_USE_KEY);
        if ($named !== []) {
            return $named;
        }

        return array_values(array_slice($matches, 1));
    }
}
