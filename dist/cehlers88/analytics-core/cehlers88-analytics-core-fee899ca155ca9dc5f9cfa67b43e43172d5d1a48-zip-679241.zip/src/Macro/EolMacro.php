<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Support\FunctionArguments;

class EolMacro extends AbstractMacro
{
    public function init(): EolMacro
    {
        $this->_source = 'CoreBundle';
        return $this;
    }

    public function getDescription(): string
    {
        return 'End of line.';
    }

    public function getName(): string
    {
        return 'eol';
    }

    protected function run(): array
    {
        echo PHP_EOL;

        return $this->_createRunResult(PHP_EOL);
    }
}
