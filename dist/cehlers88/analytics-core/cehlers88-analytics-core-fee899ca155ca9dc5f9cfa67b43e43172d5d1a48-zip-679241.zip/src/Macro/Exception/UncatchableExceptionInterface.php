<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\Exception;

/**
 * An error tryCatch hands on instead of catching: the run is being stopped from
 * outside (an aborted debug session, say), it did not fail - nothing of the
 * definition may run any more, its `catch` and `finally` neither.
 */
interface UncatchableExceptionInterface extends \Throwable
{
}
