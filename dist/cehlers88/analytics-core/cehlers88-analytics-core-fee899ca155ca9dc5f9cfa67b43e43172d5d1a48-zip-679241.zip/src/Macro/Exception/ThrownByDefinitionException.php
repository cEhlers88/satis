<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\Exception;

/**
 * The error a definition raises itself with the `throw` macro.
 */
class ThrownByDefinitionException extends \RuntimeException
{
}
