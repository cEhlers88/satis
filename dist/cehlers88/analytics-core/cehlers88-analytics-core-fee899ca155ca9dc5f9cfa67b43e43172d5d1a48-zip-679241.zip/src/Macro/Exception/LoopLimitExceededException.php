<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\Exception;

/**
 * A loop ran as often as it may and would have gone on - its condition most
 * likely never stops holding.
 */
class LoopLimitExceededException extends \RuntimeException
{
}
