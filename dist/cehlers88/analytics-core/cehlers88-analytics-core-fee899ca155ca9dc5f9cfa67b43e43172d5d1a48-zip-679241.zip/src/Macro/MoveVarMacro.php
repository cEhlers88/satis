<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\SelectVarNameValueHelper;

class MoveVarMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    private const PROPERTY_NAME = 'name';
    private const PROPERTY_SRC_CONTEXT = 'srcContext';
    private const PROPERTY_DEST_CONTEXT = 'destContext';
    private const PROPERTY_COPY = 'copy';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            // The variable is read from the source context - its names are the ones to offer.
            self::PROPERTY_NAME => PropertyUi::create()->valueHelper(SelectVarNameValueHelper::class, [
                SelectVarNameValueHelper::OPTION_CONTEXT_PROPERTY => self::PROPERTY_SRC_CONTEXT,
            ]),
            self::PROPERTY_SRC_CONTEXT, self::PROPERTY_DEST_CONTEXT => PropertyUi::create()->options(SelectVarNameValueHelper::contextOptions()),
            default => null,
        };
    }

    protected function run(): ?array
    {
        $currentValue = $this->getVariablesStoreProvider()->getVariableValue(
            $this->getPropertyValue(self::PROPERTY_NAME),
            $this->getPropertyValue(self::PROPERTY_SRC_CONTEXT)
        );

        $this->getVariablesStoreProvider()->setVariable(
            $this->getPropertyValue(self::PROPERTY_NAME),
            $currentValue,
            $this->getPropertyValue(self::PROPERTY_DEST_CONTEXT)
        );

        if ($this->getPropertyValue(self::PROPERTY_COPY) === false) {
            $this->getVariablesStoreProvider()->removeVariable(
                $this->getPropertyValue(self::PROPERTY_NAME),
                $this->getPropertyValue(self::PROPERTY_SRC_CONTEXT)
            );
        }

        return $this->_createRunResult($currentValue);
    }

    public function init(): MoveVarMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME, 'string', 'Specify the variable name'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_SRC_CONTEXT, 'string', 'Specify the source context'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DEST_CONTEXT, 'string', 'Specify the destination context'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_COPY, 'bool', 'Specify if the variable should be copied instead of moved', false));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Move/Copy a variable from a context to another.';
    }

    public function getName(): string
    {
        return 'moveVar';
    }
}