<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Entity\Client;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Doctrine\ORM\EntityManagerInterface;

class GetClientInfosMacro extends AbstractMacro
{
    private const PROPERTY_CLIENT_ID = 'clientId';
    private const PROPERTY_NAME = 'name';

    public function __construct(
        private EntityManagerInterface $entityManager
    )
    {
    }

    public function init(): GetClientInfosMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create('clientId', 'int', 'Specify the client id'))
            ->setProperty(MacroPropertyDTO::create('name', 'string', 'Specify the configuration name to retrieve', ''))
            ->setProperty(MacroPropertyDTO::create('default', 'mixed', 'Specify a default result', null));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Returns a client, or one of its values (ip, first_visit, last_visit).';
    }

    public function getName(): string
    {
        return 'getClientInfos';
    }

    protected function run(): ?array
    {
        $client = $this->entityManager->getRepository(Client::class)->find($this->getPropertyValue(self::PROPERTY_CLIENT_ID));
        if ($this->getPropertyValue(self::PROPERTY_NAME) !== '') {
            switch ($this->getPropertyValue(self::PROPERTY_NAME)) {
                case 'ip':
                    return $this->_createRunResult($client->getIp());
                case 'first_visit':
                    return $this->_createRunResult($client->getFirstVisit()->format('Y-m-d H:i:s'));
                case 'last_visit':
                    return $this->_createRunResult($client->getLastVisit()?->format('Y-m-d H:i:s'));
            }
        }

        return $this->_createRunResult($client);
    }
}