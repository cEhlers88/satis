<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Support\Condition\ConditionEvaluator;

/**
 * Runs one of two lists of commands, depending on a condition.
 *
 * The condition is a condition group - `["&&", [["==", [["get_var", {…}], "x"]], …]]`
 * - or, the way it was written before there were groups, a value or a list of
 * values that all have to hold. See ConditionEvaluator for what is read how.
 */
class IfMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    private const PROPERTY_CONDITIONS = "conditions";
    private const PROPERTY_WHEN_FALSE_COMMANDS = "whenFalseCommands";
    private const PROPERTY_WHEN_TRUE_COMMANDS = "whenTrueCommands";

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_CONDITIONS => PropertyUi::condition()->displayName('Condition'),
            self::PROPERTY_WHEN_TRUE_COMMANDS => PropertyUi::commands()->displayName('True')->cssClass('is-case case-true'),
            self::PROPERTY_WHEN_FALSE_COMMANDS => PropertyUi::commands()->displayName('False')->cssClass('is-case case-false'),
            default => null,
        };
    }

    public function init(): IfMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CONDITIONS, 'mixed', 'Specify the condition to check'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_WHEN_TRUE_COMMANDS, 'array', 'Specify commands which should execute when condition is true', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_WHEN_FALSE_COMMANDS, 'array', 'Specify commands which should execute when condition is false', []));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Check a condition and execute commands based on the result.';
    }

    public function getName(): string
    {
        return 'if';
    }

    public function needPrecompiledArguments(): bool
    {
        return false;
    }

    protected function run(): ?array
    {
        $conditionResult = new ConditionEvaluator()->evaluate(
            $this->getPropertyValue(self::PROPERTY_CONDITIONS),
            // The arguments arrive as they are written, so a command inside
            // the condition only runs once the evaluator gets to it.
            fn(mixed $value): mixed => ($value instanceof CommandDTO || $value instanceof CommandGroupDTO)
                ? $this->_runCommandDefinition($value)
                : $value
        );

        $commandsToRun = $conditionResult ? $this->getPropertyValue(self::PROPERTY_WHEN_TRUE_COMMANDS) : $this->getPropertyValue(self::PROPERTY_WHEN_FALSE_COMMANDS);

        $result = $this->_runCommandDefinition($commandsToRun);

        return $this->_createRunResult($result ?? ["__void" => true]);
    }
}
