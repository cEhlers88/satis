<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\ValueSuggestionsInterface;

class GetCustomObjectMacro extends AbstractMacro implements PropertyUiProviderInterface, ValueSuggestionsInterface
{
    private const string PROPERTY_NAME_OR_ID = 'nameOrId';

    public function __construct(
        private CustomObjectProvider $_customObjectProvider
    )
    {
    }

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return $property->name === self::PROPERTY_NAME_OR_ID
            ? PropertyUi::create()->suggestValuesFromMacro()
            : null;
    }

    /**
     * Every custom object, by its name - the name is what a reader of the definition
     * recognises. A name that several objects share would find only the first of them,
     * so those are suggested by their id.
     */
    public function suggestValues(string $propertyName, array $properties): array
    {
        if ($propertyName !== self::PROPERTY_NAME_OR_ID) {
            return [];
        }

        $entities = array_filter(
            $this->_customObjectProvider->getCustomEntitiesBy([], false),
            static fn(mixed $entity): bool => $entity instanceof CustomEntity && $entity->getId() !== null
        );
        usort($entities, static fn(CustomEntity $left, CustomEntity $right): int
            => [mb_strtolower((string)$left->getName()), $left->getId()] <=> [mb_strtolower((string)$right->getName()), $right->getId()]);

        $nameCounts = array_count_values(array_map(static fn(CustomEntity $entity): string => (string)$entity->getName(), $entities));
        $suggestions = [];

        foreach ($entities as $entity) {
            $name = (string)$entity->getName();
            $className = self::shortClassName((string)$entity->getClassName());

            if ($name === '' || is_numeric($name) || $nameCounts[$name] > 1) {
                // a numeric name would be read as an id
                $suggestions[(string)$entity->getId()] = trim($name . ' · ' . $className, ' ·');
            } else {
                $suggestions[$name] = $className . ' · #' . $entity->getId();
            }
        }

        return $suggestions;
    }

    public function init(): GetCustomObjectMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME_OR_ID, [
                MacroPropertyDTO::TYPE_INT,
                MacroPropertyDTO::TYPE_STRING
            ], 'Specify the name or id of the custom object'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Retrieve a custom object by name or id.';
    }

    public function getName(): string
    {
        return 'getCustomObject';
    }

    protected function run(): ?array
    {
        $nameOrId = $this->getPropertyValue(self::PROPERTY_NAME_OR_ID);

        if (is_numeric($nameOrId)) {
            $result = $this->_customObjectProvider->getCustomObjectById($nameOrId);
        } else {
            $result = $this->_customObjectProvider->getCustomEntitiesBy([
                'name' => $nameOrId
            ])[0] ?? null;
        }

        return $this->_createRunResult($result);
    }

    private static function shortClassName(string $className): string
    {
        $position = strrpos($className, '\\');

        return $position === false ? $className : substr($className, $position + 1);
    }
}
