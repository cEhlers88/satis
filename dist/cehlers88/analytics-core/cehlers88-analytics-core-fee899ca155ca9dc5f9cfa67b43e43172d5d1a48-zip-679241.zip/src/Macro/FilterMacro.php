<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Support\Property\PropertyConditionResolver;
use Cehlers88\AnalyticsCore\Support\Property\PropertyValuePath;

/**
 * Narrows a list down: keeps the entries whose field compares to a value the
 * way the operator says, sorts them by a field and cuts them to a limit -
 * "the ten clients with the most visits" without nesting `if` in `for`.
 * Every step is optional; the comparison is the lenient one of property
 * conditions ("2" equals 2, a list as value means "one of").
 */
class FilterMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const string SORT_ASC = 'asc';
    public const string SORT_DESC = 'desc';

    private const string PROPERTY_DATA = 'data';
    private const string PROPERTY_FIELD = 'field';
    private const string PROPERTY_OPERATOR = 'operator';
    private const string PROPERTY_VALUE = 'value';
    private const string PROPERTY_SORT_BY = 'sortBy';
    private const string PROPERTY_SORT_DIRECTION = 'sortDirection';
    private const string PROPERTY_LIMIT = 'limit';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        $operators = ['' => 'kein Filter'];
        foreach (eConditionType::cases() as $type) {
            if (!$type->isLogical()) {
                $operators[$type->operator()] = $type->operator();
            }
        }

        return match ($property->name) {
            self::PROPERTY_OPERATOR => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options($operators),
            self::PROPERTY_SORT_DIRECTION => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options([
                self::SORT_ASC => 'aufsteigend',
                self::SORT_DESC => 'absteigend',
            ]),
            self::PROPERTY_LIMIT => PropertyUi::create()->placeholder('0 = alle'),
            default => null,
        };
    }

    public function init(): FilterMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DATA, MacroPropertyDTO::TYPE_ARRAY, 'The list to filter'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_FIELD, MacroPropertyDTO::TYPE_STRING, 'Field of the entries to compare, dotted for nested values - the entries themselves when empty', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_OPERATOR, MacroPropertyDTO::TYPE_STRING, 'How to compare (==, !=, >, >=, <, <=, contains, !contains, startsWith, endsWith) - no filtering when empty', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'mixed', 'The value to compare with - a list means "one of"', null))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_SORT_BY, MacroPropertyDTO::TYPE_STRING, 'Field to sort by - the entries themselves with "." , unsorted when empty', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_SORT_DIRECTION, MacroPropertyDTO::TYPE_STRING, 'asc or desc', self::SORT_ASC))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_LIMIT, MacroPropertyDTO::TYPE_INT, 'Maximum number of entries - all when 0', 0));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Filters a list by a condition, sorts it and limits it.';
    }

    public function getName(): string
    {
        return 'filter';
    }

    protected function run(): ?array
    {
        $entries = self::toEntries($this->getPropertyValue(self::PROPERTY_DATA));
        $field = trim((string)$this->getPropertyValue(self::PROPERTY_FIELD));
        $operator = trim((string)$this->getPropertyValue(self::PROPERTY_OPERATOR));

        if ($operator !== '') {
            $type = eConditionType::tryFromOperator($operator);
            if ($type === null || $type->isLogical()) {
                return $this->_createRunResult(null, ErrorDTO::create(422, sprintf('Unknown operator "%s".', $operator)));
            }

            $expected = $this->getPropertyValue(self::PROPERTY_VALUE);
            $entries = array_values(array_filter(
                $entries,
                static fn(mixed $entry): bool => PropertyConditionResolver::compare(self::readField($entry, $field), $expected, $type)
            ));
        }

        $sortBy = trim((string)$this->getPropertyValue(self::PROPERTY_SORT_BY));
        if ($sortBy !== '') {
            $direction = strtolower(trim((string)$this->getPropertyValue(self::PROPERTY_SORT_DIRECTION))) === self::SORT_DESC ? -1 : 1;
            $sortField = $sortBy === '.' ? '' : $sortBy;
            usort($entries, static function (mixed $left, mixed $right) use ($sortField, $direction): int {
                $leftValue = self::readField($left, $sortField);
                $rightValue = self::readField($right, $sortField);

                // entries without the field go last, whichever the direction
                if ($leftValue === null || $rightValue === null) {
                    return ($leftValue === null) <=> ($rightValue === null);
                }

                return self::compareValues($leftValue, $rightValue) * $direction;
            });
        }

        $limit = (int)$this->getPropertyValue(self::PROPERTY_LIMIT);
        if ($limit > 0) {
            $entries = array_slice($entries, 0, $limit);
        }

        return $this->_createRunResult($entries);
    }

    /**
     * Numbers by value, everything else as text in natural order, so "item 10"
     * comes after "item 9".
     */
    private static function compareValues(mixed $left, mixed $right): int
    {
        if (is_numeric($left) && is_numeric($right)) {
            return ($left + 0) <=> ($right + 0);
        }

        return strnatcasecmp(self::toText($left), self::toText($right));
    }

    private static function toText(mixed $value): string
    {
        if (is_bool($value)) {
            return $value ? '1' : '0';
        }

        return is_scalar($value) ? (string)$value : (string)json_encode($value);
    }

    /**
     * The entries of a list. A list of one entry reaches the macro unwrapped
     * (AbstractMacro::execute()), so a single record counts as a list of it.
     */
    private static function toEntries(mixed $data): array
    {
        if ($data === null) {
            return [];
        }

        return is_array($data) && array_is_list($data) ? $data : [$data];
    }

    private static function readField(mixed $entry, string $field): mixed
    {
        if ($field === '') {
            return $entry;
        }
        if (is_object($entry)) {
            $entry = (array)$entry;
        }

        return is_array($entry) ? PropertyValuePath::read($entry, $field) : null;
    }
}
