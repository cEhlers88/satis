<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\Support\ListValues;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

/**
 * Turns a JSON text into a value and a value into JSON text - for webhook bodies, tracking
 * payloads or attributes that hold JSON, which the commands otherwise only see as text.
 *
 * mode auto (default) decodes a text and encodes everything else; decode and encode say it
 * explicitly - encode is the way to get "\"Hallo\"" from a text. Objects decode to objects with
 * their keys, so subValue, map and the rest can read them. An empty text decodes to null; a text
 * that is no JSON is an error naming what is wrong. Encoded text keeps umlauts and slashes as
 * they are; `pretty` indents it.
 */
class JsonMacro extends AbstractMacro
{
    private const string PROPERTY_VALUE = 'value';
    private const string PROPERTY_MODE = 'mode';
    private const string PROPERTY_PRETTY = 'pretty';

    private const array MODES = ['auto', 'decode', 'encode'];

    public function init(): JsonMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'mixed', 'A JSON text to decode, or a value to encode'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_MODE, ['string'], 'auto (decode a text, encode anything else), decode or encode', 'auto'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_PRETTY, ['bool'], 'Indent the encoded JSON', false));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Decodes a JSON text into a value or encodes a value as JSON text.';
    }

    public function getName(): string
    {
        return 'json';
    }

    protected function run(): ?array
    {
        $value = $this->getPropertyValue(self::PROPERTY_VALUE);
        $mode = strtolower(trim((string)$this->getPropertyValue(self::PROPERTY_MODE))) ?: 'auto';
        if (!in_array($mode, self::MODES, true)) {
            return $this->_createRunResult(null, ErrorDTO::create(
                400,
                sprintf('json: unknown mode "%s" - use %s', $mode, implode(', ', self::MODES))
            ));
        }
        if ($mode === 'auto') {
            $mode = is_string($value) ? 'decode' : 'encode';
        }

        if ($mode === 'encode') {
            $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION;
            if ((bool)$this->getPropertyValue(self::PROPERTY_PRETTY)) {
                $flags |= JSON_PRETTY_PRINT;
            }
            try {
                return $this->_createRunResult(json_encode(ListValues::plain($value), $flags | JSON_THROW_ON_ERROR));
            } catch (\JsonException $exception) {
                return $this->_createRunResult(null, ErrorDTO::create(400, 'json: the value cannot be encoded - ' . $exception->getMessage()));
            }
        }

        if (!is_string($value)) {
            return $this->_createRunResult(null, ErrorDTO::create(400, 'json: only a text can be decoded'));
        }
        if (trim($value) === '') {
            return $this->_createRunResult(null);
        }
        try {
            return $this->_createRunResult(json_decode($value, true, 512, JSON_THROW_ON_ERROR));
        } catch (\JsonException $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(400, 'json: the text is no valid JSON - ' . $exception->getMessage()));
        }
    }
}
