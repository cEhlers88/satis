<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\DTO\ConditionGroupDTO;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Support\Condition\ConditionEvaluator;
use Cehlers88\AnalyticsCore\Support\Property\PropertyConditionResolver;

/**
 * Runs the commands of the first case that matches a value, the default
 * commands when none does.
 *
 *     ["switch", {
 *         "value": ["get_var", {"name": "state"}],
 *         "cases": [
 *             {"when": "done", "commands": [...]},
 *             {"when": ["failed", "aborted"], "commands": [...]},
 *             {"when": [">", [["get_var", {"name": "retries"}], 3]], "commands": [...]}
 *         ],
 *         "defaultCommands": [...]
 *     }]
 *
 * A case matches when its `when` equals the value - leniently, the way the
 * conditions compare -, when it is a list one entry of which does, or when it
 * is a condition group that holds; the value plays no part in that last one.
 * Only the first matching case runs, nothing falls through.
 */
class SwitchMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const string CASE_COMMANDS = 'commands';
    public const string CASE_WHEN = 'when';

    private const PROPERTY_CASES = 'cases';
    private const PROPERTY_DEFAULT_COMMANDS = 'defaultCommands';
    private const PROPERTY_VALUE = 'value';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_VALUE => PropertyUi::create()->displayName('Value'),
            self::PROPERTY_CASES => PropertyUi::create()->editor(PropertyUi::EDITOR_CASES)->displayName('Cases'),
            self::PROPERTY_DEFAULT_COMMANDS => PropertyUi::commands()->displayName('Default')->cssClass('is-case case-false'),
            default => null,
        };
    }

    public function init(): SwitchMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'mixed', 'Specify the value the cases are compared with'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CASES, 'array', 'Specify the cases - {"when": …, "commands": […]} each', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DEFAULT_COMMANDS, 'array', 'Specify commands which should execute when no case matches', []));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Run the commands of the first case that matches a value.';
    }

    public function getName(): string
    {
        return 'switch';
    }

    public function needPrecompiledArguments(): bool
    {
        return false;
    }

    protected function run(): ?array
    {
        // The arguments arrive as they are written: a command in the value or
        // in a case only runs once it is needed, the commands of the cases
        // that do not match never run.
        $resolve = fn(mixed $value): mixed => ($value instanceof CommandDTO || $value instanceof CommandGroupDTO)
            ? $this->_runCommandDefinition($value)
            : $value;
        $subject = $resolve($this->getPropertyValue(self::PROPERTY_VALUE));

        foreach ($this->cases() as $index => $case) {
            if ($this->matches($subject, $case[self::CASE_WHEN], $resolve)) {
                $this->log(eDebuggerLogType::INFO, sprintf('Case %d matches', $index + 1), ['case' => $index]);

                return $this->runCommands($case[self::CASE_COMMANDS] ?? []);
            }
        }

        $this->log(eDebuggerLogType::INFO, 'No case matches - running the default commands');

        return $this->runCommands($this->getPropertyValue(self::PROPERTY_DEFAULT_COMMANDS));
    }

    /**
     * @return list<array{when: mixed, commands?: mixed}>
     */
    private function cases(): array
    {
        $cases = $this->getPropertyValue(self::PROPERTY_CASES);

        // AbstractMacro::execute() takes a list of one apart - a single case
        // arrives as the case itself.
        if (is_array($cases) && array_key_exists(self::CASE_WHEN, $cases)) {
            $cases = [$cases];
        }

        return array_values(array_filter(
            is_array($cases) ? $cases : [],
            static fn(mixed $case): bool => is_array($case) && array_key_exists(self::CASE_WHEN, $case)
        ));
    }

    private function matches(mixed $subject, mixed $when, callable $resolve): bool
    {
        if ($when instanceof ConditionGroupDTO || ConditionGroupDTO::isDefinition($when)) {
            return new ConditionEvaluator()->evaluate($when, $resolve);
        }

        // A list is matched by any of its entries - the comparison reads it so.
        $when = is_array($when) && array_is_list($when) ? array_map($resolve, $when) : $resolve($when);

        return PropertyConditionResolver::compare($subject, $when, eConditionType::EQUALS);
    }

    private function runCommands(mixed $commands): array
    {
        if ($commands === null || $commands === [] || $commands === '') {
            return $this->_createRunResult(['__void' => true]);
        }

        return $this->_createRunResult($this->_runCommandDefinition($commands) ?? ['__void' => true]);
    }
}
