<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Support\FunctionArguments;

/**
 * Defines a function for the rest of the run: its commands (`content`) run when the macro
 * "call" names it, with the declared `arguments` readable in the variable context "argument".
 */
class FunctionMacro extends AbstractMacro
{
    private const string PROPERTY_CONTENT = 'content';
    private const string PROPERTY_ARGUMENTS = 'arguments';
    private const string PROPERTY_NAME = 'name';

    public function init(): FunctionMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME, 'string', 'Specify the function'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CONTENT, 'Command[]', 'Specify the function-content'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ARGUMENTS, 'mixed', 'The arguments a call has to give - a list of [type, name, default?, {required, command, description}?] or {name, type, required, default, description}; types: string, integer, float, boolean, array, mixed. Without a default an argument is required.', null));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Create a function.';
    }

    public function getName(): string
    {
        return 'function';
    }

    public function needPrecompiledArguments(): bool
    {
        return false;
    }

    protected function run(): ?array
    {
        $name = trim((string)$this->getPropertyValue(self::PROPERTY_NAME));
        if ($name === '') {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'A function needs a name.'));
        }

        try {
            $arguments = FunctionArguments::declare($name, $this->getPropertyValue(self::PROPERTY_ARGUMENTS));
        } catch (\InvalidArgumentException $e) {
            return $this->_createRunResult(null, ErrorDTO::create(422, $e->getMessage()));
        }

        $this->getMacroEnvironment()->defineFunction($name, $this->getPropertyValue(self::PROPERTY_CONTENT), $arguments);

        return $this->_createRunResult(['__void' => true]);
    }
}
