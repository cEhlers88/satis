<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Macro\AbstractMacro;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Provider\ApplicationActionProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationActionRepository;
use Exception;
use Symfony\Component\Mercure\HubInterface;
use Symfony\Component\Mercure\Update;

class StartActionMacro extends AbstractMacro
{
    private const PROPERTY_ACTION = 'action';
    private const PROPERTY_ACTION_PROPERTIES = 'props';
    private const PROPERTY_REASON = 'reason';

    public function __construct(
        private ApplicationActionProvider   $applicationActionProvider,
        private ApplicationActionRepository $applicationActionRepository,
        private CommandFactory              $commandFactory,
        private HubInterface                $hub
    )
    {
    }

    public function init(): StartActionMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ACTION, ['string'], 'The action to start'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ACTION_PROPERTIES, ['array'], 'The properties for the action', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_REASON, ['string'], 'Why the action is started - stored on the action until it is started again', ''));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Starts an action.';
    }

    public function getName(): string
    {
        return 'startAction';
    }

    protected function run(): ?array
    {
        $actionName = $this->getPropertyValue(self::PROPERTY_ACTION);
        $application = $this->getMacroEnvironment()->getApplication();
        $errorDto = null;

        $result = '';

        try {
            $reason = $this->getPropertyValue(self::PROPERTY_REASON);
            $result = $this->applicationActionProvider->startAction(
                $application,
                $actionName,
                is_scalar($reason) ? (string)$reason : null
            );
        } catch (Exception $exception) {
            $errorDto = ErrorDTO::create($exception->getCode(), $exception->getMessage());
        }

        return $this->_createRunResult($result, $errorDto);
    }
}