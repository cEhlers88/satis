<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Support\Property\PropertyValuePath;

/**
 * A text with placeholders: `Hallo {kunde.name}, offen sind {betrag} €`. Saves
 * the chains of implode and strReplace a message used to take.
 *
 * A placeholder is looked up like a name in calculate: in `values` first (dotted
 * for nested values), then among the variables. `{{` and `}}` write a brace.
 * A list or an object is written as JSON, true/false as text, null as nothing.
 */
class TemplateMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const string MISSING_KEEP = 'keep';
    public const string MISSING_EMPTY = 'empty';
    public const string MISSING_ERROR = 'error';

    private const string PROPERTY_TEXT = 'text';
    private const string PROPERTY_VALUES = 'values';
    private const string PROPERTY_MISSING = 'missing';

    private const array MISSING = [
        self::MISSING_KEEP => 'Platzhalter stehen lassen',
        self::MISSING_EMPTY => 'leer einsetzen',
        self::MISSING_ERROR => 'Fehler',
    ];

    private const string PLACEHOLDER = '/\{\{|\}\}|\{\s*([A-Za-z_][A-Za-z0-9_\-]*(?:\.[A-Za-z0-9_\-]+)*)\s*\}/';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_TEXT => PropertyUi::create()->placeholder('Hallo {kunde.name}, offen sind {betrag} €'),
            self::PROPERTY_VALUES => PropertyUi::map(),
            self::PROPERTY_MISSING => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options(self::MISSING),
            default => null,
        };
    }

    public function init(): TemplateMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TEXT, MacroPropertyDTO::TYPE_STRING, 'The text with placeholders such as {name} or {kunde.name}'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUES, MacroPropertyDTO::TYPE_ARRAY, 'Values of the placeholders (name => value) - a name not given here is read from the variables', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_MISSING, MacroPropertyDTO::TYPE_STRING, 'A placeholder without value: keep it, leave it empty or fail', self::MISSING_KEEP));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Fills the placeholders of a text with values and variables.';
    }

    public function getName(): string
    {
        return 'template';
    }

    protected function run(): ?array
    {
        $text = (string)$this->getPropertyValue(self::PROPERTY_TEXT);
        $values = $this->getPropertyValue(self::PROPERTY_VALUES);
        $values = is_object($values) ? (array)$values : (is_array($values) ? $values : []);
        $missing = strtolower(trim((string)$this->getPropertyValue(self::PROPERTY_MISSING)));
        if ($missing === '') {
            $missing = self::MISSING_KEEP;
        }
        if (!array_key_exists($missing, self::MISSING)) {
            return $this->_createRunResult(null, ErrorDTO::create(422, sprintf(
                'Unknown value "%s" for missing - use one of %s.', $missing, implode(', ', array_keys(self::MISSING))
            )));
        }

        $unknown = [];
        $result = preg_replace_callback(self::PLACEHOLDER, function (array $match) use ($values, $missing, &$unknown): string {
            if ($match[0] === '{{') {
                return '{';
            }
            if ($match[0] === '}}') {
                return '}';
            }

            $value = $this->valueOf($match[1], $values);
            if ($value === VariablesProvider::UNDEFINED_VAR) {
                $unknown[] = $match[1];

                return $missing === self::MISSING_KEEP ? $match[0] : '';
            }

            return self::toText($value);
        }, $text);

        if ($missing === self::MISSING_ERROR && $unknown !== []) {
            return $this->_createRunResult(null, ErrorDTO::create(422, sprintf(
                'No value for %s - neither in "values" nor among the variables.',
                implode(', ', array_map(static fn(string $name): string => '"' . $name . '"', array_unique($unknown)))
            )));
        }

        return $this->_createRunResult($result);
    }

    public static function toText(mixed $value): string
    {
        return match (true) {
            $value === null => '',
            is_bool($value) => $value ? 'true' : 'false',
            is_scalar($value) => (string)$value,
            $value instanceof \Stringable => (string)$value,
            default => (string)json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        };
    }

    /** What a placeholder stands for - VariablesProvider::UNDEFINED_VAR when nothing does. */
    private function valueOf(string $name, array $values): mixed
    {
        // a value given as null is a value - only an unknown key is missing
        if (array_key_exists($name, $values)) {
            return $values[$name];
        }
        $value = PropertyValuePath::read($values, $name);
        if ($value !== null) {
            return $value;
        }

        [$variableName, $path] = array_pad(explode('.', $name, 2), 2, '');
        try {
            $variable = $this->getVariablesStoreProvider()->getVariableValue($variableName, defaultValue: VariablesProvider::UNDEFINED_VAR);
        } catch (\Throwable) {
            return VariablesProvider::UNDEFINED_VAR;
        }
        if ($variable === VariablesProvider::UNDEFINED_VAR || $path === '') {
            return $variable;
        }
        $nested = is_array($variable) || is_object($variable) ? PropertyValuePath::read((array)$variable, $path) : null;

        return $nested ?? VariablesProvider::UNDEFINED_VAR;
    }
}
