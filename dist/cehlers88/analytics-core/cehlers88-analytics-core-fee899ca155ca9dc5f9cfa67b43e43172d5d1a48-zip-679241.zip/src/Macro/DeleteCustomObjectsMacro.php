<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\PropertyUi\MapKeySuggestionsInterface;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\MapPropertyUi;
use Cehlers88\AnalyticsCore\Macro\Support\CustomObjectMatching;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Event\CustomObject\CustomObjectsDeletedEvent;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Doctrine\ORM\EntityManagerInterface;
use Psr\EventDispatcher\EventDispatcherInterface;

/**
 * Deletes custom objects - with saveCustomObject and findCustomObjects a command can manage
 * them completely. The objects are picked exactly like findCustomObjects picks them (`where`),
 * so a find with the same `where` shows beforehand what goes; `dryRun` does that as well, and
 * so does the protected mode.
 *
 * Without a `where` nothing is deleted: an empty filter would match every object of the class,
 * and that is not something a forgotten argument should do. Objects whose parent is deleted
 * stay, with their parentId as it was - the dashboard deletes no children either.
 *
 * What the application keeps next to a deleted object (its settings) goes with it through
 * CustomObjectsDeletedEvent - the core does not know that data.
 */
class DeleteCustomObjectsMacro extends AbstractMacro implements PropertyUiProviderInterface, MapKeySuggestionsInterface
{
    use CustomObjectMatching;

    private const string PROPERTY_CLASS_NAME = 'className';
    private const string PROPERTY_WHERE = 'where';
    private const string PROPERTY_DRY_RUN = 'dryRun';

    public function __construct(
        private CustomObjectProvider $customObjectProvider,
        private EntityManagerInterface $entityManager,
        private ?EventDispatcherInterface $eventDispatcher = null,
    )
    {
    }

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return $property->name === self::PROPERTY_WHERE
            ? MapPropertyUi::suggestKeysFromMacro(MapPropertyUi::create())->displayName('Where')
            : null;
    }

    public function suggestMapKeys(string $propertyName, array $properties): array
    {
        $className = $properties[self::PROPERTY_CLASS_NAME] ?? null;
        if ($propertyName !== self::PROPERTY_WHERE || !is_string($className)) {
            return [];
        }

        return $this->fieldsOf($className);
    }

    public function init(): DeleteCustomObjectsMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CLASS_NAME, ['string'], 'The full or short name of a custom object class'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_WHERE, ['array'], 'Which objects to delete, by field: id, name, parentId or an attribute. A list means one of its values; empty deletes nothing', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DRY_RUN, ['bool'], 'Only return what would be deleted', false));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Deletes the custom objects of a class that match their fields and attributes.';
    }

    public function getName(): string
    {
        return 'deleteCustomObjects';
    }

    protected function run(): ?array
    {
        $className = $this->resolveClassName((string)$this->getPropertyValue(self::PROPERTY_CLASS_NAME));
        if ($className === null) {
            return $this->_createRunResult(null, ErrorDTO::create(
                404,
                sprintf('deleteCustomObjects: there is no custom object class "%s"', trim((string)$this->getPropertyValue(self::PROPERTY_CLASS_NAME)))
            ));
        }

        $where = $this->conditions($this->getPropertyValue(self::PROPERTY_WHERE));
        if ($where === []) {
            return $this->_createRunResult(null, ErrorDTO::create(
                400,
                'deleteCustomObjects: "where" is empty - name the objects to delete, e.g. by their id'
            ));
        }

        $matching = $this->findMatching($className, $where);
        if ((bool)$this->getPropertyValue(self::PROPERTY_DRY_RUN)) {
            return $this->_createRunResult($matching);
        }

        // In the protected mode (the examples' "Ausführen", the console's protected switch) a
        // delete only acts as if - like saveCustomObject, which skips its effect there as well.
        $deleted = $this->runProtectedFragment(
            fn(): array => $this->delete($className, $matching),
            static fn(): array => $matching,
        );

        return $this->_createRunResult($deleted);
    }

    /**
     * @param list<array{id: int|null}> $matching
     * @return list<array{id: int|null}> the entries that were deleted
     */
    private function delete(string $className, array $matching): array
    {
        $deleted = [];
        foreach ($matching as $entry) {
            // The stored row, looked up with its class - like the dashboard's delete - so an id
            // can only reach an object of the class the command names.
            $entity = $entry['id'] === null ? null : $this->entityManager->getRepository(CustomEntity::class)->findOneBy([
                'id' => $entry['id'],
                'className' => $className,
            ]);
            if (!$entity instanceof CustomEntity) {
                continue;
            }
            $this->entityManager->remove($entity);
            $deleted[] = $entry;
        }

        if ($deleted !== []) {
            $this->entityManager->flush();
            $this->eventDispatcher?->dispatch(new CustomObjectsDeletedEvent($className, array_column($deleted, 'id')));
        }

        return $deleted;
    }
}
