<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\Exception\UncatchableExceptionInterface;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\SelectVarNameValueHelper;

/**
 * Runs commands and, when one of them fails, other commands instead of ending
 * the run.
 *
 *     ["try_catch", {
 *         "try": [...],
 *         "catch": [["log", {"value": ["get_var", {"name": "error"}]}]],
 *         "finally": [...],
 *         "errorVar": "error"
 *     }]
 *
 * Whatever fails inside `try` - a command that is not known, a macro that
 * throws, a `throw` - is caught: its message is written to the variable named
 * by `errorVar` (job context, the way setVar writes by default) and `catch`
 * runs. `finally` runs in any case, also when `catch` fails in turn; its result
 * is dropped. The result is the one of `try`, or of `catch` when `try` failed.
 * Without `catch` the error is only swallowed.
 */
class TryCatchMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const string DEFAULT_ERROR_VAR = 'error';

    private const PROPERTY_CATCH = 'catch';
    private const PROPERTY_ERROR_VAR = 'errorVar';
    private const PROPERTY_FINALLY = 'finally';
    private const PROPERTY_TRY = 'try';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_TRY => PropertyUi::commands()->displayName('Try')->cssClass('is-case case-true'),
            self::PROPERTY_CATCH => PropertyUi::commands()->displayName('Catch')->cssClass('is-case case-false'),
            self::PROPERTY_FINALLY => PropertyUi::commands()->displayName('Finally')->cssClass('is-case'),
            // Written with setVar in its default context - a variable name like
            // any other, so getVar offers it.
            self::PROPERTY_ERROR_VAR => PropertyUi::create()->displayName('Error variable')->valueHelper(SelectVarNameValueHelper::class),
            default => null,
        };
    }

    public function init(): TryCatchMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TRY, 'array', 'Specify the commands to run'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CATCH, 'array', 'Specify commands which should execute when one of the commands to run fails', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_FINALLY, 'array', 'Specify commands which should execute afterwards in any case', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ERROR_VAR, 'string', 'Name of variable to store the error message in', self::DEFAULT_ERROR_VAR));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Run commands and handle an error one of them raises instead of ending the run.';
    }

    public function getName(): string
    {
        return 'tryCatch';
    }

    public function needPrecompiledArguments(): bool
    {
        return false;
    }

    protected function run(): ?array
    {
        // Read before anything runs: the macro is one instance, a tryCatch
        // inside `try` sets its properties anew.
        $try = $this->getPropertyValue(self::PROPERTY_TRY);
        $catch = $this->getPropertyValue(self::PROPERTY_CATCH);
        $finally = $this->getPropertyValue(self::PROPERTY_FINALLY);
        $errorVar = $this->getPropertyValue(self::PROPERTY_ERROR_VAR);

        try {
            $result = $this->runCommands($try);
        } catch (UncatchableExceptionInterface $e) {
            // The run is stopped from outside - not an error of the definition,
            // and nothing of it may run any more, `finally` neither.
            throw $e;
        } catch (\Throwable $e) {
            $this->log(eDebuggerLogType::WARNING, sprintf('Caught: %s', $e->getMessage()), ['error' => $e->getMessage()]);

            try {
                $errorVar = $this->resolve($errorVar);
                if (is_string($errorVar) && trim($errorVar) !== '') {
                    $this->_executeMacro('setVar', ['name' => trim($errorVar), 'value' => $e->getMessage()]);
                }

                $result = $this->runCommands($catch);
            } catch (UncatchableExceptionInterface $aborted) {
                throw $aborted;
            } catch (\Throwable $failed) {
                $this->runCommands($finally);
                throw $failed;
            }
        }

        $this->runCommands($finally);

        return $this->_createRunResult($result ?? ['__void' => true]);
    }

    private function resolve(mixed $value): mixed
    {
        return ($value instanceof CommandDTO || $value instanceof CommandGroupDTO)
            ? $this->_runCommandDefinition($value)
            : $value;
    }

    private function runCommands(mixed $commands): mixed
    {
        if ($commands === null || $commands === [] || $commands === '') {
            return null;
        }

        return $this->_runCommandDefinition($commands);
    }
}
