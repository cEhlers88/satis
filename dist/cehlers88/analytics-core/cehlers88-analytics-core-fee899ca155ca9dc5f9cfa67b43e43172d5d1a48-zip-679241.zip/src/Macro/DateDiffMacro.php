<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use DateTimeImmutable;
use DateTimeZone;

/**
 * How far two dates are apart, in whole units: "days since the last booking",
 * "months until the contract ends". getDate moves and formats one date - this
 * compares two.
 *
 * Positive when `to` lies after `from`, negative before, unless `absolute` is
 * set. Only full units count: 23 hours are 0 days. Months and years are
 * calendar months and years, so 31.01. to 28.02. is 0 months.
 */
class DateDiffMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    private const string PROPERTY_FROM = 'from';
    private const string PROPERTY_TO = 'to';
    private const string PROPERTY_UNIT = 'unit';
    private const string PROPERTY_ABSOLUTE = 'absolute';
    private const string PROPERTY_TIMEZONE = 'timezone';

    private const array UNITS = [
        'seconds' => 'Sekunden',
        'minutes' => 'Minuten',
        'hours' => 'Stunden',
        'days' => 'Tage',
        'weeks' => 'Wochen',
        'months' => 'Monate',
        'years' => 'Jahre',
    ];

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_FROM => PropertyUi::create()->placeholder('2026-01-01'),
            self::PROPERTY_TO => PropertyUi::create()->placeholder('now'),
            self::PROPERTY_UNIT => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options(self::UNITS),
            self::PROPERTY_TIMEZONE => PropertyUi::create()->placeholder(date_default_timezone_get()),
            default => null,
        };
    }

    public function init(): DateDiffMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_FROM, [MacroPropertyDTO::TYPE_STRING, MacroPropertyDTO::TYPE_INT], 'The earlier date - a date text or a unix timestamp'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TO, [MacroPropertyDTO::TYPE_STRING, MacroPropertyDTO::TYPE_INT], 'The later date - a date text or a unix timestamp, now when empty', 'now'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_UNIT, MacroPropertyDTO::TYPE_STRING, 'Unit of the result: seconds, minutes, hours, days, weeks, months or years', 'days'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ABSOLUTE, MacroPropertyDTO::TYPE_BOOLEAN, 'Without sign - otherwise negative when "to" lies before "from"', false))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TIMEZONE, MacroPropertyDTO::TYPE_STRING, 'Timezone of date texts without one, e.g. "Europe/Berlin" - the one of the server when empty', ''));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Returns how many whole days, months, hours ... lie between two dates.';
    }

    public function getName(): string
    {
        return 'dateDiff';
    }

    protected function run(): ?array
    {
        $unit = strtolower(trim((string)$this->getPropertyValue(self::PROPERTY_UNIT)));
        if ($unit === '') {
            $unit = 'days';
        }
        if (!array_key_exists($unit, self::UNITS)) {
            return $this->_createRunResult(null, ErrorDTO::create(422, sprintf(
                'Unknown unit "%s" - use one of %s.', $unit, implode(', ', array_keys(self::UNITS))
            )));
        }

        try {
            $timezone = $this->readTimezone();
            $from = $this->readDate(self::PROPERTY_FROM, $timezone, false);
            $to = $this->readDate(self::PROPERTY_TO, $timezone, true);
        } catch (\InvalidArgumentException $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(422, $exception->getMessage()));
        }

        $difference = self::difference($from, $to, $unit);
        if (filter_var($this->getPropertyValue(self::PROPERTY_ABSOLUTE), FILTER_VALIDATE_BOOLEAN)) {
            $difference = abs($difference);
        }

        return $this->_createRunResult($difference);
    }

    public static function difference(DateTimeImmutable $from, DateTimeImmutable $to, string $unit): int
    {
        $sign = $to < $from ? -1 : 1;
        $interval = $from->diff($to);
        $seconds = $to->getTimestamp() - $from->getTimestamp();

        return match ($unit) {
            'seconds' => $seconds,
            'minutes' => intdiv($seconds, 60),
            'hours' => intdiv($seconds, 3600),
            'days' => $sign * (int)$interval->days,
            'weeks' => $sign * intdiv((int)$interval->days, 7),
            'months' => $sign * ($interval->y * 12 + $interval->m),
            'years' => $sign * $interval->y,
        };
    }

    private function readTimezone(): DateTimeZone
    {
        $timezone = trim((string)$this->getPropertyValue(self::PROPERTY_TIMEZONE));

        try {
            return new DateTimeZone($timezone === '' ? date_default_timezone_get() : $timezone);
        } catch (\Throwable) {
            throw new \InvalidArgumentException(sprintf('Unknown timezone "%s".', $timezone));
        }
    }

    private function readDate(string $property, DateTimeZone $timezone, bool $nowWhenEmpty): DateTimeImmutable
    {
        $date = $this->getPropertyValue($property);

        if ($date === null || $date === '') {
            if (!$nowWhenEmpty) {
                throw new \InvalidArgumentException(sprintf('"%s" needs a date.', $property));
            }

            return new DateTimeImmutable('now', $timezone);
        }

        if (is_int($date) || (is_string($date) && preg_match('/^-?\d{9,}$/', $date) === 1)) {
            return (new DateTimeImmutable('@' . $date))->setTimezone($timezone);
        }

        try {
            return new DateTimeImmutable((string)$date, $timezone);
        } catch (\Throwable) {
            throw new \InvalidArgumentException(sprintf('Invalid date "%s" in "%s".', (string)$date, $property));
        }
    }
}
