<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

/**
 * Several objects into one, or several lists into one: defaults with the values
 * handed over, the results of two services side by side.
 *
 * `sources` is a list of what is merged, in order. Objects (keys with values):
 * a later value wins, with `deep` nested objects are merged as well instead of
 * replaced. Lists: appended to each other, with `unique` without repeated
 * entries. Objects and lists cannot be mixed; an empty or null source is left out.
 */
class MergeMacro extends AbstractMacro
{
    private const string PROPERTY_SOURCES = 'sources';
    private const string PROPERTY_DEEP = 'deep';
    private const string PROPERTY_UNIQUE = 'unique';

    public function init(): MergeMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_SOURCES, MacroPropertyDTO::TYPE_ARRAY, 'What is merged, in order - objects or lists, not both'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DEEP, MacroPropertyDTO::TYPE_BOOLEAN, 'Objects: nested objects are merged as well instead of replaced', false))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_UNIQUE, MacroPropertyDTO::TYPE_BOOLEAN, 'Lists: an entry that is already there is left out', false));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Merges objects (a later value wins) or appends lists to each other.';
    }

    public function getName(): string
    {
        return 'merge';
    }

    protected function run(): ?array
    {
        $sources = self::plain($this->getPropertyValue(self::PROPERTY_SOURCES));
        if (!is_array($sources)) {
            return $this->_createRunResult(null, ErrorDTO::create(422, '"sources" has to be a list of the objects or lists to merge.'));
        }
        // A list of one arrives unwrapped (AbstractMacro::execute()) - one object, or the
        // entries of one list: that is the one source.
        $isOneSource = !array_is_list($sources) || array_filter(
            $sources,
            static fn(mixed $source): bool => is_array($source) || $source === null
        ) === [];
        if ($isOneSource && $sources !== []) {
            $sources = [$sources];
        }

        $sources = array_values(array_filter($sources, static fn(mixed $source): bool => $source !== null && $source !== []));
        foreach ($sources as $index => $source) {
            if (!is_array($source)) {
                return $this->_createRunResult(null, ErrorDTO::create(422, sprintf(
                    'Entry %d of "sources" is no object and no list.', $index + 1
                )));
            }
        }
        if ($sources === []) {
            return $this->_createRunResult([]);
        }

        $lists = array_map(static fn(array $source): bool => array_is_list($source), $sources);
        if (count(array_unique($lists)) > 1) {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'Objects and lists cannot be merged with each other.'));
        }

        if ($lists[0]) {
            return $this->_createRunResult(self::appendLists(
                $sources,
                filter_var($this->getPropertyValue(self::PROPERTY_UNIQUE), FILTER_VALIDATE_BOOLEAN)
            ));
        }

        $deep = filter_var($this->getPropertyValue(self::PROPERTY_DEEP), FILTER_VALIDATE_BOOLEAN);
        $result = array_shift($sources);
        foreach ($sources as $source) {
            $result = self::mergeObjects($result, $source, $deep);
        }

        return $this->_createRunResult($result);
    }

    public static function mergeObjects(array $base, array $overrides, bool $deep): array
    {
        foreach ($overrides as $key => $value) {
            $nested = $deep && is_array($value) && !array_is_list($value)
                && isset($base[$key]) && is_array($base[$key]) && !array_is_list($base[$key]);
            $base[$key] = $nested ? self::mergeObjects($base[$key], $value, true) : $value;
        }

        return $base;
    }

    public static function appendLists(array $lists, bool $unique): array
    {
        $result = array_merge(...$lists);
        if (!$unique) {
            return $result;
        }

        // compared by their JSON, so equal objects count as the same entry as well
        $seen = [];

        return array_values(array_filter($result, static function (mixed $entry) use (&$seen): bool {
            $key = json_encode($entry);
            if (isset($seen[$key])) {
                return false;
            }
            $seen[$key] = true;

            return true;
        }));
    }

    /** Decoded JSON may hold objects - they are worked on as arrays. */
    private static function plain(mixed $value): mixed
    {
        if (is_object($value) && !$value instanceof \JsonSerializable && get_class($value) !== \stdClass::class) {
            return $value;
        }

        return is_object($value) || is_array($value)
            ? json_decode((string)json_encode($value), true)
            : $value;
    }
}
