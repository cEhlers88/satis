<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class ImplodeMacro extends AbstractMacro
{
    private const string PROPERTY_SEPARATOR = 'separator';
    private const string PROPERTY_VALUE = 'value';

    public function init(): ImplodeMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'array', 'Specify the array to implode'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_SEPARATOR, 'string', 'Specify the separator to combine the array'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Use this macro to implode a array.';
    }

    public function getName(): string
    {
        return 'implode';
    }

    protected function run(): ?array
    {
        return $this->_createRunResult(implode(
            $this->getPropertyValue(self::PROPERTY_SEPARATOR),
            $this->getValues()
        ));
    }

    private function getValues(): array
    {
        $result = [];
        $valueRaw = $this->getPropertyValue(self::PROPERTY_VALUE);
        foreach ($valueRaw as $evaluatedValue) {
            if ($evaluatedValue instanceof CommandGroupDTO) {
                $evaluatedValue = $this->_runCommandDefinition($evaluatedValue);
            } else if ($evaluatedValue instanceof CommandDTO) {
                $evaluatedValue = $this->_runCommandDefinition([$evaluatedValue]);
            }
            $result[] = $evaluatedValue;
        }
        return $result;
    }
}