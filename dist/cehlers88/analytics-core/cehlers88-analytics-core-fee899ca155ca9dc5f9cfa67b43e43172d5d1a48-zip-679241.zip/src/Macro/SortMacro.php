<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\Support\ListValues;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

/**
 * Sorts a list - of plain values, or of objects by one or more of their fields.
 *
 * `by` names the fields, comma-separated, the first one deciding first; a leading "-" sorts that
 * field descending, dots reach into nested values ("attributes.betrag"). Empty `by` sorts the
 * values themselves. Empty values (null, "", []) always come last, whatever the direction - they
 * are the ones nobody looks for at the top. Equal entries keep their order.
 *
 * `type` auto compares numbers - also numeric texts - as numbers and everything else naturally
 * and case-insensitively ("RE-2" before "RE-10"); number only as numbers, other values counting
 * as empty; text alphabetically, case-insensitively. Umlauts sort as their vowel.
 *
 * A list comes back as a list; an object keeps its keys, in the new order.
 */
class SortMacro extends AbstractMacro
{
    private const string PROPERTY_VALUE = 'value';
    private const string PROPERTY_BY = 'by';
    private const string PROPERTY_TYPE = 'type';
    private const string PROPERTY_DESCENDING = 'descending';

    private const array TYPES = ['auto', 'number', 'text'];

    public function init(): SortMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, ['array'], 'The list to sort'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_BY, ['string'], 'The fields to sort by, comma-separated - a leading "-" sorts a field descending, dots reach into nested values; empty sorts the values themselves', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TYPE, ['string'], 'auto (numbers as numbers, everything else naturally), number or text', 'auto'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DESCENDING, ['bool'], 'Reverse the whole order', false));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Sorts a list by its values or by fields of its entries.';
    }

    public function getName(): string
    {
        return 'sort';
    }

    protected function run(): ?array
    {
        $list = ListValues::plain($this->getPropertyValue(self::PROPERTY_VALUE));
        if (!is_array($list)) {
            return $this->_createRunResult(null, ErrorDTO::create(400, 'sort: "value" has to be a list'));
        }

        $type = strtolower(trim((string)$this->getPropertyValue(self::PROPERTY_TYPE))) ?: 'auto';
        if (!in_array($type, self::TYPES, true)) {
            return $this->_createRunResult(null, ErrorDTO::create(
                400,
                sprintf('sort: unknown type "%s" - use %s', $type, implode(', ', self::TYPES))
            ));
        }

        $keys = self::sortKeys((string)$this->getPropertyValue(self::PROPERTY_BY));
        $reverse = (bool)$this->getPropertyValue(self::PROPERTY_DESCENDING);
        $compare = static function (mixed $left, mixed $right) use ($keys, $type, $reverse): int {
            foreach ($keys as [$field, $descending]) {
                $order = self::compare(ListValues::at($left, $field), ListValues::at($right, $field), $type, $descending !== $reverse);
                if ($order !== 0) {
                    return $order;
                }
            }

            return 0;
        };

        if (array_is_list($list)) {
            usort($list, $compare);
        } else {
            uasort($list, $compare);
        }

        return $this->_createRunResult($list);
    }

    /**
     * @return list<array{0: string, 1: bool}> [field, descending] - one entry for the value itself when `by` is empty
     */
    private static function sortKeys(string $by): array
    {
        $keys = [];
        foreach (explode(',', $by) as $field) {
            $field = trim($field);
            if ($field === '' || $field === '-') {
                continue;
            }
            $keys[] = str_starts_with($field, '-') ? [ltrim(substr($field, 1)), true] : [$field, false];
        }

        return $keys === [] ? [['', str_starts_with(trim($by), '-')]] : $keys;
    }

    private static function compare(mixed $left, mixed $right, string $type, bool $descending): int
    {
        if ($type === 'number') {
            $left = ListValues::number($left);
            $right = ListValues::number($right);
        }

        $leftEmpty = ListValues::isEmpty($left);
        $rightEmpty = ListValues::isEmpty($right);
        if ($leftEmpty || $rightEmpty) {
            return $leftEmpty <=> $rightEmpty;
        }

        $leftNumber = ListValues::number($left);
        $rightNumber = ListValues::number($right);
        $order = match (true) {
            $type !== 'text' && $leftNumber !== null && $rightNumber !== null => $leftNumber <=> $rightNumber,
            $type === 'text' => strcmp(self::sortable($left), self::sortable($right)),
            default => strnatcmp(self::sortable($left), self::sortable($right)),
        };

        return $descending ? -$order : $order;
    }

    /** Lower case, umlauts as their vowel (DIN 5007) - bytewise "Ärger" would come after "Zebra". */
    private static function sortable(mixed $value): string
    {
        return strtr(mb_strtolower(ListValues::text($value)), ['ä' => 'a', 'ö' => 'o', 'ü' => 'u', 'ß' => 'ss']);
    }
}
