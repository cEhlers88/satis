<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogReason;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\Exception\LoopLimitExceededException;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\SelectVarNameValueHelper;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Support\Condition\ConditionEvaluator;

/**
 * Runs commands again and again as long as a condition holds.
 *
 *     ["while", {
 *         "condition": ["<", [["get_var", {"name": "page"}], 10]],
 *         "commands": [...],
 *         "counterVar": "i",
 *         "maxIterations": 100
 *     }]
 *
 * The condition is read like the one of `if` (see ConditionEvaluator) and is
 * decided anew before every pass - the commands inside it run each time. A
 * condition that does not hold at the start runs the commands not at all.
 *
 * By default the loop has no limit (`maxIterations` -1). A positive
 * `maxIterations` guards against a condition that never stops holding: after
 * that many passes the loop raises an error instead of starting another one -
 * an error, not a quiet stop, since the definition did not do what it was meant
 * to. A surrounding try_catch can catch it.
 *
 * The loop returns nothing (`__void`, like `if`): what the commands produce
 * goes where they write it, into variables.
 */
class WhileMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const int UNLIMITED = -1;

    private const string PROPERTY_COMMANDS = 'commands';
    private const string PROPERTY_CONDITION = 'condition';
    private const string PROPERTY_COUNTER_VAR = 'counterVar';
    private const string PROPERTY_MAX_ITERATIONS = 'maxIterations';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_CONDITION => PropertyUi::condition()->displayName('Condition'),
            self::PROPERTY_COMMANDS => PropertyUi::commands()->displayName('Do'),
            // Written with setVar in its default context - a variable name like
            // any other, so getVar offers it.
            self::PROPERTY_COUNTER_VAR => PropertyUi::create()->valueHelper(SelectVarNameValueHelper::class),
            default => null,
        };
    }

    public function init(): WhileMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CONDITION, 'mixed', 'Specify the condition which has to hold for another pass'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_COMMANDS, 'array', 'Specify the commands to run on every pass', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_COUNTER_VAR, 'string', 'Name of variable to store the current pass in (counted from 0)', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_MAX_ITERATIONS, 'int', 'Most passes before the loop fails, -1 for no limit', self::UNLIMITED));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Run commands again and again as long as a condition holds.';
    }

    public function getName(): string
    {
        return 'while';
    }

    public function needPrecompiledArguments(): bool
    {
        return false;
    }

    protected function run(): ?array
    {
        // Read before anything runs: the macro is one instance, a while inside
        // the commands sets its properties anew.
        $condition = $this->getPropertyValue(self::PROPERTY_CONDITION);
        $commands = $this->getPropertyValue(self::PROPERTY_COMMANDS);
        $counterVar = $this->resolve($this->getPropertyValue(self::PROPERTY_COUNTER_VAR));
        $counterVar = is_string($counterVar) ? trim($counterVar) : '';
        $maxIterations = self::readMaxIterations($this->resolve($this->getPropertyValue(self::PROPERTY_MAX_ITERATIONS)));

        // The counter belongs to the commands of the loop: afterwards it is what
        // it was before it - gone, if it did not exist.
        $outerCounter = $counterVar !== '' ? $this->captureVariable($counterVar) : [];
        try {
            $this->runPasses($condition, $commands, $counterVar, $maxIterations);
        } finally {
            if ($counterVar !== '') {
                $this->restoreVariable($counterVar, $outerCounter);
            }
        }

        return $this->_createRunResult(['__void' => true]);
    }

    /**
     * Values typed into the editor arrive as strings. A positive whole number
     * is the limit; -1 - and anything else that is no positive whole number -
     * means no limit.
     */
    public static function readMaxIterations(mixed $value): int
    {
        if (is_string($value)) {
            $value = trim($value);
        }
        if (is_numeric($value) && (int)$value == $value && (int)$value > 0) {
            return (int)$value;
        }

        return self::UNLIMITED;
    }

    private function runPasses(mixed $condition, mixed $commands, string $counterVar, int $maxIterations): void
    {
        $evaluator = new ConditionEvaluator();
        $pass = 0;

        while ($evaluator->evaluate($condition, $this->resolve(...))) {
            if ($maxIterations !== self::UNLIMITED && $pass >= $maxIterations) {
                throw new LoopLimitExceededException(sprintf(
                    'while: the condition still holds after %d passes (maxIterations) - stopped to not loop forever',
                    $maxIterations
                ));
            }

            $this->log(eDebuggerLogType::INFO,
                sprintf('Pass %d', $pass + 1),
                ['pass' => $pass, 'reason' => eDebuggerLogReason::START_VIEW_GROUP]
            );

            if ($counterVar !== '') {
                $this->_executeMacro('setVar', ['name' => $counterVar, 'value' => $pass]);
            }

            $this->runCommands($commands);

            $this->log(eDebuggerLogType::INFO,
                sprintf('Finished pass %d', $pass + 1),
                ['reason' => eDebuggerLogReason::END_VIEW_GROUP]
            );

            $pass++;
        }

        $this->log(eDebuggerLogType::INFO,
            sprintf('Condition no longer holds after %d passes', $pass),
            ['passes' => $pass]
        );
    }

    private function resolve(mixed $value): mixed
    {
        return ($value instanceof CommandDTO || $value instanceof CommandGroupDTO)
            ? $this->_runCommandDefinition($value)
            : $value;
    }

    private function runCommands(mixed $commands): mixed
    {
        if ($commands === null || $commands === [] || $commands === '') {
            return null;
        }

        return $this->_runCommandDefinition($commands);
    }

    /**
     * The value the variable has before the loop, in the context setVar writes
     * it to by default - empty when it does not exist.
     *
     * @return array<string, mixed>
     */
    private function captureVariable(string $name): array
    {
        $context = $this->getVariablesStoreProvider()->getVariableValue(
            VariablesProvider::GET_VAR_WILDCARD,
            eMacroVariableContext::JOB,
            []
        );

        return is_array($context) && array_key_exists($name, $context) ? [$name => $context[$name]] : [];
    }

    /**
     * @param array<string, mixed> $outer
     */
    private function restoreVariable(string $name, array $outer): void
    {
        $variables = $this->getVariablesStoreProvider();

        if (array_key_exists($name, $outer)) {
            $variables->setVariable($name, $outer[$name], eMacroVariableContext::JOB);
        } else {
            $variables->removeVariable($name, eMacroVariableContext::JOB);
        }
    }
}
