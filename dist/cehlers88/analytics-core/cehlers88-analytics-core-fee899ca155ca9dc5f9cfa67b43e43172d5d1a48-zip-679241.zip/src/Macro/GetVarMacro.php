<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogReason;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\SelectVarNameValueHelper;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;

class GetVarMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    /** Not a context of its own: the variable is looked up in AUTO_CONTEXTS. */
    public const string CONTEXT_AUTO = 'auto';

    /**
     * The contexts an `auto` lookup searches, the first that holds the variable wins - so
     * from the most specific to the most general. get and post are left out on purpose: a
     * request must not be able to supply a variable the definition did not set; name them
     * explicitly to read them.
     */
    public const array AUTO_CONTEXTS = [
        eMacroVariableContext::ARGUMENT,
        eMacroVariableContext::LOCAL,
        eMacroVariableContext::JOB,
        eMacroVariableContext::WORKER,
        eMacroVariableContext::ENVIRONMENT,
        eMacroVariableContext::APPLICATION,
        eMacroVariableContext::SERVER,
        eMacroVariableContext::SHARED,
    ];

    private const DEFAULT_CONTEXT = self::CONTEXT_AUTO;
    private const PROPERTY_CONTEXT = 'context';
    private const PROPERTY_DEFAULT = 'default';
    private const PROPERTY_NAME = 'name';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_NAME => PropertyUi::create()->valueHelper(SelectVarNameValueHelper::class, [
                SelectVarNameValueHelper::OPTION_CONTEXT_PROPERTY => self::PROPERTY_CONTEXT,
                SelectVarNameValueHelper::OPTION_DEFAULT_CONTEXT => self::DEFAULT_CONTEXT,
            ]),
            self::PROPERTY_CONTEXT => PropertyUi::create()->options([
                self::CONTEXT_AUTO => ucfirst(self::CONTEXT_AUTO),
                ...SelectVarNameValueHelper::contextOptions(),
            ]),
            default => null,
        };
    }

    public function init(): GetVarMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME, 'string', 'Specify the variable name'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CONTEXT, 'string', 'Specify the variable context', self::DEFAULT_CONTEXT))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DEFAULT, 'mixed', 'Specify the default result', null));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Retrieve the value of a variable.';
    }

    public function getName(): string
    {
        return 'getVar';
    }

    protected function run(): ?array
    {
        $name = $this->getPropertyValue(self::PROPERTY_NAME);
        $context = $this->getPropertyValue(self::PROPERTY_CONTEXT);
        $default = $this->getPropertyValue(self::PROPERTY_DEFAULT);

        $this->log(eDebuggerLogType::INFO,
            sprintf("Get value of variable '%s'", $name),
            ['name' => $name]
        );

        if ($this->isAutoContext($context)) {
            [$result, $context] = $this->findInAutoContexts($name, $default);
        } else {
            $result = $this->getVariablesStoreProvider()->getVariableValue($name, $context, $default);
        }

        $this->log(eDebuggerLogType::INFO,
            sprintf("Received '%s'", json_encode($result)),
            [
                'name' => $name,
                'context' => $context,
                'default' => $default,
                'reason' => eDebuggerLogReason::INFO,
                'result' => $result
            ]
        );

        return $this->_createRunResult($result);
    }

    private function isAutoContext(mixed $context): bool
    {
        if ($context instanceof eMacroVariableContext) {
            return false;
        }

        // no context at all reads like the default one
        return $context === null || in_array(strtolower(trim((string)$context)), ['', self::CONTEXT_AUTO], true);
    }

    /**
     * The value from the first of AUTO_CONTEXTS that holds the variable, with that context -
     * the default and the context `auto` when none does.
     *
     * @return array{0: mixed, 1: eMacroVariableContext|string}
     */
    private function findInAutoContexts(string $name, mixed $default): array
    {
        $variables = $this->getVariablesStoreProvider();

        // The wildcard reads a whole context, and contexts do not merge into one list -
        // it keeps reading the context it read before `auto` became the default.
        if ($name === VariablesProvider::GET_VAR_WILDCARD) {
            return [$variables->getVariableValue($name, eMacroVariableContext::JOB, $default), eMacroVariableContext::JOB];
        }

        // An object no stored value can be identical to: null or the default may well be a
        // variable's real value.
        $missing = new \stdClass();

        foreach (self::AUTO_CONTEXTS as $context) {
            $value = $variables->getVariableValue($name, $context, $missing);
            // the argument context answers a missing argument with UNDEFINED_VAR, not the default
            if ($value !== $missing && $value !== VariablesProvider::UNDEFINED_VAR) {
                return [$value, $context];
            }
        }

        return [$default, self::CONTEXT_AUTO];
    }
}
