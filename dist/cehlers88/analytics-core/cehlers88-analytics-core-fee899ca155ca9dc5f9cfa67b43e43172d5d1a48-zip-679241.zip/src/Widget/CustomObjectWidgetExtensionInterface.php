<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Widget;

use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Symfony\Component\DependencyInjection\Attribute\AutoconfigureTag;

/**
 * Adds markup of its own to the dashboard widget of a custom object.
 *
 * The widget only knows the tile template of the object; what an application
 * keeps next to the object - the switches of its settings, for instance - comes
 * in through an extension. Implementing the interface is enough to be picked up.
 */
#[AutoconfigureTag(self::TAG)]
interface CustomObjectWidgetExtensionInterface
{
    public const string TAG = 'analytics.custom_object_widget_extension';

    /**
     * Markup shown above the tile of the object, or '' for none. It is printed
     * as it is, so everything in it has to be escaped already.
     */
    public function renderForWidget(object $customObject, CustomObjectView $view): string;
}
