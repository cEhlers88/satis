<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\Report\ReportPanelSelection;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Report;
use Cehlers88\AnalyticsCore\Repository\ReportRepository;
use Symfony\Bundle\SecurityBundle\Security;

/**
 * Some panels of a report, rendered the way the report renders them: the tile names the
 * report and the panels it shows, by the ids the panels were given in the report editor
 * (panel settings, see Analytics\Report\PanelIds). A panel without an id can not be picked.
 *
 * The report runs as a whole would - its settings, head commands and source apply - so a
 * panel shows the same here as it does in the report.
 */
class ReportViewWidget extends AbstractWidget
{
    public function __construct(
        private readonly ReportRepository     $reportRepository,
        private readonly ReportPanelSelection $panelSelection,
        private readonly Security             $security,
    )
    {
    }

    public function getName(): string
    {
        return 'AnalyticsCore.report';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '14px', 'boxes' => [.4]],
            ['height' => '80px', 'boxes' => [1]],
        ];
    }

    public function getTemplateName(): string
    {
        return 'reportView';
    }

    /** Reports are for the users of the dashboard, like the report page itself. */
    public function getRequiredRoles(): array
    {
        return ['ROLE_DASHBOARD'];
    }

    public function getSettingDefinitions(): array
    {
        $reportOptions = [];
        $panelConditions = [];
        foreach ($this->mayReadReports() ? $this->reportRepository->findBy([], ['title' => 'ASC']) : [] as $report) {
            $reportId = (int)$report->getId();
            $reportOptions[$reportId] = (string)$report->getTitle();

            // what the panel field offers follows the picked report
            $choices = $this->panelSelection->choices($report);
            $panelConditions[] = PropertyConditionDTO::when('report', $reportId)->then([
                PropertyConditionDTO::EFFECT_UI => ['suggestions' => $choices],
                ...($choices === [] ? [
                    PropertyConditionDTO::EFFECT_DESCRIPTION => 'Dieser Report hat noch kein Panel mit ID. Vergib im Report-Editor in den Einstellungen (⚙) eines Panels eine ID, um es hier anzeigen zu können.',
                ] : []),
            ]);
        }

        return [
            PropertyDTO::create(
                name: 'report',
                value: '',
                type: 'string',
                label: 'Report',
                description: 'Der Report, dessen Panels die Kachel zeigt.',
                ui: ['options' => $reportOptions]
            ),
            PropertyDTO::create(
                name: 'panels',
                value: '',
                type: 'string',
                label: 'Panels',
                description: 'Die Panels, die die Kachel zeigt, in dieser Reihenfolge. Wählbar sind nur Panels mit einer ID - die ID wird im Report-Editor in den Einstellungen (⚙) eines Panels vergeben.',
                ui: [
                    'input' => 'suggest',
                    'multiple' => true,
                    'suggestions' => [],
                ],
                conditions: $panelConditions
            ),
        ];
    }

    public function enrichProperties(array $properties): array
    {
        if (!$this->mayReadReports()) {
            return ['error' => 'Keine Berechtigung, Reports zu sehen.'];
        }

        $reportId = (int)($properties['report'] ?? 0);
        $report = $reportId > 0 ? $this->reportRepository->find($reportId) : null;
        if (!$report instanceof Report) {
            return ['error' => 'Den Report gibt es nicht (mehr).'];
        }

        $panelIds = self::panelIds($properties['panels'] ?? '');
        if ($panelIds === []) {
            return ['reportTitle' => (string)$report->getTitle(), 'error' => 'Es ist kein Panel gewählt.'];
        }

        return [
            'reportTitle' => (string)$report->getTitle(),
            // the markup of HtmlReportDocument, which escapes everything it writes
            'reportHtml' => $this->panelSelection->render($report, $panelIds),
        ];
    }

    /**
     * The panel ids of the setting, comma separated the way the mask keeps them.
     *
     * @return list<string>
     */
    public static function panelIds(mixed $value): array
    {
        if (is_int($value)) {
            $value = (string)$value;
        }
        if (!is_string($value)) {
            return [];
        }

        $ids = array_filter(array_map('trim', explode(',', $value)), static fn(string $id): bool => $id !== '');

        return array_values(array_unique($ids));
    }

    /** The widget may be rendered through the public widget endpoint, so it checks for itself. */
    private function mayReadReports(): bool
    {
        return $this->security->isGranted('ROLE_DASHBOARD') || $this->security->isGranted('ROLE_ADMIN');
    }
}
