<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Widget;

use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;

/**
 * The charts of a custom object as the dashboard widget offers them: one per
 * monitoring, each switchable through a "charts.<monitoring id>" setting and
 * optionally drawn in a fixed color ("fixedChartColors.<id>" / "chartColors.<id>").
 *
 * Kept apart from CustomObjectWidget, whose base class needs the host
 * application, so the selection can be tested on its own.
 */
final class CustomObjectWidgetCharts
{
    private const string COLOR_PATTERN = '/^#[0-9a-fA-F]{6}$/';

    /**
     * The monitorings whose chart the tile shows: all of them, except the ones
     * whose checkbox was cleared. A chart added after the tile was set up is
     * therefore shown until somebody turns it off.
     *
     * @return list<int>
     */
    public static function resolveVisibleMonitoringIds(CustomObjectView $view, mixed $chartSettings): array
    {
        $chartSettings = self::settingsArray($chartSettings);
        $visible = [];

        foreach (self::describe($view) as $chart) {
            $setting = $chartSettings[$chart['id']] ?? $chartSettings[(string)$chart['id']] ?? true;
            if (CustomObjectWidgetParts::isSwitchedOn($setting)) {
                $visible[] = $chart['id'];
            }
        }

        return $visible;
    }

    /**
     * The fixed colors of the charts, by monitoring id: only for the charts whose
     * switch for a fixed color is on and whose color is a valid "#rrggbb" - every
     * other chart keeps the color it picks itself.
     *
     * @return array<int, string>
     */
    public static function resolveFixedColors(CustomObjectView $view, mixed $fixedSettings, mixed $colorSettings): array
    {
        $fixedSettings = self::settingsArray($fixedSettings);
        $colorSettings = self::settingsArray($colorSettings);
        $colors = [];

        foreach (self::describe($view) as $chart) {
            $isFixed = $fixedSettings[$chart['id']] ?? $fixedSettings[(string)$chart['id']] ?? false;
            $color = $colorSettings[$chart['id']] ?? $colorSettings[(string)$chart['id']] ?? null;
            if (CustomObjectWidgetParts::isSwitchedOn($isFixed) && is_string($color) && preg_match(self::COLOR_PATTERN, $color)) {
                $colors[$chart['id']] = strtolower($color);
            }
        }

        return $colors;
    }

    /**
     * One entry per monitoring of the object: its id and a label naming the
     * attribute (a sensor value by its label) and the interval.
     *
     * @return list<array{id: int, label: string}>
     */
    public static function describe(CustomObjectView $view): array
    {
        $charts = [];

        foreach (($view->monitorings ?? []) as $attributeName => $monitorings) {
            $attributeLabel = $attributeName === 'value'
                ? (string)($view->attribute->label ?? 'value')
                : (string)$attributeName;

            foreach ((array)$monitorings as $monitoring) {
                $id = (int)($monitoring['id'] ?? 0);
                if ($id <= 0) {
                    continue;
                }
                $interval = (string)($monitoring['intervalLabel'] ?? $monitoring['interval'] ?? '');
                $charts[] = [
                    'id' => $id,
                    'label' => $interval === '' ? $attributeLabel : $attributeLabel . ' (' . $interval . ')',
                ];
            }
        }

        return $charts;
    }

    private static function settingsArray(mixed $settings): array
    {
        // The props reach the widget json decoded into objects (see renderWidget).
        return is_object($settings) ? (array)$settings : (is_array($settings) ? $settings : []);
    }
}
