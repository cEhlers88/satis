<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Widget;

/**
 * The parts of the dashboard widget of a custom object that can be turned off:
 * what extensions add (the switches of its settings, for instance) and its tile
 * template. With both off, only the picked charts are left.
 *
 * Kept apart from CustomObjectWidget, whose base class needs the host
 * application, so the decision can be tested on its own.
 */
final class CustomObjectWidgetParts
{
    /** Setting that shows what extensions add above the tile. */
    public const string SHOW_SWITCHES = 'showSwitches';

    /** Setting that shows the tile template; without it the charts stand on their own. */
    public const string SHOW_TEMPLATE = 'showTemplate';

    /**
     * Whether a part is shown. A widget set up before the setting existed has no
     * value for it and keeps showing the part.
     */
    public static function isShown(array $properties, string $part): bool
    {
        return self::isSwitchedOn($properties[$part] ?? true);
    }

    /**
     * Reads a checkbox of the settings mask, which arrives as bool, int or
     * string depending on how the props were stored.
     */
    public static function isSwitchedOn(mixed $value): bool
    {
        return $value !== false && $value !== 0 && $value !== '0' && $value !== 'false' && $value !== null;
    }
}
