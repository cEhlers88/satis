<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\ApplicationAction;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Repository\ApplicationActionRepository;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\Security\Core\User\UserInterface;

/**
 * The actions of all applications, or of the picked ones, grouped by application: whether
 * each one is running right now (ApplicationAction::isActive(), the state startAction and
 * stopAction set), and a switch to turn it on or off by hand - without running its commands,
 * like the switch in Settings > Root data.
 *
 * With "Nur aktive anzeigen" only the running actions are listed, and an application without
 * any drops out of the tile.
 *
 * Only applications the signed-in user may read are listed, and only their actions can be
 * switched. The template asks for a fresh rendering whenever an ApplicationAction changes,
 * so the tile follows startAction, stopAction and the switches elsewhere live.
 */
class ApplicationActionsViewWidget extends AbstractWidget
{
    public const FILTER_ALL = 'showAll';
    public const FILTER_APPLICATION = 'filterApplication';

    private const FALLBACK_COLOR = '#6aa3e0';

    public function __construct(
        private readonly ApplicationRepository       $applicationRepository,
        private readonly ApplicationActionRepository $applicationActionRepository,
        private readonly EntityManagerInterface      $entityManager,
        private readonly Security                    $security,
    )
    {
    }

    public function getName(): string
    {
        return 'AnalyticsCore.applicationActionsView';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '10px', 'boxes' => [.4]],
            ['height' => '10px', 'boxes' => [.05, .75, .1]],
            ['height' => '10px', 'boxes' => [.05, .75, .1]],
            ['height' => '10px', 'boxes' => [.05, .75, .1]],
            ['height' => '10px', 'boxes' => [.4]],
            ['height' => '10px', 'boxes' => [.05, .75, .1]],
        ];
    }

    public function getTemplateName(): string
    {
        return 'applicationActionsView';
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'filterType',
                value: self::FILTER_ALL,
                type: 'string',
                label: 'Anzeige',
                description: 'Die Actions aller Applications zeigen oder nur die der gewählten.',
                ui: [
                    'options' => [
                        self::FILTER_ALL => 'Alle Applications',
                        self::FILTER_APPLICATION => 'Gewählte Applications',
                    ],
                ]
            ),
            PropertyDTO::create(
                name: 'application',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Applications',
                description: 'Die Applications, deren Actions gezeigt werden.',
                ui: [
                    'input' => 'suggest',
                    'multiple' => true,
                    'suggestions' => $this->applicationSuggestions(),
                ],
                conditions: [
                    PropertyConditionDTO::when('filterType', self::FILTER_ALL)->then([
                        PropertyConditionDTO::EFFECT_VISIBLE => false,
                    ]),
                    PropertyConditionDTO::when('filterType', self::FILTER_APPLICATION)->then([
                        PropertyConditionDTO::EFFECT_IS_OPTIONAL => false,
                    ]),
                ]
            ),
            PropertyDTO::create(
                name: 'onlyActive',
                value: false,
                type: 'bool',
                isOptional: true,
                label: 'Nur aktive anzeigen',
                description: 'Nur die Actions zeigen, die gerade laufen.',
            ),
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $applications = $this->applications($this->security->getUser(), $properties);
        $onlyActive = self::onlyActive($properties['onlyActive'] ?? false);

        // the actions of all listed applications in one query, not one per application
        $actionsByApplication = [];
        $found = $applications === [] ? [] : $this->applicationActionRepository->findBy(['application' => $applications]);
        foreach ($found as $action) {
            $actionsByApplication[(int)$action->getApplication()?->getId()][] = [
                'id' => (int)$action->getId(),
                'name' => (string)$action->getName(),
                'description' => trim((string)$action->getDescription()),
                'active' => (bool)$action->isActive(),
                'reason' => $action->getReason(),
            ];
        }

        $groups = [];
        foreach ($applications as $application) {
            $actions = $actionsByApplication[(int)$application->getId()] ?? [];
            usort($actions, static fn(array $a, array $b): int => strnatcasecmp($a['name'], $b['name']));

            $active = array_values(array_filter($actions, static fn(array $action): bool => $action['active']));
            if ($onlyActive && $active === []) {
                continue;
            }

            $groups[] = [
                'id' => (int)$application->getId(),
                'name' => (string)$application->getName(),
                'color' => self::color($application),
                'actions' => $onlyActive ? $active : $actions,
                'activeCount' => count($active),
                // the head keeps counting all actions, so a filtered tile still tells how many are off
                'actionCount' => count($actions),
            ];
        }

        return [
            'groups' => $groups,
            'onlyActive' => $onlyActive,
            'canSwitch' => $this->maySwitch(),
        ];
    }

    /**
     * Switches an action on or off by hand: `id` of the action, `state` "1" or "0".
     */
    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        if ($user === null) {
            return WidgetSubmitResultDTO::createError(401, 'Nicht angemeldet.');
        }
        if (!$this->maySwitch()) {
            return WidgetSubmitResultDTO::createError(403, 'Keine Berechtigung, Actions zu schalten.');
        }

        $id = $data['id'] ?? null;
        $action = self::isId($id) ? $this->applicationActionRepository->find((int)$id) : null;
        // an action of an application the user may not read is as good as missing
        if (!$action instanceof ApplicationAction || !self::mayRead($user, $action->getApplication())) {
            return WidgetSubmitResultDTO::createError(404, 'Die Action gibt es nicht (mehr).');
        }

        $state = $data['state'] ?? null;
        if (!in_array($state, ['0', '1'], true)) {
            return WidgetSubmitResultDTO::createError(422, 'Unbekannter Zustand - erwartet wird 1 oder 0.');
        }
        $state = $state === '1';
        // switched on by hand is a start without a reason - the one of the last start would
        // tell the wrong story; switched off, it keeps it like stopAction does
        if ($state && !$action->isActive()) {
            $action->setReason(null);
        }
        $action->setState($state);
        $this->entityManager->flush();

        return WidgetSubmitResultDTO::createSuccess(
            sprintf($state ? 'Action "%s" ist jetzt aktiv.' : 'Action "%s" ist jetzt inaktiv.', $action->getName()),
            ['id' => (int)$action->getId(), 'state' => $state]
        );
    }

    /**
     * The application ids of the setting - a comma separated list from the mask, or a single
     * number once the widget request decoded it as JSON.
     *
     * @return list<int>
     */
    public static function applicationIds(mixed $value): array
    {
        if (is_int($value)) {
            return $value > 0 ? [$value] : [];
        }
        if (!is_string($value)) {
            return [];
        }

        $ids = array_map('intval', array_filter(array_map('trim', explode(',', $value)), self::isId(...)));

        return array_values(array_unique($ids));
    }

    /**
     * The setting is stored as a bool, but a tile saved before it existed has none, and a
     * widget request may hand it over as "1" or "true".
     */
    public static function onlyActive(mixed $value): bool
    {
        return is_scalar($value) && filter_var($value, FILTER_VALIDATE_BOOL);
    }

    /**
     * The applications to show, sorted by name: those the user may read, narrowed down to the
     * picked ones when the widget is filtered.
     *
     * @return list<Application>
     */
    private function applications(?UserInterface $user, array $properties): array
    {
        if ($user === null) {
            return [];
        }

        $criteria = [];
        if (($properties['filterType'] ?? self::FILTER_ALL) === self::FILTER_APPLICATION) {
            $ids = self::applicationIds($properties['application'] ?? '');
            if ($ids === []) {
                return [];
            }
            $criteria['id'] = $ids;
        }

        // findBy, not the user-aware findAll(): the repository is shared, and a user set on it
        // by an earlier request must not decide what this one sees
        $applications = array_values(array_filter(
            $this->applicationRepository->findBy($criteria),
            static fn(Application $application): bool => self::mayRead($user, $application)
        ));
        usort($applications, static fn(Application $a, Application $b): int => strnatcasecmp((string)$a->getName(), (string)$b->getName()));

        return $applications;
    }

    /** @return array<int, string> */
    private function applicationSuggestions(): array
    {
        $suggestions = [];
        foreach ($this->applications($this->security->getUser(), []) as $application) {
            $suggestions[(int)$application->getId()] = (string)$application->getName();
        }

        return $suggestions;
    }

    /** Switching is for the users of the dashboard, like the switch in Settings > Root data. */
    private function maySwitch(): bool
    {
        return $this->security->isGranted('ROLE_DASHBOARD') || $this->security->isGranted('ROLE_ADMIN');
    }

    /** A plain positive id - "1.9" or "1e3" would be cast to another action than the one meant. */
    private static function isId(mixed $value): bool
    {
        return (is_int($value) && $value > 0) || (is_string($value) && preg_match('/^[1-9]\d{0,18}$/', $value) === 1);
    }

    private static function mayRead(UserInterface $user, ?Application $application): bool
    {
        return $application !== null && $application->allowRead($user);
    }

    /** The color ends up in a style attribute, so only a plain hex color gets there. */
    private static function color(Application $application): string
    {
        $color = (string)$application->getColor();

        return preg_match('/^#[0-9a-f]{6}$/i', $color) === 1 ? $color : self::FALLBACK_COLOR;
    }
}
