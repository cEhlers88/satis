<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 20:37
 */

namespace Cehlers88\AnalyticsCore\Configuration;

use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationSuggestItemDTO;

class GeneralConfigurationGroup extends AbstractConfigurationGroup
{
    public const KEY = 'coreBundle.general';
    public const KEY_UPDATE_ACTION = 'updateAction';
    public const KEY_MAINTENANCE_ACTION = 'maintenanceAction';

    public function getItems(): array
    {
        return [
            ConfigurationSuggestItemDTO::createSuggest(self::KEY_UPDATE_ACTION, 'Update action', 'ApplicationAction'),
            ConfigurationSuggestItemDTO::createSuggest(self::KEY_MAINTENANCE_ACTION, 'Maintenance action', 'ApplicationAction'),
        ];
    }

    public function getGroupTitle(): string
    {
        return 'Allgemeine Core-Einstellungen';
    }

    public function getGroupDescription(): string
    {
        return 'Allgemeine Einstellungen für das Core-Bundle';
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}