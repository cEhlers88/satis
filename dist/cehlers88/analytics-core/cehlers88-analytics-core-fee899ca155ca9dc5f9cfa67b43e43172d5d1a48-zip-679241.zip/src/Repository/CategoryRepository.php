<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\Category;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Category>
 *
 * @method Category|null find($id, $lockMode = null, $lockVersion = null)
 * @method Category|null findOneBy(array $criteria, array $orderBy = null)
 * @method Category[]    findAll()
 * @method Category[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class CategoryRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Category::class);
    }

    /**
     * The categories with the given ids, sorted by name; unknown ids are left out.
     *
     * @param array<int|string> $ids
     * @return Category[]
     */
    public function findByIds(array $ids): array
    {
        // Only whole numbers count - "1foo" or "1.5" must not quietly become category 1.
        $ids = array_values(array_unique(array_map('intval', array_filter(
            array_map(static fn(mixed $id) => is_scalar($id) ? trim((string)$id) : '', $ids),
            static fn(string $id) => ctype_digit($id) && (int)$id > 0
        ))));
        if ($ids === []) {
            return [];
        }

        return $this->findBy(['id' => $ids], ['name' => 'ASC']);
    }
}
