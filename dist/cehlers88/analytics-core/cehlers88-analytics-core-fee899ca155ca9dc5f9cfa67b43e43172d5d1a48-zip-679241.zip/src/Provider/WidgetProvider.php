<?php

namespace Cehlers88\AnalyticsCore\Provider;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Support\Property\PropertyValuePath;
use Cehlers88\AnalyticsCore\Widget\AbstractWidget;
use Cehlers88\AnalyticsCore\Widget\WidgetSettings;
use Twig\Environment;
use Twig\TemplateWrapper;

class WidgetProvider
{
    private ?User $_user = null;

    public function __construct(
        private iterable       $widgets,
        private Environment    $twig,
        private WidgetSettings $widgetSettings = new WidgetSettings()
    )
    {
    }

    public function canAccessWidget(string $widgetName): bool
    {
        $widget = $this->getWidget($widgetName);
        if (is_null($widget)) {
            throw new \Exception('Widget not found');
        }

        if (count($widget->getRequiredRoles()) === 0) {
            return true;
        }

        if (is_null($this->_user)) {
            return false;
        }

        if ($this->_user->hasRole('ROLE_ADMIN')) {
            return true;
        }

        foreach ($widget->getRequiredRoles() as $role) {
            if (!$this->_user->hasRole($role)) {
                return false;
            }
        }

        return true;
    }

    public function getWidget(string $widgetName): ?AbstractWidget
    {
        foreach ($this->widgets as $widget) {
            if ($widget->getName() === $widgetName) {
                return $widget;
            }
        }
        return null;
    }

    public function getWidgetNames(): array
    {
        $names = [];
        foreach ($this->widgets as $widget) {
            $names[] = $widget->getName();
        }
        return $names;
    }

    public function getAvailableWidgetDefinitions(): array
    {
        $result = [];
        foreach ($this->widgets as $widget) {
            $result[] = [
                'name' => $widget->getName(),
                'preloadPlaceholders' => $widget->getPreloadPlaceholders(),
            ];
        }
        return $result;
    }

    /**
     * The widgets a user may put on a dashboard, each with the settings it can
     * be configured with. This is what the setup tile builds its type picker
     * and the matching settings mask from.
     *
     * @return array<int, array{name: string, settings: PropertyDTO[]}>
     */
    public function getSelectableWidgetDefinitions(): array
    {
        $result = [];
        foreach ($this->widgets as $widget) {
            if (!$widget->isSelectable() || !$this->canAccessWidget($widget->getName())) {
                continue;
            }

            $result[] = [
                'name' => $widget->getName(),
                // A tile that is only being picked has no values yet, so the
                // mask shows the settings as their conditions leave them when
                // nothing has been filled in.
                'settings' => array_values($this->getResolvedSettingDefinitions($widget->getName())),
            ];
        }

        return $result;
    }

    /**
     * @param array $values What the tile holds - widgets may offer settings
     *        that depend on it, see AbstractWidget::getSettingDefinitionsFor().
     *
     * @return array<string, PropertyDTO> Keyed by property name.
     */
    public function getSettingDefinitions(string $widgetName, array $values = []): array
    {
        $definitions = [];
        foreach ($this->getWidget($widgetName)?->getSettingDefinitionsFor($values) ?? [] as $definition) {
            $definitions[$definition->name] = $definition;
        }

        return $definitions;
    }

    /**
     * The settings of a widget as the given values leave them: with the
     * conditions the values fulfill applied, which is what a mask renders.
     *
     * @return array<string, PropertyDTO> Keyed by property name.
     */
    public function getResolvedSettingDefinitions(string $widgetName, array $values = []): array
    {
        return $this->widgetSettings->resolve($this->getSettingDefinitions($widgetName, $values), $values);
    }

    /**
     * Turns the values submitted for a widget into the props it is rendered
     * with - see WidgetSettings.
     */
    public function normalizeSettings(string $widgetName, array $submittedSettings): array
    {
        $staticNames = array_keys($this->getSettingDefinitions($widgetName));
        $definitions = array_filter(
            $this->getSettingDefinitions($widgetName, $submittedSettings),
            // A setting that only exists because of the submitted values (the
            // charts of the picked custom object) was never on the mask that
            // sent them - the setup mask asks for the object alone. Left out,
            // it keeps the widget's default instead of becoming an unchecked
            // "false". The tile settings send their unchecked boxes explicitly.
            static fn(PropertyDTO $definition): bool => in_array($definition->name, $staticNames, true)
                || !is_null(PropertyValuePath::read($submittedSettings, $definition->name))
        );

        return $this->widgetSettings->normalize($definitions, $submittedSettings);
    }

    /**
     * The required settings the given props do not answer - an empty array
     * means the widget has everything it needs.
     *
     * @return PropertyDTO[]
     */
    public function getMissingRequiredSettings(string $widgetName, array $props): array
    {
        return $this->widgetSettings->findUnsatisfied($this->getSettingDefinitions($widgetName, $props), $props);
    }

    public function renderWidget(string $widgetName, array $widgetProps = []): string
    {
        $widget = $this->getWidget($widgetName);
        if (is_null($widget)) {
            return 'Widget not found';
        }

        $possibleTemplatePaths = [
            'widget/' . $widget->getTemplateName(),
            'widget/' . $widget->getTemplateName() . '.html.twig',
            'widget/' . $widget->getName(),
            'widget/' . $widget->getName() . '.html.twig',
        ];

        try {
            $resolvedTemplate = $this->twig->resolveTemplate($possibleTemplatePaths);
        } catch (\Exception $e) {
            return 'No Template for widget "' . $widgetName . '" found';
        }

        try {
            return $resolvedTemplate->render([
                'widgetId' => 'wid' . uniqid(),
                ...$widgetProps
            ]);
        } catch (\Exception $e) {
            return 'Error while rendering widget "' . $widgetName . '": ' . $e->getMessage();
        }
    }

    private function resolveTemplate(string $templateName): ?TemplateWrapper
    {
        try {
            return $this->twig->resolveTemplate($templateName);
        } catch (\Exception $e) {
            return null;
        }
    }

    public function setUser(?User $user)
    {
        $this->_user = $user;
    }
}