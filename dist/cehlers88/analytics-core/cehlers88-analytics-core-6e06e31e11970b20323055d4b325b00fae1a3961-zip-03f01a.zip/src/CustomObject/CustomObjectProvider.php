<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:40
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Repository\CustomEntityRepository;

/** Provider for managing custom object instances. */
class CustomObjectProvider
{
    public function __construct(
        private iterable               $customEntityClasses,
        private CustomEntityRepository $customEntityRepository
    )
    {
    }

    /**
     * @param CustomObjectInterface $customEntity
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClass(CustomObjectInterface $customEntity): array
    {
        return $this->getCustomEntitiesByClassName($customEntity->getClassName());
    }

    /**
     * @param string $className
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClassName(string $className): array
    {
        return $this->getCustomEntitiesBy(['className' => $className]);
    }

    public function getCustomEntitiesBy(array $filters): array
    {
        $customEntities = [];

        $buffer = [];
        $parentIdList = [];

        foreach ($this->customEntityRepository->findBy($filters) as $customEntity) {
            $buffer[] = [
                'customEntity' => $customEntity,
                'children' => []
            ];
            $parentIdList[] = $customEntity->getId();
        }

        if (!empty($parentIdList)) {
            foreach ($this->customEntityRepository->findBy(['parentId' => $parentIdList]) as $customEntity) {
                foreach ($buffer as &$entry) {
                    if ($entry['customEntity']->getId() === $customEntity->getParentId()) {
                        $entry['children'][] = $this->resolveCustomEntity($customEntity);
                        break;
                    }
                }
            }
        }

        foreach ($buffer as $entry) {
            $customEntities[] = $this->resolveCustomEntity($entry['customEntity'], $entry['children']);
        }
        return $customEntities;
    }

    /**
     * Resolve a CustomEntity into a CustomObjectInterface instance.
     *
     * @param CustomEntity $customEntity The entity to resolve.
     * @return CustomObjectInterface
     */
    public function resolveCustomEntity(CustomEntity $customEntity, array $childObjects = []): CustomObjectInterface
    {
        $className = $customEntity->getClassName();

        /** @var CustomObjectInterface $instance */
        $instance = new $className();
        $instance->load($customEntity, $childObjects);

        return $instance;
    }

    public function getAttributesOfCustomEntityClass(string $className): array
    {
        return $this->customEntityRepository->findAttributeNamesByClass($className);
    }

    public function getCustomObjectById(int $id): ?CustomObjectInterface
    {
        return $this->getCustomEntitiesBy(['id' => $id])[0];

    }

    /**
     * Get all registered custom entity classes.
     *
     * @return CustomObjectInterface[]
     */
    public function getCustomClasses(): iterable
    {
        return $this->customEntityClasses;
    }

    public function createNewCustomEntity(string $className): CustomObjectInterface
    {
        /** @var CustomObjectInterface $buffer */
        $buffer = new $className();

        $buffer
            ->setCreatedAt(new \DateTimeImmutable())
            ->setModifiedAt(new \DateTimeImmutable());

        return $buffer;
    }

    public function save(CustomObjectInterface $customEntityToSave): void
    {
        $isNew = $customEntityToSave->getId() === null || $customEntityToSave->getId() <= 0;
        $attrs = [];
        $entity = null;

        if (!$isNew) {
            $entity = $this->customEntityRepository->find($customEntityToSave->getId());
            foreach ($entity->getAttributes() as $attribute) {
                $attrs[$attribute->getName()] = [
                    'obj' => $attribute,
                    'stillExist' => false,
                    'isNew' => false
                ];
            }
        } else {
            $entity = new CustomEntity();
            $entity
                ->setClassName($customEntityToSave->getClassName());
        }

        foreach ($customEntityToSave->getAttributes() as $attributeName => $attributeValue) {
            $attrs[$attributeName]['stillExist'] = true;
            $entity->setAttributeValue($attributeName, $attributeValue);
        }

        $entity->setName($customEntityToSave->getName());
        $entity->setParentId($customEntityToSave->getParentId());

        foreach ($attrs as $attributeName => $attribute) {
            if (!$attribute['stillExist']) {
                $entity->removeAttribute($attribute['obj']);
            }
        }

        $this->customEntityRepository->save($entity);
    }
}