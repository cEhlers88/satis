<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 24.05.2024
 * Time: 22:30
 */

namespace Cehlers88\AnalyticsCore\Configuration;

use Analytics\Entity\VariableStore;
use Analytics\ENUM\eMacroVariableContext;
use Analytics\Provider\VariablesProvider;
use Analytics\Repository\VariableStoreRepository;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;

class ConfigurationProvider
{
    public const KEY_INDIVIDUALS = 'individuals';
    public const KEY_GENERALS = 'main.general';

    private bool $enableAutoload = true;
    private bool $loaded = false;
    private array $_updatedVarsBuffer = [];

    /**
     * @param GroupInterface[] $configurations
     * @param ApplicationRepository $applicationRepository
     * @param VariableStoreRepository $variableStoreRepository
     * @param VariablesProvider $variablesStoreProvider
     * @param array $buffer
     */
    public function __construct(
        private iterable                $configurations,
        private ApplicationRepository   $applicationRepository,
        private VariableStoreRepository $variableStoreRepository,
        private VariablesProvider       $variablesStoreProvider,
        private array                   $buffer = [],
    )
    {
    }

    public function loadBuffer(): static
    {
        $this->_loadConfiguration();
        $this->loaded = true;
        return $this;
    }

    private function _loadConfiguration(): array
    {
        $this->buffer = [];

        $this->_defineBufferItems();

        if ($this->enableAutoload) {
            $this->_enrichBufferItemsWithValues();
        }

        // set default values if needed
        foreach ($this->buffer as $groupIndex => $bufferedGroup) {
            for ($j = 0; $j < count($bufferedGroup['items']); $j++) {
                $bufferedItem = $bufferedGroup['items'][$j];
                if (count($bufferedItem['values']) > 0) {
                    continue;
                }

                $this->buffer[$groupIndex]['items'][$j]['values'][] = [
                    'application_id' => -1,
                    'context' => eMacroVariableContext::SERVER,
                    'value' => $bufferedItem['inputDef']->defaultValue,
                ];
            }
        }

        $this->loaded = true;

        return $this->buffer;
    }

    private function _defineBufferItems(): void
    {
        foreach ($this->configurations as $configuration) {
            $bufferItems = [];
            /**
             * @var $item ConfigurationItemDTO
             */
            foreach ($configuration->getItems() as $item) {
                $bufferItems[] = $this->buildBufferItem(
                    $configuration->getKey() . '.' . $item->key,
                    $item->label,
                    [],
                    $item,
                    $item->needApplication
                );
            }
            $this->buffer[] = $this->createBufferGroup(
                $configuration->getKey(),
                $configuration->getGroupTitle(),
                $configuration->getViewContext(),
                $bufferItems,
                $configuration->needApplication(),
                $configuration->isPersistable()
            );
        }
    }

    public function buildBufferItem(
        string               $key,
        string               $label,
        mixed                $values,
        ConfigurationItemDTO $inputDef,
        bool                 $needApplication = false
    ): array
    {
        return [
            //'context' => eMacroVariableContext::SERVER,
            'key' => $key,
            'label' => $label,
            'needApplication' => $needApplication,
            'inputDef' => $inputDef,
            'values' => $values
        ];
    }

    /**
     * @phpstan-type ConfigArray array{
     *     items: array<array<string, mixed>>,
     *     key: string,
     *     label: string,
     *     needApplication: bool,
     *     persistable: bool,
     *     viewContext: string
     * }
     *
     * @param string $key
     * @param string $label
     * @param string $viewContext
     * @param array $items
     * @param bool $needApplication
     * @param bool $persistable
     * @return ConfigArray
     */
    private function createBufferGroup(
        string $key,
        string $label,
        string $viewContext = '',
        array  $items = [],
        bool   $needApplication = false,
        bool   $persistable = true
    ): array
    {
        return [
            'items' => $items,
            'key' => $key,
            'label' => $label,
            'needApplication' => $needApplication,
            'persistable' => $persistable,
            'viewContext' => $viewContext
        ];
    }

    private function _enrichBufferItemsWithValues(): void
    {
        $individualsBuffer = [];
        $constantsBuffer = [];

        foreach ($this->variableStoreRepository->findAll() as $variableStore) {
            $bufferedItemFound = false;

            foreach ($this->buffer as &$bufferedGroup) {
                foreach ($bufferedGroup['items'] as &$bufferedItem) {
                    if ($bufferedItem['key'] !== $variableStore->getName()) {
                        continue;
                    }

                    $bufferedItemFound = true;
                    $application = $variableStore->getApplication();

                    $bufferedItem['values'][] = [
                        'application_id' => $application === null ? -1 : $application->getId(),
                        'context' => $variableStore->getContext(),
                        'type' => $variableStore->getValue()[0],
                        'value' => $variableStore->getValue()[1],
                    ];

                }
            }

            if (!$bufferedItemFound) {
                $application = $variableStore->getApplication();

                $splitName = explode('.', $variableStore->getName());

                if (strtolower($splitName[0]) === 'constant') {
                    array_shift($splitName);
                    $selfName = implode('.', $splitName);
                    if (!isset($constantsBuffer[$selfName])) {
                        $constantsBuffer[$selfName] = [];
                    }
                    $constantsBuffer[$selfName][] = [
                        'application_id' => $application === null ? -1 : $application->getId(),
                        'context' => $variableStore->getContext(),
                        'type' => $variableStore->getValue()[0],
                        'value' => $variableStore->getValue()[1],
                    ];

                    continue;
                }
                $selfName = array_pop($splitName);
                /*
                                $groupName = implode('.', $splitName);*/
                /*
                                if (!isset($individualsBuffer[$groupName])) {
                                    $individualsBuffer[$groupName] = [];
                                }
                                if (!isset($individualsBuffer[$groupName][$selfName])) {
                                    $individualsBuffer[$groupName][$selfName] = [];
                                }
                                $individualsBuffer[$groupName][$selfName][] = [
                                    'application_id' => $application === null ? -1 : $application->getId(),
                                    'context' => $variableStore->getContext(),
                                    'type' => $variableStore->getValue()[0],
                                    'value' => $variableStore->getValue()[1],
                                ];*/

                $individualsBuffer[] = [
                    'key' => $variableStore->getName(),
                    'label' => $selfName,
                    'inputDef' => $this->evalInputDefByVariableStore($variableStore),
                    'values' => [
                        [
                            'application_id' => $application === null ? -1 : $application->getId(),
                            'context' => $variableStore->getContext(),
                            'type' => $variableStore->getValue()[0],
                            'value' => $variableStore->getValue()[1],
                        ]
                    ]
                ];
            }
        }

        $items = [];
        foreach ($constantsBuffer as $key => $values) {
            $type = $values[0]['type'] ?? eInputType::TEXT_SINGLE_LINE->name;

            switch (strtolower($type)) {
                case 'password':
                    $type = eInputType::PASSWORD;
                    break;
                default:
                    $type = eInputType::TEXT_SINGLE_LINE;
            }

            $items[] = $this->buildBufferItem(
                $key,
                $key,
                $values,
                ConfigurationItemDTO::create($key, $variableStore->getName(), $type)
            );
        }

        $this->buffer[] = $this->createBufferGroup(
            'CONSTANT',
            'Constants',
            'settings',
            $items
        );

        $this->buffer[] = $this->createBufferGroup(
            self::KEY_INDIVIDUALS,
            'Individuals',
            AbstractConfigurationGroup::VIEW_CONTEXT_SETTINGS,
            $individualsBuffer,
        );

        $foo = 123;
    }

    public function getValue(
        string $configurationGroupKey,
        string $configurationItemKey,
        int    $applicationId = -1,
        mixed  $defaultValue = null
    ): mixed
    {
        if ($applicationId !== -1) {
            $this->variablesStoreProvider->loadApplicationContext($applicationId);
        }

        $varName = $configurationGroupKey . '.' . $configurationItemKey;

        return $this->variablesStoreProvider->getVariableValue(
            $varName,
            ($applicationId === -1 ? eMacroVariableContext::SERVER : $this->applicationRepository->find($applicationId)->getName()),
            $defaultValue
        );
    }

    public function evalInputDefByVariableStore(VariableStore $variableStore): ConfigurationItemDTO
    {
        $type = $variableStore->getValue()[0];

        if ($type === 'array') {
            $children = [];
            $dataChild = $variableStore->getValue()[1][0];

            foreach ($dataChild as $key => $value) {
                $children[] = ConfigurationItemDTO::create($key, $key);
            }

            return ConfigurationItemDTO::createRepeat($variableStore->getName(), $variableStore->getName(), $children);
        }

        return ConfigurationItemDTO::create($variableStore->getName(), $variableStore->getName());
    }

    public function loadRequestData(array $requestData): static
    {
        $groups = [];

        foreach ($requestData as $key => $value) {
            $explodedKey = explode('_', $key);

            if (count($explodedKey) > 2) {
                $context = $explodedKey[0];
                $applicationId = $explodedKey[1];
                $key = $explodedKey[2];
                $groupName = $explodedKey[2];
                $groupKey = $explodedKey[count($explodedKey) - 1];

                if (is_array($value)) {
                    continue;
                }

                for ($i = 3; $i < count($explodedKey); $i++) {
                    $key .= '_' . $explodedKey[$i];
                    $groupName .= $i < count($explodedKey) - 1 ? '_' . $explodedKey[$i] : '';
                }

                $key = str_replace(self::KEY_INDIVIDUALS . '_', '', $key);

                $currentValue = $this->getValue(str_replace('_', '.', $groupName), $groupKey, (int)$applicationId);
                if ($currentValue . '' === $value . '') {
                    continue;
                }
                $currentValue = $this->getValue(str_replace('_', '.', $groupName), $groupKey, (int)$applicationId);

                if (is_array($value)) {
                    // store group
                    $groupIndex = -1;
                    for ($i = 0; $i < count($groups); $i++) {
                        if ($groups[$i]['groupName'] === $groupName && $groups[$i]['context'] === $context && $groups[$i]['applicationId'] === $applicationId) {
                            $groupIndex = $i;
                            break;
                        }
                    }

                    if ($groupIndex === -1) {
                        $groups[] = [
                            'groupName' => $groupName,
                            'context' => $context,
                            'applicationId' => $applicationId,
                            'values' => []
                        ];
                        $groupIndex = count($groups) - 1;
                    }

                    foreach ($value as $index => $valueEntry) {
                        if (!isset($groups[$groupIndex]['values'][$index])) {
                            $groups[$groupIndex]['values'][$index] = [];
                        }
                        $groups[$groupIndex]['values'][$index][$groupKey] = $valueEntry;
                    }
                } else {
                    $this->_addUpdatedVar(
                        eMacroVariableContext::fromString($context),
                        str_replace("_", ".", $key),
                        [
                            is_numeric($value) ? 'numeric' : gettype($value),
                            $value
                        ],
                        (int)$applicationId,
                        $groupName
                    );
                }
            }
        }

        foreach ($groups as $group) {
            $this->_addUpdatedVar(
                eMacroVariableContext::fromString($group['context']),
                str_replace("_", ".", $group['groupName']),
                [
                    is_numeric($group['values']) ? 'numeric' : gettype($group['values']),
                    $group['values']
                ],
                $group['applicationId']
            );
        }

        return $this;
    }

    private function _addUpdatedVar(
        eMacroVariableContext $context,
        string                $variableName,
        mixed                 $variableValue,
        int                   $applicationId,
        string                $groupName = ''
    ): void
    {
        if (!isset($this->_updatedVarsBuffer[$context->name])) {
            $this->_updatedVarsBuffer[$context->name] = [];
        }

        $appGroup = $applicationId > 0 ? 'app' . $applicationId : 'server';

        if (!isset($this->_updatedVarsBuffer[$context->name][$appGroup])) {
            $this->_updatedVarsBuffer[$context->name][$appGroup] = [];
        }

        $this->_updatedVarsBuffer[$context->name][$appGroup][$variableName] = [
            'context' => $context,
            'groupName' => $groupName,
            'applicationId' => $applicationId,
            'value' => $variableValue
        ];
    }

    public function persistConfiguration(): array
    {
        $changed = false;

        foreach ($this->_updatedVarsBuffer as $context => $bufferedApplicationGroups) {
            foreach ($bufferedApplicationGroups as $group => $bufferedGroupVars) {
                foreach ($bufferedGroupVars as $varName => $varInfos) {
                    $changed = $this->variableStoreRepository->setVariableValue(
                            $varInfos['context'],
                            $varName,
                            $varInfos['value'],
                            $varInfos['applicationId']
                        ) || $changed;

                }
            }
        }

        if ($changed) {
            $this->variableStoreRepository->flush();
        }

        return $this->getConfigurations();
    }

    public function getConfigurations(): array
    {
        if (!$this->loaded) {
            return $this->_loadConfiguration();
        }
        return $this->buffer;
    }

    public function getConfiguration(string $key): ?GroupInterface
    {
        foreach ($this->configurations as $group) {
            if ($group->getKey() === $key) {
                return $group;
            }
        }
        return null;
    }

    public function setEnableAutoload(bool $enableAutoload): static
    {
        $this->enableAutoload = $enableAutoload;
        return $this;
    }
}