<?php

namespace Cehlers88\AnalyticsCore\Recorder;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Observer\Message\TrackingBufferChangedObserverMessage;
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;

class TrackingRecorder
{
    public function __construct(
        private ApplicationRepository    $applicationRepository,
        private TrackingBufferRepository $trackingBufferRepository,
        private ObserverProvider         $observerProvider
    )
    {
    }

    public function track(
        int|Application $application,
        array           $data,
        bool            $flush = true
    ): TrackingRecorder
    {
        $trackingBuffer = new TrackingBuffer();

        if (is_numeric($application)) {
            $application = $this->applicationRepository->find($application);
        }

        $trackingBuffer
            ->setState(eTrackingBufferState::NEW)
            ->setApplication($application)
            ->setTimestamp(new \DateTime())
            ->setData($data);

        $this->trackingBufferRepository->save($trackingBuffer, $flush);

        $this->observerProvider->dispatch(new TrackingBufferChangedObserverMessage(
            $application->getId(),
            $trackingBuffer->getId(),
            $trackingBuffer->getState(),
            new \DateTime($trackingBuffer->getTimestamp()),
            $trackingBuffer->getData(),
            'new'
        ));
        /*
        $this->hub->publish(new Update('tracking_buffer_changed', json_encode([
            'applicationId' => $application->getId(),
            'trackingBufferId' => $trackingBuffer->getId(),
            'state' => $trackingBuffer->getState(),
            'timestamp' => $trackingBuffer->getTimestamp()->format('Y-m-d H:i:s'),
            'data' => $trackingBuffer->getData(),
            'reason' => 'new',
        ])));*/

        return $this;
    }
}