<?php

namespace Cehlers88\AnalyticsCore\Observer\Message;

class TrackingBufferChangedObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'trackingBuffer.changed';

    public function __construct(
        public int       $applicationId,
        public int       $trackingBufferId,
        public mixed     $state,
        public \DateTime $timestamp,
        public array     $data,
        public string    $reason,
    )
    {
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}