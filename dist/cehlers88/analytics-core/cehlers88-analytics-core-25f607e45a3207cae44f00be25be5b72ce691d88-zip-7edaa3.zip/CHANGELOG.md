# Changelog

## [1.39.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.9...v1.39.0) (2026-06-21)


### Features

* implement configurable CommandDefinitionValidator ([#152](https://github.com/cEhlers88/AnalyticsCore/issues/152)) ([125b454](https://github.com/cEhlers88/AnalyticsCore/commit/125b454ee8ff9fe1ca669395468b05c38164fa20))


### Performance Improvements

* **MacroPlayer:** cache macro lookups, remove debug echo and dead code ([#156](https://github.com/cEhlers88/AnalyticsCore/issues/156)) ([587868a](https://github.com/cEhlers88/AnalyticsCore/commit/587868a56c041424d7bf38c4f3f6e9acacea5768))


### Miscellaneous Chores

* add `AbstractMacro` and `MacroInterface` for defining macros with extension and logging support ([7e68527](https://github.com/cEhlers88/AnalyticsCore/commit/7e685274c36d5838a4486ab0b3927b6ffc4842a5))
* add `AbstractMacroExtension` base class and initial extensions (`JsonEncoder`, `JsonDecoder`, `MailAddressValidator`); update imports to reflect new structure ([84d01e6](https://github.com/cEhlers88/AnalyticsCore/commit/84d01e647f413846df32bd07ae0a1e003953d2dd))
* add `AbstractPropertyHolder` class to `Support` namespace; update imports across affected classes ([74f3824](https://github.com/cEhlers88/AnalyticsCore/commit/74f3824308c56d339da783990d5247a7538e73b3))
* add `ChangeApplicationMacro` with initialization, description, and property support; update DI configuration for macros; adjust project structure for test sources ([22efd00](https://github.com/cEhlers88/AnalyticsCore/commit/22efd009f5b94f033ee82af9bc85356cc53bdf7a))
* add `Documentation` framework with base `AbstractCommandDocumentation` and `DocumentationInterface`; update macros with consistent naming; extend logger with `setPropertyValue` method ([5fff098](https://github.com/cEhlers88/AnalyticsCore/commit/5fff0981c86ee364bf72126a9c276266ad51baaf))
* add `MacroExtensionProvider` to manage macro extensions; update `MacroPlayer` to integrate with the new provider ([c82095b](https://github.com/cEhlers88/AnalyticsCore/commit/c82095bd9fc54ac5121980e960707ca1c702049d))
* add `MacroProtector` framework with `AbstractMacroProtector`, `AllowAllMacroProtector`, and `DemoModeMacroProtector`; update `MacroPlayer` to integrate new protectors ([b0a73a7](https://github.com/cEhlers88/AnalyticsCore/commit/b0a73a7b00fc7c3a412ca3828a09e2cbbdf93bdc))
* add `MenuItemDTO` class to `Support\DTO\UI` namespace; update `AbstractBundlePlugin` to use new class ([db2838c](https://github.com/cEhlers88/AnalyticsCore/commit/db2838c1eef4165902a21f47cc6d05cfabb11aff))
* add `SharedData` and `VariableStore` entities with repositories; update `ConfigurationProvider` and related classes to utilize new implementations ([e608aad](https://github.com/cEhlers88/AnalyticsCore/commit/e608aaddab48215a1d2bc8d5f10c51d3e38e4d37))
* add `StrLowerMacro` to convert string values to lowercase, with initialization, description, and property support ([178009d](https://github.com/cEhlers88/AnalyticsCore/commit/178009d603f5581a5a39db7c5126ed2120999a7a))
* add `StrReplaceMacro` to replace strings with initialization, description, and property support ([7696600](https://github.com/cEhlers88/AnalyticsCore/commit/76966008b0ce310b7f668b7b1bf5f0d723ee6908))
* add `StrUpperMacro` to convert string values to uppercase, with initialization, description, and property support ([0cad1ed](https://github.com/cEhlers88/AnalyticsCore/commit/0cad1ed89e833432e4faf2f6d284d9cab766f737))
* add tests for `StrUpperMacro` and `StrLowerMacro` to validate uppercase and lowercase string transformations ([59488cb](https://github.com/cEhlers88/AnalyticsCore/commit/59488cb6cb7fc2a2032e74ebf6305d5bee81eff3))
* enhance `CommandFactory::evalDefinitionArray` with support for missing command arguments flag and update command name assignment logic ([e403aea](https://github.com/cEhlers88/AnalyticsCore/commit/e403aea8928aa68e9a47dbf7b69757aef915d006))
* implement `MacroExtensionInterface` and `MacroProtectorInterface`; update abstract classes to use interfaces and configure service definitions for DI ([10ca461](https://github.com/cEhlers88/AnalyticsCore/commit/10ca461e613a2f35515a2c26c79fdfc8f92063a1))
* implement `SilentDebugger` and `DevDebugger` for macro debugging; introduce `IMacroDebugger` interface and update `MacroEnvironment` and `CommandPlayer` configuration ([c7173a0](https://github.com/cEhlers88/AnalyticsCore/commit/c7173a0e1e1e368a6a93ca0fc0a31845ecc38bd1))
* introduce `MacroEnvironment` and `CommandPlayer` to manage and execute macro workflows, update affected classes and tests ([ef85dc7](https://github.com/cEhlers88/AnalyticsCore/commit/ef85dc78b0d1a1b4d84605cddfc08af54064ec0e))
* introduce `MacroPlayer` to centralize macro execution and management; adjust imports across affected classes ([7a7f043](https://github.com/cEhlers88/AnalyticsCore/commit/7a7f043064b4038c65e3eb45b5e1015e8eba156c))
* introduce `VariablesProvider`, update affected classes to utilize the new provider for variable management and context loading ([fa72b5a](https://github.com/cEhlers88/AnalyticsCore/commit/fa72b5ab21af57ce31035086966311105dd2adeb))
* move `DTO` base class to `Support` namespace; update imports across all affected DTO classes ([2976e10](https://github.com/cEhlers88/AnalyticsCore/commit/2976e1017f767f12a71ae07f88892aa3a5660a2d))
* move `eMacroVariableContext` to `Macro\ENUM`; update imports and implement `fromString` helper ([ddfa71e](https://github.com/cEhlers88/AnalyticsCore/commit/ddfa71ec496c9dcff0b098d7bb88f5d20d9f5d5f))
* optimize `CommandFactory` by adding command register for faster lookup and initializing it on construction ([352c997](https://github.com/cEhlers88/AnalyticsCore/commit/352c997d7cc5d6d70cef3dac5d6390d439878b29))
* refactor imports to consistently use `Cehlers88\AnalyticsCore` namespace; add `eConditionType`, `eSelfCheckResult`, and `eInstructionType` enums for standardized type management ([826fd6b](https://github.com/cEhlers88/AnalyticsCore/commit/826fd6b4092cd8298a3eb5ebe59c3f213378adeb))
* rename `CurlExecutor` to `CurlHelper` for improved context clarity ([d9d4091](https://github.com/cEhlers88/AnalyticsCore/commit/d9d409107427bf8c16fbabfadd0b890e3a6900de))
* replace `ConditionGroupDTO` reference with `Cehlers88\AnalyticsCore\DTO\ConditionGroupDTO`; add new `ConditionGroupDTO` implementation and update imports across classes ([2e76e34](https://github.com/cEhlers88/AnalyticsCore/commit/2e76e344c37746bd53361a687c49360f80b41bac))
* replace `IBundlePlugin` with `BundlePluginInterface`; create new interface and update affected classes ([d787653](https://github.com/cEhlers88/AnalyticsCore/commit/d787653594a190e3b5f32c15937c83206c3b2e80))
* update `AnalyticsCore` to extend `AbstractBundlePlugin` instead of `AbstractBundlePluginInterface` for consistency ([17b7aca](https://github.com/cEhlers88/AnalyticsCore/commit/17b7aca06564088a98712d61558880d441faa199))
* Use CommandDefinitionValidator in CommandFactory for command definition validation ([#155](https://github.com/cEhlers88/AnalyticsCore/issues/155)) ([81d4c6e](https://github.com/cEhlers88/AnalyticsCore/commit/81d4c6ea04a867d303b91eb983a6ff4eb7db90b5))

## [1.38.9](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.8...v1.38.9) (2026-06-15)


### Miscellaneous Chores

* make `AbstractEndpointEntity` an abstract class ([3069d18](https://github.com/cEhlers88/AnalyticsCore/commit/3069d18acef395d2641de17de9712c0f4d2b7f25))

## [1.38.8](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.7...v1.38.8) (2026-06-14)


### Miscellaneous Chores

* introduce new logging framework with multiple logger implementations, support for grouped logging, and enhanced configuration options ([af4b8d0](https://github.com/cEhlers88/AnalyticsCore/commit/af4b8d0245f5b24ba591999d7586662904e24889))
* Refactor styles and enhance CompositeLogger functionality ([abbcb38](https://github.com/cEhlers88/AnalyticsCore/commit/abbcb388f77547e70aada72e83aa73fce936945f))

## [1.38.7](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.6...v1.38.7) (2026-06-14)


### Miscellaneous Chores

* add `CurlExecutor` for HTTP requests and introduce `CurlResponseDTO` for response handling, enhance `AbstractExecutor` with `lastResult` tracking ([a0ecc8e](https://github.com/cEhlers88/AnalyticsCore/commit/a0ecc8e1a0e44f5ac26633f699267d8e408d922c))

## [1.38.6](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.5...v1.38.6) (2026-06-13)


### Bug Fixes

* correct parameter mapping in `ConfigurationProvider::buildBufferItem` method ([91a463c](https://github.com/cEhlers88/AnalyticsCore/commit/91a463cf1e33e201971ae9bcfc01d265e0b38b84))
* update input type handling in `ConfigurationProvider` to support password fields ([32a1cbd](https://github.com/cEhlers88/AnalyticsCore/commit/32a1cbdfb73e426a44dc07e548342ec7c5187986))


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.2.0 ([#143](https://github.com/cEhlers88/AnalyticsCore/issues/143)) ([15cf59a](https://github.com/cEhlers88/AnalyticsCore/commit/15cf59a5c3357df0d07b3ed26eaf8d70f21ebdae))
* enhance `CommandFactory` and `ProcessProvider` for improved command processing and method formatting ([dcca133](https://github.com/cEhlers88/AnalyticsCore/commit/dcca133f6ddb367ce9aaf71628f71aaa805344d5))

## [1.38.5](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.4...v1.38.5) (2026-05-25)


### Miscellaneous Chores

* update namespaces and service tags in `CheckIsFirstVisitJob` and `services.yaml` ([265b03d](https://github.com/cEhlers88/AnalyticsCore/commit/265b03d9781587432f7dbfda00afa23d84b691b5))

## [1.38.4](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.3...v1.38.4) (2026-05-25)


### Miscellaneous Chores

* add `SetTrackingBuffersStateToProcessedFinishedJob` to modify TrackingBuffer states ([62f5f07](https://github.com/cEhlers88/AnalyticsCore/commit/62f5f07baf4beb4fb3fa916b7a0d3256341490ee))
* refactor `CustomObjectProvider` to improve handling of parent-child relationships and update `AbstractCustomObject` with parent ID methods ([1b76301](https://github.com/cEhlers88/AnalyticsCore/commit/1b763018897b9d7c93d5b056ed73d9fc734ec6cb))
* simplify `CustomObjectProvider` by removing unused parent-child resolution logic and update `AbstractCustomObject` to eliminate child object handling ([925c7e2](https://github.com/cEhlers88/AnalyticsCore/commit/925c7e22229f512bb59b369d9171200d2899eb0a))

## [1.38.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.2...v1.38.3) (2026-05-25)


### Bug Fixes

* remove redundant `parent::__construct` call from `AbstractTaggedEntity` ([6751396](https://github.com/cEhlers88/AnalyticsCore/commit/6751396b3c07f541e09cf719a16e2c6c4a89960a))

## [1.38.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.1...v1.38.2) (2026-05-24)


### Miscellaneous Chores

* add `createdAt` timestamp and update `modifiedAt` handling in `CustomObjectProvider` ([ba8ec40](https://github.com/cEhlers88/AnalyticsCore/commit/ba8ec407b575996bf66e35de98ee8306d37a8ea9))
* add `NotificationChannel` entity and repository ([ceb0332](https://github.com/cEhlers88/AnalyticsCore/commit/ceb03324cde02fdb79efa25b4555fbb1608a726d))
* add `requiredPermissions` field to `NotificationChannel` entity ([9fced8e](https://github.com/cEhlers88/AnalyticsCore/commit/9fced8e45c6d1a50f3c7154cf197893faea17657))
* add `WorkerJobOptionsRepository` extending `AbstractRepository` ([788a79b](https://github.com/cEhlers88/AnalyticsCore/commit/788a79b06466868fc8aa8ce1133cb2855ad3406a))
* **deps:** update dependency phpunit/phpunit to v13.1.11 ([#139](https://github.com/cEhlers88/AnalyticsCore/issues/139)) ([cf5af17](https://github.com/cEhlers88/AnalyticsCore/commit/cf5af170bd240611a3e6f97b2e820a403f081f35))
* extend entities to `AbstractTaggedEntity` and update `User` entity with notification channels ([4a72d94](https://github.com/cEhlers88/AnalyticsCore/commit/4a72d944150ffd2dc792991ea47ea7ef4b1b10ad))
* extract tag management to `AbstractTaggedEntity` ([c2de75a](https://github.com/cEhlers88/AnalyticsCore/commit/c2de75acb76232260efeba93d5b6b57eb6b9691b))
* set `modifiedAt` timestamp when saving custom entities in `CustomObjectProvider` ([416cbe8](https://github.com/cEhlers88/AnalyticsCore/commit/416cbe8a51cde84876364471c2fcf0ccb421b5aa))

## [1.38.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.0...v1.38.1) (2026-05-17)


### Miscellaneous Chores

* add `findAttributeNamesByClass` method to `CustomEntityRepository` ([a541d1b](https://github.com/cEhlers88/AnalyticsCore/commit/a541d1bc44b6d3021ffd2cc318012116d54c409b))
* add `getAttributesOfCustomEntityClass` method to `CustomObjectProvider` ([7879a64](https://github.com/cEhlers88/AnalyticsCore/commit/7879a64285b560431adf713a5cda86e02f1f1b95))
* add `setAttributes` and `removeAttribute` methods to `AbstractCustomObject` ([a5d821c](https://github.com/cEhlers88/AnalyticsCore/commit/a5d821c644e1c273d63d78a2fe9fef2314bac890))
* extend `CustomObjectInterface` with attribute management methods ([ff50601](https://github.com/cEhlers88/AnalyticsCore/commit/ff50601f92fb19b73312e018e00e980fbaa21c28))

## [1.38.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.37.1...v1.38.0) (2026-05-17)


### Features

* add `MacroEnvironmentDTO`, `MacroProtectorResultDTO`, and `MacroPropertyDTO` classes ([b91d09a](https://github.com/cEhlers88/AnalyticsCore/commit/b91d09aa9de86f8930e775af5c9fdd5cb9a1bce4))
* introduce `CommandDTO` classes for command management ([9065491](https://github.com/cEhlers88/AnalyticsCore/commit/9065491e590ec539222900701218273b319327a2))
* introduce `CommandFactory` for streamlined command management ([b413011](https://github.com/cEhlers88/AnalyticsCore/commit/b413011cab1e0060d5543d57ad8ac8968f8b33f2))


### Miscellaneous Chores

* remove unused `CommandPropertyDTO` class ([04ab43a](https://github.com/cEhlers88/AnalyticsCore/commit/04ab43ac878ee9b9faf0b8a17f017b119eee00eb))
* replace `Analytics\DTO\PropertyDTO` with `Cehlers88\AnalyticsCore\DTO\PropertyDTO` ([55f3aaf](https://github.com/cEhlers88/AnalyticsCore/commit/55f3aaf7ab3a9b1b70f196cc4c59f2d6e1a825e8))
* update `CommandDTO` to replace `CommandPropertyDTO` with `PropertyDTO` ([3597ce5](https://github.com/cEhlers88/AnalyticsCore/commit/3597ce593e3a85603d517fdec5ede21eb32ae394))

## [1.37.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.37.0...v1.37.1) (2026-05-17)


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.10 ([#130](https://github.com/cEhlers88/AnalyticsCore/issues/130)) ([5d01362](https://github.com/cEhlers88/AnalyticsCore/commit/5d013629f25d4bbf5aa4bfd88a86e84e4ee0d436))
* extend `TrackingBufferAssembler` to handle `TemporaryTrackingBuffer` entities ([8186a2b](https://github.com/cEhlers88/AnalyticsCore/commit/8186a2b0bf339e262b375cf03423bf0a04c3f26d))

## [1.37.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.36.0...v1.37.0) (2026-05-16)


### Features

* add `parentId` support to `CustomObject` and `CustomObjectProvider` ([88d05e3](https://github.com/cEhlers88/AnalyticsCore/commit/88d05e3c3bb9a00201b8c87f29a96985211e1daf))

## [1.36.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.35.0...v1.36.0) (2026-05-16)


### Features

* enhance `CustomObject` and `TrackingBuffer` with new properties and methods ([b480b70](https://github.com/cEhlers88/AnalyticsCore/commit/b480b70fa7ddd7651f50d317ecd258d4773d09ed))


### Bug Fixes

* use `setAttributeValue` in `CustomObjectProvider` for consistent attribute updates ([cd793fc](https://github.com/cEhlers88/AnalyticsCore/commit/cd793fcf880b908e95c0ffc133366fc000eb1761))

## [1.35.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.34.0...v1.35.0) (2026-05-16)


### Features

* enhance `CustomObjectProvider` with flexible filtering, entity saving, and attribute management ([3ab583a](https://github.com/cEhlers88/AnalyticsCore/commit/3ab583a5bd9a8a45a258a5b7097a186410d7f828))

## [1.34.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.33.0...v1.34.0) (2026-05-16)


### Features

* add `handlerData` support to `TrackingRecorder` and improve documentation ([bcf1b45](https://github.com/cEhlers88/AnalyticsCore/commit/bcf1b45e07db61e626207076cc70960a4f983f02))

## [1.33.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.32.0...v1.33.0) (2026-05-14)


### Features

* add support for rerun behavior in `AbstractExecutor` and track `INTERACTION_REQUIRED` state in `eTrackingBufferState` ([a46a993](https://github.com/cEhlers88/AnalyticsCore/commit/a46a9936e3d5dbe1125353217709346825dc5ea2))

## [1.32.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.31.0...v1.32.0) (2026-05-14)


### Features

* add `wantsToReRun` method to `ExecutorInterface` ([cc33a9d](https://github.com/cEhlers88/AnalyticsCore/commit/cc33a9d754aa927159b2a8cd5d889ed36507adfa))


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.9 ([#126](https://github.com/cEhlers88/AnalyticsCore/issues/126)) ([f565375](https://github.com/cEhlers88/AnalyticsCore/commit/f5653754a390bc286ee383c0658f0acf89e04974))

## [1.31.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.30.0...v1.31.0) (2026-05-14)


### Features

* add `wantToReRun` methods in `WorkerInterface` ([d9588dd](https://github.com/cEhlers88/AnalyticsCore/commit/d9588dd956d4aff6115a5b31991eefdec9843c6d))


### Miscellaneous Chores

* refactor: reorder `AbstractWorkerJob` properties for consistency ([4f7377b](https://github.com/cEhlers88/AnalyticsCore/commit/4f7377b25587f8c1b3248235fa14c7270a268225))
* reorganize `SharedDataStoreTest` and update `WorkerInterface` stub ([ba98b09](https://github.com/cEhlers88/AnalyticsCore/commit/ba98b091e292f54f082003c7ca3ae98d14711417))

## [1.30.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.29.0...v1.30.0) (2026-05-10)


### Features

* add `wantToReRun` flag and related methods in `AbstractWorker` ([dcaeb0e](https://github.com/cEhlers88/AnalyticsCore/commit/dcaeb0ea8fd658ea6528fa8dec0f7a8b35afefee))

## [1.29.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.5...v1.29.0) (2026-05-09)


### Features

* add `ApiEntityProviderResultDTO` for handling API entity provider results ([d76c35d](https://github.com/cEhlers88/AnalyticsCore/commit/d76c35dc44e59aaa1207bdd30c7fe02b4cc06589))
* add `ApiLazyLoadEntityDTO` for managing lazy-loaded API entity relationships ([fecd10c](https://github.com/cEhlers88/AnalyticsCore/commit/fecd10c9cbba485a6509187f9706914f7518956e))

## [1.28.5](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.4...v1.28.5) (2026-05-03)


### Miscellaneous Chores

* add `getInfosArray` method to `ClientDetails` entity for decoding `infos` field as an array ([7f3b60f](https://github.com/cEhlers88/AnalyticsCore/commit/7f3b60fa283958e1e1df3a6361ece8518d252381))

## [1.28.4](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.3...v1.28.4) (2026-05-03)


### Miscellaneous Chores

* update namespace in `Client` entity for consistency with project structure ([ed356b3](https://github.com/cEhlers88/AnalyticsCore/commit/ed356b34850b7ca3c0a2f3b2995123d7ef839d1e))

## [1.28.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.2...v1.28.3) (2026-05-03)


### Miscellaneous Chores

* update `TrackingRecorder` and `TrackingBufferChangedObserverMessage` to simplify timestamp handling ([69393e0](https://github.com/cEhlers88/AnalyticsCore/commit/69393e09c82ef46f72a9845ea8521090d7ffe919))

## [1.28.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.1...v1.28.2) (2026-05-03)


### Miscellaneous Chores

* update namespace in `CaptureEventRecorder` for consistency with project structure ([ad5fc8a](https://github.com/cEhlers88/AnalyticsCore/commit/ad5fc8a98cca3196d2551608275766f7aef4c064))

## [1.28.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.0...v1.28.1) (2026-05-03)


### Miscellaneous Chores

* extend `TrackingRecorder` to support temporary tracking buffers and improve buffer handling ([62c1398](https://github.com/cEhlers88/AnalyticsCore/commit/62c1398a65bfe9d5a0c4868d0898bb614dfdca2e))

## [1.28.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.27.0...v1.28.0) (2026-05-03)


### Features

* add `CaptureEventRecorder` and `RecorderResultDTO` for event processing and result handling ([e216901](https://github.com/cEhlers88/AnalyticsCore/commit/e216901766d41ffca4774eb8ebc41f522c23c47a))

## [1.27.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.26.0...v1.27.0) (2026-05-03)


### Features

* add `TrackingRecorder` class and `TrackingBufferChangedObserverMessage` for improved buffer tracking and observer notifications ([445c1b4](https://github.com/cEhlers88/AnalyticsCore/commit/445c1b47c86ebfbb1b08f0e5c0d363b500f967b9))

## [1.26.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.25.1...v1.26.0) (2026-05-03)


### Features

* extract common data properties into `AbstractTrackingBuffer` and introduce `TemporaryTrackingBuffer` entity with repository ([e06d169](https://github.com/cEhlers88/AnalyticsCore/commit/e06d1698245f88be8830283015ca207ea6b3a2b6))

## [1.25.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.25.0...v1.25.1) (2026-05-03)


### Miscellaneous Chores

* update `composer.json` to adjust `dev-main` branch alias ([286ea26](https://github.com/cEhlers88/AnalyticsCore/commit/286ea26cbe6a54a00e3a16d59532cf5553556b47))

## [1.25.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.24.0...v1.25.0) (2026-05-03)


### Features

* Enhance `HandleClientUpdateServiceEndpointRunner` to handle `cast_info` client details update logic ([7a849d9](https://github.com/cEhlers88/AnalyticsCore/commit/7a849d9848c2e2fd691b5dac35084663fde1f030))

## [1.24.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.23.1...v1.24.0) (2026-05-03)


### Features

* add `adminNote` to `User` entity and enhance endpoint runner error handling ([c749a2f](https://github.com/cEhlers88/AnalyticsCore/commit/c749a2fb8043d5afed1ba84cade7cd63e526e967))

## [1.23.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.23.0...v1.23.1) (2026-05-03)


### Miscellaneous Chores

* rename `IServiceEndpointRunner` to `ServiceEndpointRunnerInterface` and update references ([65fa699](https://github.com/cEhlers88/AnalyticsCore/commit/65fa69955d7bb9d546d50fdaeacb6fe49c9bae3b))

## [1.23.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.22.1...v1.23.0) (2026-05-03)


### Features

* introduce `ServiceEndpointRunner` architecture for endpoint handling ([7aaf5ae](https://github.com/cEhlers88/AnalyticsCore/commit/7aaf5ae1e7e9f73fb5214ee815fb08fb9a7e6fa7))


### Miscellaneous Chores

* add `getJsonDefinition` method in `TrackingBufferView` for JSON data representation ([482af24](https://github.com/cEhlers88/AnalyticsCore/commit/482af2494038e5de45822f7c829bbc5ac8f4875d))

## [1.22.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.22.0...v1.22.1) (2026-05-02)


### Miscellaneous Chores

* update namespaces and code formatting in `ServerSideRenderer` classes ([2d1f85e](https://github.com/cEhlers88/AnalyticsCore/commit/2d1f85eba04136b9e7fb114eccbff18c831cb8cd))

## [1.22.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.21.3...v1.22.0) (2026-05-02)


### Features

* introduce `ServerSideRenderer` architecture for server-side rendering ([b8152a2](https://github.com/cEhlers88/AnalyticsCore/commit/b8152a20559c245fa3e4c069184f4f8cdbce2fba))


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.8 ([#108](https://github.com/cEhlers88/AnalyticsCore/issues/108)) ([dea7652](https://github.com/cEhlers88/AnalyticsCore/commit/dea7652a6120fb7fef3bbcbe6fc9b89a1506fd42))

## [1.21.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.21.2...v1.21.3) (2026-05-01)


### Miscellaneous Chores

* add `LoginObserverMessage` for user login event handling ([71cad26](https://github.com/cEhlers88/AnalyticsCore/commit/71cad265b27ea82e59f2fd6588746b8dce0c9b46))

## [1.21.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.21.1...v1.21.2) (2026-04-29)


### Miscellaneous Chores

* add `data` property to `SystemUpdateObserverMessage` for enhanced message context ([1ba53e1](https://github.com/cEhlers88/AnalyticsCore/commit/1ba53e174b39c11c3fad2fd1f1bdd6fea80408dd))

## [1.21.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.21.0...v1.21.1) (2026-04-29)


### Miscellaneous Chores

* add `SystemUpdateObserverMessage` and enhance observer messages ([ee419c2](https://github.com/cEhlers88/AnalyticsCore/commit/ee419c2f3b9ea03907c2543840d8575f58e26dcd))

## [1.21.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.20.0...v1.21.0) (2026-04-26)


### Features

* add `ConfigurationUpdateDTO` and enhance configuration handling ([9788925](https://github.com/cEhlers88/AnalyticsCore/commit/9788925d14641395ae89ef1f2c754740427a9816))


### Miscellaneous Chores

* **deps:** update googleapis/release-please-action action to v5 ([#101](https://github.com/cEhlers88/AnalyticsCore/issues/101)) ([0fff693](https://github.com/cEhlers88/AnalyticsCore/commit/0fff693d913e1c3c1cecf9ce6c7ae6cc76eb70a5))

## [1.20.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.19.0...v1.20.0) (2026-04-21)


### Features

* ensure `setPropertyValue` adds new properties if not existing ([3e7a2f3](https://github.com/cEhlers88/AnalyticsCore/commit/3e7a2f30eed76410743a90bd90b6880cbe85c667))

## [1.19.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.18.2...v1.19.0) (2026-04-21)


### Features

* add `setPropertyValue` method in `Worker` for dynamic property updates ([11a22d3](https://github.com/cEhlers88/AnalyticsCore/commit/11a22d3791137218bddbb11a406ae7fa651e0181))

## [1.18.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.18.1...v1.18.2) (2026-04-20)


### Miscellaneous Chores

* replace `maxRuntime` property in `Worker` with `getMaxRuntime` method ([1809e1e](https://github.com/cEhlers88/AnalyticsCore/commit/1809e1ecdc96da8f20c16de61649982894e3f1ab))

## [1.18.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.18.0...v1.18.1) (2026-04-20)


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.7 ([#84](https://github.com/cEhlers88/AnalyticsCore/issues/84)) ([c8612cf](https://github.com/cEhlers88/AnalyticsCore/commit/c8612cf8350fc091b136fad6f52d7f0ddbbda2c2))

## [1.18.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.17.0...v1.18.0) (2026-04-19)


### Features

* add `FatalError` state in `BadgeProvider` and refine worker store handling ([181957d](https://github.com/cEhlers88/AnalyticsCore/commit/181957d46d067feb771f8e88f1731bf45ca441ba))

## [1.17.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.16.1...v1.17.0) (2026-04-19)


### Features

* introduce new plugins, workers, and DTOs while enhancing process handling ([dbbec2f](https://github.com/cEhlers88/AnalyticsCore/commit/dbbec2f01420cac4eb034b55d6a80687bd93eb6d))

## [1.16.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.16.0...v1.16.1) (2026-04-14)


### Performance Improvements

* add Doctrine index for `TrackingBuffer.timestamp` ([#89](https://github.com/cEhlers88/AnalyticsCore/issues/89)) ([145b18d](https://github.com/cEhlers88/AnalyticsCore/commit/145b18df6e6e8d022560930ca5158a0d6b24fcf3))

## [1.16.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.15.0...v1.16.0) (2026-04-13)


### Features

* Add temporary shared data store to AbstractWorker and WorkerInterface ([#86](https://github.com/cEhlers88/AnalyticsCore/issues/86)) ([97aead1](https://github.com/cEhlers88/AnalyticsCore/commit/97aead1a84960e973d45741016989bfbd9916599))

## [1.15.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.14.0...v1.15.0) (2026-04-12)


### Features

* enhance worker-job interaction and introduce new workers ([3554250](https://github.com/cEhlers88/AnalyticsCore/commit/3554250f310bc9dab047d0112136d6c784338af6))

## [1.14.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.13.0...v1.14.0) (2026-04-11)


### Features

* add `getKeyValue` method in `TrackingBuffer` for key-value retrieval ([4352fc9](https://github.com/cEhlers88/AnalyticsCore/commit/4352fc9a7040c953b3d7a7d1058e8e39bbeb948f))

## [1.13.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.12.0...v1.13.0) (2026-04-10)


### Features

* add source file modification time caching in `AbstractWorkerJob` ([422824d](https://github.com/cEhlers88/AnalyticsCore/commit/422824d979461bda30bdf34748fda642edc9a691))

## [1.12.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.11.0...v1.12.0) (2026-04-06)


### Features

* extend `BadgeProvider` with additional states and update visual styles ([ab4d8c8](https://github.com/cEhlers88/AnalyticsCore/commit/ab4d8c864b094e892150b6545e680f3a241ef1b8))


### Bug Fixes

* refine `QuickStatusInfoDTO` state handling in `AbstractRunnableEntity` ([8c1cc33](https://github.com/cEhlers88/AnalyticsCore/commit/8c1cc33d21ee6f7bead400e84dd7e73f3a3e00c1))

## [1.11.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.10.1...v1.11.0) (2026-04-06)


### Features

* add `ApplicationConfigurationGroup` for managing application settings ([2c5f309](https://github.com/cEhlers88/AnalyticsCore/commit/2c5f3098622f3ef25fa24c2c074d86d4058559c7))


### Miscellaneous Chores

* remove unused `state` configuration item in `ApplicationConfigurationGroup` ([465cd8d](https://github.com/cEhlers88/AnalyticsCore/commit/465cd8d9f3b9d56e5d36acd3fca91e37c7914e45))

## [1.10.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.10.0...v1.10.1) (2026-04-06)


### Bug Fixes

* improve warning message for unknown job type in `AbstractWorker` ([4c12b3f](https://github.com/cEhlers88/AnalyticsCore/commit/4c12b3fb0e261f6a37246a5656983533ed204352))

## [1.10.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.9.0...v1.10.0) (2026-04-06)


### Features

* enhance custom entity resolution logic and improve state handling ([b9f84f9](https://github.com/cEhlers88/AnalyticsCore/commit/b9f84f9f49a795c188b3160dd1c95a4c818d7ce8))
* update `WorkerResultDTO` error handling to support arrays ([a99b2cd](https://github.com/cEhlers88/AnalyticsCore/commit/a99b2cd2bd2ef98a51dfd909d5c0059578b8b52b))

## [1.9.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.8.0...v1.9.0) (2026-04-05)


### Features

* add `parentId` property to `CustomEntity` with getter and setter methods ([386cc6c](https://github.com/cEhlers88/AnalyticsCore/commit/386cc6ccbc69fffd0b5bbd12638f39d8662a6a13))

## [1.8.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.7.0...v1.8.0) (2026-04-05)


### Features

* add warning state and enhance warning handling in `AbstractWorker` ([d63a6cc](https://github.com/cEhlers88/AnalyticsCore/commit/d63a6cc7d5c4c9a9d470fbbbad55b69b9334d20a))

## [1.7.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.6.0...v1.7.0) (2026-04-05)


### Features

* add `DomElementPropsDTO` and `AbstractInputRenderer` for input rendering and DOM definition handling ([347b785](https://github.com/cEhlers88/AnalyticsCore/commit/347b78582689836c53497bb9465a41133324df6c))
* refactor `ConfigurationProvider` with autoload toggle, enhanced buffer handling, and constant grouping logic ([fbef09b](https://github.com/cEhlers88/AnalyticsCore/commit/fbef09b82e96d54e7197289cea90633710fd2634))


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.0 ([#71](https://github.com/cEhlers88/AnalyticsCore/issues/71)) ([ea28b56](https://github.com/cEhlers88/AnalyticsCore/commit/ea28b56177d222ec9863a49d974a80e451f7444c))

## [1.6.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.5.0...v1.6.0) (2026-03-29)


### Features

* add `getResultWorkers` method to `ProcessResultWorkerProvider` to expose result worker collection ([5bbd8d1](https://github.com/cEhlers88/AnalyticsCore/commit/5bbd8d190b348d591f84e67c2ad5a806ad73377d))

## [1.5.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.4.1...v1.5.0) (2026-03-29)


### Features

* enhance process runner framework with result handling logic and configuration updates ([95435c9](https://github.com/cEhlers88/AnalyticsCore/commit/95435c9c7a32ef940abadcdcdf32cbb2f0c62933))
* update process runner and state management logic ([6dacfee](https://github.com/cEhlers88/AnalyticsCore/commit/6dacfeee3bb8addc89000fd0c542f8b8b6927afe))

## [1.4.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.4.0...v1.4.1) (2026-03-29)


### Miscellaneous Chores

* improve `AbstractExecutor` and `AbstractWorker` handling, add `isDisabled` method, enhance type hints and repository usage, and refactor worker result logic ([04b1daa](https://github.com/cEhlers88/AnalyticsCore/commit/04b1daae5f934fd1f245922602b235eb6e21fce3))
* refactor `RunChainView` constructor to `loadByRunChain` for improved usability and streamline entity handling ([2141fba](https://github.com/cEhlers88/AnalyticsCore/commit/2141fbae4420b220374c5c04cd06825e26daad88))

## [1.4.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.13...v1.4.0) (2026-03-27)


### Features

* add `QuickActionDTO` for representing quick action attributes ([2b04ed6](https://github.com/cEhlers88/AnalyticsCore/commit/2b04ed6c06f7fa1c1a125fe4a9ae0bc17803f4db))


### Miscellaneous Chores

* refactor `RunChainAssemblerTest` to improve structure and add createdAt mock setup ([4620928](https://github.com/cEhlers88/AnalyticsCore/commit/46209282dd5384662037e279c8c346152f58d45d))
* rename `one` to `assembleView` in assembler classes for improved clarity and consistency ([c1b0f55](https://github.com/cEhlers88/AnalyticsCore/commit/c1b0f55ece8f70b92e60e530860a3d4e35535f5f))

## [1.3.13](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.12...v1.3.13) (2026-03-26)


### Miscellaneous Chores

* enhance error handling in `AbstractWorker` by logging fatal errors to `TrackingBuffer` ([84e9917](https://github.com/cEhlers88/AnalyticsCore/commit/84e991785f70aa62686a8800a61451aaba8dd3c4))

## [1.3.12](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.11...v1.3.12) (2026-03-26)


### Miscellaneous Chores

* integrate `TrackingBufferRepository` into `WorkerProvider` and `AbstractWorker` for enhanced repository handling ([efcdee9](https://github.com/cEhlers88/AnalyticsCore/commit/efcdee9cda4563e3299d222717dfc084e580ed68))

## [1.3.11](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.10...v1.3.11) (2026-03-26)


### Miscellaneous Chores

* refactor error handling and status generation in core components ([dd638f6](https://github.com/cEhlers88/AnalyticsCore/commit/dd638f68e9603c95a9e91307dee10e517f80fb25))

## [1.3.10](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.9...v1.3.10) (2026-03-25)


### Miscellaneous Chores

* remove unused imports and logging methods, enhance property loading in worker classes ([dbce940](https://github.com/cEhlers88/AnalyticsCore/commit/dbce940860baf7985b6805d7b3aeff7fa8744e22))

## [1.3.9](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.8...v1.3.9) (2026-03-25)


### Miscellaneous Chores

* add `TrackingBufferView` and `TrackingBufferAssembler` for front-end representation and entity handling ([a648e4b](https://github.com/cEhlers88/AnalyticsCore/commit/a648e4b0e1fae933e98b98277f63ceb11d3ec77f))
* add `UserView` and `UserAssembler` for front-end representation, implement `EntityInterface` in `User` entity ([ed280aa](https://github.com/cEhlers88/AnalyticsCore/commit/ed280aae672908e1e9a245f2695cd628caeb337f))

## [1.3.8](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.7...v1.3.8) (2026-03-24)


### Miscellaneous Chores

* update `setAttribute` method to return `static` for improved chaining support ([a9dbbe7](https://github.com/cEhlers88/AnalyticsCore/commit/a9dbbe7660d06663b603483ee7efcd44600b9b50))

## [1.3.7](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.6...v1.3.7) (2026-03-24)


### Miscellaneous Chores

* replace `setId` with `load` in `CustomObjectInterface`, streamline attribute initialization ([38a93f0](https://github.com/cEhlers88/AnalyticsCore/commit/38a93f0cd97488d72c8df6c7859d94d28c1e9cc6))

## [1.3.6](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.5...v1.3.6) (2026-03-23)


### Miscellaneous Chores

* add `NORMALIZED` state to `eTrackingBufferState` enum ([523067c](https://github.com/cEhlers88/AnalyticsCore/commit/523067cea1fc797704c5c4112d7794c39b5fb6e7))

## [1.3.5](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.4...v1.3.5) (2026-03-23)


### Miscellaneous Chores

* remove deprecated frontend assemblers and views, add `configure` method to `AbstractAssembler` and `AssemblerInterface` ([c92d082](https://github.com/cEhlers88/AnalyticsCore/commit/c92d082c0e38bfe6c16283eba1190417c1a8f833))

## [1.3.4](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.3...v1.3.4) (2026-03-23)


### Bug Fixes

* update `filters` field in `TrackingBuffer` entity to use `TEXT` type for better compatibility ([0b4e440](https://github.com/cEhlers88/AnalyticsCore/commit/0b4e440ab506bf218d229135c5b4a5d19a548d12))


### Miscellaneous Chores

* remove deprecated `TrackingBuffer` assembler and view, introduce `AssemblerProvider` with `canHandle` support for improved entity-assembler handling ([781e19f](https://github.com/cEhlers88/AnalyticsCore/commit/781e19febe15b9e2581172bbf22b4eae3b1ee94b))

## [1.3.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.2...v1.3.3) (2026-03-23)


### Miscellaneous Chores

* add `color` property to `ApplicationView` and `ApplicationAssembler`, introduce `filters` field and indexing in `TrackingBuffer` entity ([3941987](https://github.com/cEhlers88/AnalyticsCore/commit/3941987e7366f78108c640dabe433c06595f136b))

## [1.3.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.1...v1.3.2) (2026-03-23)


### Bug Fixes

* update `TrackingBufferView` to use `eTrackingBufferState` instead of `eRunningState`, align with state changes ([a5d6189](https://github.com/cEhlers88/AnalyticsCore/commit/a5d61893da3435085ac907808ea892083719adf2))

## [1.3.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.0...v1.3.1) (2026-03-23)


### Bug Fixes

* update `TrackingBuffer` assembler and view to use `eRunningState`, refactor state handling for consistency ([5a76a35](https://github.com/cEhlers88/AnalyticsCore/commit/5a76a35ba12c64dad9a1437cbf99761208e0fb4b))

## [1.3.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.2.0...v1.3.0) (2026-03-23)


### Features

* add `TrackingBuffer` assembler and view, enhance `QuickStatusInfoProvider` with detailed states, and refactor deprecated method in `TrackingBuffer` entity ([fefdd41](https://github.com/cEhlers88/AnalyticsCore/commit/fefdd4153c9fe08ed7f8a57d7892ee3ba97dfaff))

## [1.2.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.3...v1.2.0) (2026-03-23)


### Features

* set badge label and CSS class in `ApplicationView` constructor ([75df4a3](https://github.com/cEhlers88/AnalyticsCore/commit/75df4a391519c35919bb4483c9b58734abb4298f))

## [1.1.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.2...v1.1.3) (2026-03-22)


### Bug Fixes

* handle potential null `process` in `CurlRequestProcessRunner`, refine `AbstractProcessResultWorker` process management logic ([66c2947](https://github.com/cEhlers88/AnalyticsCore/commit/66c2947a33f9e891d63191692686577980b82986))

## [1.1.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.1...v1.1.2) (2026-03-22)


### Bug Fixes

* add error handling in `ProcessProvider` to log exceptions and update process state ([ce9f2e1](https://github.com/cEhlers88/AnalyticsCore/commit/ce9f2e17a6a5eb2a32e87e73ec48f1144b576d8d))

## [1.1.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.0...v1.1.1) (2026-03-22)


### Bug Fixes

* add `statusCode` and `runner` handling in `AbstractProcessResultWorker`, minor format fix in `ModifyTrackingBufferResultWorker` ([a3c47a0](https://github.com/cEhlers88/AnalyticsCore/commit/a3c47a057d8f72fd7475a784da05cf50bb0174ae))

## [1.1.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.0.0...v1.1.0) (2026-03-22)


### Features

* add `ProcessResultWorkerProvider` for managing result workers and refine state handling in `AbstractProcessResultWorker` ([1c4a77b](https://github.com/cEhlers88/AnalyticsCore/commit/1c4a77b8980ed1715af408ad59fe737bb1c9bc6c))
* extend `ProcessRunnerInterface` and `ProcessResultWorkerInterface` with result handling methods, implement enhanced runner-worker integration in `ProcessProvider` ([ea75a12](https://github.com/cEhlers88/AnalyticsCore/commit/ea75a12ac31ae77c6ad38740501677c167214296))

## [1.0.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.11...v1.0.0) (2026-03-22)


### ⚠ BREAKING CHANGES

* add debug mode with optional process logging in `ProcessProvider`

### Features

* add debug mode with optional process logging in `ProcessProvider` ([b03320a](https://github.com/cEhlers88/AnalyticsCore/commit/b03320a4b85211d44cea7aca872aa97f28d90dbf))

## [0.5.11](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.10...v0.5.11) (2026-03-22)


### Miscellaneous Chores

* reinstate `getQuickInfo` method in `AbstractRunnableEntity` for state evaluation ([e8e73ed](https://github.com/cEhlers88/AnalyticsCore/commit/e8e73ed011c6e9b63dbd32a27e3c5651dfa80472))

## [0.5.10](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.9...v0.5.10) (2026-03-22)


### Miscellaneous Chores

* reinstate and refine `getQuickInfo` method in `Process` entity for progress calculation ([6f0bd1c](https://github.com/cEhlers88/AnalyticsCore/commit/6f0bd1c0c79a47b2c2cee728c739394598c7c21e))

## [0.5.9](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.8...v0.5.9) (2026-03-22)


### Miscellaneous Chores

* add info logging during worker configuration and initialization, reorder `getName` method in `AbstractWorker` ([65edd87](https://github.com/cEhlers88/AnalyticsCore/commit/65edd878700536abbfda1f4b315ace0116db037b))
* remove redundant logging in `AbstractWorker` ([f37c817](https://github.com/cEhlers88/AnalyticsCore/commit/f37c8175e044e2b0f0eee0bcf14c503ec8fbd1ed))
* replace `logInfo` with `handleTimeoutReached` for consistent timeout handling in `AbstractWorker` ([cc33618](https://github.com/cEhlers88/AnalyticsCore/commit/cc336186b261a8b7def5fcb3c74966bd81eb022e))

## [0.5.8](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.7...v0.5.8) (2026-03-22)


### Bug Fixes

* handle nullable `StoreDTO` in `setStore` methods of `RunChain` and `Worker` entities ([66f243f](https://github.com/cEhlers88/AnalyticsCore/commit/66f243f25d8f897eeaf97c62f91703d01443fe8d))

## [0.5.7](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.6...v0.5.7) (2026-03-22)


### Miscellaneous Chores

* make `onStart` and `onEnd` public in `AbstractExecutor` and `ExecutorInterface`, improve error handling with logging ([a1b6e7f](https://github.com/cEhlers88/AnalyticsCore/commit/a1b6e7ff2ead3dd4a137bb1f2dc8939a51469dd1))

## [0.5.6](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.5...v0.5.6) (2026-03-22)


### Miscellaneous Chores

* add `store` property and related getter/setter in `RunChain` entity to support `StoreDTO` ([fc76ea5](https://github.com/cEhlers88/AnalyticsCore/commit/fc76ea5916ffd1310727a2fc484d74bbde8bd59b))

## [0.5.5](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.4...v0.5.5) (2026-03-22)


### Bug Fixes

* replace `Profiler::runWithProfiler` with dedicated `Profiler` instance in `AbstractWorker` ([eddfd45](https://github.com/cEhlers88/AnalyticsCore/commit/eddfd45d0d4f3654eae25a1c6b5c832a0c1fd281))

## [0.5.4](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.3...v0.5.4) (2026-03-22)


### Bug Fixes

* correct logic for error detection in `AbstractErrorBag::hasError` ([7e242d5](https://github.com/cEhlers88/AnalyticsCore/commit/7e242d54ecbee53b8b3039a7ea6846ae379a6f8c))

## [0.5.3](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.2...v0.5.3) (2026-03-22)


### Miscellaneous Chores

* add `isRunning` method to `AbstractExecutor` and `ExecutorInterface` ([7599464](https://github.com/cEhlers88/AnalyticsCore/commit/75994649a88bc04da59933d9c37b4e6592881e23))
* add `preStart` hook and `ERR_ON_PRE_START` constant to `AbstractExecutor` ([4f23c58](https://github.com/cEhlers88/AnalyticsCore/commit/4f23c58e900c5a44b8fa172442d06f96d57db006))

## [0.5.2](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.1...v0.5.2) (2026-03-21)


### Miscellaneous Chores

* allow filtering to include errored workers in `fetchWaitingWorkers` and enhance state removal logic in `Worker` entity ([c2b3b8f](https://github.com/cEhlers88/AnalyticsCore/commit/c2b3b8fe1b0f49f1adc57b20ccf22f5a95354413))

## [0.5.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.0...v0.5.1) (2026-03-21)


### Miscellaneous Chores

* add generated `timestamp_time` and `handled_at_time` columns to `TrackingBuffer` entity ([38eff80](https://github.com/cEhlers88/AnalyticsCore/commit/38eff8035e0ddd1bfd332d11835e4cc608e076e5))

## [0.5.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.4.2...v0.5.0) (2026-03-20)


### Features

* add `IGNORED` state to `eTrackingBufferState` enum ([8c91865](https://github.com/cEhlers88/AnalyticsCore/commit/8c918652be693d78ec4add84985d21a2a0eb5626))

## [0.4.2](https://github.com/cEhlers88/AnalyticsCore/compare/v0.4.1...v0.4.2) (2026-03-20)


### Miscellaneous Chores

* update `_executeWorker` to return a boolean instead of enforcing void ([62ccf41](https://github.com/cEhlers88/AnalyticsCore/commit/62ccf41c8a112b323e345089cc238d21e69d86b4))

## [0.4.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.4.0...v0.4.1) (2026-03-20)


### Miscellaneous Chores

* set `VoidLogger` as default in `executeWorkersByPriorityLevel` and enforce void cast in `_executeWorker` ([4ef7378](https://github.com/cEhlers88/AnalyticsCore/commit/4ef73780780ccbda748880792f4dec90f34da397))

## [0.4.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.3.1...v0.4.0) (2026-03-20)


### Features

* enhance `AbstractExecutor` with profiler lifecycle and ms-level execution time ([84e9d3a](https://github.com/cEhlers88/AnalyticsCore/commit/84e9d3a4fde26bade3a6196ffd1b6245d2237378))
* introduce `eDebuggerLogType` and `eDebuggerLogReason` enums, update namespace usage ([327955f](https://github.com/cEhlers88/AnalyticsCore/commit/327955fbd6a495c6f22b5d473d1a5399f8038dc0))

## [0.3.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.3.0...v0.3.1) (2026-03-20)


### Miscellaneous Chores

* **deps:** update actions/checkout action to v6 ([#21](https://github.com/cEhlers88/AnalyticsCore/issues/21)) ([112697f](https://github.com/cEhlers88/AnalyticsCore/commit/112697f6e2e66d04d6555c4e5141323a3571f51a))
* **deps:** update dependency phpunit/phpunit to v13 ([#22](https://github.com/cEhlers88/AnalyticsCore/issues/22)) ([0fb6bcf](https://github.com/cEhlers88/AnalyticsCore/commit/0fb6bcfb09e641e71ce5303e726596a25512a4b5))

## [0.3.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.2.1...v0.3.0) (2026-03-19)


### Features

* add `CompositeLogger` for managing multiple loggers ([2adeeaf](https://github.com/cEhlers88/AnalyticsCore/commit/2adeeaff330a8a51eb7cd1d980e35cee7c5706f8))
* add `getLoggerByClass` method to `CompositeLogger` ([e5c9269](https://github.com/cEhlers88/AnalyticsCore/commit/e5c9269c2c2314007500787df7f14a6a8f74cca9))
* introduce `AbstractExecutor` with complete lifecycle and logging support ([5b76531](https://github.com/cEhlers88/AnalyticsCore/commit/5b76531500a34b5b9c489cefb86727ed748b4f28))

## [0.2.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.2.0...v0.2.1) (2026-01-22)


### Features

* Implement process presenter ([#15](https://github.com/cEhlers88/AnalyticsCore/issues/15)) ([230fa9e](https://github.com/cEhlers88/AnalyticsCore/commit/230fa9e762afe15c554a2d399db98a013448488c))


### Miscellaneous Chores

* Configure Renovate ([#12](https://github.com/cEhlers88/AnalyticsCore/issues/12)) ([e03e62d](https://github.com/cEhlers88/AnalyticsCore/commit/e03e62d3a081fd9dd7d3507f7045f0b803305063))

## [0.2.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.8...v0.2.0) (2026-01-22)


### Features

* Implement presenters ([#9](https://github.com/cEhlers88/AnalyticsCore/issues/9)) ([d7399a7](https://github.com/cEhlers88/AnalyticsCore/commit/d7399a7604e707761f6549279257b164c59b8970))


### Bug Fixes

* replace `DateTimeImmutable` with `DateTime` for better compatibility ([28354e5](https://github.com/cEhlers88/AnalyticsCore/commit/28354e51aecf77b1fb553a27501013c77e499f07))

## [0.1.8](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.7...v0.1.8) (2026-01-21)


### Bug Fixes

* initialize default type for AbstractWorkerJob ([aa409b5](https://github.com/cEhlers88/AnalyticsCore/commit/aa409b5b17539a63cb45d73d200f3dabb7efb9b8))

## [0.1.7](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.6...v0.1.7) (2026-01-21)


### Reverts

* fix: prepend 'TEST' to truncated tracking buffer string ([f59b84c](https://github.com/cEhlers88/AnalyticsCore/commit/f59b84cf7411e6b39e73f50cc64ef7fc5a5d4bc0))

## [0.1.6](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.5...v0.1.6) (2026-01-21)


### Bug Fixes

* prepend 'TEST' to truncated tracking buffer string ([5a68758](https://github.com/cEhlers88/AnalyticsCore/commit/5a68758fc4ccd6544fcfec8281b7c8374059fca4))

## [0.1.5](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.4...v0.1.5) (2026-01-21)


### Miscellaneous Chores

* add workflow to trigger Satis rebuild on release publication ([0ecb93e](https://github.com/cEhlers88/AnalyticsCore/commit/0ecb93ea6b9cac9b5dbd0e95e01d734f1bdfa2b5))

## [0.1.4](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.3...v0.1.4) (2026-01-21)


### Bug Fixes

* Update ClientPermission `permkeys` field type from ARRAY to JSON ([bddfd5e](https://github.com/cEhlers88/AnalyticsCore/commit/bddfd5e267cfec90fdd9624fbb9f054d77ef3102))
* Update service bindings to use `!tagged_iterator` for tagged services ([faf2a03](https://github.com/cEhlers88/AnalyticsCore/commit/faf2a03bb969fac99b2c79e326a7fd031be047d1))

## [0.1.3](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.2...v0.1.3) (2026-01-20)


### Miscellaneous Chores

* add release-please.yml ([8438a59](https://github.com/cEhlers88/AnalyticsCore/commit/8438a594eb4f9afcfd600fa0ae51d90e88fb76b6))
