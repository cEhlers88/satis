<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogReason;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\Extension\AbstractMacroExtension;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
use Cehlers88\AnalyticsCore\Support\Logging\VoidLogger;

abstract class AbstractMacro implements MacroInterface
{
    /**
     * @var MacroPropertyDTO[]
     */
    protected array $_properties = [];
    protected string $_description = "";
    protected string $_source = "APP";
    private ?LoggerInterface $_logger = null;
    private float $_executionStartTimer = 0;
    private bool $_isInitialized = false;
    private array $_extensions = [];
    private MacroEnvironment $_macroEnvironment;

    /**
     * Adds an extension to the macro
     * @param AbstractMacroExtension $extension
     * @return AbstractMacro
     */
    public function addExtension(AbstractMacroExtension $extension): AbstractMacro
    {
        $this->_extensions[] = $extension;
        return $this;
    }

    /**
     * Creates a Commanddefinition-String
     * @return string
     */
    public function generateCommandString(): string
    {
        if ($this->_isInitialized === false) {
            $this->init();
        }
        $propertyDefinitions = [];

        foreach ($this->_properties as $property) {
            $propertyDefinitions[$property->name] = $property->value;
        }

        return json_encode([
            $this->getName(),
            $propertyDefinitions
        ]);
    }

    public function init(): AbstractMacro
    {
        $this->_isInitialized = true;
        return $this;
    }

    abstract public function getName(): string;

    public function getDefinition(): array
    {
        if ($this->_isInitialized === false) {
            $this->init();
        }
        return [
            'name' => $this->getName(),
            'description' => $this->getDescription(),
            'properties' => $this->_properties
        ];
    }

    public function getDescription(): string
    {
        return $this->_description;
    }

    /**
     * Returns the extensions of the macro
     * @return AbstractMacroExtension[]
     */
    public function getExtensions(): array
    {
        return $this->_extensions;
    }

    public function getExtensionTags(): array
    {
        return [];
    }

    public function getPropertyValue(string $propertyName): mixed
    {
        return $this->_properties[$propertyName]->value;
    }

    public function getVariablesStoreProvider(): VariablesProvider
    {
        return $this->_macroEnvironment->getVariablesStoreProvider();
    }

    public function setProperty(MacroPropertyDTO $macroPropertyDTO): AbstractMacro
    {
        $this->_properties[$macroPropertyDTO->name] = $macroPropertyDTO;
        return $this;
    }

    public function getSource(): string
    {
        if ($this->_isInitialized === false) {
            $this->init();
        }
        return $this->_source;
    }

    public function needPrecompiledArguments(): bool
    {
        return true;
    }

    public function findInvalidArguments($arguments): array
    {
        $invalidArguments = [];
        foreach ($this->_properties as $property) {
            if (!$property->optional && is_null($arguments[$property->name])) {
                $invalidArguments[] = $property->name;
            }
        }
        return $invalidArguments;
    }

    protected function _createRunResult(mixed $returnValue, ?ErrorDTO $errorDTO = null): array
    {
        return [
            'error' => $errorDTO,
            'hasError' => !is_null($errorDTO),
            'returnValue' => $returnValue,
            'executionTime' => microtime(true) - $this->_executionStartTimer
        ];
    }

    protected function _executeMacro(string $name, array $arguments = []): ?array
    {
        return $this->_macroEnvironment->getMacroPlayer()->executeMacro($name, $arguments);
    }

    protected function _runCommandDefinition($definition): mixed
    {
        return $this->getMacroEnvironment()->getCommandPlayer()->run($definition);
    }

    abstract protected function run(): ?array;

    public function getMacroEnvironment(): MacroEnvironment
    {
        return $this->_macroEnvironment;
    }

    public function setMacroEnvironment(MacroEnvironment $macroEnvironment): AbstractMacro
    {
        $this->_macroEnvironment = $macroEnvironment;
        return $this;
    }

    protected function _executeExtension(string $name, mixed $data = null): mixed
    {
        $extension = $this->_getExtensionByName($name);
        if ($extension === null) {
            throw new \Exception("Extension $name not found in macro " . $this->getName());
        }
        return $extension
            ->setData($data)
            ->execute();
    }

    /**
     * Return a related extension by name
     * @param string $name
     * @return AbstractMacroExtension|null
     */
    private function _getExtensionByName(string $name): ?AbstractMacroExtension
    {
        foreach ($this->_extensions as $extension) {
            if ($extension->getName() === $name) {
                return $extension;
            }
        }
        return null;
    }

    public final function execute(array $arguments = []): ?array
    {
        $this->_executionStartTimer = microtime(true);
        $this->init();
        foreach ($arguments as $name => $value) {
            $this->setPropertyValue($name, $value);
        }
        return $this->run();
    }

    public function setPropertyValue(string $propertyName, mixed $value): AbstractMacro
    {
        if (!isset($this->_properties[$propertyName])) {
            throw new \Exception("Property $propertyName does not exist in macro " . $this->getName());
        }
        $this->_properties[$propertyName]->value = $value;
        return $this;
    }

    protected function log(eDebuggerLogType $logType, string $message, array $additionalInfos = []): AbstractMacro
    {
        if (!isset($additionalInfos['reason'])) {
            $additionalInfos['reason'] = eDebuggerLogReason::UNKNOWN;
        }
        $this->getLogger()->log($logType, $message, $additionalInfos);
        $this->_macroEnvironment->getDebugger()->attachLog($logType, $message, $additionalInfos);
        return $this;
    }

    public function getLogger(): LoggerInterface
    {
        if (is_null($this->_logger)) {
            return new VoidLogger();
        }
        return $this->_logger;
    }

    public function setLogger(?LoggerInterface $logger): static
    {
        $this->_logger = $logger;
        return $this;
    }
}