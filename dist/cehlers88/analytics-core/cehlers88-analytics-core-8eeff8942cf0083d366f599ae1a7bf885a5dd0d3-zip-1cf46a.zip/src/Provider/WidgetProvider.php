<?php

namespace Cehlers88\AnalyticsCore\Provider;

use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Widget\AbstractWidget;
use Twig\Environment;
use Twig\TemplateWrapper;

class WidgetProvider
{
    private ?User $_user = null;

    public function __construct(
        private iterable    $widgets,
        private Environment $twig
    )
    {
    }

    public function canAccessWidget(string $widgetName): bool
    {
        $widget = $this->getWidget($widgetName);
        if (is_null($widget)) {
            throw new \Exception('Widget not found');
        }

        if (count($widget->getRequiredRoles()) === 0) {
            return true;
        }

        if (is_null($this->_user)) {
            return false;
        }

        if ($this->_user->hasRole('ROLE_ADMIN')) {
            return true;
        }

        foreach ($widget->getRequiredRoles() as $role) {
            if (!$this->_user->hasRole($role)) {
                return false;
            }
        }

        return true;
    }

    public function getWidget(string $widgetName): ?AbstractWidget
    {
        foreach ($this->widgets as $widget) {
            if ($widget->getName() === $widgetName) {
                return $widget;
            }
        }
        return null;
    }

    public function getWidgetNames(): array
    {
        $names = [];
        foreach ($this->widgets as $widget) {
            $names[] = $widget->getName();
        }
        return $names;
    }

    public function getAvailableWidgetDefinitions(): array
    {
        $result = [];
        foreach ($this->widgets as $widget) {
            $result[] = [
                'name' => $widget->getName(),
                'preloadPlaceholders' => $widget->getPreloadPlaceholders(),
            ];
        }
        return $result;
    }

    public function renderWidget(string $widgetName, array $widgetProps = []): string
    {
        $widget = $this->getWidget($widgetName);
        if (is_null($widget)) {
            return 'Widget not found';
        }

        $possibleTemplatePaths = [
            'widget/' . $widget->getTemplateName(),
            'widget/' . $widget->getTemplateName() . '.html.twig',
            'widget/' . $widget->getName(),
            'widget/' . $widget->getName() . '.html.twig',
        ];

        try {
            $resolvedTemplate = $this->twig->resolveTemplate($possibleTemplatePaths);
        } catch (\Exception $e) {
            return 'No Template for widget "' . $widgetName . '" found';
        }

        try {
            return $resolvedTemplate->render([
                'widgetId' => 'wid' . uniqid(),
                ...$widgetProps
            ]);
        } catch (\Exception $e) {
            return 'Error while rendering widget "' . $widgetName . '": ' . $e->getMessage();
        }
    }

    private function resolveTemplate(string $templateName): ?TemplateWrapper
    {
        try {
            return $this->twig->resolveTemplate($templateName);
        } catch (\Exception $e) {
            return null;
        }
    }

    public function setUser(?User $user)
    {
        $this->_user = $user;
    }
}