<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\Dashboard;
use Cehlers88\AnalyticsCore\Entity\User;

interface DashboardRepositoryInterface
{
    /** @return Dashboard[] */
    public function findByUser(User $user): array;

    public function findOneByIdAndUser(int $id, User $user): ?Dashboard;

    public function getNextSortIndex(User $user): int;
}
