<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\Dashboard;
use Cehlers88\AnalyticsCore\Entity\User;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends AbstractRepository<Dashboard>
 */
class DashboardRepository extends AbstractRepository implements DashboardRepositoryInterface
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Dashboard::class);
    }

    /**
     * @return Dashboard[]
     */
    public function findByUser(User $user): array
    {
        return $this->findBy(['user' => $user], ['sortIndex' => 'ASC', 'id' => 'ASC']);
    }

    /**
     * Loads a dashboard but only if it belongs to the given user.
     */
    public function findOneByIdAndUser(int $id, User $user): ?Dashboard
    {
        return $this->findOneBy(['id' => $id, 'user' => $user]);
    }

    public function getNextSortIndex(User $user): int
    {
        $highestSortIndex = $this->createQueryBuilder('dashboard')
            ->select('MAX(dashboard.sortIndex)')
            ->where('dashboard.user = :user')
            ->setParameter('user', $user)
            ->getQuery()
            ->getSingleScalarResult();

        return is_null($highestSortIndex) ? 0 : ((int)$highestSortIndex) + 1;
    }
}
