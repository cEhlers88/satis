<?php

namespace Cehlers88\AnalyticsCore\Dashboard;

use Cehlers88\AnalyticsCore\Entity\Dashboard;

/**
 * Collects all dashboard setting definitions and turns raw request data into a
 * clean settings array.
 */
class DashboardSettingsProvider
{
    /** @var DashboardSettingDefinition[]|null */
    private ?array $definitions = null;

    /**
     * @param iterable<DashboardSettingProviderInterface> $settingProviders
     */
    public function __construct(private iterable $settingProviders)
    {
    }

    /**
     * @return DashboardSettingDefinition[] Keyed by setting key.
     */
    public function getDefinitions(): array
    {
        if (!is_null($this->definitions)) {
            return $this->definitions;
        }

        $definitions = [];
        foreach ($this->settingProviders as $settingProvider) {
            foreach ($settingProvider->getDashboardSettingDefinitions() as $definition) {
                $definitions[$definition->key] = $definition;
            }
        }

        return $this->definitions = $definitions;
    }

    public function getDefinition(string $key): ?DashboardSettingDefinition
    {
        return $this->getDefinitions()[$key] ?? null;
    }

    /**
     * Returns the stored settings enriched with the default value of every
     * known setting, so consumers never have to deal with missing keys.
     */
    public function getEffectiveSettings(?Dashboard $dashboard): array
    {
        $settings = [];
        foreach ($this->getDefinitions() as $key => $definition) {
            $settings[$key] = $definition->defaultValue;
        }

        foreach (($dashboard?->getSettings() ?? []) as $key => $value) {
            $settings[$key] = $value;
        }

        return $settings;
    }

    /**
     * Casts and filters submitted values down to the known settings.
     *
     * Unknown keys are dropped. Boolean settings that are missing from the
     * payload are stored as false, which is what an unchecked checkbox means.
     */
    public function normalizeSubmittedSettings(array $submittedSettings): array
    {
        $settings = [];

        foreach ($this->getDefinitions() as $key => $definition) {
            if (array_key_exists($key, $submittedSettings)) {
                $settings[$key] = $definition->castValue($submittedSettings[$key]);
                continue;
            }

            if ($definition->inputType->isBooleanLike()) {
                $settings[$key] = false;
            }
        }

        return $settings;
    }
}
