<?php

namespace Cehlers88\AnalyticsCore\Dashboard;

/**
 * Implement this interface to contribute additional dashboard settings.
 *
 * Implementations are collected automatically (tag: dashboard_setting_provider)
 * and their definitions are rendered into the dashboard settings mask.
 */
interface DashboardSettingProviderInterface
{
    /**
     * @return DashboardSettingDefinition[]
     */
    public function getDashboardSettingDefinitions(): array;
}
