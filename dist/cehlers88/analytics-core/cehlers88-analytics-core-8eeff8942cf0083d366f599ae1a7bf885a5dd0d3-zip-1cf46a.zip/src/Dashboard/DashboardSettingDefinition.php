<?php

namespace Cehlers88\AnalyticsCore\Dashboard;

use Cehlers88\AnalyticsCore\ENUM\eInputType;

/**
 * Describes a single configurable dashboard setting.
 *
 * Every setting that shows up in the dashboard settings mask is described by
 * one of these definitions, so adding a new setting only requires adding a
 * definition to a DashboardSettingProviderInterface implementation.
 */
readonly class DashboardSettingDefinition
{
    /**
     * @param array<string|int, string> $options Value => label map, only used by SELECT inputs.
     */
    public function __construct(
        public string     $key,
        public string     $label,
        public eInputType $inputType = eInputType::TEXT_SINGLE_LINE,
        public mixed      $defaultValue = null,
        public array      $options = [],
        public string     $description = '',
        public ?float     $min = null,
        public ?float     $max = null,
    )
    {
    }

    /**
     * Casts a raw (request) value into the type described by this definition.
     */
    public function castValue(mixed $value): mixed
    {
        if (is_null($value)) {
            return $this->defaultValue;
        }

        if ($this->inputType->isBooleanLike()) {
            return is_scalar($value) ? filter_var($value, FILTER_VALIDATE_BOOL) : $this->defaultValue;
        }

        return match ($this->inputType) {
            eInputType::NUMBER,
            eInputType::RANGE => $this->clamp($value),
            eInputType::SELECT,
            eInputType::RADIO => $this->castSelection($value),
            eInputType::COLOR => $this->castColor($value),
            default => is_scalar($value) ? trim((string)$value) : $this->defaultValue,
        };
    }

    /**
     * Colors end up in style attributes, so only plain hex values pass.
     */
    private function castColor(mixed $value): mixed
    {
        if (!is_scalar($value)) {
            return $this->defaultValue;
        }

        $color = trim((string)$value);

        return preg_match('/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $color) === 1 ? $color : $this->defaultValue;
    }

    private function clamp(mixed $value): int|float
    {
        $number = is_numeric($value) ? $value + 0 : ($this->defaultValue ?? 0);

        if (!is_null($this->min) && $number < $this->min) {
            $number = $this->min;
        }
        if (!is_null($this->max) && $number > $this->max) {
            $number = $this->max;
        }

        return is_float($number) && floor($number) === $number ? (int)$number : $number;
    }

    private function castSelection(mixed $value): mixed
    {
        if (count($this->options) === 0) {
            return is_scalar($value) ? (string)$value : $this->defaultValue;
        }

        return array_key_exists((string)$value, $this->options) ? $value : $this->defaultValue;
    }
}
