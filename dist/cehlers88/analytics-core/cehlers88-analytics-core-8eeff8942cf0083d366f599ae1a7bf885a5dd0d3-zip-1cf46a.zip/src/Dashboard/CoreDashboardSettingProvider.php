<?php

namespace Cehlers88\AnalyticsCore\Dashboard;

use Cehlers88\AnalyticsCore\ENUM\eInputType;

/**
 * Provides the dashboard settings shipped with the core.
 */
class CoreDashboardSettingProvider implements DashboardSettingProviderInterface
{
    public const SETTING_COLUMNS = 'columns';
    public const SETTING_ACCENT_COLOR = 'accentColor';
    public const SETTING_SHOW_WIDGET_TITLES = 'showWidgetTitles';

    public function getDashboardSettingDefinitions(): array
    {
        return [
            new DashboardSettingDefinition(
                key: self::SETTING_COLUMNS,
                label: 'Spalten',
                inputType: eInputType::NUMBER,
                defaultValue: 3,
                description: 'Anzahl der Spalten, in denen die Widgets angeordnet werden.',
                min: 1,
                max: 6
            ),
            new DashboardSettingDefinition(
                key: self::SETTING_ACCENT_COLOR,
                label: 'Akzentfarbe',
                inputType: eInputType::COLOR,
                defaultValue: '#1f6feb',
                description: 'Fallback-Akzentfarbe für Widgets ohne eigene Farbe.'
            ),
            new DashboardSettingDefinition(
                key: self::SETTING_SHOW_WIDGET_TITLES,
                label: 'Widget-Titel anzeigen',
                inputType: eInputType::BOOLEAN,
                defaultValue: true,
                description: 'Blendet die Titelzeile der Widgets ein oder aus.'
            ),
        ];
    }
}
