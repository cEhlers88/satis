<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\Entity\SystemLog;
use Analytics\Repository\SystemLogRepository;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;

class LogViewWidget extends AbstractWidget
{
    public function __construct(
        private readonly SystemLogRepository      $systemLogRepository,
        private readonly TrackingBufferRepository $trackingBufferRepository
    )
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.logView';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]]
        ];
    }


    public function getTemplateName(): string
    {
        return 'logView';
    }

    public function enrichProperties(array $properties): array
    {
        $logs = [];

        if (!isset($properties['source'])) {
            return $logs;
        }

        switch ($properties['source']->entity) {
            case 'SystemLog':
                $systemLogs = $this->systemLogRepository->findBy(
                    [],
                    ['id' => 'desc'],
                    10
                );
                $logs = array_map(function (SystemLog $systemLog) {
                    return [
                        'time' => $systemLog->getCreatedAt()->format('Y-m-d H:i:s'),
                        'levelClass' => 'log',
                        'level' => 'LOG',
                        'msg' => $systemLog->getData()['error']
                    ];
                }, $systemLogs);

                break;
            case 'TrackingBuffer':
                $filters = [];
                if (isset($properties['source']->keyFilter)) {
                    $filters['keyValue'] = $properties['source']->keyFilter;
                }
                $trackingBuffers = $this->trackingBufferRepository->findBy(
                    $filters,
                    ['id' => 'DESC'],
                    10
                );
                $logs = array_map(function (TrackingBuffer $trackingBuffer) {
                    return [
                        'time' => $trackingBuffer->getCreatedAt()->format('Y-m-d H:i:s'),
                        'levelClass' => 'log',
                        'level' => 'LOG',
                        'msg' => $trackingBuffer->getData()['key']
                    ];
                }, $trackingBuffers);
                break;
        }

        return [
            'logs' => $logs
        ];
    }
}