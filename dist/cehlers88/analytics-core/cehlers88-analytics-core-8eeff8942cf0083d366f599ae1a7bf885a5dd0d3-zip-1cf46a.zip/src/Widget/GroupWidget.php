<?php

namespace Cehlers88\AnalyticsCore\Widget;

class GroupWidget extends AbstractWidget
{
    public function getName(): string
    {
        return 'AnalyticsCore.group';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
        ];
    }

    public function getTemplateName(): string
    {
        return 'group';
    }
}