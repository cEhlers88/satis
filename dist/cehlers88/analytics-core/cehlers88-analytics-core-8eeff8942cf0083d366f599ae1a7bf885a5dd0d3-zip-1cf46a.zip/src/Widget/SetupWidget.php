<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Cehlers88\AnalyticsCore\Provider\WidgetProvider;

class SetupWidget extends AbstractWidget
{
    public function __construct(
        private readonly WidgetProvider $widgetProvider
    )
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.setup';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
        ];
    }


    public function getTemplateName(): string
    {
        return 'setup';
    }

    public function enrichProperties(array $properties): array
    {
        return parent::enrichProperties([
            ...$properties,
            'availableWidgets' => $this->widgetProvider->getWidgetNames()
        ]);
    }
}