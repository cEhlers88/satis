<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 19:32
 */

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Analytics\ENUM\eWidgetType;
use Analytics\Interface\IWidget;
use Cehlers88\AnalyticsCore\Entity\User;

abstract class AbstractWidget implements IWidget
{
    public function enrichProperties(array $properties): array
    {
        return $properties;
    }

    public function getTemplateName(): string
    {
        return $this->getName();
    }

    abstract public function getName(): string;

    public function getPreloadPlaceholders(): array
    {
        return [];
    }

    public function getRequiredStartArguments(): array
    {
        return [];
    }

    public function getRequiredRoles(): array
    {
        return [];
    }

    public function getWidgetType(): eWidgetType
    {
        return eWidgetType::DASHBOARD;
    }

    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        return WidgetSubmitResultDTO::createError(404, 'Not implemented');
    }
}