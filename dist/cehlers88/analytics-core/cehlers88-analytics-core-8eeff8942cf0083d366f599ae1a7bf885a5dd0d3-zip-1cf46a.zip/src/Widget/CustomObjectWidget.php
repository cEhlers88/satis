<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;

class CustomObjectWidget extends AbstractWidget
{
    public function __construct(
        private readonly CustomObjectProvider $customObjectProvider,
        private readonly AssemblerProvider    $assemblerProvider
    )
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.customObject';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
        ];
    }

    public function getTemplateName(): string
    {
        return 'customObject';
    }

    public function enrichProperties(array $properties): array
    {
        $customObject = $this->customObjectProvider->getCustomObjectById($properties['customObjectId']);
        $result = [
            ...$properties,
            'customObject' => $this->assemblerProvider->getAssemblerForClass($customObject::class)->one($customObject)
        ];

        return parent::enrichProperties($result);
    }
}