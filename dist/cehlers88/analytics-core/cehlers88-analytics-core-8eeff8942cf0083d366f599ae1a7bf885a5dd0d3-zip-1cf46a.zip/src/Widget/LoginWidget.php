<?php

namespace Cehlers88\AnalyticsCore\Widget;

class LoginWidget extends AbstractWidget
{
    public function getName(): string
    {
        return 'AnalyticsCore.login';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
        ];
    }

    public function getTemplateName(): string
    {
        return 'login';
    }
}