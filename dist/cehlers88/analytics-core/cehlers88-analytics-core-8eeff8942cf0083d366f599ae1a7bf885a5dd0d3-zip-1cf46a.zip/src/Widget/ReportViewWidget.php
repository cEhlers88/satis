<?php

namespace Cehlers88\AnalyticsCore\Widget;

class ReportViewWidget extends AbstractWidget
{
    public function getName(): string
    {
        return 'AnalyticsCore.report';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '50px', 'boxes' => [.4, .6]],
        ];
    }


    public function getTemplateName(): string
    {
        return 'reportView';
    }
}