<?php

namespace Cehlers88\AnalyticsCore\Tests\Dashboard;

use Cehlers88\AnalyticsCore\Dashboard\DashboardSettingDefinition;
use Cehlers88\AnalyticsCore\ENUM\eInputType;
use PHPUnit\Framework\TestCase;

class DashboardSettingDefinitionTest extends TestCase
{
    // ── boolean settings ─────────────────────────────────────────────────────

    public function testCastValueReadsCheckboxValuesAsBoolean(): void
    {
        $definition = new DashboardSettingDefinition(
            key: 'showTitles',
            label: 'Titel',
            inputType: eInputType::BOOLEAN,
            defaultValue: true
        );

        $this->assertTrue($definition->castValue('1'));
        $this->assertTrue($definition->castValue('on'));
        $this->assertFalse($definition->castValue('0'));
        $this->assertFalse($definition->castValue(''));
    }

    public function testCastValueTreatsNonScalarInputAsNoAnswerAtAll(): void
    {
        $definition = new DashboardSettingDefinition(
            key: 'showTitles',
            label: 'Titel',
            inputType: eInputType::BOOLEAN,
            defaultValue: true
        );

        // Request data can hold arrays - those must not be coerced into false.
        $this->assertTrue($definition->castValue(['1']));
        $this->assertTrue($definition->castValue(new \stdClass()));
    }

    // ── numbers ──────────────────────────────────────────────────────────────

    public function testCastValueClampsNumbersIntoTheAllowedRange(): void
    {
        $definition = $this->makeColumnsDefinition();

        $this->assertSame(1, $definition->castValue('-4'));
        $this->assertSame(6, $definition->castValue('99'));
        $this->assertSame(4, $definition->castValue('4'));
    }

    public function testCastValueFallsBackToTheDefaultForNonNumericInput(): void
    {
        $definition = $this->makeColumnsDefinition();

        $this->assertSame(3, $definition->castValue('drei'));
    }

    public function testCastValueReturnsTheDefaultForNull(): void
    {
        $this->assertSame(3, $this->makeColumnsDefinition()->castValue(null));
    }

    // ── selections ───────────────────────────────────────────────────────────

    public function testCastValueRejectsValuesOutsideTheOptionList(): void
    {
        $definition = new DashboardSettingDefinition(
            key: 'density',
            label: 'Dichte',
            inputType: eInputType::SELECT,
            defaultValue: 'normal',
            options: ['normal' => 'Normal', 'compact' => 'Kompakt']
        );

        $this->assertSame('compact', $definition->castValue('compact'));
        $this->assertSame('normal', $definition->castValue('huge'));
    }

    // ── colors ───────────────────────────────────────────────────────────────

    public function testCastValueOnlyAcceptsHexColors(): void
    {
        $definition = new DashboardSettingDefinition(
            key: 'accentColor',
            label: 'Akzentfarbe',
            inputType: eInputType::COLOR,
            defaultValue: '#1f6feb'
        );

        $this->assertSame('#abc', $definition->castValue('#abc'));
        $this->assertSame('#A1B2C3', $definition->castValue('#A1B2C3'));
        // Anything that could break out of the style attribute falls back.
        $this->assertSame('#1f6feb', $definition->castValue('red; background: url(x)'));
    }

    // ── free text ────────────────────────────────────────────────────────────

    public function testCastValueTrimsTextInput(): void
    {
        $definition = new DashboardSettingDefinition(key: 'note', label: 'Notiz', defaultValue: '');

        $this->assertSame('hallo', $definition->castValue('  hallo  '));
    }

    private function makeColumnsDefinition(): DashboardSettingDefinition
    {
        return new DashboardSettingDefinition(
            key: 'columns',
            label: 'Spalten',
            inputType: eInputType::NUMBER,
            defaultValue: 3,
            min: 1,
            max: 6
        );
    }
}
