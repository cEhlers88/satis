<?php

namespace Cehlers88\AnalyticsCore\Tests\Dashboard;

use Cehlers88\AnalyticsCore\Dashboard\DashboardManager;
use Cehlers88\AnalyticsCore\Dashboard\DashboardSettingDefinition;
use Cehlers88\AnalyticsCore\Dashboard\DashboardSettingProviderInterface;
use Cehlers88\AnalyticsCore\Dashboard\DashboardSettingsProvider;
use Cehlers88\AnalyticsCore\ENUM\eInputType;
use Cehlers88\AnalyticsCore\Entity\Dashboard;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Repository\DashboardRepositoryInterface;
use Doctrine\ORM\EntityManagerInterface;
use PHPUnit\Framework\TestCase;

class DashboardManagerTest extends TestCase
{
    /**
     * DashboardRepositoryInterface decoupled the repository, but the manager is
     * still typed against Doctrine's EntityManagerInterface, which the core does
     * not declare - the embedding application supplies it. These tests therefore
     * only run where that application context exists.
     */
    public static function setUpBeforeClass(): void
    {
        if (!interface_exists(EntityManagerInterface::class)) {
            self::markTestSkipped('Doctrine is not installed; DashboardManager can only be tested in an application context.');
        }
    }

    // ── resolving the active dashboard ───────────────────────────────────────

    public function testActiveDashboardIsTheOneStoredInTheUserSettings(): void
    {
        $user = new User();
        $first = $this->makeDashboard(1, 'Erstes');
        $second = $this->makeDashboard(2, 'Zweites');
        $user->setSettings([DashboardManager::ACTIVE_DASHBOARD_SETTING => 2]);

        $manager = $this->makeManager([$first, $second]);

        $this->assertSame($second, $manager->getActiveDashboard($user));
    }

    public function testActiveDashboardFallsBackToTheFirstOneWhenTheStoredIdIsGone(): void
    {
        $user = new User();
        $first = $this->makeDashboard(1, 'Erstes');
        $user->setSettings([DashboardManager::ACTIVE_DASHBOARD_SETTING => 99]);

        $manager = $this->makeManager([$first]);

        $this->assertSame($first, $manager->getActiveDashboard($user));
    }

    public function testActiveDashboardIsNullWithoutAnyDashboard(): void
    {
        $this->assertNull($this->makeManager([])->getActiveDashboard(new User()));
    }

    // ── switching ────────────────────────────────────────────────────────────

    public function testSetActiveDashboardKeepsTheOtherUserSettings(): void
    {
        $user = new User();
        $user->setSettings(['theme' => 'dark']);
        $dashboard = $this->makeDashboard(7, 'Sieben');

        $entityManager = $this->createMock(EntityManagerInterface::class);
        $entityManager->expects($this->once())->method('flush');

        $this->makeManager([$dashboard], $entityManager)->setActiveDashboard($user, $dashboard);

        $this->assertSame(
            ['theme' => 'dark', DashboardManager::ACTIVE_DASHBOARD_SETTING => 7],
            $user->getSettings()
        );
    }

    // ── creating ─────────────────────────────────────────────────────────────

    public function testCreateDashboardAppendsItToTheUserAndNormalizesItsSettings(): void
    {
        $user = new User();

        $dashboard = $this->makeManager([], null, $this->makeRepository([], 4))
            ->createDashboard($user, '  Finanzen  ', ['columns' => '9', 'unknown' => 'x'], false);

        $this->assertSame('Finanzen', $dashboard->getName());
        $this->assertSame(4, $dashboard->getSortIndex());
        $this->assertSame(['columns' => 6], $dashboard->getSettings());
        $this->assertSame($user, $dashboard->getUser());
        $this->assertTrue($user->getDashboards()->contains($dashboard));
    }

    public function testCreateDashboardFallsBackToADefaultName(): void
    {
        $dashboard = $this->makeManager([])->createDashboard(new User(), '   ', [], false);

        $this->assertSame(DashboardManager::DEFAULT_DASHBOARD_NAME, $dashboard->getName());
    }

    public function testCreateDashboardActivatesTheNewDashboardByDefault(): void
    {
        $user = new User();

        // Stand in for the id the database would hand out on persist.
        $entityManager = $this->createStub(EntityManagerInterface::class);
        $entityManager->method('persist')->willReturnCallback(
            fn(Dashboard $dashboard) => new \ReflectionProperty(Dashboard::class, 'id')->setValue($dashboard, 12)
        );

        $this->makeManager([], $entityManager)->createDashboard($user, 'Neu');

        $this->assertSame(12, $user->getSettings()[DashboardManager::ACTIVE_DASHBOARD_SETTING]);
    }

    // ── updating ─────────────────────────────────────────────────────────────

    public function testUpdateDashboardKeepsTheOldNameWhenAnEmptyOneIsSubmitted(): void
    {
        $dashboard = $this->makeDashboard(1, 'Betrieb');

        $this->makeManager([$dashboard])->updateDashboard($dashboard, '  ', ['columns' => '2']);

        $this->assertSame('Betrieb', $dashboard->getName());
        $this->assertSame(['columns' => 2], $dashboard->getSettings());
    }

    // ── deleting ─────────────────────────────────────────────────────────────

    public function testDeletingTheActiveDashboardActivatesTheRemainingOne(): void
    {
        $user = new User();
        $first = $this->makeDashboard(1, 'Erstes');
        $second = $this->makeDashboard(2, 'Zweites');
        $user->addDashboard($first);
        $user->addDashboard($second);
        $user->setSettings([DashboardManager::ACTIVE_DASHBOARD_SETTING => 2]);

        $repository = $this->makeRepository([$first]);

        $this->makeManager([$first], null, $repository)->deleteDashboard($second);

        $this->assertSame(1, $user->getSettings()[DashboardManager::ACTIVE_DASHBOARD_SETTING]);
        $this->assertFalse($user->getDashboards()->contains($second));
    }

    public function testDeletingAnInactiveDashboardLeavesTheSelectionAlone(): void
    {
        $user = new User();
        $first = $this->makeDashboard(1, 'Erstes');
        $second = $this->makeDashboard(2, 'Zweites');
        $user->addDashboard($first);
        $user->addDashboard($second);
        $user->setSettings([DashboardManager::ACTIVE_DASHBOARD_SETTING => 1]);

        $this->makeManager([$first])->deleteDashboard($second);

        $this->assertSame(1, $user->getSettings()[DashboardManager::ACTIVE_DASHBOARD_SETTING]);
    }

    public function testDeletingTheLastDashboardClearsTheSelection(): void
    {
        $user = new User();
        $only = $this->makeDashboard(1, 'Einziges');
        $user->addDashboard($only);
        $user->setSettings([DashboardManager::ACTIVE_DASHBOARD_SETTING => 1]);

        $this->makeManager([])->deleteDashboard($only);

        $this->assertNull($user->getSettings()[DashboardManager::ACTIVE_DASHBOARD_SETTING]);
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    /**
     * @param Dashboard[] $dashboards Result of the repository lookups.
     */
    private function makeManager(
        array                   $dashboards,
        ?EntityManagerInterface $entityManager = null,
        ?DashboardRepositoryInterface    $repository = null
    ): DashboardManager
    {
        return new DashboardManager(
            $repository ?? $this->makeRepository($dashboards),
            $this->makeSettingsProvider(),
            $entityManager ?? $this->createStub(EntityManagerInterface::class)
        );
    }

    /**
     * @param Dashboard[] $dashboards
     */
    private function makeRepository(array $dashboards, int $nextSortIndex = 0): DashboardRepositoryInterface
    {
        $repository = $this->createStub(DashboardRepositoryInterface::class);
        $repository->method('findByUser')->willReturn($dashboards);
        $repository->method('getNextSortIndex')->willReturn($nextSortIndex);

        return $repository;
    }

    private function makeSettingsProvider(): DashboardSettingsProvider
    {
        $settingProvider = $this->createStub(DashboardSettingProviderInterface::class);
        $settingProvider->method('getDashboardSettingDefinitions')->willReturn([
            new DashboardSettingDefinition(
                key: 'columns',
                label: 'Spalten',
                inputType: eInputType::NUMBER,
                defaultValue: 3,
                min: 1,
                max: 6
            ),
        ]);

        return new DashboardSettingsProvider([$settingProvider]);
    }

    private function makeDashboard(int $id, string $name): Dashboard
    {
        $dashboard = new Dashboard()->setName($name);

        $idProperty = new \ReflectionProperty(Dashboard::class, 'id');
        $idProperty->setValue($dashboard, $id);

        return $dashboard;
    }
}
