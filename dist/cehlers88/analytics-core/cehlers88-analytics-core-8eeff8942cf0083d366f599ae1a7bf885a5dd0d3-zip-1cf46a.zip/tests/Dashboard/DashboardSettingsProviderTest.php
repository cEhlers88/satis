<?php

namespace Cehlers88\AnalyticsCore\Tests\Dashboard;

use Cehlers88\AnalyticsCore\Dashboard\DashboardSettingDefinition;
use Cehlers88\AnalyticsCore\Dashboard\DashboardSettingProviderInterface;
use Cehlers88\AnalyticsCore\Dashboard\DashboardSettingsProvider;
use Cehlers88\AnalyticsCore\ENUM\eInputType;
use Cehlers88\AnalyticsCore\Entity\Dashboard;
use PHPUnit\Framework\TestCase;

class DashboardSettingsProviderTest extends TestCase
{
    // ── definition collection ────────────────────────────────────────────────

    public function testDefinitionsOfAllProvidersAreCollected(): void
    {
        $provider = $this->makeProvider(
            [$this->makeColumnsDefinition()],
            [new DashboardSettingDefinition(key: 'note', label: 'Notiz', defaultValue: '')]
        );

        $this->assertSame(['columns', 'note'], array_keys($provider->getDefinitions()));
        $this->assertSame('Spalten', $provider->getDefinition('columns')?->label);
        $this->assertNull($provider->getDefinition('unknown'));
    }

    // ── effective settings ───────────────────────────────────────────────────

    public function testEffectiveSettingsFillInDefaultsForMissingKeys(): void
    {
        $provider = $this->makeProvider([$this->makeColumnsDefinition(), $this->makeTitlesDefinition()]);
        $dashboard = new Dashboard()->setSettings(['columns' => 5]);

        $this->assertSame(
            ['columns' => 5, 'showWidgetTitles' => true],
            $provider->getEffectiveSettings($dashboard)
        );
    }

    public function testEffectiveSettingsOfAMissingDashboardAreTheDefaults(): void
    {
        $provider = $this->makeProvider([$this->makeColumnsDefinition()]);

        $this->assertSame(['columns' => 3], $provider->getEffectiveSettings(null));
    }

    // ── normalizing submitted data ───────────────────────────────────────────

    public function testSubmittedValuesAreCastToTheDefinedType(): void
    {
        $provider = $this->makeProvider([$this->makeColumnsDefinition(), $this->makeTitlesDefinition()]);

        $this->assertSame(
            ['columns' => 6, 'showWidgetTitles' => true],
            $provider->normalizeSubmittedSettings(['columns' => '42', 'showWidgetTitles' => '1'])
        );
    }

    public function testUnknownKeysAreDropped(): void
    {
        $provider = $this->makeProvider([$this->makeColumnsDefinition()]);

        $this->assertSame(
            ['columns' => 2],
            $provider->normalizeSubmittedSettings(['columns' => '2', 'somethingElse' => 'x'])
        );
    }

    public function testAnUncheckedCheckboxIsStoredAsFalse(): void
    {
        $provider = $this->makeProvider([$this->makeTitlesDefinition()]);

        $this->assertSame(['showWidgetTitles' => false], $provider->normalizeSubmittedSettings([]));
    }

    public function testMissingNonBooleanSettingsAreLeftOutSoTheirDefaultApplies(): void
    {
        $provider = $this->makeProvider([$this->makeColumnsDefinition()]);

        $this->assertSame([], $provider->normalizeSubmittedSettings([]));
    }

    /**
     * @param DashboardSettingDefinition[] ...$definitionSets One set per provider.
     */
    private function makeProvider(array ...$definitionSets): DashboardSettingsProvider
    {
        $settingProviders = [];
        foreach ($definitionSets as $definitions) {
            $settingProvider = $this->createStub(DashboardSettingProviderInterface::class);
            $settingProvider->method('getDashboardSettingDefinitions')->willReturn($definitions);
            $settingProviders[] = $settingProvider;
        }

        return new DashboardSettingsProvider($settingProviders);
    }

    private function makeColumnsDefinition(): DashboardSettingDefinition
    {
        return new DashboardSettingDefinition(
            key: 'columns',
            label: 'Spalten',
            inputType: eInputType::NUMBER,
            defaultValue: 3,
            min: 1,
            max: 6
        );
    }

    private function makeTitlesDefinition(): DashboardSettingDefinition
    {
        return new DashboardSettingDefinition(
            key: 'showWidgetTitles',
            label: 'Widget-Titel anzeigen',
            inputType: eInputType::BOOLEAN,
            defaultValue: true
        );
    }
}
