<?php

namespace Cehlers88\AnalyticsCore\Security\MagicRole;

use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Symfony\Component\Security\Core\User\UserInterface;

class MagicRoleAnyOf implements MagicRoleInterface
{
    private ?UserInterface $user = null;
    private ?string $clientIp = null;

    private mixed $roleResolver;

    public function canHandle(string $roleName)
    {
        return str_starts_with($roleName, 'anyOf');
    }

    public function checkRole(RoleDTO $role): bool
    {
        foreach ($role->roles as $subRole) {
            if (call_user_func($this->roleResolver, [$subRole])) return true;
        }

        return false;
    }

    public function setUser(?UserInterface $user): MagicRoleInterface
    {
        $this->user = $user;
        return $this;
    }

    public function setClientIp(?string $ip): MagicRoleInterface
    {
        $this->clientIp = $ip;
        return $this;
    }


    public function setRoleResolver(callable $roleResolver): MagicRoleInterface
    {
        $this->roleResolver = $roleResolver;
        return $this;
    }
}