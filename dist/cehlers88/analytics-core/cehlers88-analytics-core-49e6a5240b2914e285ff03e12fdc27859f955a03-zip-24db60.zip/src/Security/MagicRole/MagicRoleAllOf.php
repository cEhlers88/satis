<?php

namespace Cehlers88\AnalyticsCore\Security\MagicRole;

use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Symfony\Component\Security\Core\User\UserInterface;

class MagicRoleAllOf implements MagicRoleInterface
{
    private ?UserInterface $user = null;
    private ?string $clientIp = null;

    public function canHandle(string $roleName)
    {
        return str_starts_with($roleName, 'allOf');
    }

    public function checkRole(RoleDTO $role): bool
    {
        foreach ($role->roles as $subRole) {
            if (!$this->user?->hasRole($subRole)) return false;
        }

        return true;
    }

    public function setUser(?UserInterface $user): MagicRoleInterface
    {
        $this->user = $user;
        return $this;
    }

    public function setClientIp(?string $ip): MagicRoleInterface
    {
        $this->clientIp = $ip;
        return $this;
    }

    public function setRoleResolver(callable $roleResolver): MagicRoleInterface
    {
        return $this;
    }


}