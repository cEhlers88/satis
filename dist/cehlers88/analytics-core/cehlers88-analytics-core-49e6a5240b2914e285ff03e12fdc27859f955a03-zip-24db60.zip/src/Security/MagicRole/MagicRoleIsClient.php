<?php

namespace Cehlers88\AnalyticsCore\Security\MagicRole;

use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use Cehlers88\AnalyticsCore\Security\Role\IsClientRole;
use Symfony\Component\Security\Core\User\UserInterface;

class MagicRoleIsClient implements MagicRoleInterface
{
    private ?UserInterface $user = null;
    private ?string $clientIp = null;

    private mixed $roleResolver;

    public function __construct(
        private ClientRepository $clientRepository
    )
    {

    }

    public function canHandle(string $roleName)
    {
        return str_starts_with($roleName, IsClientRole::NAME);
    }

    public function checkRole(RoleDTO $role): bool
    {
        $clientId = str_replace(IsClientRole::NAME, '', $role->name);
        $client = $this->clientRepository->getByIp($this->clientIp);

        return (!empty($client) && $client->getId() == $clientId);
    }

    public function setUser(?UserInterface $user): MagicRoleInterface
    {
        $this->user = $user;
        return $this;
    }

    public function setClientIp(?string $ip): MagicRoleInterface
    {
        $this->clientIp = $ip;
        return $this;
    }


    public function setRoleResolver(callable $roleResolver): MagicRoleInterface
    {
        $this->roleResolver = $roleResolver;
        return $this;
    }
}