<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

interface ViewInterface
{

}