<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Service\BadgeProvider;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\WorkerView;

class WorkerAssembler extends AbstractAssembler
{
    public function __construct(
        private BadgeProvider $badgeProvider = new BadgeProvider()
    )
    {

    }

    public function one(Worker|EntityInterface $entity): WorkerView
    {
        $lastRun = $nextRun = ' - never - ';
        $lastRunResult = $entity->getLastRunResult();

        if ($lastRunResult->startedAt !== null) {
            $lastRun = $lastRunResult->getFormatedStartedAt() . ' (' . round($lastRunResult->runtime, 4) . ' s)';
        }

        if (!empty($entity->getNextRunAt())) {
            $nextRun = $entity->getNextRunAt()->format('d.m.Y | H:i:s');
        }

        $result = new WorkerView(
            id: $entity->getId(),
            name: $entity->getName(),
            description: $entity->getDescription(),
            enabled: $entity->isEnabled(),
            formatedLastRun: $lastRun,
            formatedNextRun: $nextRun,
            priority: $entity->getPriority(),
            state: $entity->getState(),
            workerClass: $entity->getWorkerClass(),
            application: new ApplicationAssembler()->one($entity->getApplication())
        );
        $result->badges = $this->badgeProvider->getBadgesByRunningStates($entity->getState());
        foreach ($entity->getCounters() as $key => $value) {
            if (!empty($result->counters)) {
                $result->counters .= ' |';
            }
            $result->counters .= $key . ': ' . $value;
        }

        $result->properties = $entity->getProperties();
        $runChainIds = [];
        foreach ($entity->getRunChains() as $runChain) {
            $runChainIds[] = $runChain->getId();
        }
        $result->runChains = $runChainIds;

        $result->readableRunInterval = $entity->getReadableRunInterval();
        $result->maxRuntime = $entity->getMaxRuntime();
        $result->runIntervalHms = $entity->getRunIntervalHms();

        return $result;
    }

}