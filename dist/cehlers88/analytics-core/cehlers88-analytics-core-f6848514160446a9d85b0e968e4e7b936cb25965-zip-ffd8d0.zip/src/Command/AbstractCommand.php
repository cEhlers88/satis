<?php

namespace Cehlers88\AnalyticsCore\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

abstract class AbstractCommand extends Command
{
    protected ?SymfonyStyle $_io = null;

    /**
     * Presents a choice question to the user and determines the selected option.
     *
     * @param string $question The question to be presented to the user.
     * @param array $choices The available choices, each represented as an associative array with at least a 'label' key.
     * @param mixed $default The default value to return if no valid selection is made.
     * @param string $choiceResultField The key of the field in the choice array to use for the result. Default is 'value'.
     *
     * @return mixed The selected choice's value for the specified field, or the default value if no choice is made.
     */
    protected function choice(
        string $question,
        array  $choices,
        mixed  $default = null,
        string $choiceResultField = 'value',
    ): mixed
    {
        if (is_null($this->_io)) {
            throw new \RuntimeException('IO is not set');
        }

        $defaultEntry = array_find($choices, function ($item) use ($choiceResultField, $default) {
            return strtolower($item['label']) === strtolower($default) || strtolower($item[$choiceResultField]) === strtolower($default);
        });

        $defaultLabel = $defaultEntry ? ($defaultEntry['label'] ? $defaultEntry['label'] : $defaultEntry[$choiceResultField]) : $default;

        $selection = $this->_io->choice($question, array_map(fn($item) => $item['label'], $choices), $defaultLabel);

        return array_find($choices, function ($item) use ($choiceResultField, $selection) {
            return strtolower($item['label']) === strtolower($selection) || strtolower($item[$choiceResultField]) === strtolower($selection);
        })[$choiceResultField];
    }

    protected function cls(): void
    {
        return;
        for ($i = 0; $i < 100; $i++) {
            $this->_io->writeln('');
        }
    }

    final protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $this->setIO(new SymfonyStyle($input, $output));

        return $this->handle();
    }

    final public function setIO(SymfonyStyle $io): static
    {
        $this->_io = $io;
        return $this;
    }

    abstract protected function handle(): int;
}