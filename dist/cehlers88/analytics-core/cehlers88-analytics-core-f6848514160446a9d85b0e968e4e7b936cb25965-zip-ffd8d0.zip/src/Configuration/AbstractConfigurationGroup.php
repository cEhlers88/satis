<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 20:19
 */

namespace Cehlers88\AnalyticsCore\Configuration;

use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\DTO\ValidationResultDTO;

abstract class AbstractConfigurationGroup implements GroupInterface
{
    public const VIEW_CONTEXT_SETTINGS = 'settings';

    public function getViewContext(): string
    {
        return self::VIEW_CONTEXT_SETTINGS;
    }

    public function isPersistable(): bool
    {
        return true;
    }

    public function needApplication(): bool
    {
        return false;
    }

    public function validate(ConfigurationItemDTO $configurationItem, mixed $value): ValidationResultDTO
    {
        return new ValidationResultDTO();
    }
}