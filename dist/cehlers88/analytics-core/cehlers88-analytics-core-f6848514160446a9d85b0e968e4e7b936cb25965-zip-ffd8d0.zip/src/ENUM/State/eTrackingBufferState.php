<?php

namespace Cehlers88\AnalyticsCore\ENUM\State;

enum eTrackingBufferState: int
{
    case NEW = 0;
    case IN_PROGRESS = 1;
    case PROCESSED_NOT_FINISHED = 2;
    case PROCESSED_FINISHED = 4;

    case CHILD_PROCESS_STARTED = 512;
    case CHILD_PROCESS_FINISHED = 1024;
    case CHILD_PROCESS_FAILED = 2048;

    case ERROR = 8192;
}