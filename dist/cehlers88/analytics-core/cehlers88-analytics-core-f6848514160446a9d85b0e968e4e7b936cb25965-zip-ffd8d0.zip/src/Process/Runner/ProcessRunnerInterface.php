<?php

namespace Cehlers88\AnalyticsCore\Process\Runner;

use Cehlers88\AnalyticsCore\Entity\Process;
use Throwable;

interface ProcessRunnerInterface
{

    public function getProcess(bool $createIfNotExist = true): ?Process;

    public function getArguments(): array;

    public function getRequiredArguments(): array;

    public function validate(): static;

    /**
     * @throws Throwable
     */
    public function run(): void;
}