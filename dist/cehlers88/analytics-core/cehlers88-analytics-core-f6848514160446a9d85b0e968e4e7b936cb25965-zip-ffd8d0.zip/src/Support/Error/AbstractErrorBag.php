<?php

namespace Cehlers88\AnalyticsCore\Support\Error;

use Analytics\Logger\VoidLogger;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;

abstract class AbstractErrorBag implements ErrorBagInterface
{
    /**
     * @var ErrorDTO[] $errors
     */
    public array $errors = [];
    protected ?LoggerInterface $_logger = null;
    private bool $_debugMode = false;

    public function hasError(): bool
    {
        return count($this->errors) > 0;
    }

    public function setError(string $message, int $code = -1, array $data = []): ErrorDTO
    {
        $result = ErrorDTO::create($code, $message, $data);
        $this->errors[] = $result;

        /*$result = ExecutorResultDTO::createError($code, $message);
        $result->data = $this->errors;
        */
        return $result;
    }

    public function getErrorsAsString(): string
    {
        $messages = [];
        foreach ($this->errors as $error) {
            $messages[] = $error->__toString();
        }
        return implode(PHP_EOL, $messages);
    }

    public function enableDebugMode(bool $enable): static
    {
        $this->_debugMode = $enable;
        return $this;
    }

    public function logInfo(string $message, bool $onlyInDebugMode = false): static
    {
        if ($onlyInDebugMode && !$this->_debugMode) {
            return $this;
        }

        $this->getLogger()->info($message);
        return $this;
    }

    public function getLogger(): LoggerInterface
    {
        return $this->_logger ?? new VoidLogger();
    }

    public function setLogger(LoggerInterface $logger): static
    {
        $this->_logger = $logger;
        return $this;
    }

    public function logWarning(string $message, bool $onlyInDebugMode = false): static
    {
        if ($onlyInDebugMode && !$this->_debugMode) {
            return $this;
        }

        $this->getLogger()->warning($message);
        return $this;
    }

    public function logError(string $message, bool $onlyInDebugMode = false): static
    {
        if ($onlyInDebugMode && !$this->_debugMode) {
            return $this;
        }

        $this->getLogger()->error($message);
        return $this;
    }
}