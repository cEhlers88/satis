<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\Client;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Client>
 *
 * @method Client|null find($id, $lockMode = null, $lockVersion = null)
 * @method Client|null findOneBy(array $criteria, array $orderBy = null)
 * @method Client[]    findAll()
 * @method Client[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ClientRepository extends ServiceEntityRepository
{
    public function __construct(
        ManagerRegistry                $registry,
        private EntityManagerInterface $entityManager
    )
    {
        parent::__construct($registry, Client::class);
    }

    public function getByIp($ip): ?Client
    {
        return $this->findOneBy(['ip' => $ip]);
    }

    public function getByMac($mac): ?Client
    {
        return $this->findOneBy(['mac' => $mac]);
    }

    public function add(Client $client, bool $flush = true): Client
    {
        $this->entityManager->persist($client);
        if ($flush) {
            $this->entityManager->flush();
        }
        return $client;
    }
}
