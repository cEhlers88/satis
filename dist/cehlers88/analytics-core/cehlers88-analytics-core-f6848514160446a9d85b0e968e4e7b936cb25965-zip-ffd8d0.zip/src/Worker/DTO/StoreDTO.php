<?php

namespace Cehlers88\AnalyticsCore\Worker\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;
use Cehlers88\AnalyticsCore\DTO\NotificationDTO;

class StoreDTO extends DTO
{
    /** @var NotificationDTO[] $alerts */
    public array $alerts = [];

    public ?string $message = null;
    public array $currentData = [];
    public array $lastData = [];

    public static function fromArray(array $data): static
    {
        $dto = new static();

        if (isset($data['message'])) {
            $dto->message = $data['message'];
        }
        if (isset($data['alerts'])) {
            $dto->alerts = $data['alerts'];
        }
        if (isset($data['currentData'])) {
            $dto->currentData = $data['currentData'];
        }
        if (isset($data['lastData'])) {
            $dto->lastData = $data['lastData'];
        }

        return $dto;
    }

    public function toArray(): array
    {
        return get_object_vars($this);
    }
}