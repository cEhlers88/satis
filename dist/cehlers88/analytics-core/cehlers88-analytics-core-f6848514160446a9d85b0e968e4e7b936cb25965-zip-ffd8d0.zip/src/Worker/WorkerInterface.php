<?php

namespace Cehlers88\AnalyticsCore\Worker;

interface WorkerInterface
{
    public function configure(array $properties): static;

    public function getRequiredJobs(): array;

    public function setBenchmarkValue(string $key, mixed $value): static;

    public function getBenchmark(): array;

    public function reachedTimeout(): bool;
}