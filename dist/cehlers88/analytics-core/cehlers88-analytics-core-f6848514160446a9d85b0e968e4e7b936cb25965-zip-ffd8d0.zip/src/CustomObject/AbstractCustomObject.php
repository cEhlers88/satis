<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:21
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

abstract class AbstractCustomObject implements CustomObjectInterface
{
    private int $_id = -1;
    private array $_attributes = [];
    private string $_name = '';

    public function getClassName(): string
    {
        return get_class($this);
    }

    public function getName(): string
    {
        return $this->_name;
    }

    public function setName(string $name): self
    {
        $this->_name = $name;
        return $this;
    }

    public function getAttribute(string $name, mixed $defaultValue = null): mixed
    {
        return $this->_attributes[$name] ?? $defaultValue;
    }

    public function getAttributes(): array
    {
        return $this->_attributes;
    }

    public function getId(): int
    {
        return $this->_id;
    }

    public function setId(int $id): self
    {
        $this->_id = $id;
        return $this;
    }

    public function setAttribute(string $name, mixed $value): self
    {
        $this->_attributes[$name] = $value;
        return $this;
    }
}