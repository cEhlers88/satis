<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Utils\ConverterUtils;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\Index;

#[ORM\Entity(repositoryClass: TrackingBufferRepository::class)]
#[Index(name: 'created_at_idx', columns: ['created_at'])]
#[Index(name: 'modified_at_idx', columns: ['modified_at'])]
#[Index(name: 'updated_at_idx', columns: ['updated_at'])]
#[Index(name: 'key_value_idx', columns: ['key_value'])]
class TrackingBuffer extends AbstractEntity
{
    public const string KEY_CAPTURE_ENDPOINT = 'CAPTURE_ENDPOINT';
    public const string KEY_SERVICE_ENDPOINT = 'SERVICE_ENDPOINT';

    #[ORM\Column]
    private ?int $state = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $timestamp = null;

    #[ORM\Column(type: Types::JSON)]
    private ?array $data = null;

    #[ORM\Column(
        name: 'key_value',
        type: 'string',
        length: 255,
        nullable: true,
        insertable: false,
        updatable: false,
        columnDefinition: "VARCHAR(255) GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(data, '$.key'))) STORED",
        generated: 'ALWAYS'
    )]
    private ?string $keyValue = null;

    #[ORM\ManyToOne(inversedBy: 'trackingBuffers')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Application $application = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeInterface $handledAt = null;

    #[ORM\Column(nullable: true)]
    private ?array $handlerData = null;

    #[ORM\Column(length: 255)]
    private string $note = '';

    public function getState(): ?eTrackingBufferState
    {
        return eTrackingBufferState::from($this->state);
    }

    public function setState(eTrackingBufferState $state): static
    {
        $this->state = $state->value;

        return $this;
    }

    public function getTimestamp(): ?\DateTimeInterface
    {
        return $this->timestamp;
    }

    public function setTimestamp(\DateTimeInterface $timestamp): static
    {
        $this->timestamp = $timestamp;

        return $this;
    }

    public function getData(): ?array
    {
        return $this->data;
    }

    public function setData(array $data): static
    {
        $this->data = $data;
        if (isset($this->data['clientInfos']) && is_string($this->data['clientInfos'])) {
            $this->data['clientInfos'] = json_decode($this->data['clientInfos'], true);
        }

        return $this;
    }

    public function getDataOverview(int $maxLength = 300): ?string
    {
        if (isset($this->handlerData['ui_overview'])) {
            return substr($this->handlerData['ui_overview']['message'], 0, $maxLength) . '...';
        }

        $result = '';
        foreach ($this->data as $key => $value) {
            if ($key !== 'key') {
                if ($result !== '') {
                    $result .= ', ';
                }
                if (is_array($value)) {
                    $value = '[' . ConverterUtils::associativeArrayToString($value) . ']';
                }
                $result .= sprintf('%s: "%s" ', $key, $value);
            }
            if (strlen($result) > $maxLength) {
                return substr($result, 0, $maxLength) . '...';
            }
        }

        return $result;
    }

    public function getApplication(): ?Application
    {
        return $this->application;
    }

    public function setApplication(?Application $application): static
    {
        $this->application = $application;

        return $this;
    }

    public function getIp(): ?string
    {
        return $this->data['ip'] ?? null;
    }

    public function getHandledAt(): ?\DateTimeInterface
    {
        return $this->handledAt;
    }

    public function setHandledAt(?\DateTimeInterface $handledAt): static
    {
        $this->handledAt = $handledAt;

        return $this;
    }

    public function getHandlerData(): ?array
    {
        return $this->handlerData;
    }

    public function setHandlerData(?array $handlerData): static
    {
        $this->handlerData = $handlerData;

        return $this;
    }

    public function getNote(): ?string
    {
        return $this->note;
    }

    public function setNote(string $note): static
    {
        $this->note = $note;

        return $this;
    }
}
