<?php

namespace Cehlers88\AnalyticsCore\Entity;

interface EntityInterface
{

}