<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Entity\AbstractEntity;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

class AbstractEndpointEntity extends AbstractEntity
{
    #[ORM\Column]
    protected array $allowedMethods = [];

    #[ORM\Column(type: Types::TEXT)]
    protected ?string $description = null;

    #[ORM\Column(length: 255)]
    protected ?string $name = null;

    #[ORM\Column(nullable: true)]
    protected ?array $options = null;

    public function getAllowedMethods(): array
    {
        return $this->allowedMethods;
    }

    public function setAllowedMethods(array $allowedMethods): static
    {
        $this->allowedMethods = $allowedMethods;
        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getOptions(): array
    {
        return $this->options ?? [];
    }

    public function setOptions(?array $options): static
    {
        $this->options = $options;

        return $this;
    }
}