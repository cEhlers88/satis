<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Widget;

/**
 * The sub widgets of the group widget, as they sit in its "widgets" prop: a
 * list of entries, each naming a widget type, the title it shows, the props it
 * is rendered with, how much room it takes and whether it is shown at all.
 *
 *   [{"name": "AnalyticsCore.report", "title": "Umsatz", "size": 2,
 *     "enabled": true, "props": {"report": 3, "panels": "kpi"}}, …]
 *
 * The props reach the widget in every form a request leaves them in - an
 * array, decoded json objects or a json string - so everything here reads all
 * of them. Kept apart from GroupWidget, whose base class needs the host
 * application, so it can be tested on its own.
 */
final class GroupWidgetChildren
{
    /** More would not fit a tile in any layout - and every one is a request of its own. */
    public const int MAX_CHILDREN = 12;

    public const int MAX_TITLE_LENGTH = 120;

    /** size => label: the share of the row (side by side) or the columns spanned (grid) */
    public const array SIZES = [1 => '1×', 2 => '2×', 3 => '3×', 4 => '4×'];

    /**
     * The entries the raw prop holds, each with every key present. An entry
     * without a widget type is dropped; everything else falls back to its
     * default.
     *
     * @return list<array{name: string, title: string, props: array, size: int, enabled: bool}>
     */
    public static function read(mixed $raw): array
    {
        $entries = self::toArray($raw);
        if (!is_array($entries)) {
            return [];
        }

        $children = [];
        foreach ($entries as $entry) {
            $entry = self::toArray($entry);
            $name = is_array($entry) && is_string($entry['name'] ?? null) ? trim($entry['name']) : '';
            if ($name === '') {
                continue;
            }

            $title = is_scalar($entry['title'] ?? null) ? trim((string)$entry['title']) : '';
            $props = self::toArray($entry['props'] ?? []);
            $size = is_numeric($entry['size'] ?? null) ? (int)$entry['size'] : 1;

            $children[] = [
                'name' => $name,
                'title' => mb_substr($title, 0, self::MAX_TITLE_LENGTH),
                'props' => is_array($props) ? $props : [],
                'size' => max(1, min(count(self::SIZES), $size)),
                'enabled' => GroupWidgetLayout::isOn($entry['enabled'] ?? true),
            ];

            if (count($children) === self::MAX_CHILDREN) {
                break;
            }
        }

        return $children;
    }

    /**
     * The entries as they may be stored: only widget types the first callback
     * admits, each with the props the second one leaves of what was submitted
     * - which is where a sub widget gets the same normalization as a tile of
     * its own, so a group can not smuggle props past a widget's settings.
     *
     * @param callable(string): bool $isAllowed
     * @param callable(string, array): array $normalizeProps
     *
     * @return list<array{name: string, title: string, props: array, size: int, enabled: bool}>
     */
    public static function normalize(mixed $raw, callable $isAllowed, callable $normalizeProps): array
    {
        $children = [];

        foreach (self::read($raw) as $child) {
            if (!$isAllowed($child['name'])) {
                continue;
            }

            $child['props'] = $normalizeProps($child['name'], $child['props']);
            $children[] = $child;
        }

        return $children;
    }

    /** What a sub widget is called on its tab or card: its title, or else its type. */
    public static function label(array $child): string
    {
        $title = trim((string)($child['title'] ?? ''));

        return $title !== '' ? $title : self::shortName((string)($child['name'] ?? ''));
    }

    /** "AnalyticsCore.report" -> "report" */
    public static function shortName(string $widgetName): string
    {
        $position = strrpos($widgetName, '.');

        return $position === false ? $widgetName : substr($widgetName, $position + 1);
    }

    /**
     * Decoded json comes as objects, a prop that went through a form field as a
     * json string - both end up as plain arrays here.
     */
    private static function toArray(mixed $value): mixed
    {
        if (is_string($value)) {
            $trimmed = trim($value);
            if ($trimmed === '' || ($trimmed[0] !== '[' && $trimmed[0] !== '{')) {
                return $value;
            }

            try {
                return json_decode($trimmed, true, 64, JSON_THROW_ON_ERROR);
            } catch (\JsonException) {
                return $value;
            }
        }

        if (is_object($value)) {
            try {
                return json_decode(json_encode($value, JSON_THROW_ON_ERROR), true, 64, JSON_THROW_ON_ERROR);
            } catch (\JsonException) {
                return [];
            }
        }

        if (is_array($value)) {
            return array_map(
                static fn(mixed $item): mixed => is_object($item) || is_array($item) ? self::toArray($item) : $item,
                $value
            );
        }

        return $value;
    }
}
