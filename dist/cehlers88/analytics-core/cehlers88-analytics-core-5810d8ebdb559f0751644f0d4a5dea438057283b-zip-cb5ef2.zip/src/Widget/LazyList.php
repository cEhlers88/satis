<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Widget;

/**
 * A list that is only built once something walks or counts it.
 *
 * The group widget hands the masks of its sub widgets and of every type that
 * can be added along with its settings - which only the editor needs. Saving
 * and validating ask for the same settings, and building every mask there would
 * query whatever those widgets read their options from, again and again.
 *
 * @implements \IteratorAggregate<int, mixed>
 */
final class LazyList implements \IteratorAggregate, \Countable
{
    private ?array $items = null;

    /**
     * @param \Closure(): array $build
     */
    public function __construct(private readonly \Closure $build)
    {
    }

    public function getIterator(): \ArrayIterator
    {
        return new \ArrayIterator($this->toArray());
    }

    public function count(): int
    {
        return count($this->toArray());
    }

    public function toArray(): array
    {
        return $this->items ??= array_values(($this->build)());
    }
}
