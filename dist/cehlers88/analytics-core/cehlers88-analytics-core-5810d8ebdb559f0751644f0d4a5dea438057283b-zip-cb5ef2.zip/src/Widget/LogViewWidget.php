<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\Entity\SystemLog;
use Analytics\Repository\SystemLogRepository;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;

/**
 * The latest entries of the system log or the tracking buffer. The tile renders itself again
 * when such an entry is written (the DatabaseChanged event the dashboard gets through Mercure)
 * and reports the ids it lists as a "tileBadge" event, so a tile minimized in the side panel
 * of the app can count the new ones (assets/Tool/SidePanel/TileBadge.ts there).
 */
class LogViewWidget extends AbstractWidget
{
    /** How many entries the tile lists. */
    public const LIMIT = 10;

    public function __construct(
        private readonly SystemLogRepository      $systemLogRepository,
        private readonly TrackingBufferRepository $trackingBufferRepository
    )
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.logView';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]]
        ];
    }


    public function getTemplateName(): string
    {
        return 'logView';
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'source.entity',
                value: null,
                type: 'string',
                label: 'Quelle',
                description: 'Woher die angezeigten Einträge stammen.',
                ui: [
                    'options' => [
                        'SystemLog' => 'Systemprotokoll',
                        'TrackingBuffer' => 'Tracking-Puffer',
                    ],
                ]
            ),
            PropertyDTO::create(
                name: 'source.keyFilter',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Key-Filter',
                description: 'Beschränkt die Einträge auf einen Key - nur für den Tracking-Puffer.'
            ),
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $logs = [];
        $entity = '';
        // The source arrives as a decoded json object from the widget request
        // and as a plain array when it comes straight out of a dashboard.
        $source = (array)($properties['source'] ?? []);

        switch ($source['entity'] ?? '') {
            case 'SystemLog':
                $entity = 'SystemLog';
                $systemLogs = $this->systemLogRepository->findBy(
                    [],
                    ['id' => 'desc'],
                    self::LIMIT
                );
                $logs = array_map(function (SystemLog $systemLog) {
                    return [
                        'id' => $systemLog->getId(),
                        'time' => $systemLog->getCreatedAt()->format('Y-m-d H:i:s'),
                        'levelClass' => 'log',
                        'level' => 'LOG',
                        'msg' => $systemLog->getMapper() . $systemLog->getData()['error']
                    ];
                }, $systemLogs);

                break;
            case 'TrackingBuffer':
                $entity = 'TrackingBuffer';
                $filters = [];
                if (($source['keyFilter'] ?? '') !== '') {
                    $filters['keyValue'] = $source['keyFilter'];
                }
                $trackingBuffers = $this->trackingBufferRepository->findBy(
                    $filters,
                    ['id' => 'DESC'],
                    self::LIMIT
                );
                $logs = array_map(function (TrackingBuffer $trackingBuffer) {
                    return [
                        'id' => $trackingBuffer->getId(),
                        'time' => $trackingBuffer->getCreatedAt()->format('Y-m-d H:i:s'),
                        'levelClass' => 'log',
                        'level' => 'LOG',
                        'msg' => $trackingBuffer->getData()['key']
                    ];
                }, $trackingBuffers);
                break;
        }

        return [
            'logs' => $logs,
            'entity' => $entity,
            // The badge counts per source - a filtered tracking buffer counts only its key
            // (the system log has no key filter).
            'badgeKey' => $entity === 'TrackingBuffer' && ($source['keyFilter'] ?? '') !== ''
                ? $entity . ':' . $source['keyFilter']
                : $entity,
            // Fewer entries than the limit are all there are; otherwise older ones may be new too.
            'complete' => count($logs) < self::LIMIT,
        ];
    }
}