<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Widget;

/**
 * How the group widget arranges its sub widgets: side by side, one below the
 * other, in a grid or as tabs - plus the spacing, the alignment and whether
 * every sub widget gets a card of its own.
 *
 * Kept apart from GroupWidget, whose base class needs the host application, so
 * what a set of props turns into can be tested on its own. Whatever the props
 * say, the result only ever holds values the template can put into a class
 * name or a css variable as they are.
 */
final class GroupWidgetLayout
{
    public const string LAYOUT_ROW = 'row';
    public const string LAYOUT_COLUMN = 'column';
    public const string LAYOUT_GRID = 'grid';
    public const string LAYOUT_TABS = 'tabs';

    /** layout => label, in the order the mask offers them */
    public const array LAYOUTS = [
        self::LAYOUT_ROW => 'Nebeneinander',
        self::LAYOUT_COLUMN => 'Untereinander',
        self::LAYOUT_GRID => 'Raster',
        self::LAYOUT_TABS => 'Reiter (Tabs)',
    ];

    /** gap => [label, pixels] */
    public const array GAPS = [
        'none' => ['Kein', 0],
        'small' => ['Klein', 6],
        'medium' => ['Normal', 12],
        'large' => ['Groß', 20],
    ];

    /** align => [label, css value] - how sub widgets of different height line up side by side */
    public const array ALIGNS = [
        'stretch' => ['Gleich hoch', 'stretch'],
        'start' => ['Oben', 'flex-start'],
        'center' => ['Mittig', 'center'],
        'end' => ['Unten', 'flex-end'],
    ];

    public const int MIN_COLUMNS = 1;
    public const int MAX_COLUMNS = 6;
    public const int DEFAULT_COLUMNS = 2;

    public const int MIN_WIDTH_FLOOR = 100;
    public const int MIN_WIDTH_CEILING = 800;
    public const int DEFAULT_MIN_WIDTH = 220;

    /**
     * The layout the given props describe, with every value nobody picked (or
     * that is not one the widget knows) at its default.
     *
     * @return array{layout: string, columns: int, gap: int, align: string, minWidth: int, framed: bool, showTitles: bool}
     */
    public static function fromProps(array $props): array
    {
        $layout = self::pick($props['layout'] ?? null, array_keys(self::LAYOUTS), self::LAYOUT_ROW);
        $gap = self::pick($props['gap'] ?? null, array_keys(self::GAPS), 'medium');
        $align = self::pick($props['align'] ?? null, array_keys(self::ALIGNS), 'stretch');

        return [
            'layout' => $layout,
            'columns' => self::clamp($props['columns'] ?? null, self::MIN_COLUMNS, self::MAX_COLUMNS, self::DEFAULT_COLUMNS),
            'gap' => self::GAPS[$gap][1],
            'align' => self::ALIGNS[$align][1],
            'minWidth' => self::clamp($props['minWidth'] ?? null, self::MIN_WIDTH_FLOOR, self::MIN_WIDTH_CEILING, self::DEFAULT_MIN_WIDTH),
            'framed' => self::isOn($props['framed'] ?? true),
            'showTitles' => self::isOn($props['showTitles'] ?? true),
        ];
    }

    /**
     * Options for a select of the settings mask, value => label.
     *
     * @param array<string, array{0: string, 1: mixed}> $choices
     *
     * @return array<string, string>
     */
    public static function options(array $choices): array
    {
        return array_map(static fn(array $choice): string => $choice[0], $choices);
    }

    /**
     * Reads a checkbox of the settings mask, which arrives as bool, int or
     * string depending on how the props were stored.
     */
    public static function isOn(mixed $value): bool
    {
        return $value !== false && $value !== 0 && $value !== '0' && $value !== 'false' && $value !== null;
    }

    /**
     * @param list<string> $allowed
     */
    private static function pick(mixed $value, array $allowed, string $default): string
    {
        return is_string($value) && in_array($value, $allowed, true) ? $value : $default;
    }

    private static function clamp(mixed $value, int $min, int $max, int $default): int
    {
        if (!is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (int)$value));
    }
}
