<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Widget;

use Cehlers88\AnalyticsCore\DTO\PropertyConditionClauseDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\Provider\WidgetProvider;
use Cehlers88\AnalyticsCore\Support\Property\PropertyValuePath;

/**
 * Several widgets in one tile: side by side, one below the other, in a grid or
 * as tabs. Every sub widget is a widget type of its own with its own settings,
 * a title and a size (see GroupWidgetChildren), and is rendered by a
 * <dashboard-tile> of its own - so it behaves exactly as it would as a tile,
 * access checks included.
 *
 * The sub widgets are edited in the settings of the tile: the "widgets" setting
 * renders the editor of the application shell (<widget-group-editor>) with a
 * card per sub widget, each holding the settings mask of its type.
 */
class GroupWidget extends AbstractWidget
{
    public const string SETTING_WIDGETS = 'widgets';

    /**
     * Widgets that can not sit inside a group: another group (which would let
     * groups nest without end) and the setup tile, which only picks a type.
     */
    public const array NOT_NESTABLE = ['AnalyticsCore.group', 'AnalyticsCore.setup'];

    public function __construct(
        private readonly WidgetProvider $widgetProvider
    )
    {
    }

    public function getName(): string
    {
        return 'AnalyticsCore.group';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '80px', 'boxes' => [.5, .5]],
            ['height' => '80px', 'boxes' => [.5, .5]],
        ];
    }

    public function getTemplateName(): string
    {
        return 'group';
    }

    public function getSettingDefinitions(): array
    {
        return $this->buildDefinitions([]);
    }

    /**
     * Once sub widgets are picked, each of them brings the mask of its type,
     * filled with the values it is rendered with.
     */
    public function getSettingDefinitionsFor(array $values): array
    {
        return $this->buildDefinitions(GroupWidgetChildren::read($values[self::SETTING_WIDGETS] ?? []));
    }

    /**
     * Every sub widget is stored the way a tile of its type would be: types the
     * user may not use are dropped, and its props go through the settings its
     * type declares.
     */
    public function normalizeProps(array $props): array
    {
        $allowed = $this->nestableWidgetNames();

        $props[self::SETTING_WIDGETS] = GroupWidgetChildren::normalize(
            $props[self::SETTING_WIDGETS] ?? [],
            static fn(string $name): bool => in_array($name, $allowed, true),
            fn(string $name, array $childProps): array => $this->widgetProvider->normalizeSettings($name, $childProps)
        );

        return $props;
    }

    /**
     * A sub widget that is shown has to have what its type insists on, just like
     * a tile. One that is switched off may stay unfinished.
     */
    public function findUnsatisfiedNestedSettings(array $props): array
    {
        $unsatisfied = [];

        foreach (GroupWidgetChildren::read($props[self::SETTING_WIDGETS] ?? []) as $index => $child) {
            if (!$child['enabled']) {
                continue;
            }

            foreach ($this->widgetProvider->getMissingRequiredSettings($child['name'], $child['props']) as $missing) {
                $labelled = clone $missing;
                $labelled->label = sprintf(
                    '%s (Unterwidget %d · %s)',
                    $missing->label,
                    $index + 1,
                    GroupWidgetChildren::label($child)
                );
                $unsatisfied[] = $labelled;
            }
        }

        return $unsatisfied;
    }

    public function enrichProperties(array $properties): array
    {
        $layout = GroupWidgetLayout::fromProps($properties);
        $allowed = $this->nestableWidgetNames();

        $items = [];
        $unavailable = [];
        foreach (GroupWidgetChildren::read($properties[self::SETTING_WIDGETS] ?? []) as $child) {
            if (!$child['enabled']) {
                continue;
            }

            if (!in_array($child['name'], $allowed, true)) {
                $unavailable[] = GroupWidgetChildren::label($child);
                continue;
            }

            $items[] = [
                ...$child,
                'label' => GroupWidgetChildren::label($child),
                // A grid can not span more columns than it has.
                'span' => min($child['size'], $layout['columns']),
                // An empty object rather than an empty list, which is what the
                // tile hands to the widget as its props.
                'propsJson' => json_encode($child['props'] === [] ? new \stdClass() : $child['props']),
            ];
        }

        return [
            ...$properties,
            'group' => $layout,
            'items' => $items,
            'unavailable' => $unavailable,
        ];
    }

    /**
     * @param list<array{name: string, title: string, props: array, size: int, enabled: bool}> $children
     *
     * @return PropertyDTO[]
     */
    private function buildDefinitions(array $children): array
    {
        $layoutIs = static fn(string $layout): PropertyConditionClauseDTO => PropertyConditionClauseDTO::create('layout', $layout);
        $layoutIsNot = static fn(string $layout): PropertyConditionClauseDTO => PropertyConditionClauseDTO::create('layout', $layout, eConditionType::NOT_EQUALS);

        return [
            PropertyDTO::create(
                name: 'layout',
                value: GroupWidgetLayout::LAYOUT_ROW,
                type: 'string',
                isOptional: true,
                label: 'Ausrichtung',
                description: 'Wie die Unterwidgets angeordnet werden. Als Reiter ist immer eines zu sehen, die anderen sind einen Klick entfernt.',
                ui: [
                    'options' => GroupWidgetLayout::LAYOUTS,
                    'group' => 'arrangement',
                    'groupLabel' => 'Anordnung',
                ],
            ),
            PropertyDTO::create(
                name: 'columns',
                value: GroupWidgetLayout::DEFAULT_COLUMNS,
                type: 'int',
                isOptional: true,
                label: 'Spalten',
                ui: [
                    'min' => GroupWidgetLayout::MIN_COLUMNS,
                    'max' => GroupWidgetLayout::MAX_COLUMNS,
                    'group' => 'arrangement',
                ],
                conditions: [PropertyConditionDTO::whenAll([$layoutIsNot(GroupWidgetLayout::LAYOUT_GRID)])->thenHidden()],
            ),
            PropertyDTO::create(
                name: 'align',
                value: 'stretch',
                type: 'string',
                isOptional: true,
                label: 'Vertikal',
                ui: [
                    'options' => GroupWidgetLayout::options(GroupWidgetLayout::ALIGNS),
                    'group' => 'arrangement',
                ],
                conditions: [PropertyConditionDTO::whenAll([$layoutIsNot(GroupWidgetLayout::LAYOUT_ROW)])->thenHidden()],
            ),
            PropertyDTO::create(
                name: 'minWidth',
                value: GroupWidgetLayout::DEFAULT_MIN_WIDTH,
                type: 'int',
                isOptional: true,
                label: 'Mindestbreite (px)',
                description: 'Ist für ein Unterwidget weniger Platz, rutscht es in die nächste Zeile - so bleibt die Gruppe auch auf dem Handy lesbar.',
                ui: [
                    'min' => GroupWidgetLayout::MIN_WIDTH_FLOOR,
                    'max' => GroupWidgetLayout::MIN_WIDTH_CEILING,
                    'group' => 'arrangement',
                ],
                conditions: [PropertyConditionDTO::whenAny([
                    $layoutIs(GroupWidgetLayout::LAYOUT_COLUMN),
                    $layoutIs(GroupWidgetLayout::LAYOUT_TABS),
                ])->thenHidden()],
            ),
            PropertyDTO::create(
                name: 'gap',
                value: 'medium',
                type: 'string',
                isOptional: true,
                label: 'Abstand',
                ui: [
                    'options' => GroupWidgetLayout::options(GroupWidgetLayout::GAPS),
                    'group' => 'arrangement',
                ],
            ),
            PropertyDTO::create(
                name: 'framed',
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Als eigene Karten',
                description: 'Jedes Unterwidget bekommt einen Rahmen in der Akzentfarbe, sonst stehen sie ohne Rahmen in der Gruppe.',
                ui: ['group' => 'look', 'groupLabel' => 'Darstellung'],
            ),
            PropertyDTO::create(
                name: 'showTitles',
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Titel anzeigen',
                ui: ['group' => 'look'],
                conditions: [PropertyConditionDTO::whenAll([$layoutIs(GroupWidgetLayout::LAYOUT_TABS)])->thenHidden()],
            ),
            PropertyDTO::create(
                name: self::SETTING_WIDGETS,
                value: [],
                type: 'array',
                isOptional: true,
                label: 'Unterwidgets',
                description: 'Die Widgets der Gruppe, in dieser Reihenfolge. Jedes hat die Einstellungen seines Typs, einen eigenen Titel und eine Breite: den Anteil an der Zeile (nebeneinander) oder die Zahl der Spalten (Raster).',
                ui: [
                    'input' => 'widgetGroup',
                    'class' => 'info-line--wide',
                    // Only the editor walks these; saving and validating never
                    // build them (see LazyList).
                    'children' => new LazyList(fn(): array => $this->describeChildren($children)),
                    'types' => new LazyList(fn(): array => $this->typeMasks()),
                    'sizes' => GroupWidgetChildren::SIZES,
                    'maxChildren' => GroupWidgetChildren::MAX_CHILDREN,
                ],
            ),
        ];
    }

    /**
     * The picked sub widgets as the editor shows them: each with the mask of
     * its type, resolved against and filled with its own values.
     *
     * @param list<array{name: string, title: string, props: array, size: int, enabled: bool}> $children
     *
     * @return list<array<string, mixed>>
     */
    private function describeChildren(array $children): array
    {
        $allowed = $this->nestableWidgetNames();
        $described = [];

        foreach ($children as $child) {
            $available = in_array($child['name'], $allowed, true);
            $settings = $available
                ? array_values($this->widgetProvider->getResolvedSettingDefinitions($child['name'], $child['props']))
                : [];

            $described[] = [
                ...$child,
                'label' => GroupWidgetChildren::label($child),
                'shortName' => GroupWidgetChildren::shortName($child['name']),
                'available' => $available,
                'settings' => $settings,
                'values' => self::flatValues($settings, $child['props']),
            ];
        }

        return $described;
    }

    /**
     * The mask of every type that can be added, unfilled - so a sub widget that
     * is added in the editor has its settings at once, without asking the
     * server again. Deliberately not cached on the service: the types depend
     * on the user, and a worker process outlives the request.
     *
     * @return list<array{name: string, label: string, settings: PropertyDTO[]}>
     */
    private function typeMasks(): array
    {
        $masks = [];
        foreach ($this->nestableWidgetNames() as $name) {
            $masks[] = [
                'name' => $name,
                'label' => GroupWidgetChildren::shortName($name),
                'settings' => array_values($this->widgetProvider->getResolvedSettingDefinitions($name)),
            ];
        }

        return $masks;
    }

    /** @return list<string> */
    private function nestableWidgetNames(): array
    {
        return $this->widgetProvider->getSelectableWidgetNames(self::NOT_NESTABLE);
    }

    /**
     * The values a mask starts out with, keyed by the name of the setting -
     * including the dotted ones, whose value sits nested inside the props.
     *
     * @param PropertyDTO[] $settings
     *
     * @return array<string, mixed>
     */
    private static function flatValues(array $settings, array $props): array
    {
        $values = [];
        foreach ($settings as $setting) {
            $value = PropertyValuePath::read($props, $setting->name);
            if (!is_null($value)) {
                $values[$setting->name] = $value;
            }
        }

        return $values;
    }
}
