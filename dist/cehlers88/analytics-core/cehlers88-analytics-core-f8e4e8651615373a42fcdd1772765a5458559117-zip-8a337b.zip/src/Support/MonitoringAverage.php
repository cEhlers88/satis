<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Support;

/**
 * The long-term average of a monitoring.
 *
 * A monitoring with an aggregation interval does not write every measurement
 * into its statistic. Its run interval is the sampling interval ("PT1M"), and
 * the samples of one aggregation window ("PT1H") are averaged into a single
 * point, written once the window is over - with the start of the window as
 * its timestamp, so the point of 10:00 is the mean from 10:00 to 11:00.
 *
 * The samples themselves are not kept: the open window lives in the statistic
 * options as a running sum and count (plus min and max), which keeps the
 * statistic small however short the sampling interval is.
 */
final class MonitoringAverage
{
    /** Where the open window is kept in the statistic options. */
    public const string OPTIONS_KEY = 'average';

    /**
     * How many empty windows are stepped over one by one after a pause before
     * the bulk of them is jumped at once.
     */
    private const int MAX_SKIPPED_WINDOWS = 1000;

    /**
     * Whether an aggregation interval can be used: an ISO 8601 duration that
     * moves time forward.
     */
    public static function isValidInterval(?string $interval): bool
    {
        return self::parseInterval($interval) !== null;
    }

    /**
     * Add one sample to the open window.
     *
     * @param array<string, mixed> $state The window as a previous call left it ([] for none)
     * @param mixed                $value The current value of the attribute
     * @param int                  $now   The time of the sample
     *
     * @return array{state: array<string, mixed>, point: ?array{value: float, timestamp: int, count: int}}
     *         The window to keep and, when a window was closed, its average.
     */
    public static function addSample(array $state, mixed $value, int $now, string $interval): array
    {
        $duration = self::parseInterval($interval);
        if ($duration === null) {
            return ['state' => $state, 'point' => null];
        }

        $start = is_int($state['start'] ?? null) ? $state['start'] : null;
        // A changed interval starts afresh - the open window would mix both.
        if ($start === null || ($state['interval'] ?? null) !== $interval || $now < $start) {
            $state = self::openWindow(self::alignStart($now, $duration), $interval);
        }

        $point = null;
        $end = self::add($state['start'], $duration);
        if ($now >= $end) {
            $count = (int)($state['count'] ?? 0);
            if ($count > 0) {
                $point = [
                    'value' => (float)$state['sum'] / $count,
                    'timestamp' => (int)$state['start'],
                    'count' => $count,
                ];
            }

            // The next window follows the closed one, so the windows stay on
            // the grid; windows nothing was measured in are left out.
            $nextStart = self::fastForward($end, $duration, $now);
            $state = self::openWindow($nextStart, $interval);
        }

        $sample = self::toNumber($value);
        if ($sample !== null) {
            $state['sum'] = (float)$state['sum'] + $sample;
            $state['count'] = (int)$state['count'] + 1;
            $state['min'] = $state['min'] === null ? $sample : min((float)$state['min'], $sample);
            $state['max'] = $state['max'] === null ? $sample : max((float)$state['max'], $sample);
        }
        $state['lastSampleAt'] = $now;

        return ['state' => $state, 'point' => $point];
    }

    /**
     * The value a sample counts with: numbers as they are, yes/no as 1/0 (so
     * the average is the share of the time it was true). Anything else is no
     * sample.
     */
    public static function toNumber(mixed $value): ?float
    {
        if (is_bool($value)) {
            return $value ? 1.0 : 0.0;
        }
        if (is_int($value) || is_float($value)) {
            return is_finite((float)$value) ? (float)$value : null;
        }
        if (!is_string($value)) {
            return null;
        }

        $trimmed = trim($value);
        if (is_numeric($trimmed)) {
            return (float)$trimmed;
        }

        return match (strtolower($trimmed)) {
            'true' => 1.0,
            'false' => 0.0,
            default => null,
        };
    }

    /**
     * The start of the window a time falls into when no window is open yet:
     * at the full minute, hour or day of the largest unit of the interval, so
     * hourly averages begin at 10:00 and not at 10:17.
     */
    public static function alignStart(int $timestamp, \DateInterval $duration): int
    {
        $time = new \DateTimeImmutable()->setTimestamp($timestamp);

        if ($duration->y > 0 || $duration->m > 0 || $duration->d > 0) {
            return $time->setTime(0, 0)->getTimestamp();
        }
        if ($duration->h > 0) {
            return $time->setTime((int)$time->format('H'), 0)->getTimestamp();
        }
        if ($duration->i > 0) {
            return $time->setTime((int)$time->format('H'), (int)$time->format('i'))->getTimestamp();
        }

        return $timestamp;
    }

    /**
     * The start of the window $now falls into, counted on from $start.
     *
     * Windows are stepped one by one so calendar lengths (months, a day with
     * a clock change) stay exact. After a long pause the bulk is jumped by
     * the current window length first and the rest stepped again, which
     * keeps the grid of the windows for fixed lengths.
     */
    private static function fastForward(int $start, \DateInterval $duration, int $now): int
    {
        $length = self::add($start, $duration) - $start;
        $pending = intdiv(max(0, $now - $start), max(1, $length));
        if ($pending > self::MAX_SKIPPED_WINDOWS) {
            $start += ($pending - 1) * $length;
        }

        while (self::add($start, $duration) <= $now) {
            $start = self::add($start, $duration);
        }
        // A jump past a longer calendar unit can overshoot; step back onto $now.
        while ($start > $now) {
            $start = new \DateTimeImmutable()->setTimestamp($start)->sub($duration)->getTimestamp();
        }

        return $start;
    }

    /**
     * @return array{interval: string, start: int, sum: float, count: int, min: ?float, max: ?float}
     */
    private static function openWindow(int $start, string $interval): array
    {
        return [
            'interval' => $interval,
            'start' => $start,
            'sum' => 0.0,
            'count' => 0,
            'min' => null,
            'max' => null,
        ];
    }

    private static function add(int $timestamp, \DateInterval $duration): int
    {
        return new \DateTimeImmutable()->setTimestamp($timestamp)->add($duration)->getTimestamp();
    }

    private static function parseInterval(?string $interval): ?\DateInterval
    {
        $interval = trim((string)$interval);
        if ($interval === '') {
            return null;
        }

        try {
            $duration = new \DateInterval($interval);
        } catch (\Throwable) {
            return null;
        }

        // An interval of zero would never close its window.
        $reference = new \DateTimeImmutable('@0');

        return $reference->add($duration) > $reference && $duration->invert === 0 ? $duration : null;
    }
}
