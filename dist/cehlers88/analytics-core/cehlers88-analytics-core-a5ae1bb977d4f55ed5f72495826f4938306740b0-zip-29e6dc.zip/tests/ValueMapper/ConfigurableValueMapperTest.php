<?php

namespace Cehlers88\AnalyticsCore\Tests\ValueMapper;

use Cehlers88\AnalyticsCore\ValueMapper\ConfigurableValueMapper;
use Cehlers88\AnalyticsCore\ValueMapper\Configuration\ValueMapperConfiguration;
use PHPUnit\Framework\TestCase;

class ConfigurableValueMapperTest extends TestCase
{
    public function test1()
    {
        $mapper = new ConfigurableValueMapper();

        $this->assertSame(true, $mapper->map(true));
        $this->assertSame(1, $mapper->map(1));
        $this->assertSame('2', $mapper->map('2'));
        $this->assertSame(true, $mapper->map(true));
        $this->assertSame(false, $mapper->map(false));
        $this->assertSame([1], $mapper->map([1]));

        $mapper->addConfiguration(new ValueMapperConfiguration());
        $this->assertSame('1', $mapper->map(1));
        $this->assertSame('2', $mapper->map('2'));
        $this->assertSame('true', $mapper->map(true));
        $this->assertSame('false', $mapper->map(false));
        $this->assertSame(['1'], $mapper->map([1]));

        $mapper = new ConfigurableValueMapper();
        $mapper->addConfiguration(new ValueMapperConfiguration('integer'));
        $this->assertSame(1, $mapper->map(1));
        $this->assertSame(2, $mapper->map('2'));
        $this->assertSame(1, $mapper->map(true));
        $this->assertSame(0, $mapper->map(false));

        $this->assertSame(0, $mapper->map(false));
    }
}
