<?php

namespace Cehlers88\AnalyticsCore\ValueMapper\Configuration;

class ValueMapperConfiguration
{

    public function __construct(
        private string $outputType = 'string',
        private string $requiredName = '',
        private string $requiredInputType = '',
    )
    {
    }

    public function canHandle(string $address, $value): bool
    {
        if ($this->requiredInputType !== '') {

        }
        if ($this->requiredName === '') {
            return true;
        }

        $addressSplit = explode('.', $address);

        return true;
    }

    public function handle(mixed $value): mixed
    {
        switch ($this->outputType) {
            case 'string':
                if (gettype($value) === 'boolean') {
                    return $value ? 'true' : 'false';
                }
                return (string)$value;
            case 'int':
            case 'integer':
                return (int)$value;
            case 'float':
                return (float)$value;
        }

        return $value;
    }
}