<?php

namespace Cehlers88\AnalyticsCore\ValueMapper;

interface ValueMapperInterface
{
    public function map(mixed $value): mixed;
}