<?php

namespace Cehlers88\AnalyticsCore\ValueMapper;

abstract class AbstractValueMapper implements ValueMapperInterface
{
    public function map(mixed $value): mixed
    {
        return $this->_map('', $value);
    }

    private function _map(string $address, mixed $value): mixed
    {
        $type = gettype($value);
        switch ($type) {
            case 'string':
            case 'integer':
            case 'float':
            case 'boolean':
                return $this->evaluate($address, $value);
            case 'array':
                foreach ($value as $key => &$subValue) {
                    if (!empty($address)) {
                        $address .= '.';
                    }
                    $address .= $key;

                    $subValue = $this->_map($address, $subValue);
                }
        }

        return $value;
    }

    abstract protected function evaluate(string $address, mixed $value): mixed;
}