<?php

namespace Cehlers88\AnalyticsCore\ValueMapper;

use Cehlers88\AnalyticsCore\ValueMapper\Configuration\ValueMapperConfiguration;

class ConfigurableValueMapper extends AbstractValueMapper
{
    /** @var ValueMapperConfiguration[] */
    private array $configurations = [];

    public function addConfiguration(ValueMapperConfiguration $configuration): static
    {
        $this->configurations[] = $configuration;
        return $this;
    }

    protected function evaluate(string $address, mixed $value): mixed
    {
        foreach ($this->configurations as $configuration) {
            if ($configuration->canHandle($address, $value)) {
                $value = $configuration->handle($value);
            }
        }

        return $value;
    }
}