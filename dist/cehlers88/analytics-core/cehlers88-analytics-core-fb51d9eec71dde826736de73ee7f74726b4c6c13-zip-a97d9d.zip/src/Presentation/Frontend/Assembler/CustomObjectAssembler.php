<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\Client;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectAttributeJson;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use stdClass;


/** Assembler for converting Application entities to views. */
class CustomObjectAssembler extends AbstractAssembler
{
    protected string $viewClass = CustomObjectView::class;

    public function __construct(
        protected CustomObjectProvider $customObjectProvider,
        protected ClientRepository     $clientRepository,
        protected AssemblerProvider    $assemblerProvider
    )
    {
    }

    /**
     * @param CustomEntity $entity
     */
    public function assembleView(EntityInterface|AbstractCustomObject $entity): CustomObjectView
    {
        $childObjects = $entity->getChildObjects();

        /** @var CustomObjectAttributeJson[] $assembledAttributes */
        $assembledAttributes = $this->assemblerProvider
            ->getAssemblerForClass(CustomEntityAttribute::class, 'backend')
            ->many($entity->getAttributes(false));

        $attributes = [];
        $monitorings = [];

        /***/
        $childMap = new stdClass();

        /***/

        foreach ($assembledAttributes as $attribute) {
            $attributes[$attribute->name] = $attribute->value;

            if (str_ends_with($attribute->name, 'client_id')) {
                $client = $this->clientRepository->find($attribute->value);
                if (!empty($client)) {
                    $name = str_replace('client_id', 'client', $attribute->name);
                    $childMap->{$name} = count($childObjects);
                    $childObjects[] = $this->assemblerProvider
                        ->getAssemblerForClass($client::class)
                        ->one($client);
                }
            }

            foreach ($attribute->monitorings as $monitoring) {
                $monitorings[$attribute->name][] = $monitoring;
            }
        }

        /** @var CustomObjectView $view */
        $view = new $this->viewClass(
            attributes: $attributes,
            childObjects: $this->assemblerProvider->assemble($childObjects),
            className: $entity->getClassName(),
            id: $entity->getId(),
            name: $entity->getName(),
        );

        $view->config = $entity->getConfig();
        $view->templatePath = $entity->getTileTemplate() ?? '';
        $view->monitorings = $monitorings;
        $view->childMap = $childMap;

        return $this->enrichView($entity, $view);
    }

    protected function enrichView(EntityInterface|AbstractCustomObject $entity, CustomObjectView $view): CustomObjectView
    {
        return $view;
    }

    public function canHandle(string $className): bool
    {
        return $className === CustomEntity::class;
    }
}