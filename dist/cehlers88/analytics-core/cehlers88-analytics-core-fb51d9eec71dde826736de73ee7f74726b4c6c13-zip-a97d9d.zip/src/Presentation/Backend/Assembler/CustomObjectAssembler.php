<?php

namespace Cehlers88\AnalyticsCore\Presentation\Backend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Assembler\AssembledInterface;
use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectJson;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use stdClass;

class CustomObjectAssembler extends AbstractAssembler
{
    public function __construct(
        private ClientRepository  $clientRepository,
        private AssemblerProvider $assemblerProvider
    )
    {

    }

    /**
     * @param CustomEntity $entity
     */
    public function assembleJson(EntityInterface|AbstractCustomObject $entity): AssembledInterface
    {
        $attributes = [];
        $childObjects = method_exists($entity, 'getChildObjects') ? $entity->getChildObjects() : [];
        $childMap = new stdClass();

        $entityAttributes = $entity->getAttributes();
        foreach ($entityAttributes as $key => $attribute) {
            $name = is_string($attribute) ? $key : $attribute->getName();
            $value = is_string($attribute) ? $attribute : $attribute->getValue();
            $attributes[$name] = $value;

            if (str_ends_with($name, 'client_id')) {
                $client = $this->clientRepository->find($value);
                if (!empty($client)) {
                    $name = str_replace('client_id', 'client', $name);
                    $childMap->{$name} = count($childObjects);
                    $childObjects[] = $this->assemblerProvider
                        ->getAssemblerForClass($client::class)
                        ->one($client);
                }
            }
        }

        $assembledCustomObject = new CustomObjectJson(
            $entity->getId(),
            $entity->getClassName(),
            $entity->getName(),
            $attributes,
            $childObjects
        );

        $assembledCustomObject->config = $entity->getConfig();
        $assembledCustomObject->childMap = $childMap;

        return $assembledCustomObject;
    }

    public function canHandle(string $className): bool
    {
        return $className === CustomEntity::class;
    }
}