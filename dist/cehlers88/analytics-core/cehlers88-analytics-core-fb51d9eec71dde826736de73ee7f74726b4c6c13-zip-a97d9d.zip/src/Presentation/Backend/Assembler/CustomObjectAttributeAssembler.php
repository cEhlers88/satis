<?php

namespace Cehlers88\AnalyticsCore\Presentation\Backend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Assembler\AssembledInterface;
use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectAttributeJson;
use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectJson;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;

class CustomObjectAttributeAssembler extends AbstractAssembler
{

    /**
     * @param CustomEntityAttribute $entity
     */
    public function assembleJson(EntityInterface|AbstractCustomObject $entity): AssembledInterface
    {
        $name = $entity->getName();

        $json = new CustomObjectAttributeJson(
            $entity->getId(),
            $name,
            $entity->getValue()
        );


        foreach ($entity->getMonitorings() as $monitoring) {
            $statistic = $monitoring->getStatistic();
            $statisticDetails = empty($statistic) ? [] : $statistic->getDetails();
            $options = empty($statisticDetails) ? [] : $statisticDetails['options'];
            $statisticValues = [];
            if (
                !empty($statisticDetails) &&
                isset($options['monitoredAttribute'])
            ) {

                $statisticValues = $statisticDetails[$options['monitoredAttribute']];
            }

            $json->monitorings[] = [
                'id' => $monitoring->getId(),
                'interval' => $monitoring->getRunInterval(),
                'statistics' => $statisticValues,
            ];
        }

        return $json;
    }

    public function canHandle(string $className): bool
    {
        return $className === CustomEntityAttribute::class;
    }
}