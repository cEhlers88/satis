<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\UserInteractionRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: UserInteractionRepository::class)]
class UserInteraction extends AbstractEntity
{
    #[ORM\Column(length: 255)]
    private ?string $refClass = null;

    #[ORM\Column]
    private ?int $refId = null;

    #[ORM\Column]
    private ?int $priority = null;

    #[ORM\Column(length: 255)]
    private ?string $interactionKey = null;

    #[ORM\Column(length: 255)]
    private ?string $subject = null;

    #[ORM\Column]
    private array $data = [];

    #[ORM\Column]
    private array $requiredRoles = [];

    public function getRefClass(): ?string
    {
        return $this->refClass;
    }

    public function setRefClass(string $refClass): static
    {
        $this->refClass = $refClass;

        return $this;
    }

    public function getRefId(): ?int
    {
        return $this->refId;
    }

    public function setRefId(int $refId): static
    {
        $this->refId = $refId;

        return $this;
    }

    public function getPriority(): ?int
    {
        return $this->priority;
    }

    public function setPriority(int $priority): static
    {
        $this->priority = $priority;

        return $this;
    }

    public function getInteractionKey(): ?string
    {
        return $this->interactionKey;
    }

    public function setInteractionKey(string $interactionKey): static
    {
        $this->interactionKey = $interactionKey;

        return $this;
    }

    public function getSubject(): ?string
    {
        return $this->subject;
    }

    public function setSubject(string $subject): static
    {
        $this->subject = $subject;

        return $this;
    }

    public function getData(): array
    {
        return $this->data;
    }

    public function setData(array $data): static
    {
        $this->data = $data;

        return $this;
    }

    public function getRequiredRoles(): array
    {
        return $this->requiredRoles;
    }

    public function setRequiredRoles(array $requiredRoles): static
    {
        $this->requiredRoles = $requiredRoles;

        return $this;
    }
}
