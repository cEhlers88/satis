<?php

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\DTO\ValidationResultDTO;
use Cehlers88\AnalyticsCore\Security\Doorman;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Symfony\Component\HttpFoundation\Request;

interface ServiceEndpointRunnerInterface
{
    public function canHandle(string $endpoint, Request $request): bool;

    public function runEndpoint(string $endpointName, Request $request): ServiceEndpointRunnerResultDTO;

    public function setDoorman(Doorman $doorman): self;

    public function getEndpoints(): mixed;

    public function getDescription(string $endpointName, array $methods): string;

    /**
     * @return RoleDTO[]
     */
    public function getRequiredRoles(): array;

    /**
     * @return EndpointDefinitionDTO[]
     */
    public function getEndpointDefinitions(): array;

    public function validate(string $endpointName, Request $request): ValidationResultDTO;
}