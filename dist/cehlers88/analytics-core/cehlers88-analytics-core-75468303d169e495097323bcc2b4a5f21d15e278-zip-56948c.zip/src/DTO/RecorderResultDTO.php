<?php

namespace Cehlers88\AnalyticsCore\DTO;

class RecorderResultDTO extends ResultDTO
{
    public string $recorderId;
}