<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class PropertyDTO extends DTO
{
    public bool $allowMonitoring = false;

    public bool $isDefaultValue = true;

    public bool $isOptional = false;

    public array $groups = [];

    public string $name = '';

    public string $label = '';

    public mixed $value = null;
    public bool $hasSubCommand = false;
    public bool $hasConditionGroups = false;

    public string $type = 'mixed';

    public string $description = '';

    public array $ui = [        // special ui properties
        'class' => '',          // specify additional css-class for this property
        'displayName' => null,  // specify a different display name for this property in the UI
    ];

    private function __construct()
    {
    }

    public static function create(
        string $name,
        mixed  $value,
        string $type = 'mixed',
        bool   $isOptional = false,
        string $label = '',
        bool   $allowMonitoring = false
    ): static
    {
        $dto = new static();
        $dto->allowMonitoring = $allowMonitoring;
        $dto->name = $name;
        $dto->label = empty($label) ? $name : $label;
        $dto->type = $type;
        $dto->value = $value;
        $dto->isOptional = $isOptional;
        return $dto;
    }

    /**
     * Creates an instance of the class from the given array.
     *
     * @param array $data An array containing the data to populate the instance.
     *                    Expected keys are in the order of type, name, and optionally value.
     *
     * @return static A new instance of the class populated with the provided data.
     */
    public static function createFromArray(array $data): static
    {
        $dto = new static();
        $dto->type = $data[0];
        $dto->name = $data[1];
        $dto->value = $data[2] ?? null;;
        $dto->isOptional = isset($data[2]);
        return $dto;
    }

    public function toArray()
    {
        $result = [$this->type, $this->name, $this->value];
        return $result;
    }

    public function toAssociativeArray()
    {
        return [
            'allowMonitoring' => $this->allowMonitoring,
            'label' => $this->label,
            'name' => $this->name,
            'type' => $this->type,
            'value' => $this->value,
            'isOptional' => $this->isOptional,
            'groups' => $this->groups,
            'hasSubCommand' => $this->hasSubCommand,
            'hasConditionGroups' => $this->hasConditionGroups,
        ];
    }
}