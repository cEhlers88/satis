<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class RoleDTO extends DTO
{
    public string $name = '';

    public static function create(string $name): RoleDTO
    {
        $dto = new RoleDTO();
        $dto->name = $name;

        return $dto;
    }

    public function __toString(): string
    {
        return $this->name;
    }
}