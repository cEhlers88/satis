<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class ExtendedRoleDTO extends RoleDTO
{
    /** @var string[]|RoleDTO[] $roles */
    public array $roles = [];

    public static function createAnyOf(...$roles): ExtendedRoleDTO
    {
        $dto = new ExtendedRoleDTO();
        $dto->name = 'anyOf';
        $dto->roles = $roles;

        return $dto;
    }

    public static function createAllOf(...$roles): ExtendedRoleDTO
    {
        $dto = new ExtendedRoleDTO();
        $dto->name = 'allOf';
        $dto->roles = $roles;

        return $dto;
    }

    public static function createNoneOf(...$roles): ExtendedRoleDTO
    {
        $dto = new ExtendedRoleDTO();
        $dto->name = 'noneOf';
        $dto->roles = $roles;

        return $dto;
    }

    public function __toString(): string
    {
        $roles = array_map(fn($role) => (string)$role, $this->roles);
        return $this->name . '_[' . implode(', ', $roles) . ']';
    }
}