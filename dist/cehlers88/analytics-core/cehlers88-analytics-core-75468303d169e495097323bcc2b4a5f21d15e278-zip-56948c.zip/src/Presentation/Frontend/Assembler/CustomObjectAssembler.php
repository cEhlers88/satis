<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\Client;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectAttributeJson;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use stdClass;


/** Assembler for converting Application entities to views. */
class CustomObjectAssembler extends AbstractAssembler
{
    protected string $viewClass = CustomObjectView::class;

    public function __construct(
        protected CustomObjectProvider $customObjectProvider,
        protected ClientRepository     $clientRepository,
        protected AssemblerProvider    $assemblerProvider
    )
    {
    }

    /**
     * @param CustomEntity $entity
     */
    public function assembleView(EntityInterface|AbstractCustomObject $entity): CustomObjectView
    {
        $childObjectsByEntity = $entity->getChildObjects();

        /** @var CustomObjectAttributeJson[] $assembledAttributes */
        $assembledAttributes = $this->assemblerProvider
            ->getAssemblerForClass(CustomEntityAttribute::class, 'backend')
            ->many($entity->getAttributes(false));

        $monitorings = [];
        $childMap = new stdClass();

        /** @var CustomObjectView $view */
        $view = new $this->viewClass(
            attributes: $assembledAttributes,
            childObjects: [],
            className: $entity->getClassName(),
            id: $entity->getId(),
            name: $entity->getName(),
        );

        foreach ($assembledAttributes as $attribute) {
            $view->attribute->{$attribute->name} = $attribute->value;
            $view->attributeIds->{$attribute->name} = $attribute->id;

            if (str_ends_with($attribute->name, 'client_id')) {
                $client = $this->clientRepository->find($attribute->value);
                if (!empty($client)) {
                    $name = str_replace('client_id', 'client', $attribute->name);
                    $view->childMap->{$name} = count($view->childObjects);
                    $view->childObjects[] = $this->assemblerProvider
                        ->getAssemblerForClass($client::class)
                        ->one($client);
                }
            } else if (str_ends_with($attribute->name, 'device_id')) {
                $device = $this->customObjectProvider->getCustomObjectById($attribute->value);
                if (!empty($device)) {
                    $name = str_replace('device_id', 'device', $attribute->name);
                    $view->childMap->{$name} = count($view->childObjects);
                    $view->childObjects[] = $this->one($device);
                }
            }

            foreach ($attribute->monitorings as $monitoring) {
                $monitorings[$attribute->name][] = $monitoring;
            }
        }

        foreach ($this->many($childObjectsByEntity) as $childObjectPerEntity) {
            $alreadyDefined = false;
            foreach ($view->childObjects as $childObject) {
                if ($childObject->id === $childObjectPerEntity->id) {
                    $alreadyDefined = true;
                    break;
                }
            }
            if ($alreadyDefined) continue;
            $view->childObjects[] = $childObjectPerEntity;
        }

        $view->config = $entity->getConfig();
        //$view->childObjects = $this->assemblerProvider->assemble($childObjects);
        $view->templatePath = $entity->getTileTemplate() ?? '';
        $view->monitorings = $monitorings;

        return $this->enrichView($entity, $view);
    }

    protected function enrichView(EntityInterface|AbstractCustomObject $entity, CustomObjectView $view): CustomObjectView
    {
        return $view;
    }

    public function canHandle(string $className): bool
    {
        return $className === CustomEntity::class;
    }
}