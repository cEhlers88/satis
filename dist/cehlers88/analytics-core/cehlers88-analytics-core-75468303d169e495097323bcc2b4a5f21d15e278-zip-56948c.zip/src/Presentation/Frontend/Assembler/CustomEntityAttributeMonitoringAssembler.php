<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttributeMonitoring;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomEntityAttributeMonitoringView;

class CustomEntityAttributeMonitoringAssembler extends AbstractAssembler
{
    /**
     * @param CustomEntityAttributeMonitoring $entity
     */
    public function assembleView(EntityInterface|AbstractCustomObject $entity): CustomEntityAttributeMonitoringView
    {

        $view = new CustomEntityAttributeMonitoringView(
            id: $entity->getId(),
        );

        return $view;
    }

    public function canHandle(string $className): bool
    {
        return $className === CustomEntityAttributeMonitoring::class;
    }
}