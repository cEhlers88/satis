<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectJson;

/** View representation of an Application entity. */
class CustomObjectView extends CustomObjectJson implements ViewInterface
{
    public ?string $templatePath = null;

}