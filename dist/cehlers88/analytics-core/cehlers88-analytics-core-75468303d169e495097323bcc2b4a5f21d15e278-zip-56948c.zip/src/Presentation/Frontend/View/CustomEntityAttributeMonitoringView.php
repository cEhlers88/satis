<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;

/** View representation of an Application entity. */
class CustomEntityAttributeMonitoringView implements ViewInterface
{
    public function __construct(
        public int $id,

    )
    {

    }
}