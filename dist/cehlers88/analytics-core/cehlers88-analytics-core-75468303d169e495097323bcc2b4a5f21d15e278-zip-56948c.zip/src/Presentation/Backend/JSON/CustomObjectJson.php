<?php

namespace Cehlers88\AnalyticsCore\Presentation\Backend\JSON;

use Cehlers88\AnalyticsCore\Presentation\Assembler\AssembledInterface;

class CustomObjectJson implements AssembledInterface
{

    public \stdClass $attribute;
    public \stdClass $attributeIds;
    public array $config = [];

    public array $monitorings = [];
    public string $titleBadgeText = '';

    public string $titlePrefix = '';
    public \stdClass $childMap;
    protected array $userInteractions = [];

    public function __construct(
        public int    $id,
        public string $className,
        public string $name,
        public array  $attributes,
        public array  $childObjects
    )
    {
        $this->attribute = new \stdClass();
        $this->attributeIds = new \stdClass();
        $this->childMap = new \stdClass();
    }

    public function getUserInteractions(): array
    {
        return $this->userInteractions;
    }

    public function setUserInteractions(array $userInteractions): self
    {
        $this->userInteractions = $userInteractions;
        return $this;
    }
}