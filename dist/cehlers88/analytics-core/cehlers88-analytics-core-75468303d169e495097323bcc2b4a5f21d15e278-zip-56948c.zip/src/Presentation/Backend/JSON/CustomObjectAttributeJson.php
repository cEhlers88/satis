<?php

namespace Cehlers88\AnalyticsCore\Presentation\Backend\JSON;

use Cehlers88\AnalyticsCore\Presentation\Assembler\AssembledInterface;

class CustomObjectAttributeJson implements AssembledInterface
{
    public array $monitorings = [];

    public function __construct(
        public int    $id,
        public string $name,
        public mixed  $value,
    )
    {
    }
}