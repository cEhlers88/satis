<?php

namespace Cehlers88\AnalyticsCore\Presentation\Service;

use Cehlers88\AnalyticsCore\Presentation\Assembler\AssembledInterface;
use Cehlers88\AnalyticsCore\Presentation\Assembler\AssemblerInterface;

class AssemblerProvider
{
    public function __construct(
        /** @var AssemblerInterface[] $assemblers */
        private iterable $assemblers
    )
    {

    }

    public function assemble(mixed $singleOrMultipleEntities): mixed
    {
        if ($singleOrMultipleEntities instanceof AssembledInterface) {
            return $singleOrMultipleEntities;
        }
        if (!is_array($singleOrMultipleEntities)) {
            $assembler = $this->getAssemblerForClass($singleOrMultipleEntities::class);
            return $this->getAssemblerForClass($singleOrMultipleEntities::class)->one($singleOrMultipleEntities);
        }
        return array_map(fn($entity) => $this->assemble($entity), $singleOrMultipleEntities);
    }

    public function getAssemblerForClass(string $class, string $for = 'view'): ?AssemblerInterface
    {
        foreach ($this->assemblers as $assembler) {
            if ($assembler->canHandle($class) && $assembler->getUseFor() === $for) {
                return $assembler;
            }
        }
        return null;
    }
}