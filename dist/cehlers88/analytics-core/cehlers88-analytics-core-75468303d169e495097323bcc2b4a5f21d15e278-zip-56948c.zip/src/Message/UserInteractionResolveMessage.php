<?php

namespace Cehlers88\AnalyticsCore\Message;

final class UserInteractionResolveMessage
{
    public function __construct(
        public readonly string    $messageId,
        public readonly int       $userId,
        public readonly int       $userInteractionId,
        public readonly \stdClass $formData,
        public readonly string    $functionName,
        public readonly \stdClass $functionArgs,
    )
    {

    }
}