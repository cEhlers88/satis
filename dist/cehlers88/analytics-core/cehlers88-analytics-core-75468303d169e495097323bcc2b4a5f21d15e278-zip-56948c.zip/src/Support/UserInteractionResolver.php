<?php

namespace Cehlers88\AnalyticsCore\Support;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\DTO\ResultDTO;
use Cehlers88\AnalyticsCore\Entity\UserInteraction;
use Cehlers88\AnalyticsCore\Message\UserInteractionResolveMessage;
use Cehlers88\AnalyticsCore\Security\Doorman;
use Cehlers88\AnalyticsCore\Support\UserInteractionFunction\UserInteractionFunctionInterface;
use Symfony\Component\Messenger\MessageBusInterface;
use Symfony\Component\Security\Core\User\UserInterface;

class UserInteractionResolver
{
    private \stdClass|null $_formData = null;

    private string $_functionName = '';

    private \stdClass|null $_functionArgs = null;

    private bool $_runAsynchronously = false;

    private ?UserInteraction $_userInteraction = null;

    private ?UserInterface $_user = null;

    /**
     * @param UserInteractionFunctionInterface[] $userInteractionFunctions
     */
    public function __construct(
        private Doorman             $doorman,
        private MessageBusInterface $messageBus,
        private iterable            $userInteractionFunctions
    )
    {
        $this->_user = $this->doorman->getUser();
    }

    public function setFormData(\stdClass|null $formData): self
    {
        $this->_formData = $formData ?? new \stdClass();
        return $this;
    }

    public function setFunctionName(string $functionName): self
    {
        $this->_functionName = $functionName;
        return $this;
    }

    public function setFunctionArgs(\stdClass $functionArgs): self
    {
        $this->_functionArgs = $functionArgs;
        return $this;
    }

    public function setRunAsynchronously(bool $runAsynchronously): self
    {
        $this->_runAsynchronously = $runAsynchronously;
        return $this;
    }

    public function setUserInteraction(UserInteraction $userInteraction): self
    {
        $this->_userInteraction = $userInteraction;
        return $this;
    }

    public function resolve(): ResultDTO
    {
        $requiredRules = ['USER_INTERACTION_RESOLVER'];
        $doneMessage = '';

        if (!empty($this->_user)) {
            $this->doorman->setUser($this->_user);
            $doneMessage .= 'User "' . $this->_user->getUserIdentifier() . '" starts';
        } else {
            $doneMessage .= 'Anonymous user starts';
        }
        if (!empty($this->_userInteraction)) {
            $doneMessage .= ' resolving interaction(#' . $this->_userInteraction->getId() . ')';
            $requiredRules = [
                ...$requiredRules,
                ... $this->_userInteraction->getRequiredRoles()
            ];
        }

        $this->doorman->setRequiredRoles($requiredRules);
        if (!$this->doorman->checkPermission()) {
            return ResultDTO::createError($doneMessage . ' but failed on access check.', 400, [
                ErrorDTO::create(400, 'Permission denied', [
                    'messages' => $this->doorman->getMessages(),
                    'reasons' => $this->doorman->getReasons(),
                ])
            ]);
        }

        if ($this->_runAsynchronously) {
            $userInteractionResolveMessage = new UserInteractionResolveMessage(
                uniqid(),
                $this->_user?->getId() ?? -1,
                $this->_userInteraction?->getId() ?? -1,
                $this->_formData,
                $this->_functionName,
                $this->_functionArgs
            );

            //$this->messageBus->dispatch($userInteractionResolveMessage);

            return ResultDTO::createSuccess($doneMessage . ' by using async message(#' . $userInteractionResolveMessage->messageId . ').', [
                'messageId' => $userInteractionResolveMessage->messageId,
            ]);
        }

        $doneMessage .= '. Try to take over users choices';
        try {
            $result = $this->_resolveFunction($this->_functionName, $this->_functionArgs);

            if (empty($result)) {
                return ResultDTO::createError($doneMessage .
                    ' but failed on function call (no handler for "' . $this->_functionName . '" found).'
                    , 404);
            }
            return $result;

        } catch (\Exception $e) {
            $doneMessage .= ' and failed:' . $e->getMessage();
            return ResultDTO::createError($doneMessage);
        }
    }

    public function setUser(UserInterface $user): self
    {
        $this->_user = $user;
        return $this;
    }

    private function _resolveFunction(string $functionName, mixed $functionArguments): ResultDTO|null
    {
        foreach ($this->userInteractionFunctions as $userInteractionFunction) {
            if ($userInteractionFunction->canHandle($functionName, $functionArguments)) {
                return $userInteractionFunction->handle($functionName, $this->_enrichArgumentsWithFormData($functionArguments));
            }
        }

        return null;
    }

    private function _enrichArgumentsWithFormData(\stdClass $arguments): \stdClass
    {
        foreach ($arguments as $key => $value) {
            if ($value instanceof \stdClass) {
                if (isset($value->source) && $value->source === 'formField' && isset($value->sourceDetails)) {
                    $arguments->{$key} = $this->_formData->{$value->sourceDetails} ?? $value;
                }
            }
        }

        return $arguments;
    }
}