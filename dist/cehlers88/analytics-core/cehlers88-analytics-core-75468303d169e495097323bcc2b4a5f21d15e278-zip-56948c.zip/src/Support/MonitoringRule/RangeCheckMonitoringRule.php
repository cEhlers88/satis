<?php

namespace Cehlers88\AnalyticsCore\Support\MonitoringRule;

use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;

class RangeCheckMonitoringRule extends AbstractMonitoringRule
{
    private int $called = 0;
    private string $reason = 'unbekannt';

    public function __construct(
        private CommandPlayer         $player,
        private MacroEnvironment      $macroEnvironment,
        private ApplicationRepository $applicationRepository,
    )
    {
    }

    public function execute(): self
    {
        $options = $this->getStatisticOptions() ?? [];
        $lastCalled = $options['called'] ?? 0;

        $commands = [];
        $this->reason = 'self(' . $this->_attributeToCheck->getValue() . ') ';
        if ($this->reachedMin()) {
            $this->reason .= 'min';
            if ($lastCalled >= 0) {
                $commands = $this->_arguments['onMin'] ?? [];
                $this->called = -1;
            }
        } else if ($this->reachedMax()) {
            $this->reason .= 'max';
            if ($lastCalled <= 0) {
                $commands = $this->_arguments['onMax'] ?? [];
                $this->called = 1;
            }
        } else {
            $this->called = 0;
            $this->reason .= 'normal';
        }
        $options['called'] = $this->called;
        $this->setStatisticOptions($options);

        $this->reason .= '(' . $this->_arguments['min'] . '/' . $this->_arguments['max'] . ')';

        if (!empty($commands)) {
            $this->macroEnvironment->setApplication(
                $this->applicationRepository->find($this->_arguments['applicationId'] ?? 1)
            );
            $this->player
                ->setMacroEnvironment($this->macroEnvironment)
                ->run($commands);
        }

        return $this;
    }

    private function reachedMin(?int $value = null): bool
    {
        if (is_null($value)) $value = $this->_attributeToCheck->getValue();
        return $value <= $this->_arguments['min'];
    }

    private function reachedMax(?int $value = null): bool
    {
        if (is_null($value)) $value = $this->_attributeToCheck->getValue();
        return $value >= $this->_arguments['max'];
    }

    public function getStatisticDetails(): array
    {
        return [
            ...parent::getStatisticDetails(),
            'reachedMin' => $this->reachedMin() ? 1 : 0,
            'reachedMax' => $this->reachedMax() ? 1 : 0,
            'called' => $this->called,
            'reason' => $this->reason,
        ];
    }

    public function validateArguments(array $arguments): bool
    {
        $requiredArguments = ['min', 'max'];

        foreach ($requiredArguments as $argument) {
            if (!isset($arguments[$argument])) {
                return false;
            }
        }

        return true;
    }
}