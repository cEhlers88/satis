<?php

namespace Cehlers88\AnalyticsCore\Support\UserInteractionFunction;

use Cehlers88\AnalyticsCore\DTO\ResultDTO;

interface UserInteractionFunctionInterface
{
    public function canHandle(string $functionName, mixed $functionArguments): bool;

    public function handle(string $functionName, mixed $functionArguments): ResultDTO;
}