<?php

namespace Cehlers88\AnalyticsCore\Support\UserInteractionFunction;

use Cehlers88\AnalyticsCore\DTO\ResultDTO;

abstract class AbstractUserInteractionFunction implements UserInteractionFunctionInterface
{
    public function canHandle(string $functionName, mixed $functionArguments): bool
    {
        foreach ($this->getFunctionCallbacks() as $name => $callback) {
            if ($name === $functionName) {
                return true;
            }
        }
        return false;
    }

    abstract public function getFunctionCallbacks(): array;

    public function handle(string $functionName, mixed $functionArguments): ResultDTO
    {
        foreach ($this->getFunctionCallbacks() as $name => $callback) {
            if ($name === $functionName) {
                try {
                    $result = call_user_func($callback, $functionArguments);
                    return ResultDTO::createSuccess('Done', $result);
                } catch (\Throwable $e) {
                    return ResultDTO::createError($e->getMessage(), 500);
                }
            }
        }
        return ResultDTO::createError('Function not found: ' . $functionName, 404);
    }

}