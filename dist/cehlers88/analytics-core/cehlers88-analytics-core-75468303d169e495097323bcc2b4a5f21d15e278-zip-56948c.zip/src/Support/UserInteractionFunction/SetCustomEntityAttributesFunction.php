<?php

namespace Cehlers88\AnalyticsCore\Support\UserInteractionFunction;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\ResultDTO;

class SetCustomEntityAttributesFunction extends AbstractUserInteractionFunction
{
    public function __construct(
        private readonly CustomObjectProvider $customObjectProvider
    )
    {

    }

    public function getFunctionCallbacks(): array
    {
        return [
            'set_custom_entity_attributes' => [$this, 'handleSetCustomEntityAttributes']
        ];
    }

    public function handleSetCustomEntityAttributes(\stdClass $data): ResultDTO
    {
        $attrs = [];
        $customObject = $this->customObjectProvider->getCustomObjectById($data->entityId);

        if (!$customObject) {
            return ResultDTO::createError('Custom entity not found');
        }

        foreach ($data as $attributeName => $attributeValue) {
            $attrs[$attributeName] = $attributeValue;
        }
        $this->customObjectProvider->updateAttributes(
            $customObject,
            $attrs
        );

        return ResultDTO::createSuccess($customObject->getName() . 'updated.', [
            'attrs' => $attrs
        ]);
    }
}