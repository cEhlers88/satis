<?php

namespace Cehlers88\AnalyticsCore\Support\UserInteractionFunction;

use Cehlers88\AnalyticsCore\DTO\ResultDTO;
use Cehlers88\AnalyticsCore\Repository\CustomEntityRepository;

class SetCustomEntityConfigFunction extends AbstractUserInteractionFunction
{
    public function __construct(
        private readonly CustomEntityRepository $customEntityRepository,
    )
    {
    }

    public function getFunctionCallbacks(): array
    {
        return [
            'set_custom_entity_config' => [$this, 'handleSetCustomEntityConfig']
        ];
    }

    public function handleSetCustomEntityConfig(\stdClass $data): ResultDTO
    {
        $customEntity = $this->customEntityRepository->find($data->entityId);
        if (empty($customEntity)) {
            return ResultDTO::createError('Custom entity not found');
        }

        $config = $customEntity->getConfig();
        foreach ($data->configs as $key => $value) {
            $config[$key] = $value;
        }
        $customEntity->setConfig($config);
        $this->customEntityRepository->save($customEntity);

        return ResultDTO::createSuccess('Done');
    }
}