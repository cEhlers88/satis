<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\CustomEntityAttributeMonitoring;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<CustomEntityAttributeMonitoring>
 */
class CustomEntityAttributeMonitoringRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CustomEntityAttributeMonitoring::class);
    }

    public function save(CustomEntityAttributeMonitoring $monitoring, bool $autoFlush = true): self
    {
        $this->getEntityManager()->persist($monitoring);
        if ($autoFlush) {
            $this->getEntityManager()->flush();
        }
        return $this;
    }

    public function flush(): self
    {
        $this->getEntityManager()->flush();
        return $this;
    }

}
