<?php

namespace Cehlers88\AnalyticsCore\CustomObject\Extension;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectInterface;

abstract class AbstractCustomObjectExtension implements CustomObjectExtensionInterface
{
    private ?array $_config = null;

    public function configure(array $config = [])
    {
        $this->_config = [
            ...$this->_config,
            ...$config
        ];
    }

    public function extend(CustomObjectInterface $customObject): CustomObjectInterface
    {
        return $customObject;
    }

    public function getExtensionType(): string
    {
        return '';
    }

    public function getFrontendDefinition(): array
    {
        return [];
    }

    public function getConfiguration(): array
    {
        if (is_null($this->_config)) {
            $this->reset();

            if (is_null($this->_config)) {
                throw new \RuntimeException('Configuration not set');
            }
        }

        return $this->_config;
    }

    public function reset(): void
    {
        $this->_config = [
            ''
        ];
    }
}