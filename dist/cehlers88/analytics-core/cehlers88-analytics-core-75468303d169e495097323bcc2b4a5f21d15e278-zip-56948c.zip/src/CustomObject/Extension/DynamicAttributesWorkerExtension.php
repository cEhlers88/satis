<?php

namespace Cehlers88\AnalyticsCore\CustomObject\Extension;

class DynamicAttributesWorkerExtension extends AbstractCustomObjectExtension
{
    public function reset(): void
    {
        parent::reset();
        
    }
}