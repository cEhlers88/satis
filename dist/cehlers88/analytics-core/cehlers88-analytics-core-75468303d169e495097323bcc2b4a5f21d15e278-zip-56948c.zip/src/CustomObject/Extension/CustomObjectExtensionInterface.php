<?php

namespace Cehlers88\AnalyticsCore\CustomObject\Extension;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectInterface;

interface CustomObjectExtensionInterface
{
    public const EXTENSION_TYPE_DYNAMIC_ATTRIBUTES_WORKER = 'dynamicAttributesWorker';

    public function configure(array $config = []);

    public function extend(CustomObjectInterface $customObject): CustomObjectInterface;

    public function getExtensionType(): string;

    public function getFrontendDefinition(): array;

    public function reset(): void;
}