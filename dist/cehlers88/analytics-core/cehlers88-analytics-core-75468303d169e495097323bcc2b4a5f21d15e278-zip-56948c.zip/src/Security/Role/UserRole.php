<?php

namespace Cehlers88\AnalyticsCore\Security\Role;

class UserRole implements RoleInterface
{
    public const NAME = 'ROLE_USER';

    public function getName(): string
    {
        return self::NAME;
    }

    public function getDescription(): string
    {
        return 'Standard Benutzerrolle.';
    }

    public function isMagicRole(): bool
    {
        return false;
    }
}