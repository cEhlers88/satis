<?php

namespace Cehlers88\AnalyticsCore\Security\Role;

interface RoleInterface
{
    public function getName(): string;

    public function getDescription(): string;

    public function isMagicRole(): bool;
}