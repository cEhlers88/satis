<?php

namespace Cehlers88\AnalyticsCore\Security\Role;

class BannedRole implements RoleInterface
{
    public const NAME = 'ROLE_BANNED';

    public function getName(): string
    {
        return self::NAME;
    }

    public function getDescription(): string
    {
        return 'Gebannte Benutzerrolle.';
    }

    public function isMagicRole(): bool
    {
        return false;
    }
}