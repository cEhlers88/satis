<?php

namespace Cehlers88\AnalyticsCore\Security\Role;

class AdminRole implements RoleInterface
{
    public const NAME = 'ROLE_ADMIN';

    public function getName(): string
    {
        return self::NAME;
    }

    public function getDescription(): string
    {
        return 'Administrative Benutzerrolle.';
    }

    public function isMagicRole(): bool
    {
        return false;
    }
}