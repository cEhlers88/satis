<?php

namespace Cehlers88\AnalyticsCore\Security\Role;

class IsAuthorizedRole implements RoleInterface
{
    public const NAME = 'IS_AUTHORIZED';

    public function getName(): string
    {
        return self::NAME;
    }

    public function getDescription(): string
    {
        return 'Ist in irgendeiner weise autorisiert. z.B. per IP, Login oder ...';
    }

    public function isMagicRole(): bool
    {
        return true;
    }
}