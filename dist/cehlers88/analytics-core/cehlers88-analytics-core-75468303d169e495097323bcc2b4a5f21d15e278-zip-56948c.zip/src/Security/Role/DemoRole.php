<?php

namespace Cehlers88\AnalyticsCore\Security\Role;

class DemoRole implements RoleInterface
{
    public const NAME = 'ROLE_DEMO';

    public function getName(): string
    {
        return self::NAME;
    }

    public function getDescription(): string
    {
        return 'Benutzerrolle für einen demonstrativen Zugriff';
    }

    public function isMagicRole(): bool
    {
        return false;
    }
}