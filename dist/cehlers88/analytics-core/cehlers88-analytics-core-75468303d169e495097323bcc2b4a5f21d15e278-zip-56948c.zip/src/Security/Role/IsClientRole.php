<?php

namespace Cehlers88\AnalyticsCore\Security\Role;

class IsClientRole implements RoleInterface
{
    public const NAME = 'IS_CLIENT#';

    public function getName(): string
    {
        return self::NAME;
    }

    public function getDescription(): string
    {
        return 'Gefolgt von der Client-ID kann so eine Rolle für einen bestimmten Client erstellt werden.';
    }

    public function isMagicRole(): bool
    {
        return true;
    }
}