<?php

namespace Cehlers88\AnalyticsCore\Security\MagicRole;

use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Symfony\Component\Security\Core\User\UserInterface;

class MagicRoleNoneOf extends AbstractMagicRole
{

    public function canHandle(string $roleName)
    {
        return str_starts_with($roleName, 'noneOf');
    }

    public function checkRole(RoleDTO $role): bool
    {
        foreach ($role->roles as $subRole) {
            if (call_user_func($this->getRoleResolver(), [$subRole])) return false;
        }

        return true;
    }
}