<?php

namespace Cehlers88\AnalyticsCore\Security\MagicRole;

use Cehlers88\AnalyticsCore\Entity\Application;
use Symfony\Component\Security\Core\User\UserInterface;

abstract class AbstractMagicRole implements MagicRoleInterface
{
    private ?Application $application = null;
    private ?string $clientIp = null;

    private mixed $roleResolver;

    private ?UserInterface $user = null;

    public function getApplication(): ?Application {
        return $this->application;
    }
    public function setApplication(?Application $application): self
    {
        $this->application = $application;
        return $this;
    }

    public function getUser(): ?UserInterface
    {
        return $this->user;
    }

    public function setUser(?UserInterface $user): self
    {
        $this->user = $user;
        return $this;
    }

    public function getClientIp(): ?string
    {
        return $this->clientIp;
    }

    public function setClientIp(?string $ip): self
    {
        $this->clientIp = $ip;
        return $this;
    }

    public function getRoleResolver(): callable
    {
        return $this->roleResolver;
    }

    public function setRoleResolver(callable $roleResolver): self
    {
        $this->roleResolver = $roleResolver;
        return $this;
    }
}