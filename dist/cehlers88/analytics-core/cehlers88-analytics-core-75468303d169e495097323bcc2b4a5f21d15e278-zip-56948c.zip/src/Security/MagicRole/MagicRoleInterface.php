<?php

namespace Cehlers88\AnalyticsCore\Security\MagicRole;

use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Symfony\Component\Security\Core\User\UserInterface;

interface MagicRoleInterface
{
    public function canHandle(string $roleName);

    public function checkRole(RoleDTO $role): bool;

    public function setApplication(?Application $application): self;

    public function setUser(?UserInterface $user): self;

    public function setClientIp(?string $ip): self;

    public function setRoleResolver(callable $roleResolver): self;
}