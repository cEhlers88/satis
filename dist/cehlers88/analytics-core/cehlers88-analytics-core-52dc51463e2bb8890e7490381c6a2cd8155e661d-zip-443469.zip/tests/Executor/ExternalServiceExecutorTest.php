<?php

namespace Cehlers88\AnalyticsCore\Tests\Executor;

use Cehlers88\AnalyticsCore\Executor\ExternalServiceExecutor;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Provider\ExternalServiceProvider;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Repository\ExternalServiceFunctionRepository;
use Cehlers88\AnalyticsCore\Interface\ExternalService\IExecutionAdapter;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerProvider;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class ExternalServiceExecutorTest extends TestCase
{
    private MockObject $commandPlayer;
    private MockObject $externalServiceProvider;
    private MockObject $variablesProvider;
    private LoggerProvider $loggerProvider;

    public function test_is_running_and_wants_to_rerun_are_always_false(): void
    {
        $executor = $this->createExecutor();

        $this->assertFalse($executor->isRunning());
        $this->assertFalse($executor->wantsToReRun());
    }

    private function createExecutor(): ExternalServiceExecutor
    {
        return new ExternalServiceExecutor(
            $this->externalServiceProvider,  // 1st: ExternalServiceProvider
            $this->externalServiceFunctionRepository,  // 2nd: ExternalServiceFunctionRepository
            $this->loggerProvider  // 3rd: LoggerProvider
        );
    }

    public function test_is_valid_requires_service_name_and_function_name(): void
    {
        $executor = $this->createExecutor();

        $this->assertFalse($executor->isValid());

        $executor
            ->setPropertyValue(ExternalServiceExecutor::KEY_SERVICE_NAME, 'myService')
            ->setPropertyValue(ExternalServiceExecutor::KEY_ARGUMENTS, [])
            ->setPropertyValue(ExternalServiceExecutor::KEY_OPTIONS, []);

        $this->assertFalse($executor->isValid());

        $executor->setPropertyValue(ExternalServiceExecutor::KEY_FUNCTION_NAME, 'myFunction');

        $this->assertTrue($executor->isValid());
    }

    public function test_run_reports_an_error_when_the_service_is_unknown(): void
    {
        $exception = new \Exception('Service "unknown" not found');

        $this->externalServiceProvider->expects($this->once())
            ->method('getExecutionAdapterByName')
            ->willThrowException($exception);

        $executor = $this->createExecutor();
        $executor
            ->setPropertyValue(ExternalServiceExecutor::KEY_SERVICE_NAME, 'unknown')
            ->setPropertyValue(ExternalServiceExecutor::KEY_FUNCTION_NAME, 'myFunction')
            ->setPropertyValue(ExternalServiceExecutor::KEY_ARGUMENTS, [])
            ->setPropertyValue(ExternalServiceExecutor::KEY_OPTIONS, []);

        $executor->run();

        $this->assertTrue($executor->hasError());
        $this->assertStringContainsString('Service "unknown" not found', $executor->getErrorsAsString());
        $this->assertSame($exception, $executor->getLastResult());
    }

    public function test_run_is_skipped_when_required_properties_are_missing(): void
    {
        $this->externalServiceProvider->expects($this->never())
            ->method('getExecutionAdapterByName');

        $executor = $this->createExecutor();
        $executor->run();

        $this->assertTrue($executor->hasError());
        $this->assertNull($executor->getLastResult());
    }

    protected function setUp(): void
    {
        parent::setUp();

        // Create mocks/stubs in the correct order
        $this->commandPlayer = $this->createMock(CommandPlayer::class);
        $this->externalServiceProvider = $this->createMock(ExternalServiceProvider::class);
        $this->externalServiceFunctionRepository = $this->createMock(ExternalServiceFunctionRepository::class);
        $this->variablesProvider = $this->createMock(VariablesProvider::class);
        $this->loggerProvider = $this->createMock(LoggerProvider::class);
    }
}
