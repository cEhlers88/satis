<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\MergeMacro;
use PHPUnit\Framework\TestCase;

class MergeMacroTest extends TestCase
{
    public function test_objects_later_value_wins(): void
    {
        $result = $this->runMacro(['sources' => [
            ['limit' => 10, 'sort' => 'asc', 'filter' => ['status' => 'open', 'type' => 'invoice']],
            ['limit' => 50, 'filter' => ['status' => 'paid']],
        ]]);

        $this->assertSame(['limit' => 50, 'sort' => 'asc', 'filter' => ['status' => 'paid']], $result);
    }

    public function test_objects_deep(): void
    {
        $result = $this->runMacro(['deep' => true, 'sources' => [
            ['limit' => 10, 'filter' => ['status' => 'open', 'type' => 'invoice']],
            (object)['filter' => (object)['status' => 'paid']],
        ]]);

        $this->assertSame(['limit' => 10, 'filter' => ['status' => 'paid', 'type' => 'invoice']], $result);
    }

    public function test_lists_are_appended_optionally_unique(): void
    {
        $this->assertSame([1, 2, ['a' => 1], 2, 3, ['a' => 1]], $this->runMacro(['sources' => [[1, 2, ['a' => 1]], [2, 3, ['a' => 1]], null]]));
        $this->assertSame([1, 2, ['a' => 1], 3], $this->runMacro(['unique' => true, 'sources' => [[1, 2, ['a' => 1]], [2, 3, ['a' => 1]]]]));
    }

    public function test_a_single_source_is_returned_as_it_is(): void
    {
        // execute() unwraps a list of one
        $this->assertSame(['a' => 1], $this->runMacro(['sources' => [['a' => 1]]]));
        $this->assertSame([1, 2], $this->runMacro(['sources' => [[1, 2]]]));
        $this->assertSame([], $this->runMacro(['sources' => []]));
    }

    public function test_objects_and_lists_cannot_be_mixed(): void
    {
        $result = $this->execute(['sources' => [['a' => 1], [1, 2]]]);

        $this->assertTrue($result['hasError']);
        $this->assertSame(422, $result['error']->number);
        $this->assertTrue($this->execute(['sources' => [['a' => 1], 'text']])['hasError']);
    }

    private function runMacro(array $arguments): mixed
    {
        $result = $this->execute($arguments);
        $this->assertFalse($result['hasError'], (string)($result['error']->message ?? ''));

        return $result['returnValue'];
    }

    private function execute(array $arguments): array
    {
        $macro = new MergeMacro();
        $macro->setMacroEnvironment($this->createMock(MacroEnvironment::class));

        return $macro->execute($arguments);
    }
}
