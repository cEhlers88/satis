<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\TemplateMacro;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use PHPUnit\Framework\TestCase;

class TemplateMacroTest extends TestCase
{
    public function test_placeholders_are_filled_from_values_and_variables(): void
    {
        $variables = $this->createMock(VariablesProvider::class);
        $variables->method('getVariableValue')->willReturnCallback(
            static fn(string $name, ...$rest): mixed => $name === 'firma' ? ['name' => 'Ehlers GmbH'] : VariablesProvider::UNDEFINED_VAR
        );

        $result = $this->createMacro($variables)->execute([
            'text' => 'Hallo {kunde.name}, offen sind {betrag} € bei {firma.name}. {{fest}}',
            'values' => ['kunde' => ['name' => 'Ada'], 'betrag' => '1.234,56'],
        ]);

        $this->assertFalse($result['hasError']);
        $this->assertSame('Hallo Ada, offen sind 1.234,56 € bei Ehlers GmbH. {fest}', $result['returnValue']);
    }

    public function test_values_are_written_as_text(): void
    {
        $result = $this->createMacro()->execute([
            'text' => '{a}|{b}|{c}|{d}',
            'values' => ['a' => true, 'b' => null, 'c' => [1, 2], 'd' => 2.5],
        ]);

        $this->assertSame('true||[1,2]|2.5', $result['returnValue']);
    }

    public function test_a_missing_placeholder_is_kept_emptied_or_an_error(): void
    {
        $text = 'Hallo {name}!';

        $this->assertSame('Hallo {name}!', $this->createMacro()->execute(['text' => $text])['returnValue']);
        $this->assertSame('Hallo !', $this->createMacro()->execute(['text' => $text, 'missing' => 'empty'])['returnValue']);

        $error = $this->createMacro()->execute(['text' => $text, 'missing' => 'error']);
        $this->assertTrue($error['hasError']);
        $this->assertSame(422, $error['error']->number);
        $this->assertStringContainsString('"name"', $error['error']->message);
    }

    public function test_values_are_edited_as_keys_with_a_value_each(): void
    {
        $ui = TemplateMacro::getPropertyUiInfos(MacroPropertyDTO::create('values', MacroPropertyDTO::TYPE_ARRAY));

        $this->assertSame(PropertyUi::EDITOR_MAP, $ui?->toArray()[PropertyUi::KEY_EDITOR] ?? null);
    }

    private function createMacro(?VariablesProvider $variables = null): TemplateMacro
    {
        $environment = $this->createMock(MacroEnvironment::class);
        if ($variables === null) {
            $variables = $this->createMock(VariablesProvider::class);
            $variables->method('getVariableValue')->willReturn(VariablesProvider::UNDEFINED_VAR);
        }
        $environment->method('getVariablesStoreProvider')->willReturn($variables);

        $macro = new TemplateMacro();
        $macro->setMacroEnvironment($environment);

        return $macro;
    }
}
