<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\RegexMatchMacro;
use PHPUnit\Framework\TestCase;

class RegexMatchMacroTest extends TestCase
{
    private const string SUBJECT = 'AW: Rechnung RE-2026-0042 und RE-2026-0043';

    public function test_modes(): void
    {
        $this->assertTrue($this->runMacro('/RE-\d{4}-\d+/', 'test'));
        $this->assertFalse($this->runMacro('/Mahnung/', 'test'));
        $this->assertSame('RE-2026-0042', $this->runMacro('/RE-\d{4}-\d+/', 'first'));
        $this->assertNull($this->runMacro('/Mahnung/', 'first'));
        $this->assertSame(['RE-2026-0042', 'RE-2026-0043'], $this->runMacro('/RE-\d{4}-\d+/', 'all'));
        $this->assertSame([], $this->runMacro('/Mahnung/', 'all'));
    }

    public function test_groups_are_named_when_the_pattern_names_them(): void
    {
        $this->assertSame(['jahr' => '2026', 'nr' => '0042'], $this->runMacro('/RE-(?<jahr>\d{4})-(?<nr>\d+)/', 'groups'));
        $this->assertSame(['2026', '0042'], $this->runMacro('/RE-(\d{4})-(\d+)/', 'groups'));
        $this->assertNull($this->runMacro('/Mahnung (\d+)/', 'groups'));
    }

    public function test_a_pattern_without_delimiters_is_taken_as_it_is(): void
    {
        $this->assertSame('RE-2026-0042', $this->runMacro('RE-\d{4}-\d+', 'first'));
        $this->assertSame(['2026'], $this->runMacro('(\d{4})', 'groups'));
        $this->assertTrue($this->runMacro('/rechnung/i', 'test'));
        $this->assertSame('~a\~b~', RegexMatchMacro::delimit('a~b'));
    }

    public function test_an_invalid_pattern_is_an_error(): void
    {
        $result = $this->execute(['subject' => self::SUBJECT, 'pattern' => '/(unclosed/']);

        $this->assertTrue($result['hasError']);
        $this->assertSame(422, $result['error']->number);
    }

    private function runMacro(string $pattern, string $mode): mixed
    {
        $result = $this->execute(['subject' => self::SUBJECT, 'pattern' => $pattern, 'mode' => $mode]);
        $this->assertFalse($result['hasError'], (string)($result['error']->message ?? ''));

        return $result['returnValue'];
    }

    private function execute(array $arguments): array
    {
        $macro = new RegexMatchMacro();
        $macro->setMacroEnvironment($this->createMock(MacroEnvironment::class));

        return $macro->execute($arguments);
    }
}
