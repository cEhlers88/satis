<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\Entity\SystemLog;
use Analytics\Repository\SystemLogRepository;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;

class WorkersViewWidget extends AbstractWidget
{
    public function __construct()
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.workersView';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]]
        ];
    }


    public function getTemplateName(): string
    {
        return 'workersView';
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'source.entity',
                value: null,
                type: 'string',
                label: 'Quelle',
                description: 'Woher die angezeigten Einträge stammen.',
                ui: [
                    'options' => [
                        'SystemLog' => 'Systemprotokoll',
                        'TrackingBuffer' => 'Tracking-Puffer',
                    ],
                ]
            ),
            PropertyDTO::create(
                name: 'source.keyFilter',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Key-Filter',
                description: 'Beschränkt die Einträge auf einen Key - nur für den Tracking-Puffer.'
            ),
        ];
    }

    public function enrichProperties(array $properties): array
    {
        return $properties;
    }
}