# Bug Reports

Users report bugs from the dashboard, administrators work through them and turn what was
fixed into changelog entries. There is no page for it: a modal that any page can open.

Unlike most of the core, this module brings its own user interface along, so every
application that uses AnalyticsCore gets the whole mechanism, not just its data.

## What belongs to it

| | |
|---|---|
| `Entity\BugReport`, `Entity\BugReportComment` | the report and everything said about it |
| `ENUM\eBugReportState` | New, Accepted, InProgress, Fixed, Declined, Duplicate (`isOpen()`, `belongsInChangelog()`, `tone()`) |
| `ENUM\eBugReportSeverity` | Low, Normal, High, Critical |
| `Repository\BugReportRepository` | `findFor()` (own or all), `countStates()`, `findForChangelog()` |
| `Support\BugReport\BugReportService` | create, comment, change state, describe, `toChangelog()` |
| `Support\BugReport\BugReportAttachmentStorage` | the attached files, one directory per report |
| `Controller\BugReportController` | `/admin_api/bug-report/*`, answers with rendered HTML |
| `Event\BugReport\BugReportCreatedEvent`, `BugReportChangedEvent` | for whoever wants to notify people |
| `templates/bugReport/` | `modal`, `button`, `style`, `script.js.twig`, `_list`, `_detail` |

## Putting it into an application

1. Import the controllers, e.g. `config/routes/analytics_core.yaml`:

   ```yaml
   analytics_core_bundle:
     resource: '@AnalyticsCore/Controller/'
     type: attribute
   ```

2. Include the three parts in the layout every signed-in page extends:

   ```twig
   {% block stylesheets %}{{ parent() }}{% include 'bugReport/style.html.twig' %}{% endblock %}

   {# somewhere in the navigation - `icon` is a symbol of the application's sprite #}
   {% include 'bugReport/button.html.twig' with {class: 'nav-action', icon: 'bug'} only %}

   {# at the end of the body, not in a block the pages below override #}
   {% include 'bugReport/modal.html.twig' %}
   <script type="text/javascript">{% include 'bugReport/script.js.twig' %}</script>
   ```

3. Create the tables `bug_report` and `bug_report_comment` with a migration of the
   application.

`BUG_REPORT_DIRECTORY` moves the attached files; by default they are kept below
`var/bug-reports`, never in the document root.

Anything carrying `data-bgr-open` opens the modal (with an id it opens that report);
`window.bugReports.open()` and the event `bugReport:open` do the same. `?bugReport=<id>` in
the address opens a report on page load - that is where the push messages point.

## Who may do what

Anybody signed in (`ROLE_USER`) reports bugs and works on their own reports; a report of
somebody else is answered with 404. `ROLE_ADMIN` sees everything, comments internally
(never shown to the reporter), changes state and severity, deletes reports and makes
changelog entries.

## Events

The core stores reports and says what happened - it notifies nobody itself:

- `BugReportCreatedEvent` - a bug was reported,
- `BugReportChangedEvent` - it was commented on, moved to another state or corrected;
  `concernsReporter()` says whether the reporter may hear about it.

`toChangelog()` hands fixed reports to whoever keeps a changelog with
`Event\Changelog\AddChangelogEntriesEvent`; reports that went there are marked and never
offered again.
