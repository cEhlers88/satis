<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Event\BugReport;

use Cehlers88\AnalyticsCore\Entity\BugReport;

/**
 * A user reported a bug. Whoever wants to tell the administrators about it - a toast, a
 * push message - listens to this; the core itself only stores the report.
 */
final class BugReportCreatedEvent
{
    public function __construct(
        public readonly BugReport $report,
    ) {
    }
}
