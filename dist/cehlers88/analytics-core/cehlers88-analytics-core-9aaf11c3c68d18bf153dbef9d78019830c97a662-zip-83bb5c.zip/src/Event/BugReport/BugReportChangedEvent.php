<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Event\BugReport;

use Cehlers88\AnalyticsCore\Entity\BugReport;
use Cehlers88\AnalyticsCore\Entity\BugReportComment;
use Cehlers88\AnalyticsCore\Entity\User;

/**
 * Something happened to a report that was already there: it was commented on, moved to
 * another state, or its text was changed. Above all the reporter wants to know.
 */
final class BugReportChangedEvent
{
    public const COMMENTED = 'commented';
    public const STATE_CHANGED = 'state';
    public const UPDATED = 'updated';

    public function __construct(
        public readonly BugReport         $report,
        /** One of COMMENTED, STATE_CHANGED, UPDATED. */
        public readonly string            $change,
        /** Who did it - null when nobody was signed in. */
        public readonly ?User             $actor = null,
        public readonly ?BugReportComment $comment = null,
    ) {
    }

    /** Whether the reporter should hear about it - an internal note stays among administrators. */
    public function concernsReporter(): bool
    {
        return $this->comment === null || !$this->comment->isInternal();
    }
}
