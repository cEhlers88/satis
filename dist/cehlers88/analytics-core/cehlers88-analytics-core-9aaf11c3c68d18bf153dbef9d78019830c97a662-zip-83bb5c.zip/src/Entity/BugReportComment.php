<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\BugReportCommentRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * What was said about a bug report - by the reporter, by an administrator, or by the
 * system itself when a state changed.
 *
 * `internal` marks a note among administrators: the reporter never gets to see it.
 */
#[ORM\Entity(repositoryClass: BugReportCommentRepository::class)]
#[ORM\Table(name: 'bug_report_comment')]
class BugReportComment extends AbstractEntity
{
    #[ORM\ManyToOne(targetEntity: BugReport::class, inversedBy: 'comments')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private ?BugReport $report = null;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?User $author = null;

    #[ORM\Column(length: 255)]
    private string $authorName = '';

    #[ORM\Column(type: Types::TEXT)]
    private string $text = '';

    #[ORM\Column]
    private bool $internal = false;

    /** Written by the system, not by a person - a state that changed, say. */
    #[ORM\Column]
    private bool $automatic = false;

    public function getReport(): ?BugReport
    {
        return $this->report;
    }

    public function setReport(?BugReport $report): static
    {
        $this->report = $report;

        return $this;
    }

    public function getAuthor(): ?User
    {
        return $this->author;
    }

    public function setAuthor(?User $author): static
    {
        $this->author = $author;

        return $this;
    }

    public function getAuthorName(): string
    {
        return $this->authorName;
    }

    public function setAuthorName(string $authorName): static
    {
        $this->authorName = $authorName;

        return $this;
    }

    public function getText(): string
    {
        return $this->text;
    }

    public function setText(string $text): static
    {
        $this->text = $text;

        return $this;
    }

    public function isInternal(): bool
    {
        return $this->internal;
    }

    public function setInternal(bool $internal): static
    {
        $this->internal = $internal;

        return $this;
    }

    public function isAutomatic(): bool
    {
        return $this->automatic;
    }

    public function setAutomatic(bool $automatic): static
    {
        $this->automatic = $automatic;

        return $this;
    }
}
