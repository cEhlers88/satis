<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\ENUM\eBugReportSeverity;
use Cehlers88\AnalyticsCore\ENUM\eBugReportState;
use Cehlers88\AnalyticsCore\Repository\BugReportRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * A bug a user reported from the dashboard.
 *
 * The reporter is kept as a relation *and* by name: the report stays readable once the
 * account is gone. What the browser could tell about the moment of the report (page,
 * browser, version) sits in `context`, the uploaded files in `attachments` - the files
 * themselves are kept outside the database (BugReportAttachmentStorage).
 */
#[ORM\Entity(repositoryClass: BugReportRepository::class)]
#[ORM\Table(name: 'bug_report')]
#[ORM\Index(name: 'bug_report_state_idx', columns: ['state'])]
class BugReport extends AbstractEntity
{
    #[ORM\Column(length: 255)]
    private string $title = '';

    #[ORM\Column(type: Types::TEXT)]
    private string $description = '';

    #[ORM\Column(length: 32, enumType: eBugReportState::class)]
    private eBugReportState $state = eBugReportState::New;

    #[ORM\Column(length: 32, enumType: eBugReportSeverity::class)]
    private eBugReportSeverity $severity = eBugReportSeverity::Normal;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?User $reporter = null;

    #[ORM\Column(length: 255)]
    private string $reporterName = '';

    /** @var array<string, string> what the browser knew: page, browser, screen, version */
    #[ORM\Column]
    private array $context = [];

    /** @var list<array{id: string, name: string, size: int, mimeType: string, createdAt: string}> */
    #[ORM\Column]
    private array $attachments = [];

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $closedAt = null;

    /** When the report became an entry of a changelog - it is offered only once. */
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $changelogAt = null;

    /** @var Collection<int, BugReportComment> */
    #[ORM\OneToMany(targetEntity: BugReportComment::class, mappedBy: 'report', cascade: ['persist', 'remove'], orphanRemoval: true)]
    #[ORM\OrderBy(['id' => 'ASC'])]
    private Collection $comments;

    public function __construct()
    {
        $this->comments = new ArrayCollection();
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function setTitle(string $title): static
    {
        $this->title = $title;

        return $this;
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function setDescription(string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getState(): eBugReportState
    {
        return $this->state;
    }

    public function setState(eBugReportState $state): static
    {
        $this->state = $state;

        return $this;
    }

    public function getSeverity(): eBugReportSeverity
    {
        return $this->severity;
    }

    public function setSeverity(eBugReportSeverity $severity): static
    {
        $this->severity = $severity;

        return $this;
    }

    public function getReporter(): ?User
    {
        return $this->reporter;
    }

    public function setReporter(?User $reporter): static
    {
        $this->reporter = $reporter;

        return $this;
    }

    public function getReporterName(): string
    {
        return $this->reporterName;
    }

    public function setReporterName(string $reporterName): static
    {
        $this->reporterName = $reporterName;

        return $this;
    }

    /** Whether the report belongs to that user - who may read it and write to it. */
    public function belongsTo(?User $user): bool
    {
        return $user !== null && $this->reporter !== null && $this->reporter->getId() === $user->getId();
    }

    /** @return array<string, string> */
    public function getContext(): array
    {
        return $this->context;
    }

    /** @param array<string, string> $context */
    public function setContext(array $context): static
    {
        $this->context = $context;

        return $this;
    }

    /** @return list<array{id: string, name: string, size: int, mimeType: string, createdAt: string}> */
    public function getAttachments(): array
    {
        return $this->attachments;
    }

    /** @param list<array{id: string, name: string, size: int, mimeType: string, createdAt: string}> $attachments */
    public function setAttachments(array $attachments): static
    {
        $this->attachments = array_values($attachments);

        return $this;
    }

    /** @param array{id: string, name: string, size: int, mimeType: string, createdAt: string} $attachment */
    public function addAttachment(array $attachment): static
    {
        $this->attachments[] = $attachment;

        return $this;
    }

    /** @return array{id: string, name: string, size: int, mimeType: string, createdAt: string}|null */
    public function getAttachment(string $fileId): ?array
    {
        foreach ($this->attachments as $attachment) {
            if ($attachment['id'] === $fileId) {
                return $attachment;
            }
        }

        return null;
    }

    public function removeAttachment(string $fileId): static
    {
        $this->attachments = array_values(array_filter(
            $this->attachments,
            static fn(array $attachment): bool => $attachment['id'] !== $fileId,
        ));

        return $this;
    }

    public function getClosedAt(): ?\DateTimeInterface
    {
        return $this->closedAt;
    }

    public function setClosedAt(?\DateTimeInterface $closedAt): static
    {
        $this->closedAt = $closedAt;

        return $this;
    }

    public function getChangelogAt(): ?\DateTimeInterface
    {
        return $this->changelogAt;
    }

    public function setChangelogAt(?\DateTimeInterface $changelogAt): static
    {
        $this->changelogAt = $changelogAt;

        return $this;
    }

    /** @return Collection<int, BugReportComment> */
    public function getComments(): Collection
    {
        return $this->comments;
    }

    public function addComment(BugReportComment $comment): static
    {
        if (!$this->comments->contains($comment)) {
            $this->comments->add($comment);
            $comment->setReport($this);
        }

        return $this;
    }

    public function removeComment(BugReportComment $comment): static
    {
        $this->comments->removeElement($comment);

        return $this;
    }
}
