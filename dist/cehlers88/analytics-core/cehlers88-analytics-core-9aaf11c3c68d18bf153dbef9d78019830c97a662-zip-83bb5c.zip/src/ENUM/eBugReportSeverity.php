<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ENUM;

/** How much the reported bug hurts - said by whoever reports it, changed by an administrator. */
enum eBugReportSeverity: string
{
    case Low = 'low';
    case Normal = 'normal';
    case High = 'high';
    case Critical = 'critical';

    public function label(): string
    {
        return match ($this) {
            self::Low => 'Kleinigkeit',
            self::Normal => 'Normal',
            self::High => 'Schwer',
            self::Critical => 'Kritisch',
        };
    }

    /** The order of the list: the worse a bug is, the further up it stands. */
    public function weight(): int
    {
        return match ($this) {
            self::Critical => 3,
            self::High => 2,
            self::Normal => 1,
            self::Low => 0,
        };
    }
}
