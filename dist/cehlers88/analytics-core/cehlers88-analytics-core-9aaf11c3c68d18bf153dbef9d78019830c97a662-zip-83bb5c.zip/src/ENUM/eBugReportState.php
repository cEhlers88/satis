<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ENUM;

/**
 * The way a reported bug goes: it is reported, someone takes it on, and it ends as fixed,
 * as a duplicate or as something that is not a bug.
 */
enum eBugReportState: string
{
    case New = 'new';
    case Accepted = 'accepted';
    case InProgress = 'in_progress';
    case Fixed = 'fixed';
    case Declined = 'declined';
    case Duplicate = 'duplicate';

    public function label(): string
    {
        return match ($this) {
            self::New => 'Neu',
            self::Accepted => 'Angenommen',
            self::InProgress => 'In Arbeit',
            self::Fixed => 'Behoben',
            self::Declined => 'Abgelehnt',
            self::Duplicate => 'Doppelt',
        };
    }

    /** Still being worked on - what the counter on the button counts. */
    public function isOpen(): bool
    {
        return match ($this) {
            self::New, self::Accepted, self::InProgress => true,
            self::Fixed, self::Declined, self::Duplicate => false,
        };
    }

    /** Fixed reports are the ones an entry of the changelog can be made from. */
    public function belongsInChangelog(): bool
    {
        return $this === self::Fixed;
    }

    /** For the chips and the colors of the list. */
    public function tone(): string
    {
        return match ($this) {
            self::New => 'new',
            self::Accepted, self::InProgress => 'working',
            self::Fixed => 'done',
            self::Declined, self::Duplicate => 'closed',
        };
    }
}
