<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Support\BugReport;

use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * The files attached to a bug report: a screenshot, a log, an export - any kind of file.
 *
 * They are kept outside the database and outside the document root, one directory per
 * report, and are handed out only through BugReportController, which never lets the
 * browser run what it gets (see the download there). The file name a user gave is kept in
 * the database, never on disk: on disk a file is 16 hex characters and nothing else, so no
 * name can reach out of its directory or mean anything to the web server.
 */
class BugReportAttachmentStorage
{
    public const MAX_FILE_BYTES = 25 * 1024 * 1024;
    public const MAX_FILES_PER_REPORT = 20;
    /** What is shown in the report itself; everything else is a download. */
    public const PREVIEWABLE_TYPES = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];

    public function __construct(
        #[Autowire('%analytics_core.bug_report.directory%')]
        private readonly string $directory,
    ) {
    }

    /**
     * Stores an uploaded file and says what the report should remember about it.
     *
     * @return array{id: string, name: string, size: int, mimeType: string, createdAt: string}
     */
    public function add(int $reportId, UploadedFile $file): array
    {
        if (!$file->isValid()) {
            throw new \InvalidArgumentException(sprintf('"%s" did not arrive in one piece.', $file->getClientOriginalName()));
        }
        $size = (int)$file->getSize();
        if ($size <= 0) {
            throw new \InvalidArgumentException(sprintf('"%s" is empty.', $file->getClientOriginalName()));
        }
        if ($size > self::MAX_FILE_BYTES) {
            throw new \InvalidArgumentException(sprintf(
                '"%s" is larger than %d MB.',
                $file->getClientOriginalName(),
                (int)(self::MAX_FILE_BYTES / 1024 / 1024),
            ));
        }

        $directory = $this->reportDirectory($reportId);
        $this->makeDirectory($directory);
        do {
            $id = bin2hex(random_bytes(8));
        } while (file_exists($directory . '/' . $id));

        $file->move($directory, $id);

        return [
            'id' => $id,
            'name' => self::cleanName($file->getClientOriginalName()),
            'size' => $size,
            // what the browser said, never trusted: the file is served as a download
            'mimeType' => self::cleanMimeType($file->getClientMimeType()),
            'createdAt' => (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM),
        ];
    }

    /** The file of an attachment, null when it is not there (any more). */
    public function path(int $reportId, string $fileId): ?string
    {
        if (preg_match('/^[a-f0-9]{16}$/D', $fileId) !== 1) {
            return null;
        }
        $file = $this->reportDirectory($reportId) . '/' . $fileId;

        return is_file($file) ? $file : null;
    }

    public function remove(int $reportId, string $fileId): void
    {
        $file = $this->path($reportId, $fileId);
        if ($file !== null) {
            @unlink($file);
        }
    }

    /** Everything a report brought along - when the report itself is deleted. */
    public function removeAll(int $reportId): void
    {
        $directory = $this->reportDirectory($reportId);
        if (!is_dir($directory)) {
            return;
        }
        foreach (scandir($directory) ?: [] as $entry) {
            if ($entry !== '.' && $entry !== '..') {
                @unlink($directory . '/' . $entry);
            }
        }
        @rmdir($directory);
    }

    public static function isPreviewable(string $mimeType): bool
    {
        return in_array($mimeType, self::PREVIEWABLE_TYPES, true);
    }

    /** The name as it is shown and downloaded - no directories, no control characters. */
    public static function cleanName(string $name): string
    {
        $name = str_replace(['/', '\\', "\0"], '_', $name);
        $name = trim(preg_replace('/[\x00-\x1F\x7F]/u', '', $name) ?? '');

        return $name === '' ? 'Datei' : mb_substr($name, 0, 180);
    }

    private static function cleanMimeType(?string $mimeType): string
    {
        // no "#" in the pattern: it is the delimiter, and a type may not carry one anyway
        return preg_match('#^[a-z0-9!$&^_.+-]+/[a-z0-9!$&^_.+-]+$#i', (string)$mimeType) === 1
            ? strtolower((string)$mimeType)
            : 'application/octet-stream';
    }

    private function reportDirectory(int $reportId): string
    {
        return $this->directory . '/' . $reportId;
    }

    private function makeDirectory(string $directory): void
    {
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException(sprintf('The directory "%s" cannot be created.', $directory));
        }
    }
}
