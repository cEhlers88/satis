<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\ENUM\eBugReportState;
use Cehlers88\AnalyticsCore\Entity\BugReport;
use Cehlers88\AnalyticsCore\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\QueryBuilder;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<BugReport>
 */
class BugReportRepository extends ServiceEntityRepository
{
    /** `state` of a filter: every report that is still being worked on. */
    public const FILTER_OPEN = 'open';
    /** `state` of a filter: everything that is done with, however it ended. */
    public const FILTER_CLOSED = 'closed';

    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, BugReport::class);
    }

    public function save(BugReport $report, bool $flush = false): void
    {
        $this->getEntityManager()->persist($report);
        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function remove(BugReport $report, bool $flush = false): void
    {
        $this->getEntityManager()->remove($report);
        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    /**
     * The reports somebody gets to see: their own ones, or all of them for an administrator.
     *
     * @param array{state?: string|null, severity?: string|null, query?: string|null} $filters
     * @return list<BugReport>
     */
    public function findFor(?User $user, bool $asAdmin, array $filters = []): array
    {
        $builder = $this->createQueryBuilder('report');
        if (!$asAdmin) {
            // no user, no reports - never every report of everybody
            $builder->andWhere('report.reporter = :reporter')->setParameter('reporter', $user?->getId() ?? 0);
        }
        $this->applyFilters($builder, $filters);

        // the worst first, then the newest; a state that is done with sinks below the rest
        return $builder
            ->addSelect('CASE WHEN report.state IN (:openStates) THEN 1 ELSE 0 END AS HIDDEN openFirst')
            ->setParameter('openStates', array_map(
                static fn(eBugReportState $state): string => $state->value,
                array_filter(eBugReportState::cases(), static fn(eBugReportState $state): bool => $state->isOpen()),
            ))
            ->orderBy('openFirst', 'DESC')
            ->addOrderBy('report.id', 'DESC')
            ->getQuery()
            ->getResult();
    }

    /**
     * How many reports are in which state - for the counter on the button and the head of
     * the list.
     *
     * @return array<string, int> count by state value, plus "open" and "all"
     */
    public function countStates(?User $user, bool $asAdmin): array
    {
        $builder = $this->createQueryBuilder('report')
            ->select('report.state AS state, COUNT(report.id) AS amount')
            ->groupBy('report.state');
        if (!$asAdmin) {
            $builder->andWhere('report.reporter = :reporter')->setParameter('reporter', $user?->getId() ?? 0);
        }

        $counts = ['open' => 0, 'all' => 0];
        foreach (eBugReportState::cases() as $state) {
            $counts[$state->value] = 0;
        }
        foreach ($builder->getQuery()->getResult() as $row) {
            $state = $row['state'] instanceof eBugReportState ? $row['state'] : eBugReportState::tryFrom((string)$row['state']);
            if ($state === null) {
                continue;
            }
            $amount = (int)$row['amount'];
            $counts[$state->value] += $amount;
            $counts['all'] += $amount;
            if ($state->isOpen()) {
                $counts['open'] += $amount;
            }
        }

        return $counts;
    }

    /**
     * Fixed reports that have not been put into a changelog yet.
     *
     * @return list<BugReport>
     */
    public function findForChangelog(): array
    {
        return $this->createQueryBuilder('report')
            ->andWhere('report.state = :state')
            ->andWhere('report.changelogAt IS NULL')
            ->setParameter('state', eBugReportState::Fixed->value)
            ->orderBy('report.id', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @param array{state?: string|null, severity?: string|null, query?: string|null} $filters
     */
    private function applyFilters(QueryBuilder $builder, array $filters): void
    {
        $state = $filters['state'] ?? null;
        if ($state === self::FILTER_OPEN || $state === self::FILTER_CLOSED) {
            $wanted = array_map(
                static fn(eBugReportState $case): string => $case->value,
                array_filter(
                    eBugReportState::cases(),
                    static fn(eBugReportState $case): bool => $case->isOpen() === ($state === self::FILTER_OPEN),
                ),
            );
            $builder->andWhere('report.state IN (:states)')->setParameter('states', $wanted);
        } elseif (is_string($state) && eBugReportState::tryFrom($state) !== null) {
            $builder->andWhere('report.state = :state')->setParameter('state', $state);
        }

        $severity = $filters['severity'] ?? null;
        if (is_string($severity) && $severity !== '') {
            $builder->andWhere('report.severity = :severity')->setParameter('severity', $severity);
        }

        $query = trim((string)($filters['query'] ?? ''));
        if ($query !== '') {
            $builder
                ->andWhere('report.title LIKE :query OR report.description LIKE :query OR report.reporterName LIKE :query')
                ->setParameter('query', '%' . addcslashes($query, '%_') . '%');
        }
    }
}
