<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Analytics\Entity\AnalyticsHeader;
use Cehlers88\AnalyticsCore\Repository\TagRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: TagRepository::class)]
class Tag extends AbstractEntity
{
    protected Collection $tags;
    #[ORM\Column(length: 255)]
    private ?string $name = null;
    #[ORM\Column(length: 255)]
    private ?string $color = null;
    /**
     * @var Collection<int, AnalyticsHeader>
     */
    #[ORM\ManyToMany(targetEntity: AnalyticsHeader::class, mappedBy: 'tags')]
    private Collection $analyticsHeaders;

    public function __construct()
    {
        $this->analyticsHeaders = new ArrayCollection();
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getColor(): ?string
    {
        return $this->color;
    }

    public function setColor(string $color): static
    {
        $this->color = $color;

        return $this;
    }

    /**
     * @return Collection<int, AnalyticsHeader>
     */
    public function getAnalyticsHeaders(): Collection
    {
        return $this->analyticsHeaders;
    }

    public function addAnalyticsHeader(AnalyticsHeader $analyticsHeader): static
    {
        if (!$this->analyticsHeaders->contains($analyticsHeader)) {
            $this->analyticsHeaders->add($analyticsHeader);
            $analyticsHeader->addTag($this);
        }

        return $this;
    }

    public function removeAnalyticsHeader(AnalyticsHeader $analyticsHeader): static
    {
        if ($this->analyticsHeaders->removeElement($analyticsHeader)) {
            $analyticsHeader->removeTag($this);
        }

        return $this;
    }
}
