<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\StatisticsRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: StatisticsRepository::class)]
class Statistics extends AbstractEntity
{
    #[ORM\Column]
    private array $details = [];

    public function getDetails(): array
    {
        return $this->details;
    }

    public function setDetails(array $details): static
    {
        $this->details = $details;

        return $this;
    }
}
