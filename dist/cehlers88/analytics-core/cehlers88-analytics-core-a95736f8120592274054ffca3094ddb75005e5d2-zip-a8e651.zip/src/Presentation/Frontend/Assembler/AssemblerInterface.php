<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ViewInterface;

interface AssemblerInterface
{
    /**
     * Processes the given entity and returns the corresponding view representation.
     *
     * @param EntityInterface $entity The entity to be processed.
     * @return ViewInterface The view representation of the processed entity.
     */
    public function one(EntityInterface $entity): ViewInterface;

    /**
     * Processes a collection of entities and returns the resulting array.
     *
     * @param EntityInterface[] $entities The collection of entities to process.
     * @return ViewInterface[] The processed view-interfaces.
     */
    public function many(iterable $entities): array;
}