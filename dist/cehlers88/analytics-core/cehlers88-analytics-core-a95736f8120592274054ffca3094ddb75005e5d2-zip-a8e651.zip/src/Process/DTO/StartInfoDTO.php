<?php

namespace Cehlers88\AnalyticsCore\Process\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;

class StartInfoDTO extends DTO
{
    public const KEY_RUNNER = 'runner';
    public const KEY_RUNNER_ARGUMENTS = 'runner_arguments';

    public string $runner = '';
    public array $runner_arguments = [];

    public static function createFromArray(array $data): static
    {
        return self::create(
            $data[self::KEY_RUNNER] ?? '',
            $data[self::KEY_RUNNER_ARGUMENTS] ?? []
        );
    }

    public static function create(string $runner, array $runnerArguments = []): static
    {
        $dto = new static();
        $dto->runner = $runner;
        $dto->runner_arguments = $runnerArguments;

        return $dto;
    }

    public function toArray(): array
    {
        return get_object_vars($this);
    }
}