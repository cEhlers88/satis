<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 31.08.2024
 * Time: 09:20
 */

namespace Cehlers88\AnalyticsCore\Process\Runner;

class CommandsPlayerProcessRunner extends AbstractProcessRunner
{

    public function handle(): void
    {
        // TODO: Implement handle() method.
    }
}