<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

use Cehlers88\AnalyticsCore\Entity\Process;

interface ProcessResultWorkerInterface
{
    public function setProcess(Process $process): static;

    public function handleResult(mixed $result): static;
}