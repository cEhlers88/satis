<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\RunChain;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Worker>
 *
 * @method Worker|null find($id, $lockMode = null, $lockVersion = null)
 * @method Worker|null findOneBy(array $criteria, array $orderBy = null)
 * @method Worker[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class WorkerRepository extends AbstractRepository
{
    public function __construct(ManagerRegistry $registry, private EntityManagerInterface $entityManager)
    {
        parent::__construct($registry, Worker::class);
    }

    public function findAll(): array
    {
        return $this->createPrefilteredQueryBuilder('w')
            ->orderBy('w.application', 'ASC')
            ->addOrderBy('w.priority', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function findBy_applicationIds(array $applicationIds, bool $onlyEnabled = true): array
    {
        $querBuilder = $this->createPrefilteredQueryBuilder('w')
            ->join('w.application', 'a')
            ->andWhere('a.id IN (:applicationIds)')
            ->setParameter('applicationIds', $applicationIds);
        if ($onlyEnabled) {
            $querBuilder->andWhere('w.enabled = 1');
        }

        return $querBuilder->getQuery()
            ->getResult();
    }

    public function findBy_priority(int $priority, RunChain $runChainFilter): array
    {
        return $this->createPrefilteredQueryBuilder('w')
            ->andWhere('w.priority = :priority')
            ->andWhere(':runChain MEMBER OF w.runChains')
            ->setParameter('priority', $priority)
            ->getQuery()
            ->getResult();
    }

    /**
     * Returns all workers that are waiting to be executed
     * @return array<Worker>
     */
    public function fetchWaitingWorkers(
        RunChain $runChainFilter,
        array    $excludeWorkers = []
    ): array
    {
        $excludeIds = array_map(
            static fn(Worker $w) => $w->getId(),
            $excludeWorkers
        );

        $qb = $this->createPrefilteredQueryBuilder('w')
            ->andWhere('w.nextRunAt < :now OR w.nextRunAt IS NULL')
            ->andWhere('w.enabled = 1')
            ->andWhere(':runChain MEMBER OF w.runChains')
            ->setParameter('now', new \DateTimeImmutable())
            ->setParameter('runChain', $runChainFilter)
            ->orderBy('w.priority', 'DESC');

        if ($excludeIds !== []) {
            $qb
                ->andWhere('w.id NOT IN (:excludeWorkers)')
                ->setParameter('excludeWorkers', $excludeIds);
        }

        return $qb->getQuery()->getResult();
    }

    public function setWorkerStarted(Worker $worker, bool $saveAndFlush = false): WorkerRepository
    {
        $worker->setStarted();
        $worker->setUpdatedAt(new \DateTimeImmutable());
        $this->save($worker, $saveAndFlush);
        return $this;
    }

    public function save(Worker $worker, bool $flush = false): WorkerRepository
    {
        $this->entityManager->persist($worker);

        if (!$flush) {
            return $this;
        }

        $this->entityManager->flush();

        return $this;
    }

    public function setWorkerIdle(Worker $worker, bool $saveAndFlush = false): WorkerRepository
    {
        $worker->setIdle();
        if (!$saveAndFlush) {
            return $this;
        }
        $this->save($worker, true);
        return $this;
    }

    public function setWorkerFinished(
        Worker          $worker,
        WorkerResultDTO $workerResultDTO,
        int             $state,
        bool            $saveAndFlush = false
    ): Worker
    {
        $store = $worker->getStore();
        $store->lastData = $store->currentData;
        $store->currentData = [];

        $worker
            ->finishWorker($workerResultDTO, $state)
            ->setUpdatedAt(new \DateTimeImmutable())
            ->setStore($store);

        if (!$saveAndFlush) {
            return $worker;
        }
        $this->save($worker, true);
        return $worker;
    }

    public function addRunChainToWorkerSimple(int $workerId, int $runChainId, bool $flush = true): WorkerRepository
    {
        return $this->addRunChainToWorker($this->find($workerId), $this->entityManager->getReference(RunChain::class, $runChainId), $flush);
    }

    public function addRunChainToWorker(Worker $worker, RunChain $runChain, bool $flush = true): WorkerRepository
    {
        $worker->addRunChain($runChain);
        return $this->save($worker, $flush);
    }

    public function removeRunChainFromWorkerSimple(int $workerId, int $runChainId, bool $flush = true): WorkerRepository
    {
        return $this->removeRunChainFromWorker($this->find($workerId), $this->entityManager->getReference(RunChain::class, $runChainId), $flush);
    }

    public function removeRunChainFromWorker(Worker $worker, RunChain $runChain, bool $flush = true): WorkerRepository
    {
        $worker->removeRunChain($runChain);
        return $this->save($worker, $flush);
    }
}
