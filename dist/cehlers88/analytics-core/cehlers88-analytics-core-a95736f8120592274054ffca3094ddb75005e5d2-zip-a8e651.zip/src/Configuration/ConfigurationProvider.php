<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 24.05.2024
 * Time: 22:30
 */

namespace Cehlers88\AnalyticsCore\Configuration;

use Analytics\ENUM\eMacroVariableContext;
use Analytics\Provider\VariablesProvider;
use Analytics\Repository\VariableStoreRepository;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;

class ConfigurationProvider
{
    public const KEY_INDIVIDUALS = 'individuals';
    public const KEY_GENERALS = 'main.general';

    private bool $loaded = false;
    private array $_updatedVarsBuffer = [];

    /**
     * @param GroupInterface[] $configurations
     * @param ApplicationRepository $applicationRepository
     * @param VariableStoreRepository $variableStoreRepository
     * @param VariablesProvider $variablesStoreProvider
     * @param array $buffer
     */
    public function __construct(
        private iterable                $configurations,
        private ApplicationRepository   $applicationRepository,
        private VariableStoreRepository $variableStoreRepository,
        private VariablesProvider       $variablesStoreProvider,
        private array                   $buffer = [],
    )
    {
    }

    public function loadRequestData(array $requestData): static
    {
        $groups = [];

        foreach ($requestData as $key => $value) {
            $exploded = explode('_', $key);

            if (count($exploded) > 2) {
                $context = $exploded[0];
                $applicationId = $exploded[1];
                $key = $exploded[2];
                $groupName = $exploded[2];
                $groupKey = $exploded[count($exploded) - 1];
                for ($i = 3; $i < count($exploded); $i++) {
                    $key .= '_' . $exploded[$i];
                    $groupName .= $i < count($exploded) - 1 ? '_' . $exploded[$i] : '';
                }
                $key = str_replace(self::KEY_INDIVIDUALS . '_', '', $key);

                if (is_array($value)) {
                    // store group
                    $groupIndex = -1;
                    for ($i = 0; $i < count($groups); $i++) {
                        if ($groups[$i]['groupName'] === $groupName && $groups[$i]['context'] === $context && $groups[$i]['applicationId'] === $applicationId) {
                            $groupIndex = $i;
                            break;
                        }
                    }
                    if ($groupIndex === -1) {
                        $groups[] = [
                            'groupName' => $groupName,
                            'context' => $context,
                            'applicationId' => $applicationId,
                            'values' => []
                        ];
                        $groupIndex = count($groups) - 1;
                    }

                    foreach ($value as $index => $valueEntry) {
                        if (!isset($groups[$groupIndex]['values'][$index])) {
                            $groups[$groupIndex]['values'][$index] = [];
                        }
                        $groups[$groupIndex]['values'][$index][$groupKey] = $valueEntry;
                    }
                } else {
                    $this->_addUpdatedVar(
                        eMacroVariableContext::fromString($context),
                        str_replace("_", ".", $key),
                        [
                            is_numeric($value) ? 'numeric' : gettype($value),
                            $value
                        ],
                        (int)$applicationId,
                        $groupName
                    );
                }
            }
        }

        foreach ($groups as $group) {
            $this->_addUpdatedVar(
                eMacroVariableContext::fromString($group['context']),
                str_replace("_", ".", $group['groupName']),
                [
                    is_numeric($group['values']) ? 'numeric' : gettype($group['values']),
                    $group['values']
                ],
                $group['applicationId']
            );
        }

        return $this;
    }

    private function _addUpdatedVar(
        eMacroVariableContext $context,
        string                $variableName,
        mixed                 $variableValue,
        int                   $applicationId,
        string                $groupName = ''
    ): void
    {
        if (!isset($this->_updatedVarsBuffer[$context->name])) {
            $this->_updatedVarsBuffer[$context->name] = [];
        }

        $appGroup = $applicationId > 0 ? 'app' . $applicationId : 'server';

        if (!isset($this->_updatedVarsBuffer[$context->name][$appGroup])) {
            $this->_updatedVarsBuffer[$context->name][$appGroup] = [];
        }

        $this->_updatedVarsBuffer[$context->name][$appGroup][$variableName] = [
            'context' => $context,
            'groupName' => $groupName,
            'applicationId' => $applicationId,
            'value' => $variableValue
        ];
    }

    public function persistConfiguration(): array
    {
        $changed = false;

        foreach ($this->_updatedVarsBuffer as $context => $bufferedApplicationGroups) {
            foreach ($bufferedApplicationGroups as $group => $bufferedGroupVars) {
                foreach ($bufferedGroupVars as $varName => $varInfos) {
                    $changed = $this->variableStoreRepository->setVariableValue(
                            $varInfos['context'],
                            $varName,
                            $varInfos['value'],
                            $varInfos['applicationId']
                        ) || $changed;

                }
            }
        }

        if ($changed) {
            $this->variableStoreRepository->flush();
        }

        return $this->getConfigurations();
    }

    public function getConfigurations(): array
    {
        if (!$this->loaded) {
            return $this->_loadConfiguration();
        }
        return $this->buffer;
    }

    private function _loadConfiguration(): array
    {
        $this->buffer = [];
        $individualsBuffer = [];

        $this->_defineBufferItems();
        $this->_enrichBufferItemsWithValues();

        // set default values if needed
        for ($i = 0; $i < count($this->buffer); $i++) {
            $bufferedGroup = $this->buffer[$i];
            for ($j = 0; $j < count($bufferedGroup['items']); $j++) {
                $bufferedItem = $bufferedGroup['items'][$j];
                if (count($bufferedItem['values']) === 0) {
                    $this->buffer[$i]['items'][$j]['values'][] = [
                        'application_id' => -1,
                        'context' => eMacroVariableContext::SERVER,
                        'value' => $bufferedItem['inputDef']->defaultValue,
                    ];
                }
            }
        }

        $this->buffer = array_merge($this->buffer, [
            $this->buildBufferGroup(
                self::KEY_INDIVIDUALS,
                'Individuals',
                AbstractConfigurationGroup::VIEW_CONTEXT_SETTINGS,
                $individualsBuffer,
            )
        ]);
        $this->loaded = true;

        return $this->buffer;
    }

    private function _defineBufferItems(): void
    {
        foreach ($this->configurations as $configuration) {
            $bufferItems = [];
            /**
             * @var $item ConfigurationItemDTO
             */
            foreach ($configuration->getItems() as $item) {
                $bufferItems[] = $this->buildBufferItem(
                    $configuration->getKey() . '.' . $item->key,
                    $item->label,
                    [],
                    $item,
                    $item->needApplication
                );
            }
            $this->buffer[] = $this->buildBufferGroup(
                $configuration->getKey(),
                $configuration->getGroupTitle(),
                $configuration->getViewContext(),
                $bufferItems,
                $configuration->needApplication(),
                $configuration->isPersistable()
            );
        }
    }

    public function buildBufferItem(
        string               $key,
        string               $label,
        mixed                $values,
        ConfigurationItemDTO $inputDef,
        bool                 $needApplication = false
    ): array
    {
        return [
            //'context' => eMacroVariableContext::SERVER,
            'key' => $key,
            'label' => $label,
            'needApplication' => $needApplication,
            'inputDef' => $inputDef,
            'values' => $values
        ];
    }

    public function buildBufferGroup(
        string $key,
        string $label,
        string $viewContext = '',
        array  $items = [],
        bool   $needApplication = false,
        bool   $persistable = true
    ): array
    {
        return [
            'items' => $items,
            'key' => $key,
            'label' => $label,
            'needApplication' => $needApplication,
            'persistable' => $persistable,
            'viewContext' => $viewContext
        ];
    }

    private function _enrichBufferItemsWithValues(): void
    {
        foreach ($this->variableStoreRepository->findAll() as $variableStore) {
            $bufferedItemFound = false;
            for ($i = 0; $i < count($this->buffer); $i++) {
                $bufferedGroup = $this->buffer[$i];
                for ($j = 0; $j < count($bufferedGroup['items']); $j++) {
                    $bufferedItem = $bufferedGroup['items'][$j];
                    if ($bufferedItem['key'] === $variableStore->getName()) {
                        $bufferedItemFound = true;
                        $application = $variableStore->getApplication();

                        $this->buffer[$i]['items'][$j]['values'][] = [
                            'application_id' => $application === null ? -1 : $application->getId(),
                            'context' => $variableStore->getContext(),
                            'type' => $variableStore->getValue()[0],
                            'value' => $variableStore->getValue()[1],
                        ];
                    }
                }
            }
            if (!$bufferedItemFound) {
                $application = $variableStore->getApplication();
                /*
                $individualsBuffer[] = [
                    'key' => $variableStore->getName(),
                    'label' => $variableStore->getName(),
                    'inputDef' => ConfigurationItemDTO::create($variableStore->getName(), $variableStore->getName(), eInputType::TEXT_SINGLE_LINE),
                    'values' => [
                        [
                            'application_id' => $application === null ? -1 : $application->getId(),
                            'context' => $variableStore->getContext(),
                            'type' => $variableStore->getValue()[0],
                            'value' => $variableStore->getValue()[1],
                        ]
                    ]
                ];*/
            }
        }
    }

    public function getValue(
        string $configurationGroupKey,
        string $configurationItemKey,
        int    $applicationId = -1,
        mixed  $defaultValue = null
    ): mixed
    {
        if ($applicationId !== -1) {
            $this->variablesStoreProvider->loadApplicationContext($applicationId);
        }

        $varName = $configurationGroupKey . '.' . $configurationItemKey;

        return $this->variablesStoreProvider->getVariableValue(
            $varName,
            ($applicationId === -1 ? eMacroVariableContext::SERVER : $this->applicationRepository->find($applicationId)->getName()),
            $defaultValue
        );
    }
}