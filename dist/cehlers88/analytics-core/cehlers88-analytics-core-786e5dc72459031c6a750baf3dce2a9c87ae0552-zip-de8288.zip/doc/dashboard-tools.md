# Dashboard Tools

A tool is a tile on the `/dashboard/tools` page of the host application that opens a dialog. The
bundle only ships the templates of a tool; the host application lists it and renders it — see
`DashboardController::tools()` there.

## Templates of a tool

Every tool consists of up to three templates below `templates/tool/`, addressed by the host as
`tool/<file>`:

| Template | Purpose |
|---|---|
| `<name>.html.twig` | the content of the dialog, including its `<style>` |
| `teaser/<name>.html.twig` | SVG illustration used as the background of the tile (optional) |
| `script/<name>.js.twig` | the behaviour, inlined into a `<script>` of the tools page (optional) |

All three receive `toolName`, which is the name the host registered. Element ids are prefixed with
it (`id="{{ toolName ~ '-field--x' }}"`), so several tools can live on the same page. A tool that
needs server-side data gets it from the `templateData` of its registration.

The host application registers it like this:

```php
[
    'description' => 'Enter commands and debug them right away',
    'name' => 'commandConsole',
    'title' => 'Command Console',
    'teaser' => 'teaser/commandConsole.html.twig',
    'template' => 'commandConsole.html.twig',
    'scripts' => ['script/commandConsole.js.twig'],
    'styles' => [],
    'templateData' => [],
]
```

## Command Console

`templates/tool/commandConsole.html.twig` lets commands be entered and debugged without storing a
procedure first. The tool itself runs nothing: it only prepares a command definition — an empty one
or the one pasted into its field — and hands it to the debugger of the host application:

```js
window.application.execDebugger({
    runType: 'commands',
    editable: true,
    commands: [['log', {message: 'hello'}]],
});
```

`editable` makes the commands run type of the debugger an editor instead of a read only preview, so
the commands are entered, run, corrected and run again inside the debugger. Breakpoints, single
steps, the instruction tree and the result view are the ones of that debugger — there is deliberately
no second thing that runs commands. Without `editable` the debugger behaves exactly as before, which
is how the procedure overview and `<exec-viewer>` open it.

A definition is a list of commands, each of them the command name and its properties, which is what
`CommandDefinitionValidator` accepts and `CommandFactory::evalDefinitionArray()` evaluates:

```json
[["setVar", {"name": "x", "value": 5}], ["log", {"message": "done"}]]
```

The field content and the definitions last handed over are kept in `localStorage` under
`analytics.tool.commandConsole.state`, so the tool comes back the way it was left.
