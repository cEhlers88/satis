<?php

namespace Cehlers88\AnalyticsCore\Support;

use Cehlers88\AnalyticsCore\Entity\CustomEntityAttributeMonitoring;
use Cehlers88\AnalyticsCore\Entity\Statistics;
use Cehlers88\AnalyticsCore\Repository\CustomEntityAttributeMonitoringRepository;
use Cehlers88\AnalyticsCore\Repository\CustomEntityAttributeRepository;
use Cehlers88\AnalyticsCore\Repository\StatisticsRepository;
use Cehlers88\AnalyticsCore\Support\MonitoringRule\AbstractMonitoringRule;
use Cehlers88\AnalyticsCore\Support\MonitoringRule\MonitoringRuleInterface;

class Monitoring
{
    public function __construct(
        private CustomEntityAttributeMonitoringRepository $customEntityAttributeMonitoringRepository,
        private CustomEntityAttributeRepository           $customEntityAttributeRepository,
        private StatisticsRepository                      $statisticsRepository,
        private iterable                                  $monitoringRules
    )
    {

    }

    public function run(): void
    {
        $monitoringDefs = $this->getRunnableMonitoringEntities();

        foreach ($monitoringDefs as $monitoring) {
            $ruleHandler = $this->runMonitoringRules($monitoring);

            $statistic = $monitoring->getStatistic();
            if (empty($statistic)) {
                $statistic = new Statistics();
            }

            $statistic->setUpdatedAt(new \DateTime());
            $details = $statistic->getDetails();
            $attributeName = $monitoring->getAttribute()->getName();

            if ($attributeName === 'value') {
                $attributeHolder = $monitoring->getAttribute()->getCustomEntity();
                foreach ($attributeHolder->getAttributes() as $attribute) {
                    if ($attribute->getName() === 'label') {
                        $attributeName = $attribute->getValue();
                    }
                }
            }
            // The options carry the state a rule keeps between runs (what it
            // last fired, the samples it measures), so they are handed on.
            $details["options"] = [
                ...($ruleHandler instanceof MonitoringRuleInterface
                    ? $ruleHandler->getStatisticOptions()
                    : (is_array($details['options'] ?? null) ? $details['options'] : [])),
                'monitoredAttribute' => $attributeName,
            ];
            $value = $monitoring->getAttribute()->getValue();
            $now = new \DateTime()->getTimestamp();
            $writesPoint = true;

            if (MonitoringAverage::isValidInterval($monitoring->getAggregationInterval())) {
                // A sample only - the statistic gets the average of the window
                // once the window is over.
                $averaged = MonitoringAverage::addSample(
                    is_array($details['options'][MonitoringAverage::OPTIONS_KEY] ?? null)
                        ? $details['options'][MonitoringAverage::OPTIONS_KEY]
                        : [],
                    $value,
                    $now,
                    (string)$monitoring->getAggregationInterval()
                );
                $details['options'][MonitoringAverage::OPTIONS_KEY] = $averaged['state'];
                // Readers expect the series once monitoredAttribute is set,
                // also before the first window closes.
                $details[$attributeName] ??= [];
                $details['timestamp'] ??= [];
                $writesPoint = $averaged['point'] !== null;
                if ($writesPoint) {
                    $details[$attributeName][] = $averaged['point']['value'];
                    $details['timestamp'][] = $averaged['point']['timestamp'];
                }
            } else {
                // Without aggregation a window left from an earlier setting
                // would only be stale state.
                unset($details['options'][MonitoringAverage::OPTIONS_KEY]);
                $details[$attributeName][] = is_numeric($value) ? (float)$value : (is_bool($value) ? ($value ? 1 : 0) : $value);
                $details['timestamp'][] = $now;
            }

            // Series of a rule are kept in step with the points of the statistic.
            if ($writesPoint && $ruleHandler instanceof MonitoringRuleInterface) {
                foreach ($ruleHandler->getStatisticDetails() as $name => $value) {
                    if (!is_array($value)) continue;
                    $details[$name][] = $value;
                }
            }
            foreach ($details as $key => $value) {
                // The options are no series - trimming them would drop rule state.
                if (!is_array($value) || $key === 'options') continue;
                while (count($details[$key]) > $monitoring->getMaxLength()) {
                    array_shift($details[$key]);
                }
                while (count($details[$key]) < $monitoring->getMaxLength()){
                    array_unshift($details[$key], 0);
                }
            }

            $statistic->setDetails($details);

            $monitoring->setStatistic($statistic);
            $monitoring->setLastRun(new \DateTime());
            $this->customEntityAttributeMonitoringRepository->save($monitoring, false);
        }

        $this->customEntityAttributeMonitoringRepository->flush();
    }

    /**
     * @return CustomEntityAttributeMonitoring[]
     */
    private function getRunnableMonitoringEntities(): array
    {
        $result = [];
        $monitoringEntities = $this->customEntityAttributeMonitoringRepository->findAll();

        foreach ($monitoringEntities as $monitoring) {
            if (!$this->_checkMonitoringIsRunnable($monitoring)) continue;

            $result[] = $monitoring;
        }

        return $result;
    }

    private function _checkMonitoringIsRunnable(CustomEntityAttributeMonitoring $monitoring): bool
    {
        $runInterval = $monitoring->getRunInterval();
        if (empty($runInterval)) {
            return false;
        }
        if (is_null($monitoring->getLastRun())) {
            return true;
        }

        $nextRunAfter = new \DateTimeImmutable()->setTimestamp($monitoring->getLastRun()->getTimestamp());
        if (empty($nextRunAfter)) {
            return true;
        }

        switch ($runInterval) {
            case 'daily_midnight':
                // Not a DateInterval, so the run is decided here and never falls
                // through to the interval arithmetic below.
                $lastMidnight = new \DateTimeImmutable()->setTime(0, 0, 0);

                return $nextRunAfter->getTimestamp() < $lastMidnight->getTimestamp();
        }

        $nextRunAfter = $nextRunAfter->add(new \DateInterval($runInterval));
        $nextRunAfter = $nextRunAfter->setTime(
            (int)$nextRunAfter->format('H'),
            (int)$nextRunAfter->format('i'),
            0
        );

        if ($nextRunAfter->getTimestamp() < new \DateTimeImmutable()->getTimestamp()) {
            return true;
        }

        return false;
    }

    public function runMonitoringRules(
        CustomEntityAttributeMonitoring $monitoring
    ): ?MonitoringRuleInterface
    {
        $ruleHandler = $this->_getMonitoringRuleHandler($monitoring->getRuleHandler() ?? '');

        try {
            if (empty($ruleHandler)) {
                return null;
            }
            $attribute = $monitoring->getAttribute();
            // A monitoring that has never run yet carries no statistic.
            $details = $monitoring->getStatistic()?->getDetails() ?? [];

            $ruleHandler
                ->setAttributeMonitoring($monitoring)
                ->setArguments($monitoring->getRuleArguments() ?? [])
                ->setAttributeToCheck($attribute)
                ->setStatisticOptions(is_array($details['options'] ?? null) ? $details['options'] : [])
                ->execute();
            $this->storeRuleOptions($monitoring, $ruleHandler->getStatisticOptions());
        } catch (\Exception $e) {
            echo $e->getMessage();
            return null;
        }

        return $ruleHandler;
    }

    /**
     * Puts the state the rule left into the statistic right away, since rules
     * also run outside run() - CustomObjectProvider runs them whenever an
     * attribute changes. Whoever runs the rule flushes the monitoring.
     */
    private function storeRuleOptions(CustomEntityAttributeMonitoring $monitoring, array $options): void
    {
        $statistic = $monitoring->getStatistic() ?? new Statistics();
        $details = $statistic->getDetails();
        $details['options'] = $options;
        $statistic->setDetails($details);
        $monitoring->setStatistic($statistic);
    }

    private function _getMonitoringRuleHandler(string $name): ?AbstractMonitoringRule
    {
        foreach ($this->monitoringRules as $monitoringRule) {
            $className = $monitoringRule::class;
            if ($className === $name) {
                return clone $monitoringRule;
            }

            // remove fqcn from class name
            $className = substr($className, strrpos($className, '\\') + 1);
            if ($className === $name) {
                return clone $monitoringRule;
            }
        }

        return null;
    }
}