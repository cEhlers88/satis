<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\Exception\ValidationFailedException;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;

/**
 * Checks a value against simple rules before it goes on - into saveCustomObject,
 * to an external service - for values a procedure gets from outside: GET/POST,
 * a webhook, arguments.
 *
 *     ["validate", {
 *         "value": ["get_var", {"name": "order", "context": "post"}],
 *         "rules": {
 *             "email": "required|email",
 *             "amount": "required|number|min:0",
 *             "country": "in:DE,AT,CH",
 *             "items.*.sku": "required|regex:/^[A-Z]{3}-\\d+$/"
 *         },
 *         "mode": "errors"
 *     }]
 *
 * `rules` names fields by path (`customer.address.zip`; `*` stands for every
 * entry of a list) and gives each a text of rules divided by `|`, or a list of
 * them. A text alone checks the value itself. The rules:
 *
 *   required        present and not empty (null, "", [] are empty)
 *   string, number, integer, boolean, date, email, url, list, object
 *                   the kind of value - texts that look like one count, so
 *                   "12" from a form is a number
 *   min:n, max:n    the smallest/largest number, the shortest/longest text,
 *                   the fewest/most entries of a list
 *   in:a,b,c        one of these values
 *   regex:pattern   matches (with or without delimiters, see regexMatch) -
 *                   last in a text of rules, since the pattern may hold a `|`
 *
 * A field that is not required and empty is not checked further.
 *
 * Mode "errors" (default) returns {valid, errors: [{field, rule, message}]};
 * mode "throw" raises a ValidationFailedException with all messages when a rule
 * fails - catchable by tryCatch - and returns the same as "errors" otherwise.
 *
 * Mind that a list with a single entry passed as an argument arrives as that
 * entry (AbstractMacro::execute) - check a list that may hold one entry as a
 * field of an object.
 */
class ValidateMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const string MODE_ERRORS = 'errors';
    public const string MODE_THROW = 'throw';

    private const string PROPERTY_MODE = 'mode';
    private const string PROPERTY_RULES = 'rules';
    private const string PROPERTY_VALUE = 'value';

    private const array TYPE_RULES = ['string', 'number', 'integer', 'boolean', 'date', 'email', 'url', 'list', 'object'];

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_RULES => PropertyUi::map()->placeholder('required|email'),
            self::PROPERTY_MODE => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options([
                self::MODE_ERRORS => 'Fehlerliste zurückgeben',
                self::MODE_THROW => 'Fehler werfen (tryCatch)',
            ]),
            default => null,
        };
    }

    public function init(): ValidateMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'mixed', 'The value to check', null))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_RULES, ['array', 'string'], 'The rules: field path => rules like "required|email", or one text of rules for the value itself'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_MODE, 'string', 'errors: return the errors, throw: raise an error when a rule fails', self::MODE_ERRORS));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Checks a value or the fields of an object against rules like required, number, email, min/max - returns the errors or raises one.';
    }

    public function getName(): string
    {
        return 'validate';
    }

    protected function run(): ?array
    {
        $value = $this->getPropertyValue(self::PROPERTY_VALUE);
        $rules = $this->getPropertyValue(self::PROPERTY_RULES);
        $mode = strtolower(trim((string)$this->getPropertyValue(self::PROPERTY_MODE)));
        $mode = $mode === '' ? self::MODE_ERRORS : $mode;

        if ($mode !== self::MODE_ERRORS && $mode !== self::MODE_THROW) {
            return $this->_createRunResult(null, ErrorDTO::create(422, sprintf(
                'Unknown mode "%s" - use "%s" or "%s".', $mode, self::MODE_ERRORS, self::MODE_THROW
            )));
        }

        try {
            $errors = self::validate($value, $rules);
        } catch (\InvalidArgumentException $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(422, $exception->getMessage()));
        }

        if ($errors !== [] && $mode === self::MODE_THROW) {
            throw new ValidationFailedException($errors);
        }

        return $this->_createRunResult(['valid' => $errors === [], 'errors' => $errors]);
    }

    /**
     * @return list<array{field: string, rule: string, message: string}>
     * @throws \InvalidArgumentException for rules that cannot be read
     */
    public static function validate(mixed $value, mixed $rules): array
    {
        $value = self::normalize($value);
        $rules = self::normalize($rules);

        if (is_string($rules) || (is_array($rules) && $rules !== [] && array_is_list($rules))) {
            // rules for the value itself - a text, or a list of single rules
            $rules = ['' => $rules];
        }
        if (!is_array($rules) || $rules === []) {
            throw new \InvalidArgumentException('validate needs rules - a text like "required|number" or field => rules.');
        }

        $errors = [];
        foreach ($rules as $path => $fieldRules) {
            $path = trim((string)$path);
            $fieldRules = self::parseRules($fieldRules, $path);

            foreach (self::resolve($value, $path === '' ? [] : explode('.', $path), '') as [$field, $exists, $fieldValue]) {
                array_push($errors, ...self::check($field === '' ? 'value' : $field, $exists, $fieldValue, $fieldRules));
            }
        }

        return $errors;
    }

    /**
     * @param list<array{0: string, 1: ?string}> $rules rule name and argument
     * @return list<array{field: string, rule: string, message: string}>
     */
    private static function check(string $field, bool $exists, mixed $value, array $rules): array
    {
        $names = array_column($rules, 0);
        $empty = !$exists || $value === null || (is_string($value) && trim($value) === '') || $value === [];

        if ($empty) {
            return in_array('required', $names, true)
                ? [self::error($field, 'required', 'is required')]
                : [];
        }

        $numeric = is_int($value) || is_float($value)
            || (is_numeric($value) && (in_array('number', $names, true) || in_array('integer', $names, true)));

        $errors = [];
        foreach ($rules as [$rule, $argument]) {
            $message = match ($rule) {
                'required' => null,
                'string' => is_string($value) ? null : 'must be a text',
                'number' => is_numeric($value) && !is_bool($value) ? null : 'must be a number',
                'integer' => filter_var($value, FILTER_VALIDATE_INT) !== false && !is_bool($value) ? null : 'must be a whole number',
                'boolean' => is_bool($value) || in_array(is_string($value) ? strtolower(trim($value)) : $value, [0, 1, '0', '1', 'true', 'false'], true) ? null : 'must be true or false',
                'date' => self::isDate($value) ? null : 'must be a date',
                'email' => is_string($value) && filter_var(trim($value), FILTER_VALIDATE_EMAIL) !== false ? null : 'must be an e-mail address',
                'url' => is_string($value) && filter_var(trim($value), FILTER_VALIDATE_URL) !== false ? null : 'must be a URL',
                'list' => is_array($value) && array_is_list($value) ? null : 'must be a list',
                'object' => is_array($value) && !array_is_list($value) ? null : 'must be an object',
                'min', 'max' => self::checkSize($value, $rule, (float)$argument, $numeric),
                'in' => self::checkIn($value, (string)$argument),
                'regex' => self::checkRegex($value, (string)$argument),
            };

            if ($message !== null) {
                $errors[] = self::error($field, $rule, $message);
            }
        }

        return $errors;
    }

    private static function checkSize(mixed $value, string $rule, float $limit, bool $numeric): ?string
    {
        [$size, $what] = match (true) {
            $numeric => [(float)$value, ''],
            is_array($value) => [count($value), ' entries'],
            is_scalar($value) => [mb_strlen((string)$value), ' characters'],
            default => [null, ''],
        };

        if ($size === null) {
            return 'has no size to compare';
        }

        $shown = rtrim(rtrim(sprintf('%.6F', $limit), '0'), '.');
        if ($rule === 'min' && $size < $limit) {
            return $numeric ? sprintf('must be at least %s', $shown) : sprintf('needs at least %s%s', $shown, $what);
        }
        if ($rule === 'max' && $size > $limit) {
            return $numeric ? sprintf('must be at most %s', $shown) : sprintf('may have at most %s%s', $shown, $what);
        }

        return null;
    }

    private static function checkIn(mixed $value, string $argument): ?string
    {
        $allowed = array_map('trim', explode(',', $argument));

        return is_scalar($value) && in_array(trim((string)$value), $allowed, true)
            ? null
            : sprintf('must be one of %s', implode(', ', $allowed));
    }

    private static function checkRegex(mixed $value, string $pattern): ?string
    {
        if (!is_scalar($value)) {
            return 'must be a text matching ' . $pattern;
        }

        return preg_match(RegexMatchMacro::delimit($pattern), (string)$value) === 1 ? null : 'does not match ' . $pattern;
    }

    private static function isDate(mixed $value): bool
    {
        if (!is_string($value) || trim($value) === '') {
            return false;
        }

        try {
            new \DateTimeImmutable(trim($value));
        } catch (\Throwable) {
            return false;
        }

        // "2026-02-31" is only a warning to the parser (it would become 3 March) - not a date
        return \DateTimeImmutable::getLastErrors() === false;
    }

    /**
     * Every value the path stands for - one, or one per list entry for `*`.
     *
     * @param list<string> $segments
     * @return list<array{0: string, 1: bool, 2: mixed}> path, whether it exists, value
     */
    private static function resolve(mixed $value, array $segments, string $path): array
    {
        if ($segments === []) {
            return [[$path, true, $value]];
        }

        $segment = array_shift($segments);
        $prefix = $path === '' ? '' : $path . '.';

        if ($segment === '*') {
            if (!is_array($value)) {
                return [];
            }
            $resolved = [];
            foreach ($value as $key => $entry) {
                array_push($resolved, ...self::resolve($entry, $segments, $prefix . $key));
            }

            return $resolved;
        }

        if (!is_array($value) || !array_key_exists($segment, $value)) {
            // a missing field is reported once, under the path that was asked for
            return [[$prefix . implode('.', [$segment, ...$segments]), false, null]];
        }

        return self::resolve($value[$segment], $segments, $prefix . $segment);
    }

    /**
     * @return list<array{0: string, 1: ?string}>
     */
    private static function parseRules(mixed $rules, string $path): array
    {
        if (is_string($rules)) {
            // a regex takes everything after it - its pattern may hold a "|"
            $regexAt = preg_match('/(^|\|)\s*regex:/', $rules, $match, PREG_OFFSET_CAPTURE) === 1 ? $match[0][1] : null;
            $regex = $regexAt === null ? null : ltrim(substr($rules, $regexAt), '|');
            $rules = explode('|', $regexAt === null ? $rules : substr($rules, 0, $regexAt));
            if ($regex !== null) {
                $rules[] = $regex;
            }
        }
        if (!is_array($rules)) {
            throw new \InvalidArgumentException(sprintf('The rules of "%s" have to be a text like "required|number".', $path));
        }

        $parsed = [];
        foreach ($rules as $rule) {
            if (!is_string($rule) || trim($rule) === '') {
                continue;
            }

            [$name, $argument] = array_pad(explode(':', trim($rule), 2), 2, null);
            $name = strtolower(trim($name));
            $name = match ($name) {
                'numeric' => 'number',
                'int' => 'integer',
                'bool' => 'boolean',
                'text' => 'string',
                'array' => 'list',
                default => $name,
            };

            if (!in_array($name, ['required', 'min', 'max', 'in', 'regex', ...self::TYPE_RULES], true)) {
                throw new \InvalidArgumentException(sprintf('Unknown rule "%s" for "%s".', $name, $path === '' ? 'value' : $path));
            }
            if (in_array($name, ['min', 'max'], true) && !is_numeric(trim((string)$argument))) {
                throw new \InvalidArgumentException(sprintf('The rule "%s" needs a number, like "%s:3".', $name, $name));
            }
            if ($name === 'regex') {
                $argument = trim((string)$argument);
                if ($argument === '' || @preg_match(RegexMatchMacro::delimit($argument), '') === false) {
                    throw new \InvalidArgumentException(sprintf('Invalid pattern "%s" for "%s".', $argument, $path === '' ? 'value' : $path));
                }
            }

            $parsed[] = [$name, $argument === null ? null : (string)$argument];
        }

        return $parsed;
    }

    /** Objects (from JSON) become arrays, all the way down. */
    private static function normalize(mixed $value): mixed
    {
        if (is_object($value)) {
            $value = get_object_vars($value);
        }

        return is_array($value) ? array_map(self::normalize(...), $value) : $value;
    }

    /** @return array{field: string, rule: string, message: string} */
    private static function error(string $field, string $rule, string $message): array
    {
        return ['field' => $field, 'rule' => $rule, 'message' => $field . ' ' . $message];
    }
}
