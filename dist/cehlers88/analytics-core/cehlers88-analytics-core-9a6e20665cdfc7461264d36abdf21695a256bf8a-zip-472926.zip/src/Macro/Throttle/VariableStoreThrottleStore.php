<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\Throttle;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Repository\VariableStoreRepository;

/**
 * Keeps the times in the variable store, as THROTTLE.<key> - in the application
 * context of the application, or in the server context without one. No table of
 * its own: the rows show up in the settings under "Individuals", where deleting
 * one lets the commands run again at once.
 *
 * Written at once, not with VariablesProvider::save(): that is only called by
 * worker jobs, and a procedure or the command console would forget the time.
 */
final class VariableStoreThrottleStore implements ThrottleStoreInterface
{
    public const string NAME_PREFIX = 'THROTTLE.';

    public function __construct(
        private readonly VariableStoreRepository $variableStoreRepository
    )
    {
    }

    public function getLastRun(string $key, ?Application $application): ?\DateTimeImmutable
    {
        $value = $this->variableStoreRepository->getVariableValue(
            self::NAME_PREFIX . $key,
            $this->context($application),
            $application?->getId() ?? -1
        );

        if (!is_string($value) || $value === '') {
            return null;
        }

        try {
            return new \DateTimeImmutable($value);
        } catch (\Throwable) {
            return null;
        }
    }

    public function setLastRun(string $key, ?Application $application, \DateTimeImmutable $time): void
    {
        $this->variableStoreRepository->setVariableValue(
            $this->context($application),
            self::NAME_PREFIX . $key,
            ['string', $time->format(\DateTimeInterface::ATOM)],
            $application?->getId() === null ? -1 : $application
        );
        $this->variableStoreRepository->flush();
    }

    private function context(?Application $application): eMacroVariableContext
    {
        return $application?->getId() === null ? eMacroVariableContext::SERVER : eMacroVariableContext::APPLICATION;
    }
}
