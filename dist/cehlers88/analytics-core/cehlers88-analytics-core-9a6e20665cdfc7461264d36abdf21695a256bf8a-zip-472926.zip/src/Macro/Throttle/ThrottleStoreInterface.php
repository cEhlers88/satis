<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\Throttle;

use Cehlers88\AnalyticsCore\Entity\Application;

/**
 * Remembers when the `throttle` macro last let its commands run under a key -
 * across runs, so a worker that checks every minute still reports only once
 * an hour. A key belongs to an application; without one it is global.
 */
interface ThrottleStoreInterface
{
    public function getLastRun(string $key, ?Application $application): ?\DateTimeImmutable;

    public function setLastRun(string $key, ?Application $application, \DateTimeImmutable $time): void;
}
