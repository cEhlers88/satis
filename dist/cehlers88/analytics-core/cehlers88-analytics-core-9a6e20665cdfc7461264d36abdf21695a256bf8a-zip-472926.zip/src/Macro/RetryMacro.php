<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogReason;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\Exception\UncatchableExceptionInterface;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\SelectVarNameValueHelper;

/**
 * Runs commands and, when one of them fails, runs them again - for the calls
 * that fail only now and then: an external service that is busy, a webhook
 * that times out.
 *
 *     ["retry", {
 *         "commands": [["call_external_service", {...}]],
 *         "attempts": 3,
 *         "delay": 2,
 *         "backoff": true,
 *         "errorVar": "error",
 *         "attemptVar": "attempt"
 *     }]
 *
 * `attempts` counts all runs, the first one included (1 to MAX_ATTEMPTS).
 * Between two runs the macro waits `delay` seconds; with `backoff` the wait
 * doubles every time (2, 4, 8 ...), never longer than MAX_DELAY_SECONDS.
 *
 * The result is the one of the run that succeeded. When every run failed, the
 * error of the last one is handed on - a surrounding tryCatch can catch it, as
 * it would catch the error without retry. A run stopped from outside is never
 * retried. A `throw` inside the commands is an error like any other, so a
 * definition can ask for another run when a result is not what it needs.
 */
class RetryMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const int DEFAULT_ATTEMPTS = 3;
    public const int MAX_ATTEMPTS = 10;
    public const int MAX_DELAY_SECONDS = 300;
    public const string DEFAULT_ERROR_VAR = 'error';

    private const string PROPERTY_ATTEMPTS = 'attempts';
    private const string PROPERTY_ATTEMPT_VAR = 'attemptVar';
    private const string PROPERTY_BACKOFF = 'backoff';
    private const string PROPERTY_COMMANDS = 'commands';
    private const string PROPERTY_DELAY = 'delay';
    private const string PROPERTY_ERROR_VAR = 'errorVar';

    /** @var callable(float): void */
    private $sleeper;

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_COMMANDS => PropertyUi::commands()->displayName('Do'),
            self::PROPERTY_ATTEMPTS => PropertyUi::create()->placeholder((string)self::DEFAULT_ATTEMPTS),
            self::PROPERTY_DELAY => PropertyUi::create()->placeholder('0 (Sekunden)'),
            self::PROPERTY_ERROR_VAR => PropertyUi::create()->displayName('Error variable')->valueHelper(SelectVarNameValueHelper::class),
            self::PROPERTY_ATTEMPT_VAR => PropertyUi::create()->displayName('Attempt variable')->valueHelper(SelectVarNameValueHelper::class),
            default => null,
        };
    }

    public function init(): RetryMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_COMMANDS, 'array', 'Specify the commands to run'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ATTEMPTS, 'int', sprintf('How often the commands run at most, the first run included (1 to %d)', self::MAX_ATTEMPTS), self::DEFAULT_ATTEMPTS))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DELAY, ['float', 'int'], 'Seconds to wait before the next run', 0))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_BACKOFF, MacroPropertyDTO::TYPE_BOOLEAN, 'Double the wait after every failed run', false))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ERROR_VAR, 'string', 'Name of variable to store the message of the last error in', self::DEFAULT_ERROR_VAR))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ATTEMPT_VAR, 'string', 'Name of variable to store the current run in (counted from 1)', ''));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Run commands again when they fail - a number of times, with a wait in between.';
    }

    public function getName(): string
    {
        return 'retry';
    }

    public function needPrecompiledArguments(): bool
    {
        return false;
    }

    /**
     * Replaces the wait between two runs - for tests, which must not sleep.
     *
     * @internal
     * @param callable(float): void $sleeper gets the seconds to wait
     */
    public function setSleeper(callable $sleeper): static
    {
        $this->sleeper = $sleeper;

        return $this;
    }

    protected function run(): ?array
    {
        // Read before anything runs: the macro is one instance, a retry inside
        // the commands sets its properties anew.
        $commands = $this->getPropertyValue(self::PROPERTY_COMMANDS);
        $attempts = self::readAttempts($this->resolve($this->getPropertyValue(self::PROPERTY_ATTEMPTS)));
        $delay = self::readDelay($this->resolve($this->getPropertyValue(self::PROPERTY_DELAY)));
        $backoff = filter_var($this->resolve($this->getPropertyValue(self::PROPERTY_BACKOFF)), FILTER_VALIDATE_BOOLEAN);
        $errorVar = self::readName($this->resolve($this->getPropertyValue(self::PROPERTY_ERROR_VAR)));
        $attemptVar = self::readName($this->resolve($this->getPropertyValue(self::PROPERTY_ATTEMPT_VAR)));

        for ($attempt = 1; ; $attempt++) {
            if ($attemptVar !== '') {
                $this->_executeMacro('setVar', ['name' => $attemptVar, 'value' => $attempt]);
            }

            try {
                $result = $this->runCommands($commands);
            } catch (UncatchableExceptionInterface $e) {
                throw $e;
            } catch (\Throwable $e) {
                if ($errorVar !== '') {
                    $this->_executeMacro('setVar', ['name' => $errorVar, 'value' => $e->getMessage()]);
                }

                if ($attempt >= $attempts) {
                    $this->log(eDebuggerLogType::WARNING,
                        sprintf('Run %d of %d failed, giving up: %s', $attempt, $attempts, $e->getMessage()),
                        ['error' => $e->getMessage(), 'attempt' => $attempt]
                    );
                    throw $e;
                }

                $wait = self::waitBefore($attempt + 1, $delay, $backoff);
                $this->log(eDebuggerLogType::WARNING,
                    sprintf('Run %d of %d failed, next run in %ss: %s', $attempt, $attempts, $wait, $e->getMessage()),
                    ['error' => $e->getMessage(), 'attempt' => $attempt, 'reason' => eDebuggerLogReason::INFO]
                );
                $this->sleep($wait);

                continue;
            }

            if ($attempt > 1) {
                $this->log(eDebuggerLogType::INFO, sprintf('Run %d of %d succeeded', $attempt, $attempts), ['attempt' => $attempt]);
            }

            return $this->_createRunResult($result ?? ['__void' => true]);
        }
    }

    /**
     * Values typed into the editor arrive as strings. Anything that is no whole
     * number of at least 1 means the default, more than MAX_ATTEMPTS is cut.
     */
    public static function readAttempts(mixed $value): int
    {
        if (is_string($value)) {
            $value = trim($value);
        }
        if (!is_numeric($value) || (int)$value != $value || (int)$value < 1) {
            return self::DEFAULT_ATTEMPTS;
        }

        return min((int)$value, self::MAX_ATTEMPTS);
    }

    public static function readDelay(mixed $value): float
    {
        if (is_string($value)) {
            $value = str_replace(',', '.', trim($value));
        }

        return is_numeric($value) && (float)$value > 0 ? min((float)$value, self::MAX_DELAY_SECONDS) : 0.0;
    }

    /** The seconds to wait before run $attempt (2 for the first retry). */
    public static function waitBefore(int $attempt, float $delay, bool $backoff): float
    {
        $wait = $backoff ? $delay * (2 ** max(0, $attempt - 2)) : $delay;

        return min($wait, (float)self::MAX_DELAY_SECONDS);
    }

    private static function readName(mixed $value): string
    {
        return is_string($value) ? trim($value) : '';
    }

    private function sleep(float $seconds): void
    {
        if ($seconds <= 0) {
            return;
        }
        if ($this->sleeper !== null) {
            ($this->sleeper)($seconds);

            return;
        }

        usleep((int)round($seconds * 1_000_000));
    }

    private function resolve(mixed $value): mixed
    {
        return ($value instanceof CommandDTO || $value instanceof CommandGroupDTO)
            ? $this->_runCommandDefinition($value)
            : $value;
    }

    private function runCommands(mixed $commands): mixed
    {
        if ($commands === null || $commands === [] || $commands === '') {
            return null;
        }

        return $this->_runCommandDefinition($commands);
    }
}
