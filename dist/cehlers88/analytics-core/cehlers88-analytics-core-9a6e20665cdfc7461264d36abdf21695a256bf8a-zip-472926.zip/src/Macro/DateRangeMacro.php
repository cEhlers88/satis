<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use DateTimeImmutable;
use DateTimeZone;

/**
 * Returns the first and the last moment of a named period - "last month",
 * "this quarter", "the last 7 days" - and, on request, the period before it and
 * the days, weeks or months it consists of.
 *
 *     ["date_range", {"period": "lastMonth", "previous": true, "buckets": "week"}]
 *
 *     {
 *         "from": "2026-10-01", "to": "2026-10-31", "days": 31,
 *         "previous": {"from": "2026-09-01", "to": "2026-09-30", "days": 30},
 *         "buckets": [{"label": "2026-W40", "from": "2026-10-01", "to": "2026-10-04"}, ...]
 *     }
 *
 * Periods are whole days: `from` is 00:00:00 of the first day, `to` 23:59:59 of
 * the last, which a format with a time shows. Weeks start on Monday. "this..."
 * periods are whole (this month ends on its last day, also when that is still
 * to come); "...ToDate" periods end with the day of `date`.
 *
 * `previous` is the period right before: the month before a month, the same
 * number of days before "lastDays" and "custom", and for "...ToDate" the same
 * stretch of the unit before (1 to 13 November -> 1 to 13 October; the end is cut
 * at the end of that unit, 1 to 31 March -> 1 to 29 February).
 *
 * Buckets cover the period without gaps - a list to run through with `for` or to
 * use as the axis of a chart, so a day without data still has its place. The
 * first and the last bucket are cut to the period.
 */
class DateRangeMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public const int MAX_BUCKETS = 3660;

    /** @var array<string, string> period => label for the editor */
    public const array PERIODS = [
        'today' => 'Heute',
        'yesterday' => 'Gestern',
        'thisWeek' => 'Diese Woche',
        'lastWeek' => 'Letzte Woche',
        'thisMonth' => 'Dieser Monat',
        'lastMonth' => 'Letzter Monat',
        'thisQuarter' => 'Dieses Quartal',
        'lastQuarter' => 'Letztes Quartal',
        'thisYear' => 'Dieses Jahr',
        'lastYear' => 'Letztes Jahr',
        'weekToDate' => 'Woche bis heute',
        'monthToDate' => 'Monat bis heute',
        'quarterToDate' => 'Quartal bis heute',
        'yearToDate' => 'Jahr bis heute',
        'lastDays' => 'Letzte N Tage (days)',
        'custom' => 'Eigener Zeitraum (from/to)',
    ];

    /** @var array<string, string> bucket unit => label for the editor */
    public const array BUCKETS = [
        '' => 'Keine',
        'day' => 'Tage',
        'week' => 'Wochen',
        'month' => 'Monate',
        'quarter' => 'Quartale',
        'year' => 'Jahre',
    ];

    private const string PROPERTY_BUCKETS = 'buckets';
    private const string PROPERTY_DATE = 'date';
    private const string PROPERTY_DAYS = 'days';
    private const string PROPERTY_FORMAT = 'format';
    private const string PROPERTY_FROM = 'from';
    private const string PROPERTY_PERIOD = 'period';
    private const string PROPERTY_PREVIOUS = 'previous';
    private const string PROPERTY_TIMEZONE = 'timezone';
    private const string PROPERTY_TO = 'to';

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_PERIOD => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options(self::PERIODS),
            self::PROPERTY_BUCKETS => PropertyUi::create()->editor(PropertyUi::EDITOR_SELECT)->options(self::BUCKETS),
            self::PROPERTY_DATE => PropertyUi::create()->placeholder('now'),
            self::PROPERTY_DAYS => PropertyUi::create()->placeholder('7 (nur für lastDays)'),
            self::PROPERTY_FROM => PropertyUi::create()->placeholder('2026-01-01 (nur für custom)'),
            self::PROPERTY_TO => PropertyUi::create()->placeholder('now (nur für custom)'),
            self::PROPERTY_FORMAT => PropertyUi::create()->options([
                'Y-m-d' => '2026-10-31',
                'Y-m-d H:i:s' => '2026-10-31 23:59:59',
                'd.m.Y' => '31.10.2026',
                'c' => 'ISO 8601',
                'U' => 'Unix-Zeitstempel',
            ]),
            self::PROPERTY_TIMEZONE => PropertyUi::create()->placeholder(date_default_timezone_get()),
            default => null,
        };
    }

    public function init(): DateRangeMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_PERIOD, 'string', 'The period: ' . implode(', ', array_keys(self::PERIODS))))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DATE, 'string', 'The day the period is seen from', 'now'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DAYS, 'int', 'Number of days for "lastDays", today included', 7))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_FROM, 'string', 'First day for "custom"', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TO, 'string', 'Last day for "custom"', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_PREVIOUS, MacroPropertyDTO::TYPE_BOOLEAN, 'Also return the period right before', false))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_BUCKETS, 'string', 'Also return the days, weeks, months, quarters or years of the period', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_FORMAT, 'string', 'Format of the dates (PHP date format)', 'Y-m-d'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TIMEZONE, 'string', 'Timezone, the server\'s when empty', ''));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Returns first and last day of a period like last month or this quarter - with the period before and its days, weeks or months.';
    }

    public function getName(): string
    {
        return 'dateRange';
    }

    protected function run(): ?array
    {
        $period = trim((string)$this->getPropertyValue(self::PROPERTY_PERIOD));
        $buckets = strtolower(trim((string)$this->getPropertyValue(self::PROPERTY_BUCKETS)));
        $format = (string)$this->getPropertyValue(self::PROPERTY_FORMAT);
        $format = trim($format) === '' ? 'Y-m-d' : $format;
        $withPrevious = filter_var($this->getPropertyValue(self::PROPERTY_PREVIOUS), FILTER_VALIDATE_BOOLEAN);

        try {
            if (!array_key_exists($buckets, self::BUCKETS)) {
                throw new \InvalidArgumentException(sprintf(
                    'Unknown buckets "%s" - use one of %s.', $buckets, implode(', ', array_filter(array_keys(self::BUCKETS)))
                ));
            }

            $timezone = $this->readTimezone();
            $range = self::range(
                $period,
                self::readDate($this->getPropertyValue(self::PROPERTY_DATE), $timezone, 'date', true),
                $this->getPropertyValue(self::PROPERTY_DAYS),
                fn(): DateTimeImmutable => self::readDate($this->getPropertyValue(self::PROPERTY_FROM), $timezone, 'from', false),
                fn(): DateTimeImmutable => self::readDate($this->getPropertyValue(self::PROPERTY_TO), $timezone, 'to', true),
            );

            $result = self::describe($range[0], $range[1], $format);
            if ($withPrevious) {
                $previous = self::previous($period, $range[0], $range[1]);
                $result['previous'] = self::describe($previous[0], $previous[1], $format);
            }
            if ($buckets !== '') {
                $result['buckets'] = self::buckets($range[0], $range[1], $buckets, $format);
            }
        } catch (\InvalidArgumentException $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(422, $exception->getMessage()));
        }

        return $this->_createRunResult($result);
    }

    /**
     * First day (00:00:00) and last day (23:59:59) of the period, seen from $date.
     *
     * @param callable(): DateTimeImmutable $from read only for "custom"
     * @param callable(): DateTimeImmutable $to read only for "custom"
     * @return array{0: DateTimeImmutable, 1: DateTimeImmutable}
     */
    public static function range(string $period, DateTimeImmutable $date, mixed $days, callable $from, callable $to): array
    {
        $day = $date->setTime(0, 0);

        [$start, $end] = match ($period) {
            'today' => [$day, $day],
            'yesterday' => [$day->modify('-1 day'), $day->modify('-1 day')],
            'thisWeek' => [self::startOf($day, 'week'), self::endOf($day, 'week')],
            'lastWeek' => [self::startOf($day, 'week')->modify('-1 week'), self::startOf($day, 'week')->modify('-1 day')],
            'thisMonth' => [self::startOf($day, 'month'), self::endOf($day, 'month')],
            'lastMonth' => [self::startOf($day, 'month')->modify('-1 month'), self::startOf($day, 'month')->modify('-1 day')],
            'thisQuarter' => [self::startOf($day, 'quarter'), self::endOf($day, 'quarter')],
            'lastQuarter' => [self::startOf($day, 'quarter')->modify('-3 months'), self::startOf($day, 'quarter')->modify('-1 day')],
            'thisYear' => [self::startOf($day, 'year'), self::endOf($day, 'year')],
            'lastYear' => [self::startOf($day, 'year')->modify('-1 year'), self::startOf($day, 'year')->modify('-1 day')],
            'weekToDate' => [self::startOf($day, 'week'), $day],
            'monthToDate' => [self::startOf($day, 'month'), $day],
            'quarterToDate' => [self::startOf($day, 'quarter'), $day],
            'yearToDate' => [self::startOf($day, 'year'), $day],
            'lastDays' => [$day->modify(sprintf('-%d days', self::readDays($days) - 1)), $day],
            'custom' => [$from()->setTime(0, 0), $to()->setTime(0, 0)],
            default => throw new \InvalidArgumentException(sprintf(
                'Unknown period "%s" - use one of %s.', $period, implode(', ', array_keys(self::PERIODS))
            )),
        };

        if ($end < $start) {
            throw new \InvalidArgumentException('The period ends before it starts - "to" lies before "from".');
        }

        return [$start, $end->setTime(23, 59, 59)];
    }

    /**
     * The period right before the one from $start to $end (see the class comment).
     *
     * @return array{0: DateTimeImmutable, 1: DateTimeImmutable}
     */
    public static function previous(string $period, DateTimeImmutable $start, DateTimeImmutable $end): array
    {
        $unit = match ($period) {
            'today', 'yesterday' => 'day',
            'thisWeek', 'lastWeek', 'weekToDate' => 'week',
            'thisMonth', 'lastMonth', 'monthToDate' => 'month',
            'thisQuarter', 'lastQuarter', 'quarterToDate' => 'quarter',
            'thisYear', 'lastYear', 'yearToDate' => 'year',
            default => null,
        };

        if ($unit === null) {
            // a number of days: the same number right before
            $days = self::countDays($start, $end);
            $previousEnd = $start->modify('-1 day')->setTime(23, 59, 59);

            return [$previousEnd->setTime(0, 0)->modify(sprintf('-%d days', $days - 1)), $previousEnd];
        }

        if ($unit === 'day' || $unit === 'week') {
            // units of a fixed length: the same days one unit earlier
            return [$start->modify(self::step($unit, -1)), $end->modify(self::step($unit, -1))];
        }

        $previousStart = self::startOf($start->modify('first day of this month')->modify(self::step($unit, -1)), $unit);
        $unitEnd = self::endOf($previousStart, $unit)->setTime(23, 59, 59);
        if (!str_ends_with($period, 'ToDate')) {
            return [$previousStart, $unitEnd];
        }

        $sameStretch = $previousStart->modify(sprintf('+%d days', self::countDays($start, $end) - 1))->setTime(23, 59, 59);

        return [$previousStart, min($unitEnd, $sameStretch)];
    }

    /**
     * @return list<array{label: string, from: string, to: string}>
     */
    public static function buckets(DateTimeImmutable $start, DateTimeImmutable $end, string $unit, string $format): array
    {
        $buckets = [];
        $bucketStart = self::startOf($start, $unit);

        while ($bucketStart <= $end) {
            if (count($buckets) >= self::MAX_BUCKETS) {
                throw new \InvalidArgumentException(sprintf(
                    'The period has more than %d %ss - choose larger buckets.', self::MAX_BUCKETS, $unit
                ));
            }

            $next = $bucketStart->modify(self::step($unit, 1));
            $bucketEnd = $next->modify('-1 second');

            $buckets[] = [
                'label' => self::label($bucketStart, $unit),
                'from' => max($bucketStart, $start)->format($format),
                'to' => min($bucketEnd, $end)->format($format),
            ];

            $bucketStart = $next;
        }

        return $buckets;
    }

    /** @return array{from: string, to: string, days: int} */
    private static function describe(DateTimeImmutable $start, DateTimeImmutable $end, string $format): array
    {
        return [
            'from' => $start->format($format),
            'to' => $end->format($format),
            'days' => self::countDays($start, $end),
        ];
    }

    private static function countDays(DateTimeImmutable $start, DateTimeImmutable $end): int
    {
        return (int)$start->setTime(0, 0)->diff($end->setTime(0, 0))->days + 1;
    }

    private static function startOf(DateTimeImmutable $date, string $unit): DateTimeImmutable
    {
        $day = $date->setTime(0, 0);

        return match ($unit) {
            'day' => $day,
            'week' => $day->modify(sprintf('-%d days', (int)$day->format('N') - 1)),
            'month' => $day->modify('first day of this month'),
            'quarter' => $day->setDate((int)$day->format('Y'), intdiv((int)$day->format('n') - 1, 3) * 3 + 1, 1),
            'year' => $day->setDate((int)$day->format('Y'), 1, 1),
        };
    }

    /** The last day (00:00:00) of the unit $date lies in. */
    private static function endOf(DateTimeImmutable $date, string $unit): DateTimeImmutable
    {
        return self::startOf($date, $unit)->modify(self::step($unit, 1))->modify('-1 day');
    }

    private static function step(string $unit, int $count): string
    {
        return match ($unit) {
            'quarter' => sprintf('%+d months', 3 * $count),
            default => sprintf('%+d %s', $count, $unit),
        };
    }

    private static function label(DateTimeImmutable $start, string $unit): string
    {
        return match ($unit) {
            'day' => $start->format('Y-m-d'),
            'week' => $start->format('o-\WW'),
            'month' => $start->format('Y-m'),
            'quarter' => sprintf('%s-Q%d', $start->format('Y'), intdiv((int)$start->format('n') - 1, 3) + 1),
            'year' => $start->format('Y'),
        };
    }

    private static function readDays(mixed $days): int
    {
        if (is_string($days)) {
            $days = trim($days);
        }
        if (!is_numeric($days) || (int)$days != $days || (int)$days < 1) {
            throw new \InvalidArgumentException('"days" has to be a whole number of at least 1.');
        }

        return (int)$days;
    }

    private function readTimezone(): DateTimeZone
    {
        $timezone = trim((string)$this->getPropertyValue(self::PROPERTY_TIMEZONE));

        try {
            return new DateTimeZone($timezone === '' ? date_default_timezone_get() : $timezone);
        } catch (\Throwable) {
            throw new \InvalidArgumentException(sprintf('Unknown timezone "%s".', $timezone));
        }
    }

    private static function readDate(mixed $date, DateTimeZone $timezone, string $property, bool $nowWhenEmpty): DateTimeImmutable
    {
        if ($date === null || $date === '') {
            if (!$nowWhenEmpty) {
                throw new \InvalidArgumentException(sprintf('"%s" needs a date.', $property));
            }

            return new DateTimeImmutable('now', $timezone);
        }

        if (is_int($date) || (is_string($date) && preg_match('/^-?\d{9,}$/', $date) === 1)) {
            return (new DateTimeImmutable('@' . $date))->setTimezone($timezone);
        }

        try {
            $parsed = new DateTimeImmutable((string)$date, $timezone);
        } catch (\Throwable) {
            throw new \InvalidArgumentException(sprintf('Invalid date "%s" in "%s".', (string)$date, $property));
        }
        // "2026-02-31" is not an error to the parser, only a warning - it would become 3 March
        if (DateTimeImmutable::getLastErrors() !== false) {
            throw new \InvalidArgumentException(sprintf('Invalid date "%s" in "%s".', (string)$date, $property));
        }

        // a text with an offset of its own ("...T23:30:00Z") keeps it; the days are those of $timezone
        return $parsed->setTimezone($timezone);
    }
}
