<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\Exception;

/**
 * A value did not hold to the rules the `validate` macro checked it against -
 * raised in its "throw" mode, catchable by tryCatch.
 */
class ValidationFailedException extends \RuntimeException
{
    /**
     * @param list<array{field: string, rule: string, message: string}> $errors
     */
    public function __construct(private readonly array $errors)
    {
        parent::__construct(implode('; ', array_column($errors, 'message')));
    }

    /** @return list<array{field: string, rule: string, message: string}> */
    public function getErrors(): array
    {
        return $this->errors;
    }
}
