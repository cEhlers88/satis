<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Macro\Throttle\ThrottleStoreInterface;
use Symfony\Component\Lock\LockFactory;

/**
 * Runs commands at most once in a while per key - so a worker that checks every
 * minute sends one push notification about a failing service, not sixty an hour.
 *
 *     ["throttle", {
 *         "key": "service-x-down",
 *         "interval": "1 hour",
 *         "commands": [["send_push_notification", {...}]],
 *         "else": [...]
 *     }]
 *
 * The commands run when they never ran under the key, or when `interval` has
 * passed since; otherwise `else` runs (if given). `interval` is a number of
 * seconds or a text like "30 minutes", "1 hour", "1 day" (or "PT1H").
 *
 * The time is kept per application (ThrottleStoreInterface) and written only
 * after the commands succeeded: when they fail, the next run tries again. In the
 * protected mode the commands are decided about and run as usual - they follow
 * the mode themselves - but the time is not written, so a test run in the
 * debugger does not hold back the real one.
 *
 * Two runs at the same time - two workers, a worker and a request - must not
 * both find the interval passed and both run the commands. So a run holds a
 * lock for its application and key from reading the time until it is written;
 * a run that finds the lock taken does not wait, it takes the commands as
 * being run right now and runs `else`.
 *
 * The result tells what happened: {ran, lastRun, nextRun} with the times as
 * ISO 8601 text (lastRun null when the key is new, nextRun null when another
 * run is just running the commands).
 */
class ThrottleMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    private const string PROPERTY_COMMANDS = 'commands';
    private const string PROPERTY_ELSE = 'else';
    private const string PROPERTY_INTERVAL = 'interval';
    private const string PROPERTY_KEY = 'key';

    /** longer than any sensible run - the lock is released at the end anyway */
    public const float LOCK_TTL_SECONDS = 3600.0;

    public function __construct(
        private readonly ThrottleStoreInterface $throttleStore,
        private readonly LockFactory $lockFactory
    )
    {
    }

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            self::PROPERTY_KEY => PropertyUi::create()->placeholder('dienst-x-down'),
            self::PROPERTY_INTERVAL => PropertyUi::create()->options([
                '5 minutes' => '5 Minuten',
                '15 minutes' => '15 Minuten',
                '1 hour' => '1 Stunde',
                '6 hours' => '6 Stunden',
                '1 day' => '1 Tag',
                '1 week' => '1 Woche',
            ]),
            self::PROPERTY_COMMANDS => PropertyUi::commands()->displayName('Do')->cssClass('is-case case-true'),
            self::PROPERTY_ELSE => PropertyUi::commands()->displayName('Else')->cssClass('is-case case-false'),
            default => null,
        };
    }

    public function init(): ThrottleMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_KEY, 'string', 'Name under which the time of the last run is kept'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_INTERVAL, ['string', 'int'], 'How long to wait before the commands may run again - seconds or a text like "1 hour"'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_COMMANDS, 'array', 'Specify the commands to run'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ELSE, 'array', 'Specify commands which should execute when the interval has not passed yet', []));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Run commands at most once per interval - for a key, across runs.';
    }

    public function getName(): string
    {
        return 'throttle';
    }

    public function needPrecompiledArguments(): bool
    {
        return false;
    }

    protected function run(): ?array
    {
        // Read before anything runs: the macro is one instance, a throttle inside
        // the commands sets its properties anew.
        $key = $this->resolve($this->getPropertyValue(self::PROPERTY_KEY));
        $key = is_scalar($key) ? trim((string)$key) : '';
        $intervalValue = $this->resolve($this->getPropertyValue(self::PROPERTY_INTERVAL));
        $commands = $this->getPropertyValue(self::PROPERTY_COMMANDS);
        $else = $this->getPropertyValue(self::PROPERTY_ELSE);

        if ($key === '') {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'throttle needs a key.'));
        }

        $interval = self::readInterval($intervalValue);
        if ($interval === null) {
            return $this->_createRunResult(null, ErrorDTO::create(422, sprintf(
                'Invalid interval "%s" - give seconds or a text like "1 hour".',
                is_scalar($intervalValue) ? (string)$intervalValue : json_encode($intervalValue)
            )));
        }

        $application = $this->getMacroEnvironment()->getApplication();
        $lock = $this->lockFactory->createLock(
            sprintf('analytics.throttle.%s.%s', $application?->getId() ?? 'server', sha1($key)),
            self::LOCK_TTL_SECONDS
        );

        if (!$lock->acquire()) {
            $this->log(eDebuggerLogType::INFO, sprintf('Throttled: "%s" is being run by another run right now', $key));
            $this->runCommands($else);

            $lastRun = $this->throttleStore->getLastRun($key, $application);

            return $this->_createRunResult(self::status(false, $lastRun, null));
        }

        try {
            // read only now: a run that held the lock until a moment ago has just written it
            $now = new \DateTimeImmutable();
            $lastRun = $this->throttleStore->getLastRun($key, $application);
            $due = $lastRun === null ? $now : $lastRun->add($interval);

            if ($due > $now) {
                $lock->release();
                $this->log(eDebuggerLogType::INFO, sprintf(
                    'Throttled: "%s" ran at %s, next run from %s',
                    $key, $lastRun->format('Y-m-d H:i:s'), $due->format('Y-m-d H:i:s')
                ));
                $this->runCommands($else);

                return $this->_createRunResult(self::status(false, $lastRun, $due));
            }

            $this->runCommands($commands);

            $this->runProtectedFragment(fn() => $this->throttleStore->setLastRun($key, $application, $now));

            return $this->_createRunResult(self::status(true, $now, $now->add($interval)));
        } finally {
            // releasing twice is fine - the else branch let go before running `else`
            $lock->release();
        }
    }

    /**
     * Seconds (a number, also as text) or a relative text such as "1 hour" or an
     * ISO 8601 duration ("PT1H"). Null when it is none of them or not positive.
     */
    public static function readInterval(mixed $value): ?\DateInterval
    {
        if (is_string($value)) {
            $value = trim($value);
        }
        if ($value === null || $value === '' || !is_scalar($value)) {
            return null;
        }

        try {
            if (is_numeric($value)) {
                $seconds = (int)round((float)$value);
                $interval = $seconds > 0 ? new \DateInterval('PT' . $seconds . 'S') : null;
            } elseif (preg_match('/^P(?=\d|T\d)/i', (string)$value) === 1) {
                $interval = new \DateInterval(strtoupper((string)$value));
            } else {
                $interval = @\DateInterval::createFromDateString((string)$value);
            }
        } catch (\Throwable) {
            return null;
        }

        if (!$interval instanceof \DateInterval) {
            return null;
        }

        // "foo" makes an empty interval and "-1 hour" one that goes back -
        // neither would ever hold anything back
        $start = new \DateTimeImmutable('2000-01-01 00:00:00');

        return $start->add($interval) > $start ? $interval : null;
    }

    /** @return array{ran: bool, lastRun: ?string, nextRun: ?string} */
    private static function status(bool $ran, ?\DateTimeImmutable $lastRun, ?\DateTimeImmutable $nextRun): array
    {
        return [
            'ran' => $ran,
            'lastRun' => $lastRun?->format(\DateTimeInterface::ATOM),
            'nextRun' => $nextRun?->format(\DateTimeInterface::ATOM),
        ];
    }

    private function resolve(mixed $value): mixed
    {
        return ($value instanceof CommandDTO || $value instanceof CommandGroupDTO)
            ? $this->_runCommandDefinition($value)
            : $value;
    }

    private function runCommands(mixed $commands): mixed
    {
        if ($commands === null || $commands === [] || $commands === '') {
            return null;
        }

        return $this->_runCommandDefinition($commands);
    }
}
