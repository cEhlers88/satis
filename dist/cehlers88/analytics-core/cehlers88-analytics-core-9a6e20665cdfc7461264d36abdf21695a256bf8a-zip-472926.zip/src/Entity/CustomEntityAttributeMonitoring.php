<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\CustomEntityAttributeMonitoringRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CustomEntityAttributeMonitoringRepository::class)]
class CustomEntityAttributeMonitoring implements EntityInterface
{
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    protected ?\DateTimeInterface $lastRun = null;
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;
    #[ORM\ManyToOne(inversedBy: 'monitorings')]
    #[ORM\JoinColumn(nullable: false)]
    private ?CustomEntityAttribute $attribute = null;
    #[ORM\Column(length: 255)]
    private ?string $runInterval = null;
    #[ORM\OneToOne(cascade: ['persist', 'remove'])]
    private ?Statistics $statistic = null;

    #[ORM\Column]
    private ?int $maxLength = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $ruleHandler = null;

    #[ORM\Column(nullable: true)]
    private ?array $ruleArguments = null;

    /**
     * When set, the run interval is the sampling interval and the statistic
     * holds one average per aggregation interval instead of every measurement
     * (see Support\MonitoringAverage). An ISO 8601 duration such as "PT1H".
     */
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $aggregationInterval = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getAttribute(): ?CustomEntityAttribute
    {
        return $this->attribute;
    }

    public function setAttribute(?CustomEntityAttribute $attribute): static
    {
        $this->attribute = $attribute;

        return $this;
    }

    public function getRunInterval(): ?string
    {
        return $this->runInterval;
    }

    public function setRunInterval(string $runInterval): static
    {
        $this->runInterval = $runInterval;

        return $this;
    }

    public function getLastRun(): ?\DateTime
    {
        return $this->lastRun;
    }

    public function setLastRun(\DateTime $lastRun): static
    {
        $this->lastRun = $lastRun;

        return $this;
    }

    public function getStatistic(): ?Statistics
    {
        return $this->statistic;
    }

    public function setStatistic(?Statistics $statistic): static
    {
        $this->statistic = $statistic;

        return $this;
    }

    public function getMaxLength(): ?int
    {
        return $this->maxLength;
    }

    public function setMaxLength(int $maxLength): static
    {
        $this->maxLength = $maxLength;

        return $this;
    }

    public function getRuleHandler(): ?string
    {
        return $this->ruleHandler;
    }

    public function setRuleHandler(?string $ruleHandler): static
    {
        $this->ruleHandler = $ruleHandler;

        return $this;
    }

    public function getRuleArguments(): ?array
    {
        return $this->ruleArguments;
    }

    public function setRuleArguments(?array $ruleArguments): static
    {
        $this->ruleArguments = $ruleArguments;

        return $this;
    }

    public function getAggregationInterval(): ?string
    {
        return $this->aggregationInterval;
    }

    public function setAggregationInterval(?string $aggregationInterval): static
    {
        $aggregationInterval = trim((string)$aggregationInterval);
        $this->aggregationInterval = $aggregationInterval === '' ? null : $aggregationInterval;

        return $this;
    }
}
