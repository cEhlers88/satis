<?php

namespace Cehlers88\AnalyticsCore\Tests\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\CustomObject\AttributeMappingDTO;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectInterface;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\ENUM\eAttributeMappingType;
use Cehlers88\AnalyticsCore\Repository\CustomEntityRepository;
use PHPUnit\Framework\TestCase;

class ClientTestObject extends AbstractCustomObject
{
}

class LanServiceTestObject extends AbstractCustomObject
{
    public function getAttributeMappings(): array
    {
        return [
            'client_id' => AttributeMappingDTO::customObject(ClientTestObject::class),
            'state' => AttributeMappingDTO::select(['on' => 'An', 'off' => 'Aus']),
        ];
    }
}

class AttributeMappingTest extends TestCase
{
    public function testCustomObjectFactoryCreatesCustomObjectMapping(): void
    {
        $mapping = AttributeMappingDTO::customObject(ClientTestObject::class);

        $this->assertSame(eAttributeMappingType::CUSTOM_OBJECT, $mapping->type);
        $this->assertSame(ClientTestObject::class, $mapping->targetClassName);
        $this->assertSame([], $mapping->options);
    }

    public function testSelectFactoryCreatesSelectMapping(): void
    {
        $mapping = AttributeMappingDTO::select(['a' => 'Label A']);

        $this->assertSame(eAttributeMappingType::SELECT, $mapping->type);
        $this->assertNull($mapping->targetClassName);
        $this->assertSame(['a' => 'Label A'], $mapping->options);
    }

    public function testAbstractCustomObjectHasNoMappingsByDefault(): void
    {
        $object = new ClientTestObject();

        $this->assertSame([], $object->getAttributeMappings());
        $this->assertNull($object->getAttributeMapping('client_id'));
    }

    public function testGetAttributeMappingReturnsDeclaredMapping(): void
    {
        $object = new LanServiceTestObject();

        $mapping = $object->getAttributeMapping('client_id');
        $this->assertInstanceOf(AttributeMappingDTO::class, $mapping);
        $this->assertSame(ClientTestObject::class, $mapping->targetClassName);
        $this->assertNull($object->getAttributeMapping('unmapped'));
    }

    public function testGetAttributeMappingsByClassName(): void
    {
        $provider = $this->createProvider();

        $mappings = $provider->getAttributeMappingsByClassName(LanServiceTestObject::class);
        $this->assertArrayHasKey('client_id', $mappings);
        $this->assertArrayHasKey('state', $mappings);

        $this->assertSame([], $provider->getAttributeMappingsByClassName(\stdClass::class));
        $this->assertSame([], $provider->getAttributeMappingsByClassName('Not\\Existing\\ClassName'));
    }

    public function testResolveAttributeValueReturnsRawValueForUnmappedAttribute(): void
    {
        $provider = $this->createProvider();
        $object = (new LanServiceTestObject())->setAttribute('port', '8080');

        $this->assertSame('8080', $provider->resolveAttributeValue($object, 'port'));
        $this->assertSame('fallback', $provider->resolveAttributeValue($object, 'missing', 'fallback'));
    }

    public function testResolveAttributeValueResolvesSelectLabel(): void
    {
        $provider = $this->createProvider();
        $object = (new LanServiceTestObject())->setAttribute('state', 'on');

        $this->assertSame('An', $provider->resolveAttributeValue($object, 'state'));
    }

    public function testResolveAttributeValueResolvesCustomObjectReference(): void
    {
        $clientEntity = $this->createCustomEntity(5, ClientTestObject::class, 'Client A');

        $repository = $this->createMock(CustomEntityRepository::class);
        $repository->expects($this->once())
            ->method('findOneBy')
            ->with(['id' => 5, 'className' => ClientTestObject::class])
            ->willReturn($clientEntity);

        $provider = $this->createProvider($repository);
        $object = (new LanServiceTestObject())->setAttribute('client_id', '5');

        $resolved = $provider->resolveAttributeValue($object, 'client_id');
        $this->assertInstanceOf(ClientTestObject::class, $resolved);
        $this->assertSame(5, $resolved->getId());
        $this->assertSame('Client A', $resolved->getName());
    }

    public function testResolveAttributeValueReturnsRawValueWhenReferenceIsMissing(): void
    {
        $repository = $this->createStub(CustomEntityRepository::class);
        $repository->method('findOneBy')->willReturn(null);

        $provider = $this->createProvider($repository);
        $object = (new LanServiceTestObject())->setAttribute('client_id', '99');

        $this->assertSame('99', $provider->resolveAttributeValue($object, 'client_id'));
    }

    public function testGetAttributeOptionsForSelectMapping(): void
    {
        $provider = $this->createProvider();
        $object = new LanServiceTestObject();

        $this->assertSame(['on' => 'An', 'off' => 'Aus'], $provider->getAttributeOptions($object, 'state'));
        $this->assertSame([], $provider->getAttributeOptions($object, 'unmapped'));
    }

    public function testGetAttributeOptionsForCustomObjectMapping(): void
    {
        $repository = $this->createMock(CustomEntityRepository::class);
        $repository->expects($this->once())
            ->method('findBy')
            ->with(['className' => ClientTestObject::class])
            ->willReturn([
                $this->createCustomEntity(1, ClientTestObject::class, 'Client A'),
                $this->createCustomEntity(2, ClientTestObject::class, 'Client B'),
            ]);

        $provider = $this->createProvider($repository);
        $object = new LanServiceTestObject();

        $this->assertSame([1 => 'Client A', 2 => 'Client B'], $provider->getAttributeOptions($object, 'client_id'));
    }

    private function createProvider(?CustomEntityRepository $repository = null): CustomObjectProvider
    {
        return new CustomObjectProvider([], $repository ?? $this->createStub(CustomEntityRepository::class));
    }

    private function createCustomEntity(int $id, string $className, string $name): CustomEntity
    {
        $entity = new CustomEntity();
        $entity->setClassName($className);
        $entity->setName($name);
        $this->setEntityId($entity, $id);

        return $entity;
    }

    private function setEntityId(CustomEntity $entity, int $id): void
    {
        $reflection = new \ReflectionClass($entity);
        while ($reflection !== false && !$reflection->hasProperty('id')) {
            $reflection = $reflection->getParentClass();
        }

        $property = $reflection->getProperty('id');
        $property->setValue($entity, $id);
    }
}
