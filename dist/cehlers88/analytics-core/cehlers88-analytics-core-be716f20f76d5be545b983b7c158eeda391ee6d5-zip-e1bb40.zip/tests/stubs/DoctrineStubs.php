<?php
/**
 * Minimal Doctrine stubs for unit tests.
 *
 * The library itself ships without Doctrine dependencies (they are provided
 * by the consuming application), so tests touching entities or repositories
 * need these lightweight replacements. Every definition is guarded so real
 * Doctrine classes take precedence when they are installed.
 */

namespace Doctrine\Common\Collections {

    if (!interface_exists(Collection::class, false)) {
        interface Collection extends \Countable, \IteratorAggregate, \ArrayAccess
        {
        }
    }

    if (!class_exists(ArrayCollection::class, false)) {
        class ArrayCollection implements Collection
        {
            public function __construct(private array $elements = [])
            {
            }

            public function add(mixed $element): void
            {
                $this->elements[] = $element;
            }

            public function contains(mixed $element): bool
            {
                return in_array($element, $this->elements, true);
            }

            public function removeElement(mixed $element): bool
            {
                $key = array_search($element, $this->elements, true);
                if ($key === false) {
                    return false;
                }
                unset($this->elements[$key]);
                return true;
            }

            public function filter(\Closure $predicate): static
            {
                return new static(array_filter($this->elements, $predicate, ARRAY_FILTER_USE_BOTH));
            }

            public function first(): mixed
            {
                return reset($this->elements);
            }

            public function toArray(): array
            {
                return $this->elements;
            }

            public function count(): int
            {
                return count($this->elements);
            }

            public function getIterator(): \Traversable
            {
                return new \ArrayIterator($this->elements);
            }

            public function offsetExists(mixed $offset): bool
            {
                return isset($this->elements[$offset]);
            }

            public function offsetGet(mixed $offset): mixed
            {
                return $this->elements[$offset] ?? null;
            }

            public function offsetSet(mixed $offset, mixed $value): void
            {
                if ($offset === null) {
                    $this->elements[] = $value;
                    return;
                }
                $this->elements[$offset] = $value;
            }

            public function offsetUnset(mixed $offset): void
            {
                unset($this->elements[$offset]);
            }
        }
    }
}

namespace Doctrine\Bundle\DoctrineBundle\Repository {

    if (!class_exists(ServiceEntityRepository::class, false)) {
        class ServiceEntityRepository
        {
            public function __construct(mixed ...$args)
            {
            }

            public function find(mixed $id, mixed $lockMode = null, mixed $lockVersion = null): ?object
            {
                return null;
            }

            /**
             * @return array<int, object>
             */
            public function findBy(array $criteria, ?array $orderBy = null, ?int $limit = null, ?int $offset = null): array
            {
                return [];
            }

            public function findOneBy(array $criteria, ?array $orderBy = null): ?object
            {
                return null;
            }
        }
    }
}
