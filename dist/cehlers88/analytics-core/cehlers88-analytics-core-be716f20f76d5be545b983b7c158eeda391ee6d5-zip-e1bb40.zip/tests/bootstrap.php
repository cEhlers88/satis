<?php

require dirname(__DIR__) . '/vendor/autoload.php';
require __DIR__ . '/stubs/DoctrineStubs.php';
