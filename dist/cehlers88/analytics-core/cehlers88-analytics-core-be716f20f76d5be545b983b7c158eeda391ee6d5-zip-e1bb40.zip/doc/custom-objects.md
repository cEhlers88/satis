# Custom Objects

The custom object system allows you to define dynamic entity classes that are persisted in the database and resolved at runtime. It lives in the `Cehlers88\AnalyticsCore\CustomObject` namespace.

## Overview

```
AbstractCustomObject      — base class for domain-specific dynamic entities
CustomObjectInterface     — contract for all custom object classes
CustomObjectProvider      — loads and resolves custom objects from the database
AttributeMappingDTO       — declares how a single attribute is mapped (relation / select)
```

## Implementing a Custom Object

Extend `AbstractCustomObject` for each type of dynamic entity:

```php
use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

class ProductObject extends AbstractCustomObject
{
    public function getPrice(): float
    {
        return (float) $this->getAttribute('price', 0.0);
    }

    public function getSku(): string
    {
        return (string) $this->getAttribute('sku', '');
    }
}
```

Register it as a Symfony service:

```yaml
# services.yaml
ProductObject:
    tags:
        - { name: analytics.custom_object }
```

## Persisting a Custom Object

Use the `CustomEntity` and `CustomEntityAttribute` entities directly via their repositories:

```php
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;

$entity = new CustomEntity();
$entity->setClassName(ProductObject::class);
$entity->setName('Widget Pro');

$attribute = new CustomEntityAttribute();
$attribute->setName('price');
$attribute->setValue('49.99');
$entity->addAttribute($attribute);

$customEntityRepository->save($entity, flush: true);
```

## Loading Custom Objects

```php
// Load all persisted instances of a class
$products = $customObjectProvider->getCustomEntitiesByClassName(ProductObject::class);

foreach ($products as $product) {
    echo $product->getName();       // "Widget Pro"
    echo $product->getPrice();      // 49.99
    echo $product->getAttribute('sku', 'N/A');
}

// Load by providing an instance (uses the class name automatically)
$products = $customObjectProvider->getCustomEntitiesByClass(new ProductObject());

// Resolve a single CustomEntity database record to its PHP object
$productObject = $customObjectProvider->resolveCustomEntity($customEntityRecord);
```

## Attribute Mappings

Attributes of a custom object are stored as plain values. A mapping declares
how such a value should be interpreted — e.g. that `client_id` references a
`Client` custom object. Mappings drive two use cases:

- **View**: the raw value is resolved (an id becomes the referenced object, a
  select value becomes its label).
- **Edit**: the mapping provides the options for a select box.

Declare mappings by overriding `getAttributeMappings()`:

```php
use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\CustomObject\AttributeMappingDTO;

class LanService extends AbstractCustomObject
{
    public function getAttributeMappings(): array
    {
        return [
            // client_id stores the id of a persisted Client custom object
            'client_id' => AttributeMappingDTO::customObject(Client::class),
            // state stores one of a static set of values
            'state' => AttributeMappingDTO::select(['on' => 'An', 'off' => 'Aus']),
        ];
    }
}
```

Resolve mapped values through the `CustomObjectProvider`:

```php
$lanService = $customObjectProvider->getCustomObjectById(42);

// View: returns the referenced Client object (or the raw value when unresolvable)
$client = $customObjectProvider->resolveAttributeValue($lanService, 'client_id');

// Edit: options for a select box, as value => label pairs
// CUSTOM_OBJECT mappings list all persisted instances of the target class (id => name)
$options = $customObjectProvider->getAttributeOptions($lanService, 'client_id');

// Mappings of a class without an instance at hand
$mappings = $customObjectProvider->getAttributeMappingsByClassName(LanService::class);
$options = $customObjectProvider->getOptionsForMapping($mappings['client_id']);
```

Unmapped attributes are returned unchanged by `resolveAttributeValue()` and
yield an empty options array.

## `AbstractCustomObject` API

| Method | Description |
|--------|-------------|
| `getName(): string` | The human-readable name of the instance |
| `setName(string): self` | Set the name |
| `getId(): int` | The database ID (`-1` if not persisted) |
| `setId(int): self` | Set the database ID |
| `getAttribute(string, mixed): mixed` | Get an attribute value with optional default |
| `getAttributes(): array` | Get all attributes as an associative array |
| `setAttribute(string, mixed): self` | Set an attribute value |
| `getAttributeMappings(): array` | Attribute mappings keyed by attribute name (default: `[]`) |
| `getAttributeMapping(string): ?AttributeMappingDTO` | Mapping of a single attribute or `null` |
| `getClassName(): string` | Returns `get_class($this)` |
