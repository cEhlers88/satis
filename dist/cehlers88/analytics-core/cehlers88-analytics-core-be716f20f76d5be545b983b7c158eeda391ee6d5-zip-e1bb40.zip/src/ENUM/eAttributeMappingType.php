<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 10.07.2026
 * Time: 09:00
 */

namespace Cehlers88\AnalyticsCore\ENUM;

/**
 * Represents the possible attribute mapping types for custom objects.
 */
enum eAttributeMappingType: string
{
    case CUSTOM_OBJECT = 'CUSTOM_OBJECT';
    case SELECT = 'SELECT';

    /**
     * Creates an eAttributeMappingType instance from a string value.
     *
     * @param string $value The string representation of the mapping type.
     * @return eAttributeMappingType
     */
    public static function fromString(string $value): eAttributeMappingType
    {
        return match ($value) {
            'CUSTOM_OBJECT' => self::CUSTOM_OBJECT,
            'SELECT' => self::SELECT,
        };
    }
}
