<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:40
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\ENUM\eAttributeMappingType;
use Cehlers88\AnalyticsCore\Repository\CustomEntityRepository;

/** Provider for managing custom object instances. */
class CustomObjectProvider
{
    public function __construct(
        private iterable               $customEntityClasses,
        private CustomEntityRepository $customEntityRepository
    )
    {
    }

    /**
     * @param CustomObjectInterface $customEntity
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClass(CustomObjectInterface $customEntity): array
    {
        return $this->getCustomEntitiesByClassName($customEntity->getClassName());
    }

    /**
     * @param string $className
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClassName(string $className): array
    {
        return $this->getCustomEntitiesBy(['className' => $className]);
    }

    /**
     * @param array<string, mixed> $filters
     * @return CustomEntity[]
     */
    public function getCustomEntitiesBy(array $filters): array
    {
        $result = [];

        foreach ($this->customEntityRepository->findBy($filters) as $entry) {
            $result[] = $this->resolveCustomEntity($entry);
        }

        return $result;
    }

    /**
     * Resolve a CustomEntity into a CustomObjectInterface instance.
     *
     * @param CustomEntity $customEntity The entity to resolve.
     * @return CustomObjectInterface
     */
    public function resolveCustomEntity(CustomEntity $customEntity): CustomObjectInterface
    {
        $className = $customEntity->getClassName();

        /** @var CustomObjectInterface $instance */
        $instance = new $className();
        $instance->load($customEntity);

        return $instance;
    }

    public function getCustomEntityByClassNameAndName(string $className, string $name): ?CustomObjectInterface
    {
        $entity = $this->customEntityRepository->findOneBy(['className' => $className, 'name' => $name]);
        if ($entity === null) {
            return null;
        }
        return $this->resolveCustomEntity($entity);
    }

    public function getAttributesOfCustomEntityClass(string $className): array
    {
        return $this->customEntityRepository->findAttributeNamesByClass($className);
    }

    public function getCustomObjectById(int $id): ?CustomObjectInterface
    {
        return $this->getCustomEntitiesBy(['id' => $id])[0] ?? null;
    }

    /**
     * Get the attribute mappings declared by a custom object class.
     *
     * @param string $className Fully qualified custom object class name.
     * @return array<string, AttributeMappingDTO>
     */
    public function getAttributeMappingsByClassName(string $className): array
    {
        if (!class_exists($className) || !is_subclass_of($className, CustomObjectInterface::class)) {
            return [];
        }

        /** @var CustomObjectInterface $instance */
        $instance = new $className();

        return $instance->getAttributeMappings();
    }

    /**
     * Resolve an attribute value according to its mapping.
     *
     * For CUSTOM_OBJECT mappings the stored id is resolved to the referenced
     * custom object instance. For SELECT mappings the stored value is resolved
     * to its option label. Unmapped or unresolvable attributes return the raw
     * value (or the default value when the attribute is not set).
     *
     * @param CustomObjectInterface $customObject The object holding the attribute.
     * @param string $attributeName Attribute name.
     * @param mixed $defaultValue Value returned when the attribute is not set.
     * @return mixed
     */
    public function resolveAttributeValue(CustomObjectInterface $customObject, string $attributeName, mixed $defaultValue = null): mixed
    {
        $value = $customObject->getAttribute($attributeName, $defaultValue);
        $mapping = $customObject->getAttributeMapping($attributeName);

        if ($mapping === null || $value === null || $value === '') {
            return $value;
        }

        return match ($mapping->type) {
            eAttributeMappingType::CUSTOM_OBJECT => $this->resolveCustomObjectReference($mapping->targetClassName, $value) ?? $value,
            eAttributeMappingType::SELECT => $mapping->options[$value] ?? $value,
        };
    }

    /**
     * Get the select options of a mapped attribute for edit views.
     *
     * @param CustomObjectInterface $customObject The object holding the attribute.
     * @param string $attributeName Attribute name.
     * @return array<int|string, string> Options as value => label pairs, empty when the attribute is not mapped.
     */
    public function getAttributeOptions(CustomObjectInterface $customObject, string $attributeName): array
    {
        $mapping = $customObject->getAttributeMapping($attributeName);

        return $mapping === null ? [] : $this->getOptionsForMapping($mapping);
    }

    /**
     * Get the select options of an attribute mapping for edit views.
     *
     * For CUSTOM_OBJECT mappings the options are built from all persisted
     * instances of the target class (id => name).
     *
     * @return array<int|string, string> Options as value => label pairs.
     */
    public function getOptionsForMapping(AttributeMappingDTO $mapping): array
    {
        return match ($mapping->type) {
            eAttributeMappingType::SELECT => $mapping->options,
            eAttributeMappingType::CUSTOM_OBJECT => $this->buildCustomObjectOptions($mapping->targetClassName),
        };
    }

    /**
     * @return array<int, string> Options as id => name pairs.
     */
    private function buildCustomObjectOptions(?string $targetClassName): array
    {
        if ($targetClassName === null) {
            return [];
        }

        $options = [];
        foreach ($this->getCustomEntitiesByClassName($targetClassName) as $customObject) {
            $options[$customObject->getId()] = $customObject->getName();
        }

        return $options;
    }

    private function resolveCustomObjectReference(?string $targetClassName, mixed $value): ?CustomObjectInterface
    {
        if ($targetClassName === null || !is_numeric($value)) {
            return null;
        }

        $entity = $this->customEntityRepository->findOneBy([
            'id' => (int)$value,
            'className' => $targetClassName,
        ]);

        return $entity === null ? null : $this->resolveCustomEntity($entity);
    }

    /**
     * Get all registered custom entity classes.
     *
     * @return CustomObjectInterface[]
     */
    public function getCustomClasses(): iterable
    {
        return $this->customEntityClasses;
    }

    public function createNewCustomEntity(string $className): CustomObjectInterface
    {
        /** @var CustomObjectInterface $buffer */
        $buffer = new $className();

        $buffer
            ->setCreatedAt(new \DateTimeImmutable())
            ->setModifiedAt(new \DateTimeImmutable());

        return $buffer;
    }

    public function save(CustomObjectInterface $customEntityToSave): void
    {
        $isNew = $customEntityToSave->getId() === null || $customEntityToSave->getId() <= 0;
        $attrs = [];
        $entity = null;

        if (!$isNew) {
            $entity = $this->customEntityRepository->find($customEntityToSave->getId());
            foreach ($entity->getAttributes() as $attribute) {
                $attrs[$attribute->getName()] = [
                    'obj' => $attribute,
                    'stillExist' => false,
                    'isNew' => false
                ];
            }
        } else {
            $entity = new CustomEntity();
            $entity
                ->setClassName($customEntityToSave->getClassName())
                ->setCreatedAt(new \DateTime());
        }

        foreach ($customEntityToSave->getAttributes() as $attributeName => $attributeValue) {
            $attrs[$attributeName]['stillExist'] = true;
            $entity->setAttributeValue($attributeName, $attributeValue);
        }

        $entity->setName($customEntityToSave->getName());
        $entity->setParentId($customEntityToSave->getParentId());
        $entity->setModifiedAt(new \DateTime());

        foreach ($attrs as $attributeName => $attribute) {
            if (!$attribute['stillExist']) {
                $entity->removeAttribute($attribute['obj']);
            }
        }

        $this->customEntityRepository->save($entity);
    }
}