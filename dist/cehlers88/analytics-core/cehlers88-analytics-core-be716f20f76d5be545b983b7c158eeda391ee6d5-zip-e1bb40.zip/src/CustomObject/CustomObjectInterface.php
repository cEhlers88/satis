<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.01.2026
 * Time: 12:19
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

use Cehlers88\AnalyticsCore\Entity\CustomEntity;

/** Interface for custom objects. */
interface CustomObjectInterface
{
    /** Get the fully qualified class name. */
    public function getClassName(): string;

    /** Get the object name. */
    public function getName(): string;

    public function setName(string $name): static;

    public function getParentId(): ?int;

    public function setParentId(?int $parentId): static;

    public function getCreatedAt(): ?\DateTimeInterface;

    public function setCreatedAt(?\DateTimeInterface $createdAt): static;

    public function getModifiedAt(): ?\DateTimeInterface;

    public function setModifiedAt(?\DateTimeInterface $modifiedAt): static;

    public function getUpdatedAt(): ?\DateTimeInterface;

    public function setUpdatedAt(?\DateTimeInterface $updatedAt): static;

    /**
     * @param string $name Attribute name.
     * @param mixed $defaultValue Value returned when attribute is not set.
     * @return mixed
     */
    public function getAttribute(string $name, mixed $defaultValue = null): mixed;

    /** Get all attributes. */
    public function getAttributes(): array;

    /**
     * Get the attribute mappings of this custom object class, keyed by attribute name.
     *
     * @return array<string, AttributeMappingDTO>
     */
    public function getAttributeMappings(): array;

    /**
     * Get the mapping of a single attribute, or null when the attribute is not mapped.
     *
     * @param string $name Attribute name.
     */
    public function getAttributeMapping(string $name): ?AttributeMappingDTO;

    public function removeAttribute(string $name): static;

    /** Get the object ID. */
    public function getId(): int;

    /**
     * @param string $name Attribute name.
     * @param mixed $value Attribute value.
     */
    public function setAttribute(string $name, mixed $value): static;

    public function setAttributes(array $attributes): static;

    public function load(CustomEntity $customEntity): static;
}