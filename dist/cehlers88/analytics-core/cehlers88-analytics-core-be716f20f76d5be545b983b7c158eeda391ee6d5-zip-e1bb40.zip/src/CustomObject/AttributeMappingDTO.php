<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 10.07.2026
 * Time: 09:00
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

use Cehlers88\AnalyticsCore\ENUM\eAttributeMappingType;

/**
 * Describes how a single custom object attribute is mapped.
 *
 * A mapping controls how an attribute value is presented: in a read view the
 * raw value can be resolved (e.g. a stored id becomes the referenced custom
 * object), while in an edit view the mapping provides the options for a
 * select box.
 */
class AttributeMappingDTO
{
    /**
     * @param eAttributeMappingType $type The mapping type.
     * @param string|null $targetClassName Target custom object class for CUSTOM_OBJECT mappings.
     * @param array<int|string, string> $options Static options (value => label) for SELECT mappings.
     */
    private function __construct(
        public readonly eAttributeMappingType $type,
        public readonly ?string               $targetClassName = null,
        public readonly array                 $options = []
    )
    {
    }

    /**
     * Map an attribute to another custom object class.
     *
     * The attribute value is treated as the id of a persisted instance of the
     * target class. Resolving returns the referenced object, the edit options
     * are built from all persisted instances of the target class.
     *
     * @param string $targetClassName Fully qualified class name of the referenced custom object.
     */
    public static function customObject(string $targetClassName): self
    {
        return new self(eAttributeMappingType::CUSTOM_OBJECT, $targetClassName);
    }

    /**
     * Map an attribute to a static list of options.
     *
     * @param array<int|string, string> $options Options as value => label pairs.
     */
    public static function select(array $options): self
    {
        return new self(eAttributeMappingType::SELECT, null, $options);
    }
}
