<?php

namespace Cehlers88\AnalyticsCore\Support;

use Analytics\Utils\UnitUtils;
use RuntimeException;

class Profiler
{
    private ?\DateTime $startedAt = null;

    private ?float $startTimestamp = null;
    private ?float $endTimestamp = null;

    private ?int $startMemoryBytes = null;
    private ?int $endMemoryBytes = null;

    public static function run(callable $callable): array
    {
        $exception = null;
        $result = null;

        $profiler = new self();
        $profiler->start();

        try {
            $result = $callable();
        } catch (\Throwable $e) {
            $exception = $e;
        }

        $profiler->stop();

        return [
            'result' => $result,
            'exception' => $exception,
            'hasError' => $exception !== null,
            'profiler' => $profiler,
        ];
    }

    public function start(): void
    {
        $this->startedAt = new \DateTime();
        $this->startTimestamp = microtime(true);
        $this->startMemoryBytes = memory_get_usage(true);

        $this->endTimestamp = null;
        $this->endMemoryBytes = null;
    }

    public function stop(): void
    {
        $this->endTimestamp = microtime(true);
        $this->endMemoryBytes = memory_get_usage(true);
    }

    public function getStartedAt(): \DateTime
    {
        return $this->startedAt;
    }

    public function getReadableDuration(): string
    {
        return UnitUtils::formatDuration($this->getDurationMilliseconds());
    }

    public function getDurationMilliseconds(): float
    {
        return $this->getDurationSeconds() * 1000;
    }

    public function getDurationSeconds(): float
    {
        $this->ensureStopped();
        return $this->endTimestamp - $this->startTimestamp;
    }

    private function ensureStopped(): void
    {
        if ($this->startTimestamp === null) {
            throw new RuntimeException('Profiler not started.');
        }

        if ($this->endTimestamp === null || $this->endMemoryBytes === null) {
            $this->stop();
        }
    }

    public function getUsedMemoryBytes(): int
    {
        $this->ensureStopped();
        return $this->endMemoryBytes - $this->startMemoryBytes;
    }

    public function getStartMemoryBytes(): int
    {
        return $this->startMemoryBytes ?? 0;
    }

    public function getEndMemoryBytes(): int
    {
        $this->ensureStopped();
        return $this->endMemoryBytes;
    }

    public function getPeakMemoryBytes(bool $realUsage = true): int
    {
        return memory_get_peak_usage($realUsage);
    }
}
