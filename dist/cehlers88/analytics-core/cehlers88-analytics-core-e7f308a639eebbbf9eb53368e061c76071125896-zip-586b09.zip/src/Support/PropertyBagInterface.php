<?php

namespace Cehlers88\AnalyticsCore\Support;

use Analytics\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Support\Error\ErrorBagInterface;

interface PropertyBagInterface extends ErrorBagInterface
{
    /**
     * @return PropertyDTO[]
     */
    public function getProperties(): array;

    /**
     * @return array<string, mixed>
     */
    public function getPropertiesAsKeyValueArray(): array;

    public function getProperty(string $name): ?PropertyDTO;

    /**
     * Retrieves the value of a property by its name.
     * If the property does not exist, the provided default value is returned.
     *
     * @param string $name The name of the property to retrieve.
     * @param mixed $defaultValue The default value to return if the property does not exist.
     * @return mixed The value of the property or the default value.
     */
    public function getPropertyValue(string $name, mixed $defaultValue = null): mixed;

    public function isValid(): bool;

    /**
     * Loads the property values into the current instance.
     *
     * @param array $properties An array of property values.
     * @param bool $createIfNotExist Determines whether to create properties if they do not exist. Defaults to false.
     * @return static Returns the current instance for method chaining.
     */
    public function loadPropertyValues(array $properties, bool $createIfNotExist = false): static;

    public function validate(): bool;
}