<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Service;

use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Presentation\QuickStatusInfoDTO;

class QuickStatusInfoProvider
{
    public function generate(object $sourceObject): QuickStatusInfoDTO
    {
        if ($sourceObject instanceof Process) {
            return $this->generateByProcess($sourceObject);
        }

        return new QuickStatusInfoDTO();
    }

    public function generateByProcess(Process $process): QuickStatusInfoDTO
    {
        $result = new QuickStatusInfoDTO();
        $result->message = 'Process neu!';

        if ($process->hasState(eRunningState::BufferComplete)) {
            if ($process->hasState(eRunningState::WillStart)) {
                $result->percentage = 40;
            } else {
                $result->percentage = 30;
            }
        } else if ($process->hasState(eRunningState::Running)) {
            $result->percentage = 45;
        } else if ($process->hasState(eRunningState::WillStart)) {
            $result->percentage = 10;
        } else if ($process->hasState(eRunningState::Finished)) {
            $result->percentage = 100;
        } else if ($process->hasState(eRunningState::Finishing)) {
            $result->percentage = 80;
        } else if ($process->hasState(eRunningState::Buffering)) {
            $result->percentage = 20;
        }

        return $result;
    }
}