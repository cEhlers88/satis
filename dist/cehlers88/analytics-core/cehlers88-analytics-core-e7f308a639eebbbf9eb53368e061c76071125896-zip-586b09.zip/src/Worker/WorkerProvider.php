<?php

namespace Cehlers88\AnalyticsCore\Worker;

use Analytics\ApplicationContext;
use Analytics\ENUM\eWorkerCounterKey;
use Analytics\Executor\WorkerExecutor;
use Analytics\Logger\SimpleConsoleLogger;
use Analytics\MacroEnvironment;
use Analytics\Message\StartHandleWorkerErrorMessage;
use Analytics\Provider\WorkerJobProvider;
use Analytics\Utils\UnitUtils;
use Cehlers88\AnalyticsCore\Entity\RunChain;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Executor\ExecutorProvider;
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\Repository\WorkerJournalRepository;
use Cehlers88\AnalyticsCore\Repository\WorkerRepository;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Cehlers88\AnalyticsCore\Worker\Observer\Message\WorkerErrorObserverMessage;
use Cehlers88\AnalyticsCore\Worker\Observer\Message\WorkerFinishedObserverMessage;
use Cehlers88\AnalyticsCore\Worker\Observer\Message\WorkerStartedObserverMessage;
use Symfony\Component\DependencyInjection\Attribute\AutowireIterator;
use Symfony\Component\Messenger\MessageBusInterface;

class WorkerProvider
{
    private bool $_debugMode = false;
    private LoggerInterface $_logger;
    private ?RunChain $runChain = null;

    /**
     * WorkerProvider constructor.
     * @param iterable<WorkerInterface> $workers
     * @param MacroEnvironment $macroEnvironment
     * @param WorkerRepository $workerRepository
     * @param WorkerJournalRepository $workerJournalRepository
     * @param MessageBusInterface $messageBus
     */
    public function __construct(
        #[AutowireIterator('analytics.worker')]
        private iterable                $workers,
        private ApplicationContext      $applicationContext,
        private MacroEnvironment        $macroEnvironment,
        private WorkerRepository        $workerRepository,
        private WorkerJobProvider       $workerJobProvider,
        private WorkerJournalRepository $workerJournalRepository,
        private MessageBusInterface     $messageBus,
        private ObserverProvider        $observerProvider,
        private ExecutorProvider        $executorProvider,
    )
    {
        $this->_logger = new SimpleConsoleLogger();
    }

    public function enableDebugMode(bool $enable = true): static
    {
        $this->_debugMode = $enable;
        return $this;
    }

    public function getUnrelatedWorkers(): array
    {
        $buffer = [];
        foreach ($this->getWorkers() as $worker) {
            $buffer[] = [
                'hasEntity' => true,
                'name_entity' => $worker->getName(),
                'has_worker' => false,
                'name_worker' => $worker->getWorkerClass()
            ];
        }

        foreach ($this->getWorkerClasses() as $worker) {
            $found = false;
            for ($i = 0; count($buffer) > $i; $i++) {
                if ($buffer[$i]['name_worker'] === get_class($worker)) {
                    $buffer[$i]['has_worker'] = true;
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $buffer[] = [
                    'hasEntity' => false,
                    'name_entity' => '',
                    'has_worker' => true,
                    'name_worker' => get_class($worker)
                ];
            }
        }
        $result = [];
        foreach ($buffer as $entry) {
            if (!$entry['hasEntity'] || !$entry['has_worker']) {
                $result[] = $entry;
            }
        }
        return $result;
    }

    /**
     * @param int[] $applicationIdFilters
     * @return Worker[]|AbstractWorker[]
     */
    public function getWorkers($applicationIdFilters = [], bool $returnInstance = false): array
    {
        return array_reduce(
            (count($applicationIdFilters) === 0 ? $this->workerRepository->findAll() : $this->workerRepository->findBy_applicationIds($applicationIdFilters)),
            function ($carry, $workerEntity) use ($applicationIdFilters, $returnInstance) {
                $carry[] = $returnInstance ? $this->getWorkerInstanceByEntityId($workerEntity->getId()) : $workerEntity;
                return $carry;
            },
            []
        );
    }

    public function getWorkerInstanceByEntityId(int $workerId): ?AbstractWorker
    {
        $workerEntity = $this->workerRepository->find($workerId);
        return $this->getWorkerInstanceByName($workerEntity->getWorkerClass());
    }

    public function getWorkerInstanceByName(string $workerName): ?AbstractWorker
    {
        foreach ($this->workers as $worker) {
            if ($worker->getName() === $workerName) {
                $worker->setMacroPlayer($this->macroEnvironment->getMacroPlayer());
                return $worker;
            }
        }
        return null;
    }

    public function getWorkerClasses(): iterable
    {
        return $this->workers;
    }

    public function getWorkerById(int $workerId): ?Worker
    {
        return $this->workerRepository->find($workerId);
    }

    public function executeWorker(int $workerId, ?LoggerInterface $logger = null, $doRunnableChecks = true): void
    {
        if (!is_null($logger)) {
            $this->_logger = $logger;
        }

        $workerEntity = $this->workerRepository->find($workerId);
        $this->_executeWorker($workerEntity, $doRunnableChecks);
    }

    private function _executeWorker(Worker $workerEntity, bool $doRunableChecks = true): bool
    {
        die('tue nichts mehr - nutze executor!');

        return true;
    }

    public function executeWorkersByPriorityLevel(int $priorityLevel, LoggerInterface $logger): void
    {
        $this->_logger = $logger;

        $workers = $this->workerRepository->findBy_priority($priorityLevel, $this->runChain);
        if (count($workers) === 0) {
            $logger->warning('No workers found for priority level ' . $priorityLevel);
            return;
        }

        $logger->info('Start worker execution (' . count($workers) . ' with priority = ' . $priorityLevel . ')');

        foreach ($workers as $workerEntity) {
            $this->_executeWorker($workerEntity);
        }
    }

    public function executeWaitingWorkers(): array
    {
        $totalExecutedWorkers = 0;
        $result = [];
        while (true) {
            $workers = $this->workerRepository->fetchWaitingWorkers($this->runChain, $result);

            if (count($workers) === 0) {
                if ($totalExecutedWorkers === 0) {
                    $this->_logInfo('No waiting workers found', true);
                } else {
                    $this->_logger->removeTabSpace(3);
                    $this->_logInfo(sprintf('</ExecutionCycle executed-workers=%d>', $totalExecutedWorkers));
                }
                return $result;
            }

            $executedAnyInThisRound = false;

            if ($totalExecutedWorkers === 0) {
                $this->_logInfo(sprintf('<ExecutionCycle execute-workers=%d>', count($workers)));
                $this->_logger->addTabSpace(3);
            }

            foreach ($workers as $workerEntity) {
                if ($totalExecutedWorkers === 0) {
                    $this->_logInfo(sprintf('<env %s/>', $this->applicationContext->getInfoString()));
                }

                $workerExecutionResult = false;
                try {
                    $workerExecutionResult = $this->_executeWorker($workerEntity);
                } catch (\Exception $e) {
                    $this->_setError('WorkerProvider', 'Error while execute worker', $e, $workerEntity);
                }

                if ($workerExecutionResult) {
                    $result[] = $workerEntity;
                    $totalExecutedWorkers++;
                    $executedAnyInThisRound = true;
                    break;
                }

                $this->_logger->info(sprintf('Worker %s skipped (currently not runnable).', $workerEntity->getName()));
                $this->_logger->removeTabSpace(3);
            }

            if (!$executedAnyInThisRound) {
                $this->_logger->info('No more runnable workers found in current waiting list.');
                break;
            }
        }
        return $result;
    }

    private function _logInfo(string $message, bool $requireDebugMode = false): void
    {
        if ($requireDebugMode === true && !$this->_debugMode) return;
        $this->_logger->info($message);
    }

    /**
     * @param Worker|null $workerEntity
     * @param int $code
     * @param array|\Exception $details
     * @param bool $isFatal
     */
    private function _setError(
        string     $source,
        string     $message,
        \Throwable $details,
        Worker     $workerEntity = null,
        int        $code = 0,
        bool       $isFatal = false,
    )
    {
        $extendedMessage = sprintf('%sError in %s: "%s"', ($isFatal ? 'Fatal-' : ''), $source, $message);
        $this->_logger->warning($extendedMessage);

        $errorDetails = [
            'exceptionTrace' => $details->getTraceAsString(),
        ];

        $this->observerProvider->dispatch(new WorkerErrorObserverMessage(
            $workerEntity,
            $errorDetails
        ));

        if ($isFatal) {
            $workerEntity
                ->setState(eRunningState::FatalError)
                ->incrementCounter(eWorkerCounterKey::FAILED);
        } else {
            if ($workerEntity->getRestRetries() === 0) {
                $this->_setError('WorkerProvider', 'Worker has no retries left', $details, $workerEntity, 0, true);
                return;
            }
            $workerEntity
                ->addState(eRunningState::Error)
                ->incrementCounter(eWorkerCounterKey::FAILED);
        }
        try {
            $this->workerRepository->save($workerEntity, true);
            $this->workerJournalRepository->addWorkerResult($workerEntity, WorkerResultDTO::createFromException($details));
        } catch (\Throwable $e) {
            $this->_logger->error('Error while save worker error: ' . $e->getMessage());
        }

        $this->messageBus->dispatch(new StartHandleWorkerErrorMessage(
            $details->getMessage(),
            $workerEntity->getId()
        ));
    }

    public function setLogger(LoggerInterface $logger): static
    {
        $this->_logger = $logger;
        return $this;
    }

    public function setActiveRunChain(RunChain $runChain): static
    {
        $this->runChain = $runChain;
        return $this;
    }

    public function setWorkerState(int $workerId, eRunningState $state): static
    {
        $workerEntity = $this->workerRepository->find($workerId);
        $workerEntity->setState($state);
        $workerEntity->setUpdatedAt(new \DateTime());
        $this->workerRepository->save($workerEntity, true);

        return $this;
    }

    public function resolveWorkerPropertyDefinition(Worker $worker): array
    {
        $instance = $this->getWorkerInstanceByName($worker->getWorkerClass());
        $result = [];
        foreach ($instance->getProperties() as $property) {
            $result[] = [$property->type, $property->name, $property->value];
        }
        return $result;
    }
}