<?php

namespace Cehlers88\AnalyticsCore\Executor;

use Cehlers88\AnalyticsCore\Support\AbstractPropertyBag;
use Cehlers88\AnalyticsCore\Support\Profiler;

abstract class AbstractExecutor extends AbstractPropertyBag implements ExecutorInterface
{
    public const int ERR_INVALID = 500001;
    public const int ERR_ON_START = 500101;
    public const int ERR_ON_END = 500102;
    public const int ERR_WHILE_EXECUTE = 500110;

    protected bool $_logHasOpenGroup = false;
    protected ?Profiler $_profiler = null;
    private ?ExecutorProvider $_executorProvider = null;

    final public function run(): void
    {
        $this->_profiler = new Profiler();
        $this->_profiler->start();

        if (!$this->isRunnable()) {
            $this->_closeLogGroup();
            return;
        }

        try {
            $this->onStart();
        } catch (\Throwable $e) {
            $this->setError($e->getMessage(), self::ERR_ON_START, [
                'trace' => $e->getTraceAsString(),
            ]);
        }
        if (!$this->hasError()) {
            if (!$this->isValid()) {
                $this->setError('Invalid', self::ERR_INVALID);
            }
        }

        if (!$this->hasError()) {
            try {
                $this->execute();
            } catch (\Throwable $e) {
                $this->setError($e->getMessage(), self::ERR_WHILE_EXECUTE, [
                    'trace' => $e->getTraceAsString(),
                ]);
            }
        }

        try {
            $this->onEnd();
        } catch (\Throwable $e) {
            $this->setError($e->getMessage(), self::ERR_ON_END, [
                'trace' => $e->getTraceAsString(),
            ]);
        }

        $this->_closeLogGroup();
    }

    public function isRunnable(): bool
    {
        return true;
    }

    private function _closeLogGroup(): void
    {
        if ($this->_logHasOpenGroup) {
            $this->getLogger()->removeTabSpace(3);
            parent::logInfo('</Executor>');
        }
        $this->_logHasOpenGroup = false;
    }

    public function logInfo(string $message, bool $onlyInDebugMode = false): static
    {
        if ($onlyInDebugMode && !$this->getDebugMode()) {
            return $this;
        }

        if (!$this->_logHasOpenGroup) {
            $this->openLogGroup();
        }

        parent::logInfo($message);

        return $this;
    }

    public function openLogGroup(): static
    {
        parent::logInfo(sprintf('<Executor name="%s" started-at="%s">',
            $this->getName(),
            $this->_profiler->getStartedAt()->format('Y-m-d H:i:s')
        ));
        $this->getLogger()->addTabSpace(3);
        $this->_logHasOpenGroup = true;
        return $this;
    }

    public function getName(): string
    {
        return static::class;
    }

    protected function onStart(): void
    {

    }

    abstract protected function execute(): void;

    protected function onEnd(): void
    {

    }

    public function getRestExecutionTimeMs(): ?float
    {
        if (is_null($this->_profiler)) {
            return null;
        }

        $allowedRuntime = $this->getPropertyValue('allowedRuntime'); // in s
        if (is_null($allowedRuntime)) {
            return null;
        }

        return $allowedRuntime - $this->_profiler->getRuntimeSeconds();
    }

    public function getExecutorProvider(): ExecutorProvider
    {
        return $this->_executorProvider;
    }

    public function setExecutorProvider(ExecutorProvider $executorProvider): static
    {
        $this->_executorProvider = $executorProvider;
        return $this;
    }
}