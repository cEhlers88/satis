<?php

namespace Cehlers88\AnalyticsCore\Executor;

class ExecutorProvider
{
    public function __construct(
        private iterable $executors
    )
    {
    }

    public function getExecutor(string $executorName): ?ExecutorInterface
    {
        foreach ($this->executors as $executor) {
            /** @var ExecutorInterface $executor */
            if ($executor->getName() === $executorName) {
                $executor->setExecutorProvider($this);
                return $executor;
            }
        }
        return null;
    }
}