<?php

namespace Cehlers88\AnalyticsCore\Executor;

use Cehlers88\AnalyticsCore\Support\PropertyBagInterface;

interface ExecutorInterface extends PropertyBagInterface
{
    public function run(): void;

    public function getRestExecutionTimeMs(): ?float;

    public function getName(): string;

    public function getExecutorProvider(): ExecutorProvider;

    public function setExecutorProvider(ExecutorProvider $executorProvider): static;
}