<?php

namespace Cehlers88\AnalyticsCore\Executor\Observer\Message;

use Cehlers88\AnalyticsCore\Executor\ExecutorInterface;
use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;

class ExecutorStartObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'executor.start';

    public function __construct(
        public ExecutorInterface $executor,
        public array             $additionalData = []
    )
    {

    }

    public function getKey(): string
    {
        return self::KEY;
    }
}