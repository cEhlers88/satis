<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 02.06.2024
 * Time: 15:33
 */

namespace Cehlers88\AnalyticsCore\Process;

use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\Process\Exception\RunnerNotFoundException;
use Cehlers88\AnalyticsCore\Process\Observer\Message\ProcessFinishedHandlingObserverMessage;
use Cehlers88\AnalyticsCore\Process\Observer\Message\ProcessStartHandlingObserverMessage;
use Cehlers88\AnalyticsCore\Process\Runner\ProcessRunnerInterface;
use Cehlers88\AnalyticsCore\Repository\ProcessRepository;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
use Cehlers88\AnalyticsCore\Support\Logging\SimpleConsoleLogger;

/** Provider for managing process execution and lifecycle. */
class ProcessProvider
{
    public const KEY_START_INFO = 'start_info';
    private LoggerInterface $logger;
    private bool $_debugMode = false;

    public function __construct(
        private ProcessRepository           $processRepository,
        private ObserverProvider            $observerProvider,
        private ProcessResultWorkerProvider $processResultWorkerProvider,
        private string                      $removeAbortedProcessesOlderThan,
        private string                      $removeFinishedProcessesOlderThan,
        private string                      $removeUnfinishedProcessesOlderThan,
    )
    {
        $this->logger = new SimpleConsoleLogger();
    }

    /**
     * Set a runner argument on a process.
     *
     * @param int|Process $process
     * @param string $argumentName
     * @param mixed $argumentValue
     * @return Process
     */
    public function setProcessRunnerArgument(
        int|Process $process,
        string      $argumentName,
        mixed       $argumentValue
    ): Process
    {
        if (is_numeric($process)) {
            $process = $this->processRepository->find($process);
        }

        if (is_null($process)) {
            throw new \Exception("Process not found");
        }

        $startInfo = $process->getStartInfo();
        $startInfo->runner_arguments[$argumentName] = $argumentValue;
        $processDetails = $process->getDetails();
        $processDetails[self::KEY_START_INFO] = $startInfo->toArray();
        $process->setDetails($processDetails);

        return $process;
    }

    /**
     * Runs all executable processes.
     * @param bool $ignoreProcessesWithMaintenanceState
     * @return static
     */
    public function runExecutableProcesses(bool $ignoreProcessesWithMaintenanceState = true): static
    {
        $processes = $this->findExecutableProcesses($ignoreProcessesWithMaintenanceState);

        foreach ($processes as $process) {
            $this->runProcess($process);
        }

        return $this;
    }

    /**
     * Returns all executable processes.
     * @param bool $ignoreProcessesWithMaintenanceState
     * @return Process[]
     */
    public function findExecutableProcesses(
        bool $ignoreProcessesWithMaintenanceState = true
    ): array
    {
        $stateBlacklist = [
            eRunningState::Running,
            eRunningState::FatalError,
            ...($ignoreProcessesWithMaintenanceState ? [
                eRunningState::Maintenance
            ] : [])
        ];

        return $this->processRepository->findByStates([
            eRunningState::WillStart,
            eRunningState::Buffering,
            eRunningState::BufferComplete,
            eRunningState::Finishing
        ], 'or', $stateBlacklist);
    }

    /**
     * Runs the given process.
     * @param Process $process
     * @return Process
     */
    public function runProcess(Process $process): Process
    {
        if ($this->_debugMode) {
            $this->logger->info("Running process: \"" . $process->getName() . "\" #" . $process->getId());
        }
        $this->_handleProcessWillStartRun($process);

        $previousState = $process->getStateValue();
        $previousDetails = $process->getDetails();

        try {
            $processRunner = $this->getProcessRunner($process);

            $processRunner
                ->setProcessResultWorkerProvider($this->processResultWorkerProvider)
                ->setProcessProvider($this)
                ->setProcessRepository($this->processRepository)
                ->setProcess($process)
                ->run();

        } catch (RunnerNotFoundException $e) {
            $process->addState(eRunningState::FatalError);
            $this->logger->error($e->getMessage(), []);
        } catch (\Throwable $e) {
            $this->logger->error($e->getMessage(), []);
        }

        if ($process->hasState(eRunningState::Finishing)) {
            $this->finishProcess($process);
        }

        $newDetails = $process->getDetails();

        if ($process->getStateValue() != $previousState || json_encode($newDetails) !== json_encode($previousDetails)) {
            $this->processRepository->save($process);
        }
        $this->_handleProcessHandled($process);

        return $process;
    }

    /**
     * Handles the process start event.
     *
     * @param Process $process
     * @return void
     */
    private function _handleProcessWillStartRun(Process $process): void
    {
        $process->setUpdatedAt(new \DateTime());
        $this->observerProvider->dispatch(new ProcessStartHandlingObserverMessage($process));
    }

    /**
     * @param Process $process
     * @return ProcessRunnerInterface
     * @throws \Exception
     */
    public function getProcessRunner(Process $process): ProcessRunnerInterface
    {
        $runnerClass = $process->getRunnerClass();

        if (empty($runnerClass)) {
            throw new RunnerNotFoundException('Runner not defined');
        }

        if (!class_exists($runnerClass)) {
            $exception = new RunnerNotFoundException(sprintf('Runner class "%s" not found', $runnerClass));
            $exception->setRunner($runnerClass);

            throw $exception;
        }

        return new $runnerClass();
    }

    /**
     * Finish a process and run its result worker if defined.
     *
     * @param Process $process
     * @return void
     */
    public function finishProcess(Process $process): void
    {
        if ($process->hasState(eRunningState::ResultProcessed)) {
            $process
                ->removeState(eRunningState::ProcessingResult)
                ->removeState(eRunningState::Finishing)
                ->addState(eRunningState::Finished);
            return;
        } else if ($process->hasState(eRunningState::ProcessingResult)) {
            return;
        }

        $resultWorkerDefinition = $process->getResultWorkerDefinition();

        if (is_null($resultWorkerDefinition)) {
            $this->logger->warning('No result worker definition found. Process will be marked as finished without processing the result.');
            $process->addState(eRunningState::ResultProcessed);
            return;
        }

        $resultWorker = $this->processResultWorkerProvider->getResultWorkerByClass($resultWorkerDefinition->worker);
        try {
            $processRunner = $this->getProcessRunner($process);
            $resultWorker
                ->setRunner($processRunner)
                ->setProcess($process);

            $resultWorker->run($process, $processRunner->getProcessResult(), $processRunner->getResultStatusCode());
        } catch (\Throwable $e) {
            $this->logger->error($e->getMessage(), []);
            $process->addState(eRunningState::Error);
        }
    }

    /**
     * Handles the process finish event.
     * @param Process $process
     * @return void
     */
    private function _handleProcessHandled(Process $process): void
    {
        $this->observerProvider->dispatch(new ProcessFinishedHandlingObserverMessage($process));
    }

    /** Finish the process associated with the given runner. */
    public function finishProcessRunner(ProcessRunnerInterface $processRunner): void
    {
        $this->finishProcess($processRunner->getProcess());
    }

    /**
     * Abort a process and store the result.
     *
     * @param int $processId
     * @param array<string, mixed> $result
     */
    public function setProcessAbort(int $processId, array $result = []): void
    {
        $process = $this->processRepository->find($processId);
        $processDetails = $process->getDetails();

        $processDetails["result"] = $result;
        $processDetails["set_cancel_at"] = (new \DateTime())->format('Y-m-d H:i:s');

        $process
            ->addState(eRunningState::Canceled)
            ->setDetails($processDetails);
        $this->processRepository->save($process);
    }

    /**
     * Mark a process as finished with the given result.
     *
     * @param int $processId
     * @param array<string, mixed> $result
     * @param \DateTime|null $finishedAt
     */
    public function setProcessFinished(int $processId, array $result = [], ?\DateTime $finishedAt = null): void
    {
        $process = $this->processRepository->find($processId);
        $processDetails = $process->getDetails();

        $processDetails["result"] = $result;
        $process
            ->setState(eRunningState::Finished)
            ->setFinishedAt(is_null($finishedAt) ? new \DateTime() : $finishedAt)
            ->setDetails($processDetails);
        $this->processRepository->save($process);
    }

    /**
     * Mark a process as started with the given start info.
     *
     * @param int $processId
     * @param array<string, mixed> $startInfo
     * @param \DateTime|null $startedAt
     */
    public function setProcessStarted(int $processId, array $startInfo = [], ?\DateTime $startedAt = null): void
    {
        $process = $this->processRepository->find($processId);
        $processDetails = $process->getDetails();

        foreach ($startInfo as $key => $value) {
            $processDetails[self::KEY_START_INFO][$key] = $value;
        }

        $process
            ->setState(eRunningState::Running)
            ->setStartedAt(is_null($startedAt) ? new \DateTime() : $startedAt)
            ->setDetails($processDetails);
        $this->processRepository->save($process);
    }

    /** Remove old processes based on configured age thresholds. */
    public function cleanUp(): static
    {
        $dateRemoveAborted = new \DateTime();
        $dateRemoveAborted->sub(\DateInterval::createFromDateString($this->removeAbortedProcessesOlderThan));

        $dateRemoveFinished = new \DateTime();
        $dateRemoveFinished->sub(\DateInterval::createFromDateString($this->removeFinishedProcessesOlderThan));

        $dateRemoveUnfinished = new \DateTime();
        $dateRemoveUnfinished->sub(\DateInterval::createFromDateString($this->removeUnfinishedProcessesOlderThan));

        $this->processRepository->removeByStateAndOlderThan(eRunningState::New, $dateRemoveUnfinished->format('Y-m-d H:i:s'));
        $this->processRepository->removeByStateAndOlderThan(eRunningState::Running, $dateRemoveUnfinished->format('Y-m-d H:i:s'));
        $this->processRepository->removeByStateAndOlderThan(eRunningState::Canceled, $dateRemoveAborted->format('Y-m-d H:i:s'));
        $this->processRepository->removeByStateAndOlderThan(eRunningState::Finished, $dateRemoveFinished->format('Y-m-d H:i:s'));

        return $this;
    }

    public function setDebugMode(bool $debugMode): static
    {
        $this->_debugMode = $debugMode;
        return $this;
    }

    private function _handleProcessErrorState(Process $process): void
    {
        $process->addState(eRunningState::Error);
        //$this->processRepository->save($process);
    }
}