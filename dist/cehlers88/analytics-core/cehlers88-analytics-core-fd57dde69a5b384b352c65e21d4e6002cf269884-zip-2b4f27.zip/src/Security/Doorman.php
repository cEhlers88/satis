<?php

namespace Cehlers88\AnalyticsCore\Security;

use Cehlers88\AnalyticsCore\DTO\ExtendedRoleDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Security\MagicRole\MagicRoleInterface;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Contracts\Service\ResetInterface;

/**
 * Decides whether the current caller has the required roles.
 *
 * The Doorman is a shared service, and a FrankenPHP worker serves many requests
 * with the same instance: the user is therefore read from the security context
 * when a check needs it - not once when the service is built - and everything a
 * request set on it is dropped between requests (reset(), tag kernel.reset).
 * Otherwise the first caller of a worker would decide who every later caller is.
 */
class Doorman implements ResetInterface
{
    private bool $debug = false;

    private int $httpStatusCode = -1;

    /** @var RoleDTO[]|ExtendedRoleDTO[] $requiredRoles */
    private array $requiredRoles = [];

    private ?Application $application = null;

    /** A user set explicitly for this request (setUser()), instead of the one signed in. */
    private ?UserInterface $user = null;
    private bool $hasExplicitUser = false;

    /** @var string[] $reasons */
    private array $reasons = [];

    /** @var string[] $messages */
    private array $messages = [];
    private ?string $clientIp = null;

    /**
     * @param MagicRoleInterface[] $magicRoles
     */
    public function __construct(
        private iterable $magicRoles,
        private Security $security,
    )
    {
    }

    public function reset(): void
    {
        $this->debug = false;
        $this->httpStatusCode = -1;
        $this->requiredRoles = [];
        $this->application = null;
        $this->user = null;
        $this->hasExplicitUser = false;
        $this->reasons = [];
        $this->messages = [];
        $this->clientIp = null;
    }

    /**
     * @param string[]|RoleDTO[]|ExtendedRoleDTO[] $roles
     */
    public function setRequiredRoles(array $roles): self
    {
        $this->requiredRoles = array_map(fn($tmp) => ($tmp instanceof RoleDTO ? $tmp : RoleDTO::create($tmp)), $roles);
        return $this;
    }

    public function checkPermission(?array $roles = null): bool
    {
        if (is_null($roles)) {
            $roles = $this->requiredRoles;
        }

        if (empty($roles)) {
            $this->messages = ['No roles required'];
            $this->reasons = ['No roles required'];

            return true;
        }

        $roles = array_map(fn($tmp) => ($tmp instanceof RoleDTO ? $tmp : RoleDTO::create($tmp)), $roles);

        $isAllowed = (count($this->_resolveRoles($roles)) === 0);

        if ($isAllowed) {
            $this->httpStatusCode = 200;
        }

        return $isAllowed;
    }

    private function _resolveRoles(?array $unresolved = null): array
    {
        if (is_null($unresolved)) {
            $unresolved = $this->requiredRoles;
        }

        $unresolved = $this->_resolveMagicRoles($unresolved);

        if (!empty($unresolved)) {
            if (!empty($this->getUser())) {
                $buffer = [];
                foreach ($unresolved as $role) {
                    if (!$this->_userHasRole($role->name)) {
                        if ($this->debug) {
                            $this->reasons[] = 'User does not have role: ' . $role->name;
                        }
                        $buffer[] = $role;
                    }
                }

                if ($this->_userHasRole('ROLE_ADMIN')) {
                    $this->httpStatusCode = 200;
                    $this->reasons[] = 'User has ROLE_ADMIN, skip missing roles:' . implode(',', $unresolved);

                    return [];
                }

                if (count($buffer) > 0) {
                    $this->httpStatusCode = 403;
                    if ($this->debug) {
                        $message = 'User "' . $this->getUser()->getUserIdentifier() . '" does not have all required roles';
                    } else {
                        $message = '';
                    }

                    foreach ($unresolved as $role) {
                        $this->reasons[] = 'User does not have role: ' . $role->name;
                    }
                    if (!in_array($message, $this->messages)) {
                        $this->messages[] = $message;
                    }
                }

                $unresolved = $buffer;
            }
        }

        return $unresolved;
    }

    /**
     * @return RoleDTO[]|ExtendedRoleDTO[]
     */
    private function _resolveMagicRoles(array $requiredRoles): array
    {
        $buffer = [];

        foreach ($requiredRoles as $role) {
            $resolved = false;
            foreach ($this->magicRoles as $magicRole) {
                if (
                    !$resolved &&
                    $magicRole
                        ->setApplication($this->application)
                        ->setUser($this->getUser())
                        ->setClientIp($this->clientIp)
                        ->canHandle($role->name)
                ) {
                    $magicRole->setRoleResolver([$this, 'checkPermission']);
                    $resolved = $magicRole->checkRole($role);
                }
            }

            if ($resolved) continue;

            $buffer[] = $role;
        }

        return $buffer;
    }

    public function setClientIp(string $clientIp): self
    {
        $this->clientIp = $clientIp;
        return $this;
    }

    public function setApplication(Application $application): self
    {
        $this->application = $application;
        return $this;
    }

    public function getUser(): ?UserInterface
    {
        return $this->hasExplicitUser ? $this->user : $this->security->getUser();
    }

    public function setUser(?UserInterface $user): self
    {
        $this->user = $user;
        $this->hasExplicitUser = true;
        return $this;
    }

    private function _userHasRole(string $role): bool
    {
        $user = $this->getUser();
        if (empty($user)) return false;

        return in_array($role, $user->getRoles());
    }

    public function getReasons(): array
    {
        return $this->reasons;
    }

    public function getMessages(): array
    {
        return $this->messages;
    }

    public function setDebug(bool $debug): self
    {
        $this->debug = $debug;
        return $this;
    }
}