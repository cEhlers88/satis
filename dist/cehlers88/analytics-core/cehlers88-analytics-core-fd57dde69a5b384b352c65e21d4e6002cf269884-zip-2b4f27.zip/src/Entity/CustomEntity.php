<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectInterface;
use Cehlers88\AnalyticsCore\Repository\CustomEntityRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CustomEntityRepository::class)]
/**
 * Entity representing a user-defined custom entity.
 */
class CustomEntity extends AbstractTaggedEntity
{
    #[ORM\Column(length: 255)]
    private ?string $className = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;
    #[ORM\Column(type: 'integer', nullable: true)]
    private ?int $parentId = null;

    /**
     * @var Collection<int, CustomEntityAttribute>
     */
    #[ORM\OneToMany(targetEntity: CustomEntityAttribute::class, mappedBy: 'customEntity', orphanRemoval: true, cascade: ['persist', 'remove'])]
    private Collection $attributes;


    #[ORM\OneToOne(cascade: ['persist', 'remove'])]
    private ?Statistics $statistics = null;

    #[ORM\Column]
    private array $config = [];

    public function __construct()
    {
        parent::__construct();
        $this->attributes = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getClassName(): ?string
    {
        return $this->className;
    }

    public function setClassName(string $className): static
    {
        $this->className = $className;

        return $this;
    }

    /**
     * @return Collection<int, CustomEntityAttribute>
     */
    public function getAttributes(): Collection
    {
        return $this->attributes;
    }

    public function hasAttribute(string $attributeName): bool
    {
        return $this->attributes->filter(function (CustomEntityAttribute $attribute) use ($attributeName) {
                return $attribute->getName() === $attributeName;
            })->count() > 0;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function setAttributeValue(string $attributeName, mixed $attributeValue): static
    {
        $attribute = $this->attributes->filter(function (CustomEntityAttribute $attribute) use ($attributeName) {
            return $attribute->getName() === $attributeName;
        })->first();

        if (empty($attribute)) {
            $attribute = new CustomEntityAttribute();
            $attribute->setName($attributeName);
        }
        $attribute
            ->setValue($attributeValue)
            ->setType(1);
        $this->addAttribute($attribute);

        return $this;
    }

    public function addAttribute(CustomEntityAttribute $attribute): static
    {
        if (!$this->attributes->contains($attribute)) {
            $this->attributes->add($attribute);
            $attribute->setCustomEntity($this);
        }

        return $this;
    }

    public function removeAttribute(CustomEntityAttribute $attribute): static
    {
        if ($this->attributes->removeElement($attribute)) {
            if ($attribute->getCustomEntity() === $this) {
                $attribute->setCustomEntity(null);
            }
        }

        return $this;
    }

    public function getCustomObject(bool $loadAttributes = true): CustomObjectInterface
    {
        /** @var CustomObjectInterface $resultObject */
        $resultObject = new $this->className();

        if (!$loadAttributes) {
            return $resultObject;
        }

        foreach ($this->attributes as $attribute) {
            $resultObject->setAttribute($attribute->getName(), $attribute->getValue());
        }

        return $resultObject;
    }

    public function getParentId(): ?int
    {
        return $this->parentId;
    }

    public function setParentId(?int $parentId): static
    {
        $this->parentId = $parentId;
        return $this;
    }


    public function getStatistics(): ?Statistics
    {
        return $this->statistics;
    }

    public function setStatistics(?Statistics $statistics): static
    {
        $this->statistics = $statistics;

        return $this;
    }

    public function getConfig(): array
    {
        return $this->config;
    }

    public function setConfig(array $config): static
    {
        $this->config = $config;

        return $this;
    }
}
