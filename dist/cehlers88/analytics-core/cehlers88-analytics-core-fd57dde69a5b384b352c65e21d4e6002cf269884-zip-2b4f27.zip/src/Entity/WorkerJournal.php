<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\WorkerJournalRepository;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\Index;

#[ORM\Entity(repositoryClass: WorkerJournalRepository::class)]
#[Index(name: 'created_at_idx', columns: ['created_at'])]
#[Index(name: 'modified_at_idx', columns: ['modified_at'])]
#[Index(name: 'updated_at_idx', columns: ['updated_at'])]
/**
 * Entity representing a worker journal entry.
 */
class WorkerJournal extends AbstractTaggedEntity
{
    #[ORM\ManyToOne(inversedBy: 'journals')]
    private ?Worker $worker = null;

    #[ORM\Column(type: Types::TEXT)]
    private ?string $result = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getWorker(): ?Worker
    {
        return $this->worker;
    }

    public function setWorker(?Worker $worker): static
    {
        $this->worker = $worker;

        return $this;
    }

    public function getResult(): ?string
    {
        return $this->result;
    }

    public function setResult(WorkerResultDTO $result): static
    {
        $this->result = $result->serialize();

        return $this;
    }
}
