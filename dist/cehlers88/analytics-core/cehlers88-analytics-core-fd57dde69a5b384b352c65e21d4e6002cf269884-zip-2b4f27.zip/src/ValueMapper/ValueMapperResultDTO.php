<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

/**
 * Outcome of a mapping. Errors mean the response did not look the way any
 * definition expects - usually the first sign that an API has changed - so
 * callers should check isSuccess() before evaluating $data.
 */
final class ValueMapperResultDTO extends DTO
{
    /**
     * @param string[] $errors
     */
    public function __construct(
        public readonly mixed          $data,
        public readonly ?string        $definitionName,
        public readonly MappingSubject $raw,
        public readonly array          $errors = [],
    )
    {
    }

    public static function createNoMatch(MappingSubject $raw): self
    {
        return new self(null, null, $raw, ['No value mapper definition matches the given value.']);
    }

    public function isSuccess(): bool
    {
        return $this->errors === [];
    }
}
