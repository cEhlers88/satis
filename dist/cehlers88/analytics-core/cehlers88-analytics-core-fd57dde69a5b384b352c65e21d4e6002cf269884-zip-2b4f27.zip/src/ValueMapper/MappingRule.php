<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper;

use Cehlers88\AnalyticsCore\ValueMapper\Transformer\TransformerInterface;

/**
 * Fills one target path of the mapped value, either from a source path of
 * the body or with a constant.
 *
 * - A source path with `*` yields a list; the transformers then run on each
 *   of its entries.
 * - A missing or null source falls back to the default, which is used as is
 *   (no transformers). Without a default a required rule fails, an optional
 *   one leaves the target out.
 */
final readonly class MappingRule
{
    /** @var TransformerInterface[] */
    private array $transformers;

    /**
     * @param TransformerInterface[] $transformers
     */
    private function __construct(
        public string   $target,
        public ?string  $source,
        private bool    $hasConstant,
        private mixed   $constant,
        array           $transformers,
        private bool    $required,
        private bool    $hasDefault,
        private mixed   $default,
    )
    {
        $this->transformers = array_values($transformers);
    }

    /**
     * @param TransformerInterface[] $transformers
     */
    public static function fromSource(
        string $target,
        string $source,
        array  $transformers = [],
        bool   $required = false,
        bool   $hasDefault = false,
        mixed  $default = null,
    ): self
    {
        return new self($target, $source, false, null, $transformers, $required, $hasDefault, $default);
    }

    public static function constant(string $target, mixed $value): self
    {
        return new self($target, null, true, $value, [], false, false, null);
    }

    /**
     * @return array{0: bool, 1: mixed} whether the target is to be set, and its value
     * @throws ValueMapperException
     */
    public function resolve(MappingSubject $subject): array
    {
        if ($this->hasConstant) {
            return [true, $this->constant];
        }

        [$found, $value] = PathAccessor::find($subject->body, (string)$this->source);

        if (!$found || $value === null) {
            if ($this->hasDefault) {
                return [true, $this->default];
            }
            if ($this->required) {
                throw new ValueMapperException(sprintf('Required source "%s" is missing or null.', $this->source));
            }

            return $found ? [true, null] : [false, null];
        }

        if (PathAccessor::containsWildcard((string)$this->source) && is_array($value)) {
            return [true, array_map($this->applyTransformers(...), $value)];
        }

        return [true, $this->applyTransformers($value)];
    }

    private function applyTransformers(mixed $value): mixed
    {
        foreach ($this->transformers as $transformer) {
            $value = $transformer->transform($value);
        }

        return $value;
    }
}
