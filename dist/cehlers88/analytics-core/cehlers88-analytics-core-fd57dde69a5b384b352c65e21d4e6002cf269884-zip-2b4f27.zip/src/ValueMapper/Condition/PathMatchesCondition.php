<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Condition;

use Cehlers88\AnalyticsCore\ValueMapper\MappingSubject;
use Cehlers88\AnalyticsCore\ValueMapper\PathAccessor;

/**
 * Matches when the scalar value at the path matches a regular expression
 * (a complete PCRE pattern including delimiters, e.g. `/^v2\./`).
 */
final readonly class PathMatchesCondition implements ConditionInterface
{
    public function __construct(
        private string $path,
        private string $pattern,
    )
    {
        if (@preg_match($pattern, '') === false) {
            throw new \InvalidArgumentException(sprintf('Invalid regular expression "%s".', $pattern));
        }
    }

    public function matches(MappingSubject $subject): bool
    {
        [$found, $value] = PathAccessor::find($subject->body, $this->path);
        if (!$found || !is_scalar($value)) {
            return false;
        }

        return preg_match($this->pattern, is_bool($value) ? ($value ? 'true' : 'false') : (string)$value) === 1;
    }
}
