<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Condition;

use Cehlers88\AnalyticsCore\ValueMapper\MappingSubject;

/**
 * Decides whether a value mapper definition is responsible for a value.
 */
interface ConditionInterface
{
    public function matches(MappingSubject $subject): bool;
}
