<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Condition;

use Cehlers88\AnalyticsCore\ValueMapper\MappingSubject;

final readonly class AnyOfCondition implements ConditionInterface
{
    /** @var ConditionInterface[] */
    private array $conditions;

    public function __construct(ConditionInterface ...$conditions)
    {
        $this->conditions = $conditions;
    }

    public function matches(MappingSubject $subject): bool
    {
        foreach ($this->conditions as $condition) {
            if ($condition->matches($subject)) {
                return true;
            }
        }

        return false;
    }
}
