<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Condition;

use Cehlers88\AnalyticsCore\ValueMapper\MappingSubject;

/**
 * Matches the status code against one or more patterns: an exact code
 * (`404`), a class (`2xx`) or an inclusive range (`500-504`).
 *
 * A value without a status code never matches, so a definition bound to a
 * status code is not applied to values of other sources by accident.
 */
final readonly class StatusCondition implements ConditionInterface
{
    /** @var array<int, array{0: int, 1: int}> */
    private array $ranges;

    /**
     * @param int|string|array<int|string> $status
     */
    public function __construct(int|string|array $status)
    {
        $patterns = is_array($status) ? $status : [$status];
        if ($patterns === []) {
            throw new \InvalidArgumentException('A status condition needs at least one status pattern.');
        }

        $this->ranges = array_map(self::parse(...), $patterns);
    }

    public function matches(MappingSubject $subject): bool
    {
        if ($subject->statusCode === null) {
            return false;
        }

        foreach ($this->ranges as [$from, $to]) {
            if ($subject->statusCode >= $from && $subject->statusCode <= $to) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return array{0: int, 1: int}
     */
    private static function parse(int|string $pattern): array
    {
        $pattern = strtolower(trim((string)$pattern));

        if (preg_match('/^\d{3}$/', $pattern)) {
            return [(int)$pattern, (int)$pattern];
        }

        if (preg_match('/^([1-5])xx$/', $pattern, $matches)) {
            $from = (int)$matches[1] * 100;

            return [$from, $from + 99];
        }

        if (preg_match('/^(\d{3})\s*-\s*(\d{3})$/', $pattern, $matches) && (int)$matches[1] <= (int)$matches[2]) {
            return [(int)$matches[1], (int)$matches[2]];
        }

        throw new \InvalidArgumentException(sprintf('Invalid status pattern "%s".', $pattern));
    }
}
