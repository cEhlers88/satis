<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Condition;

use Cehlers88\AnalyticsCore\ValueMapper\MappingSubject;

/**
 * Matches when a header is present (name compared case-insensitively) and,
 * if a value is given, one of its values equals it.
 */
final readonly class HeaderCondition implements ConditionInterface
{
    public function __construct(
        private string  $name,
        private ?string $value = null,
    )
    {
    }

    public function matches(MappingSubject $subject): bool
    {
        $values = $subject->getHeaderValues($this->name);
        if ($values === []) {
            return false;
        }

        return $this->value === null || in_array($this->value, array_map('trim', $values), true);
    }
}
