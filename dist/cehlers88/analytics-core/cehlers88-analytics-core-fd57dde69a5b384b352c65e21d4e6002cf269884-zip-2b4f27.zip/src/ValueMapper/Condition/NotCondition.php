<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Condition;

use Cehlers88\AnalyticsCore\ValueMapper\MappingSubject;

final readonly class NotCondition implements ConditionInterface
{
    public function __construct(private ConditionInterface $condition)
    {
    }

    public function matches(MappingSubject $subject): bool
    {
        return !$this->condition->matches($subject);
    }
}
