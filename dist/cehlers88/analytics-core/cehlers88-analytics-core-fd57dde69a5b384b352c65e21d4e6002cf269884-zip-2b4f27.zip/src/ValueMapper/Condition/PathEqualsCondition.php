<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Condition;

use Cehlers88\AnalyticsCore\ValueMapper\MappingSubject;
use Cehlers88\AnalyticsCore\ValueMapper\PathAccessor;

/**
 * Matches when the value at the path equals the expected one.
 *
 * Not strict by default: definitions are stored as JSON and typed into an
 * editor, so `"1"` and `1` should be the same thing there. Scalars are then
 * compared as strings (`true`/`false` as "true"/"false"), everything else
 * with `==`.
 */
final readonly class PathEqualsCondition implements ConditionInterface
{
    public function __construct(
        private string $path,
        private mixed  $value,
        private bool   $strict = false,
    )
    {
    }

    public function matches(MappingSubject $subject): bool
    {
        [$found, $actual] = PathAccessor::find($subject->body, $this->path);
        if (!$found) {
            return false;
        }

        if ($this->strict) {
            return $actual === $this->value;
        }

        if (is_scalar($actual) && is_scalar($this->value)) {
            return self::toString($actual) === self::toString($this->value);
        }

        return $actual == $this->value;
    }

    private static function toString(string|int|float|bool $value): string
    {
        return is_bool($value) ? ($value ? 'true' : 'false') : (string)$value;
    }
}
