<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Condition;

use Cehlers88\AnalyticsCore\ValueMapper\MappingSubject;
use Cehlers88\AnalyticsCore\ValueMapper\PathAccessor;

/**
 * Matches when the body contains the path - even if its value is null.
 */
final readonly class PathExistsCondition implements ConditionInterface
{
    public function __construct(private string $path)
    {
    }

    public function matches(MappingSubject $subject): bool
    {
        return PathAccessor::has($subject->body, $this->path);
    }
}
