<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Transformer;

use Cehlers88\AnalyticsCore\ValueMapper\ValueMapperException;

/**
 * Casts to `string`, `int`, `float`, `bool` or `array`.
 *
 * Unlike PHP's own casts it refuses values that have no sensible meaning in
 * the target type (`"abc"` to int, an array to string), because a silent 0
 * would hide exactly the API change the mapping is supposed to catch.
 * null is passed through; use a default on the rule to replace it.
 */
final readonly class CastTransformer implements TransformerInterface
{
    private const array TYPES = ['string', 'int', 'float', 'bool', 'array'];
    private const array ALIASES = ['integer' => 'int', 'double' => 'float', 'boolean' => 'bool'];

    private string $type;

    public function __construct(string $type)
    {
        $type = strtolower(trim($type));
        $type = self::ALIASES[$type] ?? $type;

        if (!in_array($type, self::TYPES, true)) {
            throw new \InvalidArgumentException(sprintf('Unknown cast type "%s".', $type));
        }

        $this->type = $type;
    }

    public function transform(mixed $value): mixed
    {
        if ($value === null) {
            return null;
        }

        return match ($this->type) {
            'string' => $this->toString($value),
            'int' => $this->toInt($value),
            'float' => $this->toFloat($value),
            'bool' => $this->toBool($value),
            'array' => is_array($value) ? $value : [$value],
        };
    }

    private function toString(mixed $value): string
    {
        return match (true) {
            is_bool($value) => $value ? 'true' : 'false',
            is_scalar($value), $value instanceof \Stringable => (string)$value,
            default => throw $this->cannotCast($value),
        };
    }

    private function toInt(mixed $value): int
    {
        if (is_int($value)) {
            return $value;
        }
        if (is_bool($value)) {
            return (int)$value;
        }
        // PHP clamps or wraps values beyond the integer range; that would be a made-up number.
        if (is_float($value) && floor($value) === $value && $value >= PHP_INT_MIN && $value < PHP_INT_MAX) {
            return (int)$value;
        }
        if (is_string($value) && preg_match('/^\s*([+-]?)0*(\d+)\s*$/', $value, $matches)) {
            $int = filter_var(($matches[1] === '-' ? '-' : '') . $matches[2], FILTER_VALIDATE_INT);
            if ($int !== false) {
                return $int;
            }
        }

        throw $this->cannotCast($value);
    }

    private function toFloat(mixed $value): float
    {
        if (is_int($value) || is_float($value) || is_bool($value)) {
            return (float)$value;
        }
        if (is_string($value) && is_numeric(trim($value))) {
            return (float)trim($value);
        }

        throw $this->cannotCast($value);
    }

    private function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value)) {
            return $value != 0;
        }
        if (is_string($value)) {
            $normalized = strtolower(trim($value));
            if (in_array($normalized, ['true', '1', 'yes', 'on'], true)) {
                return true;
            }
            if (in_array($normalized, ['false', '0', 'no', 'off', ''], true)) {
                return false;
            }
        }

        throw $this->cannotCast($value);
    }

    private function cannotCast(mixed $value): ValueMapperException
    {
        return new ValueMapperException(sprintf(
            'Cannot cast %s to %s.',
            is_scalar($value) ? sprintf('"%s"', $value) : get_debug_type($value),
            $this->type
        ));
    }
}
