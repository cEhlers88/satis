<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Transformer;

use Cehlers88\AnalyticsCore\ValueMapper\ValueMapperException;

/**
 * Translates values through a lookup table, e.g. an API's status names to
 * our own (`{"ACTIVE": "active", "DISABLED": "inactive"}`).
 *
 * Scalars are looked up by their string form (`true` as "true"). A value
 * missing from the table is an error unless a default is configured - an
 * unknown value is often a new state the evaluation does not know yet.
 */
final readonly class MapTransformer implements TransformerInterface
{
    /**
     * @param array<string|int, mixed> $map
     */
    public function __construct(
        private array $map,
        private bool  $hasDefault = false,
        private mixed $default = null,
    )
    {
    }

    public function transform(mixed $value): mixed
    {
        if (is_scalar($value)) {
            $key = is_bool($value) ? ($value ? 'true' : 'false') : (string)$value;
            if (array_key_exists($key, $this->map)) {
                return $this->map[$key];
            }
        }

        if ($this->hasDefault) {
            return $this->default;
        }

        throw new ValueMapperException(sprintf(
            'No mapping for %s.',
            is_scalar($value) ? sprintf('"%s"', is_bool($value) ? ($value ? 'true' : 'false') : $value) : get_debug_type($value)
        ));
    }
}
