<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Transformer;

/**
 * Trims strings; other values pass unchanged.
 */
final readonly class TrimTransformer implements TransformerInterface
{
    public function __construct(private string $characters = " \n\r\t\v\0")
    {
    }

    public function transform(mixed $value): mixed
    {
        return is_string($value) ? trim($value, $this->characters) : $value;
    }
}
