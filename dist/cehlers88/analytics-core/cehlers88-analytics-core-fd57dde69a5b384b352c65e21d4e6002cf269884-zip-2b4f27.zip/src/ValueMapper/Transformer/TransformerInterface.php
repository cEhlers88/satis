<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Transformer;

use Cehlers88\AnalyticsCore\ValueMapper\ValueMapperException;

/**
 * One step in the transformation chain of a mapping rule.
 */
interface TransformerInterface
{
    /**
     * @throws ValueMapperException when the value cannot be transformed;
     *                              never return a made-up value instead
     */
    public function transform(mixed $value): mixed;
}
