<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper\Transformer;

use Cehlers88\AnalyticsCore\ValueMapper\ValueMapperException;

/**
 * Reformats dates. The input is read with $from (a DateTimeInterface
 * format) or, without one, by DateTimeImmutable's parser; integers are
 * taken as Unix timestamps. The output is formatted with $to.
 */
final readonly class DateTransformer implements TransformerInterface
{
    public function __construct(
        private ?string $from = null,
        private string  $to = \DateTimeInterface::ATOM,
        private ?string $timezone = null,
    )
    {
        if ($timezone !== null) {
            try {
                new \DateTimeZone($timezone);
            } catch (\Exception) {
                throw new \InvalidArgumentException(sprintf('Unknown timezone "%s".', $timezone));
            }
        }
    }

    public function transform(mixed $value): mixed
    {
        if ($value === null) {
            return null;
        }

        $date = $this->parse($value);
        if ($this->timezone !== null) {
            $date = $date->setTimezone(new \DateTimeZone($this->timezone));
        }

        return $date->format($this->to);
    }

    /**
     * The parser rolls invalid dates over with only a warning (2026-02-31
     * becomes 2026-03-03) - a date the response never contained.
     */
    private static function parsedCleanly(): bool
    {
        $errors = \DateTimeImmutable::getLastErrors();

        return $errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0);
    }

    private function parse(mixed $value): \DateTimeImmutable
    {
        if ($value instanceof \DateTimeInterface) {
            return \DateTimeImmutable::createFromInterface($value);
        }

        if (is_int($value) && $this->from === null) {
            return new \DateTimeImmutable('@' . $value);
        }

        if (is_string($value) || is_int($value)) {
            $value = (string)$value;
            if ($this->from !== null) {
                $date = \DateTimeImmutable::createFromFormat($this->from, $value);
                if ($date !== false && self::parsedCleanly()) {
                    return $date;
                }
            } elseif (trim($value) !== '') {
                try {
                    $date = new \DateTimeImmutable($value);
                    if (self::parsedCleanly()) {
                        return $date;
                    }
                } catch (\Exception) {
                }
            }
        }

        throw new ValueMapperException(sprintf(
            'Cannot read %s as date%s.',
            is_scalar($value) ? sprintf('"%s"', $value) : get_debug_type($value),
            $this->from !== null ? sprintf(' in format "%s"', $this->from) : ''
        ));
    }
}
