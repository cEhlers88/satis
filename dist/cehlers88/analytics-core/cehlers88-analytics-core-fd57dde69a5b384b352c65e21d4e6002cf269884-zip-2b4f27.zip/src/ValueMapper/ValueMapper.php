<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper;

/**
 * Brings a value - typically the response of an external service - into the
 * shape its evaluation expects.
 *
 * Of the definitions, the first matching one wins: higher priority first,
 * equal priorities in the order they were added. A definition without
 * conditions and with a low priority serves as fallback. If none matches,
 * the result carries an error instead of the unmapped value.
 */
final class ValueMapper implements ValueMapperInterface
{
    /** @var ValueMapperDefinition[] */
    private array $definitions = [];

    public function __construct(ValueMapperDefinition ...$definitions)
    {
        foreach ($definitions as $definition) {
            $this->addDefinition($definition);
        }
    }

    public function addDefinition(ValueMapperDefinition $definition): static
    {
        $this->definitions[] = $definition;
        // usort is stable, so equal priorities keep their order
        usort($this->definitions, static fn(ValueMapperDefinition $a, ValueMapperDefinition $b) => $b->priority <=> $a->priority);

        return $this;
    }

    /**
     * @return ValueMapperDefinition[] in the order they are tried
     */
    public function getDefinitions(): array
    {
        return $this->definitions;
    }

    public function findDefinition(mixed $value): ?ValueMapperDefinition
    {
        $subject = MappingSubject::fromValue($value);
        foreach ($this->definitions as $definition) {
            if ($definition->matches($subject)) {
                return $definition;
            }
        }

        return null;
    }

    public function map(mixed $value): ValueMapperResultDTO
    {
        $subject = MappingSubject::fromValue($value);
        $definition = $this->findDefinition($subject);

        return $definition?->apply($subject) ?? ValueMapperResultDTO::createNoMatch($subject);
    }
}
