<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper;

/**
 * A value could not be transformed; mapping reports it as an error of the
 * rule instead of passing a wrong value on.
 */
class ValueMapperException extends \RuntimeException
{
}
