<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper;

use Cehlers88\AnalyticsCore\Support\DTO\CurlResponseDTO;

/**
 * What a value mapper works on: the body of a response plus, when the value
 * came from a transport that has them, its status code and headers.
 *
 * Paths used by conditions and rules always address the body.
 */
final readonly class MappingSubject
{
    /**
     * @param array<string, string|string[]> $headers
     */
    public function __construct(
        public mixed $body,
        public ?int  $statusCode = null,
        public array $headers = [],
    )
    {
    }

    public static function fromValue(mixed $value): self
    {
        return match (true) {
            $value instanceof self => $value,
            $value instanceof CurlResponseDTO => new self($value->body, $value->statusCode, $value->headers),
            default => new self($value),
        };
    }

    /**
     * Header values by case-insensitive name; a header sent several times
     * yields all of its values.
     *
     * @return string[]
     */
    public function getHeaderValues(string $name): array
    {
        $values = [];
        foreach ($this->headers as $headerName => $value) {
            if (strcasecmp((string)$headerName, $name) === 0) {
                array_push($values, ...(array)$value);
            }
        }

        return array_map('strval', $values);
    }
}
