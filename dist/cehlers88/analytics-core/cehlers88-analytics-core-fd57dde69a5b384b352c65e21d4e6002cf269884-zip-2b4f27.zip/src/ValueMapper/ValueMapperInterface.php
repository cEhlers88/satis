<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper;

interface ValueMapperInterface
{
    /**
     * @param mixed $value a raw value, a CurlResponseDTO or a MappingSubject
     */
    public function map(mixed $value): ValueMapperResultDTO;
}
