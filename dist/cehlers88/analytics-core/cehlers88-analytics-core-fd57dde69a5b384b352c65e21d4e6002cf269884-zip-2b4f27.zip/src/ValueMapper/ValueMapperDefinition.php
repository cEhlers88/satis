<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper;

use Cehlers88\AnalyticsCore\ValueMapper\Condition\ConditionInterface;

/**
 * One expected shape of a value: the conditions under which it applies (all
 * must match; none means always) and the rules that build the mapped value.
 */
final readonly class ValueMapperDefinition
{
    /** @var ConditionInterface[] */
    public array $conditions;
    /** @var MappingRule[] */
    public array $rules;

    /**
     * @param ConditionInterface[] $conditions
     * @param MappingRule[] $rules
     */
    public function __construct(
        public string $name,
        array         $conditions = [],
        array         $rules = [],
        public int    $priority = 0,
    )
    {
        $this->conditions = array_values($conditions);
        $this->rules = array_values($rules);
    }

    public function matches(MappingSubject $subject): bool
    {
        foreach ($this->conditions as $condition) {
            if (!$condition->matches($subject)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Applies every rule, even after one failed, so the result names all
     * deviations at once and still carries what could be mapped.
     */
    public function apply(MappingSubject $subject): ValueMapperResultDTO
    {
        $data = [];
        $errors = [];

        foreach ($this->rules as $rule) {
            try {
                [$set, $value] = $rule->resolve($subject);
            } catch (ValueMapperException $e) {
                $errors[] = sprintf('%s: %s', $rule->target === '' ? '(root)' : $rule->target, $e->getMessage());
                continue;
            }

            if ($set) {
                $data = PathAccessor::set($data, $rule->target, $value);
            }
        }

        return new ValueMapperResultDTO($data, $this->name, $subject, $errors);
    }
}
