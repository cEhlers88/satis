<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper;

/**
 * Reads and writes values by dot path (`data.items.0.id`).
 *
 * - An empty path addresses the value itself.
 * - `*` reads every entry of a list or map and yields the found values as a
 *   list (`items.*.id`); entries lacking the rest of the path are skipped.
 * - Arrays, ArrayAccess and public object properties can be read; writing
 *   only builds nested arrays.
 */
final class PathAccessor
{
    public const string WILDCARD = '*';

    public static function has(mixed $data, string $path): bool
    {
        return self::lookup($data, self::split($path))[0];
    }

    public static function get(mixed $data, string $path, mixed $default = null): mixed
    {
        [$found, $value] = self::lookup($data, self::split($path));

        return $found ? $value : $default;
    }

    /**
     * @return array{0: bool, 1: mixed} whether the path exists, and its value
     */
    public static function find(mixed $data, string $path): array
    {
        return self::lookup($data, self::split($path));
    }

    public static function containsWildcard(string $path): bool
    {
        return in_array(self::WILDCARD, self::split($path), true);
    }

    public static function set(mixed $data, string $path, mixed $value): mixed
    {
        $segments = self::split($path);
        if ($segments === []) {
            return $value;
        }

        if (in_array(self::WILDCARD, $segments, true)) {
            throw new \InvalidArgumentException(sprintf('A target path must not contain "%s": "%s"', self::WILDCARD, $path));
        }

        $data = is_array($data) ? $data : [];
        $cursor = &$data;
        foreach ($segments as $segment) {
            if (!isset($cursor[$segment]) || !is_array($cursor[$segment])) {
                $cursor[$segment] = [];
            }
            $cursor = &$cursor[$segment];
        }
        $cursor = $value;
        unset($cursor);

        return $data;
    }

    /**
     * @return string[]
     */
    private static function split(string $path): array
    {
        $path = trim($path);

        return $path === '' ? [] : explode('.', $path);
    }

    /**
     * @param string[] $segments
     * @return array{0: bool, 1: mixed}
     */
    private static function lookup(mixed $data, array $segments): array
    {
        if ($segments === []) {
            return [true, $data];
        }

        $segment = array_shift($segments);

        if ($segment === self::WILDCARD) {
            if (!is_iterable($data)) {
                return [false, null];
            }

            $values = [];
            foreach ($data as $entry) {
                [$found, $value] = self::lookup($entry, $segments);
                if ($found) {
                    $values[] = $value;
                }
            }

            return [true, $values];
        }

        if (is_array($data)) {
            return array_key_exists($segment, $data)
                ? self::lookup($data[$segment], $segments)
                : [false, null];
        }

        if ($data instanceof \ArrayAccess) {
            return $data->offsetExists($segment)
                ? self::lookup($data[$segment], $segments)
                : [false, null];
        }

        if (is_object($data)) {
            $properties = get_object_vars($data);

            return array_key_exists($segment, $properties)
                ? self::lookup($properties[$segment], $segments)
                : [false, null];
        }

        return [false, null];
    }
}
