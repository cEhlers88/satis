<?php


namespace Cehlers88\AnalyticsCore\Executor;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Interface\Repository\IExternalServiceFunctionRepository;
use Cehlers88\AnalyticsCore\Provider\ExternalServiceProvider;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerProvider;
use Cehlers88\AnalyticsCore\ValueMapper\ValueMapper;
use Cehlers88\AnalyticsCore\ValueMapper\ValueMapperFactory;
use Cehlers88\AnalyticsCore\ValueMapper\ValueMapperResultDTO;

class ExternalServiceExecutor extends AbstractExecutor
{
    public const string KEY_SERVICE_NAME = 'serviceName';
    public const string KEY_ENTRY_NAME = 'entryName';
    public const string KEY_FUNCTION_NAME = 'functionName';
    public const string KEY_ARGUMENTS = 'arguments';
    public const string KEY_OPTIONS = 'options';
    public const string KEY_LOGGER = 'logger';

    /**
     * Option the execution adapter reads to return error statuses instead of
     * throwing them; set whenever response mappings take care of them.
     */
    public const string OPTION_THROW_ON_HTTP_ERROR = 'throwOnHttpError';

    public const int ERR_RESPONSE_MAPPING = 500120;

    public function __construct(
        private ExternalServiceProvider           $externalServiceProvider,
        private IExternalServiceFunctionRepository $externalServiceFunctionRepository,
        private LoggerProvider                    $loggerProvider,
        private ValueMapperFactory                $valueMapperFactory = new ValueMapperFactory(),
    )
    {
        $this
            ->addProperty(PropertyDTO::create(self::KEY_SERVICE_NAME, null))
            ->addProperty(PropertyDTO::create(self::KEY_ARGUMENTS, null))
            ->addProperty(PropertyDTO::create(self::KEY_OPTIONS, null))
            ->addProperty(PropertyDTO::create(self::KEY_FUNCTION_NAME, null, 'string', true))
            ->addProperty(PropertyDTO::create(self::KEY_ENTRY_NAME, null, 'string', true))
            ->addProperty(PropertyDTO::create(self::KEY_LOGGER, null, 'array', true));
    }

    public function isValid(): bool
    {
        return parent::isValid()
            && $this->getPropertyValue(self::KEY_SERVICE_NAME) !== null
            && $this->getPropertyValue(self::KEY_FUNCTION_NAME) !== null;
    }

    public function isRunning(): bool
    {
        return false;
    }

    public function wantsToReRun(): bool
    {
        return false;
    }

    protected function execute(): void
    {
        $loggerData = $this->getPropertyValue(self::KEY_LOGGER);
        if (is_array($loggerData)) {
            $logger = $this->_buildLogger($loggerData);
            if ($logger !== null) {
                $this->setLogger($logger);
            }
        }

        $arguments = $this->getPropertyValue(self::KEY_ARGUMENTS, []);
        $optionOverrides = $this->getPropertyValue(self::KEY_OPTIONS, []);
        $commandPlayer = $this->externalServiceProvider->getCommandPlayer();

        $variableStoreProvider = $commandPlayer->getVariablesStoreProvider();

        foreach ($arguments as $key => $value) {
            $variableStoreProvider->setArgument($key, $value);
        }

        try {
            $adapter = $this->externalServiceProvider->getExecutionAdapterByName(
                $this->getPropertyValue(self::KEY_SERVICE_NAME)
            );
        } catch (\Exception $e) {
            $this->setError($e->getMessage());
            $this->lastResult = $e;
            return;
        }

        foreach ($optionOverrides as $key => $value) {
            $optionOverrides[$key] = $commandPlayer->run($value);
        }

        try {
            $responseMapper = $this->_buildResponseMapper();
        } catch (\InvalidArgumentException $e) {
            // Fail before the call: a broken definition would otherwise only show after the side effects.
            $this->setError('Invalid response mapping: ' . $e->getMessage(), self::ERR_RESPONSE_MAPPING);
            return;
        }

        if ($responseMapper !== null) {
            $optionOverrides[self::OPTION_THROW_ON_HTTP_ERROR] = false;
        }
        $this->logInfo(json_encode([
            'function' => $this->getPropertyValue(self::KEY_FUNCTION_NAME),
            'args' => $arguments,
            'options' => $optionOverrides,
        ]));

        $this->lastResult = $adapter->callFunction(
            $this->getPropertyValue(self::KEY_FUNCTION_NAME),
            $arguments,
            $optionOverrides
        );

        if ($responseMapper !== null) {
            $this->lastResult = $this->_mapResponse($responseMapper, $this->lastResult);
        }
    }

    /**
     * The mapper of the function's response mappings, or null when it has none
     * (and its response is handed on raw, as before).
     *
     * @throws \InvalidArgumentException when a definition is invalid
     */
    private function _buildResponseMapper(): ?ValueMapper
    {
        $function = $this->externalServiceFunctionRepository->findOneByServiceAndName(
            (string)$this->getPropertyValue(self::KEY_SERVICE_NAME),
            (string)$this->getPropertyValue(self::KEY_FUNCTION_NAME)
        );

        $mappings = $function?->getResponseMappings() ?? [];
        if ($mappings === []) {
            return null;
        }

        return $this->valueMapperFactory->createMapper($mappings);
    }

    /**
     * A response no definition expects is an error of the call, as an error
     * status was before mappings accepted it; the result keeps the raw
     * response for the caller to look at.
     */
    private function _mapResponse(ValueMapper $mapper, mixed $response): ValueMapperResultDTO
    {
        $result = $mapper->map($response);

        if ($result->isSuccess()) {
            $this->logInfo(sprintf('Response mapped by definition "%s".', $result->definitionName), true);
        } else {
            $this->setError(
                'Response mapping failed: ' . implode('; ', $result->errors),
                self::ERR_RESPONSE_MAPPING,
                ['definition' => $result->definitionName, 'statusCode' => $result->raw->statusCode]
            );
        }

        return $result;
    }

    /**
     * @param array<string, mixed> $loggerData
     */
    private function _buildLogger(array $loggerData): ?LoggerInterface
    {
        if (!isset($loggerData['loggerClass']) || !is_string($loggerData['loggerClass'])) {
            return null;
        }

        $loggerClass = $loggerData['loggerClass'];
        $knownClasses = array_column($this->loggerProvider->getLoggerDefinitions(), 'class');

        if (!in_array($loggerClass, $knownClasses, true) || !class_exists($loggerClass)) {
            return null;
        }

        $logger = $this->loggerProvider->getLoggerByName($loggerClass);

        if (!($logger instanceof LoggerInterface)) {
            return null;
        }

        $properties = $loggerData['properties'] ?? [];
        if (is_array($properties)) {
            foreach ($properties as $name => $value) {
                if (!is_string($name) || $name === '') {
                    continue;
                }
                try {
                    $logger->setPropertyValue($name, $value);
                } catch (\InvalidArgumentException) {
                    // Property doesn't exist on this logger; skip it
                }
            }
        }

        return $logger;
    }
}