<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\ExternalServiceFunction;
use Cehlers88\AnalyticsCore\Interface\Repository\IExternalServiceFunctionRepository;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<ExternalServiceFunction>
 */
class ExternalServiceFunctionRepository extends ServiceEntityRepository implements IExternalServiceFunctionRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, ExternalServiceFunction::class);
    }

    public function findOneByServiceAndName(string $serviceName, string $functionName): ?ExternalServiceFunction
    {
        return $this->createQueryBuilder('f')
            ->innerJoin('f.externalService', 's')
            ->andWhere('s.name = :serviceName')
            ->andWhere('f.name = :functionName')
            ->setParameter('serviceName', $serviceName)
            ->setParameter('functionName', $functionName)
            ->setMaxResults(1)
            ->getQuery()
            ->getOneOrNullResult();
    }
}
