<?php

namespace Cehlers88\AnalyticsCore\Support;

use Cehlers88\AnalyticsCore\Support\DTO\CurlResponseDTO;
use RuntimeException;

class CurlHelper
{
    private int $timeout = 10;
    private bool $returnTransfer = true;
    private bool $throwOnHttpError = true;

    /**
     * By default any status but 200 is thrown as RuntimeException. Callers that
     * evaluate the status themselves - e.g. through response mappings of a
     * ValueMapper - switch that off and get every response as CurlResponseDTO.
     * Transport errors (no response at all) are thrown either way.
     */
    public function setThrowOnHttpError(bool $throwOnHttpError): static
    {
        $this->throwOnHttpError = $throwOnHttpError;

        return $this;
    }

    public function get(string $url, array $headers = []): CurlResponseDTO
    {
        return $this->_exec($url, 'GET', '', $headers);
    }

    private function _exec(
        string $url,
        string $method,
        string $body = '',
        array  $headers = [],
    ): CurlResponseDTO
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, $this->returnTransfer);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        if (!empty($body)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $responseHeaders = [];
        curl_setopt($ch, CURLOPT_HEADERFUNCTION, static function ($ch, string $line) use (&$responseHeaders): int {
            // A redirect or a 100 Continue starts a new header block; only the last one belongs to the body.
            if (str_starts_with($line, 'HTTP/')) {
                $responseHeaders = [];
            } elseif (str_contains($line, ':')) {
                [$name, $value] = explode(':', $line, 2);
                $responseHeaders[trim($name)][] = trim($value);
            }

            return strlen($line);
        });
        $response = curl_exec($ch);

        if ($response === false) {
            throw new RuntimeException(
                sprintf(
                    'Curl error (%d): %s',
                    curl_errno($ch),
                    curl_error($ch)
                )
            );
        }

        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $body = $response;

        if ($this->throwOnHttpError && $statusCode !== 200) {
            throw new RuntimeException('Curl error: ' . $statusCode . ' ' . $body . '');
        }

        try {
            $body = json_decode($response, true);
            if (is_null($body) && !is_null($response)) {
                $body = $response;
            }
        } catch (\Exception) {
            $body = $response;
        }

        return new CurlResponseDTO(
            $statusCode,
            $body,
            $responseHeaders
        );
    }

    public function post(string $url, mixed $data, array $headers): CurlResponseDTO
    {
        $headers[] = 'Content-Type: application/json';
        $data = is_string($data) ? $data : json_encode($data, JSON_THROW_ON_ERROR);
        return $this->_exec($url, 'POST', $data, $headers);
    }

    public function postJson(
        string $url,
        mixed  $data = [],
        array  $headers = []
    ): CurlResponseDTO
    {
        $headers[] = 'Content-Type: application/json';
        $data = is_string($data) ? $data : json_encode($data, JSON_THROW_ON_ERROR);

        return $this->_exec(
            $url,
            'POST',
            $data,
            $headers
        );
    }
}