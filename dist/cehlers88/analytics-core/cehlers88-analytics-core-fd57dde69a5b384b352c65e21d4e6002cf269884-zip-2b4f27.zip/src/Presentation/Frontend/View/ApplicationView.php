<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;

/** View representation of an Application entity. */
class ApplicationView implements ViewInterface
{
    public BadgeDTO $badge;

    public function __construct(
        public int    $id,
        public string $name,
        public string $color
    )
    {
        $this->badge = new BadgeDTO();
        $this->badge->label = $this->name;
        $this->badge->cssClass = 'application';
    }
}