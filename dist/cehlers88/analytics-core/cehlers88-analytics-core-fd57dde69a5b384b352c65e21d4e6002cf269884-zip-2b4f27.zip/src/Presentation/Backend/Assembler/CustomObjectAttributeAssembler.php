<?php

namespace Cehlers88\AnalyticsCore\Presentation\Backend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Assembler\AssembledInterface;
use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectAttributeJson;
use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectJson;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;

class CustomObjectAttributeAssembler extends AbstractAssembler
{

    /**
     * @param CustomEntityAttribute $entity
     */
    public function assembleJson(EntityInterface|AbstractCustomObject $entity): AssembledInterface
    {
        $name = $entity->getName();

        $json = new CustomObjectAttributeJson(
            $entity->getId(),
            $name,
            $entity->getValue()
        );

        foreach ($entity->getMonitorings() as $monitoring) {
            $statistic = $monitoring->getStatistic();
            $statisticDetails = empty($statistic) ? [] : $statistic->getDetails();
            $options = empty($statisticDetails) ? [] : $statisticDetails['options'];
            $statisticValues = [];
            if (
                !empty($statisticDetails) &&
                isset($options['monitoredAttribute'])
            ) {

                $statisticValues = $statisticDetails[$options['monitoredAttribute']];
            }

            $json->monitorings[] = [
                'id' => $monitoring->getId(),
                'interval' => $monitoring->getRunInterval(),
                'statistics' => $statisticValues,
                'timestamps' => self::alignTimestamps($statisticDetails['timestamp'] ?? [], is_array($statisticValues) ? count($statisticValues) : 0),
            ];
        }

        return $json;
    }

    /**
     * One timestamp per statistic value, aligned from the end (the newest values
     * are the last ones in both lists). `0` marks a value that was never measured -
     * `Monitoring::run()` pads both lists with it up to the configured length.
     */
    private static function alignTimestamps(mixed $timestamps, int $count): array
    {
        if (!is_array($timestamps) || $count === 0) {
            return [];
        }
        $timestamps = array_map('intval', array_values(array_slice($timestamps, -$count)));

        return array_merge(array_fill(0, $count - count($timestamps), 0), $timestamps);
    }

    public function canHandle(string $className): bool
    {
        return $className === CustomEntityAttribute::class;
    }
}