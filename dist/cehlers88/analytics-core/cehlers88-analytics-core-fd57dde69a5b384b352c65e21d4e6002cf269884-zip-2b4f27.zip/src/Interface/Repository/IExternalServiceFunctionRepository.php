<?php

namespace Cehlers88\AnalyticsCore\Interface\Repository;

use Cehlers88\AnalyticsCore\Entity\ExternalServiceFunction;

interface IExternalServiceFunctionRepository
{
    public function findOneByServiceAndName(string $serviceName, string $functionName): ?ExternalServiceFunction;
}
