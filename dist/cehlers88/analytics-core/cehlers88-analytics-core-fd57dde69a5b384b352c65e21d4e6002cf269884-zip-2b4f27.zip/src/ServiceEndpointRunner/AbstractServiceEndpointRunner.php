<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 06.09.2024
 * Time: 03:25
 */

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\DTO\ValidationResultDTO;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Security\Doorman;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Symfony\Component\HttpFoundation\Exception\JsonException;
use Symfony\Component\HttpFoundation\Request;

abstract class AbstractServiceEndpointRunner implements ServiceEndpointRunnerInterface
{
    /** The answers runEndpoint() gives - EndpointResponseExamples builds its examples out of them. */
    public const PERMISSION_DENIED_MESSAGE = 'Permission denied';

    protected bool $_hasError = false;
    protected ?string $errorMessage = null;
    protected ?User $user = null;
    protected ?Doorman $doorman = null;

    private array $rawEndpoints = [];

    /** @var EndpointDefinitionDTO[]|null */
    private ?array $endpointDefinitions = null;

    /**
     * Whether one of the endpoint's definitions takes the request's method.
     * Which variant it reaches is decided in runEndpoint(), so a request that
     * matches no variant gets an answer saying so instead of a 404.
     */
    public function canHandle(string $endpoint, Request $request): bool
    {
        return count($this->getEndpointCandidates($endpoint, $request->getMethod())) > 0;
    }

    /**
     * Every definition the endpoint name (or alias) and the method lead to -
     * more than one when the endpoint has variants.
     *
     * @return EndpointDefinitionDTO[]
     */
    public function getEndpointCandidates(string $nameOrAlias, string $method): array
    {
        return array_values(array_filter(
            $this->getEndpointDefinitions(),
            static fn(EndpointDefinitionDTO $definition): bool => $definition->answersTo($nameOrAlias) && $definition->allowsMethod($method)
        ));
    }

    final public function getEndpointDefinitions(): array
    {
        if (is_null($this->endpointDefinitions)) {
            $this->_generateEndpointDefinitions();
        }
        return $this->endpointDefinitions;
    }

    private function _generateEndpointDefinitions(): void
    {
        $this->endpointDefinitions = [];

        $endpoints = $this->getEndpoints();
        if (is_string($endpoints)) {
            $endpoints = [$endpoints];
        }

        $namePrefix = empty($this->getBundleName()) ? '' : $this->getBundleName() . '.';

        foreach ($endpoints as $endpoint) {
            if (is_string($endpoint)) {
                $dto = new EndpointDefinitionDTO();
                $dto->name = $endpoint;
                $dto->methods = ['GET', 'POST'];
            } else if ($endpoint instanceof EndpointDefinitionDTO) {
                $dto = $endpoint;
            } else {
                throw new \InvalidArgumentException('Invalid endpoint definition');
            }

            $dto->name = $namePrefix . $dto->name;

            $this->endpointDefinitions[] = $dto;
        }

        $this->detectAmbiguousVariants();
    }

    public function getEndpoints(): mixed
    {
        $namespaceSplit = explode('\\', static::class);
        $selfName = end($namespaceSplit);

        return empty($this->rawEndpoints) ? [$selfName] : $this->rawEndpoints;
    }

    public function getBundleName(): string
    {
        return 'AnalyticsCore';
    }

    /**
     * Definitions registered twice for the same name and method are variants,
     * told apart by the parameters they share (EndpointVariantResolver). If a
     * request cannot tell them apart, the runner reports it as its error - the
     * service endpoint overview shows it - instead of throwing: the definitions
     * are read for every call to /api/se, and one runner must not take down all
     * the others.
     */
    private function detectAmbiguousVariants(): void
    {
        foreach (EndpointVariantResolver::groupByName($this->endpointDefinitions) as $variants) {
            $ambiguity = EndpointVariantResolver::findAmbiguityPerMethod($variants);
            if ($ambiguity !== null) {
                $this->setError($ambiguity);
                return;
            }
        }
    }

    public function setError(?string $errorMessage = null): AbstractServiceEndpointRunner
    {
        $this->_hasError = !is_null($errorMessage);
        $this->errorMessage = $errorMessage;
        return $this;
    }

    public function runEndpoint(string $endpointName, Request $request): ServiceEndpointRunnerResultDTO
    {
        $endpointDefinition = $this->resolveEndpointDefinition($endpointName, $request);
        $permissionInfo = $this->checkUserIsAllowedToRunEndpoint([
            ...$this->getRequiredRoles(),
            ...$endpointDefinition?->requiredRoles ?? []
        ]);

        if (!$permissionInfo['isAllowed']) {
            $errorMessage = self::PERMISSION_DENIED_MESSAGE;
            if (!empty($permissionInfo['message'])) {
                $errorMessage .= ': ' . $permissionInfo['message'];
            }

            $this->setError($errorMessage);
            return ServiceEndpointRunnerResultDTO::createError($errorMessage, 401);
        }

        $conflict = $this->findNeedleConflict($endpointName, $request);
        if ($conflict !== null) {
            $this->setError($conflict);
            return ServiceEndpointRunnerResultDTO::createError($conflict, 400);
        }

        if ($endpointDefinition === null) {
            $errorMessage = EndpointVariantResolver::describeUnmatched(
                $endpointName,
                $this->getEndpointCandidates($endpointName, $request->getMethod())
            );
            $this->setError($errorMessage);
            return ServiceEndpointRunnerResultDTO::createError($errorMessage, 400);
        }

        $validationResult = $this->validate($endpointName, $request);
        if (!$validationResult->isValid) {
            return ServiceEndpointRunnerResultDTO::createError(self::invalidMessage($validationResult->message));
        }

        try {
            $runnerResult = $this->handleRequest($endpointName, $request);
            return $runnerResult;
        } catch (\Exception $e) {
            $this->setError($e->getMessage());
        }

        return ServiceEndpointRunnerResultDTO::createError(self::internalErrorMessage((string)$this->errorMessage), 500);
    }

    /**
     * The definition the request reaches, deciding between the variants of the
     * endpoint by the values the request brings; null if it reaches none.
     * A runner that overrides handleRequest() asks here which variant it serves.
     */
    public function resolveEndpointDefinition(string $nameOrAlias, Request $request): ?EndpointDefinitionDTO
    {
        return EndpointVariantResolver::resolve(
            $this->getEndpointCandidates($nameOrAlias, $request->getMethod()),
            $this->getRequestData($request)
        );
    }

    /**
     * The values a request brings. The query string counts for every method, so
     * a variant can be picked by it (POST .../zip?action=act1); the body wins
     * where both carry a value - except for a needle, see findNeedleConflict().
     */
    protected function getRequestData(Request $request): array
    {
        return array_replace($request->query->all(), $this->getBodyData($request));
    }

    /**
     * Why the request cannot say which variant it means: a needle that the query
     * string and the body both carry, with different values. Letting the body win
     * silently would run a variant nobody asked for - typically a url with
     * ?action=act1 while the body still holds action=act2.
     */
    public function findNeedleConflict(string $nameOrAlias, Request $request): ?string
    {
        $candidates = $this->getEndpointCandidates($nameOrAlias, $request->getMethod());
        $query = $request->query->all();
        $body = $this->getBodyData($request);

        foreach (EndpointVariantResolver::discriminatorNames($candidates) as $name) {
            if (
                array_key_exists($name, $query) && array_key_exists($name, $body)
                && EndpointVariantResolver::normalize($query[$name]) !== EndpointVariantResolver::normalize($body[$name])
            ) {
                return EndpointVariantResolver::describeConflict($name, $query[$name], $body[$name]);
            }
        }

        return null;
    }

    /**
     * The form or json body - nothing for a GET request. Files sent with a form
     * are values like the other fields (UploadedFile objects), so a handler gets
     * them, and a required parameter can be one.
     */
    private function getBodyData(Request $request): array
    {
        if ($request->isMethod('GET')) {
            return [];
        }

        $body = $request->request->all();
        if ($body === [] && $request->files->count() === 0 && $request->getContent() !== '') {
            try {
                $body = $request->toArray();
            } catch (JsonException) {
                // neither a form nor json - nothing that could be read as values
            }
        }

        return array_replace($body, $request->files->all());
    }

    private function checkUserIsAllowedToRunEndpoint(array $requiredRoles): array
    {
        $resultInfo = [
            //'isAllowed' => false,
            'message' => '',
            'reason' => ''
        ];

        if (count($requiredRoles) === 0) {
            $resultInfo['isAllowed'] = true;
            return $resultInfo;
        }

        $resultInfo['isAllowed'] = $this->doorman->checkPermission($requiredRoles);
        $resultInfo['message'] = implode(', ', $this->doorman->getMessages());
        $resultInfo['reason'] = implode(', ', $this->doorman->getReasons());

        return $resultInfo;
    }

    public function getRequiredRoles(): array
    {
        return [
            RoleDTO::create('AUTHENTICATED_USER')
        ];
    }

    public function validate(string $endpointName, Request $request): ValidationResultDTO
    {
        $endpointDefinition = $this->resolveEndpointDefinition($endpointName, $request);
        if ($endpointDefinition === null) {
            return ValidationResultDTO::create(false, 'Endpoint not found');
        }

        $requestData = $this->getRequestData($request);
        foreach ($endpointDefinition->parameters as $parameter) {
            if ($parameter->isOptional) continue;
            if (!array_key_exists($parameter->name, $requestData)) return ValidationResultDTO::create(false, self::missingParameterMessage($parameter->name));
        }

        return ValidationResultDTO::create(true);
    }

    public static function missingParameterMessage(string $parameterName): string
    {
        return 'Missing parameter \'' . $parameterName . '\'';
    }

    public static function invalidMessage(?string $validationMessage): string
    {
        return 'Invalid' . (!empty($validationMessage) ? ': ' . $validationMessage : '');
    }

    /**
     * Hands the request to the handler of the definition it reaches. The
     * handler gets the request values and, as second argument, that definition -
     * so one handler can serve several variants.
     */
    public function handleRequest(string $endpointName, Request $request): ServiceEndpointRunnerResultDTO
    {
        $endpointDefinition = $this->resolveEndpointDefinition($endpointName, $request);
        if ($endpointDefinition === null) {
            return ServiceEndpointRunnerResultDTO::createError('Not implemented');
        }
        if (!is_callable($endpointDefinition->handler)) {
            // say which variant was reached - with variants, the one that has no
            // handler is rarely the one the caller meant
            $candidates = $this->getEndpointCandidates($endpointName, $request->getMethod());
            $needle = EndpointVariantResolver::describeValues(EndpointVariantResolver::discriminatorValues(
                $endpointDefinition,
                EndpointVariantResolver::discriminatorNames($candidates)
            ));

            return ServiceEndpointRunnerResultDTO::createError(sprintf(
                'Not implemented: endpoint \'%s\'%s has no handler',
                $endpointDefinition->name,
                $needle === '' ? '' : ' (' . $needle . ')'
            ));
        }

        return call_user_func($endpointDefinition->handler, $this->getRequestData($request), $endpointDefinition);
    }

    public static function internalErrorMessage(string $errorMessage): string
    {
        return 'Internal Server Error (' . $errorMessage . ')';
    }

    public function setDoorman(Doorman $doorman): ServiceEndpointRunnerInterface
    {
        $this->doorman = $doorman;
        $this->setUser($doorman->getUser());
        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): AbstractServiceEndpointRunner
    {
        $this->user = $user;
        return $this;
    }

    public function getDescription(string $endpointName, array $methods): string
    {
        foreach ($this->getEndpointDefinitions() as $endpointDefinition) {
            if ($endpointDefinition->name === $endpointName) {
                foreach ($methods as $method) {
                    if (in_array($method, $endpointDefinition->methods)) {
                        return $endpointDefinition->description;
                    }
                }
            }
        }
        return '';
    }

    public function getErrorMessage(): ?string
    {
        return $this->errorMessage;
    }

    public function hasError(): bool
    {
        return $this->_hasError;
    }

    protected function registerEndpoint(EndpointDefinitionDTO $endpointDefinition): AbstractServiceEndpointRunner
    {
        $this->rawEndpoints[] = $endpointDefinition;
        return $this;
    }
}
