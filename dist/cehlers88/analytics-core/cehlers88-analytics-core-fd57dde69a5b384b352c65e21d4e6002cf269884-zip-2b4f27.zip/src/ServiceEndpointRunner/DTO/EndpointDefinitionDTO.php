<?php

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;

class EndpointDefinitionDTO
{
    public string $description = '';
    public string $name = '';
    public array $aliases = [];

    /** @var string[] */
    public array $methods = [];

    /** @var PropertyDTO[] */
    public array $parameters = [];

    /** @var RoleDTO[] */
    public array $requiredRoles = [];

    public mixed $handler = null;

    /**
     * What a successful call answers, as shown in the service endpoint overview.
     * Not declared, the overview derives one (EndpointResponseExamples).
     */
    public ?ServiceEndpointRunnerResultDTO $successExample = null;

    /** What a failed call answers - see $successExample. */
    public ?ServiceEndpointRunnerResultDTO $errorExample = null;

    /**
     * Creates a new EndpointDefinitionDTO
     *
     * @param string $name
     * @param string[] $methods
     * @param PropertyDTO[] $parameters
     * @param RoleDTO[] $requiredRoles
     * @param string $description
     * @param mixed $handler
     */
    public static function create(
        string $name,
        array  $methods,
        array  $parameters = [],
        array  $requiredRoles = [],
        string $description = '',
        mixed  $handler = null
    ): EndpointDefinitionDTO
    {
        $dto = new self();

        $dto->name = $name;
        $dto->methods = $methods;
        $dto->parameters = $parameters;
        $dto->requiredRoles = $requiredRoles;
        $dto->description = $description;
        $dto->handler = $handler;

        return $dto;
    }

    /** Declares the data (and message) a successful call answers with. */
    public function withSuccessExample(mixed $data, string $message = ''): static
    {
        $this->successExample = ServiceEndpointRunnerResultDTO::createSuccess($data, $message);

        return $this;
    }

    /** Declares what a failed call answers with. */
    public function withErrorExample(string $message, int $statusCode = 500, mixed $data = null): static
    {
        $this->errorExample = ServiceEndpointRunnerResultDTO::createError($message, $statusCode);
        $this->errorExample->data = $data;

        return $this;
    }

    /** Whether the endpoint is called by the given name, directly or by one of its aliases. */
    public function answersTo(string $nameOrAlias): bool
    {
        return $this->name === $nameOrAlias || in_array($nameOrAlias, $this->aliases, true);
    }

    public function allowsMethod(string $method): bool
    {
        return in_array(strtoupper($method), array_map('strtoupper', $this->methods), true);
    }

    public function getParameter(string $name): ?PropertyDTO
    {
        foreach ($this->parameters as $parameter) {
            if ($parameter->name === $name) {
                return $parameter;
            }
        }

        return null;
    }

    /** @return string[] */
    public function getParameterNames(): array
    {
        return array_values(array_map(static fn(PropertyDTO $parameter): string => $parameter->name, $this->parameters));
    }
}
