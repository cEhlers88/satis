<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;

/**
 * An example of a successful and of a failed answer for an endpoint definition,
 * as the service endpoint overview shows them.
 *
 * A definition may declare both (EndpointDefinitionDTO::withSuccessExample() /
 * withErrorExample()). What it does not declare is derived: the error from the
 * first check of AbstractServiceEndpointRunner::runEndpoint() the definition can
 * fail, with the very message that check answers; the success as the envelope
 * without data, since only the handler knows what it returns.
 */
final class EndpointResponseExamples
{
    public const REASON_DECLARED = 'declared';
    public const REASON_SUCCESS_UNDECLARED = 'success_undeclared';
    public const REASON_VARIANT = 'variant';
    public const REASON_PARAMETER = 'parameter';
    public const REASON_PERMISSION = 'permission';
    public const REASON_GENERIC = 'generic';

    /**
     * @param EndpointDefinitionDTO[] $siblings every definition registered under the same name,
     *                                          the definition itself included
     *
     * @return array{
     *     success: array{result: ServiceEndpointRunnerResultDTO, declared: bool, reason: string},
     *     error: array{result: ServiceEndpointRunnerResultDTO, declared: bool, reason: string, parameter: ?string}
     * }
     */
    public static function forDefinition(
        ServiceEndpointRunnerInterface $runner,
        EndpointDefinitionDTO          $definition,
        array                          $siblings = []
    ): array
    {
        return [
            'success' => $definition->successExample !== null
                ? self::example($definition->successExample, self::REASON_DECLARED)
                : self::example(ServiceEndpointRunnerResultDTO::createSuccess(null), self::REASON_SUCCESS_UNDECLARED, false),
            'error' => $definition->errorExample !== null
                ? self::example($definition->errorExample, self::REASON_DECLARED)
                : self::deriveError($runner, $definition, $siblings),
        ];
    }

    private static function deriveError(
        ServiceEndpointRunnerInterface $runner,
        EndpointDefinitionDTO          $definition,
        array                          $siblings
    ): array
    {
        $competing = array_values(array_filter(
            $siblings,
            static fn(EndpointDefinitionDTO $sibling): bool => array_intersect(
                array_map('strtoupper', $sibling->methods),
                array_map('strtoupper', $definition->methods)
            ) !== []
        ));
        if (count($competing) > 1 && EndpointVariantResolver::discriminatorNames($competing) !== []) {
            return self::example(ServiceEndpointRunnerResultDTO::createError(
                EndpointVariantResolver::describeUnmatched($definition->name, $competing),
                400
            ), self::REASON_VARIANT, false);
        }

        // The messages below are what AbstractServiceEndpointRunner answers - a runner
        // with its own checks answers something else, so it only gets the generic one.
        if (!$runner instanceof AbstractServiceEndpointRunner) {
            return self::genericError();
        }

        if (!self::overrides($runner, 'validate')) {
            foreach ($definition->parameters as $parameter) {
                if (!$parameter->isOptional) {
                    return self::example(ServiceEndpointRunnerResultDTO::createError(
                        AbstractServiceEndpointRunner::invalidMessage(
                            AbstractServiceEndpointRunner::missingParameterMessage($parameter->name)
                        )
                    ), self::REASON_PARAMETER, false, $parameter->name);
                }
            }
        }

        if ([...$runner->getRequiredRoles(), ...$definition->requiredRoles] !== []) {
            return self::example(ServiceEndpointRunnerResultDTO::createError(
                AbstractServiceEndpointRunner::PERMISSION_DENIED_MESSAGE,
                401
            ), self::REASON_PERMISSION, false);
        }

        return self::genericError();
    }

    private static function genericError(): array
    {
        return self::example(ServiceEndpointRunnerResultDTO::createError(
            AbstractServiceEndpointRunner::internalErrorMessage('…'),
            500
        ), self::REASON_GENERIC, false);
    }

    private static function overrides(AbstractServiceEndpointRunner $runner, string $method): bool
    {
        return new \ReflectionMethod($runner, $method)->getDeclaringClass()->getName() !== AbstractServiceEndpointRunner::class;
    }

    private static function example(
        ServiceEndpointRunnerResultDTO $result,
        string                         $reason,
        bool                           $declared = true,
        ?string                        $parameter = null
    ): array
    {
        return ['result' => $result, 'declared' => $declared, 'reason' => $reason, 'parameter' => $parameter];
    }
}
