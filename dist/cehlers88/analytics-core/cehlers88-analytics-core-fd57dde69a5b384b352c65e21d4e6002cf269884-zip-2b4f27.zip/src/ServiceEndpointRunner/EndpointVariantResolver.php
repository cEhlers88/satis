<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;

/**
 * Tells the variants of an endpoint apart - several definitions a runner
 * registered under the same name for the same method.
 *
 * The parameters every variant declares serve as the needle: the value a
 * variant declares for them is the value a request has to bring to reach that
 * variant, in the body or in the query string (?action=act1). A parameter that
 * all variants declare with the same value tells them nothing apart, so it is
 * an ordinary parameter and no needle.
 */
final class EndpointVariantResolver
{
    /**
     * @param EndpointDefinitionDTO[] $definitions
     *
     * @return array<string, EndpointDefinitionDTO[]> the definitions by name, in registration order
     */
    public static function groupByName(array $definitions): array
    {
        $groups = [];
        foreach ($definitions as $definition) {
            $groups[$definition->name][] = $definition;
        }

        return $groups;
    }

    /**
     * The names of the parameters that tell the given variants apart.
     *
     * @param EndpointDefinitionDTO[] $variants
     *
     * @return string[]
     */
    public static function discriminatorNames(array $variants): array
    {
        $variants = array_values($variants);
        if (count($variants) < 2) {
            return [];
        }

        $shared = null;
        foreach ($variants as $variant) {
            $names = $variant->getParameterNames();
            $shared = $shared === null ? $names : array_values(array_intersect($shared, $names));
        }

        return array_values(array_filter(
            $shared ?? [],
            static function (string $name) use ($variants): bool {
                $values = array_map(
                    static fn(EndpointDefinitionDTO $variant): string => self::normalize($variant->getParameter($name)?->value),
                    $variants
                );

                return count(array_unique($values)) > 1;
            }
        ));
    }

    /**
     * The needle values of one variant.
     *
     * @param string[] $discriminatorNames
     *
     * @return array<string, mixed>
     */
    public static function discriminatorValues(EndpointDefinitionDTO $variant, array $discriminatorNames): array
    {
        $values = [];
        foreach ($discriminatorNames as $name) {
            $values[$name] = $variant->getParameter($name)?->value;
        }

        return $values;
    }

    /**
     * The variant the request data points at, or null when it points at none.
     * A single candidate needs no needle and is always the one.
     *
     * @param EndpointDefinitionDTO[] $candidates
     */
    public static function resolve(array $candidates, array $requestData): ?EndpointDefinitionDTO
    {
        $candidates = array_values($candidates);
        if (count($candidates) <= 1) {
            return $candidates[0] ?? null;
        }

        $discriminatorNames = self::discriminatorNames($candidates);
        if ($discriminatorNames === []) {
            // Nothing tells them apart - see findAmbiguity(); the first one keeps
            // the endpoint reachable at all.
            return $candidates[0];
        }

        foreach ($candidates as $candidate) {
            foreach (self::discriminatorValues($candidate, $discriminatorNames) as $name => $value) {
                if (!array_key_exists($name, $requestData) || self::normalize($requestData[$name]) !== self::normalize($value)) {
                    continue 2;
                }
            }

            return $candidate;
        }

        return null;
    }

    /**
     * Why the given variants cannot be told apart, or null when they can.
     *
     * @param EndpointDefinitionDTO[] $variants
     */
    public static function findAmbiguity(array $variants): ?string
    {
        $variants = array_values($variants);
        if (count($variants) < 2) {
            return null;
        }

        $discriminatorNames = self::discriminatorNames($variants);
        if ($discriminatorNames === []) {
            return sprintf(
                'The %d definitions of endpoint "%s" share no parameter with differing values, so a request cannot tell them apart',
                count($variants),
                $variants[0]->name
            );
        }

        $seen = [];
        foreach ($variants as $variant) {
            $signature = self::describeValues(self::discriminatorValues($variant, $discriminatorNames));
            if (isset($seen[$signature])) {
                return sprintf('Endpoint "%s" is defined twice for %s', $variant->name, $signature);
            }
            $seen[$signature] = true;
        }

        return null;
    }

    /**
     * Like findAmbiguity(), for the definitions of one endpoint name: only those
     * that take the same method compete for a request.
     *
     * @param EndpointDefinitionDTO[] $definitions
     */
    public static function findAmbiguityPerMethod(array $definitions): ?string
    {
        if (count($definitions) < 2) {
            return null;
        }

        $methods = array_unique(array_merge(...array_map(
            static fn(EndpointDefinitionDTO $definition): array => array_map('strtoupper', $definition->methods),
            array_values($definitions)
        )));

        foreach ($methods as $method) {
            $ambiguity = self::findAmbiguity(array_filter(
                $definitions,
                static fn(EndpointDefinitionDTO $definition): bool => $definition->allowsMethod($method)
            ));
            if ($ambiguity !== null) {
                return $ambiguity . ' (' . $method . ')';
            }
        }

        return null;
    }

    /**
     * The answer to a request whose needle matches none of the candidates.
     *
     * @param EndpointDefinitionDTO[] $candidates
     */
    public static function describeUnmatched(string $nameOrAlias, array $candidates): string
    {
        $discriminatorNames = self::discriminatorNames($candidates);

        return sprintf(
            'No variant of endpoint \'%s\' matches the request, expected one of: %s',
            $nameOrAlias,
            implode(' | ', array_map(
                static fn(EndpointDefinitionDTO $candidate): string => self::describeValues(
                    self::discriminatorValues($candidate, $discriminatorNames)
                ),
                array_values($candidates)
            ))
        );
    }

    /** The answer to a request that names a needle differently in query string and body. */
    public static function describeConflict(string $name, mixed $queryValue, mixed $bodyValue): string
    {
        return sprintf(
            'Conflicting values for \'%s\': \'%s\' in the query string, \'%s\' in the body',
            $name,
            self::normalize($queryValue),
            self::normalize($bodyValue)
        );
    }

    /**
     * The needle values as they would be sent, e.g. "action=act1&mode=fast".
     *
     * @param array<string, mixed> $values
     */
    public static function describeValues(array $values): string
    {
        $parts = [];
        foreach ($values as $name => $value) {
            $parts[] = $name . '=' . self::normalize($value);
        }

        return implode('&', $parts);
    }

    /**
     * A request brings its values as text (query, form) or typed (json), a
     * definition declares them typed - both are compared as the text they are
     * sent as.
     */
    public static function normalize(mixed $value): string
    {
        return match (true) {
            is_null($value) => '',
            is_bool($value) => $value ? 'true' : 'false',
            is_scalar($value) => (string)$value,
            default => (string)json_encode($value),
        };
    }
}
