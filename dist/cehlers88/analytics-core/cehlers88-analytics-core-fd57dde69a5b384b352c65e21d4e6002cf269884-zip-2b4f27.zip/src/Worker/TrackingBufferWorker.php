<?php

namespace Cehlers88\AnalyticsCore\Worker;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;

class TrackingBufferWorker extends AbstractWorker
{
    public function __construct()
    {
        //$this->addProperty(PropertyDTO::create('criteria', [], 'array'));
        //$this->addProperty(PropertyDTO::create('order', [], 'array', true));
        $this->addProperty(PropertyDTO::create('limit', 1000, 'int', true));
        $this->addProperty(PropertyDTO::create('offset', 0, 'int', true));
    }

    public function getWorkingObjects(): array
    {
        return $this->trackingBufferRepository->findBy(
            $this->getPropertyValue('criteria'),
            $this->getPropertyValue('order'),
            $this->getPropertyValue('limit'),
            $this->getPropertyValue('offset')
        );
    }
}