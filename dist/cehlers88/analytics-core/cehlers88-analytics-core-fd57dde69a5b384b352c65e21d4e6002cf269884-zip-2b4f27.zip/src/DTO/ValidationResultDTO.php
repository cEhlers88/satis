<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

/**
 * Data transfer object representing a validation result.
 */
class ValidationResultDTO extends DTO
{
    public bool $isValid = true;
    public string $message = '';

    public static function create(bool $isValid, string $message = ''): ValidationResultDTO
    {
        $result = new ValidationResultDTO();
        $result->isValid = $isValid;
        $result->message = $message;
        return $result;
    }
}