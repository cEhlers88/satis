# Changelog

## [1.44.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.43.0...v1.44.0) (2026-10-06)


### Features

* **tools:** compare two documents in the JSON Workbench ([#218](https://github.com/cEhlers88/AnalyticsCore/issues/218)) ([8ecb9d7](https://github.com/cEhlers88/AnalyticsCore/commit/8ecb9d700599d4d2845988730ab55808e349cd18))


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.3.6 ([#213](https://github.com/cEhlers88/AnalyticsCore/issues/213)) ([0dafae8](https://github.com/cEhlers88/AnalyticsCore/commit/0dafae8355df209cc57f1fc2328fdd655da3a31e))
* **deps:** update dependency phpunit/phpunit to v13.4.1 ([#217](https://github.com/cEhlers88/AnalyticsCore/issues/217)) ([2d2ac34](https://github.com/cEhlers88/AnalyticsCore/commit/2d2ac34c519052c28f23f95ff08dca6a9f03dddb))

## [1.43.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.42.9...v1.43.0) (2026-09-29)


### Features

* ValueMapper for external service responses ([#212](https://github.com/cEhlers88/AnalyticsCore/issues/212)) ([fda6bef](https://github.com/cEhlers88/AnalyticsCore/commit/fda6bef2b75acfb6be76afe77344bdf7c0cbb9a9))


### Miscellaneous Chores

* Add timestamp alignment for monitoring statistics in API response ([#210](https://github.com/cEhlers88/AnalyticsCore/issues/210)) ([f7a1165](https://github.com/cEhlers88/AnalyticsCore/commit/f7a1165b0a1eb899336d5a9a9f3b8f6d6d5afca5))

## [1.42.9](https://github.com/cEhlers88/AnalyticsCore/compare/v1.42.8...v1.42.9) (2026-09-27)


### Miscellaneous Chores

* add `ConfigurableValueMapper` with support for configurable value transformations; implement `ValueMapperConfiguration`, `AbstractValueMapper`, and `ValueMapperInterface`; update tests and version to `1.42.7` ([ca319f1](https://github.com/cEhlers88/AnalyticsCore/commit/ca319f12ba7a04afd24578b6bd6c73987b0b4f04))
* **deps:** update dependency doctrine/orm to v3.7.2 ([#206](https://github.com/cEhlers88/AnalyticsCore/issues/206)) ([857aa72](https://github.com/cEhlers88/AnalyticsCore/commit/857aa72ad9373598c637a0ae335d798e2b15c5c5))
* introduce `EndpointVariantResolver` and associated utilities for endpoint resolution logic; extend `EndpointDefinitionDTO` with response examples; enhance `Doorman` with user reset functionality; add unit tests for endpoint runner and resolver ([068cc07](https://github.com/cEhlers88/AnalyticsCore/commit/068cc07cc556cc4b241cb9bc0ac820deecc2a1a5))

## [1.42.8](https://github.com/cEhlers88/AnalyticsCore/compare/v1.42.7...v1.42.8) (2026-09-26)


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.3.5 ([#207](https://github.com/cEhlers88/AnalyticsCore/issues/207)) ([73b7e40](https://github.com/cEhlers88/AnalyticsCore/commit/73b7e40a6271fdd5b14806dc07e98fc0762aabc7))
* replace inline buttons with `ribbon-menu` in `jsonWorkbench` and `commandConsole` templates; refactor JavaScript to handle `ribbon-action` events and update state management accordingly ([96a910a](https://github.com/cEhlers88/AnalyticsCore/commit/96a910acb9525cb69a1a914695611f6f27aca898))

## [1.42.7](https://github.com/cEhlers88/AnalyticsCore/compare/v1.42.6...v1.42.7) (2026-09-20)


### Miscellaneous Chores

* extend `User` entity with profile fields (`first_name`, `last_name`, `picture_path`), update methods for `id`, `roles`, and `default_route`; improve bug report UI and style templates; add tests for client visits, macros, and markdown rendering ([59162bd](https://github.com/cEhlers88/AnalyticsCore/commit/59162bd6027da24555291fc0999483e9bb8aeeaa))
* add the missing PHPUnit dev dependencies for Doctrine repository classes and Symfony `UploadedFile` support, and add the Symfony Messenger runtime dependency for `MessageBusInterface`

## [1.42.6](https://github.com/cEhlers88/AnalyticsCore/compare/v1.42.5...v1.42.6) (2026-09-20)


### Miscellaneous Chores

* introduce bug report modal, templates (`_list.html.twig`, `_detail.html.twig`, `modal.html.twig`), styles, and ENUM definitions (`eBugReportSeverity`, `eBugReportState`); add `BugReportRepository` and README updates ([0e0bf6c](https://github.com/cEhlers88/AnalyticsCore/commit/0e0bf6c3b3b56c57476adf9eea5e276a187ebdb1))

## [1.42.5](https://github.com/cEhlers88/AnalyticsCore/compare/v1.42.4...v1.42.5) (2026-09-19)


### Miscellaneous Chores

* add teaser SVG support with `getTeaserSvg` method; introduce changelog and tool collection events; implement `MarkdownRenderer` for Markdown rendering ([7f8869c](https://github.com/cEhlers88/AnalyticsCore/commit/7f8869c520a5f0ff89be324ccae52035e3111054))

## [1.42.4](https://github.com/cEhlers88/AnalyticsCore/compare/v1.42.3...v1.42.4) (2026-09-19)


### Miscellaneous Chores

* add `lastVisit` property to `Client` entity with getter, setter, and visit tracking; update `CheckIsFirstVisitJob` to set `lastVisit` ([e6ed5f5](https://github.com/cEhlers88/AnalyticsCore/commit/e6ed5f5c94b00721ce12d89ff1d28fdb4758d7db))

## [1.42.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.42.2...v1.42.3) (2026-09-17)


### Miscellaneous Chores

* add `UserGroup` entity and repository for group-based role management; document property UI configuration and macro property editing ([53d3e63](https://github.com/cEhlers88/AnalyticsCore/commit/53d3e63ed9d6b0abca03167a877db1a42c511413))
* **deps:** update dependency phpunit/phpunit to v13.3.4 ([#200](https://github.com/cEhlers88/AnalyticsCore/issues/200)) ([500953d](https://github.com/cEhlers88/AnalyticsCore/commit/500953ddd79e3b963078e1716028b4398bdcef5a))
* enhance role and group management for `User` entity; refactor configuration handling with improved buffer enrichment, context resolution, and stored variable management; add support for inherited roles, group membership, and new utility methods ([5e60f49](https://github.com/cEhlers88/AnalyticsCore/commit/5e60f49080f015a7ca28832b9ffa22a5c5c069cb))

## [1.42.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.42.1...v1.42.2) (2026-09-14)


### Bug Fixes

* **tests:** Decouple ExternalServiceExecutor tests from DoctrineBundle repository base class ([#199](https://github.com/cEhlers88/AnalyticsCore/issues/199)) ([9796c30](https://github.com/cEhlers88/AnalyticsCore/commit/9796c300c05563bacd41dde701f4109820766ed4))


### Miscellaneous Chores

* add `IExecutionAdapter` and `IExternalService` interfaces; integrate `ExternalServiceFunctionRepository` into `ExternalServiceExecutor` and update test mocks ([34b2205](https://github.com/cEhlers88/AnalyticsCore/commit/34b2205a1a1dc4657d419c5855ff086c31265700))
* improve executor state handling, worker cloning, and shared property management; add tests for `ExternalServiceExecutor` ([f87836c](https://github.com/cEhlers88/AnalyticsCore/commit/f87836cd5c7bb12f003913b4e00351b064e29205))

## [1.42.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.42.0...v1.42.1) (2026-09-13)


### Miscellaneous Chores

* add `resolveForMacro` method to `PropertyUiResolver` for macro property resolution and `aliases` method to `eConditionType` for alternate operator spellings ([7a14ab5](https://github.com/cEhlers88/AnalyticsCore/commit/7a14ab50ffa5fa1e5831e32acb002ceb2e70d008))

## [1.42.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.41.2...v1.42.0) (2026-09-13)


### Features

* **tools:** add the command console tool ([#195](https://github.com/cEhlers88/AnalyticsCore/issues/195)) ([14ad62b](https://github.com/cEhlers88/AnalyticsCore/commit/14ad62b5f1028bcf31dec0103263d5c3194df3d3))
* **tools:** add the JSON Workbench tool ([#196](https://github.com/cEhlers88/AnalyticsCore/issues/196)) ([990583e](https://github.com/cEhlers88/AnalyticsCore/commit/990583e16cdfc4061f9e2921d3b2d2d8266831f9))


### Miscellaneous Chores

* add `ApplicationActionsViewWidget`, extend `ApplicationAction` entity with new fields, update `ResultDTO` for static return type, and rename `GetCustomObjectStatisticsMacro` method ([5dcde19](https://github.com/cEhlers88/AnalyticsCore/commit/5dcde19072b81972be2e9f05084b5f437bb4ad95))
* add `ExternalService`, `ExternalServiceFunction`, and `ExternalServiceEntry` entities with associated repositories for advanced service handling ([b087a5f](https://github.com/cEhlers88/AnalyticsCore/commit/b087a5ffcc4770bb430307e8f2faae16c313d159))
* add `ExternalService`, `ExternalServiceFunction`, and `ExternalServiceEntry` entities with associated repositories for advanced service handling ([6acc076](https://github.com/cEhlers88/AnalyticsCore/commit/6acc076d335b1006d3e2932c9a12c618b0ccb2a9))
* add `ExternalServiceExecutor` for executing external service functions and configure `ExternalServiceProvider` with execution adapters ([340bf18](https://github.com/cEhlers88/AnalyticsCore/commit/340bf18089d31ec93b1df6046f3633226140f9d1))
* add `ExternalServiceProvider` to handle execution adapters and enhance external service integrations ([e042351](https://github.com/cEhlers88/AnalyticsCore/commit/e0423517645a21c6d74aa20eb069d171aecdc23a))
* add `GetCustomObjectStatisticsMacro` and enhance argument handling in `AbstractMacro` ([1a892c9](https://github.com/cEhlers88/AnalyticsCore/commit/1a892c98e0f2a4ed0ae8af3d1967db158340f785))
* add `save` method to `ApplicationActionRepository` for persisting actions with optional flush ([62c8216](https://github.com/cEhlers88/AnalyticsCore/commit/62c821659d3251cfd8a7bf00ce8e63d51d665e76))
* add `StartActionMacro` and `StopActionMacro` to support action state management within macros ([2764b14](https://github.com/cEhlers88/AnalyticsCore/commit/2764b14b7a310e471910c085ab4aa93056858856))
* enhance macro property handling with improved context management, new utility methods, and operator refactoring; introduce `PropertyUi` support for dynamic UI configuration ([214d96a](https://github.com/cEhlers88/AnalyticsCore/commit/214d96a15dc9da525f502fa30a7619c1744c28d2))
* improve executor error handling, logging, and configuration validation; integrate `ExternalServiceFunctionRepository` into `ExternalServiceExecutor` ([795e59d](https://github.com/cEhlers88/AnalyticsCore/commit/795e59d1dfb35978ec1c17a063b983708ddbe047))
* introduce property UI support, condition evaluation, and value helper mechanisms for enhanced macro editing functionality ([39d1e77](https://github.com/cEhlers88/AnalyticsCore/commit/39d1e77807fa992a186637a972603ea23668d66f))

## [1.41.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.41.1...v1.41.2) (2026-09-11)


### Miscellaneous Chores

* refactor error handling in workers and repositories, add new query methods, and update `TrackingBuffer` with fulltext indices ([24d6be6](https://github.com/cEhlers88/AnalyticsCore/commit/24d6be6e1aa364c7cc2551483f69934103d19d36))

## [1.41.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.41.0...v1.41.1) (2026-09-11)


## [1.41.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.40.1...v1.41.0) (2026-09-11)


### Features

* find and build observer messages from the outside ([#183](https://github.com/cEhlers88/AnalyticsCore/issues/183)) ([705bba1](https://github.com/cEhlers88/AnalyticsCore/commit/705bba1d808d142ee3fa01964cab4ae699e82a2d))
* let a property declare conditions on other properties ([#186](https://github.com/cEhlers88/AnalyticsCore/issues/186)) ([1e42a3e](https://github.com/cEhlers88/AnalyticsCore/commit/1e42a3e683212149cb7fe958753422f481b955f8))
* **presentation:** expose nested tracking buffers on the view ([#187](https://github.com/cEhlers88/AnalyticsCore/issues/187)) ([ee0898f](https://github.com/cEhlers88/AnalyticsCore/commit/ee0898f0e93c9c1e9dcc6dab49c830ebcc57f757))


### Miscellaneous Chores

* add support for parent-child relationships in `TrackingBuffer` and display hostname/IP in client tile template ([830619c](https://github.com/cEhlers88/AnalyticsCore/commit/830619c5e07ec3480421a7a51b0363b8b86550bf))
* **deps:** update dependency phpunit/phpunit to v13.3.2 ([#185](https://github.com/cEhlers88/AnalyticsCore/issues/185)) ([9f2b321](https://github.com/cEhlers88/AnalyticsCore/commit/9f2b3212821a8e9ed880d6c17601b7a8cc7275a5))
* **deps:** update dependency phpunit/phpunit to v13.3.3 ([#190](https://github.com/cEhlers88/AnalyticsCore/issues/190)) ([f14fb72](https://github.com/cEhlers88/AnalyticsCore/commit/f14fb728db53b9c7979408bec4dc97305d6e8a7f))
* **deps:** update dependency symfony/security-core to v8.1.6 ([#189](https://github.com/cEhlers88/AnalyticsCore/issues/189)) ([274fba6](https://github.com/cEhlers88/AnalyticsCore/commit/274fba66b1df009f37e358d861dde904564fd114))
* update `WorkersViewWidget` to support conditional property definitions for `viewType` and `source` ([3d35435](https://github.com/cEhlers88/AnalyticsCore/commit/3d35435b7f77bbfe6005e545ebb777c3dae60f76))

## [1.40.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.40.0...v1.40.1) (2026-08-27)


### Miscellaneous Chores

* add `getArgumentDefinitions` to `MonitoringRuleInterface` and implement argument validation logic in abstract and concrete rules ([4a6ece1](https://github.com/cEhlers88/AnalyticsCore/commit/4a6ece14a95052ffc11595db60acfa92228ba094))
* add tests for structured value normalization and fallback behavior in `WidgetSettings` ([bd7fe3b](https://github.com/cEhlers88/AnalyticsCore/commit/bd7fe3b6a7f0c8c3a103b1b572c7f7c18ece961c))

## [1.40.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.14...v1.40.0) (2026-08-26)


### Features

* **widget:** let widgets declare the settings they need ([#180](https://github.com/cEhlers88/AnalyticsCore/issues/180)) ([84db1a8](https://github.com/cEhlers88/AnalyticsCore/commit/84db1a8b32de53300ca8b9ca77914fb1aa994547))

## [1.39.14](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.13...v1.39.14) (2026-08-25)


### Miscellaneous Chores

* add `Dashboard` entity and associate it with `User` entity for dashboard management ([e3f30ee](https://github.com/cEhlers88/AnalyticsCore/commit/e3f30eecc4078c2255a544052c58336e3e2ed330))
* add `DashboardRepository` for managing `Dashboard` entity interactions ([f2669d0](https://github.com/cEhlers88/AnalyticsCore/commit/f2669d0288f7fd09a263981fe78f07b128be2938))
* add `group.html.twig` template for rendering grouped widgets with dynamic properties and styling ([8254762](https://github.com/cEhlers88/AnalyticsCore/commit/82547625986287a2b5a60fb8994520c4c9378a90))
* add `WidgetProvider` for managing widgets, access control, rendering, and template resolution ([320cb3f](https://github.com/cEhlers88/AnalyticsCore/commit/320cb3f5c6f284a597c5b96a464452f23a6e580b))
* add abstract `Widget` and `LoginWidget` classes for standardized widget structure and login-specific preload placeholders ([4f83573](https://github.com/cEhlers88/AnalyticsCore/commit/4f83573c3ffa7d88a050617a27eca22ef61dbce5))
* add widget classes (`CustomObjectWidget`, `ReportViewWidget`, `SetupWidget`, `LogViewWidget`) implementing `AbstractWidget` for modular functionality ([90ec9a1](https://github.com/cEhlers88/AnalyticsCore/commit/90ec9a19f7efab4c70409074528fb3f9f4738073))
* add widget templates (`customObject.html.twig`, `logView.html.twig`, `login.html.twig`, `reportView.html.twig`, `setup.html.twig`) for rendering modular UI components ([0f71389](https://github.com/cEhlers88/AnalyticsCore/commit/0f71389067ed3c94c8834986c0796e7367c824fe))
* inject `WidgetProvider` and update namespace in `SetupWidget` for consistency and functionality ([13f043e](https://github.com/cEhlers88/AnalyticsCore/commit/13f043eada48a73b7847f0ca26de13b5f76e73e9))
* refactor `User` and `Dashboard` entities, add `GroupWidget`, enhance `LoginWidget`, and remove unused `DashboardTileServerSideRenderer` ([88d1075](https://github.com/cEhlers88/AnalyticsCore/commit/88d107571f746624e868805ee80bdae48b42d0a9))
* tag `AbstractWidget` with `widget` for consistent service tagging ([0f66080](https://github.com/cEhlers88/AnalyticsCore/commit/0f66080d7b73113e2b489803449c792d5f583eb0))

## [1.39.13](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.12...v1.39.13) (2026-08-22)


### Miscellaneous Chores

* enhance `CustomObjectAssembler` to handle `attributeStdObj` for standardized attribute mapping and streamline child object assembly ([3f5c8ef](https://github.com/cEhlers88/AnalyticsCore/commit/3f5c8efaafa22cfda5fbd6ad2598c1e81d27e31d))

## [1.39.12](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.11...v1.39.12) (2026-08-20)


### Miscellaneous Chores

* add `config` property to `CustomEntity` with getter and setter methods ([b47c8ea](https://github.com/cEhlers88/AnalyticsCore/commit/b47c8eac8115b69b31519b568862628681ee7ea8))
* add `CustomObjectAttributeAssembler` and `CustomObjectAttributeJson`, enhance `CustomObjectAssembler` and `CustomObjectView` with attribute monitoring and configuration support ([2b89c90](https://github.com/cEhlers88/AnalyticsCore/commit/2b89c907a5a7668a503443e740c0ce84af189a0c))
* add `setConfig` method to `AbstractCustomObject` for updating entity configuration ([77df87e](https://github.com/cEhlers88/AnalyticsCore/commit/77df87ea90cb1bdd1823350ccc62b47ce94b06f5))
* add `tile.html.twig` template placeholder ([64205c0](https://github.com/cEhlers88/AnalyticsCore/commit/64205c01c0aa5b49f26353402339cd2c344e9d89))
* add `titleBadgeText` property to `CustomObjectJson` for enhanced title handling ([9e577d2](https://github.com/cEhlers88/AnalyticsCore/commit/9e577d27761c6a6a0e5459085f84bfa3e4986837))
* add `UserInteractionResolveMessage` class to handle user interaction resolution messages ([07a6cdd](https://github.com/cEhlers88/AnalyticsCore/commit/07a6cdd04e98d261b696dc97e2d9a140e061951c))
* add error handling for `runMonitoringRules` in `CustomObjectProvider` to capture and aggregate exceptions ([581a6b2](https://github.com/cEhlers88/AnalyticsCore/commit/581a6b2f64df3ae2b58e98e42c60ded629be1d61))
* add exception annotations to `CustomObjectProvider` methods for better error documentation ([ecd2fd6](https://github.com/cEhlers88/AnalyticsCore/commit/ecd2fd66c151517c59c2826c2303e95bdac0b187))
* adjust `Monitoring` to pad details arrays to match `maxLength` while skipping `options` key ([fb51d9e](https://github.com/cEhlers88/AnalyticsCore/commit/fb51d9eec71dde826736de73ee7f74726b4c6c13))
* clean up `MonitoringRule` interface and `AbstractMonitoringRule` by removing `valueFromLastRun` handling for streamlined logic ([45bd99b](https://github.com/cEhlers88/AnalyticsCore/commit/45bd99bf1b4e56e992c9d9065acccfc6429628be))
* enhance `Doorman` with `setUser` method, admin role bypass, and detailed missing role handling ([8f937c4](https://github.com/cEhlers88/AnalyticsCore/commit/8f937c4029ccde1105d13f6ed83cfce2644e8e19))
* enhance assemblers with `childMap` handling, centralized `assemble` method in `AssemblerProvider`, and robust `monitorings` processing ([aec7d4c](https://github.com/cEhlers88/AnalyticsCore/commit/aec7d4c20d173b28e0de3f7e4bfbc9a95d13d0e7))
* expand `MonitoringRule` interface and refactor `AbstractMonitoringRule` logic for enhanced statistic options and execution handling ([e2f61df](https://github.com/cEhlers88/AnalyticsCore/commit/e2f61df542c1e2994edcd6b3fc8fd7317574774f))
* extend `AbstractCustomObject` with `getConfig` method and optional associative behavior in `getAttributes` ([d63fae6](https://github.com/cEhlers88/AnalyticsCore/commit/d63fae609b9cb48bc28ec6c9f763375007c11212))
* extend `CustomObjectAssembler` and `CustomObjectJson` to track `attributeIds` and initialize attributes ([3f97a66](https://github.com/cEhlers88/AnalyticsCore/commit/3f97a66468dbf9d4dbafa59eb5f39fb710963502))
* introduce `UserInteraction` entity and `UserInteractionRepository`, extend `CustomEntity` with `config` property, and implement `EntityInterface` in `CustomEntityAttribute` ([cfdde57](https://github.com/cEhlers88/AnalyticsCore/commit/cfdde573320adcff90f79148670cca8b689690db))
* introduce user interaction handling framework with abstract functions and resolver ([63d0747](https://github.com/cEhlers88/AnalyticsCore/commit/63d074778b57dafdeca3c0f46fbc8afc3447e841))
* refactor `CustomObjectAssembler` for streamlined attribute and child object handling, remove redundant logic, and enhance `attributeIds` management ([e7dd4fa](https://github.com/cEhlers88/AnalyticsCore/commit/e7dd4fa688f64969a2a575c7f2a0a214f0ae0dd5))
* refactor `CustomObjectAssembler` logic for `client_id` handling and remove redundant constructor in `CustomObjectAttributeAssembler` ([c53bcba](https://github.com/cEhlers88/AnalyticsCore/commit/c53bcba5535ec35da11e9c570360da7dc86e7117))
* refactor `Monitoring` for cleaner logic, improve rule handling, and ensure proper statistic detail processing ([11c524c](https://github.com/cEhlers88/AnalyticsCore/commit/11c524cc624f077bc162930773dd66639de9bab9))
* refactor `RecorderResultDTO`, add `ResultDTO` base class with utility methods for success/error handling ([57820e6](https://github.com/cEhlers88/AnalyticsCore/commit/57820e6e46e285a95b1be15bb3ca3d1cb38234e8))
* register `UserInteractionFunctionInterface` and `UserInteractionResolver` services with tagged iterators for user interaction handling ([a5c44d6](https://github.com/cEhlers88/AnalyticsCore/commit/a5c44d61e1736a6c2a42989e16a87dc16b2dc4aa))
* rename `validateProperties` to `validate` in `AbstractWorker` to simplify method usage ([6947e67](https://github.com/cEhlers88/AnalyticsCore/commit/6947e670aedf4af8951a2ddfdda49fe3a84984a8))
* update monitoring logic in `CustomObjectAssembler` and `Monitoring`, add numeric/boolean value handling, timestamp support, and improve `nextRunAfter` calculation ([fa4a662](https://github.com/cEhlers88/AnalyticsCore/commit/fa4a662e442f8f151d39d492e35d9b77606a1db6))

## [1.39.11](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.10...v1.39.11) (2026-08-14)


### Miscellaneous Chores

* add `AbstractMagicRole` base class with application, user, client IP, and role resolver support ([6456979](https://github.com/cEhlers88/AnalyticsCore/commit/64569795e07250639f92f8beca7f711cea390c78))
* add `allowMonitoring` property to `PropertyDTO`, update constructor and serialization logic ([e72906c](https://github.com/cEhlers88/AnalyticsCore/commit/e72906c6bfcd6ca91a813d97ce6528587ab9fff2))
* add `CustomEntityAttributeMonitoring` entity and repository to support attribute monitoring and scheduling ([1c7fee5](https://github.com/cEhlers88/AnalyticsCore/commit/1c7fee5765cb4a40e32d0d7e847e01ae3a44d59e))
* add `CustomEntityAttributeMonitoringAssembler` and `CustomEntityAttributeMonitoringView`, extend `CustomObjectView` with monitoring support ([897044c](https://github.com/cEhlers88/AnalyticsCore/commit/897044ca85f50e5df057ac27d3903d18fe7cde2b))
* enhance error message in `AbstractServiceEndpointRunner` to include detailed internal error description ([2f12f4d](https://github.com/cEhlers88/AnalyticsCore/commit/2f12f4d4089213ccb10a203be6e4178bbf13a198))
* extend `CustomEntityAttribute` and `CustomEntityAttributeMonitoring` with bidirectional relationship for monitoring, add statistics support ([bba4c7c](https://github.com/cEhlers88/AnalyticsCore/commit/bba4c7ca9cc98e77b7ca86289ddd24c2cf2cc691))
* extend `CustomEntityAttributeMonitoring` with new properties and methods, add `hasAttribute` to `CustomEntity`, and enhance repository with save/flush support ([514ba2a](https://github.com/cEhlers88/AnalyticsCore/commit/514ba2ae0ed57248e22718b9b0ab43d2f34dba79))
* extend `CustomObject` functionality with attribute monitoring, add new methods to `CustomObjectInterface`, and improve `CustomObjectProvider` logic ([d9a57ea](https://github.com/cEhlers88/AnalyticsCore/commit/d9a57ea6be43c3f1029bab44501ebceb0c3c51fa))
* improve error handling in `AbstractServiceEndpointRunner`, add `_hasError` flag, refactor permission check, and enhance exception handling ([9ada8d7](https://github.com/cEhlers88/AnalyticsCore/commit/9ada8d773fe2b82173a31caf51aeb25ebb121d87))
* introduce monitoring rule framework with `Monitoring`, `AbstractMonitoringRule`, and `RangeCheckMonitoringRule` implementations ([7980eea](https://github.com/cEhlers88/AnalyticsCore/commit/7980eea2d2f286f27813b64458034d95cbf25f01))
* refactor `MagicRoleAllOf` to extend `AbstractMagicRole` and streamline role resolution logic ([300b68c](https://github.com/cEhlers88/AnalyticsCore/commit/300b68c5164be14a4285144bef0bc4a70d60f149))
* refactor `MagicRoleAnyOf` to extend `AbstractMagicRole` and simplify role resolution logic ([a0a6099](https://github.com/cEhlers88/AnalyticsCore/commit/a0a60997be2fb0b283ba112fa2be78b65fdaea41))
* refactor `MagicRoleIsClient` to extend `AbstractMagicRole`, add `setApplication` method in `MagicRoleInterface`, and improve client IP handling ([9b7833a](https://github.com/cEhlers88/AnalyticsCore/commit/9b7833a29afefe9d86b2cc4b5ce168c8c0c8c3e7))
* refactor `MagicRoleNoneOf` to extend `AbstractMagicRole` and simplify role resolution logic ([a6b37e9](https://github.com/cEhlers88/AnalyticsCore/commit/a6b37e9805de4a3edac3de7fc45e8f6bebf81806))
* tag `MonitoringRuleInterface` implementation for DI container and update service bindings ([27e4bf9](https://github.com/cEhlers88/AnalyticsCore/commit/27e4bf97812f73f02eda73e77dfe4cc284de63e6))
* update `Doorman` to add `setApplication` method, enhance role resolution with `Application` support, and prevent duplicate error messages ([6302941](https://github.com/cEhlers88/AnalyticsCore/commit/630294196b68d57070215a5125f57097cb5c6be1))
* update `getConstants` in `VariablesProvider` to support filtering by application ID and associative array output, add duplicate name check ([1333b6a](https://github.com/cEhlers88/AnalyticsCore/commit/1333b6a512c69e866b78086acfbb08c599c92cee))

## [1.39.10](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.9...v1.39.10) (2026-08-11)


### Bug Fixes

* add Tag description and make the macro engine tolerate transient data ([#171](https://github.com/cEhlers88/AnalyticsCore/issues/171)) ([1df3088](https://github.com/cEhlers88/AnalyticsCore/commit/1df3088e42412d27a0b089ed74f0739a0a5a6e01))

## [1.39.9](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.8...v1.39.9) (2026-08-10)


### Miscellaneous Chores

* add `createNoneOf` method and update `createAllOf` method in `ExtendedRoleDTO` for expanded role composition support ([4ea075c](https://github.com/cEhlers88/AnalyticsCore/commit/4ea075c6e684a468c9d97ef1e2dc773b5cde6004))
* add `CustomObjectExtensionInterface` and base implementations, including `AbstractCustomObjectExtension` and `DynamicAttributesWorkerExtension` ([76bb1b4](https://github.com/cEhlers88/AnalyticsCore/commit/76bb1b4a2676b07ec48dcb2e4b7861e1d6b7bd4f))
* add `MagicRoleNoneOf` and `MagicRoleIsClient` implementations, introduce `BannedRole` and `IsClientRole` classes, and update `Doorman` to streamline role handling and validation ([f8ae99e](https://github.com/cEhlers88/AnalyticsCore/commit/f8ae99ef47e3963d0e3623a38304ba44e5ef95e3))
* add `RoleDTO` and `ExtendedRoleDTO` classes with role composition methods, enhance `PropertyDTO` with `description` property ([d307878](https://github.com/cEhlers88/AnalyticsCore/commit/d30787852d4ebee968b90fc02bba3f0418ae3fb2))
* add debug mode to `Doorman`, refine role resolution logic, and improve error handling with optional debug messages ([d7b5fb7](https://github.com/cEhlers88/AnalyticsCore/commit/d7b5fb7a909424f637d517ba7b5a2415ac24f267))
* add validation for worker and run chain existence in `addRunChainToWorkerSimple`, minor formatting fixes in `WorkerRepository` ([075469d](https://github.com/cEhlers88/AnalyticsCore/commit/075469d30049cb429ad58db3f4453ec4e9cd0675))
* **deps:** update dependency phpunit/phpunit to v13.3.0 ([#169](https://github.com/cEhlers88/AnalyticsCore/issues/169)) ([35c449f](https://github.com/cEhlers88/AnalyticsCore/commit/35c449f6373f12d698d63adc129ab02007553330))
* extend `ServiceEndpointRunner` with role-based access control, add support for `Doorman`, enhance endpoint role validation with `RoleDTO`, and update `getRequiredRoles` and related methods ([a724c4b](https://github.com/cEhlers88/AnalyticsCore/commit/a724c4baf36492b061d7690678f6f19a6cffb733))
* introduce `Doorman` for role-based access control, add `RoleInterface`, `MagicRoleInterface`, and `MagicRole` implementations, and update service configuration ([acc29ec](https://github.com/cEhlers88/AnalyticsCore/commit/acc29ec4c43fb7fd08ede30a58392af2cb8d0f06))
* refactor `Doorman` and `ServiceEndpointRunner` to improve user handling, add `getUser` and `setUser` methods, and streamline user propagation ([a437491](https://github.com/cEhlers88/AnalyticsCore/commit/a43749183b9bcebcb7afdee659e5f60bfe3cad36))
* refactor `RecorderResultDTO` to extend `ResultDTO`, update `createError` to support error details ([34f1ee7](https://github.com/cEhlers88/AnalyticsCore/commit/34f1ee748e4875dd509416b5f4a181a46fb840ac))
* replace `AbstractPropertyHolder` with `AbstractPropertyBag`, update dependencies, refactor property handling functionality, and add grouped property support in `PropertyBagInterface` and `PropertyDTO` ([a87b404](https://github.com/cEhlers88/AnalyticsCore/commit/a87b4048196561ee45534534586c3eb875ad27f7))

## [1.39.8](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.7...v1.39.8) (2026-07-19)


### Miscellaneous Chores

* add `BuildMacro` class, introduce `PROPERTY_ARGUMENTS` in `FunctionMacro`, modify `MacroPlayer` error message, and enhance `CurlHelper` to support mixed data types in POST methods ([35018cf](https://github.com/cEhlers88/AnalyticsCore/commit/35018cfbf19a2f9cba00de7d56af920c8c4978ce))
* add `GetCustomObjectMacro` to retrieve custom objects by name or ID ([1275cd0](https://github.com/cEhlers88/AnalyticsCore/commit/1275cd0bd868420213d5d5e03d398ab6bfc859e6))
* enhance logging and execution lifecycle in `AbstractExecutor` and `AbstractWorker`, add `startGroup` and `endGroup` methods to loggers, introduce `ConfigurationSuggestItemDTO`, and extend interfaces with new methods ([5ab7789](https://github.com/cEhlers88/AnalyticsCore/commit/5ab77894880f300bfefd83b144d4da644439ac4a))
* refactor `CustomObjectProvider` to support optional entity resolution, add `CustomObjectAssembler` and `CustomObjectView`, and update assemblers for compatibility with `AbstractCustomObject` entities ([53f78ea](https://github.com/cEhlers88/AnalyticsCore/commit/53f78ea1963bbfb143eb3bff1f4e2e866acca674))

## [1.39.7](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.6...v1.39.7) (2026-07-18)


### Miscellaneous Chores

* add `configured` state to `AbstractExecutor`, enhance error handling with contextual data, and update `error` logging signature ([3d3d4b0](https://github.com/cEhlers88/AnalyticsCore/commit/3d3d4b0763e3f887e4ed397d8a3a7a07b4fee6b0))
* extend `error` logging method to accept optional contextual data across loggers for enhanced flexibility ([07bc289](https://github.com/cEhlers88/AnalyticsCore/commit/07bc289435b235f3f11fa1ec2da9999ccaa5580e))
* extend `ObserverProvider` with `AbstractErrorBag`, add error handling and contextual logging across providers ([9ddf42f](https://github.com/cEhlers88/AnalyticsCore/commit/9ddf42f633dfd66007f795d3f257d61496f89650))
* refactor `WorkerProvider` to simplify dependencies, update property definitions and method naming, and improve logging consistency in executors ([fc61394](https://github.com/cEhlers88/AnalyticsCore/commit/fc6139415e45bec9cb825ccf9015a1f61c8f1cf2))

## [1.39.6](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.5...v1.39.6) (2026-07-12)


### Miscellaneous Chores

* refactor `CustomObjectProvider` to return resolved entities as an array, fix method names in `CustomEntityRepository` ([e2c793f](https://github.com/cEhlers88/AnalyticsCore/commit/e2c793f9721df8618e4df6154f2dcf12bae69129))

## [1.39.5](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.4...v1.39.5) (2026-07-12)


### Miscellaneous Chores

* add `getCustomEntityByClassNameAndAttribute` method to `CustomObjectProvider` for fetching entities by class and attribute ([da9e5a0](https://github.com/cEhlers88/AnalyticsCore/commit/da9e5a0c7b2a3aae3e2c4df4934e9f29866c655c))
* add `statistics` property to `CustomEntity` with getter and setter methods ([b8c495c](https://github.com/cEhlers88/AnalyticsCore/commit/b8c495cbde4e9d24b2d88c54127d87bc796bce66))

## [1.39.4](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.3...v1.39.4) (2026-07-12)


### Miscellaneous Chores

* add `description` and `requiredRoles` properties to `EndpointDefinitionDTO`; update `create` method signature to support new fields ([e37b4d2](https://github.com/cEhlers88/AnalyticsCore/commit/e37b4d27eedc5bdbabb2f49dfda07f9559b28b9e))
* add `getDescription` method to `ServiceEndpointRunnerInterface` and implement in `AbstractServiceEndpointRunner` for enhanced endpoint description retrieval ([e421ec5](https://github.com/cEhlers88/AnalyticsCore/commit/e421ec55cce017a064bb964c8727416758288778))
* add `getTileTemplate` method to `CustomObjectInterface` and implement in `AbstractCustomObject` ([98a2ad4](https://github.com/cEhlers88/AnalyticsCore/commit/98a2ad44394cd8258156f6231ab1f02ad02467a3))
* add `label` property to `PropertyDTO` and update `create` method to support it ([cb6b8ef](https://github.com/cEhlers88/AnalyticsCore/commit/cb6b8ef5cfb73623359d752e37311133ed69f6be))
* enhance `EndpointDefinitionDTO` and `ServiceEndpointRunner` functionality; add alias support, validation, and type updates ([bebe624](https://github.com/cEhlers88/AnalyticsCore/commit/bebe624e942683218eed50e187a32c3b215fb3ef))
* extend `EndpointDefinitionDTO` to support `handler`, enhance `AbstractServiceEndpointRunner` with parameter validation and endpoint handling logic ([6f3243b](https://github.com/cEhlers88/AnalyticsCore/commit/6f3243be3f140be7bcd164401b673d6a7a74ac03))
* extend interfaces and assemblers with `getUseFor` method, update `CustomObjectProvider` to return `CustomObjectInterface` ([4dcae0e](https://github.com/cEhlers88/AnalyticsCore/commit/4dcae0e43024099ea6695e3df6dec4d26f5bc632))
* refactor assembler hierarchy; introduce `AssembledInterface` and abstract base classes for frontend and backend consistency ([19e0354](https://github.com/cEhlers88/AnalyticsCore/commit/19e0354202bf3ef36ce2695983ad2840626052aa))
* refactor assembler structure; centralize `AssemblerInterface`, enhance backend assembler logic, and update `CustomObjectProvider` for improved entity handling ([d7d8cac](https://github.com/cEhlers88/AnalyticsCore/commit/d7d8cac36f15d19833e03cbf33070655ade0d8e5))
* replace `continue` with `break` in `CustomObjectAssembler` to fix client attribute handling logic ([33d81e4](https://github.com/cEhlers88/AnalyticsCore/commit/33d81e4f3a9e701c915c3beb45e4e09ea598c3a0))
* update `CustomObjectProvider` to set child objects using `getCustomEntitiesBy` method ([8710941](https://github.com/cEhlers88/AnalyticsCore/commit/8710941c26c22689e11349a3670c0e45e838ac7f))

## [1.39.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.2...v1.39.3) (2026-07-10)


### Miscellaneous Chores

* add `getCustomEntityByClassNameAndName` method in `CustomObjectProvider` to enhance entity retrieval functionality ([388d443](https://github.com/cEhlers88/AnalyticsCore/commit/388d443b800386a8df5d580d6a2ed75a3200f3d2))
* **deps:** update dependency phpunit/phpunit to v13.2.2 ([#160](https://github.com/cEhlers88/AnalyticsCore/issues/160)) ([89daaff](https://github.com/cEhlers88/AnalyticsCore/commit/89daaff6e475c05f1cc5a28026ad6790b0234de8))
* **deps:** update dependency phpunit/phpunit to v13.2.4 ([#162](https://github.com/cEhlers88/AnalyticsCore/issues/162)) ([eb0ed7d](https://github.com/cEhlers88/AnalyticsCore/commit/eb0ed7deb86188499fa235111cde43b1fefea8de))
* rename `add` to `save` in `ClientRepository`; add `getClientDetailsByTag` method in `Client` entity ([2ef06a5](https://github.com/cEhlers88/AnalyticsCore/commit/2ef06a508785c9ced57134f7049b27017b8e2119))
* replace `add` with `save` in `CheckIsFirstVisitJob` to align with `ClientRepository` method updates ([575fce5](https://github.com/cEhlers88/AnalyticsCore/commit/575fce5878dc295f0e886eb9c7eff7d931ad199b))

## [1.39.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.1...v1.39.2) (2026-06-29)


### Miscellaneous Chores

* add `AbstractValueHelper` and `SelectVarNameValueHelper` classes; implement `GetVarMacro` and `SetVarMacro` for variable management in macro system ([07eb5d1](https://github.com/cEhlers88/AnalyticsCore/commit/07eb5d14c5bbcaa084c3c688155795f2a2a7ffec))
* add `FunctionMacro`, `ReturnMacro`, and `CallMacro` classes; enhance `ProcessRepository` with `setEnabled` method ([5ce20c7](https://github.com/cEhlers88/AnalyticsCore/commit/5ce20c77c2069b9206cf008b16b914352e869c8b))
* add `MacroValueHelperValidationResultDTO` class; update imports and extend `ValidationResultDTO` with `isValid` and `message` properties ([572a1e5](https://github.com/cEhlers88/AnalyticsCore/commit/572a1e5e84a0ade71836dd0897bf0444fbf28744))
* add `Procedure` entity and `ProcedureRepository` class for managing procedures; update imports in `ProcedurePlayer` ([f82f579](https://github.com/cEhlers88/AnalyticsCore/commit/f82f579ce3087f0304b9ad977b5450af95f3ca45))
* add `ProcedurePlayer` class to handle execution of procedures with dynamic properties ([556733c](https://github.com/cEhlers88/AnalyticsCore/commit/556733c5fb770b97352fb186009a4104ceed5d20))
* add `Report` entity and `ReportRepository` class; update namespace in `ServiceEndpoint` for consistency ([3e4fdbd](https://github.com/cEhlers88/AnalyticsCore/commit/3e4fdbd5d0dc90c0cdafdc14f0cc89a3606d731f))
* add `ServiceEndpoint` entity and `ServiceEndpointRepository`; update imports in related classes ([b8c10f4](https://github.com/cEhlers88/AnalyticsCore/commit/b8c10f4ab31f88413b713cad5f166121ae135f03))
* add entities and repositories for `Category`, `CategoryGroup`, `Command`, `ApplicationAction`, and `AnalyticsHeader`; refactor imports for consistency ([62d9e5a](https://github.com/cEhlers88/AnalyticsCore/commit/62d9e5a8e8803b535df8bf5ffdf6d570eee2ce39))
* add unit tests for `GetVarMacro` and `SetVarMacro` to validate variable retrieval and assignment functionality in the macro system ([3818d14](https://github.com/cEhlers88/AnalyticsCore/commit/3818d146c1f2693e223678d72de4dcff94891398))
* **deps:** update actions/checkout action to v7 ([#149](https://github.com/cEhlers88/AnalyticsCore/issues/149)) ([d9278fe](https://github.com/cEhlers88/AnalyticsCore/commit/d9278fec19e0d9b32974d47e425b040dcd044810))
* **deps:** update dependency phpunit/phpunit to v13 ([#153](https://github.com/cEhlers88/AnalyticsCore/issues/153)) ([169ab3a](https://github.com/cEhlers88/AnalyticsCore/commit/169ab3a41022e366caca0befa425ac5e1a548b52))
* update entity and repository namespaces to `Cehlers88\AnalyticsCore` for consistency; remove redundant parent constructor call in `User` entity ([1c02076](https://github.com/cEhlers88/AnalyticsCore/commit/1c020765557775e1e03f190ffacb56b0d2acd030))
* update import for `MacroValueHelperValidationResultDTO` in `AbstractValueHelper` ([9bb36a9](https://github.com/cEhlers88/AnalyticsCore/commit/9bb36a990d10c4cae28388d1ad70ce7ee730b5a1))
* update namespace in `Procedure` entity to `Cehlers88\AnalyticsCore\Entity` for consistency ([a40576f](https://github.com/cEhlers88/AnalyticsCore/commit/a40576f4dbc9948e8c1909baca093cba659b3232))

## [1.39.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.39.0...v1.39.1) (2026-06-21)


### Miscellaneous Chores

* add empty line in `AbstractMacro` class for improved readability ([db13cd7](https://github.com/cEhlers88/AnalyticsCore/commit/db13cd77c4408c8c0e338822d5f8d19cc4d893c2))

## [1.39.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.9...v1.39.0) (2026-06-21)


### Features

* implement configurable CommandDefinitionValidator ([#152](https://github.com/cEhlers88/AnalyticsCore/issues/152)) ([125b454](https://github.com/cEhlers88/AnalyticsCore/commit/125b454ee8ff9fe1ca669395468b05c38164fa20))


### Performance Improvements

* **MacroPlayer:** cache macro lookups, remove debug echo and dead code ([#156](https://github.com/cEhlers88/AnalyticsCore/issues/156)) ([587868a](https://github.com/cEhlers88/AnalyticsCore/commit/587868a56c041424d7bf38c4f3f6e9acacea5768))


### Miscellaneous Chores

* add `AbstractMacro` and `MacroInterface` for defining macros with extension and logging support ([7e68527](https://github.com/cEhlers88/AnalyticsCore/commit/7e685274c36d5838a4486ab0b3927b6ffc4842a5))
* add `AbstractMacroExtension` base class and initial extensions (`JsonEncoder`, `JsonDecoder`, `MailAddressValidator`); update imports to reflect new structure ([84d01e6](https://github.com/cEhlers88/AnalyticsCore/commit/84d01e647f413846df32bd07ae0a1e003953d2dd))
* add `AbstractPropertyHolder` class to `Support` namespace; update imports across affected classes ([74f3824](https://github.com/cEhlers88/AnalyticsCore/commit/74f3824308c56d339da783990d5247a7538e73b3))
* add `ChangeApplicationMacro` with initialization, description, and property support; update DI configuration for macros; adjust project structure for test sources ([22efd00](https://github.com/cEhlers88/AnalyticsCore/commit/22efd009f5b94f033ee82af9bc85356cc53bdf7a))
* add `Documentation` framework with base `AbstractCommandDocumentation` and `DocumentationInterface`; update macros with consistent naming; extend logger with `setPropertyValue` method ([5fff098](https://github.com/cEhlers88/AnalyticsCore/commit/5fff0981c86ee364bf72126a9c276266ad51baaf))
* add `MacroExtensionProvider` to manage macro extensions; update `MacroPlayer` to integrate with the new provider ([c82095b](https://github.com/cEhlers88/AnalyticsCore/commit/c82095bd9fc54ac5121980e960707ca1c702049d))
* add `MacroProtector` framework with `AbstractMacroProtector`, `AllowAllMacroProtector`, and `DemoModeMacroProtector`; update `MacroPlayer` to integrate new protectors ([b0a73a7](https://github.com/cEhlers88/AnalyticsCore/commit/b0a73a7b00fc7c3a412ca3828a09e2cbbdf93bdc))
* add `MenuItemDTO` class to `Support\DTO\UI` namespace; update `AbstractBundlePlugin` to use new class ([db2838c](https://github.com/cEhlers88/AnalyticsCore/commit/db2838c1eef4165902a21f47cc6d05cfabb11aff))
* add `SharedData` and `VariableStore` entities with repositories; update `ConfigurationProvider` and related classes to utilize new implementations ([e608aad](https://github.com/cEhlers88/AnalyticsCore/commit/e608aaddab48215a1d2bc8d5f10c51d3e38e4d37))
* add `StrLowerMacro` to convert string values to lowercase, with initialization, description, and property support ([178009d](https://github.com/cEhlers88/AnalyticsCore/commit/178009d603f5581a5a39db7c5126ed2120999a7a))
* add `StrReplaceMacro` to replace strings with initialization, description, and property support ([7696600](https://github.com/cEhlers88/AnalyticsCore/commit/76966008b0ce310b7f668b7b1bf5f0d723ee6908))
* add `StrUpperMacro` to convert string values to uppercase, with initialization, description, and property support ([0cad1ed](https://github.com/cEhlers88/AnalyticsCore/commit/0cad1ed89e833432e4faf2f6d284d9cab766f737))
* add tests for `StrUpperMacro` and `StrLowerMacro` to validate uppercase and lowercase string transformations ([59488cb](https://github.com/cEhlers88/AnalyticsCore/commit/59488cb6cb7fc2a2032e74ebf6305d5bee81eff3))
* enhance `CommandFactory::evalDefinitionArray` with support for missing command arguments flag and update command name assignment logic ([e403aea](https://github.com/cEhlers88/AnalyticsCore/commit/e403aea8928aa68e9a47dbf7b69757aef915d006))
* implement `MacroExtensionInterface` and `MacroProtectorInterface`; update abstract classes to use interfaces and configure service definitions for DI ([10ca461](https://github.com/cEhlers88/AnalyticsCore/commit/10ca461e613a2f35515a2c26c79fdfc8f92063a1))
* implement `SilentDebugger` and `DevDebugger` for macro debugging; introduce `IMacroDebugger` interface and update `MacroEnvironment` and `CommandPlayer` configuration ([c7173a0](https://github.com/cEhlers88/AnalyticsCore/commit/c7173a0e1e1e368a6a93ca0fc0a31845ecc38bd1))
* introduce `MacroEnvironment` and `CommandPlayer` to manage and execute macro workflows, update affected classes and tests ([ef85dc7](https://github.com/cEhlers88/AnalyticsCore/commit/ef85dc78b0d1a1b4d84605cddfc08af54064ec0e))
* introduce `MacroPlayer` to centralize macro execution and management; adjust imports across affected classes ([7a7f043](https://github.com/cEhlers88/AnalyticsCore/commit/7a7f043064b4038c65e3eb45b5e1015e8eba156c))
* introduce `VariablesProvider`, update affected classes to utilize the new provider for variable management and context loading ([fa72b5a](https://github.com/cEhlers88/AnalyticsCore/commit/fa72b5ab21af57ce31035086966311105dd2adeb))
* move `DTO` base class to `Support` namespace; update imports across all affected DTO classes ([2976e10](https://github.com/cEhlers88/AnalyticsCore/commit/2976e1017f767f12a71ae07f88892aa3a5660a2d))
* move `eMacroVariableContext` to `Macro\ENUM`; update imports and implement `fromString` helper ([ddfa71e](https://github.com/cEhlers88/AnalyticsCore/commit/ddfa71ec496c9dcff0b098d7bb88f5d20d9f5d5f))
* optimize `CommandFactory` by adding command register for faster lookup and initializing it on construction ([352c997](https://github.com/cEhlers88/AnalyticsCore/commit/352c997d7cc5d6d70cef3dac5d6390d439878b29))
* refactor imports to consistently use `Cehlers88\AnalyticsCore` namespace; add `eConditionType`, `eSelfCheckResult`, and `eInstructionType` enums for standardized type management ([826fd6b](https://github.com/cEhlers88/AnalyticsCore/commit/826fd6b4092cd8298a3eb5ebe59c3f213378adeb))
* rename `CurlExecutor` to `CurlHelper` for improved context clarity ([d9d4091](https://github.com/cEhlers88/AnalyticsCore/commit/d9d409107427bf8c16fbabfadd0b890e3a6900de))
* replace `ConditionGroupDTO` reference with `Cehlers88\AnalyticsCore\DTO\ConditionGroupDTO`; add new `ConditionGroupDTO` implementation and update imports across classes ([2e76e34](https://github.com/cEhlers88/AnalyticsCore/commit/2e76e344c37746bd53361a687c49360f80b41bac))
* replace `IBundlePlugin` with `BundlePluginInterface`; create new interface and update affected classes ([d787653](https://github.com/cEhlers88/AnalyticsCore/commit/d787653594a190e3b5f32c15937c83206c3b2e80))
* update `AnalyticsCore` to extend `AbstractBundlePlugin` instead of `AbstractBundlePluginInterface` for consistency ([17b7aca](https://github.com/cEhlers88/AnalyticsCore/commit/17b7aca06564088a98712d61558880d441faa199))
* Use CommandDefinitionValidator in CommandFactory for command definition validation ([#155](https://github.com/cEhlers88/AnalyticsCore/issues/155)) ([81d4c6e](https://github.com/cEhlers88/AnalyticsCore/commit/81d4c6ea04a867d303b91eb983a6ff4eb7db90b5))

## [1.38.9](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.8...v1.38.9) (2026-06-15)


### Miscellaneous Chores

* make `AbstractEndpointEntity` an abstract class ([3069d18](https://github.com/cEhlers88/AnalyticsCore/commit/3069d18acef395d2641de17de9712c0f4d2b7f25))

## [1.38.8](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.7...v1.38.8) (2026-06-14)


### Miscellaneous Chores

* introduce new logging framework with multiple logger implementations, support for grouped logging, and enhanced configuration options ([af4b8d0](https://github.com/cEhlers88/AnalyticsCore/commit/af4b8d0245f5b24ba591999d7586662904e24889))
* Refactor styles and enhance CompositeLogger functionality ([abbcb38](https://github.com/cEhlers88/AnalyticsCore/commit/abbcb388f77547e70aada72e83aa73fce936945f))

## [1.38.7](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.6...v1.38.7) (2026-06-14)


### Miscellaneous Chores

* add `CurlExecutor` for HTTP requests and introduce `CurlResponseDTO` for response handling, enhance `AbstractExecutor` with `lastResult` tracking ([a0ecc8e](https://github.com/cEhlers88/AnalyticsCore/commit/a0ecc8e1a0e44f5ac26633f699267d8e408d922c))

## [1.38.6](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.5...v1.38.6) (2026-06-13)


### Bug Fixes

* correct parameter mapping in `ConfigurationProvider::buildBufferItem` method ([91a463c](https://github.com/cEhlers88/AnalyticsCore/commit/91a463cf1e33e201971ae9bcfc01d265e0b38b84))
* update input type handling in `ConfigurationProvider` to support password fields ([32a1cbd](https://github.com/cEhlers88/AnalyticsCore/commit/32a1cbdfb73e426a44dc07e548342ec7c5187986))


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.2.0 ([#143](https://github.com/cEhlers88/AnalyticsCore/issues/143)) ([15cf59a](https://github.com/cEhlers88/AnalyticsCore/commit/15cf59a5c3357df0d07b3ed26eaf8d70f21ebdae))
* enhance `CommandFactory` and `ProcessProvider` for improved command processing and method formatting ([dcca133](https://github.com/cEhlers88/AnalyticsCore/commit/dcca133f6ddb367ce9aaf71628f71aaa805344d5))

## [1.38.5](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.4...v1.38.5) (2026-05-25)


### Miscellaneous Chores

* update namespaces and service tags in `CheckIsFirstVisitJob` and `services.yaml` ([265b03d](https://github.com/cEhlers88/AnalyticsCore/commit/265b03d9781587432f7dbfda00afa23d84b691b5))

## [1.38.4](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.3...v1.38.4) (2026-05-25)


### Miscellaneous Chores

* add `SetTrackingBuffersStateToProcessedFinishedJob` to modify TrackingBuffer states ([62f5f07](https://github.com/cEhlers88/AnalyticsCore/commit/62f5f07baf4beb4fb3fa916b7a0d3256341490ee))
* refactor `CustomObjectProvider` to improve handling of parent-child relationships and update `AbstractCustomObject` with parent ID methods ([1b76301](https://github.com/cEhlers88/AnalyticsCore/commit/1b763018897b9d7c93d5b056ed73d9fc734ec6cb))
* simplify `CustomObjectProvider` by removing unused parent-child resolution logic and update `AbstractCustomObject` to eliminate child object handling ([925c7e2](https://github.com/cEhlers88/AnalyticsCore/commit/925c7e22229f512bb59b369d9171200d2899eb0a))

## [1.38.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.2...v1.38.3) (2026-05-25)


### Bug Fixes

* remove redundant `parent::__construct` call from `AbstractTaggedEntity` ([6751396](https://github.com/cEhlers88/AnalyticsCore/commit/6751396b3c07f541e09cf719a16e2c6c4a89960a))

## [1.38.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.1...v1.38.2) (2026-05-24)


### Miscellaneous Chores

* add `createdAt` timestamp and update `modifiedAt` handling in `CustomObjectProvider` ([ba8ec40](https://github.com/cEhlers88/AnalyticsCore/commit/ba8ec407b575996bf66e35de98ee8306d37a8ea9))
* add `NotificationChannel` entity and repository ([ceb0332](https://github.com/cEhlers88/AnalyticsCore/commit/ceb03324cde02fdb79efa25b4555fbb1608a726d))
* add `requiredPermissions` field to `NotificationChannel` entity ([9fced8e](https://github.com/cEhlers88/AnalyticsCore/commit/9fced8e45c6d1a50f3c7154cf197893faea17657))
* add `WorkerJobOptionsRepository` extending `AbstractRepository` ([788a79b](https://github.com/cEhlers88/AnalyticsCore/commit/788a79b06466868fc8aa8ce1133cb2855ad3406a))
* **deps:** update dependency phpunit/phpunit to v13.1.11 ([#139](https://github.com/cEhlers88/AnalyticsCore/issues/139)) ([cf5af17](https://github.com/cEhlers88/AnalyticsCore/commit/cf5af170bd240611a3e6f97b2e820a403f081f35))
* extend entities to `AbstractTaggedEntity` and update `User` entity with notification channels ([4a72d94](https://github.com/cEhlers88/AnalyticsCore/commit/4a72d944150ffd2dc792991ea47ea7ef4b1b10ad))
* extract tag management to `AbstractTaggedEntity` ([c2de75a](https://github.com/cEhlers88/AnalyticsCore/commit/c2de75acb76232260efeba93d5b6b57eb6b9691b))
* set `modifiedAt` timestamp when saving custom entities in `CustomObjectProvider` ([416cbe8](https://github.com/cEhlers88/AnalyticsCore/commit/416cbe8a51cde84876364471c2fcf0ccb421b5aa))

## [1.38.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.38.0...v1.38.1) (2026-05-17)


### Miscellaneous Chores

* add `findAttributeNamesByClass` method to `CustomEntityRepository` ([a541d1b](https://github.com/cEhlers88/AnalyticsCore/commit/a541d1bc44b6d3021ffd2cc318012116d54c409b))
* add `getAttributesOfCustomEntityClass` method to `CustomObjectProvider` ([7879a64](https://github.com/cEhlers88/AnalyticsCore/commit/7879a64285b560431adf713a5cda86e02f1f1b95))
* add `setAttributes` and `removeAttribute` methods to `AbstractCustomObject` ([a5d821c](https://github.com/cEhlers88/AnalyticsCore/commit/a5d821c644e1c273d63d78a2fe9fef2314bac890))
* extend `CustomObjectInterface` with attribute management methods ([ff50601](https://github.com/cEhlers88/AnalyticsCore/commit/ff50601f92fb19b73312e018e00e980fbaa21c28))

## [1.38.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.37.1...v1.38.0) (2026-05-17)


### Features

* add `MacroEnvironmentDTO`, `MacroProtectorResultDTO`, and `MacroPropertyDTO` classes ([b91d09a](https://github.com/cEhlers88/AnalyticsCore/commit/b91d09aa9de86f8930e775af5c9fdd5cb9a1bce4))
* introduce `CommandDTO` classes for command management ([9065491](https://github.com/cEhlers88/AnalyticsCore/commit/9065491e590ec539222900701218273b319327a2))
* introduce `CommandFactory` for streamlined command management ([b413011](https://github.com/cEhlers88/AnalyticsCore/commit/b413011cab1e0060d5543d57ad8ac8968f8b33f2))


### Miscellaneous Chores

* remove unused `CommandPropertyDTO` class ([04ab43a](https://github.com/cEhlers88/AnalyticsCore/commit/04ab43ac878ee9b9faf0b8a17f017b119eee00eb))
* replace `Analytics\DTO\PropertyDTO` with `Cehlers88\AnalyticsCore\DTO\PropertyDTO` ([55f3aaf](https://github.com/cEhlers88/AnalyticsCore/commit/55f3aaf7ab3a9b1b70f196cc4c59f2d6e1a825e8))
* update `CommandDTO` to replace `CommandPropertyDTO` with `PropertyDTO` ([3597ce5](https://github.com/cEhlers88/AnalyticsCore/commit/3597ce593e3a85603d517fdec5ede21eb32ae394))

## [1.37.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.37.0...v1.37.1) (2026-05-17)


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.10 ([#130](https://github.com/cEhlers88/AnalyticsCore/issues/130)) ([5d01362](https://github.com/cEhlers88/AnalyticsCore/commit/5d013629f25d4bbf5aa4bfd88a86e84e4ee0d436))
* extend `TrackingBufferAssembler` to handle `TemporaryTrackingBuffer` entities ([8186a2b](https://github.com/cEhlers88/AnalyticsCore/commit/8186a2b0bf339e262b375cf03423bf0a04c3f26d))

## [1.37.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.36.0...v1.37.0) (2026-05-16)


### Features

* add `parentId` support to `CustomObject` and `CustomObjectProvider` ([88d05e3](https://github.com/cEhlers88/AnalyticsCore/commit/88d05e3c3bb9a00201b8c87f29a96985211e1daf))

## [1.36.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.35.0...v1.36.0) (2026-05-16)


### Features

* enhance `CustomObject` and `TrackingBuffer` with new properties and methods ([b480b70](https://github.com/cEhlers88/AnalyticsCore/commit/b480b70fa7ddd7651f50d317ecd258d4773d09ed))


### Bug Fixes

* use `setAttributeValue` in `CustomObjectProvider` for consistent attribute updates ([cd793fc](https://github.com/cEhlers88/AnalyticsCore/commit/cd793fcf880b908e95c0ffc133366fc000eb1761))

## [1.35.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.34.0...v1.35.0) (2026-05-16)


### Features

* enhance `CustomObjectProvider` with flexible filtering, entity saving, and attribute management ([3ab583a](https://github.com/cEhlers88/AnalyticsCore/commit/3ab583a5bd9a8a45a258a5b7097a186410d7f828))

## [1.34.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.33.0...v1.34.0) (2026-05-16)


### Features

* add `handlerData` support to `TrackingRecorder` and improve documentation ([bcf1b45](https://github.com/cEhlers88/AnalyticsCore/commit/bcf1b45e07db61e626207076cc70960a4f983f02))

## [1.33.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.32.0...v1.33.0) (2026-05-14)


### Features

* add support for rerun behavior in `AbstractExecutor` and track `INTERACTION_REQUIRED` state in `eTrackingBufferState` ([a46a993](https://github.com/cEhlers88/AnalyticsCore/commit/a46a9936e3d5dbe1125353217709346825dc5ea2))

## [1.32.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.31.0...v1.32.0) (2026-05-14)


### Features

* add `wantsToReRun` method to `ExecutorInterface` ([cc33a9d](https://github.com/cEhlers88/AnalyticsCore/commit/cc33a9d754aa927159b2a8cd5d889ed36507adfa))


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.9 ([#126](https://github.com/cEhlers88/AnalyticsCore/issues/126)) ([f565375](https://github.com/cEhlers88/AnalyticsCore/commit/f5653754a390bc286ee383c0658f0acf89e04974))

## [1.31.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.30.0...v1.31.0) (2026-05-14)


### Features

* add `wantToReRun` methods in `WorkerInterface` ([d9588dd](https://github.com/cEhlers88/AnalyticsCore/commit/d9588dd956d4aff6115a5b31991eefdec9843c6d))


### Miscellaneous Chores

* refactor: reorder `AbstractWorkerJob` properties for consistency ([4f7377b](https://github.com/cEhlers88/AnalyticsCore/commit/4f7377b25587f8c1b3248235fa14c7270a268225))
* reorganize `SharedDataStoreTest` and update `WorkerInterface` stub ([ba98b09](https://github.com/cEhlers88/AnalyticsCore/commit/ba98b091e292f54f082003c7ca3ae98d14711417))

## [1.30.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.29.0...v1.30.0) (2026-05-10)


### Features

* add `wantToReRun` flag and related methods in `AbstractWorker` ([dcaeb0e](https://github.com/cEhlers88/AnalyticsCore/commit/dcaeb0ea8fd658ea6528fa8dec0f7a8b35afefee))

## [1.29.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.5...v1.29.0) (2026-05-09)


### Features

* add `ApiEntityProviderResultDTO` for handling API entity provider results ([d76c35d](https://github.com/cEhlers88/AnalyticsCore/commit/d76c35dc44e59aaa1207bdd30c7fe02b4cc06589))
* add `ApiLazyLoadEntityDTO` for managing lazy-loaded API entity relationships ([fecd10c](https://github.com/cEhlers88/AnalyticsCore/commit/fecd10c9cbba485a6509187f9706914f7518956e))

## [1.28.5](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.4...v1.28.5) (2026-05-03)


### Miscellaneous Chores

* add `getInfosArray` method to `ClientDetails` entity for decoding `infos` field as an array ([7f3b60f](https://github.com/cEhlers88/AnalyticsCore/commit/7f3b60fa283958e1e1df3a6361ece8518d252381))

## [1.28.4](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.3...v1.28.4) (2026-05-03)


### Miscellaneous Chores

* update namespace in `Client` entity for consistency with project structure ([ed356b3](https://github.com/cEhlers88/AnalyticsCore/commit/ed356b34850b7ca3c0a2f3b2995123d7ef839d1e))

## [1.28.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.2...v1.28.3) (2026-05-03)


### Miscellaneous Chores

* update `TrackingRecorder` and `TrackingBufferChangedObserverMessage` to simplify timestamp handling ([69393e0](https://github.com/cEhlers88/AnalyticsCore/commit/69393e09c82ef46f72a9845ea8521090d7ffe919))

## [1.28.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.1...v1.28.2) (2026-05-03)


### Miscellaneous Chores

* update namespace in `CaptureEventRecorder` for consistency with project structure ([ad5fc8a](https://github.com/cEhlers88/AnalyticsCore/commit/ad5fc8a98cca3196d2551608275766f7aef4c064))

## [1.28.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.28.0...v1.28.1) (2026-05-03)


### Miscellaneous Chores

* extend `TrackingRecorder` to support temporary tracking buffers and improve buffer handling ([62c1398](https://github.com/cEhlers88/AnalyticsCore/commit/62c1398a65bfe9d5a0c4868d0898bb614dfdca2e))

## [1.28.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.27.0...v1.28.0) (2026-05-03)


### Features

* add `CaptureEventRecorder` and `RecorderResultDTO` for event processing and result handling ([e216901](https://github.com/cEhlers88/AnalyticsCore/commit/e216901766d41ffca4774eb8ebc41f522c23c47a))

## [1.27.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.26.0...v1.27.0) (2026-05-03)


### Features

* add `TrackingRecorder` class and `TrackingBufferChangedObserverMessage` for improved buffer tracking and observer notifications ([445c1b4](https://github.com/cEhlers88/AnalyticsCore/commit/445c1b47c86ebfbb1b08f0e5c0d363b500f967b9))

## [1.26.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.25.1...v1.26.0) (2026-05-03)


### Features

* extract common data properties into `AbstractTrackingBuffer` and introduce `TemporaryTrackingBuffer` entity with repository ([e06d169](https://github.com/cEhlers88/AnalyticsCore/commit/e06d1698245f88be8830283015ca207ea6b3a2b6))

## [1.25.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.25.0...v1.25.1) (2026-05-03)


### Miscellaneous Chores

* update `composer.json` to adjust `dev-main` branch alias ([286ea26](https://github.com/cEhlers88/AnalyticsCore/commit/286ea26cbe6a54a00e3a16d59532cf5553556b47))

## [1.25.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.24.0...v1.25.0) (2026-05-03)


### Features

* Enhance `HandleClientUpdateServiceEndpointRunner` to handle `cast_info` client details update logic ([7a849d9](https://github.com/cEhlers88/AnalyticsCore/commit/7a849d9848c2e2fd691b5dac35084663fde1f030))

## [1.24.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.23.1...v1.24.0) (2026-05-03)


### Features

* add `adminNote` to `User` entity and enhance endpoint runner error handling ([c749a2f](https://github.com/cEhlers88/AnalyticsCore/commit/c749a2fb8043d5afed1ba84cade7cd63e526e967))

## [1.23.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.23.0...v1.23.1) (2026-05-03)


### Miscellaneous Chores

* rename `IServiceEndpointRunner` to `ServiceEndpointRunnerInterface` and update references ([65fa699](https://github.com/cEhlers88/AnalyticsCore/commit/65fa69955d7bb9d546d50fdaeacb6fe49c9bae3b))

## [1.23.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.22.1...v1.23.0) (2026-05-03)


### Features

* introduce `ServiceEndpointRunner` architecture for endpoint handling ([7aaf5ae](https://github.com/cEhlers88/AnalyticsCore/commit/7aaf5ae1e7e9f73fb5214ee815fb08fb9a7e6fa7))


### Miscellaneous Chores

* add `getJsonDefinition` method in `TrackingBufferView` for JSON data representation ([482af24](https://github.com/cEhlers88/AnalyticsCore/commit/482af2494038e5de45822f7c829bbc5ac8f4875d))

## [1.22.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.22.0...v1.22.1) (2026-05-02)


### Miscellaneous Chores

* update namespaces and code formatting in `ServerSideRenderer` classes ([2d1f85e](https://github.com/cEhlers88/AnalyticsCore/commit/2d1f85eba04136b9e7fb114eccbff18c831cb8cd))

## [1.22.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.21.3...v1.22.0) (2026-05-02)


### Features

* introduce `ServerSideRenderer` architecture for server-side rendering ([b8152a2](https://github.com/cEhlers88/AnalyticsCore/commit/b8152a20559c245fa3e4c069184f4f8cdbce2fba))


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.8 ([#108](https://github.com/cEhlers88/AnalyticsCore/issues/108)) ([dea7652](https://github.com/cEhlers88/AnalyticsCore/commit/dea7652a6120fb7fef3bbcbe6fc9b89a1506fd42))

## [1.21.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.21.2...v1.21.3) (2026-05-01)


### Miscellaneous Chores

* add `LoginObserverMessage` for user login event handling ([71cad26](https://github.com/cEhlers88/AnalyticsCore/commit/71cad265b27ea82e59f2fd6588746b8dce0c9b46))

## [1.21.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.21.1...v1.21.2) (2026-04-29)


### Miscellaneous Chores

* add `data` property to `SystemUpdateObserverMessage` for enhanced message context ([1ba53e1](https://github.com/cEhlers88/AnalyticsCore/commit/1ba53e174b39c11c3fad2fd1f1bdd6fea80408dd))

## [1.21.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.21.0...v1.21.1) (2026-04-29)


### Miscellaneous Chores

* add `SystemUpdateObserverMessage` and enhance observer messages ([ee419c2](https://github.com/cEhlers88/AnalyticsCore/commit/ee419c2f3b9ea03907c2543840d8575f58e26dcd))

## [1.21.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.20.0...v1.21.0) (2026-04-26)


### Features

* add `ConfigurationUpdateDTO` and enhance configuration handling ([9788925](https://github.com/cEhlers88/AnalyticsCore/commit/9788925d14641395ae89ef1f2c754740427a9816))


### Miscellaneous Chores

* **deps:** update googleapis/release-please-action action to v5 ([#101](https://github.com/cEhlers88/AnalyticsCore/issues/101)) ([0fff693](https://github.com/cEhlers88/AnalyticsCore/commit/0fff693d913e1c3c1cecf9ce6c7ae6cc76eb70a5))

## [1.20.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.19.0...v1.20.0) (2026-04-21)


### Features

* ensure `setPropertyValue` adds new properties if not existing ([3e7a2f3](https://github.com/cEhlers88/AnalyticsCore/commit/3e7a2f30eed76410743a90bd90b6880cbe85c667))

## [1.19.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.18.2...v1.19.0) (2026-04-21)


### Features

* add `setPropertyValue` method in `Worker` for dynamic property updates ([11a22d3](https://github.com/cEhlers88/AnalyticsCore/commit/11a22d3791137218bddbb11a406ae7fa651e0181))

## [1.18.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.18.1...v1.18.2) (2026-04-20)


### Miscellaneous Chores

* replace `maxRuntime` property in `Worker` with `getMaxRuntime` method ([1809e1e](https://github.com/cEhlers88/AnalyticsCore/commit/1809e1ecdc96da8f20c16de61649982894e3f1ab))

## [1.18.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.18.0...v1.18.1) (2026-04-20)


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.7 ([#84](https://github.com/cEhlers88/AnalyticsCore/issues/84)) ([c8612cf](https://github.com/cEhlers88/AnalyticsCore/commit/c8612cf8350fc091b136fad6f52d7f0ddbbda2c2))

## [1.18.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.17.0...v1.18.0) (2026-04-19)


### Features

* add `FatalError` state in `BadgeProvider` and refine worker store handling ([181957d](https://github.com/cEhlers88/AnalyticsCore/commit/181957d46d067feb771f8e88f1731bf45ca441ba))

## [1.17.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.16.1...v1.17.0) (2026-04-19)


### Features

* introduce new plugins, workers, and DTOs while enhancing process handling ([dbbec2f](https://github.com/cEhlers88/AnalyticsCore/commit/dbbec2f01420cac4eb034b55d6a80687bd93eb6d))

## [1.16.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.16.0...v1.16.1) (2026-04-14)


### Performance Improvements

* add Doctrine index for `TrackingBuffer.timestamp` ([#89](https://github.com/cEhlers88/AnalyticsCore/issues/89)) ([145b18d](https://github.com/cEhlers88/AnalyticsCore/commit/145b18df6e6e8d022560930ca5158a0d6b24fcf3))

## [1.16.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.15.0...v1.16.0) (2026-04-13)


### Features

* Add temporary shared data store to AbstractWorker and WorkerInterface ([#86](https://github.com/cEhlers88/AnalyticsCore/issues/86)) ([97aead1](https://github.com/cEhlers88/AnalyticsCore/commit/97aead1a84960e973d45741016989bfbd9916599))

## [1.15.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.14.0...v1.15.0) (2026-04-12)


### Features

* enhance worker-job interaction and introduce new workers ([3554250](https://github.com/cEhlers88/AnalyticsCore/commit/3554250f310bc9dab047d0112136d6c784338af6))

## [1.14.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.13.0...v1.14.0) (2026-04-11)


### Features

* add `getKeyValue` method in `TrackingBuffer` for key-value retrieval ([4352fc9](https://github.com/cEhlers88/AnalyticsCore/commit/4352fc9a7040c953b3d7a7d1058e8e39bbeb948f))

## [1.13.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.12.0...v1.13.0) (2026-04-10)


### Features

* add source file modification time caching in `AbstractWorkerJob` ([422824d](https://github.com/cEhlers88/AnalyticsCore/commit/422824d979461bda30bdf34748fda642edc9a691))

## [1.12.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.11.0...v1.12.0) (2026-04-06)


### Features

* extend `BadgeProvider` with additional states and update visual styles ([ab4d8c8](https://github.com/cEhlers88/AnalyticsCore/commit/ab4d8c864b094e892150b6545e680f3a241ef1b8))


### Bug Fixes

* refine `QuickStatusInfoDTO` state handling in `AbstractRunnableEntity` ([8c1cc33](https://github.com/cEhlers88/AnalyticsCore/commit/8c1cc33d21ee6f7bead400e84dd7e73f3a3e00c1))

## [1.11.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.10.1...v1.11.0) (2026-04-06)


### Features

* add `ApplicationConfigurationGroup` for managing application settings ([2c5f309](https://github.com/cEhlers88/AnalyticsCore/commit/2c5f3098622f3ef25fa24c2c074d86d4058559c7))


### Miscellaneous Chores

* remove unused `state` configuration item in `ApplicationConfigurationGroup` ([465cd8d](https://github.com/cEhlers88/AnalyticsCore/commit/465cd8d9f3b9d56e5d36acd3fca91e37c7914e45))

## [1.10.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.10.0...v1.10.1) (2026-04-06)


### Bug Fixes

* improve warning message for unknown job type in `AbstractWorker` ([4c12b3f](https://github.com/cEhlers88/AnalyticsCore/commit/4c12b3fb0e261f6a37246a5656983533ed204352))

## [1.10.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.9.0...v1.10.0) (2026-04-06)


### Features

* enhance custom entity resolution logic and improve state handling ([b9f84f9](https://github.com/cEhlers88/AnalyticsCore/commit/b9f84f9f49a795c188b3160dd1c95a4c818d7ce8))
* update `WorkerResultDTO` error handling to support arrays ([a99b2cd](https://github.com/cEhlers88/AnalyticsCore/commit/a99b2cd2bd2ef98a51dfd909d5c0059578b8b52b))

## [1.9.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.8.0...v1.9.0) (2026-04-05)


### Features

* add `parentId` property to `CustomEntity` with getter and setter methods ([386cc6c](https://github.com/cEhlers88/AnalyticsCore/commit/386cc6ccbc69fffd0b5bbd12638f39d8662a6a13))

## [1.8.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.7.0...v1.8.0) (2026-04-05)


### Features

* add warning state and enhance warning handling in `AbstractWorker` ([d63a6cc](https://github.com/cEhlers88/AnalyticsCore/commit/d63a6cc7d5c4c9a9d470fbbbad55b69b9334d20a))

## [1.7.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.6.0...v1.7.0) (2026-04-05)


### Features

* add `DomElementPropsDTO` and `AbstractInputRenderer` for input rendering and DOM definition handling ([347b785](https://github.com/cEhlers88/AnalyticsCore/commit/347b78582689836c53497bb9465a41133324df6c))
* refactor `ConfigurationProvider` with autoload toggle, enhanced buffer handling, and constant grouping logic ([fbef09b](https://github.com/cEhlers88/AnalyticsCore/commit/fbef09b82e96d54e7197289cea90633710fd2634))


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.0 ([#71](https://github.com/cEhlers88/AnalyticsCore/issues/71)) ([ea28b56](https://github.com/cEhlers88/AnalyticsCore/commit/ea28b56177d222ec9863a49d974a80e451f7444c))

## [1.6.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.5.0...v1.6.0) (2026-03-29)


### Features

* add `getResultWorkers` method to `ProcessResultWorkerProvider` to expose result worker collection ([5bbd8d1](https://github.com/cEhlers88/AnalyticsCore/commit/5bbd8d190b348d591f84e67c2ad5a806ad73377d))

## [1.5.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.4.1...v1.5.0) (2026-03-29)


### Features

* enhance process runner framework with result handling logic and configuration updates ([95435c9](https://github.com/cEhlers88/AnalyticsCore/commit/95435c9c7a32ef940abadcdcdf32cbb2f0c62933))
* update process runner and state management logic ([6dacfee](https://github.com/cEhlers88/AnalyticsCore/commit/6dacfeee3bb8addc89000fd0c542f8b8b6927afe))

## [1.4.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.4.0...v1.4.1) (2026-03-29)


### Miscellaneous Chores

* improve `AbstractExecutor` and `AbstractWorker` handling, add `isDisabled` method, enhance type hints and repository usage, and refactor worker result logic ([04b1daa](https://github.com/cEhlers88/AnalyticsCore/commit/04b1daae5f934fd1f245922602b235eb6e21fce3))
* refactor `RunChainView` constructor to `loadByRunChain` for improved usability and streamline entity handling ([2141fba](https://github.com/cEhlers88/AnalyticsCore/commit/2141fbae4420b220374c5c04cd06825e26daad88))

## [1.4.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.13...v1.4.0) (2026-03-27)


### Features

* add `QuickActionDTO` for representing quick action attributes ([2b04ed6](https://github.com/cEhlers88/AnalyticsCore/commit/2b04ed6c06f7fa1c1a125fe4a9ae0bc17803f4db))


### Miscellaneous Chores

* refactor `RunChainAssemblerTest` to improve structure and add createdAt mock setup ([4620928](https://github.com/cEhlers88/AnalyticsCore/commit/46209282dd5384662037e279c8c346152f58d45d))
* rename `one` to `assembleView` in assembler classes for improved clarity and consistency ([c1b0f55](https://github.com/cEhlers88/AnalyticsCore/commit/c1b0f55ece8f70b92e60e530860a3d4e35535f5f))

## [1.3.13](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.12...v1.3.13) (2026-03-26)


### Miscellaneous Chores

* enhance error handling in `AbstractWorker` by logging fatal errors to `TrackingBuffer` ([84e9917](https://github.com/cEhlers88/AnalyticsCore/commit/84e991785f70aa62686a8800a61451aaba8dd3c4))

## [1.3.12](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.11...v1.3.12) (2026-03-26)


### Miscellaneous Chores

* integrate `TrackingBufferRepository` into `WorkerProvider` and `AbstractWorker` for enhanced repository handling ([efcdee9](https://github.com/cEhlers88/AnalyticsCore/commit/efcdee9cda4563e3299d222717dfc084e580ed68))

## [1.3.11](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.10...v1.3.11) (2026-03-26)


### Miscellaneous Chores

* refactor error handling and status generation in core components ([dd638f6](https://github.com/cEhlers88/AnalyticsCore/commit/dd638f68e9603c95a9e91307dee10e517f80fb25))

## [1.3.10](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.9...v1.3.10) (2026-03-25)


### Miscellaneous Chores

* remove unused imports and logging methods, enhance property loading in worker classes ([dbce940](https://github.com/cEhlers88/AnalyticsCore/commit/dbce940860baf7985b6805d7b3aeff7fa8744e22))

## [1.3.9](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.8...v1.3.9) (2026-03-25)


### Miscellaneous Chores

* add `TrackingBufferView` and `TrackingBufferAssembler` for front-end representation and entity handling ([a648e4b](https://github.com/cEhlers88/AnalyticsCore/commit/a648e4b0e1fae933e98b98277f63ceb11d3ec77f))
* add `UserView` and `UserAssembler` for front-end representation, implement `EntityInterface` in `User` entity ([ed280aa](https://github.com/cEhlers88/AnalyticsCore/commit/ed280aae672908e1e9a245f2695cd628caeb337f))

## [1.3.8](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.7...v1.3.8) (2026-03-24)


### Miscellaneous Chores

* update `setAttribute` method to return `static` for improved chaining support ([a9dbbe7](https://github.com/cEhlers88/AnalyticsCore/commit/a9dbbe7660d06663b603483ee7efcd44600b9b50))

## [1.3.7](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.6...v1.3.7) (2026-03-24)


### Miscellaneous Chores

* replace `setId` with `load` in `CustomObjectInterface`, streamline attribute initialization ([38a93f0](https://github.com/cEhlers88/AnalyticsCore/commit/38a93f0cd97488d72c8df6c7859d94d28c1e9cc6))

## [1.3.6](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.5...v1.3.6) (2026-03-23)


### Miscellaneous Chores

* add `NORMALIZED` state to `eTrackingBufferState` enum ([523067c](https://github.com/cEhlers88/AnalyticsCore/commit/523067cea1fc797704c5c4112d7794c39b5fb6e7))

## [1.3.5](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.4...v1.3.5) (2026-03-23)


### Miscellaneous Chores

* remove deprecated frontend assemblers and views, add `configure` method to `AbstractAssembler` and `AssemblerInterface` ([c92d082](https://github.com/cEhlers88/AnalyticsCore/commit/c92d082c0e38bfe6c16283eba1190417c1a8f833))

## [1.3.4](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.3...v1.3.4) (2026-03-23)


### Bug Fixes

* update `filters` field in `TrackingBuffer` entity to use `TEXT` type for better compatibility ([0b4e440](https://github.com/cEhlers88/AnalyticsCore/commit/0b4e440ab506bf218d229135c5b4a5d19a548d12))


### Miscellaneous Chores

* remove deprecated `TrackingBuffer` assembler and view, introduce `AssemblerProvider` with `canHandle` support for improved entity-assembler handling ([781e19f](https://github.com/cEhlers88/AnalyticsCore/commit/781e19febe15b9e2581172bbf22b4eae3b1ee94b))

## [1.3.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.2...v1.3.3) (2026-03-23)


### Miscellaneous Chores

* add `color` property to `ApplicationView` and `ApplicationAssembler`, introduce `filters` field and indexing in `TrackingBuffer` entity ([3941987](https://github.com/cEhlers88/AnalyticsCore/commit/3941987e7366f78108c640dabe433c06595f136b))

## [1.3.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.1...v1.3.2) (2026-03-23)


### Bug Fixes

* update `TrackingBufferView` to use `eTrackingBufferState` instead of `eRunningState`, align with state changes ([a5d6189](https://github.com/cEhlers88/AnalyticsCore/commit/a5d61893da3435085ac907808ea892083719adf2))

## [1.3.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.0...v1.3.1) (2026-03-23)


### Bug Fixes

* update `TrackingBuffer` assembler and view to use `eRunningState`, refactor state handling for consistency ([5a76a35](https://github.com/cEhlers88/AnalyticsCore/commit/5a76a35ba12c64dad9a1437cbf99761208e0fb4b))

## [1.3.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.2.0...v1.3.0) (2026-03-23)


### Features

* add `TrackingBuffer` assembler and view, enhance `QuickStatusInfoProvider` with detailed states, and refactor deprecated method in `TrackingBuffer` entity ([fefdd41](https://github.com/cEhlers88/AnalyticsCore/commit/fefdd4153c9fe08ed7f8a57d7892ee3ba97dfaff))

## [1.2.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.3...v1.2.0) (2026-03-23)


### Features

* set badge label and CSS class in `ApplicationView` constructor ([75df4a3](https://github.com/cEhlers88/AnalyticsCore/commit/75df4a391519c35919bb4483c9b58734abb4298f))

## [1.1.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.2...v1.1.3) (2026-03-22)


### Bug Fixes

* handle potential null `process` in `CurlRequestProcessRunner`, refine `AbstractProcessResultWorker` process management logic ([66c2947](https://github.com/cEhlers88/AnalyticsCore/commit/66c2947a33f9e891d63191692686577980b82986))

## [1.1.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.1...v1.1.2) (2026-03-22)


### Bug Fixes

* add error handling in `ProcessProvider` to log exceptions and update process state ([ce9f2e1](https://github.com/cEhlers88/AnalyticsCore/commit/ce9f2e17a6a5eb2a32e87e73ec48f1144b576d8d))

## [1.1.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.0...v1.1.1) (2026-03-22)


### Bug Fixes

* add `statusCode` and `runner` handling in `AbstractProcessResultWorker`, minor format fix in `ModifyTrackingBufferResultWorker` ([a3c47a0](https://github.com/cEhlers88/AnalyticsCore/commit/a3c47a057d8f72fd7475a784da05cf50bb0174ae))

## [1.1.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.0.0...v1.1.0) (2026-03-22)


### Features

* add `ProcessResultWorkerProvider` for managing result workers and refine state handling in `AbstractProcessResultWorker` ([1c4a77b](https://github.com/cEhlers88/AnalyticsCore/commit/1c4a77b8980ed1715af408ad59fe737bb1c9bc6c))
* extend `ProcessRunnerInterface` and `ProcessResultWorkerInterface` with result handling methods, implement enhanced runner-worker integration in `ProcessProvider` ([ea75a12](https://github.com/cEhlers88/AnalyticsCore/commit/ea75a12ac31ae77c6ad38740501677c167214296))

## [1.0.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.11...v1.0.0) (2026-03-22)


### ⚠ BREAKING CHANGES

* add debug mode with optional process logging in `ProcessProvider`

### Features

* add debug mode with optional process logging in `ProcessProvider` ([b03320a](https://github.com/cEhlers88/AnalyticsCore/commit/b03320a4b85211d44cea7aca872aa97f28d90dbf))

## [0.5.11](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.10...v0.5.11) (2026-03-22)


### Miscellaneous Chores

* reinstate `getQuickInfo` method in `AbstractRunnableEntity` for state evaluation ([e8e73ed](https://github.com/cEhlers88/AnalyticsCore/commit/e8e73ed011c6e9b63dbd32a27e3c5651dfa80472))

## [0.5.10](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.9...v0.5.10) (2026-03-22)


### Miscellaneous Chores

* reinstate and refine `getQuickInfo` method in `Process` entity for progress calculation ([6f0bd1c](https://github.com/cEhlers88/AnalyticsCore/commit/6f0bd1c0c79a47b2c2cee728c739394598c7c21e))

## [0.5.9](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.8...v0.5.9) (2026-03-22)


### Miscellaneous Chores

* add info logging during worker configuration and initialization, reorder `getName` method in `AbstractWorker` ([65edd87](https://github.com/cEhlers88/AnalyticsCore/commit/65edd878700536abbfda1f4b315ace0116db037b))
* remove redundant logging in `AbstractWorker` ([f37c817](https://github.com/cEhlers88/AnalyticsCore/commit/f37c8175e044e2b0f0eee0bcf14c503ec8fbd1ed))
* replace `logInfo` with `handleTimeoutReached` for consistent timeout handling in `AbstractWorker` ([cc33618](https://github.com/cEhlers88/AnalyticsCore/commit/cc336186b261a8b7def5fcb3c74966bd81eb022e))

## [0.5.8](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.7...v0.5.8) (2026-03-22)


### Bug Fixes

* handle nullable `StoreDTO` in `setStore` methods of `RunChain` and `Worker` entities ([66f243f](https://github.com/cEhlers88/AnalyticsCore/commit/66f243f25d8f897eeaf97c62f91703d01443fe8d))

## [0.5.7](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.6...v0.5.7) (2026-03-22)


### Miscellaneous Chores

* make `onStart` and `onEnd` public in `AbstractExecutor` and `ExecutorInterface`, improve error handling with logging ([a1b6e7f](https://github.com/cEhlers88/AnalyticsCore/commit/a1b6e7ff2ead3dd4a137bb1f2dc8939a51469dd1))

## [0.5.6](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.5...v0.5.6) (2026-03-22)


### Miscellaneous Chores

* add `store` property and related getter/setter in `RunChain` entity to support `StoreDTO` ([fc76ea5](https://github.com/cEhlers88/AnalyticsCore/commit/fc76ea5916ffd1310727a2fc484d74bbde8bd59b))

## [0.5.5](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.4...v0.5.5) (2026-03-22)


### Bug Fixes

* replace `Profiler::runWithProfiler` with dedicated `Profiler` instance in `AbstractWorker` ([eddfd45](https://github.com/cEhlers88/AnalyticsCore/commit/eddfd45d0d4f3654eae25a1c6b5c832a0c1fd281))

## [0.5.4](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.3...v0.5.4) (2026-03-22)


### Bug Fixes

* correct logic for error detection in `AbstractErrorBag::hasError` ([7e242d5](https://github.com/cEhlers88/AnalyticsCore/commit/7e242d54ecbee53b8b3039a7ea6846ae379a6f8c))

## [0.5.3](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.2...v0.5.3) (2026-03-22)


### Miscellaneous Chores

* add `isRunning` method to `AbstractExecutor` and `ExecutorInterface` ([7599464](https://github.com/cEhlers88/AnalyticsCore/commit/75994649a88bc04da59933d9c37b4e6592881e23))
* add `preStart` hook and `ERR_ON_PRE_START` constant to `AbstractExecutor` ([4f23c58](https://github.com/cEhlers88/AnalyticsCore/commit/4f23c58e900c5a44b8fa172442d06f96d57db006))

## [0.5.2](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.1...v0.5.2) (2026-03-21)


### Miscellaneous Chores

* allow filtering to include errored workers in `fetchWaitingWorkers` and enhance state removal logic in `Worker` entity ([c2b3b8f](https://github.com/cEhlers88/AnalyticsCore/commit/c2b3b8fe1b0f49f1adc57b20ccf22f5a95354413))

## [0.5.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.0...v0.5.1) (2026-03-21)


### Miscellaneous Chores

* add generated `timestamp_time` and `handled_at_time` columns to `TrackingBuffer` entity ([38eff80](https://github.com/cEhlers88/AnalyticsCore/commit/38eff8035e0ddd1bfd332d11835e4cc608e076e5))

## [0.5.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.4.2...v0.5.0) (2026-03-20)


### Features

* add `IGNORED` state to `eTrackingBufferState` enum ([8c91865](https://github.com/cEhlers88/AnalyticsCore/commit/8c918652be693d78ec4add84985d21a2a0eb5626))

## [0.4.2](https://github.com/cEhlers88/AnalyticsCore/compare/v0.4.1...v0.4.2) (2026-03-20)


### Miscellaneous Chores

* update `_executeWorker` to return a boolean instead of enforcing void ([62ccf41](https://github.com/cEhlers88/AnalyticsCore/commit/62ccf41c8a112b323e345089cc238d21e69d86b4))

## [0.4.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.4.0...v0.4.1) (2026-03-20)


### Miscellaneous Chores

* set `VoidLogger` as default in `executeWorkersByPriorityLevel` and enforce void cast in `_executeWorker` ([4ef7378](https://github.com/cEhlers88/AnalyticsCore/commit/4ef73780780ccbda748880792f4dec90f34da397))

## [0.4.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.3.1...v0.4.0) (2026-03-20)


### Features

* enhance `AbstractExecutor` with profiler lifecycle and ms-level execution time ([84e9d3a](https://github.com/cEhlers88/AnalyticsCore/commit/84e9d3a4fde26bade3a6196ffd1b6245d2237378))
* introduce `eDebuggerLogType` and `eDebuggerLogReason` enums, update namespace usage ([327955f](https://github.com/cEhlers88/AnalyticsCore/commit/327955fbd6a495c6f22b5d473d1a5399f8038dc0))

## [0.3.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.3.0...v0.3.1) (2026-03-20)


### Miscellaneous Chores

* **deps:** update actions/checkout action to v6 ([#21](https://github.com/cEhlers88/AnalyticsCore/issues/21)) ([112697f](https://github.com/cEhlers88/AnalyticsCore/commit/112697f6e2e66d04d6555c4e5141323a3571f51a))
* **deps:** update dependency phpunit/phpunit to v13 ([#22](https://github.com/cEhlers88/AnalyticsCore/issues/22)) ([0fb6bcf](https://github.com/cEhlers88/AnalyticsCore/commit/0fb6bcfb09e641e71ce5303e726596a25512a4b5))

## [0.3.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.2.1...v0.3.0) (2026-03-19)


### Features

* add `CompositeLogger` for managing multiple loggers ([2adeeaf](https://github.com/cEhlers88/AnalyticsCore/commit/2adeeaff330a8a51eb7cd1d980e35cee7c5706f8))
* add `getLoggerByClass` method to `CompositeLogger` ([e5c9269](https://github.com/cEhlers88/AnalyticsCore/commit/e5c9269c2c2314007500787df7f14a6a8f74cca9))
* introduce `AbstractExecutor` with complete lifecycle and logging support ([5b76531](https://github.com/cEhlers88/AnalyticsCore/commit/5b76531500a34b5b9c489cefb86727ed748b4f28))

## [0.2.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.2.0...v0.2.1) (2026-01-22)


### Features

* Implement process presenter ([#15](https://github.com/cEhlers88/AnalyticsCore/issues/15)) ([230fa9e](https://github.com/cEhlers88/AnalyticsCore/commit/230fa9e762afe15c554a2d399db98a013448488c))


### Miscellaneous Chores

* Configure Renovate ([#12](https://github.com/cEhlers88/AnalyticsCore/issues/12)) ([e03e62d](https://github.com/cEhlers88/AnalyticsCore/commit/e03e62d3a081fd9dd7d3507f7045f0b803305063))

## [0.2.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.8...v0.2.0) (2026-01-22)


### Features

* Implement presenters ([#9](https://github.com/cEhlers88/AnalyticsCore/issues/9)) ([d7399a7](https://github.com/cEhlers88/AnalyticsCore/commit/d7399a7604e707761f6549279257b164c59b8970))


### Bug Fixes

* replace `DateTimeImmutable` with `DateTime` for better compatibility ([28354e5](https://github.com/cEhlers88/AnalyticsCore/commit/28354e51aecf77b1fb553a27501013c77e499f07))

## [0.1.8](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.7...v0.1.8) (2026-01-21)


### Bug Fixes

* initialize default type for AbstractWorkerJob ([aa409b5](https://github.com/cEhlers88/AnalyticsCore/commit/aa409b5b17539a63cb45d73d200f3dabb7efb9b8))

## [0.1.7](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.6...v0.1.7) (2026-01-21)


### Reverts

* fix: prepend 'TEST' to truncated tracking buffer string ([f59b84c](https://github.com/cEhlers88/AnalyticsCore/commit/f59b84cf7411e6b39e73f50cc64ef7fc5a5d4bc0))

## [0.1.6](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.5...v0.1.6) (2026-01-21)


### Bug Fixes

* prepend 'TEST' to truncated tracking buffer string ([5a68758](https://github.com/cEhlers88/AnalyticsCore/commit/5a68758fc4ccd6544fcfec8281b7c8374059fca4))

## [0.1.5](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.4...v0.1.5) (2026-01-21)


### Miscellaneous Chores

* add workflow to trigger Satis rebuild on release publication ([0ecb93e](https://github.com/cEhlers88/AnalyticsCore/commit/0ecb93ea6b9cac9b5dbd0e95e01d734f1bdfa2b5))

## [0.1.4](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.3...v0.1.4) (2026-01-21)


### Bug Fixes

* Update ClientPermission `permkeys` field type from ARRAY to JSON ([bddfd5e](https://github.com/cEhlers88/AnalyticsCore/commit/bddfd5e267cfec90fdd9624fbb9f054d77ef3102))
* Update service bindings to use `!tagged_iterator` for tagged services ([faf2a03](https://github.com/cEhlers88/AnalyticsCore/commit/faf2a03bb969fac99b2c79e326a7fd031be047d1))

## [0.1.3](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.2...v0.1.3) (2026-01-20)


### Miscellaneous Chores

* add release-please.yml ([8438a59](https://github.com/cEhlers88/AnalyticsCore/commit/8438a594eb4f9afcfd600fa0ae51d90e88fb76b6))
