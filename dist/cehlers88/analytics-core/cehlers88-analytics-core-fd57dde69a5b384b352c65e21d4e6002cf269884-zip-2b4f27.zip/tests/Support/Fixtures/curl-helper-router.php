<?php

// Router for the built-in web server CurlHelperTest starts: /status/<code> answers
// with that status, a JSON body and a repeated header.
if (!preg_match('#^/status/(\d{3})$#', parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), $matches)) {
    http_response_code(400);
    return;
}

http_response_code((int)$matches[1]);
header('Content-Type: application/json');
header('X-Api-Version: 1');
header('X-Api-Version: 2', false);
echo json_encode(['status' => (int)$matches[1]]);
