<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support;

use Cehlers88\AnalyticsCore\Support\CurlHelper;
use PHPUnit\Framework\TestCase;

/**
 * Runs against PHP's built-in web server, so the status handling is tested
 * with real HTTP responses.
 */
class CurlHelperTest extends TestCase
{
    /** @var resource|null */
    private static $server = null;
    private static string $baseUrl = '';

    public static function setUpBeforeClass(): void
    {
        $socket = @stream_socket_server('tcp://127.0.0.1:0');
        if ($socket === false) {
            return;
        }
        $port = (int)substr(strrchr(stream_socket_get_name($socket, false), ':'), 1);
        fclose($socket);

        self::$server = proc_open(
            [PHP_BINARY, '-S', '127.0.0.1:' . $port, __DIR__ . '/Fixtures/curl-helper-router.php'],
            [1 => ['file', '/dev/null', 'w'], 2 => ['file', '/dev/null', 'w']],
            $pipes
        ) ?: null;
        self::$baseUrl = 'http://127.0.0.1:' . $port;

        for ($attempt = 0; self::$server !== null && $attempt < 50; $attempt++) {
            $connection = @fsockopen('127.0.0.1', $port);
            if ($connection !== false) {
                fclose($connection);
                return;
            }
            usleep(100_000);
        }

        // Never came up (e.g. the port was taken meanwhile): skip instead of testing a dead port.
        self::tearDownAfterClass();
    }

    public static function tearDownAfterClass(): void
    {
        if (self::$server !== null) {
            proc_terminate(self::$server);
            proc_close(self::$server);
            self::$server = null;
        }
    }

    protected function setUp(): void
    {
        if (self::$server === null) {
            $this->markTestSkipped('The built-in web server could not be started.');
        }
    }

    public function testReturnsStatusBodyAndHeaders(): void
    {
        $response = new CurlHelper()->get(self::$baseUrl . '/status/200');

        $this->assertSame(200, $response->statusCode);
        $this->assertSame(['status' => 200], $response->body);
        $this->assertSame(['1', '2'], $response->headers['X-Api-Version']);
    }

    public function testThrowsOnErrorStatusByDefault(): void
    {
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Curl error: 404');

        new CurlHelper()->get(self::$baseUrl . '/status/404');
    }

    public function testReturnsErrorStatusWhenAskedTo(): void
    {
        $response = new CurlHelper()->setThrowOnHttpError(false)->get(self::$baseUrl . '/status/404');

        $this->assertSame(404, $response->statusCode);
        $this->assertSame(['status' => 404], $response->body);
    }
}
