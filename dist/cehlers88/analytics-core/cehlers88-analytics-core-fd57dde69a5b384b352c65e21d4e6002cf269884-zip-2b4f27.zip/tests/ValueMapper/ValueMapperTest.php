<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\ValueMapper;

use Cehlers88\AnalyticsCore\Support\DTO\CurlResponseDTO;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\ConditionInterface;
use Cehlers88\AnalyticsCore\ValueMapper\MappingSubject;
use Cehlers88\AnalyticsCore\ValueMapper\Transformer\TransformerInterface;
use Cehlers88\AnalyticsCore\ValueMapper\ValueMapper;
use Cehlers88\AnalyticsCore\ValueMapper\ValueMapperFactory;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

/**
 * The mapper as it is meant to be used: the definitions of one external
 * function, stored as arrays, applied to its responses.
 */
class ValueMapperTest extends TestCase
{
    private ValueMapper $mapper;

    protected function setUp(): void
    {
        $this->mapper = new ValueMapperFactory()->createMapper([
            [
                'name' => 'not_found',
                'conditions' => [['type' => 'status', 'value' => 404]],
                'rules' => [
                    ['target' => 'items', 'const' => []],
                    ['target' => 'total', 'const' => 0],
                ],
            ],
            [
                'name' => 'ok_v1_legacy',
                'priority' => 5,
                'conditions' => [
                    ['type' => 'status', 'value' => '2xx'],
                    ['type' => 'pathExists', 'path' => 'items'],
                ],
                'rules' => [
                    ['target' => 'items', 'source' => 'items', 'required' => true],
                    ['target' => 'total', 'source' => 'count', 'transforms' => [['type' => 'cast', 'to' => 'int']]],
                ],
            ],
            [
                'name' => 'ok_v2',
                'priority' => 10,
                'conditions' => [
                    ['type' => 'status', 'value' => '2xx'],
                    ['type' => 'pathExists', 'path' => 'data.items'],
                ],
                'rules' => [
                    ['target' => 'items', 'source' => 'data.items', 'required' => true],
                    ['target' => 'total', 'source' => 'data.meta.total', 'default' => 0, 'transforms' => ['trim', ['type' => 'cast', 'to' => 'int']]],
                    ['target' => 'ids', 'source' => 'data.items.*.id', 'transforms' => [['type' => 'cast', 'to' => 'string']]],
                    ['target' => 'meta.state', 'source' => 'data.state', 'transforms' => [['type' => 'map', 'map' => ['ACTIVE' => 'active']]]],
                ],
            ],
        ]);
    }

    public function testPicksTheDefinitionMatchingTheResponse(): void
    {
        $v2 = $this->mapper->map(new CurlResponseDTO(200, [
            'data' => ['items' => [['id' => 1], ['id' => 2]], 'meta' => ['total' => ' 2 '], 'state' => 'ACTIVE'],
        ]));

        $this->assertTrue($v2->isSuccess(), implode(', ', $v2->errors));
        $this->assertSame('ok_v2', $v2->definitionName);
        $this->assertSame([
            'items' => [['id' => 1], ['id' => 2]],
            'total' => 2,
            'ids' => ['1', '2'],
            'meta' => ['state' => 'active'],
        ], $v2->data);

        $v1 = $this->mapper->map(new CurlResponseDTO(200, ['items' => [['id' => 1]], 'count' => '1']));

        $this->assertSame('ok_v1_legacy', $v1->definitionName);
        $this->assertSame(['items' => [['id' => 1]], 'total' => 1], $v1->data);

        $notFound = $this->mapper->map(new CurlResponseDTO(404, 'Not Found'));

        $this->assertSame('not_found', $notFound->definitionName);
        $this->assertSame(['items' => [], 'total' => 0], $notFound->data);
        $this->assertSame(404, $notFound->raw->statusCode);
        $this->assertSame('Not Found', $notFound->raw->body);
    }

    public function testDefaultsAndOptionalRules(): void
    {
        $result = $this->mapper->map(new CurlResponseDTO(200, ['data' => ['items' => []]]));

        $this->assertTrue($result->isSuccess());
        $this->assertSame(['items' => [], 'total' => 0, 'ids' => []], $result->data);
    }

    public function testReportsEveryDeviationOfAMatchingDefinition(): void
    {
        $result = $this->mapper->map(new CurlResponseDTO(201, [
            'data' => ['items' => null, 'meta' => ['total' => 'many'], 'state' => 'ARCHIVED'],
        ]));

        $this->assertFalse($result->isSuccess());
        $this->assertSame('ok_v2', $result->definitionName);
        $this->assertCount(3, $result->errors);
        $this->assertStringStartsWith('items: Required source "data.items"', $result->errors[0]);
        $this->assertStringStartsWith('total: Cannot cast "many" to int', $result->errors[1]);
        $this->assertStringStartsWith('meta.state: No mapping for "ARCHIVED"', $result->errors[2]);
    }

    public function testReportsAnUnknownResponseShape(): void
    {
        $result = $this->mapper->map(new CurlResponseDTO(500, ['error' => 'boom']));

        $this->assertFalse($result->isSuccess());
        $this->assertNull($result->definitionName);
        $this->assertNull($result->data);
        $this->assertSame(['error' => 'boom'], $result->raw->body);
    }

    public function testPlainValuesHaveNoStatusCode(): void
    {
        $mapper = new ValueMapperFactory()->createMapper([
            ['name' => 'http', 'priority' => 1, 'conditions' => [['type' => 'status', 'value' => '2xx']], 'rules' => [['target' => 'via', 'const' => 'http']]],
            ['name' => 'fallback', 'rules' => [['target' => '', 'source' => '']]],
        ]);

        $result = $mapper->map(['untouched' => true]);

        $this->assertSame('fallback', $result->definitionName);
        $this->assertSame(['untouched' => true], $result->data);
    }

    public function testEqualPrioritiesKeepTheirOrder(): void
    {
        $mapper = new ValueMapperFactory()->createMapper([
            ['name' => 'first'],
            ['name' => 'second'],
        ]);

        $this->assertSame('first', $mapper->map(null)->definitionName);
        $this->assertSame(['first', 'second'], array_map(static fn($d) => $d->name, $mapper->getDefinitions()));
    }

    public function testCompositeConditionsFromArrays(): void
    {
        $mapper = new ValueMapperFactory()->createMapper([
            [
                'name' => 'error_payload',
                'conditions' => [[
                    'type' => 'anyOf',
                    'conditions' => [
                        ['type' => 'pathEquals', 'path' => 'ok', 'value' => false],
                        ['type' => 'not', 'condition' => ['type' => 'pathExists', 'path' => 'result']],
                    ],
                ]],
                'rules' => [['target' => 'error', 'source' => 'message', 'default' => 'unknown']],
            ],
            ['name' => 'success', 'rules' => [['target' => '', 'source' => 'result']]],
        ]);

        $this->assertSame(['error' => 'nope'], $mapper->map(['ok' => false, 'message' => 'nope', 'result' => 1])->data);
        $this->assertSame(['error' => 'unknown'], $mapper->map(['ok' => true])->data);
        $this->assertSame(42, $mapper->map(['ok' => true, 'result' => 42])->data);
    }

    public function testCustomConditionAndTransformerTypes(): void
    {
        $factory = new ValueMapperFactory()
            ->registerCondition('isList', static fn(array $c) => new class implements ConditionInterface {
                public function matches(MappingSubject $subject): bool
                {
                    return is_array($subject->body) && array_is_list($subject->body);
                }
            })
            ->registerTransformer('upper', static fn(array $t) => new class implements TransformerInterface {
                public function transform(mixed $value): mixed
                {
                    return strtoupper((string)$value);
                }
            });

        $mapper = $factory->createMapper([
            ['conditions' => [['type' => 'isList']], 'rules' => [['target' => 'names', 'source' => '*.name', 'transforms' => ['upper']]]],
        ]);

        $result = $mapper->map([['name' => 'a'], ['name' => 'b']]);

        $this->assertSame('#0', $result->definitionName);
        $this->assertSame(['names' => ['A', 'B']], $result->data);
    }

    public function testTypeErrorsOfCustomBuildersBecomeInvalidDefinitions(): void
    {
        $factory = new ValueMapperFactory()->registerCondition(
            'typed',
            static fn(array $c) => new \Cehlers88\AnalyticsCore\ValueMapper\Condition\PathExistsCondition($c['path'] ?? null)
        );

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid options for "typed"');

        $factory->createCondition(['type' => 'typed']);
    }

    public static function invalidDefinitionProvider(): iterable
    {
        yield 'unknown condition' => [['conditions' => [['type' => 'nope']]], 'Unknown condition type "nope"'];
        yield 'unknown transformer' => [['rules' => [['target' => 'a', 'source' => 'a', 'transforms' => ['nope']]]], 'Unknown transformer type "nope"'];
        yield 'rule without source' => [['rules' => [['target' => 'a']]], 'needs either "source" or "const"'];
        yield 'rule with both' => [['rules' => [['target' => 'a', 'source' => 'a', 'const' => 1]]], 'needs either "source" or "const"'];
        yield 'wildcard target' => [['rules' => [['target' => 'a.*', 'source' => 'a']]], 'must not contain "*"'];
        yield 'missing option' => [['conditions' => [['type' => 'pathExists']]], '"pathExists" needs "path"'];
        yield 'bad status' => [['conditions' => [['type' => 'status', 'value' => 'ok']]], 'Invalid status pattern'];
        yield 'null status' => [['conditions' => [['type' => 'status', 'value' => null]]], '"status": "value" must be a status pattern'];
        yield 'float status' => [['conditions' => [['type' => 'status', 'value' => 2.5]]], '"status": "value" must be a status pattern'];
        yield 'nested status list' => [['conditions' => [['type' => 'status', 'value' => [200, [404]]]]], '"status": "value" must be a status pattern'];
        yield 'empty status list' => [['conditions' => [['type' => 'status', 'value' => []]]], '"status": "value" must not be empty'];
        yield 'header value array' => [['conditions' => [['type' => 'header', 'name' => 'x', 'value' => ['a']]]], '"header": "value" must be a string'];
        yield 'date format array' => [['rules' => [['target' => 'a', 'source' => 'a', 'transforms' => [['type' => 'date', 'to' => ['Y']]]]]], '"date": "to" must be a string'];
        yield 'bad priority' => [['priority' => 'high'], '"priority" must be an integer'];
    }

    #[DataProvider('invalidDefinitionProvider')]
    public function testInvalidDefinitionsFailWhenBuilt(array $definition, string $message): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage($message);

        new ValueMapperFactory()->createDefinition(['name' => 'broken'] + $definition);
    }
}
