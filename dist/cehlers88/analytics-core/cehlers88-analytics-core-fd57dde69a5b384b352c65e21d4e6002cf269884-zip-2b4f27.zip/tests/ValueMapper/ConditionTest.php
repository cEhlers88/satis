<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\ValueMapper;

use Cehlers88\AnalyticsCore\ValueMapper\Condition\AllOfCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\AnyOfCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\HeaderCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\NotCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\PathEqualsCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\PathExistsCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\PathMatchesCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\StatusCondition;
use Cehlers88\AnalyticsCore\ValueMapper\MappingSubject;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class ConditionTest extends TestCase
{
    public static function statusProvider(): iterable
    {
        yield 'exact' => [404, 404, true];
        yield 'exact miss' => [404, 400, false];
        yield 'class' => ['2xx', 204, true];
        yield 'class miss' => ['2xx', 301, false];
        yield 'range' => ['500-504', 503, true];
        yield 'range miss' => ['500-504', 505, false];
        yield 'list' => [[200, '4xx'], 422, true];
    }

    #[DataProvider('statusProvider')]
    public function testStatus(int|string|array $pattern, int $status, bool $expected): void
    {
        $this->assertSame($expected, new StatusCondition($pattern)->matches(new MappingSubject([], $status)));
    }

    public function testStatusNeverMatchesWithoutStatusCode(): void
    {
        $this->assertFalse(new StatusCondition('2xx')->matches(new MappingSubject([])));
    }

    public function testStatusRejectsInvalidPattern(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        new StatusCondition('2x');
    }

    public function testPathConditions(): void
    {
        $subject = new MappingSubject(['state' => 'ACTIVE', 'count' => 1, 'flag' => true, 'empty' => null]);

        $this->assertTrue(new PathExistsCondition('empty')->matches($subject));
        $this->assertFalse(new PathExistsCondition('missing')->matches($subject));

        $this->assertTrue(new PathEqualsCondition('state', 'ACTIVE')->matches($subject));
        $this->assertTrue(new PathEqualsCondition('count', '1')->matches($subject));
        $this->assertFalse(new PathEqualsCondition('count', '1', strict: true)->matches($subject));
        $this->assertTrue(new PathEqualsCondition('flag', 'true')->matches($subject));
        $this->assertFalse(new PathEqualsCondition('missing', null)->matches($subject));
        $this->assertTrue(new PathEqualsCondition('empty', null, strict: true)->matches($subject));

        $this->assertTrue(new PathMatchesCondition('state', '/^act/i')->matches($subject));
        $this->assertFalse(new PathMatchesCondition('empty', '/.*/')->matches($subject));
    }

    public function testPathMatchesRejectsInvalidPattern(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        new PathMatchesCondition('state', 'no delimiters');
    }

    public function testHeader(): void
    {
        $subject = new MappingSubject([], 200, ['Content-Type' => 'application/json', 'X-Api-Version' => ['1', '2']]);

        $this->assertTrue(new HeaderCondition('content-type')->matches($subject));
        $this->assertTrue(new HeaderCondition('x-api-version', '2')->matches($subject));
        $this->assertFalse(new HeaderCondition('x-api-version', '3')->matches($subject));
        $this->assertFalse(new HeaderCondition('x-missing')->matches($subject));
    }

    public function testComposites(): void
    {
        $subject = new MappingSubject(['a' => 1], 200);
        $yes = new PathExistsCondition('a');
        $no = new PathExistsCondition('b');

        $this->assertTrue(new AllOfCondition($yes, new StatusCondition(200))->matches($subject));
        $this->assertFalse(new AllOfCondition($yes, $no)->matches($subject));
        $this->assertTrue(new AnyOfCondition($no, $yes)->matches($subject));
        $this->assertFalse(new AnyOfCondition()->matches($subject));
        $this->assertTrue(new NotCondition($no)->matches($subject));
    }
}
