<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\ValueMapper;

use Cehlers88\AnalyticsCore\ValueMapper\PathAccessor;
use PHPUnit\Framework\TestCase;

class PathAccessorTest extends TestCase
{
    private const array DATA = [
        'data' => [
            'items' => [
                ['id' => 1, 'name' => 'a'],
                ['id' => 2],
                ['id' => 3, 'name' => null],
            ],
            'meta' => ['total' => '3'],
        ],
    ];

    public function testReadsNestedPathsAndListIndexes(): void
    {
        $this->assertSame('3', PathAccessor::get(self::DATA, 'data.meta.total'));
        $this->assertSame(2, PathAccessor::get(self::DATA, 'data.items.1.id'));
        $this->assertSame(self::DATA, PathAccessor::get(self::DATA, ''));
    }

    public function testDistinguishesMissingFromNull(): void
    {
        $this->assertTrue(PathAccessor::has(self::DATA, 'data.items.2.name'));
        $this->assertFalse(PathAccessor::has(self::DATA, 'data.items.1.name'));
        $this->assertFalse(PathAccessor::has(self::DATA, 'data.meta.total.deeper'));
        $this->assertSame('fallback', PathAccessor::get(self::DATA, 'nope', 'fallback'));
    }

    public function testWildcardCollectsFoundValuesOnly(): void
    {
        $this->assertSame([1, 2, 3], PathAccessor::get(self::DATA, 'data.items.*.id'));
        $this->assertSame(['a', null], PathAccessor::get(self::DATA, 'data.items.*.name'));
        $this->assertFalse(PathAccessor::has(self::DATA, 'data.meta.total.*'));
    }

    public function testReadsObjects(): void
    {
        $object = json_decode('{"a": {"b": [10, 20]}}');

        $this->assertSame(20, PathAccessor::get($object, 'a.b.1'));
        $this->assertSame(10, PathAccessor::get(new \ArrayObject(['x' => 10]), 'x'));
    }

    public function testSetBuildsNestedArrays(): void
    {
        $data = PathAccessor::set([], 'a.b', 1);
        $data = PathAccessor::set($data, 'a.c', 2);
        $data = PathAccessor::set($data, 'd', 3);

        $this->assertSame(['a' => ['b' => 1, 'c' => 2], 'd' => 3], $data);
        $this->assertSame('whole', PathAccessor::set($data, '', 'whole'));
    }

    public function testSetRejectsWildcards(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        PathAccessor::set([], 'a.*', 1);
    }
}
