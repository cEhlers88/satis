<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\ValueMapper;

use Cehlers88\AnalyticsCore\ValueMapper\Transformer\CastTransformer;
use Cehlers88\AnalyticsCore\ValueMapper\Transformer\DateTransformer;
use Cehlers88\AnalyticsCore\ValueMapper\Transformer\MapTransformer;
use Cehlers88\AnalyticsCore\ValueMapper\Transformer\TrimTransformer;
use Cehlers88\AnalyticsCore\ValueMapper\ValueMapperException;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class TransformerTest extends TestCase
{
    public static function castProvider(): iterable
    {
        yield ['string', 1, '1'];
        yield ['string', 1.5, '1.5'];
        yield ['string', true, 'true'];
        yield ['string', false, 'false'];
        yield ['int', '2', 2];
        yield ['integer', ' -7 ', -7];
        yield ['int', 3.0, 3];
        yield ['int', true, 1];
        yield ['int', '007', 7];
        yield ['int', '9223372036854775807', PHP_INT_MAX];
        yield ['int', '-9223372036854775808', PHP_INT_MIN];
        yield ['float', '1.25', 1.25];
        yield ['float', 2, 2.0];
        yield ['bool', 'yes', true];
        yield ['bool', '0', false];
        yield ['bool', 0, false];
        yield ['array', 'x', ['x']];
        yield ['array', ['x'], ['x']];
        yield ['int', null, null];
    }

    #[DataProvider('castProvider')]
    public function testCast(string $type, mixed $input, mixed $expected): void
    {
        $this->assertSame($expected, new CastTransformer($type)->transform($input));
    }

    public static function invalidCastProvider(): iterable
    {
        yield ['int', 'abc'];
        yield ['int', 1.5];
        yield ['float', 'abc'];
        yield ['bool', 'maybe'];
        yield ['string', ['a']];
        yield 'int beyond range' => ['int', '999999999999999999999'];
        yield 'negative int beyond range' => ['int', '-9223372036854775809'];
        yield 'float beyond int range' => ['int', 1e20];
    }

    #[DataProvider('invalidCastProvider')]
    public function testCastRefusesMeaninglessValues(string $type, mixed $input): void
    {
        $this->expectException(ValueMapperException::class);
        new CastTransformer($type)->transform($input);
    }

    public function testCastRejectsUnknownType(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        new CastTransformer('object');
    }

    public function testTrim(): void
    {
        $this->assertSame('a', new TrimTransformer()->transform(" a\n"));
        $this->assertSame('a', new TrimTransformer('/')->transform('/a/'));
        $this->assertSame(5, new TrimTransformer()->transform(5));
    }

    public function testMap(): void
    {
        $map = new MapTransformer(['ACTIVE' => 'active', '1' => 'one', 'true' => 'yes']);

        $this->assertSame('active', $map->transform('ACTIVE'));
        $this->assertSame('one', $map->transform(1));
        $this->assertSame('yes', $map->transform(true));

        $this->assertSame('unknown', new MapTransformer([], true, 'unknown')->transform('NEW'));
        $this->assertNull(new MapTransformer([], true)->transform('NEW'));

        $this->expectException(ValueMapperException::class);
        $map->transform('NEW');
    }

    public function testDate(): void
    {
        $this->assertSame('2026-09-29', new DateTransformer(to: 'Y-m-d')->transform('2026-09-29T10:00:00+02:00'));
        $this->assertSame('2026-09-29 08:00', new DateTransformer(to: 'Y-m-d H:i', timezone: 'UTC')->transform('2026-09-29T10:00:00+02:00'));
        $this->assertSame('2026-09-29', new DateTransformer('d.m.Y', 'Y-m-d')->transform('29.09.2026'));
        $this->assertSame('1970-01-02', new DateTransformer(to: 'Y-m-d')->transform(86400));
        $this->assertNull(new DateTransformer()->transform(null));

        $this->expectException(ValueMapperException::class);
        new DateTransformer('d.m.Y')->transform('2026-09-29');
    }

    public function testDateRejectsDatesTheParserWouldRollOver(): void
    {
        foreach ([new DateTransformer('Y-m-d'), new DateTransformer()] as $transformer) {
            try {
                $transformer->transform('2026-02-31');
                $this->fail('2026-02-31 must not become a date.');
            } catch (ValueMapperException $e) {
                $this->assertStringContainsString('2026-02-31', $e->getMessage());
            }
        }
    }

    public function testDateRejectsGarbage(): void
    {
        $this->expectException(ValueMapperException::class);
        new DateTransformer()->transform('not a date');
    }
}
