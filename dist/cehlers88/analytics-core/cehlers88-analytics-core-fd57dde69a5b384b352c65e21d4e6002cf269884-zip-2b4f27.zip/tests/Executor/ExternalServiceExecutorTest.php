<?php

namespace Cehlers88\AnalyticsCore\Tests\Executor;

use Cehlers88\AnalyticsCore\Entity\ExternalServiceFunction;
use Cehlers88\AnalyticsCore\Executor\ExternalServiceExecutor;
use Cehlers88\AnalyticsCore\Interface\Repository\IExternalServiceFunctionRepository;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Provider\ExternalServiceProvider;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Interface\ExternalService\IExecutionAdapter;
use Cehlers88\AnalyticsCore\Support\DTO\CurlResponseDTO;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerProvider;
use Cehlers88\AnalyticsCore\ValueMapper\ValueMapperResultDTO;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class ExternalServiceExecutorTest extends TestCase
{
    private MockObject $commandPlayer;
    private MockObject $externalServiceProvider;
    private MockObject $externalServiceFunctionRepository;
    private MockObject $variablesProvider;
    private LoggerProvider $loggerProvider;

    public function test_is_running_and_wants_to_rerun_are_always_false(): void
    {
        $executor = $this->createExecutor();

        $this->assertFalse($executor->isRunning());
        $this->assertFalse($executor->wantsToReRun());
    }

    private function createExecutor(): ExternalServiceExecutor
    {
        return new ExternalServiceExecutor(
            $this->externalServiceProvider,  // 1st: ExternalServiceProvider
            $this->externalServiceFunctionRepository,  // 2nd: ExternalServiceFunctionRepository
            $this->loggerProvider  // 3rd: LoggerProvider
        );
    }

    public function test_is_valid_requires_service_name_and_function_name(): void
    {
        $executor = $this->createExecutor();

        $this->assertFalse($executor->isValid());

        $executor
            ->setPropertyValue(ExternalServiceExecutor::KEY_SERVICE_NAME, 'myService')
            ->setPropertyValue(ExternalServiceExecutor::KEY_ARGUMENTS, [])
            ->setPropertyValue(ExternalServiceExecutor::KEY_OPTIONS, []);

        $this->assertFalse($executor->isValid());

        $executor->setPropertyValue(ExternalServiceExecutor::KEY_FUNCTION_NAME, 'myFunction');

        $this->assertTrue($executor->isValid());
    }

    public function test_run_reports_an_error_when_the_service_is_unknown(): void
    {
        $exception = new \Exception('Service "unknown" not found');

        $this->externalServiceProvider->expects($this->once())
            ->method('getExecutionAdapterByName')
            ->willThrowException($exception);

        $executor = $this->createExecutor();
        $executor
            ->setPropertyValue(ExternalServiceExecutor::KEY_SERVICE_NAME, 'unknown')
            ->setPropertyValue(ExternalServiceExecutor::KEY_FUNCTION_NAME, 'myFunction')
            ->setPropertyValue(ExternalServiceExecutor::KEY_ARGUMENTS, [])
            ->setPropertyValue(ExternalServiceExecutor::KEY_OPTIONS, []);

        $executor->run();

        $this->assertTrue($executor->hasError());
        $this->assertStringContainsString('Service "unknown" not found', $executor->getErrorsAsString());
        $this->assertSame($exception, $executor->getLastResult());
    }

    public function test_run_is_skipped_when_required_properties_are_missing(): void
    {
        $this->externalServiceProvider->expects($this->never())
            ->method('getExecutionAdapterByName');

        $executor = $this->createExecutor();
        $executor->run();

        $this->assertTrue($executor->hasError());
        $this->assertNull($executor->getLastResult());
    }

    public function test_run_hands_on_the_raw_response_without_response_mappings(): void
    {
        $response = new CurlResponseDTO(200, ['a' => 1]);
        $this->expectCall($response, static fn(array $overrides) => !array_key_exists(ExternalServiceExecutor::OPTION_THROW_ON_HTTP_ERROR, $overrides));
        $this->givenFunctionWithMappings([]);

        $executor = $this->createConfiguredExecutor();
        $executor->run();

        $this->assertFalse($executor->hasError(), $executor->getErrorsAsString());
        $this->assertSame($response, $executor->getLastResult());
    }

    public function test_run_maps_the_response_and_accepts_error_statuses(): void
    {
        $this->expectCall(
            new CurlResponseDTO(404, 'Not Found'),
            static fn(array $overrides) => ($overrides[ExternalServiceExecutor::OPTION_THROW_ON_HTTP_ERROR] ?? null) === false
        );
        $this->givenFunctionWithMappings([
            ['name' => 'ok', 'conditions' => [['type' => 'status', 'value' => '2xx']], 'rules' => [['target' => 'items', 'source' => 'items']]],
            ['name' => 'not_found', 'conditions' => [['type' => 'status', 'value' => 404]], 'rules' => [['target' => 'items', 'const' => []]]],
        ]);

        $executor = $this->createConfiguredExecutor();
        $executor->run();

        $this->assertFalse($executor->hasError(), $executor->getErrorsAsString());
        $result = $executor->getLastResult();
        $this->assertInstanceOf(ValueMapperResultDTO::class, $result);
        $this->assertSame('not_found', $result->definitionName);
        $this->assertSame(['items' => []], $result->data);
    }

    public function test_run_reports_a_response_no_definition_expects(): void
    {
        $this->expectCall(new CurlResponseDTO(500, ['error' => 'boom']));
        $this->givenFunctionWithMappings([
            ['name' => 'ok', 'conditions' => [['type' => 'status', 'value' => '2xx']], 'rules' => [['target' => '', 'source' => '']]],
        ]);

        $executor = $this->createConfiguredExecutor();
        $executor->run();

        $this->assertTrue($executor->hasError());
        $this->assertStringContainsString('Response mapping failed', $executor->getErrorsAsString());
        $this->assertSame(['error' => 'boom'], $executor->getLastResult()->raw->body);
    }

    public function test_run_refuses_to_call_with_invalid_response_mappings(): void
    {
        $adapter = $this->createMock(IExecutionAdapter::class);
        $adapter->expects($this->never())->method('callFunction');
        $this->externalServiceProvider->method('getExecutionAdapterByName')->willReturn($adapter);
        $this->givenFunctionWithMappings([['conditions' => [['type' => 'nope']]]]);

        $executor = $this->createConfiguredExecutor();
        $executor->run();

        $this->assertTrue($executor->hasError());
        $this->assertStringContainsString('Invalid response mapping', $executor->getErrorsAsString());
    }

    private function createConfiguredExecutor(): ExternalServiceExecutor
    {
        return $this->createExecutor()
            ->setPropertyValue(ExternalServiceExecutor::KEY_SERVICE_NAME, 'myService')
            ->setPropertyValue(ExternalServiceExecutor::KEY_FUNCTION_NAME, 'myFunction')
            ->setPropertyValue(ExternalServiceExecutor::KEY_ARGUMENTS, [])
            ->setPropertyValue(ExternalServiceExecutor::KEY_OPTIONS, []);
    }

    private function expectCall(mixed $response, ?\Closure $checkOverrides = null): IExecutionAdapter
    {
        $adapter = $this->createMock(IExecutionAdapter::class);
        $adapter->expects($this->once())
            ->method('callFunction')
            ->with('myFunction', [], $this->callback($checkOverrides ?? static fn() => true))
            ->willReturn($response);
        $this->externalServiceProvider->method('getExecutionAdapterByName')->willReturn($adapter);

        return $adapter;
    }

    private function givenFunctionWithMappings(array $mappings): void
    {
        $this->externalServiceFunctionRepository
            ->expects($this->once())
            ->method('findOneByServiceAndName')
            ->with('myService', 'myFunction')
            ->willReturn(new ExternalServiceFunction()->setResponseMappings($mappings));
    }

    protected function setUp(): void
    {
        parent::setUp();

        // Create mocks/stubs in the correct order
        $this->commandPlayer = $this->createMock(CommandPlayer::class);
        $this->externalServiceProvider = $this->createMock(ExternalServiceProvider::class);
        $this->externalServiceFunctionRepository = $this->createMock(IExternalServiceFunctionRepository::class);
        $this->variablesProvider = $this->createMock(VariablesProvider::class);
        $this->loggerProvider = $this->createMock(LoggerProvider::class);
    }
}
