<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpFoundation\Request;

class AbstractServiceEndpointRunnerVariantTest extends TestCase
{
    public function test_the_shared_parameter_picks_the_variant_from_the_body(): void
    {
        $runner = $this->createZipRunner();

        $first = $runner->runEndpoint('zip', Request::create('/api/se/zip', 'POST', ['action' => 'act1']));
        $second = $runner->runEndpoint('zip', Request::create('/api/se/zip', 'POST', ['action' => 'act2', 'actionProp' => 'x']));

        $this->assertFalse($first->hasError, $first->message);
        $this->assertSame('first', $first->data['variant']);
        $this->assertFalse($second->hasError, $second->message);
        $this->assertSame('second', $second->data['variant']);
    }

    public function test_a_post_request_can_pick_the_variant_by_its_query_string(): void
    {
        $runner = $this->createZipRunner();

        $result = $runner->runEndpoint('zip', Request::create('/api/se/zip?action=act2&actionProp=x', 'POST'));

        $this->assertFalse($result->hasError, $result->message);
        $this->assertSame('second', $result->data['variant']);
        $this->assertSame('x', $result->data['values']['actionProp']);
    }

    public function test_a_json_body_picks_the_variant_as_well(): void
    {
        $runner = $this->createZipRunner();

        $request = Request::create('/api/se/zip', 'POST', [], [], [], ['CONTENT_TYPE' => 'application/json'], '{"action":"act1"}');
        $result = $runner->runEndpoint('zip', $request);

        $this->assertSame('first', $result->data['variant']);
    }

    public function test_the_variant_validates_its_own_parameters(): void
    {
        $runner = $this->createZipRunner();

        $result = $runner->runEndpoint('zip', Request::create('/api/se/zip?action=act2', 'POST'));

        $this->assertTrue($result->hasError);
        $this->assertStringContainsString('actionProp', $result->message);
    }

    public function test_a_value_no_variant_declares_is_answered_with_the_expected_values(): void
    {
        $runner = $this->createZipRunner();

        $this->assertTrue($runner->canHandle('zip', Request::create('/api/se/zip?action=act3', 'POST')));
        $result = $runner->runEndpoint('zip', Request::create('/api/se/zip?action=act3', 'POST'));

        $this->assertTrue($result->hasError);
        $this->assertSame(400, $result->statusCode);
        $this->assertStringContainsString('action=act1 | action=act2', $result->message);
    }

    public function test_a_method_no_variant_takes_is_not_handled(): void
    {
        $this->assertFalse($this->createZipRunner()->canHandle('zip', Request::create('/api/se/zip?action=act1')));
    }

    public function test_variants_nothing_tells_apart_are_reported_as_error(): void
    {
        $runner = new VariantTestRunner([
            EndpointDefinitionDTO::create('zip', ['POST'], [PropertyDTO::create('action', 'act1', 'string')]),
            EndpointDefinitionDTO::create('zip', ['POST'], [PropertyDTO::create('action', 'act1', 'string')]),
        ]);

        $runner->getEndpointDefinitions();

        $this->assertTrue($runner->hasError());
        $this->assertStringContainsString('zip', (string)$runner->getErrorMessage());
    }

    public function test_an_endpoint_without_variants_still_works_as_before(): void
    {
        $runner = new VariantTestRunner([
            EndpointDefinitionDTO::create('single', ['GET'], [PropertyDTO::create('name', null, 'string')], [], '', static fn(array $values) => ServiceEndpointRunnerResultDTO::createSuccess($values)),
        ]);

        $result = $runner->runEndpoint('single', Request::create('/api/se/single?name=foo'));

        $this->assertFalse($runner->hasError());
        $this->assertSame(['name' => 'foo'], $result->data);
    }

    public function test_a_needle_the_query_and_the_body_name_differently_is_refused(): void
    {
        $runner = $this->createZipRunner();
        $request = Request::create('/api/se/zip?action=act1', 'POST', [], [], [], ['CONTENT_TYPE' => 'application/json'], '{"action":"act2","actionProp":"x"}');

        $result = $runner->runEndpoint('zip', $request);

        $this->assertTrue($result->hasError);
        $this->assertSame(400, $result->statusCode);
        $this->assertSame("Conflicting values for 'action': 'act1' in the query string, 'act2' in the body", $result->message);
    }

    public function test_the_same_needle_in_query_and_body_is_no_conflict(): void
    {
        $runner = $this->createZipRunner();
        $request = Request::create('/api/se/zip?action=act1', 'POST', ['action' => 'act1']);

        $this->assertSame('first', $runner->runEndpoint('zip', $request)->data['variant']);
    }

    public function test_a_variant_without_handler_says_which_variant_was_reached(): void
    {
        $runner = new VariantTestRunner([
            EndpointDefinitionDTO::create('zip', ['POST'], [PropertyDTO::create('action', 'act1', 'string')], [], '', static fn() => ServiceEndpointRunnerResultDTO::createSuccess('ok')),
            EndpointDefinitionDTO::create('zip', ['POST'], [PropertyDTO::create('action', 'act2', 'string')]),
        ]);

        $result = $runner->runEndpoint('zip', Request::create('/api/se/zip', 'POST', ['action' => 'act2']));

        $this->assertSame("Not implemented: endpoint 'zip' (action=act2) has no handler", $result->message);
    }

    public function test_a_file_sent_with_a_form_reaches_the_handler(): void
    {
        $runner = new VariantTestRunner([
            EndpointDefinitionDTO::create('upload', ['POST'], [PropertyDTO::create('file', null, 'file')], [], '', static fn(array $values) => ServiceEndpointRunnerResultDTO::createSuccess($values)),
        ]);
        $path = tempnam(sys_get_temp_dir(), 'upl');
        file_put_contents($path, 'x');
        $file = new \Symfony\Component\HttpFoundation\File\UploadedFile($path, 'a.txt', 'text/plain', null, true);

        $result = $runner->runEndpoint('upload', Request::create('/api/se/upload', 'POST', ['name' => 'a'], [], ['file' => $file]));

        $this->assertFalse($result->hasError, $result->message);
        $this->assertSame('a', $result->data['name']);
        $this->assertSame($file, $result->data['file']);
        unlink($path);
    }

    private function createZipRunner(): VariantTestRunner
    {
        $handler = static fn(array $values, EndpointDefinitionDTO $definition) => ServiceEndpointRunnerResultDTO::createSuccess([
            'variant' => $definition->description,
            'values' => $values,
        ]);

        return new VariantTestRunner([
            EndpointDefinitionDTO::create('zip', ['POST'], [
                PropertyDTO::create('action', 'act1', 'string'),
            ], [], 'first', $handler),
            EndpointDefinitionDTO::create('zip', ['POST'], [
                PropertyDTO::create('action', 'act2', 'string'),
                PropertyDTO::create('actionProp', 'irgendwas', 'string'),
            ], [], 'second', $handler),
        ]);
    }
}

class VariantTestRunner extends AbstractServiceEndpointRunner
{
    /** @param EndpointDefinitionDTO[] $definitions */
    public function __construct(array $definitions)
    {
        foreach ($definitions as $definition) {
            $this->registerEndpoint($definition);
        }
    }

    public function getBundleName(): string
    {
        return '';
    }

    public function getRequiredRoles(): array
    {
        return [];
    }
}
