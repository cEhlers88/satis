<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\DTO\ValidationResultDTO;
use Cehlers88\AnalyticsCore\Security\Doorman;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\EndpointResponseExamples;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpFoundation\Request;

class EndpointResponseExamplesTest extends TestCase
{
    public function test_declared_examples_are_shown_as_they_are(): void
    {
        $definition = EndpointDefinitionDTO::create('ping', ['GET'])
            ->withSuccessExample('pong')
            ->withErrorExample('Kaputt', 503, ['retry' => true]);

        $examples = EndpointResponseExamples::forDefinition(new VariantTestRunner([$definition]), $definition, [$definition]);

        $this->assertTrue($examples['success']['declared']);
        $this->assertSame('pong', $examples['success']['result']->data);
        $this->assertTrue($examples['error']['declared']);
        $this->assertSame(503, $examples['error']['result']->statusCode);
        $this->assertSame(['retry' => true], $examples['error']['result']->data);
    }

    public function test_an_undeclared_success_is_the_envelope_without_data(): void
    {
        $definition = EndpointDefinitionDTO::create('ping', ['GET']);

        $success = EndpointResponseExamples::forDefinition(new VariantTestRunner([$definition]), $definition, [$definition])['success'];

        $this->assertFalse($success['declared']);
        $this->assertSame(EndpointResponseExamples::REASON_SUCCESS_UNDECLARED, $success['reason']);
        $this->assertFalse($success['result']->hasError);
        $this->assertNull($success['result']->data);
    }

    public function test_a_missing_parameter_is_derived_as_the_runner_answers_it(): void
    {
        $definition = EndpointDefinitionDTO::create('upload', ['POST'], [
            PropertyDTO::create('mimeType', '', 'string', true),
            PropertyDTO::create('name', null, 'string'),
        ]);
        $runner = new VariantTestRunner([$definition]);

        $error = EndpointResponseExamples::forDefinition($runner, $definition, [$definition])['error'];
        $actual = $runner->runEndpoint('upload', Request::create('/api/se/upload', 'POST'));

        $this->assertSame(EndpointResponseExamples::REASON_PARAMETER, $error['reason']);
        $this->assertSame('name', $error['parameter']);
        $this->assertEquals($actual, $error['result']);
    }

    public function test_a_needle_matching_no_variant_is_derived_as_the_runner_answers_it(): void
    {
        $first = EndpointDefinitionDTO::create('zip', ['POST'], [PropertyDTO::create('action', 'act1', 'string')]);
        $second = EndpointDefinitionDTO::create('zip', ['POST'], [PropertyDTO::create('action', 'act2', 'string')]);
        $runner = new VariantTestRunner([$first, $second]);

        $error = EndpointResponseExamples::forDefinition($runner, $second, [$first, $second])['error'];
        $actual = $runner->runEndpoint('zip', Request::create('/api/se/zip?action=nope', 'POST'));

        $this->assertSame(EndpointResponseExamples::REASON_VARIANT, $error['reason']);
        $this->assertEquals($actual, $error['result']);
    }

    public function test_required_roles_are_derived_as_permission_denied(): void
    {
        $definition = EndpointDefinitionDTO::create('secret', ['GET'], [], [RoleDTO::create('ADMIN')]);
        $runner = new VariantTestRunner([$definition]);
        $doorman = $this->createStub(Doorman::class);
        $doorman->method('checkPermission')->willReturn(false);
        $doorman->method('getMessages')->willReturn([]);
        $doorman->method('getReasons')->willReturn([]);
        $runner->setDoorman($doorman);

        $error = EndpointResponseExamples::forDefinition($runner, $definition, [$definition])['error'];
        $actual = $runner->runEndpoint('secret', Request::create('/api/se/secret'));

        $this->assertSame(EndpointResponseExamples::REASON_PERMISSION, $error['reason']);
        $this->assertEquals($actual, $error['result']);
    }

    public function test_a_runner_with_its_own_validation_gets_no_parameter_message(): void
    {
        $definition = EndpointDefinitionDTO::create('upload', ['POST'], [PropertyDTO::create('name', null, 'string')]);
        $runner = new class([$definition]) extends VariantTestRunner {
            public function validate(string $endpointName, Request $request): ValidationResultDTO
            {
                return ValidationResultDTO::create(true);
            }
        };

        $error = EndpointResponseExamples::forDefinition($runner, $definition, [$definition])['error'];

        $this->assertSame(EndpointResponseExamples::REASON_GENERIC, $error['reason']);
        $this->assertSame(500, $error['result']->statusCode);
    }
}
