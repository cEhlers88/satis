<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\EndpointVariantResolver;
use PHPUnit\Framework\TestCase;

class EndpointVariantResolverTest extends TestCase
{
    public function test_a_parameter_all_variants_declare_alike_is_no_needle(): void
    {
        $variants = [
            EndpointDefinitionDTO::create('zip', ['POST'], [
                PropertyDTO::create('token', null, 'string'),
                PropertyDTO::create('action', 'act1', 'string'),
            ]),
            EndpointDefinitionDTO::create('zip', ['POST'], [
                PropertyDTO::create('token', null, 'string'),
                PropertyDTO::create('action', 'act2', 'string'),
                PropertyDTO::create('extra', 'x', 'string'),
            ]),
        ];

        $this->assertSame(['action'], EndpointVariantResolver::discriminatorNames($variants));
        $this->assertSame($variants[1], EndpointVariantResolver::resolve($variants, ['token' => 'abc', 'action' => 'act2']));
        $this->assertNull(EndpointVariantResolver::resolve($variants, ['token' => 'abc']));
        $this->assertNull(EndpointVariantResolver::findAmbiguity($variants));
    }

    public function test_typed_values_match_their_text_form(): void
    {
        $variants = [
            EndpointDefinitionDTO::create('count', ['POST'], [PropertyDTO::create('level', 1, 'int')]),
            EndpointDefinitionDTO::create('count', ['POST'], [PropertyDTO::create('level', 2, 'int')]),
        ];

        $this->assertSame($variants[1], EndpointVariantResolver::resolve($variants, ['level' => '2']));
    }

    public function test_two_variants_with_the_same_needle_values_are_ambiguous(): void
    {
        $variants = [
            EndpointDefinitionDTO::create('zip', ['POST'], [PropertyDTO::create('action', 'a', 'string'), PropertyDTO::create('mode', 'x', 'string')]),
            EndpointDefinitionDTO::create('zip', ['POST'], [PropertyDTO::create('action', 'b', 'string'), PropertyDTO::create('mode', 'x', 'string')]),
            EndpointDefinitionDTO::create('zip', ['POST'], [PropertyDTO::create('action', 'a', 'string'), PropertyDTO::create('mode', 'x', 'string')]),
        ];

        $this->assertStringContainsString('action=a', (string)EndpointVariantResolver::findAmbiguity($variants));
    }
}
