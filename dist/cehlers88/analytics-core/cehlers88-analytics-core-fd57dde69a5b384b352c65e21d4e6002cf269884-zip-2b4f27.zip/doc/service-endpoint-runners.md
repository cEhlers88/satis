# Service Endpoint Runners

A service endpoint runner answers requests to `/api/se/<name>`. It extends
`AbstractServiceEndpointRunner` and is picked up through the service tag
`analytics.service_endpoint_runner`.

## Registering endpoints

Endpoints are registered in the constructor as `EndpointDefinitionDTO`s:

```php
public function __construct()
{
    $this->registerEndpoint(EndpointDefinitionDTO::create(
        'observer_trigger',
        ['POST'],
        [PropertyDTO::create('message', 'system.update', 'string')],
        [],                              // required roles on top of getRequiredRoles()
        'Dispatches an observer message.',
        [$this, 'handleTriggerRequest']  // fn(array $values, EndpointDefinitionDTO $definition)
    ));
}
```

The endpoint name is prefixed with `getBundleName()` (`AnalyticsCore.<name>` by
default); a runner that returns `''` there keeps the plain name.

A handler gets the request values - the query string and, for any method but
GET, the form or JSON body on top of it - and the definition the request
reached. A runner without handlers overrides `handleRequest()` and asks
`resolveEndpointDefinition($endpointName, $request)` which definition it serves.

Non-optional parameters are checked before the handler runs (`validate()`).

## Variants: one name, several definitions

An endpoint may be registered more than once under the same name and method.
Each definition is a *variant*; the parameters **all** variants declare, with
**differing** values, are the needle that decides which one a request reaches:

```php
public function __construct()
{
    $this->registerEndpoint(EndpointDefinitionDTO::create('zip', ['POST'], [
        PropertyDTO::create('action', 'act1', 'string'),
    ]));
    $this->registerEndpoint(EndpointDefinitionDTO::create('zip', ['POST'], [
        PropertyDTO::create('action', 'act2', 'string'),
        PropertyDTO::create('actionProp', 'irgendwas', 'string'),
    ]));
}
```

- `action=act1` reaches the first variant, `action=act2` the second.
- The needle may come in the body or in the query string, so
  `POST /api/se/zip?action=act2` works just like a body with `action=act2`.
  If both carry it with different values, the request is refused with 400
  (`Conflicting values for 'action': …`) instead of silently letting the body
  win - for any other parameter the body wins.
- Values are compared as the text they are sent as (`1` matches `'1'`,
  `true` matches `'true'`).
- A parameter all variants declare with the *same* value (a shared `token`, say)
  is an ordinary parameter, not a needle.
- Each variant validates its own parameters and may have its own roles,
  description and handler.
- A request whose needle matches no variant is answered with 400 and the values
  that would match (`expected one of: action=act1 | action=act2`).
- A variant without handler (and a runner that does not override
  `handleRequest()`) answers `Not implemented: endpoint 'zip' (action=act2) has no handler`.

Variants a request cannot tell apart - no differing shared parameter, or two
variants with the same needle values - are reported as the runner's error
(`hasError()` / `getErrorMessage()`) instead of an exception, so one runner
cannot break every other endpoint; the service endpoint overview of the
dashboard shows the message. `EndpointVariantResolver` holds the rules.

## Example answers

The service endpoint overview of the dashboard shows an example of a successful
and of a failed answer for every definition. A definition declares them:

```php
EndpointDefinitionDTO::create('ping', ['GET'])
    ->withSuccessExample('pong')                       // data, optional message
    ->withErrorExample('Unknown type: foo', 400);      // message, statusCode, optional data
```

What it does not declare, `EndpointResponseExamples` derives - the error from
the first check of `runEndpoint()` the definition can fail, with the very
message that check answers:

1. a needle that matches no variant (400),
2. a missing required parameter, unless the runner overrides `validate()`,
3. missing roles (401),
4. otherwise the answer to an exception in the handler (500).

An undeclared success is the envelope without data, since only the handler
knows what it returns - declare it wherever the data is worth showing. Runners
answer with HTTP 200 in every case; `hasError` and `statusCode` in the body tell
whether the call succeeded.
