# Value Mapper

`Cehlers88\AnalyticsCore\ValueMapper` sits between a response - typically the result of an
external service function - and its evaluation:

```
response ──► ValueMapper ──► evaluation
```

The evaluation is written against one fixed shape. When an API changes its response, only the
mapping definitions change. Each definition describes one expected form of the response: when it
applies and how the fixed shape is built from it.

## Flow

1. The input is wrapped in a `MappingSubject` (`body`, `statusCode`, `headers`). A
   `CurlResponseDTO` provides all three; any other value becomes the body, without a status code.
2. The definitions are tried in order of **priority** (highest first; equal priorities in the
   order they were added). **The first one whose conditions all match wins.**
3. Its rules build the mapped value.
4. The result is a `ValueMapperResultDTO`:

| Field            | Meaning                                                       |
|------------------|---------------------------------------------------------------|
| `data`           | the mapped value (`null` if no definition matched)            |
| `definitionName` | the definition that was applied                               |
| `raw`            | the `MappingSubject` that was mapped - keep it for debugging  |
| `errors`         | deviations; `isSuccess()` is `true` only when there are none  |

Errors are the point of the exercise. "No value mapper definition matches the given value",
a missing required field, a value that cannot be cast or an unknown enum value is usually the
first sign that an API has changed. A matching definition applies all of its rules even after
one fails, so the result lists every deviation and still holds whatever could be mapped.

## External service functions

An `ExternalServiceFunction` carries its definitions in `responseMappings` (JSON column
`response_mappings`, empty = none). `ExternalServiceExecutor` then:

1. builds the mapper **before** calling the function - invalid definitions stop the call with
   an error (`ERR_RESPONSE_MAPPING`) instead of failing after its side effects;
2. passes the option `throwOnHttpError: false` to the execution adapter, so error statuses reach
   the mapper as `CurlResponseDTO` instead of being thrown (`CurlHelper::setThrowOnHttpError()`);
3. sets the `ValueMapperResultDTO` as `getLastResult()`. If no definition matches or a rule
   fails, the executor also reports an error - just as an error status did before - while the
   result still holds the raw response.

Without response mappings nothing changes: `getLastResult()` is the raw response, and any
status but 200 is thrown as before.

## Definitions

Definitions are plain arrays (stored as JSON) and are built by `ValueMapperFactory`:

```php
$mapper = new ValueMapperFactory()->createMapper($definitions);
$result = $mapper->map($curlResponse);

if (!$result->isSuccess()) {
    // log $result->errors, fall back, alert ...
}
```

```json
[
  {
    "name": "ok_v2",
    "priority": 10,
    "conditions": [
      {"type": "status", "value": "2xx"},
      {"type": "pathExists", "path": "data.items"}
    ],
    "rules": [
      {"target": "items", "source": "data.items", "required": true},
      {"target": "total", "source": "data.meta.total", "default": 0, "transforms": [{"type": "cast", "to": "int"}]},
      {"target": "ids", "source": "data.items.*.id"},
      {"target": "meta.state", "source": "data.state", "transforms": [{"type": "map", "map": {"ACTIVE": "active"}}]}
    ]
  },
  {
    "name": "not_found",
    "conditions": [{"type": "status", "value": 404}],
    "rules": [{"target": "items", "const": []}, {"target": "total", "const": 0}]
  }
]
```

| Key          | Meaning                                                          |
|--------------|------------------------------------------------------------------|
| `name`       | shown in the result; defaults to `#<index>`                      |
| `priority`   | integer, default `0`                                             |
| `conditions` | all must match; none means the definition always applies        |
| `rules`      | build the mapped value, starting from an empty array             |

A definition without conditions and with a low priority serves as a **fallback**; a rule
`{"target": "", "source": ""}` passes the body on unchanged.

The factory rejects invalid definitions (unknown types, missing options or options of the wrong
type, bad status patterns or regular expressions) with an `InvalidArgumentException` when they are **built**, not during
mapping.

## Paths

Dot paths always address the **body**: `data.items.0.id`. `""` is the whole body. `*` reads every
entry of a list and yields a list of the values found (`data.items.*.id`); entries without the
rest of the path are skipped. Arrays, `ArrayAccess` and public object properties can be read.
Target paths build nested arrays and must not contain `*`.

## Conditions

| `type`        | Options                            | Matches when                                                       |
|---------------|------------------------------------|--------------------------------------------------------------------|
| `status`      | `value`: `404`, `"2xx"`, `"500-504"` or a list of these | the status code fits; never for values without one |
| `pathExists`  | `path`                             | the path exists (even when its value is `null`)                    |
| `pathEquals`  | `path`, `value`, `strict` (false)  | the value equals; without `strict`, scalars compare as strings (`1` = `"1"`, `true` = `"true"`) |
| `pathMatches` | `path`, `pattern` (PCRE with delimiters) | the scalar value matches the regular expression               |
| `header`      | `name` (case-insensitive), `value` (optional) | the header is present / has the value                  |
| `allOf`       | `conditions`                       | all match                                                          |
| `anyOf`       | `conditions`                       | at least one matches                                               |
| `not`         | `condition`                        | the condition does not match                                       |

## Rules

| Key          | Meaning                                                                  |
|--------------|--------------------------------------------------------------------------|
| `target`     | where the value goes in the mapped value (`""` = the whole value)        |
| `source`     | path in the body - **or** -                                              |
| `const`      | a fixed value                                                            |
| `transforms` | applied in order; with a `*` source to each entry of the list            |
| `default`    | used as is (not transformed) when the source is missing or `null`        |
| `required`   | without a default, a missing or `null` source is an error                |

An optional rule whose source is missing leaves its target out; a source that exists with `null`
sets the target to `null`.

## Transformers

A transformer is given as `{"type": "...", ...options}`, or just as its type name (`"trim"`).

| `type` | Options                                         | Does                                                                  |
|--------|-------------------------------------------------|-----------------------------------------------------------------------|
| `cast` | `to`: `string`, `int`, `float`, `bool`, `array` | casts, but refuses meaningless values (`"abc"` → int, `1.5` → int, integers beyond the platform range); `null` stays `null` |
| `trim` | `characters` (optional)                         | trims strings, other values pass                                      |
| `map`  | `map` (lookup table), `default` (optional)      | translates values; an unknown value is an error unless a default is set |
| `date` | `from` (format, optional), `to` (default ATOM), `timezone` (optional) | reformats dates; integers are Unix timestamps; invalid dates (`2026-02-31`) are errors instead of rolled over |

A transformer that cannot do its job throws a `ValueMapperException`, which the mapping reports
as an error of the rule. It never returns a made-up value.

## Extending

Additional types are registered on the factory with a builder that receives the configuration
array and the factory (to build nested conditions):

```php
$factory
    ->registerCondition('isList', fn(array $config) => new IsListCondition())
    ->registerTransformer('slug', fn(array $config) => new SlugTransformer($config['separator'] ?? '-'));
```

Conditions implement `Condition\ConditionInterface`, transformers `Transformer\TransformerInterface`.
