<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

/**
 * Data transfer object representing a validation result.
 */
class ValidationResultDTO extends DTO
{

}