<?php

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class ServiceEndpointRunnerResultDTO extends DTO
{
    public bool $hasError = false;
    public int $statusCode = 200;
    public string $message = '';
    public array $data = [];

    private function __construct()
    {
    }

    public static function createError(string $message, int $statusCode = 500): ServiceEndpointRunnerResultDTO
    {
        $result = new ServiceEndpointRunnerResultDTO();
        $result->hasError = true;
        $result->message = $message;
        $result->statusCode = $statusCode;
        return $result;
    }

    public static function createSuccess(array $data, string $message = ''): ServiceEndpointRunnerResultDTO
    {
        $result = new ServiceEndpointRunnerResultDTO();
        $result->data = $data;
        $result->message = $message;
        return $result;
    }
}