<?php

namespace Cehlers88\AnalyticsCore\Tests\Observer;

use Cehlers88\AnalyticsCore\Observer\Message\LoginObserverMessage;
use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;
use Cehlers88\AnalyticsCore\Observer\ObserverInterface;
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use PHPUnit\Framework\TestCase;

class ObserverProviderTest extends TestCase
{
    private function makeObserver(bool $canHandle): ObserverInterface
    {
        $observer = $this->createMock(ObserverInterface::class);
        $observer->method('canHandle')->willReturn($canHandle);
        $observer->expects($canHandle ? $this->once() : $this->never())->method('handle');

        return $observer;
    }

    private function makeFailingObserver(string $throwMessage): ObserverInterface
    {
        $observer = $this->createStub(ObserverInterface::class);
        $observer->method('canHandle')->willReturn(true);
        $observer->method('handle')->willThrowException(new \Exception($throwMessage));

        return $observer;
    }

    public function testTheReportSaysWhichObserverTookTheMessage(): void
    {
        $provider = new ObserverProvider([
            $this->makeObserver(true),
            $this->makeObserver(false),
        ]);

        $report = $provider->dispatchWithReport(new LoginObserverMessage('christoph'));

        $this->assertCount(2, $report);
        $this->assertTrue($report[0]['handled']);
        $this->assertNull($report[0]['error']);
        $this->assertFalse($report[1]['handled']);
    }

    public function testAFailingObserverIsReportedInsteadOfStoppingTheDispatch(): void
    {
        $provider = new ObserverProvider([
            $this->makeFailingObserver('observer is broken'),
            $this->makeObserver(true),
        ]);

        $report = $provider->dispatchWithReport(new LoginObserverMessage('christoph'));

        $this->assertSame('observer is broken', $report[0]['error']);
        $this->assertTrue($report[1]['handled']);
        $this->assertNull($report[1]['error']);
    }

    public function testDispatchStillHandsTheMessageToEveryObserver(): void
    {
        $handledMessages = [];

        $observer = new class($handledMessages) implements ObserverInterface {
            public function __construct(private array &$handledMessages)
            {
            }

            public function canHandle(ObserverMessageInterface $message): bool
            {
                return true;
            }

            public function handle(ObserverMessageInterface $message): void
            {
                $this->handledMessages[] = $message->getKey();
            }
        };

        new ObserverProvider([$observer])->dispatch(new LoginObserverMessage('christoph'));

        $this->assertSame([LoginObserverMessage::KEY], $handledMessages);
    }
}
