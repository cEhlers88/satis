<?php

namespace Cehlers88\AnalyticsCore\Tests\Observer;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Observer\ArgumentResolver\ObserverMessageArgumentResolverInterface;
use Cehlers88\AnalyticsCore\Observer\Message\ErrorObserverMessage;
use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;
use Cehlers88\AnalyticsCore\Observer\Message\SystemUpdateObserverMessage;
use Cehlers88\AnalyticsCore\Observer\ObserverInterface;
use Cehlers88\AnalyticsCore\Observer\ObserverMessageProvider;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

/** A message whose arguments an input mask can fill in on its own. */
class ScalarTestObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'test.scalar';

    public function __construct(
        public string $title,
        public int    $amount = 3,
        public array  $data = [],
        public bool   $flag = false,
    )
    {
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}

/** A message that carries an exception and a point in time. */
class RichTestObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'test.rich';

    public function __construct(
        public \Throwable  $exception,
        public ?\DateTime  $when = null,
        public mixed       $payload = null,
        public eTestState  $state = eTestState::NEW,
    )
    {
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}

class UnbuildableTestObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'test.unbuildable';

    public function __construct(
        public ObserverInterface $observer,
        public string            $note = '',
    )
    {
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}

enum eTestState: string
{
    case NEW = 'new';
    case DONE = 'done';
}

class ObserverMessageProviderTest extends TestCase
{
    private function makeProvider(array $messageClasses, iterable $argumentResolvers = []): ObserverMessageProvider
    {
        return new ObserverMessageProvider(
            $argumentResolvers,
            ObserverMessageProvider::DEFAULT_NAMESPACE_PREFIXES,
            $messageClasses
        );
    }

    public function testTheConstructorArgumentsBecomeTheArgumentDefinitions(): void
    {
        $definition = $this->makeProvider([ScalarTestObserverMessage::class])
            ->getDefinition(ScalarTestObserverMessage::class);

        $this->assertNotNull($definition);
        $this->assertSame('test.scalar', $definition->key);
        $this->assertSame('Scalar test', $definition->label);
        $this->assertSame('A message whose arguments an input mask can fill in on its own.', $definition->description);

        $arguments = [];
        foreach ($definition->arguments as $argument) {
            $arguments[$argument->name] = $argument;
        }

        $this->assertSame(['title', 'amount', 'data', 'flag'], array_keys($arguments));
        $this->assertSame('string', $arguments['title']->type);
        $this->assertFalse($arguments['title']->isOptional);
        $this->assertTrue($arguments['amount']->isOptional);
        $this->assertSame(3, $arguments['amount']->value);
        $this->assertSame('number', $arguments['amount']->ui['input']);
        $this->assertSame('json', $arguments['data']->ui['input']);
        $this->assertSame('checkbox', $arguments['flag']->ui['input']);
    }

    public function testTheDefinitionIsHandedToAMaskAsAPlainArray(): void
    {
        $definition = $this->makeProvider([UnbuildableTestObserverMessage::class])
            ->getDefinition('test.unbuildable')
            ->toAssociativeArray();

        $this->assertSame('test.unbuildable', $definition['key']);
        $this->assertSame(UnbuildableTestObserverMessage::class, $definition['className']);
        $this->assertFalse($definition['isTriggerable']);
        $this->assertSame(['observer'], $definition['unsupportedArguments']);

        $arguments = [];
        foreach ($definition['arguments'] as $argument) {
            $arguments[$argument['name']] = $argument;
        }

        $this->assertFalse($arguments['observer']['isSupported']);
        $this->assertTrue($arguments['note']['isSupported']);
        $this->assertSame('text', $arguments['note']['ui']['input']);
    }

    public function testAMessageIsFoundByItsKeyAsWellAsByItsClass(): void
    {
        $provider = $this->makeProvider([ScalarTestObserverMessage::class]);

        $this->assertSame(
            $provider->getDefinition(ScalarTestObserverMessage::class),
            $provider->getDefinition('test.scalar')
        );
        $this->assertNull($provider->getDefinition('nothing.like.that'));
    }

    public function testScalarArgumentsAreBuiltIntoTheMessage(): void
    {
        /** @var ScalarTestObserverMessage $message */
        $message = $this->makeProvider([ScalarTestObserverMessage::class])->createMessage('test.scalar', [
            'title' => 'A title',
            'amount' => '7',
            'data' => '{"key":"value"}',
            'flag' => 'true',
        ]);

        $this->assertInstanceOf(ScalarTestObserverMessage::class, $message);
        $this->assertSame('A title', $message->title);
        $this->assertSame(7, $message->amount);
        $this->assertSame(['key' => 'value'], $message->data);
        $this->assertTrue($message->flag);
    }

    public function testLeftOutOptionalArgumentsKeepTheirDefault(): void
    {
        /** @var ScalarTestObserverMessage $message */
        $message = $this->makeProvider([ScalarTestObserverMessage::class])
            ->createMessage('test.scalar', ['title' => 'Only the title']);

        $this->assertSame(3, $message->amount);
        $this->assertSame([], $message->data);
        $this->assertFalse($message->flag);
    }

    public function testExceptionsDatesAndEnumsAreBuiltFromPlainInput(): void
    {
        /** @var RichTestObserverMessage $message */
        $message = $this->makeProvider([RichTestObserverMessage::class])->createMessage('test.rich', [
            'exception' => 'Something went wrong',
            'when' => '2026-08-27 21:00:00',
            'payload' => '[1,2]',
            'state' => 'done',
        ]);

        $this->assertSame('Something went wrong', $message->exception->getMessage());
        $this->assertSame('2026-08-27 21:00:00', $message->when->format('Y-m-d H:i:s'));
        $this->assertSame([1, 2], $message->payload);
        $this->assertSame(eTestState::DONE, $message->state);
    }

    public function testAMissingRequiredArgumentIsRefused(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Missing argument \'title\'');

        $this->makeProvider([ScalarTestObserverMessage::class])->createMessage('test.scalar', []);
    }

    public function testAnUnknownMessageIsRefused(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Unknown observer message');

        $this->makeProvider([ScalarTestObserverMessage::class])->createMessage('test.nothing');
    }

    public function testAMessageThatNeedsAnObjectNobodyCanBuildIsNotTriggerable(): void
    {
        $provider = $this->makeProvider([UnbuildableTestObserverMessage::class]);
        $definition = $provider->getDefinition('test.unbuildable');

        $this->assertFalse($definition->isTriggerable);
        $this->assertStringContainsString('observer', $definition->notTriggerableReason);
        $this->assertSame(['observer'], $definition->unsupportedArguments);

        $this->expectException(InvalidArgumentException::class);
        $provider->createMessage('test.unbuildable', ['note' => 'nope']);
    }

    public function testAnOwnResolverTeachesTheProviderAnArgumentType(): void
    {
        $resolver = new class implements ObserverMessageArgumentResolverInterface {
            public function supports(string $type): bool
            {
                return $type === ObserverInterface::class;
            }

            public function describe(PropertyDTO $property): PropertyDTO
            {
                $property->ui['input'] = 'text';

                return $property;
            }

            public function resolve(string $type, mixed $value): mixed
            {
                return new class implements ObserverInterface {
                    public function canHandle(ObserverMessageInterface $message): bool
                    {
                        return false;
                    }

                    public function handle(ObserverMessageInterface $message): void
                    {
                    }
                };
            }
        };

        $provider = $this->makeProvider([UnbuildableTestObserverMessage::class], [$resolver]);
        $definition = $provider->getDefinition('test.unbuildable');

        $this->assertTrue($definition->isTriggerable);
        $this->assertSame([], $definition->unsupportedArguments);

        /** @var UnbuildableTestObserverMessage $message */
        $message = $provider->createMessage('test.unbuildable', ['observer' => 'anything', 'note' => 'built']);
        $this->assertSame('built', $message->note);
    }

    public function testTheMessagesOfTheCoreAreFoundOnTheirOwn(): void
    {
        $messageClasses = new ObserverMessageProvider()->getMessageClasses();

        $this->assertContains(ErrorObserverMessage::class, $messageClasses);
        $this->assertContains(SystemUpdateObserverMessage::class, $messageClasses);
    }

    public function testTheFoundMessagesAreDescribedAndOrderedByKey(): void
    {
        $definitions = new ObserverMessageProvider()->getDefinitions();

        $this->assertArrayHasKey(SystemUpdateObserverMessage::class, $definitions);
        $this->assertTrue($definitions[SystemUpdateObserverMessage::class]->isTriggerable);

        $keys = array_map(static fn($definition) => $definition->key, $definitions);
        $sortedKeys = $keys;
        sort($sortedKeys);
        $this->assertSame($sortedKeys, array_values($keys));
    }
}
