<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Cehlers88\AnalyticsCore\Provider\WidgetProvider;

class SetupWidget extends AbstractWidget
{
    public function __construct(
        private readonly WidgetProvider $widgetProvider
    )
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.setup';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
        ];
    }


    public function getTemplateName(): string
    {
        return 'setup';
    }

    /**
     * A tile that is already a setup tile has nothing to gain from being turned
     * into another one.
     */
    public function isSelectable(): bool
    {
        return false;
    }

    public function enrichProperties(array $properties): array
    {
        return parent::enrichProperties([
            ...$properties,
            // Carries the settings of every pickable widget, so the mask for the
            // picked type is there without asking the server a second time.
            'availableWidgets' => $this->widgetProvider->getSelectableWidgetDefinitions()
        ]);
    }
}