<?php

namespace Cehlers88\AnalyticsCore\Widget;

class LoginWidget extends AbstractWidget
{
    public function getName(): string
    {
        return 'AnalyticsCore.login';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
        ];
    }

    public function getTemplateName(): string
    {
        return 'login';
    }

    /**
     * The login form is shown as an overlay on top of a widget the user may not
     * see yet; it is not something to put on a dashboard.
     */
    public function isSelectable(): bool
    {
        return false;
    }
}