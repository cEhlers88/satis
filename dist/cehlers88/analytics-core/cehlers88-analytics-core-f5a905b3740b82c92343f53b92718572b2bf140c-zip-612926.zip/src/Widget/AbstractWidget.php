<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 19:32
 */

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Analytics\ENUM\eWidgetType;
use Analytics\Interface\IWidget;
use Cehlers88\AnalyticsCore\Entity\User;

abstract class AbstractWidget implements IWidget
{
    public function enrichProperties(array $properties): array
    {
        return $properties;
    }

    public function getTemplateName(): string
    {
        return $this->getName();
    }

    abstract public function getName(): string;

    public function getPreloadPlaceholders(): array
    {
        return [];
    }

    public function getRequiredStartArguments(): array
    {
        return [];
    }

    public function getRequiredRoles(): array
    {
        return [];
    }

    /**
     * Describes what this widget can be configured with, so that the setup tile
     * can ask for those values while the widget type is being picked.
     *
     * The name of a property is the prop its value ends up in, and a property
     * that is not optional is one the widget can not be rendered without.
     *
     * @return PropertyDTO[]
     */
    public function getSettingDefinitions(): array
    {
        return [];
    }

    /**
     * Whether this widget can be picked as the type of a dashboard tile.
     *
     * The setup tile itself and widgets that only ever appear inside another
     * one (a login overlay, for instance) say no here.
     */
    public function isSelectable(): bool
    {
        return true;
    }

    public function getWidgetType(): eWidgetType
    {
        return eWidgetType::DASHBOARD;
    }

    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        return WidgetSubmitResultDTO::createError(404, 'Not implemented');
    }
}