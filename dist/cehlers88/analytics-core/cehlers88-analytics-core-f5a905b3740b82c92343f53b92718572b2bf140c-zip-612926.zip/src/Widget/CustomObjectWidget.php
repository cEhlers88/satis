<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;

class CustomObjectWidget extends AbstractWidget
{
    public function __construct(
        private readonly CustomObjectProvider $customObjectProvider,
        private readonly AssemblerProvider    $assemblerProvider
    )
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.customObject';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
        ];
    }

    public function getTemplateName(): string
    {
        return 'customObject';
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'customObjectId',
                value: null,
                type: 'int',
                label: 'Custom-Object-ID',
                description: 'Das Custom Object, das die Kachel anzeigt.',
                ui: ['min' => 1]
            ),
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $customObjectId = (int)($properties['customObjectId'] ?? 0);
        $customObject = $this->customObjectProvider->getCustomObjectById($customObjectId);
        if (is_null($customObject)) {
            throw new \InvalidArgumentException(sprintf('Custom object %d not found', $customObjectId));
        }
        $assembler = $this->assemblerProvider->getAssemblerForClass($customObject::class);
        if (is_null($assembler)) {
            $assembler = $this->assemblerProvider->getAssemblerForClass(CustomEntity::class);
        }

        $result = [
            ...$properties,
            'customObject' => $assembler->one($customObject)
        ];

        return parent::enrichProperties($result);
    }
}