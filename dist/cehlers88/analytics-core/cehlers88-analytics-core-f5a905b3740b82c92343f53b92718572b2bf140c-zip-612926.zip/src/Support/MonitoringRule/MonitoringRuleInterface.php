<?php

namespace Cehlers88\AnalyticsCore\Support\MonitoringRule;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;

interface MonitoringRuleInterface
{
    /**
     * The arguments the rule knows, described the same way a widget describes
     * its settings: the name is the key inside the rule arguments, the type
     * says what the value is and isOptional whether the rule runs without it.
     *
     * A mask that configures a monitoring builds its fields out of these, so a
     * rule that wants another argument only needs a property for it.
     *
     * @return PropertyDTO[]
     */
    public function getArgumentDefinitions(): array;

    public function setArguments(array $arguments): self;

    public function setAttributeToCheck(CustomEntityAttribute $attribute): self;

    public function execute(): self;

    public function getStatisticDetails(): array;

    public function setStatisticOptions(array $options): self;

    public function getStatisticOptions(): array;

    public function preventStatisticCreation(): bool;
}