<?php

namespace Cehlers88\AnalyticsCore\Support\MonitoringRule;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttributeMonitoring;
use Cehlers88\AnalyticsCore\Widget\WidgetSettings;

abstract class AbstractMonitoringRule implements MonitoringRuleInterface
{
    protected array $_statisticOptions = [];
    protected CustomEntityAttribute $_attributeToCheck;
    protected array $_arguments = [];
    protected ?CustomEntityAttributeMonitoring $_attributeMonitoring = null;

    public function setArguments(array $arguments): self
    {
        if (!$this->validateArguments($arguments)) {
            throw new \InvalidArgumentException('Invalid arguments');
        }

        $this->_arguments = $arguments;
        return $this;
    }

    /**
     * A rule that declares no arguments knows none it could insist on.
     *
     * @return PropertyDTO[]
     */
    public function getArgumentDefinitions(): array
    {
        return [];
    }

    /**
     * Whether the given arguments answer everything the rule insists on.
     *
     * Rule arguments and widget settings are the same PropertyDTO mechanism,
     * so the same check decides what counts as answered - a rule only overrides
     * this when its arguments cannot be expressed as properties.
     */
    public function validateArguments(array $arguments): bool
    {
        $definitions = $this->getArgumentDefinitions();

        if ($definitions === []) {
            return true;
        }

        return new WidgetSettings()->findUnsatisfied($definitions, $arguments) === [];
    }

    public function setAttributeToCheck(CustomEntityAttribute $attribute): self
    {
        $this->_attributeToCheck = $attribute;
        return $this;
    }

    public function getStatisticDetails(): array
    {
        return [
            'id' => $this->_attributeMonitoring->getId(),
        ];
    }


    public function getName(): string
    {
        return $this->_arguments['name'] ?? '';
    }

    public function preventStatisticCreation(): bool
    {
        return false;
    }

    public function setAttributeMonitoring(CustomEntityAttributeMonitoring $attributeMonitoring): self
    {
        $this->_attributeMonitoring = $attributeMonitoring;
        return $this;
    }

    public function getStatisticOptions(): array
    {
        return $this->_statisticOptions;
    }

    public function setStatisticOptions(array $options): self
    {
        $this->_statisticOptions = $options;
        return $this;
    }
}