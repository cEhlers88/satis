<?php

namespace Cehlers88\AnalyticsCore\Support;

use Cehlers88\AnalyticsCore\Entity\CustomEntityAttributeMonitoring;
use Cehlers88\AnalyticsCore\Entity\Statistics;
use Cehlers88\AnalyticsCore\Repository\CustomEntityAttributeMonitoringRepository;
use Cehlers88\AnalyticsCore\Repository\CustomEntityAttributeRepository;
use Cehlers88\AnalyticsCore\Repository\StatisticsRepository;
use Cehlers88\AnalyticsCore\Support\MonitoringRule\AbstractMonitoringRule;
use Cehlers88\AnalyticsCore\Support\MonitoringRule\MonitoringRuleInterface;

class Monitoring
{
    public function __construct(
        private CustomEntityAttributeMonitoringRepository $customEntityAttributeMonitoringRepository,
        private CustomEntityAttributeRepository           $customEntityAttributeRepository,
        private StatisticsRepository                      $statisticsRepository,
        private iterable                                  $monitoringRules
    )
    {

    }

    public function run(): void
    {
        $monitoringDefs = $this->getRunnableMonitoringEntities();

        foreach ($monitoringDefs as $monitoring) {
            $ruleHandler = $this->runMonitoringRules($monitoring);

            $statistic = $monitoring->getStatistic();
            if (empty($statistic)) {
                $statistic = new Statistics();
            }

            $statistic->setUpdatedAt(new \DateTime());
            $details = $statistic->getDetails();
            $attributeName = $monitoring->getAttribute()->getName();

            if ($attributeName === 'value') {
                $attributeHolder = $monitoring->getAttribute()->getCustomEntity();
                foreach ($attributeHolder->getAttributes() as $attribute) {
                    if ($attribute->getName() === 'label') {
                        $attributeName = $attribute->getValue();
                    }
                }
            }
            $details["options"] = [
                'monitoredAttribute' => $attributeName,
            ];
            $value = $monitoring->getAttribute()->getValue();
            $details[$attributeName][] = is_numeric($value) ? (float)$value : (is_bool($value) ? ($value ? 1 : 0) : $value);
            $details['timestamp'][] = new \DateTime()->getTimestamp();

            if ($ruleHandler instanceof MonitoringRuleInterface) {
                foreach ($ruleHandler->getStatisticDetails() as $name => $value) {
                    if (!is_array($value)) continue;
                    $details[$name][] = $value;
                }
            }
            foreach ($details as $key => $value) {
                if (!is_array($value)) continue;
                while (count($details[$key]) > $monitoring->getMaxLength()) {
                    array_shift($details[$key]);
                }
                if ($key === 'options') continue;
                while (count($details[$key]) < $monitoring->getMaxLength()){
                    array_unshift($details[$key], 0);
                }
            }

            $statistic->setDetails($details);

            $monitoring->setStatistic($statistic);
            $monitoring->setLastRun(new \DateTime());
            $this->customEntityAttributeMonitoringRepository->save($monitoring, false);
        }

        $this->customEntityAttributeMonitoringRepository->flush();
    }

    /**
     * @return CustomEntityAttributeMonitoring[]
     */
    private function getRunnableMonitoringEntities(): array
    {
        $result = [];
        $monitoringEntities = $this->customEntityAttributeMonitoringRepository->findAll();

        foreach ($monitoringEntities as $monitoring) {
            if (!$this->_checkMonitoringIsRunnable($monitoring)) continue;

            $result[] = $monitoring;
        }

        return $result;
    }

    private function _checkMonitoringIsRunnable(CustomEntityAttributeMonitoring $monitoring): bool
    {
        $runInterval = $monitoring->getRunInterval();
        if (empty($runInterval)) {
            return false;
        }
        if (is_null($monitoring->getLastRun())) {
            return true;
        }

        $nextRunAfter = new \DateTimeImmutable()->setTimestamp($monitoring->getLastRun()->getTimestamp());
        if (empty($nextRunAfter)) {
            return true;
        }

        switch ($runInterval) {
            case 'daily_midnight':
                // Not a DateInterval, so the run is decided here and never falls
                // through to the interval arithmetic below.
                $lastMidnight = new \DateTimeImmutable()->setTime(0, 0, 0);

                return $nextRunAfter->getTimestamp() < $lastMidnight->getTimestamp();
        }

        $nextRunAfter = $nextRunAfter->add(new \DateInterval($runInterval));
        $nextRunAfter = $nextRunAfter->setTime(
            (int)$nextRunAfter->format('H'),
            (int)$nextRunAfter->format('i'),
            0
        );

        if ($nextRunAfter->getTimestamp() < new \DateTimeImmutable()->getTimestamp()) {
            return true;
        }

        return false;
    }

    public function runMonitoringRules(
        CustomEntityAttributeMonitoring $monitoring
    ): ?MonitoringRuleInterface
    {
        $ruleHandler = $this->_getMonitoringRuleHandler($monitoring->getRuleHandler() ?? '');

        try {
            if (empty($ruleHandler)) {
                return null;
            }
            $attribute = $monitoring->getAttribute();
            // A monitoring that has never run yet carries no statistic.
            $details = $monitoring->getStatistic()?->getDetails() ?? [];

            $ruleHandler
                ->setAttributeMonitoring($monitoring)
                ->setArguments($monitoring->getRuleArguments() ?? [])
                ->setAttributeToCheck($attribute)
                //->setStatisticOptions($details['options'] ?? [])
                ->execute();
            $newOptions = $ruleHandler->getStatisticOptions();
            //$details = $monitoring->getStatistic()->getDetails() ?? [];
            $details['options'] = $newOptions;
            //$monitoring->getStatistic()->setDetails($details);
        } catch (\Exception $e) {
            echo $e->getMessage();
            return null;
        }

        return $ruleHandler;
    }

    private function _getMonitoringRuleHandler(string $name): ?AbstractMonitoringRule
    {
        foreach ($this->monitoringRules as $monitoringRule) {
            $className = $monitoringRule::class;
            if ($className === $name) {
                return clone $monitoringRule;
            }

            // remove fqcn from class name
            $className = substr($className, strrpos($className, '\\') + 1);
            if ($className === $name) {
                return clone $monitoringRule;
            }
        }

        return null;
    }
}