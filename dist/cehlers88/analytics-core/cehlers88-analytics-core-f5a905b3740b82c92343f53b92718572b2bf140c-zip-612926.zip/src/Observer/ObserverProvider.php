<?php

namespace Cehlers88\AnalyticsCore\Observer;

use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;
use Cehlers88\AnalyticsCore\Support\Error\AbstractErrorBag;

/** Provider for managing and notifying observers. */
class ObserverProvider extends AbstractErrorBag
{
    /**
     * @param iterable<ObserverInterface> $observers
     */
    public function __construct(
        private iterable $observers
    )
    {

    }

    /**
     * Dispatch a message to all observers that can handle it.
     *
     * @param ObserverMessageInterface $message
     * @return void
     */
    public function dispatch(ObserverMessageInterface $message): void
    {
        $this->dispatchWithReport($message);
    }

    /**
     * Dispatch a message and say what every observer made of it.
     *
     * The dispatch itself never fails - an observer that throws is logged the
     * same way as during a normal dispatch, the report only makes visible what
     * happened, which is what a mask that triggers a message by hand needs.
     *
     * @return array<int, array{observer: string, handled: bool, error: string|null}>
     */
    public function dispatchWithReport(ObserverMessageInterface $message): array
    {
        $report = [];

        foreach ($this->observers as $observer) {
            if (!$observer->canHandle($message)) {
                $report[] = [
                    'observer' => $observer::class,
                    'handled' => false,
                    'error' => null,
                ];
                continue;
            }

            $error = null;

            try {
                $observer->handle($message);
            } catch (\Exception $e) {
                $error = $e->getMessage();
                $this->getLogger()->error($e->getMessage(), [
                    'code' => $e->getCode(),
                    'trace' => $e->getTraceAsString(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                    'observerMessageKey' => $message->getKey(),
                ]);
            }

            $report[] = [
                'observer' => $observer::class,
                'handled' => true,
                'error' => $error,
            ];
        }

        return $report;
    }
}
