<?php

namespace Cehlers88\AnalyticsCore\Observer;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Observer\ArgumentResolver\BackedEnumArgumentResolver;
use Cehlers88\AnalyticsCore\Observer\ArgumentResolver\DateTimeArgumentResolver;
use Cehlers88\AnalyticsCore\Observer\ArgumentResolver\ObserverMessageArgumentResolverInterface;
use Cehlers88\AnalyticsCore\Observer\ArgumentResolver\ScalarArgumentResolver;
use Cehlers88\AnalyticsCore\Observer\ArgumentResolver\ThrowableArgumentResolver;
use Cehlers88\AnalyticsCore\Observer\DTO\ObserverMessageDefinitionDTO;
use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;
use Composer\Autoload\ClassLoader;
use InvalidArgumentException;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use ReflectionClass;
use ReflectionNamedType;
use ReflectionParameter;

/**
 * Knows every observer message of the system and how to build one.
 *
 * Observer messages are value objects, so they are not services and cannot be
 * collected by a tag. They all live in an `Observer\Message` namespace though,
 * which is what this provider looks for in the source directories of the
 * watched namespaces.
 */
class ObserverMessageProvider
{
    /** Namespaces that are searched for observer messages. */
    public const DEFAULT_NAMESPACE_PREFIXES = ['Cehlers88\\', 'Analytics\\'];

    /** Every observer message lives in a directory of that name. */
    private const MESSAGE_DIRECTORY = 'Observer' . DIRECTORY_SEPARATOR . 'Message';

    /** @var ObserverMessageArgumentResolverInterface[] */
    private array $argumentResolvers = [];

    /** @var ObserverMessageDefinitionDTO[]|null Definitions by class name. */
    private ?array $definitions = null;

    /**
     * @param iterable<ObserverMessageArgumentResolverInterface> $argumentResolvers Resolvers
     *        that are asked before the built-in ones, so an application can teach the
     *        provider its own argument types.
     * @param string[] $namespacePrefixes Namespaces whose source directories are searched.
     * @param string[] $messageClasses When given, exactly these classes are described and
     *        nothing is searched for.
     */
    public function __construct(
        iterable      $argumentResolvers = [],
        private array $namespacePrefixes = self::DEFAULT_NAMESPACE_PREFIXES,
        private array $messageClasses = [],
    )
    {
        foreach ($argumentResolvers as $argumentResolver) {
            $this->argumentResolvers[] = $argumentResolver;
        }

        // the built-in resolvers come last, so an application can take a type over
        $this->argumentResolvers[] = new BackedEnumArgumentResolver();
        $this->argumentResolvers[] = new DateTimeArgumentResolver();
        $this->argumentResolvers[] = new ThrowableArgumentResolver();
        $this->argumentResolvers[] = new ScalarArgumentResolver();
    }

    /**
     * Every known observer message, ordered by key.
     *
     * @return ObserverMessageDefinitionDTO[] Definitions by class name.
     */
    public function getDefinitions(): array
    {
        if (is_null($this->definitions)) {
            $this->definitions = [];

            foreach ($this->getMessageClasses() as $messageClass) {
                $definition = $this->buildDefinition($messageClass);
                if (!is_null($definition)) {
                    $this->definitions[$messageClass] = $definition;
                }
            }

            uasort(
                $this->definitions,
                static fn(ObserverMessageDefinitionDTO $left, ObserverMessageDefinitionDTO $right): int
                    => [$left->key, $left->className] <=> [$right->key, $right->className]
            );
        }

        return $this->definitions;
    }

    /** Looks a message up by its class name or by the key it is dispatched under. */
    public function getDefinition(string $classNameOrKey): ?ObserverMessageDefinitionDTO
    {
        $definitions = $this->getDefinitions();
        $className = ltrim($classNameOrKey, '\\');

        if (isset($definitions[$className])) {
            return $definitions[$className];
        }

        foreach ($definitions as $definition) {
            if ($definition->key === $classNameOrKey) {
                return $definition;
            }
        }

        return null;
    }

    /**
     * Builds an observer message out of the given arguments.
     *
     * @param string $classNameOrKey Class name or dispatch key of the message.
     * @param array<string, mixed> $arguments Values by argument name. An argument that
     *        is left out keeps the default of the message.
     *
     * @throws InvalidArgumentException When the message is unknown, cannot be built from
     *         the outside or a required argument is missing.
     */
    public function createMessage(string $classNameOrKey, array $arguments = []): ObserverMessageInterface
    {
        $definition = $this->getDefinition($classNameOrKey);

        if (is_null($definition)) {
            throw new InvalidArgumentException('Unknown observer message: ' . $classNameOrKey);
        }

        if (!$definition->isTriggerable) {
            throw new InvalidArgumentException(
                $definition->className . ' cannot be built: ' . $definition->notTriggerableReason
            );
        }

        $constructorArguments = [];

        foreach ($definition->arguments as $argument) {
            $isGiven = array_key_exists($argument->name, $arguments)
                && !($arguments[$argument->name] === null && $argument->isOptional);

            if (!$isGiven) {
                if (!$argument->isOptional) {
                    throw new InvalidArgumentException('Missing argument \'' . $argument->name . '\'');
                }
                continue;
            }

            $resolver = $this->getArgumentResolver($argument->type);
            if (is_null($resolver)) {
                // an optional argument nobody can build - the message keeps its default
                continue;
            }

            $constructorArguments[$argument->name] = $resolver->resolve($argument->type, $arguments[$argument->name]);
        }

        /** @var ObserverMessageInterface $message */
        $message = new $definition->className(...$constructorArguments);

        return $message;
    }

    /**
     * The classes of all observer messages that were found.
     *
     * @return string[]
     */
    public function getMessageClasses(): array
    {
        if ($this->messageClasses !== []) {
            return $this->messageClasses;
        }

        $messageClasses = [];

        foreach ($this->getWatchedSourceDirectories() as $namespacePrefix => $directories) {
            foreach ($directories as $directory) {
                foreach ($this->findMessageClassesIn($directory, $namespacePrefix) as $messageClass) {
                    $messageClasses[$messageClass] = $messageClass;
                }
            }
        }

        return array_values($messageClasses);
    }

    /** Describes a single message class, null when it is none. */
    private function buildDefinition(string $className): ?ObserverMessageDefinitionDTO
    {
        if (!class_exists($className) || !is_a($className, ObserverMessageInterface::class, true)) {
            return null;
        }

        $reflection = new ReflectionClass($className);
        if (!$reflection->isInstantiable()) {
            return null;
        }

        $definition = ObserverMessageDefinitionDTO::create(
            $className,
            $reflection->hasConstant('KEY') ? (string)$reflection->getConstant('KEY') : '',
            [],
            '',
            $this->readClassDescription($reflection)
        );

        $unbuildableArguments = [];

        foreach ($reflection->getConstructor()?->getParameters() ?? [] as $parameter) {
            $argument = $this->describeParameter($parameter);
            $definition->arguments[] = $argument;

            if (is_null($this->getArgumentResolver($argument->type))) {
                $definition->unsupportedArguments[] = $argument->name;

                if (!$argument->isOptional) {
                    $unbuildableArguments[] = $argument->name;
                }
            }
        }

        if ($unbuildableArguments !== []) {
            $definition->markNotTriggerable($unbuildableArguments);
        }

        return $definition;
    }

    private function describeParameter(ReflectionParameter $parameter): PropertyDTO
    {
        $type = $parameter->getType();
        $typeName = $type instanceof ReflectionNamedType ? ltrim($type->getName(), '\\') : (string)$type;

        $argument = PropertyDTO::create(
            $parameter->getName(),
            $parameter->isDefaultValueAvailable() ? $parameter->getDefaultValue() : null,
            $typeName === '' ? 'mixed' : $typeName,
            $parameter->isDefaultValueAvailable()
        );

        $resolver = $this->getArgumentResolver($argument->type);

        return is_null($resolver) ? $argument : $resolver->describe($argument);
    }

    private function getArgumentResolver(string $type): ?ObserverMessageArgumentResolverInterface
    {
        foreach ($this->argumentResolvers as $argumentResolver) {
            if ($argumentResolver->supports($type)) {
                return $argumentResolver;
            }
        }

        return null;
    }

    /** The summary line of the class doc block, so a mask can say what the message is. */
    private function readClassDescription(ReflectionClass $reflection): string
    {
        $docComment = $reflection->getDocComment();
        if ($docComment === false) {
            return '';
        }

        foreach (explode("\n", $docComment) as $line) {
            $line = preg_replace('#^\s*(/\*\*|\*/|\*)#', '', $line) ?? '';
            $line = trim(preg_replace('#\*/\s*$#', '', $line) ?? '');

            if ($line !== '' && !str_starts_with($line, '@')) {
                return $line;
            }
        }

        return '';
    }

    /**
     * The source directories of the watched namespaces, taken from the autoloader.
     *
     * @return array<string, string[]> Directories by namespace prefix.
     */
    private function getWatchedSourceDirectories(): array
    {
        if (!class_exists(ClassLoader::class) || !method_exists(ClassLoader::class, 'getRegisteredLoaders')) {
            return [];
        }

        $directories = [];

        foreach (ClassLoader::getRegisteredLoaders() as $classLoader) {
            foreach ($classLoader->getPrefixesPsr4() as $namespacePrefix => $prefixDirectories) {
                if (!$this->isWatchedNamespace($namespacePrefix)) {
                    continue;
                }

                foreach ($prefixDirectories as $prefixDirectory) {
                    if (is_dir($prefixDirectory)) {
                        $directories[$namespacePrefix][] = $prefixDirectory;
                    }
                }
            }
        }

        return $directories;
    }

    private function isWatchedNamespace(string $namespacePrefix): bool
    {
        foreach ($this->namespacePrefixes as $watchedPrefix) {
            if (str_starts_with($namespacePrefix, $watchedPrefix)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return string[] The classes of every file below an `Observer/Message` directory.
     */
    private function findMessageClassesIn(string $directory, string $namespacePrefix): array
    {
        $messageClasses = [];

        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($files as $file) {
            if (!$file->isFile() || $file->getExtension() !== 'php') {
                continue;
            }

            if (!str_ends_with($file->getPath(), self::MESSAGE_DIRECTORY)) {
                continue;
            }

            $relativePath = substr($file->getPathname(), strlen(rtrim($directory, DIRECTORY_SEPARATOR)) + 1, -4);
            $className = $namespacePrefix . str_replace(DIRECTORY_SEPARATOR, '\\', $relativePath);

            if (class_exists($className) && is_a($className, ObserverMessageInterface::class, true)) {
                $messageClasses[] = $className;
            }
        }

        return $messageClasses;
    }
}
