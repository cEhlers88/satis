<?php

namespace Cehlers88\AnalyticsCore\Observer\DTO;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Support\DTO\DTO;

/**
 * Describes an observer message the way a mask needs it: what it is called,
 * which arguments its constructor insists on and whether those arguments can
 * be filled in from the outside at all.
 *
 * The arguments are described the same way a widget describes its settings and
 * a monitoring rule its arguments - as PropertyDTOs, so the same mask building
 * works for all of them.
 */
class ObserverMessageDefinitionDTO extends DTO
{
    public string $className = '';

    /** The key the message is dispatched under, e.g. 'system.update'. */
    public string $key = '';

    public string $label = '';

    public string $description = '';

    /** @var PropertyDTO[] */
    public array $arguments = [];

    /**
     * Names of arguments no resolver knows how to build. A message that needs
     * one of them cannot be triggered from the outside.
     *
     * @var string[]
     */
    public array $unsupportedArguments = [];

    public bool $isTriggerable = true;

    /** Says why the message cannot be triggered, empty while it can. */
    public string $notTriggerableReason = '';

    /**
     * @param PropertyDTO[] $arguments
     */
    public static function create(
        string $className,
        string $key,
        array  $arguments = [],
        string $label = '',
        string $description = ''
    ): self
    {
        $dto = new self();

        $dto->className = $className;
        $dto->key = $key;
        $dto->arguments = $arguments;
        $dto->label = $label === '' ? self::buildLabel($className) : $label;
        $dto->description = $description;

        return $dto;
    }

    /**
     * Marks the message as not triggerable, naming the arguments that keep it
     * from being built.
     *
     * @param string[] $argumentNames
     */
    public function markNotTriggerable(array $argumentNames): self
    {
        $this->isTriggerable = false;
        $this->notTriggerableReason = 'The argument(s) ' . implode(', ', $argumentNames)
            . ' cannot be filled in, the message can only be dispatched by the code that owns it.';

        return $this;
    }

    public function toAssociativeArray(): array
    {
        return [
            'className' => $this->className,
            'key' => $this->key,
            'label' => $this->label,
            'description' => $this->description,
            'arguments' => array_map(
                fn(PropertyDTO $argument) => [
                    ...$argument->toAssociativeArray(),
                    'description' => $argument->description,
                    'ui' => $argument->ui,
                    'isSupported' => !in_array($argument->name, $this->unsupportedArguments, true),
                ],
                $this->arguments
            ),
            'unsupportedArguments' => $this->unsupportedArguments,
            'isTriggerable' => $this->isTriggerable,
            'notTriggerableReason' => $this->notTriggerableReason,
        ];
    }

    /** Turns 'SystemUpdateObserverMessage' into 'System update'. */
    private static function buildLabel(string $className): string
    {
        $namespaceSplit = explode('\\', $className);
        $shortName = preg_replace('/ObserverMessage$/', '', end($namespaceSplit));

        $words = preg_split('/(?=[A-Z])/', $shortName, -1, PREG_SPLIT_NO_EMPTY) ?: [$shortName];

        return ucfirst(strtolower(implode(' ', $words)));
    }
}
