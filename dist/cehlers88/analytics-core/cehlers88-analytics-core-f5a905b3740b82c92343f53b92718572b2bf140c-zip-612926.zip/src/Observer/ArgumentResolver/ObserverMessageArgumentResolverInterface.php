<?php

namespace Cehlers88\AnalyticsCore\Observer\ArgumentResolver;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;

/**
 * Builds a constructor argument of an observer message out of a plain value.
 *
 * An observer message is a value object, not a service, so a mask that wants
 * to dispatch one has to hand in its constructor arguments. The resolvers say
 * which types can be built that way and how the input for them looks - a
 * message whose arguments no resolver knows cannot be triggered from a mask.
 */
interface ObserverMessageArgumentResolverInterface
{
    /**
     * Whether the resolver builds values for the given constructor type.
     *
     * @param string $type The declared type, without the nullability marker.
     */
    public function supports(string $type): bool;

    /**
     * Refines the property describing the argument, so a mask can offer the
     * input the resolver expects.
     */
    public function describe(PropertyDTO $property): PropertyDTO;

    /** Builds the constructor value out of what was filled in. */
    public function resolve(string $type, mixed $value): mixed;
}
