<?php

namespace Cehlers88\AnalyticsCore\Observer\ArgumentResolver;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use ReflectionClass;
use RuntimeException;
use Throwable;

/**
 * Builds the exception an error message carries. A mask only hands in the
 * message text (and optionally a code), the exception itself is created here -
 * with the declared type whenever that type can be created that way.
 */
class ThrowableArgumentResolver implements ObserverMessageArgumentResolverInterface
{
    public function supports(string $type): bool
    {
        $type = ltrim($type, '\\');

        return $type === Throwable::class || is_a($type, Throwable::class, true);
    }

    public function describe(PropertyDTO $property): PropertyDTO
    {
        $property->ui['input'] = 'text';

        if ($property->description === '') {
            $property->description = 'Message of the exception that is created for this argument.';
        }

        return $property;
    }

    public function resolve(string $type, mixed $value): Throwable
    {
        if ($value instanceof Throwable) {
            return $value;
        }

        $message = 'Triggered manually';
        $code = 0;

        if (is_array($value)) {
            $message = (string)($value['message'] ?? $message);
            $code = (int)($value['code'] ?? 0);
        } elseif (is_scalar($value) && (string)$value !== '') {
            $message = (string)$value;
        }

        return $this->createException(ltrim($type, '\\'), $message, $code);
    }

    private function createException(string $type, string $message, int $code): Throwable
    {
        if ($type === Throwable::class || !class_exists($type)) {
            return new RuntimeException($message, $code);
        }

        $reflection = new ReflectionClass($type);
        if (!$reflection->isInstantiable()) {
            return new RuntimeException($message, $code);
        }

        try {
            /** @var Throwable $exception */
            $exception = $reflection->newInstance($message, $code);

            return $exception;
        } catch (Throwable) {
            // an exception with its own constructor signature - the plain one still carries the message
            return new RuntimeException($message, $code);
        }
    }
}
