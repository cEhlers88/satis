<?php

namespace Cehlers88\AnalyticsCore\Observer\ArgumentResolver;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use DateTime;
use DateTimeImmutable;
use DateTimeInterface;
use InvalidArgumentException;

/** Builds date arguments out of anything strtotime() understands. */
class DateTimeArgumentResolver implements ObserverMessageArgumentResolverInterface
{
    public function supports(string $type): bool
    {
        return in_array(ltrim($type, '\\'), [DateTime::class, DateTimeImmutable::class, DateTimeInterface::class], true);
    }

    public function describe(PropertyDTO $property): PropertyDTO
    {
        $property->ui['input'] = 'datetime-local';

        if ($property->description === '') {
            $property->description = 'A point in time, e.g. 2026-08-27T21:00 or "now".';
        }

        return $property;
    }

    public function resolve(string $type, mixed $value): DateTimeInterface
    {
        if ($value instanceof DateTimeInterface) {
            return $value;
        }

        $time = is_string($value) && trim($value) !== '' ? trim($value) : 'now';

        try {
            return ltrim($type, '\\') === DateTime::class
                ? new DateTime($time)
                : new DateTimeImmutable($time);
        } catch (\Exception $exception) {
            throw new InvalidArgumentException('Not a readable point in time: ' . $time, 0, $exception);
        }
    }
}
