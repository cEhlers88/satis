<?php

namespace Cehlers88\AnalyticsCore\Observer\ArgumentResolver;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;

/**
 * Handles everything an input field can carry on its own: strings, numbers,
 * booleans, arrays and untyped arguments.
 */
class ScalarArgumentResolver implements ObserverMessageArgumentResolverInterface
{
    private const TYPES = ['string', 'int', 'float', 'bool', 'array', 'iterable', 'mixed'];

    /** The input a mask offers for the type. */
    private const INPUTS = [
        'string' => 'text',
        'int' => 'number',
        'float' => 'number',
        'bool' => 'checkbox',
        'array' => 'json',
        'iterable' => 'json',
        'mixed' => 'json',
    ];

    public function supports(string $type): bool
    {
        return in_array($type, self::TYPES, true);
    }

    public function describe(PropertyDTO $property): PropertyDTO
    {
        $property->ui['input'] = self::INPUTS[$property->type] ?? 'text';

        if ($property->ui['input'] === 'json' && $property->description === '') {
            $property->description = $property->type === 'mixed'
                ? 'Any value, given as JSON.'
                : 'A list or map, given as JSON.';
        }

        return $property;
    }

    public function resolve(string $type, mixed $value): mixed
    {
        return match ($type) {
            'string' => is_scalar($value) || $value === null ? (string)$value : (string)json_encode($value),
            'int' => (int)$value,
            'float' => (float)$value,
            'bool' => filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? (bool)$value,
            'array', 'iterable' => $this->toArray($value),
            default => $this->decodeWhenJson($value),
        };
    }

    private function toArray(mixed $value): array
    {
        if (is_array($value)) {
            return $value;
        }

        $decoded = $this->decodeWhenJson($value);

        return is_array($decoded) ? $decoded : array_filter([$decoded], static fn($entry) => $entry !== null && $entry !== '');
    }

    /**
     * A mask sends JSON as text, everything else is taken as it is - a plain
     * string stays a string, only valid JSON becomes the value it describes.
     */
    private function decodeWhenJson(mixed $value): mixed
    {
        if (!is_string($value) || trim($value) === '') {
            return $value;
        }

        $decoded = json_decode($value, true);

        return json_last_error() === JSON_ERROR_NONE ? $decoded : $value;
    }
}
