<?php

namespace Cehlers88\AnalyticsCore\Observer\ArgumentResolver;

use BackedEnum;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use InvalidArgumentException;

/** Turns the value of a backed enum back into the enum case, e.g. a state. */
class BackedEnumArgumentResolver implements ObserverMessageArgumentResolverInterface
{
    public function supports(string $type): bool
    {
        $type = ltrim($type, '\\');

        return enum_exists($type) && is_a($type, BackedEnum::class, true);
    }

    public function describe(PropertyDTO $property): PropertyDTO
    {
        /** @var class-string<BackedEnum> $type */
        $type = ltrim($property->type, '\\');

        $options = [];
        foreach ($type::cases() as $case) {
            $options[$case->value] = $case->name;
        }

        $property->ui['input'] = 'select';
        $property->ui['options'] = $options;

        return $property;
    }

    public function resolve(string $type, mixed $value): BackedEnum
    {
        if ($value instanceof BackedEnum) {
            return $value;
        }

        /** @var class-string<BackedEnum> $type */
        $type = ltrim($type, '\\');
        $case = is_int($value) || is_string($value) ? $type::tryFrom($value) : null;

        if ($case === null) {
            throw new InvalidArgumentException('Not a case of ' . $type . ': ' . var_export($value, true));
        }

        return $case;
    }
}
