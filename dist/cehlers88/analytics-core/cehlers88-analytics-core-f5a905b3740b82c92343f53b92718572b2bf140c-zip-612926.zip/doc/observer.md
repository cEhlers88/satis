# Observer Pattern

The observer system provides a lightweight publish/subscribe mechanism for reacting to lifecycle events. It lives in the `Cehlers88\AnalyticsCore\Observer` namespace.

## Overview

```
ObserverProvider         — dispatches messages to all registered observers
ObserverInterface        — implemented by each observer
ObserverMessageInterface — marker interface for all messages
ObserverMessageProvider  — knows every message of the system and builds one
```

## Dispatching a Message

```php
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\Worker\Observer\Message\WorkerStartedObserverMessage;

$observerProvider->dispatch(new WorkerStartedObserverMessage($workerEntity));
```

`dispatchWithReport()` does the same and says what every observer made of the
message - which one took it and which one threw. A mask that dispatches a
message by hand needs that answer, a normal dispatch does not:

```php
foreach ($observerProvider->dispatchWithReport($message) as $entry) {
    // ['observer' => 'Analytics\Observer\SysLogRelevantMessageObserver',
    //  'handled' => true, 'error' => null]
}
```

An observer that throws is logged and the dispatch continues, exactly as during
a normal dispatch.

## Implementing an Observer

```php
use Cehlers88\AnalyticsCore\Observer\ObserverInterface;
use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;
use Cehlers88\AnalyticsCore\Worker\Observer\Message\WorkerFinishedObserverMessage;

class MyObserver implements ObserverInterface
{
    public function canHandle(ObserverMessageInterface $message): bool
    {
        return $message instanceof WorkerFinishedObserverMessage;
    }

    public function handle(ObserverMessageInterface $message): void
    {
        /** @var WorkerFinishedObserverMessage $message */
        $worker = $message->getWorker();
        // React to the event...
    }
}
```

Register in `services.yaml`:
```yaml
MyObserver:
    tags:
        - { name: analytics.observer }
```

## Built-in Observer Messages

### Worker Messages (`Cehlers88\AnalyticsCore\Worker\Observer\Message`)

| Message | Trigger |
|---------|---------|
| `WorkerStartedObserverMessage` | Worker begins execution |
| `WorkerFinishedObserverMessage` | Worker completes execution |
| `WorkerErrorObserverMessage` | Worker encounters an error |

### Process Messages (`Cehlers88\AnalyticsCore\Process\Observer\Message`)

| Message | Trigger |
|---------|---------|
| `ProcessStartedObserverMessage` | Process transitions to Running |
| `ProcessFinishedObserverMessage` | Process transitions to Finished |
| `ProcessStartHandlingObserverMessage` | Before a process is handled by `ProcessProvider` |
| `ProcessFinishedHandlingObserverMessage` | After a process is handled by `ProcessProvider` |
| `ProcessErrorObserverMessage` | Process encounters an error |

### Executor Messages (`Cehlers88\AnalyticsCore\Executor\Observer\Message`)

| Message | Trigger |
|---------|---------|
| `ExecutorStartObserverMessage` | Executor begins `run()` |
| `ExecutorEndObserverMessage` | Executor finishes `run()` |

### Generic Messages (`Cehlers88\AnalyticsCore\Observer\Message`)

| Message | Trigger |
|---------|---------|
| `ErrorObserverMessage` | Generic/cross-cutting error event |

## Finding and Building Messages

Observer messages are value objects, not services, so they cannot be collected
by a tag. They all live in an `Observer\Message` namespace though, and that is
what `ObserverMessageProvider` searches for in the source directories of the
watched namespaces (`Cehlers88\` and `Analytics\` by default).

```php
foreach ($observerMessageProvider->getDefinitions() as $definition) {
    $definition->key;           // 'system.update'
    $definition->arguments;     // PropertyDTO[] - one per constructor argument
    $definition->isTriggerable; // false when an argument cannot be filled in
}

$message = $observerMessageProvider->createMessage('system.update', [
    'version' => 'v1.2.3',
    'startTime' => '2026-08-27T21:00',
]);
```

The arguments are described as `PropertyDTO`s - the same way a widget describes
its settings and a monitoring rule its arguments - so a mask builds its fields
out of them. An argument that is left out keeps the default of the message.

### Argument Resolvers

Which argument types can be filled in from the outside is decided by the
resolvers. The core brings resolvers for scalars, arrays, backed enums, dates
and exceptions; an application teaches the provider its own types by
implementing `ObserverMessageArgumentResolverInterface`:

```php
class DeviceArgumentResolver implements ObserverMessageArgumentResolverInterface
{
    public function supports(string $type): bool
    {
        return $type === Device::class;
    }

    public function describe(PropertyDTO $property): PropertyDTO
    {
        $property->ui['input'] = 'number';

        return $property;
    }

    public function resolve(string $type, mixed $value): mixed
    {
        return $this->deviceRepository->find((int)$value);
    }
}
```

Register in `services.yaml`:
```yaml
DeviceArgumentResolver:
    tags:
        - { name: analytics.observer_message_argument_resolver }
```

A message with a required argument no resolver knows is reported as not
triggerable, together with the reason - it can only be dispatched by the code
that owns it.
