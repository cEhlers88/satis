<?php

namespace Cehlers88\AnalyticsCore\Process\Runner;

use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\Process\ProcessResultWorkerProvider;
use Throwable;

/** Interface for process runners. */
interface ProcessRunnerInterface
{
    /**
     * @param bool $createIfNotExist
     * @return Process|null
     */
    public function getProcess(bool $createIfNotExist = true): ?Process;

    /** @return array<string, mixed> */
    public function getArguments(): array;

    /** @return array<int, string> */
    public function getRequiredArguments(): array;

    /** Validate that all required arguments are present. */
    public function validate(): static;

    /**
     * @throws Throwable
     */
    public function run(): void;

    public function getProcessResult(): mixed;

    public function getResultStatusCode(): int;

    public function setProcessResultWorkerProvider(ProcessResultWorkerProvider $resultWorkerProvider): static;
}