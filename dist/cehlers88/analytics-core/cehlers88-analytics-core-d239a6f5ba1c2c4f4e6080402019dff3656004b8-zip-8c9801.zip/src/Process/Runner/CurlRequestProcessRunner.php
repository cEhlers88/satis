<?php

namespace Cehlers88\AnalyticsCore\Process\Runner;

use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

/** Process runner that executes cURL HTTP requests. */
class CurlRequestProcessRunner extends AbstractProcessRunner
{
    public const ARGUMENT_KEY_HOST = 'host';

    protected int $defaultTimeout = 10;
    protected bool $returnTransfer = true;

    /** {@inheritdoc} */
    public function handle(): void
    {
        if ($this->process->hasState(eRunningState::Running)) {
            return;
        }
        if ($this->process->hasState(eRunningState::WillStart)) {
            if ($this->process->hasState(eRunningState::BufferComplete)) {
                $this->startRequest();
                return;
            }

            $this->process
                ->removeState(eRunningState::WillStart)
                ->addState(eRunningState::Buffering)
                ->setStartedAt(new \DateTime());;

            return;
        }
        if ($this->process->hasState(eRunningState::Buffering)) {
            $this->process
                ->removeState(eRunningState::Buffering)
                ->addState(eRunningState::BufferComplete);
            return;
        }
        if ($this->process->hasState(eRunningState::BufferComplete)) {
            $this->process
                ->addState(eRunningState::WillStart);
        }
        if ($this->process->hasState(eRunningState::ResultProcessed)) {
            $this->process->addState(eRunningState::Finished);
        }
    }

    /**
     * Handles the initiation of a request process and manages its states.
     *
     * This method performs the following actions:
     * - Updates the process states to indicate the start of the request.
     * - Fetches configuration values like host, port, HTTP method, headers, body, and timeout
     *   from the process runner attributes.
     * - Initializes and configures a cURL request with the retrieved parameters.
     * - Sends the HTTP request and retrieves the response.
     * - Handles errors by setting error information if the request fails.
     * - Processes the response and updates the process states accordingly.
     */
    private function startRequest(): void
    {
        $this->process
            ->removeState(eRunningState::WillStart)
            ->removeState(eRunningState::BufferComplete)
            ->addState(eRunningState::Running);

        $host = $this->getProcess()->getRunnerAttributeValue(self::ARGUMENT_KEY_HOST);
        $defaultPort = strpos(strtolower($host), 'https') === false ? 80 : 443;
        $port = $this->getProcess()->getRunnerAttributeValue('port', $defaultPort);
        $method = $this->getProcess()->getRunnerAttributeValue('method', 'GET');
        $headers = $this->getProcess()->getRunnerAttributeValue('headers', []);
        $body = $this->getProcess()->getRunnerAttributeValue('body', '');
        $timeout = $this->getProcess()->getRunnerAttributeValue('timeout', $this->defaultTimeout);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $host);
        curl_setopt($ch, CURLOPT_PORT, $port);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->enrichHeaders($headers));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, $this->returnTransfer);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $this->enrichBody($body));
        $response = curl_exec($ch);

        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $info = curl_getinfo($ch);

        $this->process
            ->removeState(eRunningState::Running);

        if ($response === false) {
            //$this->setError($error, $errno);
            switch ($errno) {
                case CURLE_OPERATION_TIMEDOUT:
                    $this->handleCurlResult('', 523);
                    return;
            }
        }


        $this->handleCurlResult($response, $info['http_code'] ?? 200);
        $this->process
            ->addState(eRunningState::Finishing);
    }

    /**
     * Enrich request headers before sending.
     *
     * @param array<int, string> $headers
     * @return array<int, string>
     */
    protected function enrichHeaders(array $headers): array
    {
        return $headers;
    }

    /**
     * Enrich request body before sending.
     *
     * @param mixed $body
     * @return mixed
     */
    protected function enrichBody(mixed $body): mixed
    {
        return $body;
    }

    /**
     * Handle the cURL response.
     *
     * @param string $response
     * @param int $statusCode
     */
    protected function handleCurlResult(string $response, int $statusCode = 200)
    {
        $details = $this->process->getDetails();

        $details['responseCode'] = $statusCode;
        $details['result'] = $response;

        $this->process->setDetails($details);

        $this->process
            ->addState(eRunningState::ResultReceived)
            ->addState(eRunningState::ProcessingResult);
    }

    /** {@inheritdoc} */
    public function getRequiredArguments(): array
    {
        return [
            self::ARGUMENT_KEY_HOST
        ];
    }

    public function getProcessResult(): mixed
    {
        return $this->process?->getDetails()['result'] ?? null;
    }

    public function getResultStatusCode(): int
    {
        return $this->process?->getDetails()['responseCode'] ?? -1;
    }


}