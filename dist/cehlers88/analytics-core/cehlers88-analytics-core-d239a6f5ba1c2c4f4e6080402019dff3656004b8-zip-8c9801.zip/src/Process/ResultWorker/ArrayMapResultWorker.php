<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

class ArrayMapResultWorker extends AbstractProcessResultWorker
{
    /**
     * @param array $result
     */
    public function handleResult(mixed $result): static
    {
        foreach ($result as $key => $value) {
            // map throw
        }

        return $this;
    }

}