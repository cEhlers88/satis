<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

/** Result worker that modifies tracking buffer entries. */
class ModifyTrackingBufferResultWorker extends AbstractProcessResultWorker
{
    public function handleResult(mixed $result): static
    {
        $this->process
            ->addState(eRunningState::ResultProcessed)
            ->removeState(eRunningState::ProcessingResult);
        return $this;
    }


}