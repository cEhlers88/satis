<?php

namespace Cehlers88\AnalyticsCore\Process;

use Cehlers88\AnalyticsCore\Process\ResultWorker\ProcessResultWorkerInterface;

class ProcessResultWorkerProvider
{
    public function __construct(
        private iterable $processResultWorkers
    )
    {

    }

    public function getResultWorkerByClass(string $class): ?ProcessResultWorkerInterface
    {
        foreach ($this->processResultWorkers as $processResultWorker) {
            if ($processResultWorker::class === $class) {
                return $processResultWorker;
            }
        }
        return null;
    }

    public function getResultWorkers(): iterable
    {
        return $this->processResultWorkers;
    }
}