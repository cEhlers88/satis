<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Service;

use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Presentation\QuickStatusInfoDTO;

/** Service providing quick status information for entities. */
class QuickStatusInfoProvider
{
    /**
     * Generate quick status info from a source object.
     *
     * @param object $sourceObject
     * @return QuickStatusInfoDTO
     */
    public function generate(object $sourceObject): QuickStatusInfoDTO
    {
        if ($sourceObject instanceof Process) {
            return $this->generateByProcess($sourceObject);
        }

        return new QuickStatusInfoDTO();
    }

    /**
     * Generate quick status info from a Process entity.
     *
     * @param Process $process
     * @return QuickStatusInfoDTO
     */
    public function generateByProcess(Process $process): QuickStatusInfoDTO
    {
        $result = new QuickStatusInfoDTO();

        $messages = [];

        if ($process->hasState(eRunningState::Error) || $process->hasState(eRunningState::FatalError)) {
            $result->hasError = true;
            $messages[] = 'Error';
        }

        if ($process->hasState(eRunningState::BufferComplete)) {
            $result->percentage = 30;
            $messages[] = 'Buffer complete';

            if ($process->hasState(eRunningState::WillStart)) {
                $result->percentage = 40;
                $messages[] = 'Will start';
            }
        }

        if ($process->hasState(eRunningState::Running)) {
            $result->percentage = 45;
            $messages[] = 'Running';
        }

        if ($process->hasState(eRunningState::WillStart)) {
            $result->percentage = 10;
            $messages[] = 'Will start';
        }

        if ($process->hasState(eRunningState::ProcessingResult)) {
            $result->percentage = 60;
            $messages[] = 'Processing result';
        }
        if ($process->hasState(eRunningState::ResultProcessed)) {
            $result->percentage = 80;
            $messages[] = 'Result processed';
        }

        if ($process->hasState(eRunningState::Finished)) {
            $result->percentage = 100;
            $messages[] = 'Finished';
        }

        if ($process->hasState(eRunningState::Finishing)) {
            $result->percentage = 80;
            $messages[] = 'Finishing';
        }

        if ($process->hasState(eRunningState::Buffering)) {
            $result->percentage = 20;
            $messages[] = 'Buffering';
        }

        $result->message = implode(', ', $messages);

        return $result;
    }
}