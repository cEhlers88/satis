<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 21.05.2024
 * Time: 20:06
 */

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\InputRenderer;

use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\DTO\DomElementPropsDTO;
use CEhlers88\AnalyticsCore\ENUM\eInputType;

abstract class AbstractInputRenderer
{
    protected $value;
    protected string $namePrefix;
    protected string $nameSuffix;
    private $childRenderer;
    private string $nameSeparator = '.';

    abstract public function canRender(eInputType $inputType, $value): bool;

    public function enrichChildInteractions(array $interactions): array
    {
        return $interactions;
    }

    public function setChildRenderer(callable $childRenderer): void
    {
        $this->childRenderer = $childRenderer;
    }

    public function setNamePrefix(string $namePrefix): AbstractInputRenderer
    {
        $this->namePrefix = $namePrefix;
        return $this;
    }

    public function setNameSuffix(string $nameSuffix): AbstractInputRenderer
    {
        $this->nameSuffix = $nameSuffix;
        return $this;
    }

    public function renderChild($value, ConfigurationItemDTO $configurationItemDTO, $namePrefix = "", $nameSuffix = "", $returnRendered = true): string|array
    {
        return ($this->childRenderer)($value, $configurationItemDTO, $namePrefix, $nameSuffix, $returnRendered);
    }

    final public function doRender($value, ConfigurationItemDTO $configurationItemDTO): array
    {
        $this->setValue($value);
        return [
            'domDefinition' => $this->getDomDefinition($configurationItemDTO),
            'hadError' => false,
            'html' => $this->renderHtml($configurationItemDTO),
            'name' => $this->buildInputName($configurationItemDTO->key),
            'interactions' => $this->getInteractions($configurationItemDTO),
        ];
    }

    public function setValue($value): AbstractInputRenderer
    {
        $this->value = $value;
        return $this;
    }

    abstract public function getDomDefinition(ConfigurationItemDTO $configurationItemDTO): DomElementPropsDTO;

    abstract public function renderHtml(ConfigurationItemDTO $configurationItemDTO): string;

    public function buildInputName(string $nameRaw): string
    {
        $nameEntries = [];

        if (!empty($this->namePrefix)) {
            $nameEntries[] = $this->namePrefix;
        }

        $nameEntries[] = $nameRaw;

        if (!empty($this->nameSuffix) && $this->nameSuffix !== '[]') {
            $nameEntries[] = $this->nameSuffix;
        }

        return implode($this->nameSeparator, $nameEntries);
    }

    public function getInteractions(ConfigurationItemDTO $configurationItemDTO): array
    {
        $result = [];
        if ($configurationItemDTO->deletable) {
            $result[] = [
                'tag' => 'remover',
                'html' => '<span>X</span>',
            ];
        }
        return $result;
    }
}