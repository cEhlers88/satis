<?php

namespace Cehlers88\AnalyticsCore\Presentation\ServerSideRenderer;

interface ServerSideRendererInterface
{
    public function render(): string;

    public function getKey(): string;

    public function setData(array $data): static;

    public function getDataValue(string $key, $default = null): mixed;
}