<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 31.08.2024
 * Time: 23:47
 */

namespace Cehlers88\AnalyticsCore\Presentation\ServerSideRenderer;

abstract class AbstractServerSideRenderer implements ServerSideRendererInterface
{
    protected array $_data = [];

    abstract public function getKey(): string;

    public function render(): string
    {
        return '';
    }

    public function getDataValue(string $key, $default = null): mixed
    {
        return $this->_data[$key] ?? $default;
    }

    public function setData(array $data): static
    {
        $this->_data = $data;
        return $this;
    }
}