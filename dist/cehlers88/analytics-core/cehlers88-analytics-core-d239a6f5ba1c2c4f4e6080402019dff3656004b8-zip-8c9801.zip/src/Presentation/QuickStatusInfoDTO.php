<?php

namespace Cehlers88\AnalyticsCore\Presentation;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;
use Cehlers88\AnalyticsCore\DTO\DTO;

/** Data transfer object for quick status information. */
class QuickStatusInfoDTO extends DTO
{
    /** @var BadgeDTO[] */
    public array $badges = [];
    /** @var string|null */
    public ?string $message = null;
    /** @var string|null */
    public ?string $icon = null;
    /** @var bool */
    public bool $hasError = false;
    /** @var bool */
    public bool $hasWarning = false;

    /** @var float|null */
    public ?float $percentage = null;

    public string $trafficLightColor = "#76a64d";

    public static function createFromArray(array $definition): static
    {
        return new self();
    }
}