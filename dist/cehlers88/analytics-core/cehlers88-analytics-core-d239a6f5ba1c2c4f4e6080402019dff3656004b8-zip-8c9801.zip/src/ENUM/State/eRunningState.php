<?php

namespace Cehlers88\AnalyticsCore\ENUM\State;

/**
 * Represents the possible running states of an entity.
 */
enum eRunningState: int
{
    case New = 1 << 0;
    case NeedsValidation = 1 << 2;
    case Idle = 1 << 3;
    case WillStart = 1 << 4;
    case Starting = 1 << 5;

    case Warning = 1 << 7;

    case Running = 1 << 10;
    case Ran = 1 << 11;

    case StartingSubProcess = 1 << 12;
    case RunningSubProcess = 1 << 13;
    case Paused = 1 << 15;
    case Waiting = 1 << 16;
    case ResultReceived = 1 << 17;
    case ProcessingResult = 1 << 18;
    case ResultProcessed = 1 << 19;
    case Buffering = 1 << 20;
    case BufferComplete = 1 << 23;
    case Finishing = 1 << 25;
    case Finished = 1 << 27;
    case Canceled = 1 << 29;
    case Error = 1 << 30;
    case Invalid = 1 << 35;
    case InvalidSubProcess = 1 << 37;
    case ErrorInSubProcess = 1 << 40;
    case Dangerous = 1 << 41;
    case Suspicious = 1 << 43;
    case NoWork = 1 << 45;
    case Timeout = 1 << 47;
    case TimeoutInSubProcess = 1 << 48;
    case FatalError = 1 << 50;
    case Maintenance = 1 << 55;
    case Unknown = 1 << 60;

    /**
     * Converts all enum cases to a key-value array.
     *
     * @param string $keyName The key name for the case name.
     * @param string $valueName The key name for the case value.
     * @return array
     */
    public static function toKeyValueArray(
        string $keyName = 'key',
        string $valueName = 'value'
    ): array
    {
        return array_map(fn($e) => [
            $keyName => $e->name,
            $valueName => $e->value
        ], self::cases());
    }
}
