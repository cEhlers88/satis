<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Presentation\QuickStatusInfoDTO;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * Base class for entities that can be run and have a state.
 */
class AbstractRunnableEntity extends AbstractEntity
{
    #[ORM\Column(type: Types::BIGINT)]
    protected ?string $state = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    protected ?\DateTimeInterface $startedAt = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    protected ?\DateTimeInterface $finishedAt = null;

    #[ORM\Column]
    protected ?bool $enabled = null;

    /** Initializes the entity with the New state. */
    public function __construct()
    {
        parent::__construct();
        $this->setState(eRunningState::New);
    }

    /**
     * Adds one or more states to the current state bitmask.
     *
     * @param eRunningState ...$states The states to add.
     * @return static
     */
    public function addState(eRunningState ...$states): static
    {
        $current = $this->state !== null
            ? (int)$this->state
            : eRunningState::Unknown->value;

        foreach ($states as $state) {
            if ($state === eRunningState::Unknown) {
                continue;
            }

            if ($current === eRunningState::Unknown->value) {
                $current = $state->value;
            } else {
                $current |= $state->value;
            }
        }

        $this->state = (string)$current;

        return $this;
    }

    /** Returns the started-at timestamp. */
    public function getStartedAt(): ?\DateTimeInterface
    {
        return $this->startedAt;
    }

    /** Sets the started-at timestamp. */
    public function setStartedAt(?\DateTimeInterface $startedAt): static
    {
        $this->startedAt = $startedAt;

        return $this;
    }

    /** Returns the finished-at timestamp. */
    public function getFinishedAt(): ?\DateTimeInterface
    {
        return $this->finishedAt;
    }

    /** Sets the finished-at timestamp. */
    public function setFinishedAt(?\DateTimeInterface $finishedAt): static
    {
        $this->finishedAt = $finishedAt;

        return $this;
    }

    /**
     * @return eRunningState[]
     */
    public function getState(): array
    {
        $value = $this->state ?? eRunningState::Unknown->value;

        if ($value === eRunningState::Unknown->value) {
            return [eRunningState::Unknown];
        }

        $result = [];

        foreach (eRunningState::cases() as $case) {
            if ($case === eRunningState::Unknown) {
                continue;
            }

            if ($value & $case->value) {
                $result[] = $case;
            }
        }

        return $result;
    }

    /**
     * @param eRunningState ...$states
     * @return $this
     */
    public function setState(eRunningState ...$states): static
    {
        if ($states === []) {
            $this->state = eRunningState::Unknown->value;
            return $this;
        }

        $value = 0;

        foreach ($states as $state) {
            if ($state === eRunningState::Unknown) {
                continue;
            }

            $value |= $state->value;
        }

        $this->state = $value === 0 ? eRunningState::Unknown->value : $value;

        return $this;
    }

    /** Returns the raw integer value of the state bitmask. */
    public function getStateValue(): int
    {
        return (int)($this->state ?? eRunningState::Unknown->value);
    }

    /** Checks if the entity is enabled and waiting to run. */
    public function isWaiting(): bool
    {
        return $this->isEnabled() &&
            !$this->hasState(eRunningState::Running) &&
            (is_null($this->getNextRunAt()) || $this->getNextRunAt() < new \DateTime());
    }

    /** Returns whether the entity is enabled. */
    public function isEnabled(): bool
    {
        return $this->enabled ?? false;
    }

    /**
     * Checks if the entity has a specific state.
     *
     * @param eRunningState $state The state to check for.
     * @return bool
     */
    public function hasState(eRunningState $state): bool
    {
        $current = (int)($this->state ?? eRunningState::Unknown->value);
        return ($current & $state->value) !== 0;
    }

    /**
     * Removes one or more states from the current state bitmask.
     *
     * @param eRunningState ...$states The states to remove.
     * @return static
     */
    public function removeState(eRunningState ...$states): static
    {
        $current = $this->state ?? eRunningState::Unknown->value;

        foreach ($states as $state) {
            if ($state === eRunningState::Unknown) {
                continue;
            }

            $current &= ~$state->value;
        }

        if ($current === 0) {
            $current = eRunningState::Unknown->value;
        }

        $this->state = $current;

        return $this;
    }

    /** Sets whether the entity is enabled. */
    public function setEnabled(bool $enabled): static
    {
        $this->enabled = $enabled;

        return $this;
    }

    public function getQuickInfo(): QuickStatusInfoDTO
    {
        $result = new QuickStatusInfoDTO();

        if ($this->hasState(eRunningState::Warning)) {
            $result->hasWarning = true;
            $result->trafficLightColor = '#ff7400';
        }
        if ($this->hasState(eRunningState::Error) || $this->hasState(eRunningState::FatalError)) {
            $result->hasError = true;
            $result->trafficLightColor = '#c35151';
        }

        if (!$this->isEnabled()) {
            $result->trafficLightColor = '#4da697';
        }

        return $result;
    }


    /** Sets the state bitmask from a raw integer value. */
    public function setStateValue(int $value): static
    {
        $this->state = (string)$value;
        return $this;
    }

    /**
     * Adds a state to the history.
     *
     * @param eRunningState|null $state The state to add, or null to add the current state.
     * @return $this
     */
    public function addStateToHistory(?eRunningState $state = null): static
    {
        return $this;
    }

    /**
     * Returns the state history.
     *
     * @return array
     */
    public function getStateHistory(): array
    {
        return [];
    }
}