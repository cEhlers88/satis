<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\RunChain;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * Repository for Worker entities.
 *
 * @extends ServiceEntityRepository<Worker>
 *
 * @method Worker|null find($id, $lockMode = null, $lockVersion = null)
 * @method Worker|null findOneBy(array $criteria, array $orderBy = null)
 * @method Worker[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class WorkerRepository extends AbstractRepository
{
    public function __construct(ManagerRegistry $registry, private EntityManagerInterface $entityManager)
    {
        parent::__construct($registry, Worker::class);
    }

    public function findAll(): array
    {
        return $this->createPrefilteredQueryBuilder('w')
            ->orderBy('w.application', 'ASC')
            ->addOrderBy('w.priority', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function findBy_applicationIds(array $applicationIds, bool $onlyEnabled = true): array
    {
        $querBuilder = $this->createPrefilteredQueryBuilder('w')
            ->join('w.application', 'a')
            ->andWhere('a.id IN (:applicationIds)')
            ->setParameter('applicationIds', $applicationIds);
        if ($onlyEnabled) {
            $querBuilder->andWhere('w.enabled = 1');
        }

        return $querBuilder->getQuery()
            ->getResult();
    }

    public function findBy_priority(int $priority, RunChain $runChainFilter): array
    {
        return $this->createPrefilteredQueryBuilder('w')
            ->andWhere('w.priority = :priority')
            ->andWhere(':runChain MEMBER OF w.runChains')
            ->setParameter('priority', $priority)
            ->getQuery()
            ->getResult();
    }

    /**
     * Returns all workers that are waiting to be executed
     * @param RunChain $runChainFilter
     * @param Worker[] $excludeWorkers
     * @param bool $includeErroredWorkersRegardlessOfState
     * @return array<Worker>
     */
    public function fetchWaitingWorkers(
        RunChain $runChainFilter,
        array    $excludeWorkers = [],
        bool     $includeErroredWorkersRegardlessOfState = false,
    ): array
    {
        $excludeIds = array_map(
            static fn(Worker $w) => $w->getId(),
            $excludeWorkers
        );

        $qb = $this->createPrefilteredQueryBuilder('w')
            ->andWhere('w.nextRunAt < :now OR w.nextRunAt IS NULL')
            ->andWhere('w.enabled = 1')
            ->andWhere(':runChain MEMBER OF w.runChains')
            ->setParameter('now', new \DateTime())
            ->setParameter('runChain', $runChainFilter)
            ->orderBy('w.priority', 'DESC');

        if ($includeErroredWorkersRegardlessOfState) {
            $qb->andWhere(sprintf(
                '(BIT_AND(w.state, %d) = 0 OR BIT_AND(w.state, %d) > 0)',
                eRunningState::Running->value,
                eRunningState::Error->value,
            ));
        } else {
            $qb->andWhere(sprintf(
                'BIT_AND(w.state, %d) = 0',
                eRunningState::Running->value,
            ));
        }

        if (count($excludeIds) > 0) {
            $qb
                ->andWhere('w.id NOT IN (:excludeWorkers)')
                ->setParameter('excludeWorkers', $excludeIds);
        }

        return $qb->getQuery()->getResult();
    }

    public function setWorkerStarted(Worker $worker, bool $saveAndFlush = false): WorkerRepository
    {
        $store = $worker->getStore();
        $store->lastData = $store->currentData;
        $worker
            ->setStarted()
            ->setUpdatedAt(new \DateTime())
            ->setStore($store);

        $this->save($worker, $saveAndFlush);
        return $this;
    }

    public function save(Worker $worker, bool $flush = false): WorkerRepository
    {
        try {

            $this->entityManager->persist($worker);
            if (!$flush) {
                return $this;
            }

            $this->entityManager->flush();
        } catch (\Throwable $e) {
            throw $e;
        }
        return $this;
    }

    public function setWorkerIdle(Worker $worker, bool $saveAndFlush = false): WorkerRepository
    {
        $worker->setIdle();
        if (!$saveAndFlush) {
            return $this;
        }
        $this->save($worker, true);
        return $this;
    }

    public function setWorkerFinished(
        Worker          $worker,
        WorkerResultDTO $workerResultDTO,
        int             $state,
        bool            $saveAndFlush = false
    ): Worker
    {
        $worker
            ->finishWorker($workerResultDTO, $state)
            ->setUpdatedAt(new \DateTime())
        ;

        if (!$saveAndFlush) {
            return $worker;
        }

        $this->save($worker, $saveAndFlush);
        return $worker;
    }

    public function addRunChainToWorkerSimple(int $workerId, int $runChainId, bool $flush = true): WorkerRepository
    {
        return $this->addRunChainToWorker($this->find($workerId), $this->entityManager->getReference(RunChain::class, $runChainId), $flush);
    }

    public function addRunChainToWorker(Worker $worker, RunChain $runChain, bool $flush = true): WorkerRepository
    {
        $worker->addRunChain($runChain);
        return $this->save($worker, $flush);
    }

    public function removeRunChainFromWorkerSimple(int $workerId, int $runChainId, bool $flush = true): WorkerRepository
    {
        return $this->removeRunChainFromWorker($this->find($workerId), $this->entityManager->getReference(RunChain::class, $runChainId), $flush);
    }

    public function removeRunChainFromWorker(Worker $worker, RunChain $runChain, bool $flush = true): WorkerRepository
    {
        $worker->removeRunChain($runChain);
        return $this->save($worker, $flush);
    }
}
