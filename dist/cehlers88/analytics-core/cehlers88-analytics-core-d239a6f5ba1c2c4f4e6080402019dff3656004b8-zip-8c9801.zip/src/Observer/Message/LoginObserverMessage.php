<?php

namespace Cehlers88\AnalyticsCore\Observer\Message;

/** Observer message dispatched when a user logs in. */
class LoginObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'system.login';

    public function __construct(
        public string $username,
        public string $ip = ''
    )
    {
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}