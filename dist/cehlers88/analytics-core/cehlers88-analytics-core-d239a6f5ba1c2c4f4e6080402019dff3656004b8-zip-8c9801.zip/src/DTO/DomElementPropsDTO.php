<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 25.05.2024
 * Time: 23:18
 */

namespace Cehlers88\AnalyticsCore\DTO;

class DomElementPropsDTO extends DTO
{
    public string $tagName = '';
    public array $attributes = [];
    public array $children = [];
}