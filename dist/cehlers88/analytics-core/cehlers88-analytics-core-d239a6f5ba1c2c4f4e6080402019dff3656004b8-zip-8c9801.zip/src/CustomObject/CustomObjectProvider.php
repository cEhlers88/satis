<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:40
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Repository\CustomEntityRepository;

/** Provider for managing custom object instances. */
class CustomObjectProvider
{
    public function __construct(
        private iterable               $customEntityClasses,
        private CustomEntityRepository $customEntityRepository
    )
    {
    }

    /**
     * @param CustomObjectInterface $customEntity
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClass(CustomObjectInterface $customEntity): array
    {
        return $this->getCustomEntitiesByClassName($customEntity->getClassName());
    }

    /**
     * @param string $className
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClassName(string $className): array
    {
        $customEntities = [];

        $buffer = [];
        $parentIdList = [];

        foreach ($this->customEntityRepository->findBy(['className' => $className]) as $customEntity) {
            $buffer[] = [
                'customEntity' => $customEntity,
                'children' => []
            ];
            $parentIdList[] = $customEntity->getId();
        }

        foreach ($this->customEntityRepository->findBy(['parentId' => $parentIdList]) as $customEntity) {
            foreach ($buffer as &$entry) {
                if ($entry['customEntity']->getId() === $customEntity->getParentId()) {
                    $entry['children'][] = $this->resolveCustomEntity($customEntity);
                    break;
                }
            }
        }

        foreach ($buffer as $entry) {

            $customEntities[] = $this->resolveCustomEntity($entry['customEntity'], $entry['children']);
        }

        return $customEntities;
    }

    /**
     * Resolve a CustomEntity into a CustomObjectInterface instance.
     *
     * @param CustomEntity $customEntity The entity to resolve.
     * @return CustomObjectInterface
     */
    public function resolveCustomEntity(CustomEntity $customEntity, array $childObjects = []): CustomObjectInterface
    {
        $className = $customEntity->getClassName();

        /** @var CustomObjectInterface $instance */
        $instance = new $className();
        $instance->load($customEntity, $childObjects);

        return $instance;
    }

    /** Get all registered custom entity classes. */
    public function getCustomClasses(): iterable
    {
        return $this->customEntityClasses;
    }
}