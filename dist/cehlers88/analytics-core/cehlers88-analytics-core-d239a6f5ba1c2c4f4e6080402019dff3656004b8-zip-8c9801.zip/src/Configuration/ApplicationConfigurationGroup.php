<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 20:16
 */

namespace Cehlers88\AnalyticsCore\Configuration;

use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

class ApplicationConfigurationGroup extends AbstractConfigurationGroup
{
    public const KEY = 'application_setup';

    public function __construct()
    {
    }

    public function getItems(): array
    {
        return [
            ConfigurationItemDTO::create('name', 'Name'),
            ConfigurationItemDTO::create('description', 'Description', eInputType::TEXT_MULTI_LINE),
            ConfigurationItemDTO::create('token', 'Token'),
            ConfigurationItemDTO::create('color', 'Color'),
        ];
    }

    public function getGroupTitle(): string
    {
        return 'Application settings';
    }

    public function getGroupDescription(): string
    {
        return 'This group contains general process settings.';
    }

    public function getKey(): string
    {
        return self::KEY;
    }

    public function getViewContext(): string
    {
        return 'application_setup';
    }
}