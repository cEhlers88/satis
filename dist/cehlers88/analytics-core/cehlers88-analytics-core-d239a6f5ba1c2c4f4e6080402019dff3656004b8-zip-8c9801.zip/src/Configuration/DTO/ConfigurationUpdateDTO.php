<?php

namespace Cehlers88\AnalyticsCore\Configuration\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;

class ConfigurationUpdateDTO extends DTO
{
    public string $action = '';
    public ConfigurationItemDTO $configurationItemDTO;

    public static function createSetValue(
        string $key,
        mixed  $value
    ): ConfigurationUpdateDTO
    {
        $dto = new ConfigurationUpdateDTO();
        $dto->action = 'set_value';
        $dto->configurationItemDTO = ConfigurationItemDTO::create($key);
        $dto->configurationItemDTO->defaultValue = $value;

        return $dto;
    }
}