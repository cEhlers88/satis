<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 07.05.2024
 * Time: 21:46
 */

namespace Cehlers88\AnalyticsCore\Support;

use Analytics\DTO\UI\MenuItemDTO;
use Analytics\Interface\IBundlePlugin;
use Symfony\Component\HttpKernel\Bundle\Bundle;

abstract class AbstractBundlePlugin extends Bundle implements IBundlePlugin
{
    abstract public function getDescription(): string;

    abstract public function getVersion(): string;

    /**
     * @return MenuItemDTO[]
     */
    public function getMenuItems(): array
    {
        return [];
    }

    public function getPermissions(): array
    {
        return [];
    }

    public function handleInstall(): array
    {
        return [];
    }

    public function handleUpdate(string $previousVersion): array
    {
        return [];
    }

    public function getTrackingBufferKeys(): array
    {
        return [];
    }
}