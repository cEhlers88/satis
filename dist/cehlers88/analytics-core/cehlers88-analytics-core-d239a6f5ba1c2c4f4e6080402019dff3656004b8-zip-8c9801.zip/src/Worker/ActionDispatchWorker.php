<?php

namespace Cehlers88\AnalyticsCore\Worker;

use Analytics\DTO\PropertyDTO;

class ActionDispatchWorker extends AbstractWorker
{
    public function __construct()
    {
        //$this->addProperty(PropertyDTO::create('criteria', [], 'array'));
        //$this->addProperty(PropertyDTO::create('order', [], 'array', true));
        $this->addProperty(PropertyDTO::create('action_name', '', 'string', false));
        $this->addProperty(PropertyDTO::create('offset', 0, 'int', true));
    }

    public function getWorkingObjects(): array
    {
        return [];
    }
}