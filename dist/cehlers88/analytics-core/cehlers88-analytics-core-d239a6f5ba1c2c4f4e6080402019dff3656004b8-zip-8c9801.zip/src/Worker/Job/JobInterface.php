<?php

namespace Cehlers88\AnalyticsCore\Worker\Job;

use Cehlers88\AnalyticsCore\Worker\WorkerInterface;

/** Interface for worker jobs. */
interface JobInterface
{
    public function getDescription(): string;

    public function setWorker(WorkerInterface $worker): self;

    public function willHandle(object $workingObject): bool;
}