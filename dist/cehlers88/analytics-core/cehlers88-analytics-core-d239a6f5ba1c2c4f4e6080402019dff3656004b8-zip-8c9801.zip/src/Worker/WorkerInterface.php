<?php

namespace Cehlers88\AnalyticsCore\Worker;

use Cehlers88\AnalyticsCore\Worker\Job\JobInterface;

/** Interface for background workers. */
interface WorkerInterface
{
    /**
     * Configure the worker with the given properties.
     *
     * @param array $properties Configuration properties.
     * @return static
     */
    public function configure(array $properties): static;

    /**
     * Get the list of required job class names.
     *
     * @return array<string>
     */
    public function getRequiredJobs(): array;

    /** Set a benchmark value. */
    public function setBenchmarkValue(string $key, mixed $value): static;

    /** Get all benchmark data. */
    public function getBenchmark(): array;

    public function getJobByClassName(string $className): ?JobInterface;

    /** Check whether the worker reached its timeout. */
    public function reachedTimeout(): bool;

    /**
     * Store a value in the temporary shared data store for the duration of the worker run.
     *
     * @param string $key   The key to store the value under.
     * @param mixed  $value The value to store.
     * @return static
     */
    public function setSharedData(string $key, mixed $value): static;

    /**
     * Retrieve a value from the temporary shared data store.
     *
     * @param string $key     The key to retrieve.
     * @param mixed  $default Default value when the key does not exist.
     * @return mixed
     */
    public function getSharedData(string $key, mixed $default = null): mixed;

    /**
     * Check whether the temporary shared data store contains the given key.
     *
     * @param string $key The key to check.
     * @return bool
     */
    public function hasSharedData(string $key): bool;

    /**
     * Remove a single entry from the temporary shared data store.
     *
     * @param string $key The key to remove.
     * @return static
     */
    public function removeSharedData(string $key): static;

    /**
     * Clear the entire temporary shared data store.
     *
     * @return static
     */
    public function clearSharedData(): static;
}