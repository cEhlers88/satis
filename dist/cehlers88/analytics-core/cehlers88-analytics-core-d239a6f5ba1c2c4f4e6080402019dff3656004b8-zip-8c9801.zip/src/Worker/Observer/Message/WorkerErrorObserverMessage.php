<?php

namespace Cehlers88\AnalyticsCore\Worker\Observer\Message;

use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;

/** Observer message dispatched when a worker error occurs. */
class WorkerErrorObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'worker.error';

    public function __construct(
        public Worker $workerEntity,
        public array  $additionalData = []
    )
    {

    }

    public function getKey(): string
    {
        return self::KEY;
    }
}