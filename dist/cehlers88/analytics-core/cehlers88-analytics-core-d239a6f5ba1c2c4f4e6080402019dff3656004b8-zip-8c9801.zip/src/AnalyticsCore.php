<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 18:59
 */

namespace Cehlers88\AnalyticsCore;

use Cehlers88\AnalyticsCore\Support\AbstractBundlePlugin;

/**
 * Core bundle plugin for AnalyticsCore.
 */
class AnalyticsCore extends AbstractBundlePlugin
{
    public function getDescription(): string
    {
        return 'Core bundle';
    }

    public function getMenuItems(): array
    {
        return [

        ];
    }

    public function getPermissions(): array
    {
        return [

        ];
    }

    public function getVersion(): string
    {
        return '1.0.0';
    }
}