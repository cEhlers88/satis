<?php

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Symfony\Component\HttpFoundation\Request;

interface IServiceEndpointRunner
{
    public function canHandle(string $endpoint, Request $request): bool;

    public function runEndpoint(Request $request): ServiceEndpointRunnerResultDTO;

    /**
     * @return array<string,string>|string
     */
    public function getEndpoints(): mixed;

    /**
     * @return string[]
     */
    public function getRequiredRoles(): array;

    /**
     * @return EndpointDefinitionDTO[]
     */
    public function getEndpointDefinitions(): array;
}