<?php

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;

class ServiceEndpointRunnerResultDTO extends DTO
{
    public bool $hasError = false;
    public string $message = '';
    public array $data = [];

    private function __construct()
    {
    }

    public static function createError(string $message): ServiceEndpointRunnerResultDTO
    {
        $result = new ServiceEndpointRunnerResultDTO();
        $result->hasError = true;
        $result->message = $message;
        return $result;
    }

    public static function createSuccess(array $data, string $message = ''): ServiceEndpointRunnerResultDTO
    {
        $result = new ServiceEndpointRunnerResultDTO();
        $result->data = $data;
        $result->message = $message;
        return $result;
    }
}