<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 06.09.2024
 * Time: 03:25
 */

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Symfony\Component\HttpFoundation\Request;

abstract class AbstractServiceEndpointRunner implements IServiceEndpointRunner
{
    protected bool $hasError = false;
    protected ?string $errorMessage = null;
    protected ?User $user = null;

    /** @var EndpointDefinitionDTO[]|null */
    private ?array $endpointDefinitions = null;

    public function canHandle(string $endpoint, Request $request): bool
    {
        if (is_null($this->endpointDefinitions)) {
            $this->_generateEndpointDefinitions();
        }

        foreach ($this->endpointDefinitions as $endpointDefinition) {
            if ($endpointDefinition->name === $endpoint) {
                return true;
            }
        }

        return false;
    }

    private function _generateEndpointDefinitions(): void
    {
        $this->endpointDefinitions = [];

        $endpoints = $this->getEndpoints();
        if (is_string($endpoints)) {
            $endpoints = [$endpoints];
        }

        $namePrefix = empty($this->getBundleName()) ? '' : $this->getBundleName() . '.';

        foreach ($endpoints as $endpoint) {
            if (is_string($endpoint)) {
                $dto = new EndpointDefinitionDTO();
                $dto->name = $endpoint;
                $dto->methods = ['GET', 'POST'];
            } else if ($endpoint instanceof EndpointDefinitionDTO) {
                $dto = $endpoint;
            } else {
                throw new \InvalidArgumentException('Invalid endpoint definition');
            }

            $dto->name = $namePrefix . $dto->name;

            $this->endpointDefinitions[] = $dto;
        }
    }

    abstract public function getEndpoints(): mixed;

    public function getBundleName(): string
    {
        return '';
    }

    public function getEndpointDefinitions(): array
    {
        if (is_null($this->endpointDefinitions)) {
            $this->_generateEndpointDefinitions();
        }
        return $this->endpointDefinitions;
    }

    public function runEndpoint(Request $request): ServiceEndpointRunnerResultDTO
    {
        $runnerResult = $this->handleRequest($request);
        if (is_string($runnerResult)) {
            return ServiceEndpointRunnerResultDTO::createSuccess([], $runnerResult);
        }

        return $runnerResult instanceof ServiceEndpointRunnerResultDTO ? $runnerResult : ServiceEndpointRunnerResultDTO::createSuccess($runnerResult);
    }

    abstract public function handleRequest(Request $request): mixed;

    public function getDescription(): string
    {
        return '';
    }

    public function getErrorMessage(): ?string
    {
        return $this->errorMessage;
    }

    public function getRequiredRoles(): array
    {
        return [];
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): AbstractServiceEndpointRunner
    {
        $this->user = $user;
        return $this;
    }

    public function hasError(): bool
    {
        return $this->hasError;
    }

    public function setError(?string $errorMessage = null): AbstractServiceEndpointRunner
    {
        $this->hasError = !is_null($errorMessage);
        $this->errorMessage = $errorMessage;
        return $this;
    }

    public function validate(): bool
    {
        return true;
    }
}