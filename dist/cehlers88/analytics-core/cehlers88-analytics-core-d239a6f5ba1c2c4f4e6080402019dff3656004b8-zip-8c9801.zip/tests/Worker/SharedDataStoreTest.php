<?php

namespace Cehlers88\AnalyticsCore\Tests\Worker;

use Cehlers88\AnalyticsCore\Worker\WorkerInterface;
use PHPUnit\Framework\TestCase;

/**
 * Tests for the temporary shared data store on WorkerInterface.
 *
 * Uses a minimal in-memory stub that only implements the shared-data
 * contract so that no external (Analytics\*) dependencies are required.
 */
class SharedDataStoreTest extends TestCase
{
    private WorkerInterface $worker;

    protected function setUp(): void
    {
        $this->worker = $this->createWorkerStub();
    }

    public function testSetAndGetSharedData(): void
    {
        $this->worker->setSharedData('key', 'value');

        $this->assertSame('value', $this->worker->getSharedData('key'));
    }

    public function testGetSharedDataReturnsDefaultWhenKeyMissing(): void
    {
        $this->assertNull($this->worker->getSharedData('missing'));
        $this->assertSame('default', $this->worker->getSharedData('missing', 'default'));
    }

    public function testHasSharedDataReturnsTrueForExistingKey(): void
    {
        $this->worker->setSharedData('exists', 123);

        $this->assertTrue($this->worker->hasSharedData('exists'));
    }

    public function testHasSharedDataReturnsFalseForMissingKey(): void
    {
        $this->assertFalse($this->worker->hasSharedData('nonexistent'));
    }

    public function testRemoveSharedDataDeletesKey(): void
    {
        $this->worker->setSharedData('toRemove', true);
        $this->worker->removeSharedData('toRemove');

        $this->assertFalse($this->worker->hasSharedData('toRemove'));
    }

    public function testRemoveSharedDataOnMissingKeyDoesNotThrow(): void
    {
        // Should be a no-op without throwing
        $this->worker->removeSharedData('nonexistent');

        $this->assertFalse($this->worker->hasSharedData('nonexistent'));
    }

    public function testClearSharedDataRemovesAllKeys(): void
    {
        $this->worker->setSharedData('a', 1);
        $this->worker->setSharedData('b', 2);
        $this->worker->clearSharedData();

        $this->assertFalse($this->worker->hasSharedData('a'));
        $this->assertFalse($this->worker->hasSharedData('b'));
    }

    public function testSetSharedDataSupportsVariousTypes(): void
    {
        $this->worker->setSharedData('int', 42);
        $this->worker->setSharedData('array', ['foo' => 'bar']);
        $this->worker->setSharedData('null', null);

        $this->assertSame(42, $this->worker->getSharedData('int'));
        $this->assertSame(['foo' => 'bar'], $this->worker->getSharedData('array'));
        // null is stored, so hasSharedData should be true but getSharedData returns null
        $this->assertTrue($this->worker->hasSharedData('null'));
        $this->assertNull($this->worker->getSharedData('null'));
    }

    public function testSetSharedDataOverwritesExistingKey(): void
    {
        $this->worker->setSharedData('key', 'first');
        $this->worker->setSharedData('key', 'second');

        $this->assertSame('second', $this->worker->getSharedData('key'));
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    /** Create a minimal WorkerInterface stub backed by an in-memory array. */
    private function createWorkerStub(): WorkerInterface
    {
        return new class implements WorkerInterface {
            private array $store = [];

            public function configure(array $properties): static { return $this; }
            public function getRequiredJobs(): array { return []; }
            public function setBenchmarkValue(string $key, mixed $value): static { return $this; }
            public function getBenchmark(): array { return []; }
            public function getJobByClassName(string $className): ?\Cehlers88\AnalyticsCore\Worker\Job\JobInterface { return null; }
            public function reachedTimeout(): bool { return false; }

            public function setSharedData(string $key, mixed $value): static
            {
                $this->store[$key] = $value;
                return $this;
            }

            public function getSharedData(string $key, mixed $default = null): mixed
            {
                return array_key_exists($key, $this->store) ? $this->store[$key] : $default;
            }

            public function hasSharedData(string $key): bool
            {
                return array_key_exists($key, $this->store);
            }

            public function removeSharedData(string $key): static
            {
                unset($this->store[$key]);
                return $this;
            }

            public function clearSharedData(): static
            {
                $this->store = [];
                return $this;
            }
        };
    }
}
