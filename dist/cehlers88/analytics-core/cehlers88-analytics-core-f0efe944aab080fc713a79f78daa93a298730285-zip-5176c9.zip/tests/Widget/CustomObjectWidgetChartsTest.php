<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Widget;

use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsCore\Widget\CustomObjectWidgetCharts;
use PHPUnit\Framework\TestCase;

/**
 * Which charts the dashboard widget of a custom object shows.
 */
class CustomObjectWidgetChartsTest extends TestCase
{
    private static function sensorView(): CustomObjectView
    {
        $view = new CustomObjectView(5, 'SmartDevice', 'growbox_gas', [], []);
        $view->attribute->label = 'CO2';
        $view->monitorings = [
            'value' => [
                ['id' => 11, 'interval' => 'PT1M', 'intervalLabel' => '1 min'],
                ['id' => 12, 'interval' => 'PT5M', 'intervalLabel' => '5 min'],
            ],
            'temp' => [
                ['id' => 13, 'interval' => 'daily_midnight'],
            ],
        ];

        return $view;
    }

    public function testEveryMonitoringIsDescribedByAttributeAndInterval(): void
    {
        $this->assertSame([
            ['id' => 11, 'label' => 'CO2 (1 min)'],
            ['id' => 12, 'label' => 'CO2 (5 min)'],
            ['id' => 13, 'label' => 'temp (daily_midnight)'],
        ], CustomObjectWidgetCharts::describe(self::sensorView()));
    }

    public function testWithoutSettingsEveryChartIsShown(): void
    {
        $this->assertSame([11, 12, 13], CustomObjectWidgetCharts::resolveVisibleMonitoringIds(self::sensorView(), null));
    }

    public function testClearedChartsAreHidden(): void
    {
        // the props arrive json decoded into objects
        $settings = json_decode('{"11": false, "12": true}');

        $this->assertSame([12, 13], CustomObjectWidgetCharts::resolveVisibleMonitoringIds(self::sensorView(), $settings));
        $this->assertSame([12, 13], CustomObjectWidgetCharts::resolveVisibleMonitoringIds(self::sensorView(), [11 => false]));
    }
}
