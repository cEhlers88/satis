<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support;

use Cehlers88\AnalyticsCore\Support\IntervalLabel;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class IntervalLabelTest extends TestCase
{
    public static function intervals(): array
    {
        return [
            'one minute' => ['PT1M', '1 min'],
            'five minutes' => ['PT5M', '5 min'],
            'hour and a half' => ['PT1H30M', '1 h 30 min'],
            'a day' => ['P1D', '1 d'],
            'a month is no minute' => ['P1M', '1 mo'],
            'weeks' => ['P2W', '2 w'],
            'seconds' => ['PT90S', '90 s'],
            'zero' => ['PT0S', '0 s'],
            'named interval' => ['daily_midnight', '00:00'],
            'empty' => ['', ''],
            'not a duration' => ['bogus', 'bogus'],
        ];
    }

    #[DataProvider('intervals')]
    public function testLabel(string $interval, string $expected): void
    {
        $this->assertSame($expected, IntervalLabel::of($interval));
    }
}
