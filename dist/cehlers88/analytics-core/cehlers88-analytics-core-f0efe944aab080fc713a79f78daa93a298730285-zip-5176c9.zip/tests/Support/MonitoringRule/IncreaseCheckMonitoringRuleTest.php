<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support\MonitoringRule;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttributeMonitoring;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Support\MonitoringRule\IncreaseCheckMonitoringRule;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class IncreaseCheckMonitoringRuleTest extends TestCase
{
    private const int START = 1_760_000_000;

    /** @var list<mixed> the command lists the player was asked to run */
    private array $ran = [];

    private bool $applicationExists = true;

    public static function setUpBeforeClass(): void
    {
        if (!class_exists(\Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository::class)) {
            self::markTestSkipped('Doctrine is not installed; the rule needs the application repository.');
        }
    }

    private function rule(): IncreaseCheckMonitoringRule
    {
        $player = $this->createStub(CommandPlayer::class);
        $player->method('setMacroEnvironment')->willReturnSelf();
        $player->method('run')->willReturnCallback(function (mixed $commands) {
            $this->ran[] = $commands;
            return null;
        });

        $applications = $this->createStub(ApplicationRepository::class);
        $applications->method('find')->willReturn($this->applicationExists ? $this->createStub(Application::class) : null);

        return new class($player, $this->createStub(MacroEnvironment::class), $applications) extends IncreaseCheckMonitoringRule {
            public int $clock = 0;

            protected function now(): int
            {
                return $this->clock;
            }
        };
    }

    /**
     * Runs the rule once per value, $step seconds apart, handing the options on
     * the way Monitoring does.
     *
     * @return IncreaseCheckMonitoringRule the rule after the last run
     */
    private function measure(array $arguments, array $values, int $step = 600): IncreaseCheckMonitoringRule
    {
        $options = [];
        $rule = null;
        foreach ($values as $index => $value) {
            $rule = $this->rule();
            $rule->clock = self::START + $index * $step;
            $rule
                ->setAttributeMonitoring($this->createStub(CustomEntityAttributeMonitoring::class))
                ->setArguments([
                    'onIncrease' => ['alarm'],
                    'onRecover' => ['all clear'],
                    ...$arguments,
                ])
                ->setAttributeToCheck(new CustomEntityAttribute()->setValue($value === null ? null : (string)$value))
                ->setStatisticOptions($options)
                ->execute();
            $options = $rule->getStatisticOptions();
        }

        return $rule;
    }

    public function testARiseWithinTheTimespanFires(): void
    {
        // 10-minute steps: 3 → 14 is a rise of 11 within the last hour
        $rule = $this->measure(['increase' => 10, 'timespan' => 'PT1H'], [1, 3, 5, 9, 14]);

        $details = $rule->getStatisticDetails();
        $this->assertSame(1, $details['triggered']);
        $this->assertSame(13.0, $details['increase']);
        $this->assertSame([['alarm']], $this->ran, 'the commands run once, when the rise is reached');
    }

    public function testTheSameRiseSpreadOverALongerTimeDoesNotFire(): void
    {
        // +2 per hour: never 10 within one hour
        $rule = $this->measure(['increase' => 10, 'timespan' => 'PT1H'], [0, 2, 4, 6, 8, 10, 12, 14], 3600);

        $this->assertSame(0, $rule->getStatisticDetails()['triggered']);
        $this->assertSame(2.0, $rule->getStatisticDetails()['increase']);
        $this->assertSame([], $this->ran);
    }

    public function testTheCommandsRunOncePerCrossing(): void
    {
        // rise, stays high, levels out for more than an hour, rises again
        $this->measure(['increase' => 10, 'timespan' => 'PT1H'], [0, 12, 13, 13, 13, 13, 13, 13, 13, 13, 30], 900);

        $this->assertSame([['alarm'], ['all clear'], ['alarm']], $this->ran);
    }

    public function testAResetCounterDoesNotHideANewRise(): void
    {
        $rule = $this->measure(['increase' => 5, 'timespan' => 'PT1H'], [40, 0, 6]);

        $this->assertSame(1, $rule->getStatisticDetails()['triggered']);
        $this->assertSame(6.0, $rule->getStatisticDetails()['increase']);
    }

    public function testTheRiseCanBeGivenInPercent(): void
    {
        $rule = $this->measure(['increase' => 50, 'timespan' => 'PT1H', 'mode' => 'percent'], [20, 25, 31]);

        $this->assertSame(1, $rule->getStatisticDetails()['triggered']);
        $this->assertEqualsWithDelta(55.0, $rule->getStatisticDetails()['increase'], 1e-9);
    }

    public function testANonNumericValueKeepsTheState(): void
    {
        $rule = $this->measure(['increase' => 5, 'timespan' => 'PT1H'], [0, 8, 'offline']);

        $this->assertSame(1, $rule->getStatisticDetails()['triggered']);
        $this->assertCount(2, $rule->getStatisticOptions()[IncreaseCheckMonitoringRule::OPTIONS_KEY]['samples']);
        $this->assertSame([['alarm']], $this->ran);
    }

    public function testOnlyTheSamplesTheTimespanNeedsAreKept(): void
    {
        $rule = $this->measure(['increase' => 100, 'timespan' => 'PT30M'], [1, 2, 3, 4, 5, 6], 600);

        $samples = $rule->getStatisticOptions()[IncreaseCheckMonitoringRule::OPTIONS_KEY]['samples'];
        $this->assertSame([3.0, 4.0, 5.0, 6.0], array_column($samples, 1), 'the window plus the value it started with');
    }

    public function testMeasureIncrease(): void
    {
        $this->assertNull(IncreaseCheckMonitoringRule::measureIncrease([]));
        $this->assertSame(0.0, IncreaseCheckMonitoringRule::measureIncrease([[1, 5.0]]));
        $this->assertSame(4.0, IncreaseCheckMonitoringRule::measureIncrease([[1, 5.0], [2, 3.0], [3, 7.0]]));
        $this->assertNull(IncreaseCheckMonitoringRule::measureIncrease([[1, 0.0], [2, 7.0]], 'percent'), 'no percentage of zero');
        $this->assertSame(0.0, IncreaseCheckMonitoringRule::measureIncrease([[1, 5.0], [2, 3.0]]), 'a falling value is no rise');
    }

    /** @return iterable<string, array{array<string, mixed>, bool}> */
    public static function arguments(): iterable
    {
        yield 'complete' => [['increase' => 10, 'timespan' => 'PT1H'], true];
        yield 'with percent' => [['increase' => 10, 'timespan' => 'P1D', 'mode' => 'percent'], true];
        yield 'no rise' => [['timespan' => 'PT1H'], false];
        yield 'no timespan' => [['increase' => 10], false];
        yield 'no duration' => [['increase' => 10, 'timespan' => '1 hour'], false];
        yield 'empty duration' => [['increase' => 10, 'timespan' => 'PT0S'], false];
        yield 'no rise at all' => [['increase' => 0, 'timespan' => 'PT1H'], false];
        yield 'no number' => [['increase' => 'abc', 'timespan' => 'PT1H'], false];
        yield 'unknown mode' => [['increase' => 10, 'timespan' => 'PT1H', 'mode' => 'relative'], false];
        yield 'commands of another shape' => [['increase' => 10, 'timespan' => 'PT1H', 'onIncrease' => 5], false];
        yield 'commands as definition' => [['increase' => '10', 'timespan' => 'PT1H', 'onIncrease' => '[]', 'mode' => ''], true];
    }

    #[DataProvider('arguments')]
    public function testValidateArguments(array $arguments, bool $valid): void
    {
        $this->assertSame($valid, $this->rule()->validateArguments($arguments));
    }

    public function testTimespanSeconds(): void
    {
        $this->assertSame(900, IncreaseCheckMonitoringRule::timespanSeconds('PT15M'));
        $this->assertSame(86400, IncreaseCheckMonitoringRule::timespanSeconds('P1D'));
    }

    public function testCommandsAreSkippedWhenTheApplicationIsGone(): void
    {
        $this->applicationExists = false;

        $rule = $this->measure(['increase' => 5, 'timespan' => 'PT1H', 'applicationId' => 99], [0, 8]);

        $this->assertSame(1, $rule->getStatisticDetails()['triggered']);
        $this->assertSame([], $this->ran);
        $this->assertStringContainsString('Application 99 nicht gefunden', $rule->getStatisticDetails()['reason']);
    }

    public function testSamplesThatCanNoLongerBeTheLowestAreDropped(): void
    {
        $samples = [[1, 9.0], [2, 4.0], [3, 7.0], [4, 6.0], [5, 8.0]];

        $this->assertSame([[2, 4.0, 1], [4, 6.0, 3], [5, 8.0, 5]], IncreaseCheckMonitoringRule::keepSamples($samples, 0));
    }

    /** @return iterable<string, array{int, int}> */
    public static function randomSeries(): iterable
    {
        foreach ([42, 7, 1234] as $seed) {
            yield 'seed ' . $seed . ', window 600' => [$seed, 600];
            yield 'seed ' . $seed . ', window 10' => [$seed, 10];
        }
    }

    #[DataProvider('randomSeries')]
    public function testDroppingSamplesNeverChangesTheMeasurement(int $seed, int $window): void
    {
        mt_srand($seed);
        $all = [];
        $kept = [];
        // irregular steps - attribute changes run the rule between the scheduled runs
        for ($time = 1, $run = 0; $run < 3000; $time += mt_rand(1, 15), $run++) {
            $sample = [$time, (float)mt_rand(0, 50)];
            $all[] = $sample;
            $windowStart = $time - $window;
            $kept = IncreaseCheckMonitoringRule::keepSamples([...$kept, $sample], $windowStart);

            $reference = array_values(array_filter($all, fn(array $s) => $s[0] > $windowStart));
            $before = array_values(array_filter($all, fn(array $s) => $s[0] <= $windowStart));
            if ($before !== []) {
                array_unshift($reference, $before[array_key_last($before)]);
            }

            $this->assertSame(
                IncreaseCheckMonitoringRule::measureIncrease($reference),
                IncreaseCheckMonitoringRule::measureIncrease($kept),
                'at ' . $time
            );
        }
    }

    public function testALongSteadyRiseIsThinnedButStaysExact(): void
    {
        $samples = [];
        for ($time = 1; $time <= 1440; $time++) {
            $samples[] = [$time, (float)$time];
        }

        $kept = IncreaseCheckMonitoringRule::keepSamples($samples, 0);

        $this->assertCount(IncreaseCheckMonitoringRule::MAX_SAMPLES, $kept);
        $this->assertSame([1, 1.0], array_slice($kept[0], 0, 2));
        $this->assertSame([1440, 1440.0], array_slice($kept[array_key_last($kept)], 0, 2));
        $this->assertSame(1439.0, IncreaseCheckMonitoringRule::measureIncrease($kept));
    }
}
