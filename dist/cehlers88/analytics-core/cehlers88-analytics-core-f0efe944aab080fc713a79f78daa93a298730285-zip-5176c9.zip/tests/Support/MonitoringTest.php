<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support;

use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttributeMonitoring;
use Cehlers88\AnalyticsCore\Repository\CustomEntityAttributeMonitoringRepository;
use Cehlers88\AnalyticsCore\Repository\CustomEntityAttributeRepository;
use Cehlers88\AnalyticsCore\Repository\StatisticsRepository;
use Cehlers88\AnalyticsCore\Support\Monitoring;
use Cehlers88\AnalyticsCore\Support\MonitoringRule\AbstractMonitoringRule;
use PHPUnit\Framework\TestCase;

/**
 * A rule keeps its state between runs in the statistic options - what it last
 * fired, the samples it measures.
 */
class MonitoringTest extends TestCase
{
    public static function setUpBeforeClass(): void
    {
        if (!class_exists(\Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository::class)) {
            self::markTestSkipped('Doctrine is not installed; Monitoring needs the repositories.');
        }
    }

    public function testTheRuleGetsBackTheOptionsItLeftAndTheHistoryStaysTrimmed(): void
    {
        $rule = new class extends AbstractMonitoringRule {
            /** @var list<array> the options each run started with */
            public static array $seen = [];

            public function execute(): self
            {
                self::$seen[] = $this->getStatisticOptions();
                $options = $this->getStatisticOptions();
                $options['runs'] = ($options['runs'] ?? 0) + 1;
                $options['samples'] = [...($options['samples'] ?? []), [1, 2], [3, 4]];

                return $this->setStatisticOptions($options);
            }
        };

        $monitoring = new CustomEntityAttributeMonitoring()
            ->setAttribute(new CustomEntityAttribute()->setName('errors')->setValue('3'))
            ->setRunInterval('PT1M')
            ->setMaxLength(2)
            ->setRuleHandler($rule::class);

        $repository = $this->createStub(CustomEntityAttributeMonitoringRepository::class);
        $repository->method('findAll')->willReturn([$monitoring]);
        $repository->method('save')->willReturnSelf();
        $repository->method('flush')->willReturnSelf();

        $monitor = new Monitoring(
            $repository,
            $this->createStub(CustomEntityAttributeRepository::class),
            $this->createStub(StatisticsRepository::class),
            [$rule]
        );

        foreach (range(1, 3) as $run) {
            $monitoring->setLastRun(new \DateTime('-1 hour'));
            $monitor->run();
        }

        $this->assertSame([], $rule::$seen[0]);
        $this->assertSame(2, $rule::$seen[2]['runs'], 'the third run starts from what the second left');

        $details = $monitoring->getStatistic()->getDetails();
        $this->assertSame(3, $details['options']['runs']);
        $this->assertCount(6, $details['options']['samples'], 'options are no series and are not cut to the max length');
        $this->assertSame('errors', $details['options']['monitoredAttribute']);
        $this->assertSame([3.0, 3.0], $details['errors'], 'the series stay at the max length');
    }

    public function testARuleRunOnItsOwnKeepsItsState(): void
    {
        $rule = new class extends AbstractMonitoringRule {
            public function execute(): self
            {
                $options = $this->getStatisticOptions();
                $options['runs'] = ($options['runs'] ?? 0) + 1;

                return $this->setStatisticOptions($options);
            }
        };

        $monitoring = new CustomEntityAttributeMonitoring()
            ->setAttribute(new CustomEntityAttribute()->setName('errors')->setValue('3'))
            ->setRunInterval('PT1M')
            ->setMaxLength(2)
            ->setRuleHandler($rule::class);

        $monitor = new Monitoring(
            $this->createStub(CustomEntityAttributeMonitoringRepository::class),
            $this->createStub(CustomEntityAttributeRepository::class),
            $this->createStub(StatisticsRepository::class),
            [$rule]
        );

        // as CustomObjectProvider does when the attribute changes
        $monitor->runMonitoringRules($monitoring);
        $monitor->runMonitoringRules($monitoring);

        $this->assertSame(2, $monitoring->getStatistic()->getDetails()['options']['runs']);
    }
}
