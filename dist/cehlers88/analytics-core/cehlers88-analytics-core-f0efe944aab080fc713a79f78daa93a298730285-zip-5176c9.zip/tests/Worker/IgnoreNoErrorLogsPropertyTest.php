<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Worker;

use Cehlers88\AnalyticsCore\Worker\AbstractWorker;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class IgnoreNoErrorLogsPropertyTest extends TestCase
{
    private function worker(): AbstractWorker
    {
        return new class extends AbstractWorker {
            public function __construct()
            {
            }

            public function getWorkingObjects(): array
            {
                return [];
            }
        };
    }

    public function testAWorkerWithoutThePropertyLogsEveryRun(): void
    {
        $worker = $this->worker()->configure([]);

        self::assertTrue($worker->hasProperty(AbstractWorker::PROPERTY_IGNORE_NO_ERROR_LOGS));
        self::assertTrue($worker->getProperty(AbstractWorker::PROPERTY_IGNORE_NO_ERROR_LOGS)->isOptional);
        self::assertFalse($worker->ignoresNoErrorLogs());
    }

    #[DataProvider('storedValues')]
    public function testTheStoredValueDecides(mixed $stored, bool $expected): void
    {
        $worker = $this->worker()->configure([['string', AbstractWorker::PROPERTY_IGNORE_NO_ERROR_LOGS, $stored]]);

        self::assertSame($expected, $worker->ignoresNoErrorLogs());
    }

    public static function storedValues(): array
    {
        return [
            'bool true' => [true, true],
            'bool false' => [false, false],
            'string from the card' => ['true', true],
            'one' => ['1', true],
            'string false' => ['false', false],
            'empty input' => ['', false],
            'zero' => ['0', false],
            'nonsense' => ['maybe', false],
        ];
    }

    public function testConfiguringTwiceDoesNotThrow(): void
    {
        $worker = $this->worker()->configure([])->configure([['boolean', AbstractWorker::PROPERTY_IGNORE_NO_ERROR_LOGS, true]]);

        self::assertTrue($worker->ignoresNoErrorLogs());
    }
}
