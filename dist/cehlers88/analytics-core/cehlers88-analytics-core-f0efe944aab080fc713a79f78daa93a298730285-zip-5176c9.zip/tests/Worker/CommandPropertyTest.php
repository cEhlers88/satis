<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Worker;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Command;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Repository\CommandRepository;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Player\MacroPlayer;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Worker\AbstractWorker;
use PHPUnit\Framework\Attributes\AllowMockObjectsWithoutExpectations;
use PHPUnit\Framework\TestCase;

/**
 * A property may hold a command: the worker runs it at the start of every run and works
 * with its result.
 */
#[AllowMockObjectsWithoutExpectations]
class CommandPropertyTest extends TestCase
{
    /** @var list<mixed> what the command player was asked to run */
    private array $ran = [];

    private function worker(mixed $commandResult): AbstractWorker
    {
        // the real factory decides what is a command - only running one is played
        $getVar = (new Command())->setName('getVar')->setMacroProps([]);
        $commands = $this->createStub(CommandRepository::class);
        $commands->method('findAll')->willReturn([$getVar]);
        $commands->method('findOneBy')->willReturn($getVar);
        $player = $this->getMockBuilder(CommandPlayer::class)
            ->setConstructorArgs([new CommandFactory($commands)])
            ->onlyMethods(['run', 'setApplication'])
            ->getMock();
        $player->method('run')->willReturnCallback(function (mixed $definition) use ($commandResult) {
            $this->ran[] = $definition;
            if ($commandResult instanceof \Throwable) {
                throw $commandResult;
            }

            return $commandResult;
        });
        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('getCommandPlayer')->willReturn($player);
        $environment->method('getVariablesStoreProvider')->willReturn($this->createStub(VariablesProvider::class));
        $macroPlayer = $this->createStub(MacroPlayer::class);
        $macroPlayer->method('getMacroEnvironment')->willReturn($environment);

        // execute() needs classes of the application, so the run is played up to the point
        // the command properties are resolved - execute() does that right after its start
        $worker = new class extends AbstractWorker {
            public function __construct()
            {
                $this->addProperty(PropertyDTO::create('limit', 10, 'int', true));
            }

            public function getWorkingObjects(): array
            {
                return [];
            }

            public function startRun(): void
            {
                $this->resolveCommandProperties();
            }
        };
        $worker->setMacroPlayer($macroPlayer);

        return $worker;
    }

    public function testTheCommandIsRunAndItsResultUsed(): void
    {
        $worker = $this->worker(42)->configure([['command', 'limit', [['getVar', ['name' => 'limit']]]]]);

        $this->assertSame(['limit' => [['getVar', ['name' => 'limit']]]], $worker->getCommandProperties());
        $this->assertSame([['getVar', ['name' => 'limit']]], $worker->getPropertyValue('limit'), 'until a run, the definition is the value');

        $worker->startRun();

        $this->assertSame(42, $worker->getPropertyValue('limit'));
        $this->assertSame([[['getVar', ['name' => 'limit']]]], $this->ran);
        $this->assertFalse($worker->hasError());
    }

    public function testAFailingCommandIsAnErrorOfTheRun(): void
    {
        $worker = $this->worker(new \RuntimeException('no such variable'))->configure([['command', 'limit', ['getVar', []]]]);

        $worker->startRun();

        $this->assertTrue($worker->hasError());
        $this->assertSame('Property "limit": its command failed: no such variable', $worker->getErrorsAsString());
    }

    public function testPlainValuesRunNothing(): void
    {
        $worker = $this->worker(42)->configure([['integer', 'limit', 5]]);

        $worker->startRun();

        $this->assertSame(5, $worker->getPropertyValue('limit'));
        $this->assertSame([], $this->ran);
    }

    /** @return iterable<string, array{mixed, mixed}> */
    public static function writtenCommands(): iterable
    {
        yield 'a bare command name' => ['getVar', ['getVar', []]];
        yield 'JSON text' => ['[["getVar", {"name": "limit"}]]', [['getVar', ['name' => 'limit']]]];
        yield 'a single call' => [['getVar', ['name' => 'limit']], ['getVar', ['name' => 'limit']]];
    }

    #[\PHPUnit\Framework\Attributes\DataProvider('writtenCommands')]
    public function testEveryWayOfWritingACommandIsRun(mixed $stored, mixed $run): void
    {
        $worker = $this->worker(42)->configure([['command', 'limit', $stored]]);

        $worker->startRun();

        $this->assertSame([$run], $this->ran);
        $this->assertSame(42, $worker->getPropertyValue('limit'));
        $this->assertFalse($worker->hasError());
    }

    /** @return iterable<string, array{mixed}> */
    public static function noCommands(): iterable
    {
        yield 'an unknown command' => ['noSuchCommand'];
        yield 'a plain text' => ['just some text'];
        yield 'nothing' => [''];
        yield 'an empty list' => [[]];
        yield 'a list of values' => [[1, 2, 3]];
    }

    #[\PHPUnit\Framework\Attributes\DataProvider('noCommands')]
    public function testWhatIsNoCommandIsAnErrorInsteadOfAValue(mixed $stored): void
    {
        $worker = $this->worker(42)->configure([['command', 'limit', $stored]]);

        $worker->startRun();

        $this->assertSame([], $this->ran, 'nothing is run');
        $this->assertSame('Property "limit": its value is no command definition.', $worker->getErrorsAsString());
    }
}
