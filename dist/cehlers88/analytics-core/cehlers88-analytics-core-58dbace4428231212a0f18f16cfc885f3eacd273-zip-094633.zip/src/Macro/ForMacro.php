<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogReason;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiProviderInterface;
use Cehlers88\AnalyticsCore\Macro\ValueHelper\SelectVarNameValueHelper;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;

class ForMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    private const PROPERTY_AS = "as";
    private const PROPERTY_COMMANDS = "commands";
    private const PROPERTY_COUNTER_VAR = "counterVar";
    private const PROPERTY_ITEMS = "items";

    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            // Both are written with setVar in its default context - so they
            // are variable names like any other and offered as such.
            self::PROPERTY_AS, self::PROPERTY_COUNTER_VAR => PropertyUi::create()->valueHelper(SelectVarNameValueHelper::class),
            self::PROPERTY_COMMANDS => PropertyUi::commands(),
            default => null,
        };
    }

    public function __construct(
        private CommandFactory $commandFactory
    )
    {
    }

    public function init(): ForMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_AS, MacroPropertyDTO::TYPE_STRING, ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_COMMANDS, MacroPropertyDTO::TYPE_ARRAY, ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ITEMS, MacroPropertyDTO::TYPE_ARRAY, '', []))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_COUNTER_VAR, MacroPropertyDTO::TYPE_STRING, 'Name of variable to store current counter', ''));

        return $this;
    }

    public function getDescription(): string
    {
        return '';
    }

    public function getName(): string
    {
        return 'for';
    }

    public function needPrecompiledArguments(): bool
    {
        return false;
    }

    protected function run(): ?array
    {
        $items = $this->getPropertyValue(self::PROPERTY_ITEMS);
        $counterVar = $this->getPropertyValue(self::PROPERTY_COUNTER_VAR);

        if (is_array($items)) {
            $evaluatedItems = $this->commandFactory->evalDefinitionArray($this->getPropertyValue(self::PROPERTY_ITEMS), true);

            if ($evaluatedItems instanceof CommandGroupDTO) {
                $commandResults = $this->_runCommandDefinition($evaluatedItems);
                $evaluatedItems = [];
                foreach ($commandResults as $commandResult) {
                    if (!is_null($commandResult)) {
                        $evaluatedItems[] = $commandResult;
                    }
                }
            }
            $itemsCount = count($evaluatedItems);
            $this->log(eDebuggerLogType::INFO,
                sprintf("Execute Macro with %d items found", $itemsCount),
                ['items' => $itemsCount]
            );
            $result = [];
            // `as` and the counter belong to the commands of the loop: afterwards they
            // are what they were before it - gone, if they did not exist.
            $loopVariables = array_values(array_unique(array_filter(
                [(string)$this->getPropertyValue(self::PROPERTY_AS), (string)$counterVar],
                static fn(string $name): bool => $name !== ''
            )));
            $outerValues = $this->captureLoopVariables($loopVariables);

            try {
                $this->runItems($evaluatedItems, $counterVar, $result);
            } finally {
                $this->restoreLoopVariables($loopVariables, $outerValues);
            }
        }

        return $this->_createRunResult($result);
    }

    private function runItems(array $evaluatedItems, mixed $counterVar, array &$result): void
    {
        foreach ($evaluatedItems as $i => $item) {
            $this->log(eDebuggerLogType::INFO,
                sprintf("Processing %d. item", ($i + 1)),
                [
                    'item' => $item,
                    'reason' => eDebuggerLogReason::START_VIEW_GROUP
                ]
            );

            if ($counterVar !== '') {
                $this->_executeMacro('setVar', ['name' => $counterVar, 'value' => $i]);
            }

            $this->_executeMacro('setVar', [
                'name' => $this->getPropertyValue(self::PROPERTY_AS),
                'value' => $item
            ]);

            $commandsToRun = $this->getPropertyValue(self::PROPERTY_COMMANDS);
            $result[] = $this->_runCommandDefinition($commandsToRun);

            $this->log(eDebuggerLogType::INFO,
                sprintf("Finished processing %d. item", ($i + 1)),
                [
                    'reason' => eDebuggerLogReason::END_VIEW_GROUP
                ]
            );
        }
    }

    /**
     * The values the loop variables have before the loop, in the context setVar writes them
     * to by default - only those that exist.
     *
     * @param list<string> $names
     *
     * @return array<string, mixed>
     */
    private function captureLoopVariables(array $names): array
    {
        $context = $this->getVariablesStoreProvider()->getVariableValue(
            VariablesProvider::GET_VAR_WILDCARD,
            eMacroVariableContext::JOB,
            []
        );
        $outer = [];

        foreach ($names as $name) {
            if (is_array($context) && array_key_exists($name, $context)) {
                $outer[$name] = $context[$name];
            }
        }

        return $outer;
    }

    /**
     * @param list<string> $names
     * @param array<string, mixed> $outerValues
     */
    private function restoreLoopVariables(array $names, array $outerValues): void
    {
        $variables = $this->getVariablesStoreProvider();

        foreach ($names as $name) {
            if (array_key_exists($name, $outerValues)) {
                $variables->setVariable($name, $outerValues[$name], eMacroVariableContext::JOB);
            } else {
                $variables->removeVariable($name, eMacroVariableContext::JOB);
            }
        }
    }
}