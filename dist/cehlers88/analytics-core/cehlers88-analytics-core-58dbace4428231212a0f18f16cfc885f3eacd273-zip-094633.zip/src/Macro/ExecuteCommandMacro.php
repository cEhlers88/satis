<?php

namespace Cehlers88\AnalyticsCore\Macro;


class ExecuteCommandMacro extends AbstractMacro
{
    protected function run(): ?array
    {
        return [];
    }

    public function init(): ExecuteCommandMacro
    {
        $this->_source = 'CoreBundle';
        /*$this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CONDITIONS,'mixed', 'Specify the condition to check'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_WHEN_TRUE_COMMANDS,'array', '',[]))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_WHEN_FALSE_COMMANDS, 'array','',[]))
        ;*/

        return $this;
    }

    public function getDescription(): string
    {
        return 'Execute a command.';
    }

    public function getName(): string
    {
        return 'executeCommand';
    }
}