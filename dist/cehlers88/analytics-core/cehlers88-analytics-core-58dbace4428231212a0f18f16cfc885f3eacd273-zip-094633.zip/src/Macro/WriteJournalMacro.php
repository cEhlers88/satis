<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class WriteJournalMacro extends AbstractMacro
{
    private const PROPERTY_DATA = 'data';
    private const PROPERTY_GROUP = 'group';
    private const PROPERTY_KEY = 'key';

    protected function run(): ?array
    {
        $this->_executeMacro('startAction', [
            'action' => 'NOTICE',
            'props' => 'Macro writeJournal muss noch implementiert werder.'
        ]);
        return $this->_createRunResult($this->getPropertyValue(self::PROPERTY_KEY));
    }

    public function init(): WriteJournalMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DATA, ['string', 'array']))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_GROUP, ['boolean']))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_KEY, ['string']));
        return $this;
    }

    public function getDescription(): string
    {
        return '';
    }

    public function getName(): string
    {
        return 'writeJournal';
    }
}