<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class StartWorkerMacro extends AbstractMacro
{
    protected function run(): ?array
    {
        return [];
    }

    public function init(): StartWorkerMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create('workerId', 'int', 'The id of the Worker to start'))
            ->setProperty(MacroPropertyDTO::create('workerProps', 'array', 'The worker properties', []));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Starts an action.';
    }

    public function getName(): string
    {
        return 'startWorker';
    }
}