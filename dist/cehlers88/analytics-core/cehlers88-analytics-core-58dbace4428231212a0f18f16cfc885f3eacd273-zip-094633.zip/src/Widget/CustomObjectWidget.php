<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Symfony\Component\DependencyInjection\Attribute\AutowireIterator;

class CustomObjectWidget extends AbstractWidget
{
    /** Prefix of the settings that show or hide one chart: "charts.<monitoring id>". */
    public const string CHART_SETTING_PREFIX = 'charts.';

    /**
     * @param iterable<CustomObjectWidgetExtensionInterface> $extensions
     */
    public function __construct(
        private readonly CustomObjectProvider $customObjectProvider,
        private readonly AssemblerProvider    $assemblerProvider,
        #[AutowireIterator(CustomObjectWidgetExtensionInterface::TAG)]
        private readonly iterable             $extensions = []
    )
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.customObject';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
        ];
    }

    public function getTemplateName(): string
    {
        return 'customObject';
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'customObjectId',
                value: null,
                type: 'int',
                label: 'Custom-Object-ID',
                description: 'Das Custom Object, das die Kachel anzeigt.',
                ui: ['min' => 1]
            ),
            PropertyDTO::create(
                name: CustomObjectWidgetParts::SHOW_SWITCHES,
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Schalter anzeigen',
                description: 'Die Schalter der Einstellungen des Objekts über der Kachel.',
            ),
            PropertyDTO::create(
                name: CustomObjectWidgetParts::SHOW_TEMPLATE,
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Template anzeigen',
                description: 'Die Kachel des Objekts. Ohne sie bleiben nur die ausgewählten Diagramme.',
            ),
        ];
    }

    /**
     * Once the object is known, every chart it has gets a checkbox of its own,
     * so the tile shows exactly the charts that were picked.
     */
    public function getSettingDefinitionsFor(array $values): array
    {
        $definitions = $this->getSettingDefinitions();
        $view = $this->assembleView((int)($values['customObjectId'] ?? 0));
        if (is_null($view)) {
            return $definitions;
        }

        foreach (CustomObjectWidgetCharts::describe($view) as $chart) {
            $definitions[] = PropertyDTO::create(
                name: self::CHART_SETTING_PREFIX . $chart['id'],
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Diagramm: ' . $chart['label'],
            );
        }

        return $definitions;
    }

    public function enrichProperties(array $properties): array
    {
        $customObjectId = (int)($properties['customObjectId'] ?? 0);
        $customObject = $this->customObjectProvider->getCustomObjectById($customObjectId);
        if (is_null($customObject)) {
            throw new \InvalidArgumentException(sprintf('Custom object %d not found', $customObjectId));
        }
        $view = $this->assembleViewOf($customObject);

        $extensionHtml = '';
        if (CustomObjectWidgetParts::isShown($properties, CustomObjectWidgetParts::SHOW_SWITCHES)) {
            foreach ($this->extensions as $extension) {
                $extensionHtml .= $extension->renderForWidget($customObject, $view);
            }
        }

        $result = [
            ...$properties,
            'customObject' => $view,
            'visibleMonitoringIds' => CustomObjectWidgetCharts::resolveVisibleMonitoringIds($view, $properties['charts'] ?? []),
            // Every chart the object has, so the tile folds none of the picked ones away.
            'chartCount' => count(CustomObjectWidgetCharts::describe($view)),
            'extensionHtml' => $extensionHtml,
            'showTemplate' => CustomObjectWidgetParts::isShown($properties, CustomObjectWidgetParts::SHOW_TEMPLATE),
        ];

        return parent::enrichProperties($result);
    }

    private function assembleView(int $customObjectId): ?CustomObjectView
    {
        if ($customObjectId <= 0) {
            return null;
        }

        try {
            $customObject = $this->customObjectProvider->getCustomObjectById($customObjectId);
        } catch (\Throwable) {
            return null;
        }

        return is_null($customObject) ? null : $this->assembleViewOf($customObject);
    }

    private function assembleViewOf(object $customObject): CustomObjectView
    {
        $assembler = $this->assemblerProvider->getAssemblerForClass($customObject::class);
        if (is_null($assembler)) {
            $assembler = $this->assemblerProvider->getAssemblerForClass(CustomEntity::class);
        }

        return $assembler->one($customObject);
    }
}
