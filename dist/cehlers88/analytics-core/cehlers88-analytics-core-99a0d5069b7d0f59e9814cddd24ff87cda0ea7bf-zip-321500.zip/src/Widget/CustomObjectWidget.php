<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionClauseDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Symfony\Component\DependencyInjection\Attribute\AutowireIterator;

class CustomObjectWidget extends AbstractWidget
{
    /** Prefix of the settings that show or hide one chart: "charts.<monitoring id>". */
    public const string CHART_SETTING_PREFIX = 'charts.';

    /** Prefix of the settings that give one chart a fixed color: "fixedChartColors.<monitoring id>". */
    public const string FIXED_COLOR_SETTING_PREFIX = 'fixedChartColors.';

    /** Prefix of the settings that hold that color: "chartColors.<monitoring id>". */
    public const string COLOR_SETTING_PREFIX = 'chartColors.';

    /** What the color picker of a chart starts from, so neighbouring charts do not start alike. */
    private const array DEFAULT_COLORS = ['#4e9af1', '#e07b39', '#5cb85c', '#d9534f', '#9b59b6', '#f0ad4e'];

    /**
     * @param iterable<CustomObjectWidgetExtensionInterface> $extensions
     */
    public function __construct(
        private readonly CustomObjectProvider $customObjectProvider,
        private readonly AssemblerProvider    $assemblerProvider,
        #[AutowireIterator(CustomObjectWidgetExtensionInterface::TAG)]
        private readonly iterable             $extensions = []
    )
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.customObject';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
            ['height' => '50px', 'boxes' => [.4, .6]],
        ];
    }

    public function getTemplateName(): string
    {
        return 'customObject';
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'customObjectId',
                value: null,
                type: 'int',
                label: 'Custom Object',
                description: 'Das Custom Object, das die Kachel anzeigt.',
                ui: [
                    'input' => 'suggest',
                    'suggestions' => $this->customObjectSuggestions(),
                    'min' => 1,
                ]
            ),
            PropertyDTO::create(
                name: CustomObjectWidgetParts::SHOW_SWITCHES,
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Schalter anzeigen',
                description: 'Die Schalter der Einstellungen des Objekts über der Kachel.',
            ),
            PropertyDTO::create(
                name: CustomObjectWidgetParts::SHOW_TEMPLATE,
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Template anzeigen',
                description: 'Die Kachel des Objekts. Ohne sie bleiben nur die ausgewählten Diagramme.',
            ),
        ];
    }

    /**
     * Once the object is known, every chart it has gets a switch of its own,
     * so the tile shows exactly the charts that were picked, and may get a
     * fixed color - without one it keeps the color the chart picks itself.
     */
    public function getSettingDefinitionsFor(array $values): array
    {
        $definitions = $this->getSettingDefinitions();
        $view = $this->assembleView((int)($values['customObjectId'] ?? 0));
        if (is_null($view)) {
            return $definitions;
        }

        foreach (CustomObjectWidgetCharts::describe($view) as $index => $chart) {
            $chartSetting = self::CHART_SETTING_PREFIX . $chart['id'];
            $fixedColorSetting = self::FIXED_COLOR_SETTING_PREFIX . $chart['id'];

            $definitions[] = PropertyDTO::create(
                name: $chartSetting,
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Diagramm: ' . $chart['label'],
            );
            // A chart that is not shown has no use for a color.
            $definitions[] = PropertyDTO::create(
                name: $fixedColorSetting,
                value: false,
                type: 'bool',
                isOptional: true,
                label: 'Feste Farbe: ' . $chart['label'],
                conditions: [
                    PropertyConditionDTO::when($chartSetting, false)->thenHidden(),
                ]
            );
            $definitions[] = PropertyDTO::create(
                name: self::COLOR_SETTING_PREFIX . $chart['id'],
                value: self::DEFAULT_COLORS[$index % count(self::DEFAULT_COLORS)],
                type: 'string',
                isOptional: true,
                label: 'Farbe: ' . $chart['label'],
                ui: ['input' => 'color'],
                conditions: [
                    PropertyConditionDTO::whenAny([
                        PropertyConditionClauseDTO::create($chartSetting, false),
                        PropertyConditionClauseDTO::create($fixedColorSetting, false),
                    ])->thenHidden(),
                ]
            );
        }

        return $definitions;
    }

    public function enrichProperties(array $properties): array
    {
        $customObjectId = (int)($properties['customObjectId'] ?? 0);
        $customObject = $this->customObjectProvider->getCustomObjectById($customObjectId);
        if (is_null($customObject)) {
            throw new \InvalidArgumentException(sprintf('Custom object %d not found', $customObjectId));
        }
        $view = $this->assembleViewOf($customObject);

        $extensionHtml = '';
        if (CustomObjectWidgetParts::isShown($properties, CustomObjectWidgetParts::SHOW_SWITCHES)) {
            foreach ($this->extensions as $extension) {
                $extensionHtml .= $extension->renderForWidget($customObject, $view);
            }
        }

        $result = [
            ...$properties,
            'customObject' => $view,
            'visibleMonitoringIds' => CustomObjectWidgetCharts::resolveVisibleMonitoringIds($view, $properties['charts'] ?? []),
            'chartColors' => CustomObjectWidgetCharts::resolveFixedColors(
                $view,
                $properties['fixedChartColors'] ?? [],
                $properties['chartColors'] ?? []
            ),
            // Every chart the object has, so the tile folds none of the picked ones away.
            'chartCount' => count(CustomObjectWidgetCharts::describe($view)),
            'extensionHtml' => $extensionHtml,
            'showTemplate' => CustomObjectWidgetParts::isShown($properties, CustomObjectWidgetParts::SHOW_TEMPLATE),
        ];

        return parent::enrichProperties($result);
    }

    /**
     * Every custom object by its name, so the object is picked by name instead
     * of by an id somebody has to look up first.
     *
     * @return array<int, string>
     */
    private function customObjectSuggestions(): array
    {
        try {
            $entities = $this->customObjectProvider->getCustomEntitiesBy([], false);
        } catch (\Throwable) {
            return [];
        }

        $suggestions = [];
        foreach ($entities as $entity) {
            $id = (int)$entity->getId();
            if ($id <= 0) {
                continue;
            }
            $class = (string)$entity->getClassName();
            $shortClass = str_contains($class, '\\') ? substr((string)strrchr($class, '\\'), 1) : $class;
            $name = trim((string)$entity->getName());
            $suggestions[$id] = ($name === '' ? '#' . $id : $name) . ($shortClass === '' ? '' : ' (' . $shortClass . ')');
        }
        asort($suggestions, SORT_NATURAL | SORT_FLAG_CASE);

        return $suggestions;
    }

    private function assembleView(int $customObjectId): ?CustomObjectView
    {
        if ($customObjectId <= 0) {
            return null;
        }

        try {
            $customObject = $this->customObjectProvider->getCustomObjectById($customObjectId);
        } catch (\Throwable) {
            return null;
        }

        return is_null($customObject) ? null : $this->assembleViewOf($customObject);
    }

    private function assembleViewOf(object $customObject): CustomObjectView
    {
        $assembler = $this->assemblerProvider->getAssemblerForClass($customObject::class);
        if (is_null($assembler)) {
            $assembler = $this->assemblerProvider->getAssemblerForClass(CustomEntity::class);
        }

        return $assembler->one($customObject);
    }
}
