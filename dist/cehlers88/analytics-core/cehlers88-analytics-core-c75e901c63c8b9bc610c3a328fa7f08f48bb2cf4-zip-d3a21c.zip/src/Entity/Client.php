<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ClientRepository::class)]
/**
 * Client entity representing an API client.
 */
class Client extends AbstractTaggedEntity
{
    #[ORM\Column(length: 40)]
    private ?string $ip = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $first_visit = null;

    /** The latest visit known; null for a client recorded before it was kept. */
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $last_visit = null;

    #[ORM\OneToMany(targetEntity: AnalyticsHeader::class, mappedBy: 'client')]
    private Collection $analyticsHeaders;

    #[ORM\OneToMany(targetEntity: ClientDetails::class, mappedBy: 'client', cascade: ['persist', 'remove'])]
    private Collection $clientDetails;

    #[ORM\ManyToMany(targetEntity: ClientPermission::class, inversedBy: 'clients')]
    private Collection $permissions;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $hostname = null;

    #[ORM\Column(length: 30, nullable: true)]
    private ?string $mac = null;

    public function __construct()
    {
        parent::__construct();
        $this->analyticsHeaders = new ArrayCollection();
        $this->clientDetails = new ArrayCollection();
        $this->permissions = new ArrayCollection();
    }

    public function getIp(): ?string
    {
        return $this->ip;
    }

    public function setIp(string $ip): static
    {
        $this->ip = $ip;

        return $this;
    }

    public function getFirstVisit(): ?\DateTimeInterface
    {
        return $this->first_visit;
    }

    public function setFirstVisit(\DateTimeInterface $first_visit): static
    {
        $this->first_visit = $first_visit;

        return $this;
    }

    public function getLastVisit(): ?\DateTimeInterface
    {
        return $this->last_visit;
    }

    public function setLastVisit(?\DateTimeInterface $last_visit): static
    {
        $this->last_visit = $last_visit;

        return $this;
    }

    /**
     * Records a visit at the given time. Visits are reported in batches and not necessarily
     * in order, so the last visit only ever moves forward - and the first one back.
     */
    public function registerVisit(\DateTimeInterface $visitedAt): static
    {
        if ($this->last_visit === null || $visitedAt > $this->last_visit) {
            $this->last_visit = $visitedAt;
        }
        if ($this->first_visit === null || $visitedAt < $this->first_visit) {
            $this->first_visit = $visitedAt;
        }

        return $this;
    }

    /**
     * @return Collection<int, AnalyticsHeader>
     */
    public function getAnalyticsHeaders(): Collection
    {
        return $this->analyticsHeaders;
    }

    public function addAnalyticsHeader(AnalyticsHeader $analyticsHeader): static
    {
        if (!$this->analyticsHeaders->contains($analyticsHeader)) {
            $this->analyticsHeaders->add($analyticsHeader);
            $analyticsHeader->setClient($this);
        }

        return $this;
    }

    public function removeAnalyticsHeader(AnalyticsHeader $analyticsHeader): static
    {
        if ($this->analyticsHeaders->removeElement($analyticsHeader)) {
            // set the owning side to null (unless already changed)
            if ($analyticsHeader->getClient() === $this) {
                $analyticsHeader->setClient(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, ClientDetails>
     */
    public function getClientDetails(): Collection
    {
        return $this->clientDetails;
    }

    public function getClientDetailsByTag(string $tag): ?ClientDetails
    {
        foreach ($this->clientDetails as $clientDetail) {
            if ($clientDetail->getTag() === $tag) {
                return $clientDetail;
            }
        }
        return null;
    }

    public function addClientDetail(ClientDetails $clientDetail): static
    {
        if (!$this->clientDetails->contains($clientDetail)) {
            $this->clientDetails->add($clientDetail);
            $clientDetail->setClient($this);
        }

        return $this;
    }

    public function removeClientDetail(ClientDetails $clientDetail): static
    {
        if ($this->clientDetails->removeElement($clientDetail)) {
            // set the owning side to null (unless already changed)
            if ($clientDetail->getClient() === $this) {
                $clientDetail->setClient(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, ClientPermission>
     */
    public function getPermissions(): Collection
    {
        return $this->permissions;
    }

    public function addPermission(ClientPermission $permission): static
    {
        if (!$this->permissions->contains($permission)) {
            $this->permissions->add($permission);
        }

        return $this;
    }

    public function removePermission(ClientPermission $permission): static
    {
        $this->permissions->removeElement($permission);

        return $this;
    }

    public function getHostname(): ?string
    {
        return $this->hostname;
    }

    public function setHostname(?string $hostname): static
    {
        $this->hostname = $hostname;

        return $this;
    }

    public function getMac(): ?string
    {
        return $this->mac;
    }

    public function setMac(?string $mac): static
    {
        $this->mac = $mac;

        return $this;
    }
}
