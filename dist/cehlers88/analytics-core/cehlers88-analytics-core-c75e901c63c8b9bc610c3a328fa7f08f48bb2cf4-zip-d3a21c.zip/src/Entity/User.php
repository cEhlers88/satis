<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Dashboard\DashboardManager;
use Cehlers88\AnalyticsCore\Repository\UserRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Security\Core\User\PasswordAuthenticatedUserInterface;
use Symfony\Component\Security\Core\User\UserInterface;

#[ORM\Entity(repositoryClass: UserRepository::class)]
#[ORM\UniqueConstraint(name: 'UNIQ_IDENTIFIER_EMAIL', fields: ['email'])]
/**
 * Entity representing a system user.
 */
class User extends AbstractEntity implements UserInterface, PasswordAuthenticatedUserInterface, EntityInterface
{
    #[ORM\Column(length: 180)]
    private ?string $email = null;

    /**
     * @var list<string> The user roles
     */
    #[ORM\Column]
    private array $roles = [];

    /**
     * @var string The hashed password
     */
    #[ORM\Column]
    private ?string $password = null;

    #[ORM\Column]
    private array $settings = [];

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $adminNote = null;

    #[ORM\OneToMany(targetEntity: NotificationChannel::class, mappedBy: 'user')]
    private Collection $notificationChannels;

    /**
     * @var Collection<int, Dashboard>
     */
    #[ORM\OneToMany(targetEntity: Dashboard::class, mappedBy: 'user')]
    private Collection $dashboards;

    /**
     * @var Collection<int, UserGroup> The groups whose roles the user inherits
     */
    #[ORM\ManyToMany(targetEntity: UserGroup::class, inversedBy: 'users')]
    #[ORM\JoinTable(name: 'user_user_group')]
    private Collection $userGroups;

    public function __construct()
    {
        $this->notificationChannels = new ArrayCollection();
        $this->dashboards = new ArrayCollection();
        $this->userGroups = new ArrayCollection();
    }


    /**
     * Resolves the dashboard that is currently selected by this user and falls
     * back to the first one when nothing (valid) is stored.
     *
     * @see DashboardManager for creating, updating and switching dashboards.
     */
    public function getActiveDashboard(): ?Dashboard
    {
        $dashboards = $this->getSortedDashboards();
        if (count($dashboards) === 0) {
            return null;
        }

        $activeDashboardId = $this->getActiveDashboardId();

        if (!is_null($activeDashboardId)) {
            foreach ($dashboards as $dashboard) {
                if ($dashboard->getId() === $activeDashboardId) {
                    return $dashboard;
                }
            }
        }

        return $dashboards[0];
    }

    public function getActiveDashboardId(): ?int
    {
        $activeDashboardId = $this->getSettings()[DashboardManager::ACTIVE_DASHBOARD_SETTING] ?? null;

        return is_null($activeDashboardId) ? null : (int)$activeDashboardId;
    }

    /**
     * @return Dashboard[] Dashboards in the order the user arranged them.
     */
    public function getSortedDashboards(): array
    {
        $dashboards = $this->getDashboards()->toArray();
        usort(
            $dashboards,
            static fn(Dashboard $left, Dashboard $right) => [$left->getSortIndex(), $left->getId()] <=> [$right->getSortIndex(), $right->getId()]
        );

        return array_values($dashboards);
    }

    /**
     * @return Collection<int, Dashboard>
     */
    public function getDashboards(): Collection
    {
        return $this->dashboards;
    }

    public function getSettings(): array
    {
        return $this->settings;
    }

    public function setSettings(array $settings): static
    {
        $this->settings = $settings;

        return $this;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): static
    {
        $this->email = $email;

        return $this;
    }

    /**
     * A visual identifier that represents this user.
     *
     * @see UserInterface
     */
    public function getUserIdentifier(): string
    {
        return (string)$this->email;
    }

    public function hasRole(string $role): bool
    {
        return in_array($role, $this->getRoles());
    }

    /**
     * The effective roles: the ones assigned to the user, the ones of every group the
     * user belongs to, and ROLE_USER, which every user has.
     *
     * @return list<string>
     * @see UserInterface
     */
    public function getRoles(): array
    {
        return array_values(array_unique([...$this->getAssignedRoles(), ...$this->getGroupRoles(), 'ROLE_USER']));
    }

    /**
     * The roles assigned to the user directly - what setRoles() stores, without the
     * inherited ones. Editing a user works on these.
     *
     * @return list<string>
     */
    public function getAssignedRoles(): array
    {
        return array_values(array_unique(array_map('strval', $this->roles)));
    }

    /**
     * The roles the user inherits from its groups.
     *
     * @return list<string>
     */
    public function getGroupRoles(): array
    {
        $roles = [];
        foreach ($this->userGroups as $group) {
            array_push($roles, ...$group->getRoles());
        }

        return array_values(array_unique($roles));
    }

    /**
     * The groups a role comes from, by role - to show where an inherited role stems from.
     *
     * @return array<string, list<string>>
     */
    public function getRoleSources(): array
    {
        $sources = [];
        foreach ($this->userGroups as $group) {
            foreach ($group->getRoles() as $role) {
                $sources[$role][] = $group->getName();
            }
        }

        return $sources;
    }

    /**
     * The roles assigned to the user directly; inherited roles are not stored here.
     *
     * @param list<string> $roles
     */
    public function setRoles(array $roles): static
    {
        $this->roles = array_values(array_unique(array_map('strval', $roles)));

        return $this;
    }

    /**
     * @return Collection<int, UserGroup>
     */
    public function getUserGroups(): Collection
    {
        return $this->userGroups;
    }

    public function addUserGroup(UserGroup $userGroup): static
    {
        if (!$this->userGroups->contains($userGroup)) {
            $this->userGroups->add($userGroup);
            $userGroup->addUser($this);
        }

        return $this;
    }

    public function removeUserGroup(UserGroup $userGroup): static
    {
        if ($this->userGroups->removeElement($userGroup)) {
            $userGroup->removeUser($this);
        }

        return $this;
    }

    /**
     * @see PasswordAuthenticatedUserInterface
     */
    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): static
    {
        $this->password = $password;

        return $this;
    }

    /**
     * @see UserInterface
     */
    public function eraseCredentials(): void
    {
        // If you store any temporary, sensitive data on the user, clear it here
        // $this->plainPassword = null;
    }

    public function getAdminNote(): ?string
    {
        return $this->adminNote;
    }

    public function setAdminNote(?string $adminNote): static
    {
        $this->adminNote = $adminNote;
        return $this;
    }

    public function getNotificationChannels(): Collection
    {
        return $this->notificationChannels;
    }

    public function setNotificationChannels(Collection $notificationChannels): static
    {
        $this->notificationChannels = $notificationChannels;
        return $this;
    }

    public function addDashboard(Dashboard $dashboard): static
    {
        if (!$this->dashboards->contains($dashboard)) {
            $this->dashboards->add($dashboard);
            $dashboard->setUser($this);
        }

        return $this;
    }

    public function removeDashboard(Dashboard $dashboard): static
    {
        if ($this->dashboards->removeElement($dashboard)) {
            // set the owning side to null (unless already changed)
            if ($dashboard->getUser() === $this) {
                $dashboard->setUser(null);
            }
        }

        return $this;
    }
}
