<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class FunctionMacro extends AbstractMacro
{
    private const string PROPERTY_CONTENT = 'content';
    private const string PROPERTY_ARGUMENTS = 'arguments';
    private const string PROPERTY_NAME = 'name';

    public function init(): FunctionMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_NAME, 'string', 'Specify the function'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_CONTENT, 'Command[]', 'Specify the function-content'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ARGUMENTS, 'mixed', 'Specify the function arguments', null));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Create a function.';
    }

    public function getName(): string
    {
        return 'function';
    }

    public function needPrecompiledArguments(): bool
    {
        return false;
    }

    protected function run(): ?array
    {
        return $this->_createRunResult($this->getPropertyValue(self::PROPERTY_NAME));
    }
}