<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\VariableStore;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<VariableStore>
 *
 * @method VariableStore|null find($id, $lockMode = null, $lockVersion = null)
 * @method VariableStore|null findOneBy(array $criteria, array $orderBy = null)
 * @method VariableStore[]    findAll()
 * @method VariableStore[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class VariableStoreRepository extends ServiceEntityRepository
{
    private bool $_autoFlush = false;

    public function __construct(
        private ApplicationRepository $applicationRepository,
        ManagerRegistry               $registry
    )
    {
        parent::__construct($registry, VariableStore::class);
    }

    public function deleteBy_applicationAndContext(Application $application, eMacroVariableContext $context): VariableStoreRepository
    {
        $this->createQueryBuilder('t')
            ->delete()
            ->where('t.application = :applicationId')
            ->andWhere('t.context = :context')
            ->setParameter('applicationId', $application->getId())
            // the column holds the enum, so the enum is what the query takes - its name
            // ("SERVER") is not the value that is stored ("server") and matches nothing
            ->setParameter('context', $context)
            ->getQuery()
            ->execute();
        return $this;
    }

    public function getVariableValue(
        string                $variableName,
        eMacroVariableContext $context = eMacroVariableContext::SERVER,
        Application|int       $application = -1,
        bool                  $evaluate = true,
        mixed                 $defaultValue = null
    )
    {
        $applicationId = $application instanceof Application ? $application->getId() : (int)$application;

        $queryBuilder = $this->createQueryBuilder('t')
            ->andWhere('t.context = :context')
            ->andWhere('t.name = :name');

        if ($applicationId > 0) {
            $queryBuilder
                ->andWhere('t.application = :applicationId')
                ->setParameter('applicationId', $applicationId);
        } else {
            // without an application only the rows that belong to no application are meant -
            // otherwise a variable of the same name of any application would answer here
            $queryBuilder->andWhere('t.application IS NULL');
        }

        $queryBuilder
            ->setParameter('context', $context)
            ->setParameter('name', $variableName)
            // a store that holds the same variable twice must not make reading it fail;
            // the newest row wins, which is the one the last save meant (older
            // installations hold duplicates, written before the context was queried right)
            ->orderBy('t.id', 'DESC')
            ->setMaxResults(1);

        $variableStore = $queryBuilder->getQuery()->getOneOrNullResult();

        if (is_null($variableStore)) {
            return $defaultValue;
        }

        if (!$evaluate) {
            return $variableStore->getValue();
        }

        $stored = $variableStore->getValue();
        $value = $stored[1] ?? null;

        // a list is stored as an array; only the older rows hold it as JSON text
        if (($stored[0] ?? '') === 'array' && is_string($value)) {
            return json_decode($value);
        }

        return $value;
    }

    public function setVariableValue(
        eMacroVariableContext $context,
        string                $variableName,
        mixed                 $value,
        Application|int       $application = -1
    ): bool
    {
        $changed = false;
        $filter = [
            // by its name the criteria matched nothing, and every save wrote another row
            'context' => $context,
            'name' => $variableName
        ];
        if (is_numeric($application) && (int)$application > 0) {
            $application = $this->applicationRepository->find((int)$application);
        }
        // null is part of the filter, not the absence of one: a server variable must not
        // find - and then overwrite - the variable of the same name of an application
        $filter['application'] = $application instanceof Application ? $application : null;
        // the newest row of a name is the one that is kept up to date
        $existingVariable = $this->findOneBy($filter, ['id' => 'DESC']);

        if (!is_array($value)) {
            $value = [
                is_numeric($value) ? 'numeric' : gettype($value),
                $value
            ];
        }

        if ($value[0] === 'numeric') {
            $value[1] = str_contains((string)$value[1], '.') ? (float)$value[1] : (int)$value[1];
        }

        if ($existingVariable) {
            $changed = $existingVariable->getValue() !== $value;
            $existingVariable->setValue($value);

            $this->getEntityManager()->persist($existingVariable);
        } else {
            $changed = true;
            $newVariable = new VariableStore();
            if ($application instanceof Application) {
                $newVariable->setApplication($application);
            }
            $newVariable->setContext($context);
            $newVariable->setName($variableName);
            $newVariable->setValue($value);

            $this->getEntityManager()->persist($newVariable);
        }

        if ($this->_autoFlush) {
            $this->flush();
        }

        return $changed;
    }

    public function flush(): static
    {
        $this->getEntityManager()->flush();
        return $this;
    }

    public function findAllConstants(?int $applicationIdFilter = null): array
    {
        $queryBuilder = $this->createQueryBuilder('t')
            ->andWhere('t.context = :context');

        if (is_null($applicationIdFilter)) {
            $queryBuilder
                ->andWhere('t.application IS NULL');
        } else {
            $queryBuilder->andWhere('t.application = :applicationId');
        }

        $queryBuilder
            ->andWhere('t.name LIKE :name')
            ->setParameter('name', 'CONSTANT.%');

        if (is_null($applicationIdFilter)) {
            $queryBuilder->setParameter('context', eMacroVariableContext::SERVER);
        } else {
            $queryBuilder
                ->setParameter('applicationId', $applicationIdFilter)
                ->setParameter('context', eMacroVariableContext::APPLICATION);
        }

        return $queryBuilder
            ->getQuery()
            ->getResult();
    }

    public function findAll_groupByName(): array
    {
        // return all fields grouped by name
        return $this->createQueryBuilder('t')
            ->select('t.name, t.context, COUNT(t.id) as anzahl')
            ->groupBy('t.name, t.context')
            ->getQuery()
            ->getResult();
    }

    public function setAutoFlush(bool $autoFlush): static
    {
        $this->_autoFlush = $autoFlush;
        return $this;
    }
}
