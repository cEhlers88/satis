<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\DefaultView;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\UserView;

class UserAssembler extends AbstractAssembler
{
    /**
     * @param User $entity
     */
    public function assembleView(EntityInterface|AbstractCustomObject $entity): UserView
    {
        $user = new UserView(
            id: $entity->getId(),
            email: $entity->getEmail(),
            roles: $entity->getRoles(),
            assignedRoles: $entity->getAssignedRoles(),
            groups: array_values(array_map(static fn($group) => $group->getName(), $entity->getUserGroups()->toArray())),
        );

        return $user;
    }

    public function canHandle(string $className): bool
    {
        return $className === User::class;
    }
}