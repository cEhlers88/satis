<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

/** View representation of a User entity. */
class UserView implements ViewInterface
{
    /**
     * @param list<string> $roles         the effective roles, inherited ones included
     * @param list<string> $assignedRoles the roles assigned to the user directly
     * @param list<string> $groups        the names of the user's groups
     */
    public function __construct(
        public int    $id,
        public string $email,
        public array  $roles,
        public array  $assignedRoles = [],
        public array  $groups = [],
    )
    {
    }
}