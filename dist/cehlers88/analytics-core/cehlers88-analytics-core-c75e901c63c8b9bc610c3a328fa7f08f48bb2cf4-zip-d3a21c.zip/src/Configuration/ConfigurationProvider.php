<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 24.05.2024
 * Time: 22:30
 */

namespace Cehlers88\AnalyticsCore\Configuration;

use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\Entity\VariableStore;
use Cehlers88\AnalyticsCore\ENUM\eInputType;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\VariableStoreRepository;

class ConfigurationProvider
{
    public const KEY_INDIVIDUALS = 'individuals';
    public const KEY_CONSTANTS = 'CONSTANT';
    public const KEY_GENERALS = 'main.general';

    private bool $enableAutoload = true;
    private bool $loaded = false;
    private array $_updatedVarsBuffer = [];

    /**
     * @param GroupInterface[] $configurations
     * @param ApplicationRepository $applicationRepository
     * @param VariableStoreRepository $variableStoreRepository
     * @param VariablesProvider $variablesStoreProvider
     * @param array $buffer
     */
    public function __construct(
        private iterable                $configurations,
        private ApplicationRepository   $applicationRepository,
        private VariableStoreRepository $variableStoreRepository,
        private VariablesProvider       $variablesStoreProvider,
        private array                   $buffer = [],
    )
    {
    }

    public function loadBuffer(): static
    {
        $this->_loadConfiguration();
        $this->loaded = true;
        return $this;
    }

    private function _loadConfiguration(): array
    {
        $this->buffer = [];

        $this->_defineBufferItems();

        if ($this->enableAutoload) {
            $this->_enrichBufferItemsWithValues();
        }

        // set default values if needed
        foreach ($this->buffer as $groupIndex => $bufferedGroup) {
            for ($j = 0; $j < count($bufferedGroup['items']); $j++) {
                $bufferedItem = $bufferedGroup['items'][$j];
                if (count($bufferedItem['values']) > 0) {
                    continue;
                }

                $this->buffer[$groupIndex]['items'][$j]['values'][] = [
                    'application_id' => -1,
                    'context' => eMacroVariableContext::SERVER,
                    'value' => $bufferedItem['inputDef']->defaultValue,
                ];
            }
        }

        $this->loaded = true;

        return $this->buffer;
    }

    private function _defineBufferItems(): void
    {
        foreach ($this->configurations as $configuration) {
            $bufferItems = [];
            /**
             * @var $item ConfigurationItemDTO
             */
            foreach ($configuration->getItems() as $item) {
                $bufferItems[] = $this->buildBufferItem(
                    $configuration->getKey() . '.' . $item->key,
                    $item->label,
                    [],
                    $item,
                    $item->needApplication
                );
            }
            $this->buffer[] = $this->createBufferGroup(
                $configuration->getKey(),
                $configuration->getGroupTitle(),
                $configuration->getViewContext(),
                $bufferItems,
                $configuration->needApplication(),
                $configuration->isPersistable()
            );
        }
    }

    public function buildBufferItem(
        string               $key,
        string               $label,
        mixed                $values,
        ConfigurationItemDTO $inputDef,
        bool                 $needApplication = false
    ): array
    {
        return [
            //'context' => eMacroVariableContext::SERVER,
            'key' => $key,
            'label' => $label,
            'needApplication' => $needApplication,
            'inputDef' => $inputDef,
            'values' => $values
        ];
    }

    /**
     * @phpstan-type ConfigArray array{
     *     items: array<array<string, mixed>>,
     *     key: string,
     *     label: string,
     *     needApplication: bool,
     *     persistable: bool,
     *     viewContext: string
     * }
     *
     * @param string $key
     * @param string $label
     * @param string $viewContext
     * @param array $items
     * @param bool $needApplication
     * @param bool $persistable
     * @return ConfigArray
     */
    private function createBufferGroup(
        string $key,
        string $label,
        string $viewContext = '',
        array  $items = [],
        bool   $needApplication = false,
        bool   $persistable = true
    ): array
    {
        return [
            'items' => $items,
            'key' => $key,
            'label' => $label,
            'needApplication' => $needApplication,
            'persistable' => $persistable,
            'viewContext' => $viewContext
        ];
    }

    /**
     * Fills the buffered items with what is stored for them, and collects everything the
     * store holds beyond them into two more groups: the constants (CONSTANT.*) and the
     * individuals - variables nobody declared a configuration item for.
     *
     * The buffer is walked by index rather than by reference: the values are appended to
     * the item they belong to, and nothing outlives the loop it was made in.
     */
    private function _enrichBufferItemsWithValues(): void
    {
        $individualsBuffer = [];
        $constantsBuffer = [];
        $constantsSource = [];

        foreach ($this->variableStoreRepository->findAll() as $variableStore) {
            $bufferedItemFound = false;
            $application = $variableStore->getApplication();
            $storedValue = $this->readStoredValue($variableStore);

            foreach ($this->buffer as $groupIndex => $bufferedGroup) {
                foreach ($bufferedGroup['items'] as $itemIndex => $bufferedItem) {
                    if ($bufferedItem['key'] !== $variableStore->getName()) {
                        continue;
                    }

                    $bufferedItemFound = true;
                    $this->buffer[$groupIndex]['items'][$itemIndex]['values'][] = $storedValue;
                }
            }

            if ($bufferedItemFound) {
                continue;
            }

            $splitName = explode('.', $variableStore->getName());

            if (strtolower($splitName[0]) === 'constant') {
                array_shift($splitName);
                $selfName = implode('.', $splitName);
                $constantsBuffer[$selfName][] = $storedValue;
                $constantsSource[$selfName] ??= $variableStore;

                continue;
            }

            $individualsBuffer[] = $this->buildBufferItem(
                $variableStore->getName(),
                (string)array_pop($splitName),
                [$storedValue],
                $this->evalInputDefByVariableStore($variableStore)
            );
        }

        $items = [];
        foreach ($constantsBuffer as $key => $values) {
            $type = match (strtolower((string)($values[0]['type'] ?? ''))) {
                'password' => eInputType::PASSWORD,
                default => eInputType::TEXT_SINGLE_LINE,
            };

            $items[] = $this->buildBufferItem(
                $key,
                $key,
                $values,
                ConfigurationItemDTO::create($key, $constantsSource[$key]->getName(), $type)
            );
        }

        $this->buffer[] = $this->createBufferGroup(
            self::KEY_CONSTANTS,
            'Constants',
            AbstractConfigurationGroup::VIEW_CONTEXT_SETTINGS,
            $items
        );

        $this->buffer[] = $this->createBufferGroup(
            self::KEY_INDIVIDUALS,
            'Individuals',
            AbstractConfigurationGroup::VIEW_CONTEXT_SETTINGS,
            $individualsBuffer,
        );
    }

    /** One stored value as the buffer holds it - application, context, type and value. */
    private function readStoredValue(VariableStore $variableStore): array
    {
        $application = $variableStore->getApplication();
        $stored = $variableStore->getValue();

        return [
            'application_id' => $application === null ? -1 : $application->getId(),
            'context' => $variableStore->getContext(),
            'type' => $stored[0] ?? eInputType::TEXT_SINGLE_LINE->name,
            'value' => $stored[1] ?? null,
        ];
    }

    public function getValue(
        string $configurationGroupKey,
        string $configurationItemKey,
        int    $applicationId = -1,
        mixed  $defaultValue = null
    ): mixed
    {
        $varName = $configurationGroupKey . '.' . $configurationItemKey;
        // an application that was deleted meanwhile falls back to the server context
        $application = $applicationId === -1 ? null : $this->applicationRepository->find($applicationId);

        // straight from the store: the variables provider is asked for a context, and it
        // was handed the *name of the application* as one, which matches no context at
        // all - so a value set for an application was never found
        return $this->variableStoreRepository->getVariableValue(
            $varName,
            $application === null ? eMacroVariableContext::SERVER : eMacroVariableContext::APPLICATION,
            $application ?? -1,
            true,
            $defaultValue
        );
    }

    /**
     * The input a stored variable is edited with when no configuration item declares it:
     * a list of rows becomes a repeat with the fields of its first row, a password stays
     * a password and everything else is a line of text.
     */
    public function evalInputDefByVariableStore(VariableStore $variableStore): ConfigurationItemDTO
    {
        $stored = $variableStore->getValue();
        $type = $stored[0] ?? '';
        $value = $stored[1] ?? null;

        if ($type === 'array') {
            $rows = is_string($value) ? json_decode($value, true) : $value;
            $firstRow = is_array($rows) ? (reset($rows) ?: []) : [];
            $children = [];

            foreach (is_array($firstRow) ? array_keys($firstRow) : [] as $key) {
                $children[] = ConfigurationItemDTO::create((string)$key, (string)$key);
            }

            return ConfigurationItemDTO::createRepeat($variableStore->getName(), $variableStore->getName(), $children);
        }

        if (strtolower((string)$type) === 'password') {
            return ConfigurationItemDTO::create($variableStore->getName(), $variableStore->getName(), eInputType::PASSWORD);
        }

        return ConfigurationItemDTO::create($variableStore->getName(), $variableStore->getName());
    }

    public function loadRequestData(array $requestData): static
    {
        $groups = [];

        foreach ($requestData as $key => $value) {
            $explodedKey = explode('_', $key);

            if (count($explodedKey) > 2) {
                $context = $explodedKey[0];
                $applicationId = $explodedKey[1];
                $key = $explodedKey[2];
                $groupName = $explodedKey[2];
                $groupKey = $explodedKey[count($explodedKey) - 1];

                for ($i = 3; $i < count($explodedKey); $i++) {
                    $key .= '_' . $explodedKey[$i];
                    $groupName .= $i < count($explodedKey) - 1 ? '_' . $explodedKey[$i] : '';
                }

                $key = str_replace(self::KEY_INDIVIDUALS . '_', '', $key);

                if (!is_array($value)) {
                    // unchanged values are not written again; both sides are compared as
                    // text because what comes in from a form is always text
                    $currentValue = $this->getValue(str_replace('_', '.', $groupName), $groupKey, (int)$applicationId);
                    if (!is_array($currentValue) && (string)$currentValue === (string)$value) {
                        continue;
                    }
                }

                if (is_array($value)) {
                    // store group
                    $groupIndex = -1;
                    for ($i = 0; $i < count($groups); $i++) {
                        if ($groups[$i]['groupName'] === $groupName && $groups[$i]['context'] === $context && $groups[$i]['applicationId'] === $applicationId) {
                            $groupIndex = $i;
                            break;
                        }
                    }

                    if ($groupIndex === -1) {
                        $groups[] = [
                            'groupName' => $groupName,
                            'context' => $context,
                            'applicationId' => $applicationId,
                            'values' => []
                        ];
                        $groupIndex = count($groups) - 1;
                    }

                    foreach ($value as $index => $valueEntry) {
                        if (!isset($groups[$groupIndex]['values'][$index])) {
                            $groups[$groupIndex]['values'][$index] = [];
                        }
                        $groups[$groupIndex]['values'][$index][$groupKey] = $valueEntry;
                    }
                } else {
                    $this->_addUpdatedVar(
                        eMacroVariableContext::fromString($context),
                        str_replace("_", ".", $key),
                        [
                            is_numeric($value) ? 'numeric' : gettype($value),
                            $value
                        ],
                        (int)$applicationId,
                        $groupName
                    );
                }
            }
        }

        foreach ($groups as $group) {
            $this->_addUpdatedVar(
                eMacroVariableContext::fromString($group['context']),
                str_replace("_", ".", $group['groupName']),
                ['array', $group['values']],
                $group['applicationId']
            );
        }

        return $this;
    }

    private function _addUpdatedVar(
        eMacroVariableContext $context,
        string                $variableName,
        mixed                 $variableValue,
        int                   $applicationId,
        string                $groupName = ''
    ): void
    {
        if (!isset($this->_updatedVarsBuffer[$context->name])) {
            $this->_updatedVarsBuffer[$context->name] = [];
        }

        $appGroup = $applicationId > 0 ? 'app' . $applicationId : 'server';

        if (!isset($this->_updatedVarsBuffer[$context->name][$appGroup])) {
            $this->_updatedVarsBuffer[$context->name][$appGroup] = [];
        }

        $this->_updatedVarsBuffer[$context->name][$appGroup][$variableName] = [
            'context' => $context,
            'groupName' => $groupName,
            'applicationId' => $applicationId,
            'value' => $variableValue
        ];
    }

    public function persistConfiguration(): array
    {
        $changed = false;

        foreach ($this->_updatedVarsBuffer as $context => $bufferedApplicationGroups) {
            foreach ($bufferedApplicationGroups as $group => $bufferedGroupVars) {
                foreach ($bufferedGroupVars as $varName => $varInfos) {
                    $changed = $this->variableStoreRepository->setVariableValue(
                            $varInfos['context'],
                            $varName,
                            $varInfos['value'],
                            $varInfos['applicationId']
                        ) || $changed;

                }
            }
        }

        if ($changed) {
            $this->variableStoreRepository->flush();
        }

        return $this->getConfigurations();
    }

    public function getConfigurations(): array
    {
        if (!$this->loaded) {
            return $this->_loadConfiguration();
        }
        return $this->buffer;
    }

    public function getConfiguration(string $key): ?GroupInterface
    {
        foreach ($this->configurations as $group) {
            if ($group->getKey() === $key) {
                return $group;
            }
        }
        return null;
    }

    public function setEnableAutoload(bool $enableAutoload): static
    {
        $this->enableAutoload = $enableAutoload;
        return $this;
    }
}