# Property UI

How a property of a command is edited in the command editors of the
application - the commands view (`<exec-viewer>` with `<property-element>`s)
and the code view. A macro describes it; the editors read it.

## Declaring

A macro implements `Macro\PropertyUi\PropertyUiProviderInterface`:

```php
class IfMacro extends AbstractMacro implements PropertyUiProviderInterface
{
    public static function getPropertyUiInfos(MacroPropertyDTO $property): ?PropertyUi
    {
        return match ($property->name) {
            'conditions' => PropertyUi::condition()->displayName('Condition'),
            'whenTrueCommands' => PropertyUi::commands()->displayName('True')->cssClass('is-case case-true'),
            default => null,
        };
    }
}
```

`$property` carries the name, the type of the command row and the value the
property holds right now. Returning `null` leaves the property to be edited the
way its value suggests. A plain array with the same keys works as well.

| Key           | Builder                     | Meaning                                                           |
|---------------|-----------------------------|-------------------------------------------------------------------|
| `displayName` | `displayName()`             | Label instead of the property name                                |
| `class`       | `cssClass()`                | Additional css classes of the property                            |
| `description` | `description()`             | Explanation; defaults to the description the macro gives          |
| `editor`      | `editor()`, `commands()`, `condition()` | `text` (default), `select`, `commands`, `condition`, `cases` (`[{"when": …, "commands": […]}]`) |
| `options`     | `options()`                 | Fixed values (`value => label`); suggestions, or the only choice with `select` |
| `placeholder` | `placeholder()`             | Placeholder of an empty field                                     |
| `valueHelper` | `valueHelper($class, $opts)`| Suggestions that depend on the definition being edited            |

Keys this list does not know are passed through unchanged.

## Resolving

`PropertyUiResolver` merges, later wins:

1. the description the macro gives the property,
2. the macro the command runs - found by its name among the `analytics.macro`
   services, or by the class written into `command.macro`,
3. `ui_settings.propertyExtender` - `"Class::getPropertyUiInfos"`, for a
   command whose macro cannot be found that way (only that method is called),
4. `ui_settings.properties.<property>` - plain infos on a single command row.

So a command row needs nothing in `ui_settings` for a macro that implements
the interface. `PropertyUi::normalize()` makes every source look the same;
a `valueHelper` that is no `AbstractValueHelper` is dropped, since its class
name travels to the browser and back.

Where the infos reach the editors:

- `CommandFactory::setPropertyUiResolver()` puts them on `PropertyDTO::$ui` of
  every command it reads (the conversion endpoint the commands view uses),
- `/admin_api/list/command` carries `propertyUi` per command for the code view,
  which works on raw definitions.

## Value helpers

A value helper extends `Macro\ValueHelper\AbstractValueHelper` and is run by
`ValueHelperRunner` (endpoint `/admin_api/execute/valueHelper`). It is handed a
`ValueHelperContextDTO`:

- the command and property being edited and the properties around it,
- the whole definition and its arguments,
- `occurrences` - every other property of the definition that names the same
  helper, with its value and its sibling properties.

`SelectVarNameValueHelper` builds its suggestions from those occurrences:
every property that names it - `setVar.name`, `getVar.name`, `for.as` - is a
variable name, so a macro takes part simply by naming the helper. Options:
`contextProperty` (sibling property holding the context) and `defaultContext`.

## Conditions

A condition group is written `[operator, [values…]]` and read into a
`ConditionGroupDTO`. `Support\Condition\ConditionEvaluator` decides it:

| Operators                                                          | Meaning                                          |
|--------------------------------------------------------------------|--------------------------------------------------|
| `&&` `and`, `\|\|` `or`, `xor`                                     | combine the conditions they hold                 |
| `!` `not`                                                          | negate - several values read as "not all of them" |
| `==` `===` `equals`, `!=` `!==`, `>`, `>=`, `<`, `<=`              | compare pairwise left to right (`1 < x < 10`)    |
| `contains`, `!contains`, `startsWith`, `endsWith`                  | on strings, `contains` also on lists             |

Comparisons are the lenient ones of the property conditions - values typed
into an editor arrive as strings. A value without operator holds when it is
`true`, a number above zero or `"true"`/`"1"`; a list without operator when all
entries hold (the shape `if` was given before there were groups). Commands in a
condition run only when the evaluator reaches them, so `&&` and `||` stop early.

`eConditionType::tryFromOperator()` / `operator()` are the one place the
spellings live; `assets/Property/PropertyUi.ts` of the application mirrors them.
