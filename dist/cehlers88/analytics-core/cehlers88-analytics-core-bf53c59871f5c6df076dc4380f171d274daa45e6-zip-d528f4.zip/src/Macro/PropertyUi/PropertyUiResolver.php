<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\PropertyUi;

use Cehlers88\AnalyticsCore\Entity\Command;
use Cehlers88\AnalyticsCore\Macro\AbstractMacro;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\MacroInterface;

/**
 * How the properties of a command are edited, merged from - later wins:
 *
 *  1. the description the macro gives the property
 *  2. the macro the command runs, when it is a PropertyUiProviderInterface
 *  3. `ui_settings.propertyExtender` of the command row - "Class::getPropertyUiInfos",
 *     for a command whose macro cannot be found by its name
 *  4. `ui_settings.properties.<property>` of the command row - plain infos, so
 *     a single command can be adjusted without code
 *
 * Every source is run through PropertyUi::normalize(), so the editors always
 * read one shape.
 */
final class PropertyUiResolver
{
    public const string SETTINGS_PROPERTY_EXTENDER = 'propertyExtender';
    public const string SETTINGS_PROPERTIES = 'properties';

    private const string PROVIDER_METHOD = 'getPropertyUiInfos';

    /** @var array<string, AbstractMacro>|null */
    private ?array $macrosByName = null;

    /**
     * @param iterable<MacroInterface> $macros
     */
    public function __construct(
        private readonly iterable $macros = []
    )
    {
    }

    /**
     * The infos of one property. $value is what the property holds right now -
     * a provider may decide on it.
     */
    public function resolve(Command $command, string $propertyName, mixed $value = null): array
    {
        $infos = [];
        $description = $this->descriptionOf($command, $propertyName);

        if ($description !== '') {
            $infos[PropertyUi::KEY_DESCRIPTION] = $description;
        }

        $property = MacroPropertyDTO::create($propertyName, $this->typesOf($command, $propertyName), $description, $value);
        $providers = array_unique(array_filter([
            $this->macroClassOf($command),
            $this->extenderClassOf($command),
        ]));

        foreach ($providers as $provider) {
            if ($this->isProvider($provider)) {
                $infos = array_replace($infos, PropertyUi::normalize($provider::getPropertyUiInfos(clone $property)));
            }
        }

        $overrides = $command->getUiSettings()[self::SETTINGS_PROPERTIES][$propertyName] ?? null;

        if (is_array($overrides)) {
            $infos = array_replace($infos, PropertyUi::normalize($overrides));
        }

        return $infos;
    }

    /**
     * The infos of every property that has any, by property name - what an
     * editor needs that reads a definition without asking for each command.
     *
     * @return array<string, array>
     */
    public function resolveAll(Command $command): array
    {
        $names = array_map(
            static fn(array $macroProp): string => (string)($macroProp[Command::MACRO_PROPS_INDEX_NAMES] ?? ''),
            array_filter($command->getMacroProps() ?? [], 'is_array')
        );
        $names = [...$names, ...array_keys($command->getUiSettings()[self::SETTINGS_PROPERTIES] ?? [])];
        $result = [];

        foreach (array_unique(array_filter($names)) as $name) {
            $infos = $this->resolve($command, $name);

            if ($infos !== []) {
                $result[$name] = $infos;
            }
        }

        return $result;
    }

    /** The macro service a command runs, null when there is none by that name. */
    public function macroOf(Command $command): ?AbstractMacro
    {
        $macro = ltrim((string)$command->getMacro(), '\\');

        if ($macro === '') {
            return null;
        }

        foreach ($this->macrosByName() as $name => $instance) {
            if ($name === $macro || $instance::class === $macro) {
                return $instance;
            }
        }

        return null;
    }

    /**
     * The class of the macro a command runs. A class that is written out is
     * taken even when it is no service - its infos are static.
     */
    public function macroClassOf(Command $command): ?string
    {
        $instance = $this->macroOf($command);

        if ($instance !== null) {
            return $instance::class;
        }

        $macro = ltrim((string)$command->getMacro(), '\\');

        return str_contains($macro, '\\') && class_exists($macro) ? $macro : null;
    }

    /**
     * The class a command row names as its extender. Only the one method of
     * the contract is accepted - the row is data, not a place to call
     * anything from.
     */
    private function extenderClassOf(Command $command): ?string
    {
        $extender = $command->getUiSettings()[self::SETTINGS_PROPERTY_EXTENDER] ?? null;

        if (!is_string($extender) || !str_contains($extender, '::')) {
            return null;
        }

        [$class, $method] = explode('::', ltrim($extender, '\\'), 2);

        return $method === self::PROVIDER_METHOD && class_exists($class) ? $class : null;
    }

    /**
     * A macro written before the interface existed has the method but not the
     * interface - it is a macro all the same, so it is asked too.
     */
    private function isProvider(string $class): bool
    {
        return is_subclass_of($class, PropertyUiProviderInterface::class)
            || (is_subclass_of($class, MacroInterface::class) && method_exists($class, self::PROVIDER_METHOD));
    }

    private function descriptionOf(Command $command, string $propertyName): string
    {
        $macro = $this->macroOf($command);

        if ($macro === null) {
            return '';
        }

        try {
            $property = $macro->getDefinition()['properties'][$propertyName] ?? null;
        } catch (\Throwable) {
            // A macro that cannot describe itself outside of a run simply has
            // no description to offer.
            return '';
        }

        return $property instanceof MacroPropertyDTO ? $property->description : '';
    }

    private function typesOf(Command $command, string $propertyName): array
    {
        foreach ($command->getMacroProps() ?? [] as $macroProp) {
            if (is_array($macroProp) && ($macroProp[Command::MACRO_PROPS_INDEX_NAMES] ?? null) === $propertyName) {
                return [(string)($macroProp[Command::MACRO_PROPS_INDEX_TYPES] ?? 'mixed')];
            }
        }

        return [];
    }

    /** @return array<string, AbstractMacro> */
    private function macrosByName(): array
    {
        if ($this->macrosByName === null) {
            $this->macrosByName = [];

            foreach ($this->macros as $macro) {
                if ($macro instanceof AbstractMacro) {
                    $this->macrosByName[$macro->getName()] = $macro;
                }
            }
        }

        return $this->macrosByName;
    }
}
