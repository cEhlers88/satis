<?php

namespace Cehlers88\AnalyticsCore\Process\Exception;

class RunnerNotFoundException extends \Exception
{
    private string $runner;

    public function getRunner(): string
    {
        return $this->runner;
    }

    public function setRunner(string $runner): static
    {
        $this->runner = $runner;
        return $this;
    }

}