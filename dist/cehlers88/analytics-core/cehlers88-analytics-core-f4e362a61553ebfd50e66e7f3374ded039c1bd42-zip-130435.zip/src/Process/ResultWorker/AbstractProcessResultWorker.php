<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

use Analytics\Abstract\AbstractPropertyHolder;
use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

abstract class AbstractProcessResultWorker extends AbstractPropertyHolder implements ProcessResultWorkerInterface
{
    protected Process $process;

    public function setProcess(Process $process): static
    {
        $this->process = $process;
        return $this;
    }

    public function run(Process $process, mixed $result): static
    {
        $this->process = $process;
        $process->addState(eRunningState::ProcessingResult);
        $this->handleResult($result);
        $process
            ->removeState(eRunningState::ProcessingResult)
            ->addState(eRunningState::ResultProcessed);

        return $this;
    }
}