<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

class ModifyTrackingBufferResultWorker extends AbstractProcessResultWorker
{
    public function handleResult(mixed $result): static
    {
        return $this;
    }

}