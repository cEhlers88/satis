<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 31.08.2024
 * Time: 09:20
 */

namespace Cehlers88\AnalyticsCore\Process\Runner;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Process\DTO\StartInfoDTO;
use Cehlers88\AnalyticsCore\Process\ProcessProvider;
use Cehlers88\AnalyticsCore\Repository\ProcessRepository;
use Cehlers88\AnalyticsCore\Support\Error\AbstractErrorBag;

abstract class AbstractProcessRunner extends AbstractErrorBag implements ProcessRunnerInterface
{
    public const STARTINFO_KEY_RUNNER_ARGUMENTS = 'runner_arguments';
    public const CODE_INVALID_ARGUMENTS = 510;

    protected ?Process $process = null;
    protected ProcessProvider $processProvider;
    protected ProcessRepository $processRepository;


    public function run(): void
    {
        if ($this->process->hasState(eRunningState::NeedsValidation)) {
            $this->validate();
            return;
        }

        if ($this->process->hasState(eRunningState::Invalid)) {
            return;
        }

        if ($this->process->hasState(eRunningState::Canceled)) {
            $this->process->setState(eRunningState::Canceled); // to remove every not "Canceled" state
            return;
        }

        $this->handle();
    }

    public function validate(): static
    {
        foreach ($this->getRequiredArguments() as $var) {
            if (is_null($this->getProcess()->getRunnerAttributeValue($var))) {
                $this->process->addState(eRunningState::Invalid);
                $this->logInfo('Missing argument "' . $var . '"');
            }
        }

        $this->process->removeState(eRunningState::NeedsValidation);

        return $this;
    }

    public function getRequiredArguments(): array
    {
        return [];
    }

    /*public function handleExternalResponse(Process $process, mixed $response): ProcessRunnerResultDTO
    {
              if (!$process->hasState(eProcessState::WAITING)) {
                  throw new \RuntimeException('Process is not waiting for external response');
              }

              $this->process = $process;
              $this->handle();
              $result = ProcessRunnerResultDTO::createSuccess();
              $result->newState = $this->process->getStateValue();

        return ProcessRunnerResultDTO::createSuccess();
    }*/

    public function getProcess(bool $createIfNotExist = true): ?Process
    {
        return $this->process ?? ($createIfNotExist ? new Process() : null);
    }

    public function setProcess(Process $process): static
    {
        $this->process = $process;
        return $this;
    }

    public function setState(int $state): static
    {
        $this->process->setStateValue($state);
        return $this;
    }

    abstract public function handle(): void;

    public function getArguments(): array
    {
        return $this->getProcess()->getStartInfo(StartInfoDTO::KEY_RUNNER_ARGUMENTS) ?? [];
    }

    public function setError(string $message, int $code = -1, array $data = []): ErrorDTO
    {
        $this->process->addState(eRunningState::Error);
        $details = $this->process->getDetails() ?? [];
        $errors = $details['errors'] ?? [];
        if (count($errors) > 0) {
            if (end($errors) !== $message) {
                $errors[] = $message;
            }
        }
        $details['errors'] = $errors;
        $this->process->setDetails($details);

        return parent::setError($message, $code, $data);
    }

    public function setProcessProvider(ProcessProvider $processProvider): static
    {
        $this->processProvider = $processProvider;
        return $this;
    }

    public function setProcessRepository(ProcessRepository $processRepository): static
    {
        $this->processRepository = $processRepository;
        return $this;
    }
}