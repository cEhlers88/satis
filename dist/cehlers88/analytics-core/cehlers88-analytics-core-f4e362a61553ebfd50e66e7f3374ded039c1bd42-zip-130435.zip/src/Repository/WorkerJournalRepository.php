<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\Entity\WorkerJournal;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<WorkerJournal>
 *
 * @method WorkerJournal|null find($id, $lockMode = null, $lockVersion = null)
 * @method WorkerJournal|null findOneBy(array $criteria, array $orderBy = null)
 * @method WorkerJournal[]    findAll()
 * @method WorkerJournal[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class WorkerJournalRepository extends ServiceEntityRepository
{
    public function __construct(
        ManagerRegistry                $registry,
        private EntityManagerInterface $entityManager
    )
    {
        parent::__construct($registry, WorkerJournal::class);
    }

    public function addWorkerResult(Worker $worker, WorkerResultDTO $resultDTO): WorkerJournalRepository
    {
        $workerJournal = new WorkerJournal();
        $workerJournal
            ->setWorker($worker)
            ->setResult($resultDTO);
        return $this->add($workerJournal);
    }

    public function add(WorkerJournal $workerJournal): WorkerJournalRepository
    {
        $this->entityManager->persist($workerJournal);
        $this->entityManager->flush();

        return $this;
    }

    public function save(WorkerJournal $object, bool $flush = true): static
    {
        $this->entityManager->persist($object);
        if ($flush) {
            $this->entityManager->flush();
        }
        return $this;
    }
}
