<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<CustomEntityAttribute>
 */
class CustomEntityAttributeRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CustomEntityAttribute::class);
    }
}
