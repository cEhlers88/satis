# Changelog

## [0.1.4](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.3...v0.1.4) (2026-01-21)


### Bug Fixes

* Update ClientPermission `permkeys` field type from ARRAY to JSON ([bddfd5e](https://github.com/cEhlers88/AnalyticsCore/commit/bddfd5e267cfec90fdd9624fbb9f054d77ef3102))
* Update service bindings to use `!tagged_iterator` for tagged services ([faf2a03](https://github.com/cEhlers88/AnalyticsCore/commit/faf2a03bb969fac99b2c79e326a7fd031be047d1))

## [0.1.3](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.2...v0.1.3) (2026-01-20)


### Miscellaneous Chores

* add release-please.yml ([8438a59](https://github.com/cEhlers88/AnalyticsCore/commit/8438a594eb4f9afcfd600fa0ae51d90e88fb76b6))
