<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Event\Tool;

/**
 * Asks the bundles for the tools they bring to the tools page of the application - a
 * bundle adds its own without the application (or another bundle) knowing its classes.
 *
 * A tool is described as the application's tool catalog describes its own:
 *  - name, title, description (required; the name is unique)
 *  - categories: the chips its tile is filtered by
 *  - teaser / image: the tile background (templates/tool/teaser/*.html.twig or an url)
 *  - template, scripts, styles: what the modal of the tool is made of (templates/tool/)
 *  - requiredRoles: the roles a user needs by default
 *  - routes: the route names (or prefixes ending in "_") of the tool's own backend
 *  - templateData: what its template is rendered with
 */
final class CollectToolsEvent
{
    /** @var array<string, array<string, mixed>> */
    private array $tools = [];

    /** @param array<string, mixed> $tool */
    public function addTool(array $tool): self
    {
        $name = $tool['name'] ?? null;
        if (!is_string($name) || preg_match('/^[A-Za-z][A-Za-z0-9]*$/', $name) !== 1) {
            throw new \InvalidArgumentException('A tool needs a name of letters and digits.');
        }
        foreach (['title', 'description', 'template'] as $key) {
            if (!is_string($tool[$key] ?? null) || $tool[$key] === '') {
                throw new \InvalidArgumentException(sprintf('The tool "%s" needs a %s.', $name, $key));
            }
        }
        $this->tools[$name] = $tool;

        return $this;
    }

    /** @return list<array<string, mixed>> */
    public function getTools(): array
    {
        return array_values($this->tools);
    }
}
