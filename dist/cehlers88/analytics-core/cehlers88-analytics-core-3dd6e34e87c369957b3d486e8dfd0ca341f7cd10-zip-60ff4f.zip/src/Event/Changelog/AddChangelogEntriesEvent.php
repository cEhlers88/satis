<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Event\Changelog;

/**
 * Entries for a changelog - the done tasks of a note, say. Whoever keeps the changelog
 * (CollectChangelogTargetsEvent) takes them and says so with accept(); nobody taking them
 * leaves the event unhandled.
 */
final class AddChangelogEntriesEvent
{
    private ?string $acceptedBy = null;
    private int $acceptedCount = 0;

    /**
     * @param list<string> $entries one line of text each, Markdown allowed
     * @param string|null $target the key of the changelog meant; null: the first that takes them
     * @param string $source where the entries come from ("Notiz „Release 0.31“")
     * @param string|null $author who moves them
     */
    public function __construct(
        public readonly array   $entries,
        public readonly ?string $target = null,
        public readonly string  $source = '',
        public readonly ?string $author = null,
    ) {
    }

    public function accept(string $target, int $count): void
    {
        $this->acceptedBy = $target;
        $this->acceptedCount = $count;
    }

    public function isHandled(): bool
    {
        return $this->acceptedBy !== null;
    }

    public function getAcceptedBy(): ?string
    {
        return $this->acceptedBy;
    }

    public function getAcceptedCount(): int
    {
        return $this->acceptedCount;
    }
}
