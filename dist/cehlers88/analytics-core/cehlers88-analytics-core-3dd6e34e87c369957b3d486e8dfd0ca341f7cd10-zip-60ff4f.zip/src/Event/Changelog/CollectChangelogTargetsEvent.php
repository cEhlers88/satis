<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Event\Changelog;

/**
 * Asks whether there is a changelog that takes entries (AddChangelogEntriesEvent) - so the
 * notes can offer to move done tasks there only when a bundle keeps one.
 */
final class CollectChangelogTargetsEvent
{
    /** @var array<string, string> label by key */
    private array $targets = [];

    public function addTarget(string $key, string $label): self
    {
        $this->targets[$key] = $label;

        return $this;
    }

    /** @return array<string, string> label by key */
    public function getTargets(): array
    {
        return $this->targets;
    }

    public function hasTargets(): bool
    {
        return $this->targets !== [];
    }
}
