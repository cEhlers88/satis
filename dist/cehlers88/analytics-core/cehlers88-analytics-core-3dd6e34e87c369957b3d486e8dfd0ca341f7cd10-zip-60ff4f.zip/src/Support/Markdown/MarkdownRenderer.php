<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Support\Markdown;

/**
 * The everyday part of Markdown as HTML - for every bundle that shows text someone wrote
 * (the notes of the application, the changelog of the develope bundle, ...): headings,
 * paragraphs, lists and task lists, tables, quotes, code blocks, rules, `code`, **bold**,
 * *italic*, ~~struck~~, http(s) links, colored text ([text]{color=#… bg=#…}) - and images,
 * when the caller says where they may come from (the image resolver).
 *
 * Everything is escaped before it becomes markup: the text may end up on a public page.
 */
final class MarkdownRenderer
{
    private const LINK_ATTRIBUTES = 'target="_blank" rel="noopener noreferrer"';
    private const TASK_ITEM = '/^\[([ xX])\]\s+(.*)$/';

    /**
     * @param (\Closure(string): ?string)|null $imageResolver turns the source of an image
     *        (![alt](source)) into the url it is shown from - null for a source that is not
     *        to be shown. Without a resolver there are no images: the markup stays text.
     */
    public function __construct(
        private readonly ?\Closure $imageResolver = null,
    ) {
    }

    public function render(string $source): string
    {
        $lines = explode("\n", str_replace(["\r\n", "\r"], "\n", $source));
        $html = [];
        $paragraph = [];
        $quote = [];
        $list = null;

        $flushParagraph = function () use (&$paragraph, &$html): void {
            if ($paragraph !== []) {
                $html[] = '<p>' . implode('<br>', array_map($this->inline(...), $paragraph)) . '</p>';
                $paragraph = [];
            }
        };
        $flushQuote = function () use (&$quote, &$html): void {
            if ($quote !== []) {
                $html[] = '<blockquote>' . implode('<br>', array_map($this->inline(...), $quote)) . '</blockquote>';
                $quote = [];
            }
        };
        $flushList = static function () use (&$list, &$html): void {
            if ($list !== null) {
                $html[] = "<{$list['tag']}>" . implode('', $list['items']) . "</{$list['tag']}>";
                $list = null;
            }
        };
        $flush = static function () use ($flushParagraph, $flushQuote, $flushList): void {
            $flushParagraph();
            $flushQuote();
            $flushList();
        };

        for ($index = 0; $index < count($lines); $index++) {
            $line = $lines[$index];

            if (preg_match('/^\s*```/', $line) === 1) {
                $flush();
                $code = [];
                for ($index++; $index < count($lines) && preg_match('/^\s*```\s*$/', $lines[$index]) !== 1; $index++) {
                    $code[] = $lines[$index];
                }
                $html[] = '<pre><code>' . self::escape(implode("\n", $code)) . '</code></pre>';
                continue;
            }
            if (trim($line) === '') {
                $flush();
                continue;
            }

            $alignments = $index + 1 < count($lines) && str_contains($line, '|') ? self::alignments($lines[$index + 1]) : null;
            if ($alignments !== null) {
                $head = self::cells($line);
                if (count($head) === count($alignments)) {
                    $flush();
                    $rows = [];
                    for ($index += 2; $index < count($lines) && str_contains($lines[$index], '|') && trim($lines[$index]) !== ''; $index++) {
                        $rows[] = self::cells($lines[$index]);
                    }
                    $index--;
                    $html[] = $this->table($head, $alignments, $rows);
                    continue;
                }
            }

            if (preg_match('/^\s*(#{1,6})\s+(.*?)\s*#*\s*$/', $line, $heading) === 1) {
                $flush();
                $level = min(strlen($heading[1]) + 2, 6);
                $html[] = "<h{$level}>" . $this->inline($heading[2]) . "</h{$level}>";
                continue;
            }
            if (preg_match('/^\s*([-*_])(\s*\1){2,}\s*$/', $line) === 1) {
                $flush();
                $html[] = '<hr>';
                continue;
            }
            if (preg_match('/^\s*>\s?(.*)$/', $line, $quoted) === 1) {
                $flushParagraph();
                $flushList();
                $quote[] = $quoted[1];
                continue;
            }
            if (preg_match('/^\s*([-*+]|\d{1,9}[.)])\s+(.*)$/', $line, $item) === 1) {
                $flushParagraph();
                $flushQuote();
                $tag = preg_match('/\d/', $item[1]) === 1 ? 'ol' : 'ul';
                if ($list === null || $list['tag'] !== $tag) {
                    $flushList();
                    $list = ['tag' => $tag, 'items' => []];
                }
                if (preg_match(self::TASK_ITEM, $item[2], $task) === 1) {
                    $checked = $task[1] !== ' ';
                    $list['items'][] = '<li class="is-task' . ($checked ? ' is-done' : '') . '">'
                        . '<input type="checkbox" disabled' . ($checked ? ' checked' : '') . '> '
                        . $this->inline($task[2]) . '</li>';
                } else {
                    $list['items'][] = '<li>' . $this->inline($item[2]) . '</li>';
                }
                continue;
            }

            $flushQuote();
            $flushList();
            $paragraph[] = $line;
        }
        $flush();

        return implode('', $html);
    }

    /** How many tasks the text holds, and how many of them are ticked off. */
    public static function taskCount(string $source): array
    {
        $done = 0;
        $total = 0;
        foreach (explode("\n", str_replace(["\r\n", "\r"], "\n", $source)) as $line) {
            if (preg_match('/^\s*(?:[-*+]|\d{1,9}[.)])\s+\[([ xX])\]\s/', $line, $match) === 1) {
                $total++;
                $done += $match[1] === ' ' ? 0 : 1;
            }
        }

        return ['done' => $done, 'total' => $total];
    }

    private static function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    /**
     * @return list<string>
     */
    private static function cells(string $line): array
    {
        $trimmed = preg_replace('/^\||\|$/', '', trim($line)) ?? '';

        return array_map(
            static fn(string $cell): string => trim(str_replace('\\|', '|', $cell)),
            preg_split('/(?<!\\\\)\|/', $trimmed) ?: [],
        );
    }

    /**
     * @return list<string>|null
     */
    private static function alignments(string $line): ?array
    {
        if (!str_contains($line, '|') || preg_match('/^[\s|:-]+$/', $line) !== 1) {
            return null;
        }
        $cells = self::cells($line);
        if ($cells === []) {
            return null;
        }
        foreach ($cells as $cell) {
            if (preg_match('/^:?-+:?$/', $cell) !== 1) {
                return null;
            }
        }

        return array_map(static function (string $cell): string {
            $left = str_starts_with($cell, ':');
            $right = str_ends_with($cell, ':');

            return $left && $right ? 'center' : ($right ? 'right' : ($left ? 'left' : ''));
        }, $cells);
    }

    /**
     * @param list<string> $head
     * @param list<string> $alignments
     * @param list<list<string>> $rows
     */
    private function table(array $head, array $alignments, array $rows): string
    {
        $cell = function (string $tag, string $value, int $column) use ($alignments): string {
            $align = $alignments[$column] ?? '';

            return sprintf('<%s%s>%s</%s>', $tag, $align !== '' ? sprintf(' style="text-align: %s"', $align) : '', $this->inline($value), $tag);
        };

        $html = '<table><thead><tr>';
        foreach ($head as $column => $value) {
            $html .= $cell('th', $value, $column);
        }
        $html .= '</tr></thead><tbody>';
        foreach ($rows as $row) {
            $html .= '<tr>';
            foreach (array_keys($head) as $column) {
                $html .= $cell('td', $row[$column] ?? '', $column);
            }
            $html .= '</tr>';
        }

        return $html . '</tbody></table>';
    }

    /** [text]{color=#… bg=#…} - brackets in the text are escaped with a backslash. */
    private const COLOR_SPAN = '/\[((?:\\\\[\[\]]|[^\[\]])+)\]\{([^{}\n]*)\}/';

    /**
     * [text]{color=#e53935 bg=#5c4b00} - colored text, as Notes.ts renders it. Only hex
     * colors are taken, so the style attribute holds nothing but colors; inner spans are
     * replaced first, so spans can nest.
     */
    private static function colorSpans(string $html): string
    {
        for ($pass = 0; $pass < 5; ++$pass) {
            $next = preg_replace_callback(
                self::COLOR_SPAN,
                static function (array $m): string {
                    $colors = self::colorAttributes($m[2]);
                    if ($colors === null) {
                        return $m[0];
                    }
                    $style = implode('; ', array_filter([
                        $colors['color'] !== '' ? 'color: ' . $colors['color'] : '',
                        $colors['bg'] !== '' ? 'background-color: ' . $colors['bg'] : '',
                    ]));
                    $label = preg_replace('/\\\\([\[\]])/', '$1', $m[1]) ?? $m[1];

                    return sprintf('<span class="note-color%s" style="%s">%s</span>', $colors['bg'] !== '' ? ' has-bg' : '', $style, $label);
                },
                $html,
            ) ?? $html;
            if ($next === $html) {
                break;
            }
            $html = $next;
        }

        return $html;
    }

    /** The text without its color markup, as Notes.ts stripColors() gives it. */
    public static function stripColors(string $text): string
    {
        for ($pass = 0; $pass < 5; ++$pass) {
            $next = preg_replace_callback(
                self::COLOR_SPAN,
                static fn(array $m): string => self::colorAttributes($m[2]) === null ? $m[0] : (preg_replace('/\\\\([\[\]])/', '$1', $m[1]) ?? $m[1]),
                $text,
            ) ?? $text;
            if ($next === $text) {
                break;
            }
            $text = $next;
        }

        return $text;
    }

    /** @return array{color: string, bg: string}|null */
    private static function colorAttributes(string $attributes): ?array
    {
        $colors = ['color' => '', 'bg' => ''];
        $parts = preg_split('/\s+/', trim($attributes), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        if ($parts === []) {
            return null;
        }
        foreach ($parts as $part) {
            if (preg_match('/^(color|bg)=(#(?:[0-9a-f]{3}|[0-9a-f]{6}))$/iD', $part, $match) !== 1) {
                return null;
            }
            $colors[strtolower($match[1])] = strtolower($match[2]);
        }

        return $colors;
    }

    /** Code spans and links are set aside first, so emphasis cannot reach into them. */
    private function inline(string $line): string
    {
        $kept = [];
        $keep = static function (string $html) use (&$kept): string {
            $kept[] = $html;

            return "\x00" . (count($kept) - 1) . "\x00";
        };

        $html = self::escape(str_replace("\x00", '', $line));
        $html = preg_replace_callback('/`([^`]+)`/', static fn(array $m): string => $keep('<code>' . $m[1] . '</code>'), $html) ?? $html;
        if ($this->imageResolver !== null) {
            // ![alt](source) - before the links, whose pattern would take the part after the "!"
            $html = preg_replace_callback(
                '/!\[([^\]]*)\]\(([^)\s]+)\)/',
                function (array $m) use ($keep): string {
                    $url = ($this->imageResolver)(html_entity_decode($m[2], ENT_QUOTES | ENT_HTML5, 'UTF-8'));

                    return $url === null
                        ? $m[0]
                        : $keep(sprintf('<img src="%s" alt="%s" loading="lazy">', self::escape($url), $m[1]));
                },
                $html,
            ) ?? $html;
        }
        $html = preg_replace_callback(
            '/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/',
            static fn(array $m): string => $keep(sprintf('<a href="%s" %s>%s</a>', $m[2], self::LINK_ATTRIBUTES, $m[1])),
            $html,
        ) ?? $html;
        $html = preg_replace_callback(
            '/https?:\/\/[^\s<]*[^\s<.,;:!?)]/',
            static fn(array $m): string => $keep(sprintf('<a href="%s" %s>%s</a>', $m[0], self::LINK_ATTRIBUTES, $m[0])),
            $html,
        ) ?? $html;
        $html = preg_replace('/\*\*(?=\S)([^*]*\S)\*\*/', '<strong>$1</strong>', $html) ?? $html;
        $html = preg_replace('/(^|[^*\w])\*(?=\S)([^*]*\S)\*(?![*\w])/', '$1<em>$2</em>', $html) ?? $html;
        $html = preg_replace('/~~(?=\S)([^~]*\S)~~/', '<del>$1</del>', $html) ?? $html;
        $html = self::colorSpans($html);

        return preg_replace_callback('/\x00(\d+)\x00/', static fn(array $m): string => $kept[(int) $m[1]], $html) ?? $html;
    }
}
