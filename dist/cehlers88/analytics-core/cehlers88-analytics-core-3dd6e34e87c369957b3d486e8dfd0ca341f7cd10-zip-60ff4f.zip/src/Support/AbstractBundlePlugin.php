<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 07.05.2024
 * Time: 21:46
 */

namespace Cehlers88\AnalyticsCore\Support;

use Cehlers88\AnalyticsCore\Support\DTO\UI\MenuItemDTO;
use Symfony\Component\HttpKernel\Bundle\Bundle;

abstract class AbstractBundlePlugin extends Bundle implements BundlePluginInterface
{
    abstract public function getDescription(): string;

    abstract public function getVersion(): string;

    /**
     * @return MenuItemDTO[]
     */
    public function getMenuItems(): array
    {
        return [];
    }

    public function getPermissions(): array
    {
        return [];
    }

    public function handleInstall(): array
    {
        return [];
    }

    public function handleUpdate(string $previousVersion): array
    {
        return [];
    }

    public function getTrackingBufferKeys(): array
    {
        return [];
    }

    /**
     * An illustration that stands for the bundle - the bundle cards of the settings show it,
     * as the tool tiles show theirs. By default Resources/teaser.svg of the bundle; an SVG of
     * 320 x 160 whose ids are unique across the page (several bundles are shown at once).
     *
     * @return string|null the SVG markup, null when the bundle has none
     */
    public function getTeaserSvg(): ?string
    {
        $file = $this->getPath() . '/Resources/teaser.svg';
        if (!is_file($file)) {
            return null;
        }
        $svg = file_get_contents($file);

        return $svg === false || trim($svg) === '' ? null : $svg;
    }
}