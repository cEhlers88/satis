<?php

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;

class EndpointDefinitionDTO
{
    public string $name;

    /** @var string[] */
    public array $methods = [];

    /** @var PropertyDTO[] */
    public array $parameters = [];

    public static function create(string $name, array $methods, array $parameters = []): EndpointDefinitionDTO
    {
        $dto = new self();
        $dto->name = $name;
        $dto->methods = $methods;
        $dto->parameters = $parameters;

        return $dto;
    }
}