<?php

namespace Cehlers88\AnalyticsCore\Command\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;

class MixedCommandGroupDTO extends DTO
{
    /**
     * @var CommandDTO[]|mixed
     */
    public array $commands = [];

    public static function create(array $commands): MixedCommandGroupDTO
    {
        $dto = new self();
        $dto->commands = $commands;
        return $dto;
    }
}