<?php

namespace Cehlers88\AnalyticsCore\Command\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;

class CommandGroupDTO extends DTO
{
    /**
     * @var CommandDTO[]
     */
    public array $commands = [];

    public static function create(array $commands): CommandGroupDTO
    {
        $dto = new self();
        $dto->commands = $commands;
        return $dto;
    }
}