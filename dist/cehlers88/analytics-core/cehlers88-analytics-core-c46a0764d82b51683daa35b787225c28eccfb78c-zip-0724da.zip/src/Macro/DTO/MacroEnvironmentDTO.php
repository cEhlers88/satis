<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 23.08.2024
 * Time: 23:34
 */

namespace Cehlers88\AnalyticsCore\Macro\DTO;

use Analytics\DTO\ContextNameValueDTO;
use Cehlers88\AnalyticsCore\DTO\DTO;

class MacroEnvironmentDTO extends DTO
{
    public int $applicationId = -1;
    /**
     * @var ContextNameValueDTO[]
     */
    public array $arguments = [];
    /**
     * @var ContextNameValueDTO[]
     */
    public array $variables = [];

    /**
     * @param int $applicationId
     * @param ContextNameValueDTO[] $arguments
     * @param ContextNameValueDTO[] $variables
     * @return MacroEnvironmentDTO
     */
    public static function create(int $applicationId, array $arguments = [], array $variables = []): MacroEnvironmentDTO
    {
        $dto = new self();

        $dto->applicationId = $applicationId;
        $dto->arguments = $arguments;
        $dto->variables = $variables;

        return $dto;
    }
}