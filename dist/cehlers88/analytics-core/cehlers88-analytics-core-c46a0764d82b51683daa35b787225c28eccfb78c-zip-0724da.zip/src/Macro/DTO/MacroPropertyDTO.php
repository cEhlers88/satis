<?php

namespace Cehlers88\AnalyticsCore\Macro\DTO;

use Analytics\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\DTO\DTO;

class MacroPropertyDTO extends DTO
{
    public const TYPE_ARRAY = 'array';
    public const TYPE_BOOLEAN = 'bool';
    public const TYPE_INT = 'int';
    public const TYPE_STRING = 'string';

    public string $description = '';
    public string $name = '';
    public bool $optional = false;
    public array $types = [];
    public mixed $value = null;

    public static function create(
        string       $name,
        string|array $types = MacroPropertyDTO::TYPE_INT,
        string       $description = "",
        mixed        $value = VariablesProvider::UNDEFINED_VAR
    ): MacroPropertyDTO
    {
        $dto = new self();

        $dto->name = $name;
        $dto->description = $description;
        $dto->optional = $value !== VariablesProvider::UNDEFINED_VAR;
        $dto->value = $value;

        if (!is_array($types)) {
            $dto->types = [$types];
        } else {
            $dto->types = $types;
        }

        return $dto;
    }
}