<?php

namespace Cehlers88\AnalyticsCore\Observer\Message;

/** Observer message dispatched when a system update runs/ends */
class SystemUpdateObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'system.update';

    public function __construct(
        public ?\DateTime $startTime = null,
        public ?\DateTime $endTime = null,
        public string     $version = '',
        public string     $message = ''
    )
    {
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}