<?php

namespace Cehlers88\AnalyticsCore\Tests\Configuration\DTO;

use Cehlers88\AnalyticsCore\Configuration\DTO\UserInputActionDTO;
use PHPUnit\Framework\TestCase;

class UserInputActionDTOTest extends TestCase
{
    public function testCreateSetValueSetsActionAndItemProperties(): void
    {
        $dto = UserInputActionDTO::createSetValue('my_key', 'my_value');

        $this->assertSame(UserInputActionDTO::ACTION_SET_VALUE, $dto->action);
        $this->assertSame('my_key', $dto->configurationItemDTO->key);
        $this->assertSame('my_value', $dto->configurationItemDTO->defaultValue);
        $this->assertNull($dto->position);
    }

    public function testCreateAddItemWithoutPosition(): void
    {
        $dto = UserInputActionDTO::createAddItem('items', ['label' => 'New item']);

        $this->assertSame(UserInputActionDTO::ACTION_ADD_ITEM, $dto->action);
        $this->assertSame('items', $dto->configurationItemDTO->key);
        $this->assertSame(['label' => 'New item'], $dto->configurationItemDTO->defaultValue);
        $this->assertNull($dto->position);
    }

    public function testCreateAddItemWithPosition(): void
    {
        $dto = UserInputActionDTO::createAddItem('items', null, 2);

        $this->assertSame(UserInputActionDTO::ACTION_ADD_ITEM, $dto->action);
        $this->assertSame('items', $dto->configurationItemDTO->key);
        $this->assertSame(2, $dto->position);
    }

    public function testCreateAddItemAtFirstPosition(): void
    {
        $dto = UserInputActionDTO::createAddItem('items', 'val', 0);

        $this->assertSame(0, $dto->position);
    }

    public function testCreateRemoveItemWithoutPosition(): void
    {
        $dto = UserInputActionDTO::createRemoveItem('items');

        $this->assertSame(UserInputActionDTO::ACTION_REMOVE_ITEM, $dto->action);
        $this->assertSame('items', $dto->configurationItemDTO->key);
        $this->assertNull($dto->position);
    }

    public function testCreateRemoveItemWithPosition(): void
    {
        $dto = UserInputActionDTO::createRemoveItem('items', 3);

        $this->assertSame(UserInputActionDTO::ACTION_REMOVE_ITEM, $dto->action);
        $this->assertSame('items', $dto->configurationItemDTO->key);
        $this->assertSame(3, $dto->position);
    }

    public function testActionConstants(): void
    {
        $this->assertSame('set_value', UserInputActionDTO::ACTION_SET_VALUE);
        $this->assertSame('add_item', UserInputActionDTO::ACTION_ADD_ITEM);
        $this->assertSame('remove_item', UserInputActionDTO::ACTION_REMOVE_ITEM);
    }

    public function testConfigurationUpdateDTOIsBackwardCompatible(): void
    {
        $legacyDto = \Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationUpdateDTO::createSetValue('key', 'val');

        $this->assertInstanceOf(UserInputActionDTO::class, $legacyDto);
        $this->assertSame(UserInputActionDTO::ACTION_SET_VALUE, $legacyDto->action);
    }
}
