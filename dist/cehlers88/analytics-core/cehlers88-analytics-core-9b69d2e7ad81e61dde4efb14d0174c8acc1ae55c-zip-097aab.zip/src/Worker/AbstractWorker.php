<?php

namespace Cehlers88\AnalyticsCore\Worker;

use Analytics\Abstract\AbstractPropertyHolder;
use Analytics\DTO\PropertyDTO;
use Analytics\ENUM\eMacroVariableContext;
use Analytics\ENUM\eWorkerJobType;
use Analytics\Player\MacroPlayer;
use Analytics\Utils\UnitUtils;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Repository\WorkerRepository;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
use Cehlers88\AnalyticsCore\Support\Profiler;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Cehlers88\AnalyticsCore\Worker\Job\JobInterface;

/** Base class for background worker implementations. */
abstract class AbstractWorker extends AbstractPropertyHolder implements WorkerInterface
{
    public array $environment = [];
    protected ?int $entityId = null;
    protected Application $_application;
    protected MacroPlayer $macroPlayer;
    protected bool $_jobsFinished = false;
    protected WorkerRepository $workerRepository;
    protected TrackingBufferRepository $trackingBufferRepository;
    private array $benchmark = [

    ];
    private int $_entityState;
    /**
     * @var $_jobs JobInterface[]
     */
    private array $_jobs = [];
    private float $startTime;
    private bool $_timeoutReached = false;

    private array $warnings = [];
    private array $resultMessages = [];
    private array $_sharedData = [];
    private bool $_wantToReRun = false;

    /**
     * Configure the worker with the given properties.
     *
     * @param array $properties Configuration properties.
     * @return static
     */
    public function configure(array $properties): static
    {
        $this->logInfo('Configuring worker.', true);
        $this->addProperty(PropertyDTO::create('allowed_runtime', -1));

        $this->loadPropertyValues($properties, true);
        return $this;
    }

    public function addResultMessage(string $message): self
    {
        $this->resultMessages[] = $message;
        return $this;
    }

    public function clearResultMessages(): self
    {
        $this->resultMessages = [];
        return $this;
    }

    /**
     * @return array<string>
     */
    public function getRequiredJobs(): array
    {
        return [];
    }

    /**
     * Handle a worker error.
     *
     * @param string $error Error message.
     * @param array $data Additional error data.
     */
    public function handleError(string $error, array $data): void
    {
        $workerEntity = $this->workerRepository->find($this->entityId);
        $workerEntity->setState(eRunningState::FatalError, eRunningState::Error);
        $this->workerRepository->save($workerEntity, true);

        $trackingBuffer = new TrackingBuffer();
        $trackingBuffer
            ->setData([
                'key' => 'Worker.error',
                'error' => $error,
                'data' => $data
            ])
            ->setTimestamp(new \DateTime())
            ->setState(eTrackingBufferState::NEW)
            ->setNote('Unknown error occurred: ' . $error . ' set state to Fatal')
            ->setApplication($workerEntity->getApplication());

        $this->trackingBufferRepository->save($trackingBuffer, true);
    }

    /**
     * Add a job to the worker.
     *
     * @param AbstractWorkerJob $job The job to add.
     * @return AbstractWorker
     */
    public function addJob(AbstractWorkerJob $job): AbstractWorker
    {
        $this->_jobs[] = $job;
        return $this;
    }

    /** Check whether the worker is allowed to run. */
    public function allowRun(): bool
    {
        return $this->_entityState !== eRunningState::Error;
    }

    /** Get the number of registered jobs. */
    public function countJobs(): int
    {
        return count($this->_jobs);
    }

    /**
     * Execute the worker and all registered jobs.
     *
     * @return WorkerResultDTO
     */
    final public function execute(): WorkerResultDTO
    {
        $this->_logger->addTabSpace(3);

        $result = new WorkerResultDTO();

        $this->startTime = microtime(true);
        $this->sharedData = [];

        $this->logInfo(sprintf('<Execution jobs-count=%d start-time="%s">', count($this->_jobs), $this->startTime));
        $this->_logger->addTabSpace(3);

        $result->workerInfos['allowed_runtime'] = $this->getPropertyValue('allowed_runtime');
        $result->workerInfos['environment'] = $this->environment;
        $result->workerInfos['properties'] = $this->getProperties();

        if (!$this->validateProperties() && !$this->hasError()) {
            $this->setError('Invalid properties');
        }

        $workingObjects = [];
        $this->macroPlayer->getMacroEnvironment()->getVariablesStoreProvider()->clearContext(eMacroVariableContext::WORKER);

        if ($this->hasError() === false) {
            $profiler = new Profiler();
            $profiler->start();
            try {
                $workingObjects = $this->getWorkingObjects();
            } catch (\Exception $e) {
                $this->setError($e->getMessage());
            }
            $profiler->stop();

            $this->setBenchmarkValue('fetch_working_objects_duration', $profiler->getReadableDuration());
        }

        if (empty($workingObjects)) {
            $this->logInfo('No working objects found. Skipping working.', true);
        }

        $result->workerInfos['working_objects_count'] = count($workingObjects);

        if (!$this->checkTimeoutReached() && !$this->hasError()) {
            $this->logInfo('Start handle working objects.', true);

            $profiler = new Profiler();
            $profiler->start();
            try {
                $workingObjectResult = $this->handleWorkingObjects($workingObjects);
            } catch (\Exception $e) {
                $this->setError('Error while handle working objects: ' . $e->getMessage());
            }
            $profiler->stop();

            $this->setBenchmarkValue('handle_working_objects_duration', $profiler->getReadableDuration());
        }

        $result->runtime = microtime(true) - $this->startTime;
        $this->logInfo('Finished working after ' . UnitUtils::formatDuration($result->runtime, 's') . '.', true);
        $result->timedOut = $this->reachedTimeout();
        $result->error = [];
        $result->warnings = $this->getWarnings();
        $result->messages = $this->getResultMessages();
        foreach ($this->errors as $error) {
            $result->error[] = $error->message;
        }

        $result->endedAt = (new \DateTime())->getTimestamp();

        //$this->_logger->removeTabSpace(3);
        $this->logInfo(sprintf('</Execution duration="%s" %s>',
            UnitUtils::formatDuration($result->runtime, 's'),
            $this->getBenchmarkAttributes()
        ));

        //$this->_logger->removeTabSpace(3);
        $result->workerInfos[WorkerResultDTO::KEY_BENCHMARK] = $this->getBenchmark();

        return $result;
    }

    /** Get the objects to work on. */
    abstract public function getWorkingObjects(): array;

    /** Set a benchmark value. */
    public function setBenchmarkValue(string $key, mixed $value): static
    {
        $this->benchmark[$key] = $value;
        return $this;
    }

    private function checkTimeoutReached(): bool
    {
        if ($this->_timeoutReached) {
            return true;
        }

        $runtime = microtime(true) - $this->startTime;
        $this->_timeoutReached = $runtime > $this->getPropertyValue('allowed_runtime');

        if ($this->_timeoutReached) {
            $this->logInfo(sprintf('Timeout (max %d) reached. Stop working.', $this->getPropertyValue('allowed_runtime')), true);
        }

        return $this->_timeoutReached;
    }

    /**
     * Process all working objects through registered jobs.
     *
     * @param array $workingObjects The objects to process.
     * @return array
     */
    public function handleWorkingObjects(array $workingObjects): array
    {
        $this->_jobsFinished = false;
        $results = [];

        if (count($workingObjects) === 0) {
            return $results;
        }

        $validJobsCount = 0;
        foreach ($this->_jobs as $job) {
            if ($job->getType() === eWorkerJobType::UNKNOWN) {
                $this->logWarning(sprintf('Job "%s" has type "%s". Jobs with this type will be ignored.', $job->getName(), eWorkerJobType::UNKNOWN->name));
                continue;
            }
            $validJobsCount++;
        }

        if ($validJobsCount === 0) {
            $this->logInfo('No valid jobs found. Skipping working objects.');
            return $results;
        }

        try {
            $jobsResults = $this->handleJobsByType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_START, $workingObjects);
        } catch (\Exception $e) {
            $this->setError('hier, fehler: ' . $e->getMessage());
        }

        if ($this->checkTimeoutReached()) {
            if ($this->handleTimeoutReached('Before start working on each object.') === false) {
                return $results;
            }
        }

        foreach ($workingObjects as $workingObject) {
            if ($this->checkTimeoutReached()) {
                $this->handleTimeoutReached('Timeout reached while working on objects.');
                break;
                /*if ($this->handleTimeoutReached(sprintf('%d of %d objects were handled', $handledObjectsCount, count($workingObjects))) === false) {
                    return $results;
                }*/
            }
            if ($this->handleWorkingObjectStart($workingObject) === false) {
                continue;
            }

            try {
                foreach ($this->handleJobsByType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION, $workingObject) as $handleResult) {
                    $jobsResults[] = $handleResult;
                }
            } catch (\Exception $e) {
                $this->setError($e->getMessage());
            }
            if ($this->checkTimeoutReached()) {
                $this->handleTimeoutReached('Timeout reached while working on objects.');
                break;
            }
            $this->handleWorkingObjectEnd($workingObject, $jobsResults);
        }

        if ($this->checkTimeoutReached()) {
            $this->handleTimeoutReached(sprintf('Timeout (max %d) reached after working on all objects but before finishing. Stop worker.', $this->getPropertyValue('allowed_runtime')));
        } else {
            $this->handleJobsByType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_END, $workingObjects);
        }
        $this->logInfo('Jobs finished.', true);

        $this->checkTimeoutReached();
        $this->onJobsComplete();

        return $results;
    }

    public function logWarning(string $message, bool $onlyInDebugMode = false): static
    {
        $this->warnings[] = $message;
        return parent::logWarning($message, $onlyInDebugMode);
    }

    /** Get the worker name. */
    public function getName(): string
    {
        return static::class;
    }

    private function handleJobsByType(eWorkerJobType $type, mixed $workingData): array
    {
        $jobsResults = [];
        foreach ($this->_jobs as $job) {
            if ($this->checkTimeoutReached()) {
                $this->handleTimeoutReached(sprintf('Timeout (max %d) reached. Stop working on jobs.', $this->getPropertyValue('allowed_runtime')));
                return $jobsResults;
            }
            if ($job->getType() !== $type) {
                continue;
            }

            $this->macroPlayer->getMacroEnvironment()->getVariablesStoreProvider()->clearContext(eMacroVariableContext::JOB);
            $job
                ->setWorker($this)
                ->setLogger($this->_logger)
                ->setMacroProvider($this->macroPlayer);

            if (is_array($workingData)) {
                $job->setWorkingObjects($workingData);
            } else {
                $job->setWorkingObject($workingData);
            }

            try {
                $job->setMaxRuntime($this->getPropertyValue('allowed_runtime') - (microtime(true) - $this->startTime));
                $runResult = $job->run();
                $jobsResults[] = $runResult;
            } catch (\Exception $e) {
                $this->setError($e->getMessage());
                return $jobsResults;
            }
            if ($job->hasError()) {
                $this->setError($job->getError());
                return $jobsResults;
            }
        }
        return $jobsResults;
    }

    /**
     * Handle timeout reached.
     *
     * @param string $logMessage The log message to log.
     * @return bool Return true if the worker should continue working.
     */
    protected function handleTimeoutReached(string $logMessage): bool
    {
        $this->logWarning(sprintf('Timeout (%d max) reached. ', $this->getPropertyValue('allowed_runtime')) . $logMessage);
        return false;
    }

    /**
     * Called before processing a single working object.
     *
     * @param mixed $workingObject The object about to be processed.
     * @return bool False to skip this object.
     */
    public function handleWorkingObjectStart(mixed $workingObject): bool
    {
        return true;
    }

    /**
     * Called after processing a single working object.
     *
     * @param mixed $workingObject The object that was processed.
     * @param array $jobResults Results from the jobs that ran.
     */
    public function handleWorkingObjectEnd(mixed $workingObject, array $jobResults): void
    {
    }

    /** Called when all jobs have completed. */
    protected function onJobsComplete(): void
    {
        $this->_jobsFinished = true;
    }

    /** Check whether the worker reached its timeout. */
    public function reachedTimeout(): bool
    {
        return $this->_timeoutReached;
    }

    public function getWarnings(): array
    {
        return $this->warnings;
    }

    public function getResultMessages(): array
    {
        return $this->resultMessages;
    }

    private function getBenchmarkAttributes(): string
    {
        $result = '';
        foreach ($this->benchmark as $key => $value) {
            $result .= sprintf('%s="%s" ', $key, $value);
        }
        return $result;
    }

    /** Get all benchmark data. */
    public function getBenchmark(): array
    {
        return $this->benchmark;
    }

    public function hasWarnings(): bool
    {
        return count($this->warnings) > 0;
    }

    /**
     * Build an initial WorkerResultDTO for the given working objects.
     *
     * @param array $workingObjects The objects to work on.
     * @return WorkerResultDTO
     */
    public function buildWorkerResultPrototype(array $workingObjects): WorkerResultDTO
    {
        $result = new WorkerResultDTO();
        $result->workerInfos['working_objects_count'] = count($workingObjects);

        return $result;
    }

    /** Get the application ID. */
    public function getApplicationId(): int
    {
        return $this->_application->getId();
    }

    /** Get the worker version. */
    public function getVersion(): string
    {
        return '0.0.1';
    }

    /**
     * Initialize the worker from a Worker entity.
     *
     * @param Worker $workerEntity The worker entity.
     * @param LoggerInterface|null $logger Optional logger instance.
     * @param bool $debugMode Whether to enable debug mode.
     * @return AbstractWorker
     */
    public function init(Worker $workerEntity, ?LoggerInterface $logger = null, bool $debugMode = false): AbstractWorker
    {
        $this->logInfo(sprintf('Initializing worker "%s" (id=%d)', $workerEntity->getName(), $workerEntity->getId()), true);
        $this->entityId = $workerEntity->getId();
        $this->enableDebugMode($debugMode);
        $this->_application = $workerEntity->getApplication();
        $this->_entityState = $workerEntity->getStateValue();

        if ($logger !== null) {
            $this->setLogger($logger);
        }

        return $this;
    }

    /** Set the macro player instance. */
    public function setMacroPlayer(MacroPlayer $macroPlayer): AbstractWorker
    {
        $this->macroPlayer = $macroPlayer;
        return $this;
    }

    /** Get all registered jobs. */
    public function getJobs(): array
    {
        return $this->_jobs;
    }

    public function setTrackingBufferRepository(TrackingBufferRepository $trackingBufferRepository): static
    {
        $this->trackingBufferRepository = $trackingBufferRepository;
        return $this;
    }

    public function setWorkerRepository(WorkerRepository $workerRepository): AbstractWorker
    {
        $this->workerRepository = $workerRepository;
        return $this;
    }

    public function getJobByClassName(string $className): ?JobInterface
    {
        foreach ($this->_jobs as $job) {
            if ($job instanceof $className) {
                return $job;
            }
        }
        return null;
    }

    /**
     * Retrieve a value from the temporary shared data store.
     *
     * @param string $key The key to retrieve.
     * @param mixed $default Default value when the key does not exist.
     * @return mixed
     */
    public function getSharedData(string $key, mixed $default = null): mixed
    {
        if (array_key_exists($key, $this->_sharedData)) {
            return $this->_sharedData[$key];
        }

        return $default;
    }

    /**
     * Store a value in the temporary shared data store for the duration of the worker run.
     *
     * @param string $key The key to store the value under.
     * @param mixed $value The value to store.
     * @return static
     */
    public function setSharedData(string $key, mixed $value): static
    {
        $this->_sharedData[$key] = $value;
        return $this;
    }

    /**
     * Check whether the temporary shared data store contains the given key.
     *
     * @param string $key The key to check.
     * @return bool
     */
    public function hasSharedData(string $key): bool
    {
        return array_key_exists($key, $this->_sharedData);
    }

    /**
     * Remove a single entry from the temporary shared data store.
     *
     * @param string $key The key to remove.
     * @return static
     */
    public function removeSharedData(string $key): static
    {
        unset($this->_sharedData[$key]);
        return $this;
    }

    /**
     * Clear the entire temporary shared data store.
     *
     * @return static
     */
    public function clearSharedData(): static
    {
        $this->_sharedData = [];
        return $this;
    }

    public function wantToReRun(): bool
    {
        return $this->_wantToReRun;
    }

    public function setWantToReRun(bool $wantToReRun): static
    {
        $this->_wantToReRun = $wantToReRun;
        return $this;
    }
}