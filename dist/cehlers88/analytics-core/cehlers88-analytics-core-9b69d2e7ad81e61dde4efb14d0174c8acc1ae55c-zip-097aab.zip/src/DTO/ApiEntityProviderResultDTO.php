<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;

class ApiEntityProviderResultDTO extends DTO
{
    /** @var ErrorDTO[] */
    public array $errors = [];

    public int $limit = -1;

    public int $offset = -1;

    /** @var EntityInterface|EntityInterface[]|null $results */
    public mixed $results = null;

    public int $total = -1;

    public static function createFromError(ErrorDTO|string $error): self
    {
        $result = new self();

        if (is_string($error)) {
            $error = ErrorDTO::create($error);
        }
        $result->errors[] = $error;

        return $result;
    }

    /**
     * @param EntityInterface|EntityInterface[]|null $results
     */
    public static function create(
        mixed $results,
        int   $limit = -1,
        int   $offset = -1,
        int   $total = -1
    ): self
    {
        $result = new self();
        $result->results = $results;
        $result->limit = $limit;
        $result->offset = $offset;
        $result->total = $total;

        return $result;
    }

    public function getPage(): int
    {
        return (int)ceil($this->offset / $this->limit);
    }
}