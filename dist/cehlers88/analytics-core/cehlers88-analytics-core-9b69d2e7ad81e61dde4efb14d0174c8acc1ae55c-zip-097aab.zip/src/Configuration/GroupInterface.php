<?php

namespace Cehlers88\AnalyticsCore\Configuration;

use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\Configuration\DTO\UserInputActionDTO;
use Cehlers88\AnalyticsCore\DTO\ValidationResultDTO;

interface GroupInterface
{
    /**
     * @return ConfigurationItemDTO[]
     */
    public function getItems(): array;

    public function getGroupTitle(): string;

    public function getGroupDescription(): string;

    public function getKey(): string;

    public function getViewContext(): string;

    public function isPersistable(): bool;

    public function needApplication(): bool;

    /**
     * Handle a user input event and return a list of frontend actions to execute.
     *
     * @return UserInputActionDTO[]
     */
    public function handleUserInput(
        string $key,
        mixed  $newValue,
        mixed  $oldValue
    ): array;

    public function validate(ConfigurationItemDTO $configurationItem, mixed $value): ValidationResultDTO;
}