<?php

namespace Cehlers88\AnalyticsCore\Configuration\DTO;

/**
 * @deprecated Use UserInputActionDTO instead.
 */
class ConfigurationUpdateDTO extends UserInputActionDTO
{
}