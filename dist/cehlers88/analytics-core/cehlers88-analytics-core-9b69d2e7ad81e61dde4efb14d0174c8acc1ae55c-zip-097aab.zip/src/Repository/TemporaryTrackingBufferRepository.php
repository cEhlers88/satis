<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\TemporaryTrackingBuffer;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;

/**
 * Repository for TemporaryTrackingBuffer entities.
 *
 * @extends ServiceEntityRepository<TemporaryTrackingBuffer>
 *
 * @method TemporaryTrackingBuffer|null find($id, $lockMode = null, $lockVersion = null)
 * @method TemporaryTrackingBuffer|null findOneBy(array $criteria, array $orderBy = null)
 * @method TemporaryTrackingBuffer[]    findAll()
 * @method TemporaryTrackingBuffer[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class TemporaryTrackingBufferRepository extends TrackingBufferRepository
{

}
