<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Support\ConverterUtils;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\Index;

#[ORM\Entity(repositoryClass: TrackingBufferRepository::class)]
#[Index(name: 'created_at_idx', columns: ['created_at'])]
#[Index(name: 'modified_at_idx', columns: ['modified_at'])]
#[Index(name: 'updated_at_idx', columns: ['updated_at'])]
#[Index(name: 'key_value_idx', columns: ['key_value'])]
#[Index(name: 'timestamp_idx', columns: ['timestamp'])]
#[Index(name: 'timestamp_time_idx', columns: ['timestamp_time'])]
#[Index(name: 'handled_at_time_idx', columns: ['handled_at_time'])]
#[Index(name: 'filters_idx', columns: ['filters'])]
class TrackingBuffer extends AbstractTrackingBuffer
{
    public const string KEY_CAPTURE_ENDPOINT = 'CAPTURE_ENDPOINT';
    public const string KEY_SERVICE_ENDPOINT = 'SERVICE_ENDPOINT';
}
