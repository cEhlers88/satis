<?php

namespace Cehlers88\AnalyticsCore\ENUM\State;

/**
 * Represents the possible states of a tracking buffer.
 */
enum eTrackingBufferState: int
{
    case NEW = 0;
    case IN_PROGRESS = 1;

    case PROCESSED_NOT_FINISHED = 2;
    case PROCESSED_FINISHED = 4;
    case INTERACTION_REQUIRED = 8;

    case IGNORED = 32;
    case NORMALIZED = 256;

    case CHILD_PROCESS_STARTED = 512;
    case CHILD_PROCESSES_FINISHED = 1024;
    case CHILD_PROCESS_WAITING = 2048;
    case CHILD_PROCESS_FAILED = 4096;

    case ERROR = 8192;
}