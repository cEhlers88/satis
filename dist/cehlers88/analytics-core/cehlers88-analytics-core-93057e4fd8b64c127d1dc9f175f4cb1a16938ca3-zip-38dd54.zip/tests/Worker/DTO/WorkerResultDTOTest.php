<?php

namespace Cehlers88\AnalyticsCore\Tests\Worker\DTO;

use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use PHPUnit\Framework\TestCase;

class WorkerResultDTOTest extends TestCase
{
    public function testNewInstanceSetsStartedAt(): void
    {
        $dto = new WorkerResultDTO();

        $this->assertNotNull($dto->startedAt);
        $this->assertGreaterThan(0, $dto->startedAt);
    }

    public function testDefaultValues(): void
    {
        $dto = new WorkerResultDTO();

        $this->assertNull($dto->error);
        $this->assertSame(-1, $dto->endedAt);
        $this->assertSame(0.0, $dto->runtime);
        $this->assertFalse($dto->timedOut);
        $this->assertSame([], $dto->jobResults);
        $this->assertSame([], $dto->workerInfos);
    }

    public function testSerializeAndCreateFromString(): void
    {
        $dto = new WorkerResultDTO();
        $dto->error = ['Test error'];
        $dto->endedAt = 1700000000;
        $dto->runtime = 1.5;
        $dto->timedOut = true;
        $dto->jobResults = ['job1' => 'done'];
        $dto->workerInfos = ['info' => 'data'];

        $serialized = $dto->serialize();
        $restored = WorkerResultDTO::createFromString($serialized);

        $this->assertSame('Test error', $restored->error[0]);
        $this->assertSame(1700000000, $restored->endedAt);
        $this->assertSame(1.5, $restored->runtime);
        $this->assertTrue($restored->timedOut);
        $this->assertSame(['job1' => 'done'], $restored->jobResults);
        $this->assertSame(['info' => 'data'], $restored->workerInfos);
    }

    public function testCreateFromStringWithEmptyString(): void
    {
        $dto = WorkerResultDTO::createFromString('');

        $this->assertNull($dto->startedAt);
    }

    public function testCreateFromException(): void
    {
        $exception = new \RuntimeException('Something failed');
        $dto = WorkerResultDTO::createFromException($exception);

        $this->assertSame('Something failed', $dto->error[0]);
        $this->assertNotNull($dto->endedAt);
        $this->assertGreaterThan(0, $dto->endedAt);
    }

    public function testToStringReturnsJsonString(): void
    {
        $dto = new WorkerResultDTO();
        $dto->error = null;

        $string = (string)$dto;

        $this->assertJson($string);
        $decoded = json_decode($string, true);
        $this->assertArrayHasKey('error', $decoded);
        $this->assertArrayHasKey('startedAt', $decoded);
        $this->assertArrayHasKey('endedAt', $decoded);
        $this->assertArrayHasKey('runtime', $decoded);
        $this->assertArrayHasKey('timedOut', $decoded);
        $this->assertArrayHasKey('jobResults', $decoded);
        $this->assertArrayHasKey('workerInfos', $decoded);
    }
}
