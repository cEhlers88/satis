<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 31.08.2024
 * Time: 09:20
 */

namespace Cehlers88\AnalyticsCore\Process\Runner;

use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\ProcedureRepository;
use Cehlers88\AnalyticsCore\Repository\UserRepository;
use Cehlers88\AnalyticsCore\Security\Doorman;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;

/**
 * Process runner that plays commands - or the commands of a procedure - with the command player.
 *
 * Picked up by the process chain (run:processes, a run chain with "handleProcesses") once the
 * process is "WillStart", e.g. after a restart on /dashboard/processes. The runner arguments
 * are the ones the app stores for asynchronous runs and asynchronous settings:
 * commands | procedureId, applicationId, executorName, runAsUserId, arguments, attributes.
 * Older processes of the command console kept the commands in start_info.runnerArguments.
 *
 * A failure is thrown on: ProcessProvider::runProcess() ends the process in the error state
 * and keeps the message in details.errors.
 */
class CommandsPlayerProcessRunner extends AbstractProcessRunner
{
    public const ARGUMENT_COMMANDS = 'commands';
    public const ARGUMENT_PROCEDURE = 'procedureId';
    public const ARGUMENT_APPLICATION = 'applicationId';
    public const ARGUMENT_EXECUTOR = 'executorName';
    public const ARGUMENT_RUN_AS_USER = 'runAsUserId';
    public const ARGUMENT_ARGUMENTS = 'arguments';
    public const ARGUMENT_ATTRIBUTES = 'attributes';

    /**
     * The services are optional: ProcessProvider takes the runner from the container, the
     * process runner console command still creates it with `new` - then handle() reports
     * that it cannot run instead of failing on a missing service.
     */
    public function __construct(
        private readonly ?MacroEnvironment      $macroEnvironment = null,
        private readonly ?ApplicationRepository $applicationRepository = null,
        private readonly ?ProcedureRepository   $procedureRepository = null,
        private readonly ?UserRepository        $userRepository = null,
        private readonly ?TokenStorageInterface $tokenStorage = null,
        private readonly ?Doorman               $doorman = null,
    )
    {
    }

    public function handle(): void
    {
        // started already - by this chain run or by a request working it off itself
        if ($this->process->hasState(eRunningState::Running) || !$this->process->hasState(eRunningState::WillStart)) {
            return;
        }

        if ($this->macroEnvironment === null) {
            throw new \RuntimeException('Der Runner wurde ohne MacroEnvironment erzeugt und kann keine Commands ausführen');
        }

        $commands = $this->resolveCommands();

        $this->process
            ->setState(eRunningState::Running)
            ->setStartedAt(new \DateTime())
            ->setFinishedAt(null);
        // visible as running while the commands run, and no other chain run starts it again
        if (isset($this->processRepository)) {
            $this->processRepository->save($this->process);
        }

        $runAsUserId = $this->getArgument(self::ARGUMENT_RUN_AS_USER);
        $previousToken = $this->tokenStorage?->getToken();
        $previousDoormanUser = $this->doorman?->getUser();
        $variables = $this->macroEnvironment->getVariablesStoreProvider();
        $attributes = (array)($this->getArgument(self::ARGUMENT_ATTRIBUTES) ?? []);
        $bufferLevel = ob_get_level();

        try {
            if ($runAsUserId !== null) {
                $this->runAs((int)$runAsUserId);
            }
            $this->prepareEnvironment();

            foreach ((array)($this->getArgument(self::ARGUMENT_ARGUMENTS) ?? []) as $name => $value) {
                $variables->setArgument((string)$name, $value);
            }
            foreach ($attributes as $name => $value) {
                $variables->setVariable((string)$name, $value, eMacroVariableContext::JOB);
            }

            ob_start();
            try {
                $result = $this->macroEnvironment->getCommandPlayer()->run($commands);
            } catch (\Throwable $exception) {
                throw new \RuntimeException(sprintf('Commands sind fehlgeschlagen: %s', $exception->getMessage()), 0, $exception);
            }
            $output = (string)ob_get_clean();
        } finally {
            while (ob_get_level() > $bufferLevel) {
                ob_end_clean();
            }
            foreach (array_keys($attributes) as $name) {
                $variables->removeVariable((string)$name, eMacroVariableContext::JOB);
            }
            if ($runAsUserId !== null) {
                $this->tokenStorage?->setToken($previousToken);
                $this->doorman?->setUser($previousDoormanUser);
            }
        }

        $details = $this->process->getDetails() ?? [];
        $details['result'] = [
            'runner' => self::storable($result),
            'output' => $output,
        ];
        $this->process->setDetails($details);

        if ($this->process->getResultWorkerDefinition() !== null) {
            // ProcessProvider::finishProcess() hands the result to the result worker
            $this->process->setState(eRunningState::ResultReceived, eRunningState::Finishing);
            return;
        }

        $this->process
            ->setState(eRunningState::Finished)
            ->setFinishedAt(new \DateTime());
    }

    public function getProcessResult(): mixed
    {
        return $this->process?->getDetails()['result']['runner'] ?? null;
    }

    /** @return array|string the command definition to play */
    private function resolveCommands(): array|string
    {
        $commands = $this->getArgument(self::ARGUMENT_COMMANDS)
            ?? ($this->process->getStartInfo('runnerArguments')[self::ARGUMENT_COMMANDS] ?? null);

        if ($commands === null && $this->getArgument(self::ARGUMENT_PROCEDURE) !== null) {
            $procedureId = (int)$this->getArgument(self::ARGUMENT_PROCEDURE);
            $procedure = $this->procedureRepository?->find($procedureId);
            if ($procedure === null) {
                throw new \RuntimeException(sprintf('Prozedur #%d existiert nicht mehr', $procedureId));
            }
            $commands = $procedure->getContent();
        }

        if (is_string($commands)) {
            $decoded = json_decode($commands, true);
            $commands = is_array($decoded) ? $decoded : $commands;
        }
        if ($commands === null || $commands === [] || $commands === '') {
            throw new \RuntimeException('Der Prozess enthält keine Commands zum Ausführen');
        }

        return $commands;
    }

    private function prepareEnvironment(): void
    {
        $this->macroEnvironment->setExecutorInfos(
            (string)($this->getArgument(self::ARGUMENT_EXECUTOR) ?? $this->process->getName()),
            '',
            (string)$this->process->getId()
        );

        $applicationId = $this->getArgument(self::ARGUMENT_APPLICATION);
        if ($applicationId !== null) {
            $application = $this->applicationRepository?->find((int)$applicationId);
            if ($application === null) {
                throw new \RuntimeException(sprintf('Anwendung #%d existiert nicht mehr', (int)$applicationId));
            }
            $this->macroEnvironment->setApplication($application);
        }

        // the environment outlives the run in a long-running worker
        $this->macroEnvironment->getVariablesStoreProvider()->clearContext(eMacroVariableContext::JOB);
    }

    private function runAs(int $userId): void
    {
        $user = $this->userRepository?->find($userId);
        if (!$user instanceof User) {
            throw new \RuntimeException(sprintf('Benutzer #%d existiert nicht mehr', $userId));
        }

        $this->tokenStorage?->setToken(new UsernamePasswordToken($user, 'api', $user->getRoles()));
        $this->doorman?->setUser($user);
    }

    /** The details of a process are a JSON column - what does not fit is named only. */
    private static function storable(mixed $result): mixed
    {
        try {
            json_encode($result, JSON_THROW_ON_ERROR);

            return $result;
        } catch (\JsonException) {
            return get_debug_type($result);
        }
    }
}
