<?php

namespace Cehlers88\AnalyticsCore\Support\MonitoringRule;

use Cehlers88\AnalyticsCore\Player\CommandPlayer;

class RangeCheckMonitoringRule extends AbstractMonitoringRule
{
    private bool $reachedMin = false;

    private bool $reachedMax = false;

    public function __construct(
        private CommandPlayer $player
    )
    {
    }

    public function execute(): self
    {
        $commands = [];
        if ($this->reachedMin()) {
            $this->reachedMin = true;
            $commands = $this->_arguments['onMin'] ?? [];
        } else if ($this->reachedMax()) {
            $this->reachedMax = true;
            $commands = $this->_arguments['onMax'] ?? [];
        }

        if (!empty($commands)) {
            $this->player->run($commands);
        }

        return $this;
    }

    private function reachedMin(): bool
    {
        return $this->_attributeToCheck->getValue() <= $this->_arguments['min'];
    }

    private function reachedMax(): bool
    {
        return $this->_attributeToCheck->getValue() >= $this->_arguments['max'];
    }

    public function getStatisticDetails(): array
    {
        return [
            'reachedMin' => $this->reachedMin() ? 1 : 0,
            'reachedMax' => $this->reachedMax() ? 1 : 0,
        ];
    }

    public function validateArguments(array $arguments): bool
    {
        $requiredArguments = ['min', 'max'];
        return count(array_diff_key($arguments, array_flip($requiredArguments))) === 0;
    }
}