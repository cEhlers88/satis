<?php

namespace Cehlers88\AnalyticsCore\Support\MonitoringRule;

use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;

abstract class AbstractMonitoringRule implements MonitoringRuleInterface
{
    protected CustomEntityAttribute $_attributeToCheck;
    protected array $_arguments = [];

    public abstract function validateArguments(array $arguments): bool;

    public function setArguments(array $arguments): self
    {
        if (!$this->validateArguments($arguments)) {
            throw new \InvalidArgumentException('Invalid arguments');
        }

        $this->_arguments = $arguments;
        return $this;
    }

    public function setAttributeToCheck(CustomEntityAttribute $attribute): self
    {
        $this->_attributeToCheck = $attribute;
        return $this;
    }

    public function getStatisticDetails(): array
    {
        return [];
    }


    public function getName(): string
    {
        return $this->_arguments['name'] ?? '';
    }

    public function preventStatisticCreation(): bool
    {
        return false;
    }
}