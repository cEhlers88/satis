<?php

namespace Cehlers88\AnalyticsCore\Support\MonitoringRule;

use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;

interface MonitoringRuleInterface
{
    public function setArguments(array $arguments): self;

    public function setAttributeToCheck(CustomEntityAttribute $attribute): self;

    public function execute(): self;

    public function getStatisticDetails(): array;

    public function preventStatisticCreation(): bool;
}