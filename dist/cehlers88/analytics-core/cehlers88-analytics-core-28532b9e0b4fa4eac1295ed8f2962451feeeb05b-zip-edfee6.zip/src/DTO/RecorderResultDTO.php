<?php

namespace Cehlers88\AnalyticsCore\DTO;

class RecorderResultDTO extends ResultDTO
{
    private function __construct()
    {
    }

    public static function createError(string $message, int $number = -1, array $errorData = []): RecorderResultDTO
    {
        $result = new RecorderResultDTO();
        $result->errors = [ErrorDTO::create(
            $number,
            $message,
            $errorData
        )];
        $result->message = $message;
        return $result;
    }

    public static function createSuccess(array $data, string $message = ''): RecorderResultDTO
    {
        $result = new RecorderResultDTO();
        $result->data = $data;
        $result->message = $message;
        return $result;
    }
}