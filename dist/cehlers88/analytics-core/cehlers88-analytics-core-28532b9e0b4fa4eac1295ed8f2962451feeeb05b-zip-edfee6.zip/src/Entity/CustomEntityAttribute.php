<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\CustomEntityAttributeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CustomEntityAttributeRepository::class)]
/**
 * Entity representing an attribute of a custom entity.
 */
class CustomEntityAttribute
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column]
    private ?int $type = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $value = null;

    #[ORM\ManyToOne(inversedBy: 'attributes')]
    #[ORM\JoinColumn(nullable: false)]
    private ?CustomEntity $customEntity = null;

    /**
     * @var Collection<int, CustomEntityAttributeMonitoring>
     */
    #[ORM\OneToMany(targetEntity: CustomEntityAttributeMonitoring::class, mappedBy: 'attribute')]
    private Collection $monitorings;

    public function __construct()
    {
        $this->monitorings = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getType(): ?int
    {
        return $this->type;
    }

    public function setType(int $type): static
    {
        $this->type = $type;

        return $this;
    }

    public function getValue(): ?string
    {
        return $this->value;
    }

    public function setValue(?string $value): static
    {
        $this->value = $value;

        return $this;
    }

    public function getCustomEntity(): ?CustomEntity
    {
        return $this->customEntity;
    }

    public function setCustomEntity(?CustomEntity $customEntity): static
    {
        $this->customEntity = $customEntity;

        return $this;
    }

    /**
     * @return Collection<int, CustomEntityAttributeMonitoring>
     */
    public function getMonitorings(): Collection
    {
        return $this->monitorings;
    }

    public function addMonitoring(CustomEntityAttributeMonitoring $monitoring): static
    {
        if (!$this->monitorings->contains($monitoring)) {
            $this->monitorings->add($monitoring);
            $monitoring->setAttribute($this);
        }

        return $this;
    }

    public function removeMonitoring(CustomEntityAttributeMonitoring $monitoring): static
    {
        if ($this->monitorings->removeElement($monitoring)) {
            // set the owning side to null (unless already changed)
            if ($monitoring->getAttribute() === $this) {
                $monitoring->setAttribute(null);
            }
        }

        return $this;
    }
}
