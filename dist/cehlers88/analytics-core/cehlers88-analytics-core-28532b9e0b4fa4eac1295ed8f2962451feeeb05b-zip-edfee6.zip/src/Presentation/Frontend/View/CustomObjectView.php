<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;

/** View representation of an Application entity. */
class CustomObjectView implements ViewInterface
{
    public array $monitorings = [];
    public ?string $templatePath = null;

    public function __construct(
        public int    $id,
        public string $className,
        public string $name,
        public array  $attributes,
        public array  $childObjects
    )
    {

    }
}