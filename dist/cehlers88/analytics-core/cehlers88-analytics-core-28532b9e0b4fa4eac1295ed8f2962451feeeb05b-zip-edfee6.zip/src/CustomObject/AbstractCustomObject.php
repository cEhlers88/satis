<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:21
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;

/** Base class for custom object implementations. */
abstract class AbstractCustomObject implements CustomObjectInterface
{
    protected ?CustomEntity $_entity = null;

    /** @var AbstractCustomObject[] */
    protected array $_childObjects = [];
    private int $_id = -1;
    private ?int $_parentId = null;
    private array $_attributes = [];
    private array $_monitorings = [];
    private string $_name = '';
    private ?\DateTimeInterface $_createdAt = null;
    private ?\DateTimeInterface $_updatedAt = null;
    private ?\DateTimeInterface $_modifiedAt = null;

    /** Get the fully qualified class name. */
    public function getClassName(): string
    {
        return get_class($this);
    }

    /**
     * @param string $name Attribute name.
     * @param mixed $defaultValue Value returned when attribute is not set.
     * @return mixed
     */
    public function getAttribute(string $name, mixed $defaultValue = null): mixed
    {
        return $this->_attributes[$name] ?? $defaultValue;
    }

    public function hasAttribute(string $name): bool
    {
        return isset($this->_attributes[$name]);
    }

    public function getAttributeTemplates(): array
    {
        return [];
    }

    public function load(CustomEntity $customEntity): static
    {
        $this->_attributes = [];
        $this->_entity = $customEntity;
        $this->_id = $customEntity->getId();
        $this->_name = $customEntity->getName();
        $this->_parentId = $customEntity->getParentId();

        $this->_createdAt = $customEntity->getCreatedAt();
        $this->_updatedAt = $customEntity->getUpdatedAt();
        $this->_modifiedAt = $customEntity->getModifiedAt();
        $this->_childObjects = [];
        $this->_monitorings = [];

        foreach ($customEntity->getAttributes() as $attribute) {
            $this->setAttribute($attribute->getName(), $attribute->getValue());
        }

        return $this;
    }

    /** Get the object ID. */
    public function getId(): int
    {
        return $this->_id;
    }

    /** Get the object name. */
    public function getName(): string
    {
        return $this->_name;
    }

    /** Set the object name. */
    public function setName(string $name): static
    {
        $this->_name = $name;
        return $this;
    }

    public function getParentId(): ?int
    {
        return $this->_parentId;
    }

    public function setParentId(?int $parentId): static
    {
        $this->_parentId = $parentId;
        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->_createdAt;
    }

    public function setCreatedAt(?\DateTimeInterface $createdAt): static
    {
        $this->_createdAt = $createdAt;
        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->_updatedAt;
    }

    public function setUpdatedAt(?\DateTimeInterface $updatedAt): static
    {
        $this->_updatedAt = $updatedAt;
        return $this;
    }

    public function getModifiedAt(): ?\DateTimeInterface
    {
        return $this->_modifiedAt;
    }

    public function setModifiedAt(?\DateTimeInterface $modifiedAt): static
    {
        $this->_modifiedAt = $modifiedAt;
        return $this;
    }

    /** Get all attributes. */
    public function getAttributes(): array
    {
        return $this->_attributes;
    }

    public function setAttributes(array $attributes): static
    {
        $this->_attributes = $attributes;
        return $this;
    }

    /**
     * @param string $name Attribute name.
     * @param mixed $value Attribute value.
     */
    public function setAttribute(string $name, mixed $value): static
    {
        $this->_attributes[$name] = $value;
        return $this;
    }

    public function getMonitorings(): array
    {
        return $this->_monitorings;
    }

    public function setMonitorings(array $monitorings): static
    {
        $this->_monitorings = $monitorings;
        return $this;
    }

    public function removeAttribute(string $name): static
    {
        unset($this->_attributes[$name]);
        return $this;
    }

    public function getChildObjects(): array
    {
        return $this->_childObjects;
    }

    public function setChildObjects(array $childObjects): static
    {
        $this->_childObjects = $childObjects;
        return $this;
    }

    public function getTileTemplate(): ?string
    {
        return null;
    }

    public function getTileDetails(): array
    {
        return [];
    }
}