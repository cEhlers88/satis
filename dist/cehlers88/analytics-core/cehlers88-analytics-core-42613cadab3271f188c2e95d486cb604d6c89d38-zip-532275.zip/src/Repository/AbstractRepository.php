<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;

abstract class AbstractRepository extends ServiceEntityRepository
{
    private array $idBlacklist = [];

    public function getIdBlacklist(): array
    {
        return $this->idBlacklist;
    }

    public function addIdToBlacklist(int $id): static
    {
        $this->idBlacklist[] = $id;
        return $this;
    }

    public function removeIdFromBlacklist(int $id): static
    {
        $key = array_search($id, $this->idBlacklist);
        if ($key !== false) {
            unset($this->idBlacklist[$key]);
        }
        return $this;
    }

    public function clearIdBlacklist(): void
    {
        $this->idBlacklist = [];
    }

    protected function createPrefilteredQueryBuilder(string $alias): \Doctrine\ORM\QueryBuilder
    {
        $queryBuilder = $this->createQueryBuilder($alias);

        if (!empty($this->idBlacklist)) {
            $queryBuilder
                ->andWhere($alias . '.id NOT IN (:blacklist)')
                ->setParameter('blacklist', $this->idBlacklist);
        }

        return $queryBuilder;
    }
}