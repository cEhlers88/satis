<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectInterface;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<CustomEntity>
 */
class CustomEntityRepository extends ServiceEntityRepository
{
    public function __construct(
        private EntityManagerInterface $_em,
        ManagerRegistry                $registry
    )
    {
        parent::__construct($registry, CustomEntity::class);
    }

    public function save(CustomEntity $customEntity): CustomEntityRepository
    {
        $this->_em->persist($customEntity);
        $this->_em->flush();
        return $this;
    }

    /**
     * @param string $class
     * @return CustomEntity[]
     */
    public function findAllByClass(string $class): array
    {
        return $this->findBy(['className' => $class]);
    }

    /**
     * @param string $class
     * @param string $attributeName
     * @param string $attributeValue
     * @return CustomObjectInterface[]
     */
    public function findByByClassAndAttribute(string $class, string $attributeName, string $attributeValue): array
    {
        $entities = $this->createQueryBuilder('e')
            ->select('DISTINCT e')
            ->innerJoin('e.attributes', 'a')
            ->andWhere('e.class = :class')
            ->andWhere('a.name = :name')
            ->andWhere('a.value = :value')
            ->setParameter('class', $class)
            ->setParameter('name', $attributeName)
            ->setParameter('value', $attributeValue)
            ->getQuery()
            ->getResult();
        $result = [];
        /** @var CustomEntity $entity */
        foreach ($entities as $entity) {
            $result[] = $entity->getCustomObject();
        }
        return $result;
    }
}
