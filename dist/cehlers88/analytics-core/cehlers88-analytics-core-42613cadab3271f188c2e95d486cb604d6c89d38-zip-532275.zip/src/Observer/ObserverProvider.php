<?php

namespace Cehlers88\AnalyticsCore\Observer;

use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;

class ObserverProvider
{
    /**
     * @param iterable<ObserverInterface> $observers
     */
    public function __construct(
        private iterable $observers
    )
    {

    }

    public function dispatch(ObserverMessageInterface $message): void
    {
        foreach ($this->observers as $observer) {
            if ($observer->canHandle($message)) {
                $observer->handle($message);
            }
        }
    }
}