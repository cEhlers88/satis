<?php

namespace Cehlers88\AnalyticsCore\Worker;

use Analytics\Abstract\AbstractPropertyHolder;
use Analytics\ENUM\eMacroVariableContext;
use Analytics\ENUM\eWorkerJobType;
use Analytics\Player\MacroPlayer;
use Analytics\Utils\Profiler;
use Analytics\Utils\UnitUtils;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;

abstract class AbstractWorker extends AbstractPropertyHolder implements WorkerInterface
{
    protected ?int $entityId = null;
    protected Application $_application;
    protected MacroPlayer $macroPlayer;
    protected bool $_jobsFinished = false;
    private array $benchmark = [

    ];
    private int $_entityState;
    private int $allowedRuntimeInSeconds = -1;
    /**
     * @var $_jobs AbstractWorkerJob[]
     */
    private array $_jobs = [];
    private float $startTime;
    private bool $_timeoutReached = false;

    public function configure(array $properties): static
    {
        return $this;
    }

    /**
     * @return array<string>
     */
    public function getRequiredJobs(): array
    {
        return [];
    }

    public function handleError(string $error, array $data): void
    {
    }

    public function addJob(AbstractWorkerJob $job): AbstractWorker
    {
        $this->_jobs[] = $job;
        return $this;
    }

    public function allowRun(): bool
    {
        return $this->_entityState !== eRunningState::Error;
    }

    public function countJobs(): int
    {
        return count($this->_jobs);
    }

    final public function execute(): WorkerResultDTO
    {
        $this->_logger->addTabSpace(3);

        $result = new WorkerResultDTO();

        $this->startTime = microtime(true);

        $this->logInfo(sprintf('<Execution jobs-count=%d start-time="%s">.', count($this->_jobs), $this->startTime));
        $this->_logger->addTabSpace(3);

        $result->workerInfos['start_properties'] = $this->propertyLoads;

        if (!$this->validateProperties()) {
            $this->setError('Invalid properties');
        }

        $workingObjects = [];
        $this->macroPlayer->getMacroEnvironment()->getVariablesStoreProvider()->clearContext(eMacroVariableContext::WORKER);

        if ($this->hasError() === false) {
            $profiledFetchWorkingObjectsResult = Profiler::runWithProfiler([$this, 'getWorkingObjects']);
            $this->setBenchmarkValue('fetch_working_objects_duration', $profiledFetchWorkingObjectsResult['profiler']->getReadableRuntime());

            if ($profiledFetchWorkingObjectsResult['hasError']) {
                $this->setError('Error while get working objects: ' . $profiledFetchWorkingObjectsResult['error']);
            } else {
                $workingObjects = $profiledFetchWorkingObjectsResult['result'];
            }
        }

        if ($this->hasError() === false) {
            try {
                $result = $this->buildWorkerResultPrototype($workingObjects);
            } catch (\Exception $e) {
                $this->setError('Error while build worker result dummy: ' . $e->getMessage());
            }
        }

        if (!$this->checkTimeoutReached() && !$this->hasError()) {
            $this->logInfo('Start handle working objects.', true);
            $profiledHandleWorkingObjectsResult = Profiler::runWithProfiler(fn() => $this->handleWorkingObjects($workingObjects));
            $this->setBenchmarkValue('handle_working_objects_duration', $profiledHandleWorkingObjectsResult['profiler']->getReadableRuntime());

            if ($profiledHandleWorkingObjectsResult['hasError']) {
                $this->setError('Error while handle working objects: ' . $profiledHandleWorkingObjectsResult['error']);
            }
        }
        $result->runtime = microtime(true) - $this->startTime;
        $this->logInfo('Finished working after ' . UnitUtils::formatDuration($result->runtime, 's') . '.', true);
        $result->timedOut = $this->reachedTimeout();
        $result->error = $this->getErrorsAsString();
        $result->endedAt = (new \DateTime())->getTimestamp();

        $this->_logger->removeTabSpace(3);
        $this->logInfo(sprintf('</Execution duration="%s" %s>',
            UnitUtils::formatDuration($result->runtime, 's'),
            $this->getBenchmarkAttributes()
        ));

        $this->logInfo('return to provider', true);
        $this->_logger->removeTabSpace(3);
        $result->workerInfos[WorkerResultDTO::KEY_BENCHMARK] = $this->getBenchmark();

        return $result;
    }

    public function setBenchmarkValue(string $key, mixed $value): static
    {
        $this->benchmark[$key] = $value;
        return $this;
    }

    public function buildWorkerResultPrototype(array $workingObjects): WorkerResultDTO
    {
        $result = new WorkerResultDTO();
        $result->workerInfos['working_objects_count'] = count($workingObjects);

        return $result;
    }

    private function checkTimeoutReached(): bool
    {
        if ($this->_timeoutReached) {
            return true;
        }

        $runtime = microtime(true) - $this->startTime;
        $this->_timeoutReached = $this->allowedRuntimeInSeconds > 0 && $runtime > $this->allowedRuntimeInSeconds;

        $this->logInfo(
            sprintf('Timeout check: %s',
                ($this->_timeoutReached ? 'reached' : 'not reached, rest: ' . UnitUtils::formatDuration($this->allowedRuntimeInSeconds - $runtime, 's'))
            ),
            true
        );

        return $this->_timeoutReached;
    }

    public function handleWorkingObjects(array $workingObjects): array
    {
        $this->_jobsFinished = false;
        $results = [];

        if (count($workingObjects) === 0) {
            return $results;
        }

        $validJobsCount = 0;
        foreach ($this->_jobs as $job) {
            if ($job->getType() === eWorkerJobType::UNKNOWN) {
                $this->logInfo('Warning: Job of type "UNKNOWN" found. Jobs with type "UNKNOWN" are ignored.');
                continue;
            }
            $validJobsCount++;
        }

        if ($validJobsCount === 0) {
            $this->logInfo('No valid jobs found. Skipping working objects.');
            return $results;
        }

        try {
            $jobsResults = $this->handleJobsByType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_START, $workingObjects);
        } catch (\Exception $e) {
            $this->logError($e->getMessage());
        }

        if ($this->checkTimeoutReached()) {
            if ($this->handleTimeoutReached('Before start working on each object.') === false) {
                return $results;
            }
        }

        foreach ($workingObjects as $workingObject) {
            if ($this->checkTimeoutReached()) {
                break;
                /*if ($this->handleTimeoutReached(sprintf('%d of %d objects were handled', $handledObjectsCount, count($workingObjects))) === false) {
                    return $results;
                }*/
            }
            if ($this->handleWorkingObjectStart($workingObject) === false) {
                continue;
            }

            try {
                foreach ($this->handleJobsByType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION, $workingObject) as $handleResult) {
                    $jobsResults[] = $handleResult;
                }
            } catch (\Exception $e) {
                $this->setError($e->getMessage());
            }
            if ($this->checkTimeoutReached()) {
                break;
            }
            $this->handleWorkingObjectEnd($workingObject, $jobsResults);
        }

        if ($this->checkTimeoutReached()) {
            $this->logInfo(sprintf('Timeout (max %d) reached after working on all objects but before finishing. Stop worker.', $this->allowedRuntimeInSeconds));
        } else {
            $this->handleJobsByType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_END, $workingObjects);
        }
        $this->logInfo('Jobs finished.', true);

        $this->checkTimeoutReached();
        $this->onJobsComplete();

        return $results;
    }

    private function handleJobsByType(eWorkerJobType $type, mixed $workingData): array
    {
        $jobsResults = [];
        foreach ($this->_jobs as $job) {
            if ($this->checkTimeoutReached()) {
                $this->logInfo(sprintf('Timeout (max %d) reached. Stop working on jobs.', $this->allowedRuntimeInSeconds));
                return $jobsResults;
            }
            if ($job->getType() !== $type) {
                continue;
            }

            $this->macroPlayer->getMacroEnvironment()->getVariablesStoreProvider()->clearContext(eMacroVariableContext::JOB);
            $job->setLogger($this->_logger);
            $job->setMacroProvider($this->macroPlayer);

            if (is_array($workingData)) {
                $job->setWorkingObjects($workingData);
            } else {
                $job->setWorkingObject($workingData);
            }

            try {
                $job->setMaxRuntime($this->allowedRuntimeInSeconds - (microtime(true) - $this->startTime));
                $runResult = $job->run();
                $jobsResults[] = $runResult;
            } catch (\Exception $e) {
                $this->setError($e->getMessage());
                return $jobsResults;
            }
            if ($job->hasError()) {
                $this->setError($job->getError());
                return $jobsResults;
            }
        }
        return $jobsResults;
    }

    /**
     * Handle timeout reached.
     *
     * @param string $logMessage The log message to log.
     * @return bool Return true if the worker should continue working.
     */
    protected function handleTimeoutReached(string $logMessage): bool
    {
        $this->logInfo(sprintf('Timeout (%d max) reached. ', $this->allowedRuntimeInSeconds) . $logMessage);
        return false;
    }

    public function handleWorkingObjectStart(mixed $workingObject): bool
    {
        return true;
    }

    public function handleWorkingObjectEnd(mixed $workingObject, array $jobResults): void
    {
    }

    protected function onJobsComplete(): void
    {
        $this->_jobsFinished = true;
    }

    public function reachedTimeout(): bool
    {
        return $this->_timeoutReached;
    }

    private function getBenchmarkAttributes(): string
    {
        $result = '';
        foreach ($this->benchmark as $key => $value) {
            $result .= sprintf('%s="%s" ', $key, $value);
        }
        return $result;
    }

    public function getBenchmark(): array
    {
        return $this->benchmark;
    }

    abstract public function getWorkingObjects(): array;

    public function getName(): string
    {
        return static::class;
    }

    public function getApplicationId(): int
    {
        return $this->_application->getId();
    }

    public function getVersion(): string
    {
        return '0.0.1';
    }

    public function init(Worker $workerEntity, ?LoggerInterface $logger = null, bool $debugMode = false): AbstractWorker
    {
        $this->entityId = $workerEntity->getId();
        $this->enableDebugMode($debugMode);
        $this->_application = $workerEntity->getApplication();
        $this->_entityState = $workerEntity->getStateValue();
        $this->allowedRuntimeInSeconds = $workerEntity->getMaxRuntime();

        if ($logger !== null) {
            $this->setLogger($logger);
        }

        return $this;
    }

    public function setMacroPlayer(MacroPlayer $macroPlayer): AbstractWorker
    {
        $this->macroPlayer = $macroPlayer;
        return $this;
    }

    public function getJobs(): array
    {
        return $this->_jobs;
    }
}