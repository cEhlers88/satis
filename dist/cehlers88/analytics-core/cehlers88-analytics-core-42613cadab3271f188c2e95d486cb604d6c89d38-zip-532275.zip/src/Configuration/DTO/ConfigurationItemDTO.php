<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.01.26
 * Time: 07:18
 */

namespace Cehlers88\AnalyticsCore\Configuration\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;

class ConfigurationItemDTO extends DTO
{

    public string $key = '';
    public string $label = '';
    public bool $deletable = false;
    public string $description = '';
    public array $children = [];
    public \Closure $condition;
    public bool $extendable = false;
    public string $helpText = '';
    public eInputType $inputType = eInputType::TEXT_SINGLE_LINE;
    public mixed $defaultValue = null;
    public bool $readOnly = false;
    public bool $needApplication = false;

    private function __construct()
    {
        $this->condition = function () {
            return true;
        };
    }

    public static function createRepeat(
        string $key,
        string $label = '',
        array  $children = [],
        string $description = ''
    ): ConfigurationItemDTO
    {
        $dto = self::create($key, $label, eInputType::REPEAT, null, $description);
        $dto->children = $children;
        $dto->extendable = true;
        return $dto;
    }

    public static function create(
        string     $key,
        string     $label = '',
        eInputType $inputType = eInputType::TEXT_SINGLE_LINE,
        mixed      $defaultValue = null,
        string     $description = '',
    ): ConfigurationItemDTO
    {
        $instance = new self();
        $instance->key = $key;
        $instance->inputType = $inputType;
        $instance->label = $label ?? $key;
        $instance->description = $description;
        $instance->defaultValue = $defaultValue;

        return $instance;
    }

    public static function createSelect(
        string $key,
        array  $options,
        string $label = '',
        mixed  $defaultValue = null,
        string $description = ''
    ): ConfigurationItemDTO
    {
        $dto = self::create($key, $label, eInputType::SELECT, $defaultValue, $description);
        $dto->children = $options;
        return $dto;
    }
}