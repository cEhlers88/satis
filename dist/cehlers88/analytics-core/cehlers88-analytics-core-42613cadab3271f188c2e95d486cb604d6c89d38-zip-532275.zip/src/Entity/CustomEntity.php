<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectInterface;
use Cehlers88\AnalyticsCore\Repository\CustomEntityRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CustomEntityRepository::class)]
class CustomEntity extends AbstractEntity
{
    #[ORM\Column(length: 255)]
    private ?string $className = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    /**
     * @var Collection<int, CustomEntityAttribute>
     */
    #[ORM\OneToMany(targetEntity: CustomEntityAttribute::class, mappedBy: 'customEntity', orphanRemoval: true)]
    private Collection $attributes;

    public function __construct()
    {
        parent::__construct();
        $this->attributes = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getClassName(): ?string
    {
        return $this->className;
    }

    public function setClassName(string $className): static
    {
        $this->className = $className;

        return $this;
    }

    /**
     * @return Collection<int, CustomEntityAttribute>
     */
    public function getAttributes(): Collection
    {
        return $this->attributes;
    }

    public function addAttribute(CustomEntityAttribute $attribute): static
    {
        if (!$this->attributes->contains($attribute)) {
            $this->attributes->add($attribute);
            $attribute->setCustomEntity($this);
        }

        return $this;
    }

    public function removeAttribute(CustomEntityAttribute $attribute): static
    {
        if ($this->attributes->removeElement($attribute)) {
            // set the owning side to null (unless already changed)
            if ($attribute->getCustomEntity() === $this) {
                $attribute->setCustomEntity(null);
            }
        }

        return $this;
    }

    public function getCustomObject(bool $loadAttributes = true): CustomObjectInterface
    {
        /** @var CustomObjectInterface $resultObject */
        $resultObject = new $this->className();

        if (!$loadAttributes) {
            return $resultObject;
        }

        foreach ($this->attributes as $attribute) {
            $resultObject->setAttribute($attribute->getName(), $attribute->getValue());
        }
        return $resultObject;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }
}
