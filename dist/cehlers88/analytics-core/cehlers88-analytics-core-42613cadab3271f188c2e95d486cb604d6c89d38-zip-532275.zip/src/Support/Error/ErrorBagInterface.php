<?php

namespace Cehlers88\AnalyticsCore\Support\Error;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;

interface ErrorBagInterface
{
    /**
     * Enable or disable debug mode.
     * @param bool $enable
     * @return static
     */
    public function enableDebugMode(bool $enable): static;

    public function getErrorsAsString(): string;

    public function getLogger(): LoggerInterface;

    public function setLogger(LoggerInterface $logger): static;

    public function hasError(): bool;

    public function setError(string $message, int $code = -1, array $data = []): ErrorDTO;

    public function logInfo(string $message, bool $onlyInDebugMode = false): static;

    public function logWarning(string $message, bool $onlyInDebugMode = false): static;

    public function logError(string $message, bool $onlyInDebugMode = false): static;
}