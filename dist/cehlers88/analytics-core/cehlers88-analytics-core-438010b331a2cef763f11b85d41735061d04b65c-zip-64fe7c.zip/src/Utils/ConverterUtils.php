<?php

namespace Cehlers88\AnalyticsCore\Utils;

use BackedEnum;

class ConverterUtils
{
    /**
     * @param array<int|BackedEnum> $states
     */
    public static function arrayToBitmask(array $states): int
    {
        $mask = 0;

        foreach ($states as $state) {
            if ($state instanceof BackedEnum) {
                $mask |= $state->value;
            } else {
                $mask |= (int)$state;
            }
        }

        return $mask;
    }

    public static function associativeArrayToString(array $array): string
    {
        $result = "";
        foreach ($array as $key => $value) {
            if ($result !== "") {
                $result .= ",";
            }
            if (is_array($value)) {
                $value = self::associativeArrayToString($value);
            }
            $result .= $key . ":" . $value;
        }
        return $result;
    }
}