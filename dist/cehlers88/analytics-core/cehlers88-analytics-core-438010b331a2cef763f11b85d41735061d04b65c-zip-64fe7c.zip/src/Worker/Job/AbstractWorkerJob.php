<?php

namespace Cehlers88\AnalyticsCore\Worker\Job;

use Analytics\ENUM\eWorkerJobType;
use Analytics\Player\MacroPlayer;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;

abstract class AbstractWorkerJob implements JobInterface
{
    public eWorkerJobType $type = eWorkerJobType::UNKNOWN;
    protected LoggerInterface $_logger;
    protected array $_requiredKeys = [];
    protected bool $_handleMultipleObjects = false;
    protected MacroPlayer $_macroProvider;
    private float $_startTime = 0;
    private array $_commands = [];
    private array $_jobResults = [];
    private mixed $_workingObjects;
    private float $_maxRuntime = -1;
    private ?\Throwable $error = null;
    private bool $_hasOpenFormatedLog = false;

    public function getError(): ?\Throwable
    {
        return $this->error;
    }

    public function hasError(): bool
    {
        return $this->error !== null;
    }

    public function run(): array
    {
        $this->_startTime = microtime(true);
        $this->startJob();
        $this->_handleJobCommands();
        $this->_handleWorkingObjects();
        $this->finishJob();

        return $this->_jobResults;
    }

    protected function startJob(): void
    {

    }

    private function _handleJobCommands(): void
    {
        if (count($this->_commands) === 0) {
            return;
        }
        foreach ($this->_commands as $command) {
            $this->_macroProvider->executeMacro($command[0], $command[1]);
        }
        $this->_macroProvider->getMacroEnvironment()->getVariablesStoreProvider()->save();
    }

    private function _handleWorkingObjects(): void
    {
        foreach ($this->_workingObjects as $workingObject) {
            if ($this->_maxRuntime > 0 && microtime(true) - $this->_startTime > $this->_maxRuntime) {
                $this->logInfo('Max runtime reached. Stopping job.');
                break;
            }

            if (!$this->willHandle($workingObject)) {
                continue;
            }

            try {
                $this->workOnObject($workingObject);
            } catch (\Throwable $e) {
                $this->error = $e;
                break;
            }
        }
    }

    public function logInfo($message): AbstractWorkerJob
    {
        if (!$this->_hasOpenFormatedLog) {
            $this->_logger->info(sprintf('<Job name="%s">', $this->getName()));
            $this->_logger->addTabSpace(3);
            $this->_hasOpenFormatedLog = true;
        }

        $this->_logger->info($message);
        return $this;
    }

    public function getName(): string
    {
        return static::class;
    }

    protected function willHandle(object $workingObject): bool
    {
        return true;
    }

    public function workOnObject(object $object): AbstractWorkerJob
    {
        return $this;
    }

    protected function finishJob(): void
    {
        if ($this->_hasOpenFormatedLog) {
            $this->_logger->removeTabSpace(3);
            $this->logInfo('</Job>');
        }
    }

    public function setWorkingObject(mixed $workingObject): AbstractWorkerJob
    {
        return $this->setWorkingObjects([$workingObject]);
    }

    public function getDescription(): string
    {
        return '';
    }

    public function getHandleMultipleObjects(): bool
    {
        return $this->_handleMultipleObjects;
    }

    public function getType(): eWorkerJobType
    {
        return $this->type;
    }

    public function setType(eWorkerJobType $type): AbstractWorkerJob
    {
        $this->type = $type;
        return $this;
    }

    public function getWorkingObject(): mixed
    {
        return $this->_workingObjects[0];
    }

    public function getWorkingObjects(): mixed
    {
        return $this->_workingObjects;
    }

    public function setWorkingObjects(mixed $workingObjects): AbstractWorkerJob
    {

        if (count($this->_requiredKeys) === 0 || !($workingObjects instanceof TrackingBuffer)) {
            $this->_workingObjects = $workingObjects;
            return $this;
        }

        $this->_workingObjects = [];

        /** @var TrackingBuffer $workingObject */
        foreach ($workingObjects as $workingObject) {
            if (in_array($workingObject->getData()['key'], $this->_requiredKeys)) {
                $this->_workingObjects[] = $workingObject;
            }
        }

        return $this;
    }

    public function setLogger(LoggerInterface $logger): AbstractWorkerJob
    {
        $this->_logger = $logger;
        return $this;
    }

    public function setMacroProvider(MacroPlayer $macroProvider): AbstractWorkerJob
    {
        $this->_macroProvider = $macroProvider;
        return $this;
    }

    public function setMaxRuntime(float $maxRuntime): AbstractWorkerJob
    {
        $this->_maxRuntime = $maxRuntime;
        return $this;
    }

    protected function addCommand(string $command, array $arguments = []): AbstractWorkerJob
    {
        $this->_commands[] = [$command, $arguments];
        return $this;
    }

    protected function addJobResult(mixed $result): AbstractWorkerJob
    {
        $this->_jobResults[] = $result;
        return $this;
    }

}