<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Process\DTO\StartInfoDTO;
use Cehlers88\AnalyticsCore\Process\ProcessProvider;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Process>
 */
class ProcessRepository extends ServiceEntityRepository
{
    private bool $ignoreDisabled = true;

    public function __construct(
        ManagerRegistry                $registry,
        private EntityManagerInterface $_em
    )
    {
        parent::__construct($registry, Process::class);
    }

    public function createNew(string $name, string $description, string $runnerClass, array $runnerArguments = [], ?\DateTime $startedAt = null): Process
    {
        $process = new Process();
        $state = is_null($startedAt) ? eRunningState::New : eRunningState::Running;

        if (is_null($startedAt)) {
            $startedAt = date_create('01.01.1970 00:00:00');
        }

        $process
            ->setCreatedAt(new \DateTime())
            ->setName($name)
            ->setDescription($description)
            ->setState($state)
            ->setStartedAt($startedAt)
            ->setDetails([ProcessProvider::KEY_START_INFO => StartInfoDTO::create($runnerClass, $runnerArguments)->toArray()]);

        return $process;
    }

    public function findByStates(array $states, string $mode = 'or', array $stateBlacklist = []): array
    {
        $mode = strtolower($mode);

        $mask = 0;
        foreach ($states as $state) {
            $mask |= $state instanceof eRunningState ? $state->value : (int)$state;
        }

        $blacklistMask = 0;
        foreach ($stateBlacklist as $state) {
            $blacklistMask |= $state instanceof eRunningState ? $state->value : (int)$state;
        }

        $qb = $this->createQueryBuilder('p');

        if ($mask !== 0) {
            if ($mode === 'and') {
                $qb->andWhere('BIT_AND(p.state, :mask) = :mask');
            } else {
                $qb->andWhere('BIT_AND(p.state, :mask) <> 0');
            }
            $qb->setParameter('mask', $mask);
        }

        if ($this->ignoreDisabled) {
            $qb->andWhere('p.enabled = 1');
        }

        if ($blacklistMask !== 0) {
            $qb->andWhere('BIT_AND(p.state, :blacklistMask) = 0');
            $qb->setParameter('blacklistMask', $blacklistMask);
        }

        if ($mask === 0 && $blacklistMask === 0) {
            $qb->orderBy('p.sort', 'DESC');
            return $qb->getQuery()->getResult();
        }

        $qb->orderBy('p.sort', 'DESC');

        return $qb->getQuery()->getResult();
    }


    public function findAll(): array
    {
        $where = [];
        if ($this->ignoreDisabled) {
            $where['enabled'] = true;
        }
        return parent::findBy($where, ['sort' => 'DESC']);
    }

    public function findBy(array $criteria, array|null $orderBy = null, int|null $limit = null, int|null $offset = null): array
    {
        if (is_null($orderBy)) {
            $orderBy = [];
        }
        $orderBy['sort'] = 'DESC';

        return parent::findBy($criteria, $orderBy, $limit, $offset);
    }

    public function removeByStateAndOlderThan(eRunningState $state, string $olderThan): void
    {
        $qb = $this->_em->createQueryBuilder();
        $qb->delete(Process::class, 'p')
            ->where('p.state = :state')
            ->andWhere('p.startedAt < :olderThan')
            ->setParameter('state', $state)
            ->setParameter('olderThan', $olderThan);
        if ($this->ignoreDisabled) {
            $qb->andWhere('p.enabled = 1');
        }
        $qb
            ->getQuery()
            ->execute();
    }

    public function save(Process $process): Process
    {
        $this->_em->persist($process);
        $this->_em->flush();
        return $process;
    }

    public function setIgnoreDisabled(bool $ignoreDisabled): static
    {
        $this->ignoreDisabled = $ignoreDisabled;
        return $this;

    }
}
