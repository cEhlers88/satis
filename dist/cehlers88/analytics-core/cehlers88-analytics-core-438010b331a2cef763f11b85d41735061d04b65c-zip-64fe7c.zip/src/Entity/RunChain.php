<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Repository\RunChainRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: RunChainRepository::class)]
class RunChain extends AbstractEntity
{
    /**
     * @var Collection<int, Worker>
     */
    #[ORM\ManyToMany(targetEntity: Worker::class, mappedBy: 'runChains')]
    private Collection $workers;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $startedAt = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $finishedAt = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $description = null;

    #[ORM\Column]
    private ?int $status = null;

    #[ORM\Column]
    private array $options = [];

    #[ORM\Column(length: 255)]
    private ?string $color = null;

    #[ORM\Column]
    private ?int $maxRuntime = null;

    #[ORM\OneToOne(cascade: ['persist', 'remove'])]
    private ?Statistics $statistics = null;

    public function __construct()
    {
        parent::__construct();
        $this->workers = new ArrayCollection();
    }

    /**
     * @return Collection<int, Worker>
     */
    public function getWorkers(): Collection
    {
        return $this->workers;
    }

    public function addWorker(Worker $worker): static
    {
        if (!$this->workers->contains($worker)) {
            $this->workers->add($worker);
            $worker->addRunChain($this);
        }

        return $this;
    }

    public function removeWorker(Worker $worker): static
    {
        if ($this->workers->removeElement($worker)) {
            $worker->removeRunChain($this);
        }

        return $this;
    }

    public function getStartedAt(): ?\DateTimeInterface
    {
        return $this->startedAt;
    }

    public function setStartedAt(?\DateTimeInterface $startedAt): static
    {
        $this->startedAt = $startedAt;

        return $this;
    }

    public function getFinishedAt(): ?\DateTimeInterface
    {
        return $this->finishedAt;
    }

    public function setFinishedAt(?\DateTimeInterface $finishedAt): static
    {
        $this->finishedAt = $finishedAt;

        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getStatus(): ?array
    {
        $value = $this->status ?? eRunningState::Unknown->value;

        if ($value === eRunningState::Unknown->value) {
            return [eRunningState::Unknown];
        }

        $result = [];

        foreach (eRunningState::cases() as $case) {
            if ($case === eRunningState::Unknown) {
                continue;
            }

            if ($value & $case->value) {
                $result[] = $case;
            }
        }

        return $result;
    }

    public function setStatus(eRunningState ...$status): static
    {
        if ($status === []) {
            $this->status = eRunningState::Unknown->value;
            return $this;
        }

        $value = 0;

        foreach ($status as $statusValue) {
            if ($statusValue === eRunningState::Unknown) {
                continue;
            }

            $value |= $statusValue->value;
        }

        $this->status = $value === 0 ? eRunningState::Unknown->value : $value;

        return $this;
    }

    public function hasStatus(eRunningState $status): bool
    {
        return ($this->getStatusValue() & $status->value) === $status->value;
    }

    public function getStatusValue(): int
    {
        return $this->status ?? eRunningState::Unknown->value;
    }

    public function removeStatus(eRunningState ...$status): static
    {
        $current = $this->getStatusValue();
        foreach ($status as $state) {
            if ($state === eRunningState::Unknown) {
                continue;
            }
            $current &= ~$state->value;
        }
        $this->setStatusValue($current);
        return $this;
    }

    public function setStatusValue(int $value): static
    {
        $this->status = $value;
        return $this;
    }

    public function getOption(string $key, mixed $defaultValue = null): mixed
    {
        return $this->options[$key] ?? $defaultValue;
    }

    public function getOptions(): array
    {
        return $this->options;
    }

    public function setOptions(array $options): static
    {
        $this->options = $options;

        return $this;
    }

    public function getColor(): ?string
    {
        return $this->color;
    }

    public function setColor(string $color): static
    {
        $this->color = $color;

        return $this;
    }

    public function isSelectAble(): bool
    {
        return $this->options['selectable'] ?? true;
    }

    public function getMaxRuntime(): ?int
    {
        return $this->maxRuntime;
    }

    public function setMaxRuntime(int $maxRuntime): static
    {
        $this->maxRuntime = $maxRuntime;

        return $this;
    }

    public function getStatistics(): ?Statistics
    {
        return $this->statistics;
    }

    public function setStatistics(?Statistics $statistics): static
    {
        $this->statistics = $statistics;

        return $this;
    }
}
