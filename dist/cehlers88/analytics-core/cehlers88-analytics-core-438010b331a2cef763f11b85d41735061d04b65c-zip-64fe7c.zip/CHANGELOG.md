# Changelog

## [0.1.3](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.2...v0.1.3) (2026-01-20)


### Miscellaneous Chores

* add release-please.yml ([8438a59](https://github.com/cEhlers88/AnalyticsCore/commit/8438a594eb4f9afcfd600fa0ae51d90e88fb76b6))
