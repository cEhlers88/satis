<?php

namespace Cehlers88\AnalyticsCore\Recorder;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\TemporaryTrackingBuffer;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Observer\Message\TrackingBufferChangedObserverMessage;
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\TemporaryTrackingBufferRepository;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;

class TrackingRecorder
{
    private array $temporaryTrackingBufferKeyWhitelist = [];
    private array $trackingBufferKeyBlacklist = [];

    public function __construct(
        private ApplicationRepository             $applicationRepository,
        private TrackingBufferRepository          $trackingBufferRepository,
        private TemporaryTrackingBufferRepository $temporaryTrackingBufferRepository,
        private ObserverProvider                  $observerProvider
    )
    {
    }

    public function track(
        int|Application $application,
        array           $data,
        bool            $flush = true
    ): TrackingRecorder
    {
        if (is_numeric($application)) {
            $application = $this->applicationRepository->find($application);
        }
        $key = $data['key'] ?? null;

        if (is_null($key) || !in_array($key, $this->trackingBufferKeyBlacklist)) {
            $this->_createTrackingBuffer($application, $data, $flush);
        }

        if (in_array($key, $this->temporaryTrackingBufferKeyWhitelist)) {
            $this->_createTemporaryTrackingBuffer($application, $data, $flush);
        }

        return $this;
    }

    private function _createTrackingBuffer(Application $application, array $data, bool $flush): void
    {
        $trackingBuffer = new TrackingBuffer();
        $trackingBuffer
            ->setState(eTrackingBufferState::NEW)
            ->setApplication($application)
            ->setTimestamp(new \DateTime())
            ->setData($data);

        $this->trackingBufferRepository->save($trackingBuffer, $flush);

        $this->observerProvider->dispatch(new TrackingBufferChangedObserverMessage(
            $application->getId(),
            $trackingBuffer->getId(),
            $trackingBuffer->getState(),
            new \DateTime($trackingBuffer->getTimestamp()),
            $trackingBuffer->getData(),
            'new'
        ));

        /*
        $this->hub->publish(new Update('tracking_buffer_changed', json_encode([
            'applicationId' => $application->getId(),
            'trackingBufferId' => $trackingBuffer->getId(),
            'state' => $trackingBuffer->getState(),
            'timestamp' => $trackingBuffer->getTimestamp()->format('Y-m-d H:i:s'),
            'data' => $trackingBuffer->getData(),
            'reason' => 'new',
        ])));*/
    }

    private function _createTemporaryTrackingBuffer(Application $application, array $data, bool $flush): void
    {
        $trackingBuffer = new TemporaryTrackingBuffer();
        $trackingBuffer
            ->setState(eTrackingBufferState::NEW)
            ->setApplication($application)
            ->setTimestamp(new \DateTime())
            ->setData($data);

        $this->temporaryTrackingBufferRepository->save($trackingBuffer, $flush);
    }
}