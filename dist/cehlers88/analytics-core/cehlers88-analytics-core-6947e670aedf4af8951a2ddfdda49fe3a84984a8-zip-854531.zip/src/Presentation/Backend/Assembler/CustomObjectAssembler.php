<?php

namespace Cehlers88\AnalyticsCore\Presentation\Backend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Assembler\AssembledInterface;
use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectJson;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;

class CustomObjectAssembler extends AbstractAssembler
{
    public function __construct(
        private ClientRepository  $clientRepository,
        private AssemblerProvider $assemblerProvider
    )
    {

    }

    /**
     * @param CustomEntity $entity
     */
    public function assembleJson(EntityInterface|AbstractCustomObject $entity): AssembledInterface
    {
        $attributes = [];

        $entityAttributes = $entity->getAttributes();
        foreach ($entityAttributes as $key => $attribute) {
            $name = is_string($attribute) ? $key : $attribute->getName();
            $value = is_string($attribute) ? $attribute : $attribute->getValue();

            switch ($name) {
                case 'client_id':
                    $attributes[$name] = $value;
                    $client = $this->clientRepository->find($value);
                    if (empty($client)) break;
                    $attributes['client'] = $this->assemblerProvider
                        ->getAssemblerForClass($client::class)
                        ->one($client);
                    break;
                default:
                    $attributes[$name] = $value;
            }
        }

        $assembledCustomObject = new CustomObjectJson(
            $entity->getId(),
            $entity->getClassName(),
            $entity->getName(),
            $attributes,
            method_exists($entity, 'getChildObjects') ? $entity->getChildObjects() : []
        );
        return $assembledCustomObject;
    }

    public function canHandle(string $className): bool
    {
        return $className === CustomEntity::class;
    }
}