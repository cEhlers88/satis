<?php

namespace Cehlers88\AnalyticsCore\Support;

use Cehlers88\AnalyticsCore\Entity\CustomEntityAttributeMonitoring;
use Cehlers88\AnalyticsCore\Entity\Statistics;
use Cehlers88\AnalyticsCore\Repository\CustomEntityAttributeMonitoringRepository;
use Cehlers88\AnalyticsCore\Repository\CustomEntityAttributeRepository;
use Cehlers88\AnalyticsCore\Repository\StatisticsRepository;
use Cehlers88\AnalyticsCore\Support\MonitoringRule\AbstractMonitoringRule;
use Cehlers88\AnalyticsCore\Support\MonitoringRule\MonitoringRuleInterface;

class Monitoring
{
    public function __construct(
        private CustomEntityAttributeMonitoringRepository $customEntityAttributeMonitoringRepository,
        private CustomEntityAttributeRepository           $customEntityAttributeRepository,
        private StatisticsRepository                      $statisticsRepository,
        private iterable                                  $monitoringRules
    )
    {

    }

    public function run(): void
    {
        $monitoringDefs = $this->getRunnableMonitoringEntities();

        foreach ($monitoringDefs as $monitoring) {
            /*$monitoring->setAttribute(
                $this->customEntityAttributeRepository->find($monitoring->getAttribute()->getId())
            );*/

            $ruleHandler = $this->runMonitoringRules($monitoring);

            $statistic = $monitoring->getStatistic();
            if (empty($statistic)) {
                $statistic = new Statistics();
            }

            $statistic->setUpdatedAt(new \DateTime());
            $details = $statistic->getDetails();
            $attributeName = $monitoring->getAttribute()->getName();

            if ($attributeName === 'value') {
                $attributeHolder = $monitoring->getAttribute()->getCustomEntity();
                foreach ($attributeHolder->getAttributes() as $attribute) {
                    if ($attribute->getName() === 'label') {
                        $attributeName = $attribute->getValue();
                    }
                }
            }
            $details["options"] = [
                'monitoredAttribute' => $attributeName,
            ];
            $value = $monitoring->getAttribute()->getValue();
            $details[$attributeName][] = is_numeric($value) ? (float)$value : (is_bool($value) ? ($value ? 1 : 0) : $value);
            $details['timestamp'][] = new \DateTime()->getTimestamp();

            if ($ruleHandler instanceof MonitoringRuleInterface) {
                foreach ($ruleHandler->getStatisticDetails() as $name => $value) {
                    $details[$name][] = $value;
                }
            }
            foreach ($details as $key => $value) {
                while (count($details[$key]) > $monitoring->getMaxLength()) {
                    array_shift($details[$key]);
                }
            }

            $statistic->setDetails($details);

            $monitoring->setStatistic($statistic);
            $monitoring->setLastRun(new \DateTime());
            $this->customEntityAttributeMonitoringRepository->save($monitoring, false);
        }

        $this->customEntityAttributeMonitoringRepository->flush();
    }

    /**
     * @return CustomEntityAttributeMonitoring[]
     */
    private function getRunnableMonitoringEntities(): array
    {
        $result = [];
        $monitoringEntities = $this->customEntityAttributeMonitoringRepository->findAll();

        foreach ($monitoringEntities as $monitoring) {
            if (!$this->_checkMonitoringIsRunnable($monitoring)) continue;

            $result[] = $monitoring;
        }

        return $result;
    }

    private function _checkMonitoringIsRunnable(CustomEntityAttributeMonitoring $monitoring): bool
    {
        $runInterval = $monitoring->getRunInterval();
        if (empty($runInterval)) {
            return false;
        }

        $nextRunAfter = new \DateTimeImmutable()->setTimestamp($monitoring->getLastRun()->getTimestamp());
        if (empty($nextRunAfter)) {
            return true;
        }

        switch ($runInterval) {
            case 'daily_midnight':
                $lastMidnight = new \DateTimeImmutable()->setTime(0, 0, 0);
                if ($nextRunAfter->getTimestamp() < $lastMidnight->getTimestamp()) {
                    return true;
                }
                break;
        }

        $nextRunAfter = $nextRunAfter->add(new \DateInterval($runInterval));
        $nextRunAfter = $nextRunAfter->setTime(
            (int)$nextRunAfter->format('H'),
            (int)$nextRunAfter->format('i'),
            0
        );

        if ($nextRunAfter->getTimestamp() < new \DateTimeImmutable()->getTimestamp()) {
            return true;
        }

        return false;
    }

    public function runMonitoringRules(
        CustomEntityAttributeMonitoring $monitoring
    ): ?MonitoringRuleInterface
    {
        $ruleHandler = $this->_getMonitoringRuleHandler($monitoring->getRuleHandler() ?? '');

        try {
            if (empty($ruleHandler)) {
                return null;
            }

            $ruleHandler
                ->setArguments($monitoring->getRuleArguments() ?? [])
                ->setAttributeToCheck($monitoring->getAttribute())
                ->execute();
        } catch (\Exception $e) {
            $test = 123;
        }

        return $ruleHandler;
    }

    private function _getMonitoringRuleHandler(string $name): ?AbstractMonitoringRule
    {
        foreach ($this->monitoringRules as $monitoringRule) {
            $className = $monitoringRule::class;
            if ($className === $name) {
                return $monitoringRule;
            }

            // remove fqcn from class name
            $className = substr($className, strrpos($className, '\\') + 1);
            if ($className === $name) {
                return $monitoringRule;
            }
        }

        return null;
    }
}