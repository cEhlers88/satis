<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\Exception\LoopLimitExceededException;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\WhileMacro;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Player\MacroPlayer;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use PHPUnit\Framework\TestCase;

class WhileMacroTest extends TestCase
{
    /** @var list<string> the commands that ran, in order */
    private array $ran = [];
    /** @var array<string, mixed> the variables setVar wrote */
    private array $variables = [];
    /** how often "count" ran */
    private int $count = 0;

    public function test_runs_the_commands_as_long_as_the_condition_holds(): void
    {
        // "count" returns how often it ran, "below3" holds while that is below 3
        $result = $this->macro()->execute([
            'condition' => [$this->command('below3')],
            'commands' => [$this->command('count')],
        ]);

        $this->assertSame(['__void' => true], $result['returnValue']);
        $this->assertSame(['below3', 'count', 'below3', 'count', 'below3', 'count', 'below3'], $this->ran);
    }

    public function test_a_condition_that_does_not_hold_at_the_start_runs_nothing(): void
    {
        $result = $this->macro()->execute([
            'condition' => false,
            'commands' => [$this->command('count')],
        ]);

        $this->assertSame(['__void' => true], $result['returnValue']);
        $this->assertSame([], $this->ran);
    }

    public function test_a_condition_group_is_decided_anew_before_every_pass(): void
    {
        $this->macro()->execute([
            'condition' => ['<', [$this->command('counted'), 2]],
            'commands' => [$this->command('count')],
        ]);

        $this->assertSame(2, $this->count);
    }

    public function test_the_counter_variable_holds_the_pass_and_is_removed_afterwards(): void
    {
        $variables = $this->createMock(VariablesProvider::class);
        $variables->method('getVariableValue')->willReturn([]);
        $variables->expects($this->once())->method('removeVariable')->with('i', eMacroVariableContext::JOB);

        $this->macro($variables)->execute([
            'condition' => [$this->command('below3')],
            'commands' => [$this->command('count')],
            'counterVar' => 'i',
        ]);

        $this->assertSame(['i' => 2], $this->variables);
    }

    public function test_a_counter_variable_that_existed_gets_its_value_back(): void
    {
        $variables = $this->createMock(VariablesProvider::class);
        $variables->method('getVariableValue')->willReturn(['i' => 'outer']);
        $variables->expects($this->once())->method('setVariable')->with('i', 'outer', eMacroVariableContext::JOB);
        $variables->expects($this->never())->method('removeVariable');

        $this->macro($variables)->execute([
            'condition' => [$this->command('below3')],
            'commands' => [$this->command('count')],
            'counterVar' => 'i',
        ]);
    }

    public function test_a_condition_that_holds_forever_fails_after_max_iterations(): void
    {
        try {
            $this->macro()->execute([
                'condition' => true,
                'commands' => [$this->command('count')],
                'maxIterations' => '5',
            ]);
            $this->fail('the loop is stopped');
        } catch (LoopLimitExceededException $e) {
            $this->assertStringContainsString('5 passes', $e->getMessage());
        }

        $this->assertSame(5, $this->count);
    }

    public function test_the_limit_is_not_reached_when_the_condition_stops_holding_in_time(): void
    {
        $this->macro()->execute([
            'condition' => [$this->command('below3')],
            'commands' => [$this->command('count')],
            'maxIterations' => 3,
        ]);

        $this->assertSame(3, $this->count);
    }

    public function test_by_default_the_loop_has_no_limit(): void
    {
        $this->macro()->execute([
            'condition' => [$this->command('below1500')],
            'commands' => [$this->command('count')],
        ]);

        $this->assertSame(1500, $this->count);
    }

    public function test_max_iterations_means_no_limit_for_minus_one_and_values_that_are_no_positive_number(): void
    {
        foreach ([0, -1, '-1', '', 'abc', null, 2.5, '0'] as $value) {
            $this->assertSame(WhileMacro::UNLIMITED, WhileMacro::readMaxIterations($value), var_export($value, true));
        }
        $this->assertSame(20, WhileMacro::readMaxIterations(' 20 '));
        $this->assertSame(7, WhileMacro::readMaxIterations(7.0));
    }

    public function test_an_error_in_the_commands_ends_the_loop(): void
    {
        $this->expectExceptionMessage('fail failed');

        $this->macro()->execute([
            'condition' => true,
            'commands' => [$this->command('fail')],
        ]);
    }

    /**
     * A while whose commands write down that they ran: "count" counts and
     * returns the count, "counted" returns it, "below3"/"below1500" hold while it is
     * below 3/1500, "fail" throws.
     */
    private function macro(?VariablesProvider $variables = null): WhileMacro
    {
        $player = $this->createStub(CommandPlayer::class);
        $player->method('run')->willReturnCallback(function (mixed $definition): mixed {
            $command = is_array($definition) ? $definition[0] : $definition;
            $this->ran[] = $command->commandName;

            return match ($command->commandName) {
                'count' => ++$this->count,
                'counted' => $this->count,
                'below3' => $this->count < 3,
                'below1500' => $this->count < 1500,
                'fail' => throw new \RuntimeException('fail failed'),
            };
        });

        $macroPlayer = $this->createStub(MacroPlayer::class);
        $macroPlayer->method('executeMacro')->willReturnCallback(function (string $name, array $arguments): array {
            $this->assertSame('setVar', $name);
            $this->variables[$arguments['name']] = $arguments['value'];

            return ['returnValue' => ['__void' => true]];
        });

        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('getCommandPlayer')->willReturn($player);
        $environment->method('getMacroPlayer')->willReturn($macroPlayer);
        $environment->method('getVariablesStoreProvider')->willReturn($variables ?? $this->createStub(VariablesProvider::class));

        $macro = new WhileMacro();
        $macro->setMacroEnvironment($environment);

        return $macro;
    }

    private function command(string $name): CommandDTO
    {
        $command = new CommandDTO();
        $command->commandName = $name;

        return $command;
    }
}
