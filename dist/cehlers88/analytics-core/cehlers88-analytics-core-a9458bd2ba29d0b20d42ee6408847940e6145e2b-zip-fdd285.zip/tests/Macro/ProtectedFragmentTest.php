<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\AbstractMacro;
use Cehlers88\AnalyticsCore\Macro\Debugger\IMacroDebugger;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use PHPUnit\Framework\TestCase;

class ProtectedFragmentTest extends TestCase
{
    public function test_outside_the_protected_mode_the_fragment_runs(): void
    {
        $macro = $this->createMacro(false);

        $result = $macro->execute();

        $this->assertSame('booked', $result['returnValue']);
        $this->assertSame(['real'], $macro->ran);
    }

    public function test_in_the_protected_mode_the_protected_fragment_runs_instead(): void
    {
        $macro = $this->createMacro(true);

        $result = $macro->execute();

        $this->assertSame('as if booked', $result['returnValue']);
        $this->assertSame(['protected'], $macro->ran);
    }

    public function test_without_a_protected_fragment_nothing_runs(): void
    {
        $macro = $this->createMacro(true);
        $macro->withProtectedFragment = false;

        $result = $macro->execute();

        $this->assertNull($result['returnValue']);
        $this->assertSame([], $macro->ran);
    }

    public function test_the_mode_is_read_on_every_run(): void
    {
        $environment = $this->createMock(MacroEnvironment::class);
        $environment->method('isProtectedMode')->willReturnOnConsecutiveCalls(true, false);
        $environment->method('getDebugger')->willReturn($this->createMock(IMacroDebugger::class));
        $macro = new ProtectedFragmentTestBookMacro();
        $macro->setMacroEnvironment($environment);

        $this->assertSame('as if booked', $macro->execute()['returnValue']);
        $this->assertSame('booked', $macro->execute()['returnValue']);
    }

    private function createMacro(bool $protectedMode): ProtectedFragmentTestBookMacro
    {
        $environment = $this->createMock(MacroEnvironment::class);
        $environment->method('isProtectedMode')->willReturn($protectedMode);
        $environment->method('getDebugger')->willReturn($this->createMock(IMacroDebugger::class));

        $macro = new ProtectedFragmentTestBookMacro();
        $macro->setMacroEnvironment($environment);

        return $macro;
    }
}

class ProtectedFragmentTestBookMacro extends AbstractMacro
{
    public array $ran = [];
    public bool $withProtectedFragment = true;

    public function getName(): string
    {
        return 'testBook';
    }

    protected function run(): ?array
    {
        $result = $this->runProtectedFragment(
            function (): string {
                $this->ran[] = 'real';
                return 'booked';
            },
            $this->withProtectedFragment
                ? function (): string {
                    $this->ran[] = 'protected';
                    return 'as if booked';
                }
                : null
        );

        return $this->_createRunResult($result);
    }
}
