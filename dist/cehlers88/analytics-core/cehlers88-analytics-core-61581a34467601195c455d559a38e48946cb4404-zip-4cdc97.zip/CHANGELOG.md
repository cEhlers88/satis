# Changelog

## [1.21.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.20.0...v1.21.0) (2026-04-26)


### Features

* add `ConfigurationUpdateDTO` and enhance configuration handling ([9788925](https://github.com/cEhlers88/AnalyticsCore/commit/9788925d14641395ae89ef1f2c754740427a9816))


### Miscellaneous Chores

* **deps:** update googleapis/release-please-action action to v5 ([#101](https://github.com/cEhlers88/AnalyticsCore/issues/101)) ([0fff693](https://github.com/cEhlers88/AnalyticsCore/commit/0fff693d913e1c3c1cecf9ce6c7ae6cc76eb70a5))

## [1.20.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.19.0...v1.20.0) (2026-04-21)


### Features

* ensure `setPropertyValue` adds new properties if not existing ([3e7a2f3](https://github.com/cEhlers88/AnalyticsCore/commit/3e7a2f30eed76410743a90bd90b6880cbe85c667))

## [1.19.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.18.2...v1.19.0) (2026-04-21)


### Features

* add `setPropertyValue` method in `Worker` for dynamic property updates ([11a22d3](https://github.com/cEhlers88/AnalyticsCore/commit/11a22d3791137218bddbb11a406ae7fa651e0181))

## [1.18.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.18.1...v1.18.2) (2026-04-20)


### Miscellaneous Chores

* replace `maxRuntime` property in `Worker` with `getMaxRuntime` method ([1809e1e](https://github.com/cEhlers88/AnalyticsCore/commit/1809e1ecdc96da8f20c16de61649982894e3f1ab))

## [1.18.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.18.0...v1.18.1) (2026-04-20)


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.7 ([#84](https://github.com/cEhlers88/AnalyticsCore/issues/84)) ([c8612cf](https://github.com/cEhlers88/AnalyticsCore/commit/c8612cf8350fc091b136fad6f52d7f0ddbbda2c2))

## [1.18.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.17.0...v1.18.0) (2026-04-19)


### Features

* add `FatalError` state in `BadgeProvider` and refine worker store handling ([181957d](https://github.com/cEhlers88/AnalyticsCore/commit/181957d46d067feb771f8e88f1731bf45ca441ba))

## [1.17.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.16.1...v1.17.0) (2026-04-19)


### Features

* introduce new plugins, workers, and DTOs while enhancing process handling ([dbbec2f](https://github.com/cEhlers88/AnalyticsCore/commit/dbbec2f01420cac4eb034b55d6a80687bd93eb6d))

## [1.16.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.16.0...v1.16.1) (2026-04-14)


### Performance Improvements

* add Doctrine index for `TrackingBuffer.timestamp` ([#89](https://github.com/cEhlers88/AnalyticsCore/issues/89)) ([145b18d](https://github.com/cEhlers88/AnalyticsCore/commit/145b18df6e6e8d022560930ca5158a0d6b24fcf3))

## [1.16.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.15.0...v1.16.0) (2026-04-13)


### Features

* Add temporary shared data store to AbstractWorker and WorkerInterface ([#86](https://github.com/cEhlers88/AnalyticsCore/issues/86)) ([97aead1](https://github.com/cEhlers88/AnalyticsCore/commit/97aead1a84960e973d45741016989bfbd9916599))

## [1.15.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.14.0...v1.15.0) (2026-04-12)


### Features

* enhance worker-job interaction and introduce new workers ([3554250](https://github.com/cEhlers88/AnalyticsCore/commit/3554250f310bc9dab047d0112136d6c784338af6))

## [1.14.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.13.0...v1.14.0) (2026-04-11)


### Features

* add `getKeyValue` method in `TrackingBuffer` for key-value retrieval ([4352fc9](https://github.com/cEhlers88/AnalyticsCore/commit/4352fc9a7040c953b3d7a7d1058e8e39bbeb948f))

## [1.13.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.12.0...v1.13.0) (2026-04-10)


### Features

* add source file modification time caching in `AbstractWorkerJob` ([422824d](https://github.com/cEhlers88/AnalyticsCore/commit/422824d979461bda30bdf34748fda642edc9a691))

## [1.12.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.11.0...v1.12.0) (2026-04-06)


### Features

* extend `BadgeProvider` with additional states and update visual styles ([ab4d8c8](https://github.com/cEhlers88/AnalyticsCore/commit/ab4d8c864b094e892150b6545e680f3a241ef1b8))


### Bug Fixes

* refine `QuickStatusInfoDTO` state handling in `AbstractRunnableEntity` ([8c1cc33](https://github.com/cEhlers88/AnalyticsCore/commit/8c1cc33d21ee6f7bead400e84dd7e73f3a3e00c1))

## [1.11.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.10.1...v1.11.0) (2026-04-06)


### Features

* add `ApplicationConfigurationGroup` for managing application settings ([2c5f309](https://github.com/cEhlers88/AnalyticsCore/commit/2c5f3098622f3ef25fa24c2c074d86d4058559c7))


### Miscellaneous Chores

* remove unused `state` configuration item in `ApplicationConfigurationGroup` ([465cd8d](https://github.com/cEhlers88/AnalyticsCore/commit/465cd8d9f3b9d56e5d36acd3fca91e37c7914e45))

## [1.10.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.10.0...v1.10.1) (2026-04-06)


### Bug Fixes

* improve warning message for unknown job type in `AbstractWorker` ([4c12b3f](https://github.com/cEhlers88/AnalyticsCore/commit/4c12b3fb0e261f6a37246a5656983533ed204352))

## [1.10.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.9.0...v1.10.0) (2026-04-06)


### Features

* enhance custom entity resolution logic and improve state handling ([b9f84f9](https://github.com/cEhlers88/AnalyticsCore/commit/b9f84f9f49a795c188b3160dd1c95a4c818d7ce8))
* update `WorkerResultDTO` error handling to support arrays ([a99b2cd](https://github.com/cEhlers88/AnalyticsCore/commit/a99b2cd2bd2ef98a51dfd909d5c0059578b8b52b))

## [1.9.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.8.0...v1.9.0) (2026-04-05)


### Features

* add `parentId` property to `CustomEntity` with getter and setter methods ([386cc6c](https://github.com/cEhlers88/AnalyticsCore/commit/386cc6ccbc69fffd0b5bbd12638f39d8662a6a13))

## [1.8.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.7.0...v1.8.0) (2026-04-05)


### Features

* add warning state and enhance warning handling in `AbstractWorker` ([d63a6cc](https://github.com/cEhlers88/AnalyticsCore/commit/d63a6cc7d5c4c9a9d470fbbbad55b69b9334d20a))

## [1.7.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.6.0...v1.7.0) (2026-04-05)


### Features

* add `DomElementPropsDTO` and `AbstractInputRenderer` for input rendering and DOM definition handling ([347b785](https://github.com/cEhlers88/AnalyticsCore/commit/347b78582689836c53497bb9465a41133324df6c))
* refactor `ConfigurationProvider` with autoload toggle, enhanced buffer handling, and constant grouping logic ([fbef09b](https://github.com/cEhlers88/AnalyticsCore/commit/fbef09b82e96d54e7197289cea90633710fd2634))


### Miscellaneous Chores

* **deps:** update dependency phpunit/phpunit to v13.1.0 ([#71](https://github.com/cEhlers88/AnalyticsCore/issues/71)) ([ea28b56](https://github.com/cEhlers88/AnalyticsCore/commit/ea28b56177d222ec9863a49d974a80e451f7444c))

## [1.6.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.5.0...v1.6.0) (2026-03-29)


### Features

* add `getResultWorkers` method to `ProcessResultWorkerProvider` to expose result worker collection ([5bbd8d1](https://github.com/cEhlers88/AnalyticsCore/commit/5bbd8d190b348d591f84e67c2ad5a806ad73377d))

## [1.5.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.4.1...v1.5.0) (2026-03-29)


### Features

* enhance process runner framework with result handling logic and configuration updates ([95435c9](https://github.com/cEhlers88/AnalyticsCore/commit/95435c9c7a32ef940abadcdcdf32cbb2f0c62933))
* update process runner and state management logic ([6dacfee](https://github.com/cEhlers88/AnalyticsCore/commit/6dacfeee3bb8addc89000fd0c542f8b8b6927afe))

## [1.4.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.4.0...v1.4.1) (2026-03-29)


### Miscellaneous Chores

* improve `AbstractExecutor` and `AbstractWorker` handling, add `isDisabled` method, enhance type hints and repository usage, and refactor worker result logic ([04b1daa](https://github.com/cEhlers88/AnalyticsCore/commit/04b1daae5f934fd1f245922602b235eb6e21fce3))
* refactor `RunChainView` constructor to `loadByRunChain` for improved usability and streamline entity handling ([2141fba](https://github.com/cEhlers88/AnalyticsCore/commit/2141fbae4420b220374c5c04cd06825e26daad88))

## [1.4.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.13...v1.4.0) (2026-03-27)


### Features

* add `QuickActionDTO` for representing quick action attributes ([2b04ed6](https://github.com/cEhlers88/AnalyticsCore/commit/2b04ed6c06f7fa1c1a125fe4a9ae0bc17803f4db))


### Miscellaneous Chores

* refactor `RunChainAssemblerTest` to improve structure and add createdAt mock setup ([4620928](https://github.com/cEhlers88/AnalyticsCore/commit/46209282dd5384662037e279c8c346152f58d45d))
* rename `one` to `assembleView` in assembler classes for improved clarity and consistency ([c1b0f55](https://github.com/cEhlers88/AnalyticsCore/commit/c1b0f55ece8f70b92e60e530860a3d4e35535f5f))

## [1.3.13](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.12...v1.3.13) (2026-03-26)


### Miscellaneous Chores

* enhance error handling in `AbstractWorker` by logging fatal errors to `TrackingBuffer` ([84e9917](https://github.com/cEhlers88/AnalyticsCore/commit/84e991785f70aa62686a8800a61451aaba8dd3c4))

## [1.3.12](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.11...v1.3.12) (2026-03-26)


### Miscellaneous Chores

* integrate `TrackingBufferRepository` into `WorkerProvider` and `AbstractWorker` for enhanced repository handling ([efcdee9](https://github.com/cEhlers88/AnalyticsCore/commit/efcdee9cda4563e3299d222717dfc084e580ed68))

## [1.3.11](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.10...v1.3.11) (2026-03-26)


### Miscellaneous Chores

* refactor error handling and status generation in core components ([dd638f6](https://github.com/cEhlers88/AnalyticsCore/commit/dd638f68e9603c95a9e91307dee10e517f80fb25))

## [1.3.10](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.9...v1.3.10) (2026-03-25)


### Miscellaneous Chores

* remove unused imports and logging methods, enhance property loading in worker classes ([dbce940](https://github.com/cEhlers88/AnalyticsCore/commit/dbce940860baf7985b6805d7b3aeff7fa8744e22))

## [1.3.9](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.8...v1.3.9) (2026-03-25)


### Miscellaneous Chores

* add `TrackingBufferView` and `TrackingBufferAssembler` for front-end representation and entity handling ([a648e4b](https://github.com/cEhlers88/AnalyticsCore/commit/a648e4b0e1fae933e98b98277f63ceb11d3ec77f))
* add `UserView` and `UserAssembler` for front-end representation, implement `EntityInterface` in `User` entity ([ed280aa](https://github.com/cEhlers88/AnalyticsCore/commit/ed280aae672908e1e9a245f2695cd628caeb337f))

## [1.3.8](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.7...v1.3.8) (2026-03-24)


### Miscellaneous Chores

* update `setAttribute` method to return `static` for improved chaining support ([a9dbbe7](https://github.com/cEhlers88/AnalyticsCore/commit/a9dbbe7660d06663b603483ee7efcd44600b9b50))

## [1.3.7](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.6...v1.3.7) (2026-03-24)


### Miscellaneous Chores

* replace `setId` with `load` in `CustomObjectInterface`, streamline attribute initialization ([38a93f0](https://github.com/cEhlers88/AnalyticsCore/commit/38a93f0cd97488d72c8df6c7859d94d28c1e9cc6))

## [1.3.6](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.5...v1.3.6) (2026-03-23)


### Miscellaneous Chores

* add `NORMALIZED` state to `eTrackingBufferState` enum ([523067c](https://github.com/cEhlers88/AnalyticsCore/commit/523067cea1fc797704c5c4112d7794c39b5fb6e7))

## [1.3.5](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.4...v1.3.5) (2026-03-23)


### Miscellaneous Chores

* remove deprecated frontend assemblers and views, add `configure` method to `AbstractAssembler` and `AssemblerInterface` ([c92d082](https://github.com/cEhlers88/AnalyticsCore/commit/c92d082c0e38bfe6c16283eba1190417c1a8f833))

## [1.3.4](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.3...v1.3.4) (2026-03-23)


### Bug Fixes

* update `filters` field in `TrackingBuffer` entity to use `TEXT` type for better compatibility ([0b4e440](https://github.com/cEhlers88/AnalyticsCore/commit/0b4e440ab506bf218d229135c5b4a5d19a548d12))


### Miscellaneous Chores

* remove deprecated `TrackingBuffer` assembler and view, introduce `AssemblerProvider` with `canHandle` support for improved entity-assembler handling ([781e19f](https://github.com/cEhlers88/AnalyticsCore/commit/781e19febe15b9e2581172bbf22b4eae3b1ee94b))

## [1.3.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.2...v1.3.3) (2026-03-23)


### Miscellaneous Chores

* add `color` property to `ApplicationView` and `ApplicationAssembler`, introduce `filters` field and indexing in `TrackingBuffer` entity ([3941987](https://github.com/cEhlers88/AnalyticsCore/commit/3941987e7366f78108c640dabe433c06595f136b))

## [1.3.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.1...v1.3.2) (2026-03-23)


### Bug Fixes

* update `TrackingBufferView` to use `eTrackingBufferState` instead of `eRunningState`, align with state changes ([a5d6189](https://github.com/cEhlers88/AnalyticsCore/commit/a5d61893da3435085ac907808ea892083719adf2))

## [1.3.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.3.0...v1.3.1) (2026-03-23)


### Bug Fixes

* update `TrackingBuffer` assembler and view to use `eRunningState`, refactor state handling for consistency ([5a76a35](https://github.com/cEhlers88/AnalyticsCore/commit/5a76a35ba12c64dad9a1437cbf99761208e0fb4b))

## [1.3.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.2.0...v1.3.0) (2026-03-23)


### Features

* add `TrackingBuffer` assembler and view, enhance `QuickStatusInfoProvider` with detailed states, and refactor deprecated method in `TrackingBuffer` entity ([fefdd41](https://github.com/cEhlers88/AnalyticsCore/commit/fefdd4153c9fe08ed7f8a57d7892ee3ba97dfaff))

## [1.2.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.3...v1.2.0) (2026-03-23)


### Features

* set badge label and CSS class in `ApplicationView` constructor ([75df4a3](https://github.com/cEhlers88/AnalyticsCore/commit/75df4a391519c35919bb4483c9b58734abb4298f))

## [1.1.3](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.2...v1.1.3) (2026-03-22)


### Bug Fixes

* handle potential null `process` in `CurlRequestProcessRunner`, refine `AbstractProcessResultWorker` process management logic ([66c2947](https://github.com/cEhlers88/AnalyticsCore/commit/66c2947a33f9e891d63191692686577980b82986))

## [1.1.2](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.1...v1.1.2) (2026-03-22)


### Bug Fixes

* add error handling in `ProcessProvider` to log exceptions and update process state ([ce9f2e1](https://github.com/cEhlers88/AnalyticsCore/commit/ce9f2e17a6a5eb2a32e87e73ec48f1144b576d8d))

## [1.1.1](https://github.com/cEhlers88/AnalyticsCore/compare/v1.1.0...v1.1.1) (2026-03-22)


### Bug Fixes

* add `statusCode` and `runner` handling in `AbstractProcessResultWorker`, minor format fix in `ModifyTrackingBufferResultWorker` ([a3c47a0](https://github.com/cEhlers88/AnalyticsCore/commit/a3c47a057d8f72fd7475a784da05cf50bb0174ae))

## [1.1.0](https://github.com/cEhlers88/AnalyticsCore/compare/v1.0.0...v1.1.0) (2026-03-22)


### Features

* add `ProcessResultWorkerProvider` for managing result workers and refine state handling in `AbstractProcessResultWorker` ([1c4a77b](https://github.com/cEhlers88/AnalyticsCore/commit/1c4a77b8980ed1715af408ad59fe737bb1c9bc6c))
* extend `ProcessRunnerInterface` and `ProcessResultWorkerInterface` with result handling methods, implement enhanced runner-worker integration in `ProcessProvider` ([ea75a12](https://github.com/cEhlers88/AnalyticsCore/commit/ea75a12ac31ae77c6ad38740501677c167214296))

## [1.0.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.11...v1.0.0) (2026-03-22)


### ⚠ BREAKING CHANGES

* add debug mode with optional process logging in `ProcessProvider`

### Features

* add debug mode with optional process logging in `ProcessProvider` ([b03320a](https://github.com/cEhlers88/AnalyticsCore/commit/b03320a4b85211d44cea7aca872aa97f28d90dbf))

## [0.5.11](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.10...v0.5.11) (2026-03-22)


### Miscellaneous Chores

* reinstate `getQuickInfo` method in `AbstractRunnableEntity` for state evaluation ([e8e73ed](https://github.com/cEhlers88/AnalyticsCore/commit/e8e73ed011c6e9b63dbd32a27e3c5651dfa80472))

## [0.5.10](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.9...v0.5.10) (2026-03-22)


### Miscellaneous Chores

* reinstate and refine `getQuickInfo` method in `Process` entity for progress calculation ([6f0bd1c](https://github.com/cEhlers88/AnalyticsCore/commit/6f0bd1c0c79a47b2c2cee728c739394598c7c21e))

## [0.5.9](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.8...v0.5.9) (2026-03-22)


### Miscellaneous Chores

* add info logging during worker configuration and initialization, reorder `getName` method in `AbstractWorker` ([65edd87](https://github.com/cEhlers88/AnalyticsCore/commit/65edd878700536abbfda1f4b315ace0116db037b))
* remove redundant logging in `AbstractWorker` ([f37c817](https://github.com/cEhlers88/AnalyticsCore/commit/f37c8175e044e2b0f0eee0bcf14c503ec8fbd1ed))
* replace `logInfo` with `handleTimeoutReached` for consistent timeout handling in `AbstractWorker` ([cc33618](https://github.com/cEhlers88/AnalyticsCore/commit/cc336186b261a8b7def5fcb3c74966bd81eb022e))

## [0.5.8](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.7...v0.5.8) (2026-03-22)


### Bug Fixes

* handle nullable `StoreDTO` in `setStore` methods of `RunChain` and `Worker` entities ([66f243f](https://github.com/cEhlers88/AnalyticsCore/commit/66f243f25d8f897eeaf97c62f91703d01443fe8d))

## [0.5.7](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.6...v0.5.7) (2026-03-22)


### Miscellaneous Chores

* make `onStart` and `onEnd` public in `AbstractExecutor` and `ExecutorInterface`, improve error handling with logging ([a1b6e7f](https://github.com/cEhlers88/AnalyticsCore/commit/a1b6e7ff2ead3dd4a137bb1f2dc8939a51469dd1))

## [0.5.6](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.5...v0.5.6) (2026-03-22)


### Miscellaneous Chores

* add `store` property and related getter/setter in `RunChain` entity to support `StoreDTO` ([fc76ea5](https://github.com/cEhlers88/AnalyticsCore/commit/fc76ea5916ffd1310727a2fc484d74bbde8bd59b))

## [0.5.5](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.4...v0.5.5) (2026-03-22)


### Bug Fixes

* replace `Profiler::runWithProfiler` with dedicated `Profiler` instance in `AbstractWorker` ([eddfd45](https://github.com/cEhlers88/AnalyticsCore/commit/eddfd45d0d4f3654eae25a1c6b5c832a0c1fd281))

## [0.5.4](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.3...v0.5.4) (2026-03-22)


### Bug Fixes

* correct logic for error detection in `AbstractErrorBag::hasError` ([7e242d5](https://github.com/cEhlers88/AnalyticsCore/commit/7e242d54ecbee53b8b3039a7ea6846ae379a6f8c))

## [0.5.3](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.2...v0.5.3) (2026-03-22)


### Miscellaneous Chores

* add `isRunning` method to `AbstractExecutor` and `ExecutorInterface` ([7599464](https://github.com/cEhlers88/AnalyticsCore/commit/75994649a88bc04da59933d9c37b4e6592881e23))
* add `preStart` hook and `ERR_ON_PRE_START` constant to `AbstractExecutor` ([4f23c58](https://github.com/cEhlers88/AnalyticsCore/commit/4f23c58e900c5a44b8fa172442d06f96d57db006))

## [0.5.2](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.1...v0.5.2) (2026-03-21)


### Miscellaneous Chores

* allow filtering to include errored workers in `fetchWaitingWorkers` and enhance state removal logic in `Worker` entity ([c2b3b8f](https://github.com/cEhlers88/AnalyticsCore/commit/c2b3b8fe1b0f49f1adc57b20ccf22f5a95354413))

## [0.5.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.5.0...v0.5.1) (2026-03-21)


### Miscellaneous Chores

* add generated `timestamp_time` and `handled_at_time` columns to `TrackingBuffer` entity ([38eff80](https://github.com/cEhlers88/AnalyticsCore/commit/38eff8035e0ddd1bfd332d11835e4cc608e076e5))

## [0.5.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.4.2...v0.5.0) (2026-03-20)


### Features

* add `IGNORED` state to `eTrackingBufferState` enum ([8c91865](https://github.com/cEhlers88/AnalyticsCore/commit/8c918652be693d78ec4add84985d21a2a0eb5626))

## [0.4.2](https://github.com/cEhlers88/AnalyticsCore/compare/v0.4.1...v0.4.2) (2026-03-20)


### Miscellaneous Chores

* update `_executeWorker` to return a boolean instead of enforcing void ([62ccf41](https://github.com/cEhlers88/AnalyticsCore/commit/62ccf41c8a112b323e345089cc238d21e69d86b4))

## [0.4.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.4.0...v0.4.1) (2026-03-20)


### Miscellaneous Chores

* set `VoidLogger` as default in `executeWorkersByPriorityLevel` and enforce void cast in `_executeWorker` ([4ef7378](https://github.com/cEhlers88/AnalyticsCore/commit/4ef73780780ccbda748880792f4dec90f34da397))

## [0.4.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.3.1...v0.4.0) (2026-03-20)


### Features

* enhance `AbstractExecutor` with profiler lifecycle and ms-level execution time ([84e9d3a](https://github.com/cEhlers88/AnalyticsCore/commit/84e9d3a4fde26bade3a6196ffd1b6245d2237378))
* introduce `eDebuggerLogType` and `eDebuggerLogReason` enums, update namespace usage ([327955f](https://github.com/cEhlers88/AnalyticsCore/commit/327955fbd6a495c6f22b5d473d1a5399f8038dc0))

## [0.3.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.3.0...v0.3.1) (2026-03-20)


### Miscellaneous Chores

* **deps:** update actions/checkout action to v6 ([#21](https://github.com/cEhlers88/AnalyticsCore/issues/21)) ([112697f](https://github.com/cEhlers88/AnalyticsCore/commit/112697f6e2e66d04d6555c4e5141323a3571f51a))
* **deps:** update dependency phpunit/phpunit to v13 ([#22](https://github.com/cEhlers88/AnalyticsCore/issues/22)) ([0fb6bcf](https://github.com/cEhlers88/AnalyticsCore/commit/0fb6bcfb09e641e71ce5303e726596a25512a4b5))

## [0.3.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.2.1...v0.3.0) (2026-03-19)


### Features

* add `CompositeLogger` for managing multiple loggers ([2adeeaf](https://github.com/cEhlers88/AnalyticsCore/commit/2adeeaff330a8a51eb7cd1d980e35cee7c5706f8))
* add `getLoggerByClass` method to `CompositeLogger` ([e5c9269](https://github.com/cEhlers88/AnalyticsCore/commit/e5c9269c2c2314007500787df7f14a6a8f74cca9))
* introduce `AbstractExecutor` with complete lifecycle and logging support ([5b76531](https://github.com/cEhlers88/AnalyticsCore/commit/5b76531500a34b5b9c489cefb86727ed748b4f28))

## [0.2.1](https://github.com/cEhlers88/AnalyticsCore/compare/v0.2.0...v0.2.1) (2026-01-22)


### Features

* Implement process presenter ([#15](https://github.com/cEhlers88/AnalyticsCore/issues/15)) ([230fa9e](https://github.com/cEhlers88/AnalyticsCore/commit/230fa9e762afe15c554a2d399db98a013448488c))


### Miscellaneous Chores

* Configure Renovate ([#12](https://github.com/cEhlers88/AnalyticsCore/issues/12)) ([e03e62d](https://github.com/cEhlers88/AnalyticsCore/commit/e03e62d3a081fd9dd7d3507f7045f0b803305063))

## [0.2.0](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.8...v0.2.0) (2026-01-22)


### Features

* Implement presenters ([#9](https://github.com/cEhlers88/AnalyticsCore/issues/9)) ([d7399a7](https://github.com/cEhlers88/AnalyticsCore/commit/d7399a7604e707761f6549279257b164c59b8970))


### Bug Fixes

* replace `DateTimeImmutable` with `DateTime` for better compatibility ([28354e5](https://github.com/cEhlers88/AnalyticsCore/commit/28354e51aecf77b1fb553a27501013c77e499f07))

## [0.1.8](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.7...v0.1.8) (2026-01-21)


### Bug Fixes

* initialize default type for AbstractWorkerJob ([aa409b5](https://github.com/cEhlers88/AnalyticsCore/commit/aa409b5b17539a63cb45d73d200f3dabb7efb9b8))

## [0.1.7](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.6...v0.1.7) (2026-01-21)


### Reverts

* fix: prepend 'TEST' to truncated tracking buffer string ([f59b84c](https://github.com/cEhlers88/AnalyticsCore/commit/f59b84cf7411e6b39e73f50cc64ef7fc5a5d4bc0))

## [0.1.6](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.5...v0.1.6) (2026-01-21)


### Bug Fixes

* prepend 'TEST' to truncated tracking buffer string ([5a68758](https://github.com/cEhlers88/AnalyticsCore/commit/5a68758fc4ccd6544fcfec8281b7c8374059fca4))

## [0.1.5](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.4...v0.1.5) (2026-01-21)


### Miscellaneous Chores

* add workflow to trigger Satis rebuild on release publication ([0ecb93e](https://github.com/cEhlers88/AnalyticsCore/commit/0ecb93ea6b9cac9b5dbd0e95e01d734f1bdfa2b5))

## [0.1.4](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.3...v0.1.4) (2026-01-21)


### Bug Fixes

* Update ClientPermission `permkeys` field type from ARRAY to JSON ([bddfd5e](https://github.com/cEhlers88/AnalyticsCore/commit/bddfd5e267cfec90fdd9624fbb9f054d77ef3102))
* Update service bindings to use `!tagged_iterator` for tagged services ([faf2a03](https://github.com/cEhlers88/AnalyticsCore/commit/faf2a03bb969fac99b2c79e326a7fd031be047d1))

## [0.1.3](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.2...v0.1.3) (2026-01-20)


### Miscellaneous Chores

* add release-please.yml ([8438a59](https://github.com/cEhlers88/AnalyticsCore/commit/8438a594eb4f9afcfd600fa0ae51d90e88fb76b6))
