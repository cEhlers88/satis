<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\GetApplicationActionMacro;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Repository\ApplicationActionRepository;
use PHPUnit\Framework\TestCase;

class GetApplicationActionMacroTest extends TestCase
{
    /** @return array<string, mixed>|null the criteria the action was looked up by */
    private function lookUp(?Application $application): ?array
    {
        $criteria = null;
        $repository = $this->createMock(ApplicationActionRepository::class);
        $repository->method('findOneBy')->willReturnCallback(function (array $given) use (&$criteria) {
            $criteria = $given;

            return null;
        });
        $environment = $this->createMock(MacroEnvironment::class);
        $environment->method('getApplication')->willReturn($application);

        $macro = new GetApplicationActionMacro($repository);
        $macro->setMacroEnvironment($environment);
        $macro->execute(['actionName' => 'Deploy']);

        return $criteria;
    }

    public function testTheActionIsLookedUpInTheApplicationTheMacroRunsFor(): void
    {
        $application = $this->createMock(Application::class);

        $this->assertSame(['name' => 'Deploy', 'application' => $application], $this->lookUp($application));
    }

    public function testWithoutAnApplicationTheNameIsEnough(): void
    {
        $this->assertSame(['name' => 'Deploy'], $this->lookUp(null));
    }
}
