<?php

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\GetClientInfosMacro;
use Cehlers88\AnalyticsCore\Entity\Client;
use Doctrine\ORM\EntityRepository;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Doctrine\ORM\EntityManagerInterface;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class GetClientInfosMacroTest extends TestCase
{
    private MockObject $environmentMock;
    private MockObject $entityManagerMock;
    private MockObject $repositoryMock;

    protected function setUp(): void
    {
        parent::setUp();

        $this->environmentMock = $this->createMock(MacroEnvironment::class);
        $this->repositoryMock  = $this->createMock(EntityRepository::class);
        $this->entityManagerMock = $this->createMock(EntityManagerInterface::class);
        $this->entityManagerMock
            ->method('getRepository')
            ->with(Client::class)
            ->willReturn($this->repositoryMock);
    }

    private function execute(int $clientId, string $name = '', mixed $default = null): array
    {
        $macro = new GetClientInfosMacro($this->entityManagerMock);
        $macro->setMacroEnvironment($this->environmentMock);

        $args = ['clientId' => $clientId, 'name' => $name, 'default' => $default];

        return $macro->execute($args);
    }

    private function makeClient(string $ip = '127.0.0.1', string $firstVisit = '2026-01-15 10:30:00'): Client
    {
        $client = new Client();
        $client->setIp($ip);
        $client->setFirstVisit(new \DateTime($firstVisit));

        return $client;
    }

    // -------------------------------------------------------------------------
    // Returns the full client entity when name is empty
    // -------------------------------------------------------------------------

    public function testReturnsClientEntityWhenNameIsEmpty(): void
    {
        $client = $this->makeClient();
        $this->repositoryMock->method('find')->with(42)->willReturn($client);

        $result = $this->execute(42, '');

        $this->assertSame($client, $result['returnValue']);
        $this->assertFalse($result['hasError']);
    }

    // -------------------------------------------------------------------------
    // Returns the client's IP address (introduced in recent enhancement)
    // -------------------------------------------------------------------------

    public function testReturnsClientIpWhenNameIsIp(): void
    {
        $client = $this->makeClient('192.168.1.100');
        $this->repositoryMock->method('find')->with(7)->willReturn($client);

        $result = $this->execute(7, 'ip');

        $this->assertSame('192.168.1.100', $result['returnValue']);
        $this->assertFalse($result['hasError']);
    }

    // -------------------------------------------------------------------------
    // Returns first_visit formatted as Y-m-d H:i:s
    // -------------------------------------------------------------------------

    public function testReturnsFirstVisitFormattedWhenNameIsFirstVisit(): void
    {
        $client = $this->makeClient('10.0.0.1', '2026-03-22 08:15:00');
        $this->repositoryMock->method('find')->with(3)->willReturn($client);

        $result = $this->execute(3, 'first_visit');

        $this->assertSame('2026-03-22 08:15:00', $result['returnValue']);
        $this->assertFalse($result['hasError']);
    }

    // -------------------------------------------------------------------------
    // Falls back to full client entity for an unrecognised name
    // -------------------------------------------------------------------------

    public function testReturnsClientEntityForUnknownName(): void
    {
        $client = $this->makeClient();
        $this->repositoryMock->method('find')->with(1)->willReturn($client);

        $result = $this->execute(1, 'unknown_field');

        $this->assertSame($client, $result['returnValue']);
        $this->assertFalse($result['hasError']);
    }
}
