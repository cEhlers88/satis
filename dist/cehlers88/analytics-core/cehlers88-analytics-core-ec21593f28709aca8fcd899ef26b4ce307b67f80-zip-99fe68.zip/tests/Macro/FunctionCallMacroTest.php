<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\CallMacro;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\FunctionMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Repository\SharedDataRepository;
use Cehlers88\AnalyticsCore\Repository\VariableStoreRepository;
use Doctrine\Common\Collections\ArrayCollection;
use PHPUnit\Framework\TestCase;

/**
 * "function" declares a function with its arguments, "call" runs it - but only with the
 * arguments it declares, each of its type.
 */
class FunctionCallMacroTest extends TestCase
{
    private VariablesProvider $variables;
    private MacroEnvironment $environment;
    /** @var array<string, array> */
    private array $functions = [];
    /** The arguments the function's commands saw, per run. @var list<array<string, mixed>> */
    private array $seen = [];

    protected function setUp(): void
    {
        if (!class_exists(ArrayCollection::class)) {
            $this->markTestSkipped('doctrine/collections is not installed');
        }
        $this->variables = new VariablesProvider(
            $this->createStub(VariableStoreRepository::class),
            $this->createStub(SharedDataRepository::class)
        );

        $commandPlayer = $this->createStub(CommandPlayer::class);
        $commandPlayer->method('run')->willReturnCallback(function (mixed $definition) {
            $this->seen[] = array_column(
                array_map(static fn($argument) => (array)$argument, $this->variables->getVariables(eMacroVariableContext::ARGUMENT)),
                'value',
                'name'
            );

            // a list of one command arrives as that command (AbstractMacro::execute)
            return 'ran ' . (is_array($definition[0] ?? null) ? $definition[0][1] : $definition[1]);
        });

        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('getVariablesStoreProvider')->willReturn($this->variables);
        $environment->method('getCommandPlayer')->willReturn($commandPlayer);
        $environment->method('defineFunction')->willReturnCallback(function (string $name, mixed $content, array $arguments) use ($environment) {
            $this->functions[$name] = ['content' => $content, 'arguments' => $arguments];

            return $environment;
        });
        $environment->method('getFunction')->willReturnCallback(fn(string $name): ?array => $this->functions[$name] ?? null);
        $this->environment = $environment;
    }

    private function define(mixed $arguments): array
    {
        return (new FunctionMacro())->setMacroEnvironment($this->environment)->execute([
            'name' => 'greet',
            'content' => [['MARKER', 'greet']],
            'arguments' => $arguments,
        ]);
    }

    private function call(array $arguments): array
    {
        return (new CallMacro())->setMacroEnvironment($this->environment)->execute([
            'name' => 'greet',
            'arguments' => $arguments,
        ]);
    }

    public function testACallWithValidArgumentsRunsTheFunctionWithThem(): void
    {
        $this->define([['string', 'name'], ['integer', 'times', 2]]);

        $result = $this->call(['name' => 'Ada', 'times' => '3']);

        $this->assertFalse($result['hasError']);
        $this->assertSame('ran greet', $result['returnValue']);
        $this->assertSame([['name' => 'Ada', 'times' => 3]], $this->seen);
        $this->assertSame([], $this->variables->getVariables(eMacroVariableContext::ARGUMENT), 'the arguments are gone once it ran');
    }

    public function testDefiningAFunctionProducesNoOutput(): void
    {
        $this->assertSame(['__void' => true], $this->define(null)['returnValue']);
    }

    public function testAnInvalidCallRunsNothingAndSaysWhy(): void
    {
        $this->define([['string', 'name'], ['integer', 'times', 2]]);

        $result = $this->call(['times' => 'often']);

        $this->assertInstanceOf(ErrorDTO::class, $result['error']);
        $this->assertSame(422, $result['error']->number);
        $this->assertStringContainsString('"name" (string) is required but not given', $result['error']->message);
        $this->assertStringContainsString('"times" has to be an integer', $result['error']->message);
        $this->assertSame([], $this->seen, 'nothing ran');
    }

    public function testAnUnknownFunctionIsAnError(): void
    {
        $result = $this->call([]);

        $this->assertSame(404, $result['error']->number);
        $this->assertStringContainsString('Function "greet" is not defined', $result['error']->message);
    }

    public function testAnUnreadableDeclarationIsReportedWhenTheFunctionIsDefined(): void
    {
        $result = $this->define([['string', 'name'], ['string', 'name']]);

        $this->assertSame(422, $result['error']->number);
        $this->assertSame([], $this->functions, 'the function is not defined');
    }

    public function testAFunctionWithoutDeclaredArgumentsTakesWhateverIsGiven(): void
    {
        $this->define(null);

        $this->call(['anything' => 1]);

        $this->assertSame([['anything' => 1]], $this->seen);
    }
}
