<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Analytics\Message\StartWorkerMessage;
use Analytics\Security\Permissions;
use Analytics\Service\Workers\WorkerAdministration;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Repository\WorkerRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\Messenger\MessageBusInterface;
use Symfony\Component\Security\Core\User\UserInterface;

/**
 * All workers, or the picked ones: whether each one runs, waits, failed or is disabled, its
 * last and next run, and its counters. Users with the permission MANAGE_WORKERS
 * (WorkerAdministration::PERMISSION) also get the controls of the worker page: start it,
 * put it back to idle, enable or disable it and reset its counters - submit() checks that
 * permission again, the template only leaves the buttons out.
 *
 * Only workers of applications the signed-in user may read are listed or can be changed.
 * The template asks for a fresh rendering whenever a Worker changes, so runs show up live.
 */
class WorkersViewWidget extends AbstractWidget
{
    public const VIEW_ALL = 'all';
    public const VIEW_SELECTED = 'selected';

    public const ACTION_START = 'start';
    public const ACTION_IDLE = 'idle';
    public const ACTION_ENABLE = 'enable';
    public const ACTION_DISABLE = 'disable';
    public const ACTION_RESET_COUNTERS = 'resetCounters';

    public const STATUS_RUNNING = 'running';
    public const STATUS_ERROR = 'error';
    public const STATUS_DISABLED = 'disabled';
    public const STATUS_WAITING = 'waiting';
    public const STATUS_IDLE = 'idle';

    private const STATUS_LABELS = [
        self::STATUS_RUNNING => 'läuft',
        self::STATUS_ERROR => 'Fehler',
        self::STATUS_DISABLED => 'deaktiviert',
        self::STATUS_WAITING => 'wartet',
        self::STATUS_IDLE => 'bereit',
    ];

    /** The view types of the first version of this widget - both meant the picked workers. */
    private const LEGACY_SELECTED_VIEW_TYPES = ['single', 'multi'];

    private const FALLBACK_COLOR = '#6aa3e0';

    public function __construct(
        private readonly WorkerRepository       $workerRepository,
        private readonly EntityManagerInterface $entityManager,
        private readonly MessageBusInterface    $messageBus,
        private readonly Permissions            $permissions,
        private readonly Security               $security,
    )
    {
    }

    public function getName(): string
    {
        return 'AnalyticsCore.workersView';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '10px', 'boxes' => [.05, .6, .2]],
            ['height' => '8px', 'boxes' => [.05, .8]],
            ['height' => '10px', 'boxes' => [.05, .6, .2]],
            ['height' => '8px', 'boxes' => [.05, .8]],
            ['height' => '10px', 'boxes' => [.05, .6, .2]],
            ['height' => '8px', 'boxes' => [.05, .8]],
        ];
    }

    public function getTemplateName(): string
    {
        return 'workersView';
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'viewType',
                value: self::VIEW_ALL,
                type: 'string',
                label: 'Anzeige',
                description: 'Alle Worker zeigen oder nur die gewählten.',
                ui: [
                    'options' => [
                        self::VIEW_ALL => 'Alle Worker',
                        self::VIEW_SELECTED => 'Gewählte Worker',
                    ],
                ]
            ),
            PropertyDTO::create(
                name: 'source',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Worker',
                description: 'Die Worker, die gezeigt werden - einer oder mehrere.',
                ui: [
                    'input' => 'suggest',
                    'multiple' => true,
                    'suggestions' => $this->workerSuggestions(),
                ],
                conditions: [
                    PropertyConditionDTO::when('viewType', self::VIEW_ALL)->then([
                        PropertyConditionDTO::EFFECT_VISIBLE => false,
                    ]),
                    PropertyConditionDTO::when('viewType', self::VIEW_SELECTED)->then([
                        PropertyConditionDTO::EFFECT_IS_OPTIONAL => false,
                    ]),
                ]
            ),
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $user = $this->security->getUser();
        $workers = array_map(
            fn(Worker $worker): array => $this->describe($worker),
            $this->workers($user, $properties)
        );

        return [
            'workers' => $workers,
            'runningCount' => count(array_filter($workers, static fn(array $worker): bool => $worker['status'] === self::STATUS_RUNNING)),
            'errorCount' => count(array_filter($workers, static fn(array $worker): bool => $worker['hasError'])),
            'canManage' => $this->mayManage($user),
        ];
    }

    /**
     * Changes a worker: `id` of the worker, `action` one of the ACTION_* constants. Answers
     * with the worker as describe() sees it afterwards.
     */
    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        if ($user === null) {
            return WidgetSubmitResultDTO::createError(401, 'Nicht angemeldet.');
        }
        if (!$this->mayManage($user)) {
            return WidgetSubmitResultDTO::createError(403, 'Worker bearbeiten braucht die Berechtigung ' . WorkerAdministration::PERMISSION . '.');
        }

        $id = $data['id'] ?? null;
        $worker = self::isId($id) ? $this->workerRepository->find((int)$id) : null;
        // a worker of an application the user may not read is as good as missing
        if (!$worker instanceof Worker || !self::mayRead($user, $worker->getApplication())) {
            return WidgetSubmitResultDTO::createError(404, 'Den Worker gibt es nicht (mehr).');
        }

        $name = (string)$worker->getName();
        switch ($data['action'] ?? null) {
            case self::ACTION_START:
                if ($worker->hasState(eRunningState::Running)) {
                    return WidgetSubmitResultDTO::createError(409, sprintf('Worker "%s" läuft bereits.', $name));
                }
                // the same message the start button of the worker page sends (ApiWorkerController)
                $message = new StartWorkerMessage();
                $message->selector = 'id';
                $message->id = (int)$worker->getId();
                $message->enableLiveLogs = true;
                $this->messageBus->dispatch($message);
                $text = sprintf('Worker "%s" wird gestartet.', $name);
                break;
            case self::ACTION_IDLE:
                $worker->setIdle();
                $text = sprintf('Worker "%s" ist wieder bereit.', $name);
                break;
            case self::ACTION_ENABLE:
                $worker->setEnabled(true);
                $text = sprintf('Worker "%s" ist aktiviert.', $name);
                break;
            case self::ACTION_DISABLE:
                $worker->setEnabled(false);
                $text = sprintf('Worker "%s" ist deaktiviert.', $name);
                break;
            case self::ACTION_RESET_COUNTERS:
                $worker->resetCounters();
                $text = sprintf('Die Zähler von "%s" stehen wieder auf 0.', $name);
                break;
            default:
                return WidgetSubmitResultDTO::createError(422, 'Unbekannte Aktion.');
        }

        $this->entityManager->flush();

        return WidgetSubmitResultDTO::createSuccess($text, $this->describe($worker));
    }

    /**
     * What the template shows of a worker. One status sums it up - running wins over an
     * error, an error over being disabled - while hasError and enabled keep the rest.
     *
     * @return array<string, mixed>
     */
    public function describe(Worker $worker): array
    {
        $lastRun = $worker->getLastRunResult();
        $error = self::firstError($lastRun->error);
        $hasError = $error !== ''
            || $worker->hasState(eRunningState::Error)
            || $worker->hasState(eRunningState::FatalError)
            || $worker->hasState(eRunningState::Timeout);

        $status = match (true) {
            $worker->hasState(eRunningState::Running) => self::STATUS_RUNNING,
            $hasError => self::STATUS_ERROR,
            !$worker->isEnabled() => self::STATUS_DISABLED,
            $worker->isWaiting() => self::STATUS_WAITING,
            default => self::STATUS_IDLE,
        };

        $counters = $worker->getCounters();
        $runtime = $lastRun->runtime;

        return [
            'id' => (int)$worker->getId(),
            'name' => (string)$worker->getName(),
            'description' => trim((string)$worker->getDescription()),
            'application' => (string)$worker->getApplication()?->getName(),
            'color' => self::color($worker->getApplication()),
            'status' => $status,
            'statusLabel' => self::STATUS_LABELS[$status],
            'enabled' => $worker->isEnabled(),
            'hasError' => $hasError,
            'isIdle' => $worker->hasState(eRunningState::Idle),
            'error' => $error,
            'interval' => (string)$worker->getReadableRunInterval(),
            'startedAt' => $worker->getStartedAt()?->getTimestamp(),
            'finishedAt' => $worker->getFinishedAt()?->getTimestamp(),
            'nextRunAt' => $worker->getNextRunAt()?->getTimestamp(),
            'runtime' => $runtime !== null && $runtime > 0 ? round($runtime, 1) : null,
            'counters' => [
                'success' => (int)($counters['success'] ?? 0),
                'failed' => (int)($counters['failed'] ?? 0),
                'timeout' => (int)($counters['timeout'] ?? 0),
            ],
        ];
    }

    /**
     * The worker ids of the setting - a comma separated list from the mask, or a single
     * number once the widget request decoded it as JSON.
     *
     * @return list<int>
     */
    public static function workerIds(mixed $value): array
    {
        if (is_int($value)) {
            return $value > 0 ? [$value] : [];
        }
        if (!is_string($value)) {
            return [];
        }

        $ids = array_map('intval', array_filter(array_map('trim', explode(',', $value)), self::isId(...)));

        return array_values(array_unique($ids));
    }

    /**
     * The workers to show, sorted by name: those of applications the user may read, narrowed
     * down to the picked ones unless all are shown.
     *
     * @return list<Worker>
     */
    private function workers(?UserInterface $user, array $properties): array
    {
        if ($user === null) {
            return [];
        }

        $criteria = [];
        $viewType = $properties['viewType'] ?? self::VIEW_ALL;
        if ($viewType === self::VIEW_SELECTED || in_array($viewType, self::LEGACY_SELECTED_VIEW_TYPES, true)) {
            $ids = self::workerIds($properties['source'] ?? '');
            if ($ids === []) {
                return [];
            }
            $criteria['id'] = $ids;
        }

        // findBy, not findAll(): that one is prefiltered by whatever user was set on the
        // shared repository by an earlier request
        $workers = array_values(array_filter(
            $this->workerRepository->findBy($criteria),
            static fn(Worker $worker): bool => self::mayRead($user, $worker->getApplication())
        ));
        usort($workers, static fn(Worker $a, Worker $b): int => strnatcasecmp((string)$a->getName(), (string)$b->getName()));

        return $workers;
    }

    /** @return array<int, string> */
    private function workerSuggestions(): array
    {
        $suggestions = [];
        foreach ($this->workers($this->security->getUser(), []) as $worker) {
            $suggestions[(int)$worker->getId()] = sprintf('%s (#%d)', $worker->getName(), $worker->getId());
        }

        return $suggestions;
    }

    /**
     * Changing a worker takes the dashboard and MANAGE_WORKERS - as on the worker page
     * (AdminApiWorkerController::denyUnlessWorkerManager()).
     */
    private function mayManage(?UserInterface $user): bool
    {
        return ($this->security->isGranted('ROLE_DASHBOARD') || $this->security->isGranted('ROLE_ADMIN'))
            && $this->permissions->has($user, WorkerAdministration::PERMISSION);
    }

    /** A plain positive id - "1.9" or "1e3" would be cast to another worker than the one meant. */
    private static function isId(mixed $value): bool
    {
        return (is_int($value) && $value > 0) || (is_string($value) && preg_match('/^[1-9]\d{0,18}$/', $value) === 1);
    }

    private static function mayRead(UserInterface $user, ?Application $application): bool
    {
        return $application !== null && $application->allowRead($user);
    }

    /** The first message of the error of the last run, '' without one. */
    private static function firstError(?array $error): string
    {
        foreach ($error ?? [] as $entry) {
            $text = trim(is_scalar($entry) ? (string)$entry : (string)json_encode($entry));
            if ($text !== '') {
                return mb_strimwidth($text, 0, 300, '…');
            }
        }

        return '';
    }

    /** The color ends up in a style attribute, so only a plain hex color gets there. */
    private static function color(?Application $application): string
    {
        $color = (string)$application?->getColor();

        return preg_match('/^#[0-9a-f]{6}$/i', $color) === 1 ? $color : self::FALLBACK_COLOR;
    }
}
