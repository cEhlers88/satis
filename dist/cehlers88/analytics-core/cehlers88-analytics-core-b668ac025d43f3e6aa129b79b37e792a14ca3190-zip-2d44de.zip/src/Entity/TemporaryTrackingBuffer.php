<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\TemporaryTrackingBufferRepository;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\Index;

#[ORM\Entity(repositoryClass: TemporaryTrackingBufferRepository::class)]
#[ORM\AssociationOverrides([
    new ORM\AssociationOverride(name: 'application', inversedBy: 'temporaryTrackingBuffers'),
])]
#[Index(name: 'tmp_created_at_idx', columns: ['created_at'])]
#[Index(name: 'tmp_modified_at_idx', columns: ['modified_at'])]
#[Index(name: 'tmp_updated_at_idx', columns: ['updated_at'])]
#[Index(name: 'tmp_key_value_idx', columns: ['key_value'])]
#[Index(name: 'tmp_timestamp_idx', columns: ['timestamp'])]
#[Index(name: 'tmp_timestamp_time_idx', columns: ['timestamp_time'])]
#[Index(name: 'tmp_handled_at_time_idx', columns: ['handled_at_time'])]
#[Index(name: 'tmp_filters_idx', columns: ['filters'])]
/**
 * Independent entity with the same structure as TrackingBuffer, stored in its
 * own table with no database-level relationship to tracking_buffer.
 * Enforces a maximum of MAX_ENTRIES_PER_KEY_VALUE entries per key_value;
 * the oldest entries are removed automatically before a new one is persisted.
 */
class TemporaryTrackingBuffer extends AbstractTrackingBuffer
{
    public const int MAX_ENTRIES_PER_KEY_VALUE = 5;
}
