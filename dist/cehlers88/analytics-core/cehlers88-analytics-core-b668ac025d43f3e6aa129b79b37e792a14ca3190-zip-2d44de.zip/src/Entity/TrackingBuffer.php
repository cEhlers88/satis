<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\Index;

#[ORM\Entity(repositoryClass: TrackingBufferRepository::class)]
#[ORM\AssociationOverrides([
    new ORM\AssociationOverride(name: 'application', inversedBy: 'trackingBuffers'),
])]
#[Index(name: 'created_at_idx', columns: ['created_at'])]
#[Index(name: 'modified_at_idx', columns: ['modified_at'])]
#[Index(name: 'updated_at_idx', columns: ['updated_at'])]
#[Index(name: 'key_value_idx', columns: ['key_value'])]
#[Index(name: 'timestamp_idx', columns: ['timestamp'])]
#[Index(name: 'timestamp_time_idx', columns: ['timestamp_time'])]
#[Index(name: 'handled_at_time_idx', columns: ['handled_at_time'])]
#[Index(name: 'filters_idx', columns: ['filters'])]
/**
 * Entity representing a tracking buffer entry.
 */
class TrackingBuffer extends AbstractTrackingBuffer
{
}
