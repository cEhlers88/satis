<?php

namespace Cehlers88\AnalyticsCore\Worker;

use Analytics\DTO\PropertyDTO;

class TemporaryTrackingBufferWorker extends AbstractWorker
{
    public function __construct()
    {
        $this->addProperty(PropertyDTO::create('limit', 1000, 'int', true));
        $this->addProperty(PropertyDTO::create('offset', 0, 'int', true));
    }

    public function getWorkingObjects(): array
    {
        return $this->temporaryTrackingBufferRepository->findBy(
            $this->getPropertyValue('criteria'),
            $this->getPropertyValue('order'),
            $this->getPropertyValue('limit'),
            $this->getPropertyValue('offset')
        );
    }
}
