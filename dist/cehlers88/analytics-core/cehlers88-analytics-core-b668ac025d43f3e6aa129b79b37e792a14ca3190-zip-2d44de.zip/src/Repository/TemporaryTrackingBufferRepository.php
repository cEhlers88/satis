<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Analytics\ApplicationContext;
use Cehlers88\AnalyticsCore\Entity\TemporaryTrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * Repository for TemporaryTrackingBuffer entities.
 *
 * Enforces a maximum of {@see TemporaryTrackingBuffer::MAX_ENTRIES_PER_KEY_VALUE}
 * entries per key_value. When saving a new entry, the oldest entries for the
 * same key_value are removed so that the limit is respected.
 *
 * @extends ServiceEntityRepository<TemporaryTrackingBuffer>
 *
 * @method TemporaryTrackingBuffer|null find($id, $lockMode = null, $lockVersion = null)
 * @method TemporaryTrackingBuffer|null findOneBy(array $criteria, array $orderBy = null)
 * @method TemporaryTrackingBuffer[]    findAll()
 * @method TemporaryTrackingBuffer[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class TemporaryTrackingBufferRepository extends ServiceEntityRepository
{
    public function __construct(
        ManagerRegistry                $registry,
        private EntityManagerInterface $entityManager,
        private ApplicationContext     $applicationContext
    ) {
        parent::__construct($registry, TemporaryTrackingBuffer::class);
    }

    public function countUnhandled(int $applicationId): int
    {
        return count($this->getUnhandled($applicationId));
    }

    public function getUnhandled(int $applicationId): array
    {
        return $this->createQueryBuilder('t')
            ->where('t.state != ' . eTrackingBufferState::PROCESSED_FINISHED->value)
            ->andWhere('t.application = :applicationId')
            ->setParameter('applicationId', $applicationId)
            ->getQuery()
            ->getResult();
    }

    /**
     * Return all available key values as array.
     *
     * @param int $applicationId
     * @return string[]
     */
    public function getAvailableKeyValues(int $applicationId = -1): array
    {
        $qb = $this->createQueryBuilder('t');
        $qb->select('t.keyValue');
        $qb->distinct();
        if ($applicationId > 0) {
            $qb->andWhere('t.application = :applicationId');
            $qb->setParameter('applicationId', $applicationId);
        }
        $qb->orderBy('t.keyValue', 'ASC');
        $resultArray = [];

        foreach ($qb->getQuery()->getArrayResult() as $row) {
            $resultArray[] = $row['keyValue'];
        }
        return $resultArray;
    }

    /**
     * @param int $applicationId
     * @param int $limit
     * @return TemporaryTrackingBuffer[]
     */
    public function getUnfinished(int $applicationId, int $limit = -1): array
    {
        $result = $this->createQueryBuilder('t')
            ->where('t.state != ' . eTrackingBufferState::PROCESSED_FINISHED->value)
            ->andWhere('t.state != ' . eTrackingBufferState::ERROR->value)
            ->andWhere('t.application = :applicationId')
            ->setParameter('applicationId', $applicationId);
        if ($limit > 0) {
            $result->setMaxResults($limit);
        }
        return $result->getQuery()
            ->getResult();
    }

    public function findAllLimited(array $keyFilters = [], int $limit = 100): array
    {
        $queryBuilder = $this->createQueryBuilder('t')
            ->setMaxResults($limit)
            ->orderBy('t.id', 'DESC');

        if (count($keyFilters) > 0) {
            $queryBuilder->andWhere('t.keyValue IN (:keyFilters)')
                ->setParameter('keyFilters', $keyFilters);
        }

        return $queryBuilder->getQuery()->getResult();
    }

    /**
     * Finds entities in the repository that match any of the specified keys and a given state.
     *
     * @param array $keys An array of keys to match against the `keyValue` field.
     * @param eTrackingBufferState $state The state to filter entities by. Defaults to `eTrackingBufferState::NEW`.
     *
     * @return TemporaryTrackingBuffer[] An array of entities that match the specified keys and state.
     */
    public function findByAnyDataKeyValue(array $keys, eTrackingBufferState $state = eTrackingBufferState::NEW): array
    {
        return $this->createQueryBuilder('t')
            ->where('t.state = :state')
            ->andWhere('t.keyValue IN (:keys)')
            ->setParameter('state', $state->value)
            ->setParameter('keys', $keys)
            ->getQuery()
            ->getResult();
    }

    public function findByDataLike(string $needle, bool $excludeFinished = false, int $limit = -1): array
    {
        $result = $this->createQueryBuilder('t')
            ->where('t.data LIKE :needle');
        if ($excludeFinished) {
            $result->andWhere('t.state != ' . eTrackingBufferState::PROCESSED_FINISHED->value);
        }

        $result->setParameter('needle', '%' . $needle . '%');

        if ($limit > 0) {
            $result->setMaxResults($limit);
        }
        return $result->getQuery()->getResult();
    }

    /**
     * Persists the entity and enforces the per-key_value entry limit.
     *
     * Before inserting the new entry, any entries with the same key_value that
     * would exceed {@see TemporaryTrackingBuffer::MAX_ENTRIES_PER_KEY_VALUE} are
     * removed (oldest first, ordered by id ASC).
     */
    public function save(TemporaryTrackingBuffer $entity, bool $flush = false): static
    {
        if (is_null($entity->getTimestamp())) {
            $entity->setTimestamp(new \DateTime());
        }

        $data = $entity->getData();
        if (!isset($data['data'])) {
            $data['data'] = [];
        }
        if (!isset($data['body'])) {
            $data['body'] = [];
        }
        $data['applicationVersion'] = $this->applicationContext->getApplicationVersion();

        $entity->setData($data);

        // Enforce MAX_ENTRIES_PER_KEY_VALUE limit before persisting.
        $keyValue = $data['key'] ?? null;
        if ($keyValue !== null) {
            $existing = $this->findBy(
                ['keyValue' => $keyValue],
                ['id' => 'ASC']
            );

            $excessCount = count($existing) - (TemporaryTrackingBuffer::MAX_ENTRIES_PER_KEY_VALUE - 1);
            for ($i = 0; $i < $excessCount; $i++) {
                $this->entityManager->remove($existing[$i]);
            }
        }

        $this->entityManager->persist($entity);
        if (!$flush) {
            return $this;
        }

        try {
            $this->entityManager->flush();
        } catch (\Throwable $e) {
            dump($e->getMessage(), $e->getPrevious()?->getMessage());
            throw $e;
        }
        return $this;
    }

    public function flush(): static
    {
        $this->entityManager->flush();
        return $this;
    }
}
