<?php

namespace Cehlers88\AnalyticsCore\Tests\Entity;

use Cehlers88\AnalyticsCore\Entity\AbstractTrackingBuffer;
use Cehlers88\AnalyticsCore\Entity\TemporaryTrackingBuffer;
use PHPUnit\Framework\TestCase;

/**
 * Tests for the TemporaryTrackingBuffer entity.
 */
class TemporaryTrackingBufferTest extends TestCase
{
    public function testIsInstanceOfAbstractTrackingBuffer(): void
    {
        $entity = new TemporaryTrackingBuffer();

        $this->assertInstanceOf(AbstractTrackingBuffer::class, $entity);
    }

    public function testMaxEntriesPerKeyValueConstantIsCorrect(): void
    {
        $this->assertSame(5, TemporaryTrackingBuffer::MAX_ENTRIES_PER_KEY_VALUE);
    }

    public function testSetDataAndGetData(): void
    {
        $entity = new TemporaryTrackingBuffer();
        $data = ['key' => 'test-key', 'value' => 'test-value'];

        $entity->setData($data);

        $this->assertSame('test-key', $entity->getData()['key']);
        $this->assertSame('test-value', $entity->getData()['value']);
    }

    public function testSetTimestamp(): void
    {
        $entity = new TemporaryTrackingBuffer();
        $timestamp = new \DateTime();

        $entity->setTimestamp($timestamp);

        $this->assertSame($timestamp, $entity->getTimestamp());
    }

    public function testSetNote(): void
    {
        $entity = new TemporaryTrackingBuffer();

        $entity->setNote('some note');

        $this->assertSame('some note', $entity->getNote());
    }

    public function testClientInfosStringIsDecodedOnSetData(): void
    {
        $entity = new TemporaryTrackingBuffer();
        $clientInfos = ['browser' => 'Firefox', 'os' => 'Linux'];
        $data = ['key' => 'test', 'clientInfos' => json_encode($clientInfos)];

        $entity->setData($data);

        $this->assertSame($clientInfos, $entity->getData()['clientInfos']);
    }
}
