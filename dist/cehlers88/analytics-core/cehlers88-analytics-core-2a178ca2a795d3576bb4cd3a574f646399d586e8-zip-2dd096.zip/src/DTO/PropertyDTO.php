<?php

namespace Cehlers88\AnalyticsCore\DTO;

class PropertyDTO extends DTO
{
    public bool $isDefaultValue = true;
    public bool $isOptional = false;
    public string $name = '';
    public mixed $value = null;
    public bool $hasSubCommand = false;
    public bool $hasConditionGroups = false;
    public string $type = 'mixed';

    public array $ui = [        // special ui properties
        'class' => '',          // specify additional css-class for this property
        'displayName' => null,  // specify a different display name for this property in the UI
    ];

    private function __construct()
    {
    }

    public static function create(string $name, mixed $value, string $type = 'mixed', bool $isOptional = false): static
    {
        $dto = new static();
        $dto->name = $name;
        $dto->type = $type;
        $dto->value = $value;
        $dto->isOptional = $isOptional;
        return $dto;
    }

    public static function createFromArray(array $data): static
    {
        $dto = new static();
        $dto->type = $data[0];
        $dto->name = $data[1];
        $dto->value = $data[2] ?? null;;
        $dto->isOptional = isset($data[2]);
        return $dto;
    }

    public function toArray()
    {
        $result = [$this->type, $this->name, $this->value];
        return $result;
    }

    public function toNamedArray()
    {
        return ['name' => $this->name, 'type' => $this->type, 'value' => $this->value];
    }
}