<?php

namespace Cehlers88\AnalyticsCore\Factory;

use Analytics\DTO\ConditionGroupDTO;
use Analytics\Entity\Command;
use Analytics\ENUM\eConditionType;
use Analytics\Repository\CommandRepository;
use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Validator\CommandDefinitionValidator;

class CommandFactory
{
    public const UI_PROPERTY_EXTENDER_KEY = 'propertyExtender';
    private const array OPERATORS = [
        '==' => eConditionType::EQUALS,
        '===' => eConditionType::EQUALS,
        'equals' => eConditionType::EQUALS,
        '!=' => eConditionType::NOT_EQUALS,
        '>' => eConditionType::GREATER_THAN,
        '>=' => eConditionType::GREATER_THAN_OR_EQUALS,
        '<' => eConditionType::LESS_THAN,
        '<=' => eConditionType::LESS_THAN_OR_EQUALS,
        '&&' => eConditionType::AND,
        'and' => eConditionType::AND,
        '||' => eConditionType::OR,
        'or' => eConditionType::OR,
        'xor' => eConditionType::XOR
    ];
    private bool $_enrichUiInfos = false;
    private array $_commands;
    private array $_commandRegister = [];
    private $_commandDtoExtender;
    private CommandDefinitionValidator $_commandDefinitionValidator;

    public function __construct(
        private CommandRepository $commandRepository,
    )
    {
        $this->init();
    }

    private function init()
    {
        $this->_commands = $this->commandRepository->findAll();

        foreach ($this->_commands as $index => $command) {
            $this->_commandRegister[$command->getName()] = $index;
        }

        $this->_commandDefinitionValidator = new CommandDefinitionValidator(array_keys($this->_commandRegister));

        $this->setCommandDtoExtender(function (CommandDto $dto, Command $command) {
            return $dto;
        });
    }

    public function setCommandDtoExtender(callable $_commandDtoExtender): CommandFactory
    {
        $this->_commandDtoExtender = $_commandDtoExtender;
        return $this;
    }

    public function buildCommandDTO(Command $command, bool $includeOptionals = false): CommandDTO
    {
        $dto = new CommandDTO();

        $dto->commandName = $command->getName();
        foreach ($command->getMacroProps() as $macroProp) {
            $property = PropertyDTO::create(
                $macroProp[Command::MACRO_PROPS_INDEX_NAMES],
                ''
            );

            $property->value = $macroProp[Command::MACRO_PROPS_INDEX_TYPES] == 'string' ? "dummy value" : $property->value;
            $property->value = $macroProp[Command::MACRO_PROPS_INDEX_TYPES] == 'int' ? 123456 : $property->value;
            $property->value = $macroProp[Command::MACRO_PROPS_INDEX_TYPES] == 'boolean' ? 'true' : $property->value;

            if (isset($macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE])) {
                $property->value = $macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE];
                $property->isOptional = true;
            } else {
                $property->isOptional = false;
                $property->isDefaultValue = false;
            }

            if ($includeOptionals || !$property->isOptional) {
                $dto->properties[] = $property;
            }
        }

        return $dto;
    }

    public function buildQuickView(Command $command, array $values = []): string
    {
        $html = '';
        $formatArgs = [];
        if (isset($command->getQuickViewFormat()['keyWords'])) {
            foreach ($command->getQuickViewFormat()['keyWords'] as $keyWord) {
                $formatArgs[] = '<span class="keyWord">' . $keyWord . '</span>';
            }
        }

        foreach ($command->getMacroProps() as $macroProp) {
            $value = isset($values[$macroProp[Command::MACRO_PROPS_INDEX_NAMES]]) ? $values[$macroProp[Command::MACRO_PROPS_INDEX_NAMES]] : $macroProp[Command::MACRO_PROPS_INDEX_NAMES];
            $formatArgs[] = '<span class="property" data-name="' . $macroProp[Command::MACRO_PROPS_INDEX_NAMES] . '">' . $value . '</span>';
        }
        if (isset($command->getQuickViewFormat()['definition'])) {
            $html = sprintf($command->getQuickViewFormat()['definition'], ...$formatArgs);
        }
        return $html;
    }

    /**
     * Evaluates a command definition array and returns a CommandGroupDTO object.
     * If the definition is not an array of commands, it will be wrapped in an array.
     *
     * @param array $definition
     * @param bool $returnOriginalIfNotArrayOfCommands
     * @param bool $ignoreMissingCommandArguments
     *
     * @return CommandGroupDTO|array
     */
    public function evalDefinitionArray(
        array $definition,
        bool  $returnOriginalIfNotArrayOfCommands = false,
        bool  $ignoreMissingCommandArguments = false
    ): CommandGroupDTO|array
    {
        $result = new CommandGroupDTO();
        $isArrayOfCommands = false;

        try {
            if (isset($definition[0]) && is_array($definition[0]) && $this->_commandDefinitionValidator->validate($definition[0])) {
                foreach ($definition as $subDefinition) {
                    $result->commands[] = $this->commandDtoByDefinition($subDefinition);
                }
                $isArrayOfCommands = true;
            } else if (isset($definition[0]) && is_string($definition[0]) && $this->_commandDefinitionValidator->validate($definition)) {
                $result->commands = [$this->commandDtoByDefinition($definition)];
                $isArrayOfCommands = true;
            } else if (!$ignoreMissingCommandArguments) {
                // todo: implement possibility to define command/s with missing arguments
                foreach ($definition as $subDefinition) {
                    if (is_string($subDefinition)) {
                        //
                        continue;
                    }
                }
            }
        } catch (\Exception $e) {

        }

        if (!$isArrayOfCommands) {
            if ($returnOriginalIfNotArrayOfCommands) {
                return $definition;
            }
            $result->commands = [$this->commandDtoByDefinition($definition)];
        }
        return $result;
    }

    public function getCommandByName(string $name): ?Command
    {
        $index = $this->_commandRegister[$name] ?? null;
        if (is_null($index)) {
            return null;
        }
        return $this->_commands[$index];
    }

    public function commandDtoByDefinition(array $definition, string $address = ''): ?CommandDTO
    {
        if (
            !array_is_list($definition)
            || count($definition) !== 2
            || !is_string($definition[0])
            || !is_array($definition[1])
        ) {
            return null;
        }

        if (!$this->_commandDefinitionValidator->validate($definition)) {
            return null;
        }

        $command = $this->getCommandByName($definition[0]);
        if ($command === null) {
            return null;
        }

        $dto = new CommandDTO();
        $dto->commandName = $command->getName();
        $dto->properties = [];
        $dto->address = $address;

        $propOverwrites = $command->getMacroPropsOverwrites();
        foreach ($command->getMacroProps() as $macroProp) {
            $propName = $macroProp[Command::MACRO_PROPS_INDEX_NAMES];
            $propValue = (isset($macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE]) ? $macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE] : '');

            if (isset($definition[1])) {
                $propValue = (is_array($definition[1]) ?
                    (isset($definition[1][$propName]) ? $definition[1][$propName] : $propValue) :
                    (isset($definition[1]->$propName) ? $definition[1]->$propName : $propValue)
                );
            }

            if (isset($propOverwrites[$propName])) {
                $propValue = $propOverwrites[$propName];
                unset($propOverwrites[$propName]);
            }

            $property = $this->_enrichSubCommandCallInProperties(PropertyDTO::create($propName, $propValue, $macroProp[Command::MACRO_PROPS_INDEX_TYPES]));
            $property->isOptional = isset($macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE]);

            if (is_array($definition[1]) && isset($definition[1][$propName])) {
                unset($definition[1][$propName]);
                $property->isDefaultValue = false;
            } else if (is_object($definition[1]) && isset($definition[1]->$propName)) {
                unset($definition[1]->$propName);
                $property->isDefaultValue = false;
            }

            if (
                $this->_enrichUiInfos &&
                $command->getUiSettings() !== null &&
                array_key_exists(self::UI_PROPERTY_EXTENDER_KEY, $command->getUiSettings())
            ) {
                $uiInfos = call_user_func(
                    $command->getUiSettings()[self::UI_PROPERTY_EXTENDER_KEY],
                    MacroPropertyDTO::create($property->name, [], '', $property->value)
                );
                if ($uiInfos) {
                    $property->ui = $uiInfos;
                }
            }

            $dto->properties[] = $property;
        }

        foreach ($propOverwrites as $propName => $propValue) {
            $dto->properties[] = $this->_enrichSubCommandCallInProperties(PropertyDTO::create($propName, $propValue));
        }

        foreach ($definition[1] as $propName => $propValue) {
            $dto->unknownProperties[] = $this->_enrichSubCommandCallInProperties(PropertyDTO::create($propName, $propValue));
        }

        return call_user_func($this->_commandDtoExtender, $dto, $command, $this);
    }

    private function _enrichSubCommandCallInProperties(PropertyDTO $propertyDTO): ?PropertyDTO
    {
        // [X] value = "test"
        // [_] value = ["test","test2","test3"]
        // [_] value = ["test",["command",{"prop1":"test","prop2":"test2"}],"test3"]
        // [_] value = ["command",{"prop1":"test","prop2":"test2"}]
        // [_] value = [["command1",{"prop1":"test","prop2":"test2"}],["command2",{"prop1":"test","prop2":"test2"}]]

        if (is_array($propertyDTO->value)) {
            $propertyDTO->value = $this->_recursiveCommandSearch($propertyDTO->value);

            if ($propertyDTO->value instanceof CommandDTO) {
                $propertyDTO->hasSubCommand = true;
            } else {
                if ($propertyDTO->value instanceof ConditionGroupDTO) {
                    $propertyDTO->hasConditionGroups = true;
                } else {
                    foreach ($propertyDTO->value as $value) {
                        if ($value instanceof CommandDTO) {
                            $propertyDTO->hasSubCommand = true;
                        }
                    }
                }
            }
        } else {
            if ($propertyDTO->value instanceof CommandDTO) {
                $propertyDTO->hasSubCommand = true;
            }
        }

        return $propertyDTO;
    }

    private function _recursiveCommandSearch(array $definition, string $address = ''): mixed
    {
        if (count($definition) >= 2 && is_string($definition[0])) {
            if ($this->_isOperator($definition[0])) {
                return $this->conditionGroupDtoByDefinition($definition);
            } else if (isset($this->_commandRegister[$definition[0]])) {
                $resultDto = $this->commandDtoByDefinition($definition, $address);
                return $resultDto;
            }
        } else {
            $innerCounter = 0;
            foreach ($definition as $key => $value) {
                $definition[$key] = is_array($value) && count($value) >= 2 ? $this->_recursiveCommandSearch($value, ($address !== '' ? $address . '-' : '') . $innerCounter) : $value;
                $innerCounter++;
            }
        }
        return $definition;
    }

    private function _isOperator(string $operator): bool
    {
        return array_key_exists($operator, self::OPERATORS);
    }

    public function conditionGroupDtoByDefinition(array $definition): ?ConditionGroupDTO
    {
        foreach ($definition[1] as $key => $value) {
            if (is_array($value)) {
                $commandDto = $this->commandDtoByDefinition($value);
                if ($commandDto) {
                    $definition[1][$key] = $commandDto;
                }
            }
        }
        return ConditionGroupDTO::create($definition[1], self::OPERATORS[$definition[0]]);
    }

    public function setEnrichUiInfos(bool $enrichUiInfos): CommandFactory
    {
        $this->_enrichUiInfos = $enrichUiInfos;
        return $this;
    }
}