<?php

namespace Cehlers88\AnalyticsCore\Worker\Job;

use Analytics\Abstract\AbstractPropertyHolder;
use Analytics\ENUM\eWorkerJobType;
use Analytics\Player\MacroPlayer;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;

/** Base class for worker jobs. */
abstract class AbstractWorkerJob extends AbstractPropertyHolder implements JobInterface
{
    private static array $sourceFileModifiedAtCache = [];

    public eWorkerJobType $type = eWorkerJobType::UNKNOWN;
    protected array $_requiredKeys = [];
    protected bool $_handleMultipleObjects = false;
    protected MacroPlayer $_macroProvider;
    private float $_startTime = 0;
    private array $_commands = [];
    private array $_jobResults = [];
    private mixed $_workingObjects;
    private float $_maxRuntime = -1;
    private ?\Throwable $error = null;
    private bool $_hasOpenFormatedLog = false;

    /** Get the job error, if any. */
    public function getError(): ?\Throwable
    {
        return $this->error;
    }

    /** Check whether an error occurred. */
    public function hasError(): bool
    {
        return $this->error !== null;
    }

    /**
     * Run the job and return results.
     *
     * @return array
     */
    public function run(): array
    {
        $this->_startTime = microtime(true);
        $this->startJob();
        $this->_handleJobCommands();
        $this->_handleWorkingObjects();
        $this->finishJob();

        return $this->_jobResults;
    }

    /** Called before processing working objects. */
    protected function startJob(): void
    {

    }

    private function _handleJobCommands(): void
    {
        if (count($this->_commands) === 0) {
            return;
        }
        foreach ($this->_commands as $command) {
            $this->_macroProvider->executeMacro($command[0], $command[1]);
        }
        $this->_macroProvider->getMacroEnvironment()->getVariablesStoreProvider()->save();
    }

    private function _handleWorkingObjects(): void
    {
        foreach ($this->_workingObjects as $workingObject) {
            if ($this->_maxRuntime > 0 && microtime(true) - $this->_startTime > $this->_maxRuntime) {
                $this->logInfo('Max runtime reached. Stopping job.');
                break;
            }

            if (!$this->willHandle($workingObject)) {
                continue;
            }

            try {
                $this->workOnObject($workingObject);
            } catch (\Throwable $e) {
                $this->error = $e;
                break;
            }
        }
    }

    /**
     * Determine whether the job should handle the given object.
     *
     * @param object $workingObject The object to check.
     * @return bool
     */
    protected function willHandle(object $workingObject): bool
    {
        return true;
    }

    /**
     * Process a single working object.
     *
     * @param object $object The object to process.
     * @return AbstractWorkerJob
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        return $this;
    }

    /** Called after all working objects have been processed. */
    protected function finishJob(): void
    {
        if ($this->_hasOpenFormatedLog) {
            $this->_logger->removeTabSpace(3);
            $this->logInfo('</Job>');
        }
    }

    /** Get the job name. */
    public function getName(): string
    {
        return static::class;
    }

    /** Set a single working object. */
    public function setWorkingObject(mixed $workingObject): AbstractWorkerJob
    {
        return $this->setWorkingObjects([$workingObject]);
    }

    /** Get the job description. */
    public function getDescription(): string
    {
        return '';
    }

    /** Check whether the job handles multiple objects at once. */
    public function getHandleMultipleObjects(): bool
    {
        return $this->_handleMultipleObjects;
    }

    /** Get the job type. */
    public function getType(): eWorkerJobType
    {
        return $this->type;
    }

    /** Set the job type. */
    public function setType(eWorkerJobType $type): AbstractWorkerJob
    {
        $this->type = $type;
        return $this;
    }

    /** Get the first working object. */
    public function getWorkingObject(): mixed
    {
        return $this->_workingObjects[0];
    }

    /** Get all working objects. */
    public function getWorkingObjects(): mixed
    {
        return $this->_workingObjects;
    }

    /** Set the working objects to process. */
    public function setWorkingObjects(mixed $workingObjects): AbstractWorkerJob
    {

        if (count($this->_requiredKeys) === 0 || !($workingObjects instanceof TrackingBuffer)) {
            $this->_workingObjects = $workingObjects;
            return $this;
        }

        $this->_workingObjects = [];

        /** @var TrackingBuffer $workingObject */
        foreach ($workingObjects as $workingObject) {
            if (in_array($workingObject->getData()['key'], $this->_requiredKeys)) {
                $this->_workingObjects[] = $workingObject;
            }
        }

        return $this;
    }

    /** Set the macro provider. */
    public function setMacroProvider(MacroPlayer $macroProvider): AbstractWorkerJob
    {
        $this->_macroProvider = $macroProvider;
        return $this;
    }

    /** Set the maximum allowed runtime in seconds. */
    public function setMaxRuntime(float $maxRuntime): AbstractWorkerJob
    {
        $this->_maxRuntime = $maxRuntime;
        return $this;
    }

    protected function getSourceFileModifiedAt(): \DateTimeImmutable
    {
        $class = static::class;

        if (!isset(self::$sourceFileModifiedAtCache[$class])) {
            $reflection = new \ReflectionClass($class);
            $filePath = $reflection->getFileName();

            if ($filePath === false) {
                throw new \RuntimeException('Konnte die Quelldatei der Klasse nicht ermitteln.');
            }

            $mtime = filemtime($filePath);
            if ($mtime === false) {
                throw new \RuntimeException('Konnte das Änderungsdatum der Quelldatei nicht ermitteln.');
            }

            self::$sourceFileModifiedAtCache[$class] = (new \DateTimeImmutable())
                ->setTimestamp($mtime);
        }

        return self::$sourceFileModifiedAtCache[$class];
    }

    /**
     * Add a command to be executed during the job.
     *
     * @param string $command Command name.
     * @param array $arguments Command arguments.
     * @return AbstractWorkerJob
     */
    protected function addCommand(string $command, array $arguments = []): AbstractWorkerJob
    {
        $this->_commands[] = [$command, $arguments];
        return $this;
    }

    /** Add a result to the job results collection. */
    protected function addJobResult(mixed $result): AbstractWorkerJob
    {
        $this->_jobResults[] = $result;
        return $this;
    }

}