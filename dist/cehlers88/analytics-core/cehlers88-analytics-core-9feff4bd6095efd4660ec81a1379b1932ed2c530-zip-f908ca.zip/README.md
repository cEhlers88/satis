# AnalyticsCore

A PHP library providing core functionality for analytics applications.

## Description

AnalyticsCore is a PHP library that provides core components and abstractions for building analytics applications. It includes entity management, repository patterns, configuration handling, and support utilities for error handling and logging.

## Features

- **Entity Management**: Abstract entities for applications, processes, workers, and custom entities
- **Repository Pattern**: Abstract repositories for data access and persistence
- **Configuration System**: Flexible configuration provider with group-based organization
- **Error Handling**: Abstract error bag implementations for consistent error management
- **Logging Support**: Abstract logger implementations including void logger
- **Worker System**: Worker and job management with journal tracking
- **Statistics Tracking**: Built-in statistics entities and repositories
- **Custom Objects**: Support for custom entities and attributes
- **Command Processing**: Command pattern implementations
- **Observer Pattern**: Observer implementations for event handling

## Requirements

- PHP 7.4 or higher
- ext-curl

## Installation

Install via Composer:

```bash
composer require cehlers88/analytics-core
```

## Usage

The library provides several key components:

### Entities

```php
use Cehlers88\AnalyticsCore\Entity\AbstractEntity;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\Process;
```

### Repositories

```php
use Cehlers88\AnalyticsCore\Repository\AbstractRepository;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
```

### Configuration

```php
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
```

### Logging

```php
use Cehlers88\AnalyticsCore\Support\Logging\AbstractLogger;
```

## Project Structure

```
src/
├── AnalyticsCore.php          # Main bundle plugin class
├── Command/                    # Command implementations
├── Configuration/              # Configuration system
├── CustomObject/               # Custom object support
├── DTO/                        # Data Transfer Objects
├── ENUM/                       # Enumerations
├── Entity/                     # Entity classes
├── Observer/                   # Observer pattern implementations
├── Process/                    # Process management
├── Repository/                 # Repository pattern implementations
├── Resources/                  # Resource files
├── Support/                    # Support utilities
├── Utils/                      # Utility classes
└── Worker/                     # Worker system
```

## License

Proprietary

## Author

Christoph Ehlers <webmaster@c-ehlers.de>

## Version

1.0.0
