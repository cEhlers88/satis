<?php

namespace Cehlers88\AnalyticsCore\DTO;

class ValidationResultDTO extends DTO
{

}