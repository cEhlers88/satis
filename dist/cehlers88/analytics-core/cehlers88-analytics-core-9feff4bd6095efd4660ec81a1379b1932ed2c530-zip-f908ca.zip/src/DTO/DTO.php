<?php

namespace Cehlers88\AnalyticsCore\DTO;

abstract class DTO
{

}