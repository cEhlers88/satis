<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.09.2024
 * Time: 01:50
 */

namespace Cehlers88\AnalyticsCore\Support\Logging;

use Analytics\ENUM\eDebuggerLogType;

interface LoggerInterface
{
    public function log(eDebuggerLogType $logType, string $message, array $additionalInfos = []);

    public function addDateTimeToLogMessage(bool $addDateTime): static;

    public function addTypeToLogMessage(bool $addType): static;

    public function addTabSpace(int $tabSpaceCount = 1): static;

    public function removeTabSpace(int $tabSpaceCount = 1): static;

    public function error(string $message): void;

    public function info(string $message): void;

    public function progressAdvance(int $step = 1): void;

    public function progressStart(int $max): void;

    public function warning(string $message): void;

    public function setIgnoreInfoLog(bool $ignoreInfoLog = true): static;
}