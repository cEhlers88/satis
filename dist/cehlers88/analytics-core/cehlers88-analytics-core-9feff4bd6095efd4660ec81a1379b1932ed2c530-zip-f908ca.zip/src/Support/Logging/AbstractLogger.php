<?php

namespace Cehlers88\AnalyticsCore\Support\Logging;

use Analytics\ENUM\eDebuggerLogType;

abstract class AbstractLogger implements LoggerInterface
{
    protected int $tabSpaces = 0;
    protected bool $addDateTimeToLogMessage = true;
    protected bool $addTypeToLogMessage = true;

    public function log(eDebuggerLogType $logType, string $message, array $additionalInfos = [])
    {
        switch ($logType) {
            case eDebuggerLogType::ERROR:
                $this->error($message);
                break;

            case eDebuggerLogType::WARNING:
                $this->warning($message);
                break;

            default:
                $this->info($message);
                break;
        }
    }

    public function addDateTimeToLogMessage(bool $addDateTime): static
    {
        $this->addDateTimeToLogMessage = $addDateTime;
        return $this;
    }

    public function addTypeToLogMessage(bool $addType): static
    {
        $this->addTypeToLogMessage = $addType;
        return $this;
    }

    public function addTabSpace(int $tabSpaceCount = 1): static
    {
        $this->tabSpaces += $tabSpaceCount;
        return $this;
    }

    public function removeTabSpace(int $tabSpaceCount = 1): static
    {
        $this->tabSpaces -= $tabSpaceCount;
        return $this;
    }
}