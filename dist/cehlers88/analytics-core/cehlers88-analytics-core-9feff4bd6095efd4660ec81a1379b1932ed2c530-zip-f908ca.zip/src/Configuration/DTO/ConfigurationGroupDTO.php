<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.01.26
 * Time: 07:18
 */

namespace Cehlers88\AnalyticsCore\Configuration\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;

class ConfigurationGroupDTO extends DTO
{
    /** @var ConfigurationItemDTO[] */
    public array $items = [];
    public string $label = '';
    public string $description = '';
    public string $key = '';
    public string $name = '';
}