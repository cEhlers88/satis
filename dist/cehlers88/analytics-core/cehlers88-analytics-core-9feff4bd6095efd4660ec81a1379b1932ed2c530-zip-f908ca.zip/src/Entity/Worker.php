<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Analytics\ENUM\eWorkerCounterKey;
use Analytics\Register\BadgeRegister;
use Analytics\Utils\DateUtils;
use Cehlers88\AnalyticsCore\DTO\BadgeDTO;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Repository\WorkerRepository;
use Cehlers88\AnalyticsCore\Worker\DTO\StoreDTO;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: WorkerRepository::class)]
class Worker extends AbstractRunnableEntity
{
    public const ACTION_SET_IDLE = 'set_idle';
    public const ACTION_ENABLE = 'enable';
    public const ACTION_DISABLE = 'disable';
    private const PROPERTY_ALLOW_AUTOMATIC_RE_RUN_AFTER_FAILURE = 'allowAutomaticReRunAfterFailure';

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(length: 255)]
    private ?string $workerClass = null;

    #[ORM\OneToMany(targetEntity: WorkerJournal::class, mappedBy: 'worker')]
    private Collection $journals;

    #[ORM\Column]
    private array $counters = [];

    #[ORM\Column(type: Types::TEXT)]
    private string $lastRunResult = "";

    #[ORM\ManyToOne(inversedBy: 'workers')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Application $application = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $nextRunAt = null;

    #[ORM\Column]
    private array $properties = [];

    #[ORM\Column]
    private ?int $priority = null;

    #[ORM\Column(length: 20, nullable: true)]
    private ?string $runInterval = null;

    #[ORM\Column]
    private ?float $maxRuntime = null;

    /**
     * @var Collection<int, RunChain>
     */
    #[ORM\ManyToMany(targetEntity: RunChain::class, inversedBy: 'workers')]
    private Collection $runChains;

    /**
     * @var Collection<int, WorkerJobOptions>
     */
    #[ORM\OneToMany(targetEntity: WorkerJobOptions::class, mappedBy: 'worker', orphanRemoval: true)]
    private Collection $jobOptions;

    #[ORM\Column(nullable: true)]
    private ?array $store = null;

    public function __construct()
    {
        parent::__construct();
        $this->journals = new ArrayCollection();
        $this->runChains = new ArrayCollection();
        $this->jobOptions = new ArrayCollection();
    }


    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return Collection<int, WorkerJournal>
     */
    public function getJournals(): Collection
    {
        return $this->journals;
    }

    public function addJournal(WorkerJournal $journal): static
    {
        if (!$this->journals->contains($journal)) {
            $this->journals->add($journal);
            $journal->setWorker($this);
        }

        return $this;
    }

    public function allowAutomaticReRunAfterFailure(): bool
    {
        return $this->getProperty(self::PROPERTY_ALLOW_AUTOMATIC_RE_RUN_AFTER_FAILURE, false) === true;
    }

    public function getProperty(string $key, mixed $default = null): mixed
    {
        $result = array_find($this->properties, fn($property) => $property[1] === $key);
        return $result ? $result[2] : $default;
    }

    public function setAllowAutomaticReRunAfterFailure(bool $isAllowed): static
    {
        return $this->setProperty(self::PROPERTY_ALLOW_AUTOMATIC_RE_RUN_AFTER_FAILURE, $isAllowed);
    }

    public function setProperty(string $key, mixed $value): static
    {
        $saved = false;
        foreach ($this->properties as $property) {
            if ($property[1] === $key) {
                $property[2] = $value;
                $saved = true;
            }
        }
        if (!$saved) {
            $this->properties[] = [gettype($this), $key, $value];
        }
        return $this;
    }

    public function removeJournal(WorkerJournal $journal): static
    {
        if ($this->journals->removeElement($journal)) {
            // set the owning side to null (unless already changed)
            if ($journal->getWorker() === $this) {
                $journal->setWorker(null);
            }
        }

        return $this;
    }

    public function addCounterEntry(mixed $entry, eWorkerCounterKey $counterKey): static
    {
        if (!isset($this->counters[$counterKey->value])) {
            $this->counters[$counterKey->value] = [];
        }
        $this->counters[$counterKey->value][] = $entry;
        return $this;
    }

    public function getCounters(): array
    {
        return $this->counters;
    }

    public function setCounters(array $counters): static
    {
        $this->counters = $counters;

        return $this;
    }

    /**
     * Finalizes the worker process by updating the state, timestamps, and result counters
     * based on the provided result data and next run time.
     *
     * @param WorkerResultDTO $workerResultDTO The worker result data transfer object containing
     *                                             details of the worker execution result.
     * @param \DateTimeInterface|null $nextRunAt The next scheduled execution time. Can be null.
     * @param eRunningState $state The state to be applied to the worker.
     *
     * @return static Returns the updated instance of the object.
     */
    public function finishWorker(
        WorkerResultDTO $workerResultDTO,
        int             $state
    ): static
    {
        $this
            ->setLastRunResult($workerResultDTO)
            ->setFinishedAt(new \DateTime())
            ->setStateValue($state);

        if ($workerResultDTO->timedOut) {
            $this->incrementCounter(eWorkerCounterKey::TIMEOUT);
        } elseif (!empty($workerResultDTO->error)) {
            $this->incrementCounter(eWorkerCounterKey::FAILED);
        } else {
            $this->incrementCounter(eWorkerCounterKey::SUCCESS);
        }

        return $this;
    }

    public function incrementCounter(eWorkerCounterKey $counterKey): static
    {
        $this->counters[$counterKey->value] = ($this->counters[$counterKey->value] ?? 0) + 1;
        return $this;
    }

    public function resetCounters(): static
    {
        foreach ($this->counters as $counterKey => $counterValue) {
            $this->counters[$counterKey] = 0;
        }
        return $this;
    }

    public function setStarted(): static
    {
        $this
            ->setStartedAt(new \DateTime())
            ->setFinishedAt(null)
            ->setNextRunAt((new \DateTime())->add(new \DateInterval($this->getRunInterval())))
            ->incrementCounter(eWorkerCounterKey::STARTED)
            ->removeState(eRunningState::Finished)
            ->removeState(eRunningState::Idle)
            ->addState(eRunningState::Running);

        return $this;
    }

    public function getRunInterval(): ?string
    {
        return $this->runInterval;
    }

    public function setRunInterval(?string $runInterval): static
    {
        $this->runInterval = $runInterval;

        return $this;
    }

    public function setIdle(): static
    {
        $this
            ->setState(eRunningState::Idle);
        return $this;
    }

    public function getApplication(): ?Application
    {
        return $this->application;
    }

    public function setApplication(?Application $application): static
    {
        $this->application = $application;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getFormatedNextRunAt(): \DateTimeInterface
    {
        return $this->getNextRunAt();
    }

    public function getNextRunAt(): ?\DateTimeInterface
    {
        return $this->nextRunAt;
    }

    public function setNextRunAt(?\DateTimeInterface $nextRunAt): static
    {
        $this->nextRunAt = $nextRunAt;

        return $this;
    }

    public function getProperties(): array
    {
        return $this->properties;
    }

    public function setProperties(array $properties): static
    {
        $this->properties = $properties;

        return $this;
    }

    public function getPriority(): ?int
    {
        return $this->priority;
    }

    public function setPriority(int $priority): static
    {
        $this->priority = $priority;

        return $this;
    }

    public function getReadableRunInterval(): ?string
    {
        return DateUtils::readableInterval($this->runInterval);
    }

    public function getRunIntervalHms(): ?string
    {
        return DateUtils::durationToHms($this->runInterval);
    }

    public function getRunIntervalInt(): ?int
    {

        return DateUtils::readableInterval($this->runInterval, 'array')['int'];
    }

    public function getRunIntervalUnit(bool $checkSingularPlural = true): ?string
    {
        return DateUtils::readableInterval($this->runInterval, 'array', $checkSingularPlural)['unit'];
    }

    public function getMaxRuntime(): ?float
    {
        return $this->maxRuntime;
    }

    public function setMaxRuntime(float $maxRuntime): static
    {
        $this->maxRuntime = $maxRuntime;

        return $this;
    }

    public function getAvailableActions(): array
    {
        $actions = [];

        if (!$this->hasState(eRunningState::Idle)) {
            $actions[] = self::ACTION_SET_IDLE;
        }

        if ($this->isEnabled()) {
            $actions[] = self::ACTION_DISABLE;
        } else {
            $actions[] = self::ACTION_ENABLE;
        }

        return $actions;
    }

    /**
     * @return BadgeDTO[]
     */
    public function getBadges(BadgeRegister $badgeRegister): array
    {
        $resultBadges = [];
        $valid = !empty($this->getWorkerClass()) && class_exists($this->getWorkerClass()) && $this->getRunChains()->count() > 0;
        $isWaiting = false;
        $isWorking = false;

        if ($this->hasState(eRunningState::NoWork)) {
            $resultBadges[] = $badgeRegister->getBadge('no_work');
        }

        if ($this->hasState(eRunningState::Error) || !empty($this->getLastRunResult()->error)) {
            $resultBadges[] = $badgeRegister->getBadge('error');
        }

        if ($this->getLastRunResult()->startedAt === -1) {
            $resultBadges[] = $badgeRegister->getBadge('new');
        }

        if ($valid && $this->isWaiting()) {
            $isWaiting = true;
        }

        if ($this->hasState(eRunningState::Timeout)) {
            $resultBadges[] = $badgeRegister->getBadge('timeout');
        }

        if ($this->hasState(eRunningState::Running)) {
            $isWorking = true;
        }

        if ($valid && $this->hasState(eRunningState::Idle) || $this->hasState(eRunningState::Finished)) {
            $resultBadges[] = $badgeRegister->getBadge('idle');
        }

        if (!$this->isEnabled()) {
            $resultBadges[] = $badgeRegister->getBadge('disabled');
        }

        if (!$valid) {
            $resultBadges[] = $badgeRegister->getBadge('invalid');
        } else {
            if ($isWaiting) {
                if ($isWorking) {
                    $resultBadges[] = $badgeRegister->getBadge('to_slow');
                } else {
                    $resultBadges[] = $badgeRegister->getBadge('waiting');
                }
            } else {
                if ($isWorking) {
                    $resultBadges[] = $badgeRegister->getBadge('working');
                }
            }
        }

        return $resultBadges;
    }

    public function getWorkerClass(): ?string
    {
        return $this->workerClass;
    }

    public function setWorkerClass(string $workerClass): static
    {
        $this->workerClass = $workerClass;

        return $this;
    }

    /**
     * @return Collection<int, RunChain>
     */
    public function getRunChains(): Collection
    {
        return $this->runChains;
    }

    public function getLastRunResult(): WorkerResultDTO
    {
        return WorkerResultDTO::createFromString($this->lastRunResult);
    }

    public function setLastRunResult(WorkerResultDTO $lastRunResult): static
    {
        $this->lastRunResult = $lastRunResult->__toString();

        return $this;
    }

    public function addRunChain(RunChain $runChain): static
    {
        if (!$this->runChains->contains($runChain)) {
            $this->runChains->add($runChain);
        }

        return $this;
    }

    public function removeRunChain(RunChain $runChain): static
    {
        $this->runChains->removeElement($runChain);

        return $this;
    }

    /**
     * @return Collection<int, WorkerJobOptions>
     */
    public function getJobOptions(): Collection
    {
        return $this->jobOptions;
    }

    public function addJobOption(WorkerJobOptions $jobOption): static
    {
        if (!$this->jobOptions->contains($jobOption)) {
            $this->jobOptions->add($jobOption);
            $jobOption->setWorker($this);
        }

        return $this;
    }

    public function removeJobOption(WorkerJobOptions $jobOption): static
    {
        if ($this->jobOptions->removeElement($jobOption)) {
            // set the owning side to null (unless already changed)
            if ($jobOption->getWorker() === $this) {
                $jobOption->setWorker(null);
            }
        }

        return $this;
    }

    public function getRestRetries(bool $createIfNotExist = true, int $defaultRetryCounter = 3): int
    {
        $allowedRetries = $this->getProperty('allowed_retries', null);
        if (is_null($allowedRetries)) {
            $allowedRetries = $defaultRetryCounter;
            if ($createIfNotExist) {
                $this->setProperty('allowed_retries', $defaultRetryCounter);
            }
        }
        return $allowedRetries - $this->getCounter(eWorkerCounterKey::RETRY->value);
    }

    /**
     * @param eWorkerCounterKey $counterKey
     * @return int
     */
    public function getCounter(string $counterKey): int
    {
        return $this->counters[gettype($counterKey) === 'string' ? $counterKey : $counterKey->value] ?? 0;
    }

    public function getStore(): ?StoreDTO
    {
        return StoreDTO::fromArray($this->store ?? []);
    }

    public function setStore(?StoreDTO $store): static
    {
        $this->store = $store->toArray();

        return $this;
    }
}
