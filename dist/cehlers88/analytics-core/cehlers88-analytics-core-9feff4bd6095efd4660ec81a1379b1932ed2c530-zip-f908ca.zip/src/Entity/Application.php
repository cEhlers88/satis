<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Analytics\Entity\ApplicationAction;
use Analytics\Entity\Category;
use Analytics\Entity\ServiceEndpoint;
use Analytics\Entity\VariableStore;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Security\Core\User\UserInterface;

#[ORM\Entity(repositoryClass: ApplicationRepository::class)]
class Application extends AbstractEntity
{
    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    #[ORM\Column(length: 255)]
    private ?string $token = null;

    #[ORM\OneToMany(targetEntity: ApplicationAction::class, mappedBy: 'application', orphanRemoval: true)]
    private Collection $actions;

    #[ORM\OneToMany(targetEntity: Category::class, mappedBy: 'application')]
    private Collection $categories;

    #[ORM\OneToMany(targetEntity: ServiceEndpoint::class, mappedBy: 'application')]
    private Collection $serviceEndpoints;

    #[ORM\OneToMany(targetEntity: TrackingBuffer::class, mappedBy: 'application')]
    private Collection $trackingBuffers;

    #[ORM\OneToMany(targetEntity: Worker::class, mappedBy: 'application')]
    private Collection $workers;

    #[ORM\OneToMany(targetEntity: VariableStore::class, mappedBy: 'application')]
    private Collection $variableStores;

    #[ORM\Column(length: 10)]
    private ?string $color = null;

    public function __construct()
    {
        parent::__construct();
        $this->actions = new ArrayCollection();
        $this->categories = new ArrayCollection();
        $this->serviceEndpoints = new ArrayCollection();
        $this->trackingBuffers = new ArrayCollection();
        $this->workers = new ArrayCollection();
        $this->variableStores = new ArrayCollection();
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getToken(): ?string
    {
        return $this->token;
    }

    public function setToken(string $token): static
    {
        $this->token = $token;

        return $this;
    }

    /**
     * @return Collection<int, ApplicationAction>
     */
    public function getActions(): Collection
    {
        return $this->actions;
    }

    public function addAction(ApplicationAction $action): static
    {
        if (!$this->actions->contains($action)) {
            $this->actions->add($action);
            $action->setApplication($this);
        }

        return $this;
    }

    public function removeAction(ApplicationAction $action): static
    {
        if ($this->actions->removeElement($action)) {
            // set the owning side to null (unless already changed)
            if ($action->getApplication() === $this) {
                $action->setApplication(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, Category>
     */
    public function getCategories(): Collection
    {
        return $this->categories;
    }

    public function addCategory(Category $category): static
    {
        if (!$this->categories->contains($category)) {
            $this->categories->add($category);
            $category->setApplication($this);
        }

        return $this;
    }

    public function removeCategory(Category $category): static
    {
        if ($this->categories->removeElement($category)) {
            // set the owning side to null (unless already changed)
            if ($category->getApplication() === $this) {
                $category->setApplication(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, ServiceEndpoint>
     */
    public function getServiceEndpoints(): Collection
    {
        return $this->serviceEndpoints;
    }

    public function addServiceEndpoint(ServiceEndpoint $serviceEndpoint): static
    {
        if (!$this->serviceEndpoints->contains($serviceEndpoint)) {
            $this->serviceEndpoints->add($serviceEndpoint);
            $serviceEndpoint->setApplication($this);
        }

        return $this;
    }

    public function removeServiceEndpoint(ServiceEndpoint $serviceEndpoint): static
    {
        if ($this->serviceEndpoints->removeElement($serviceEndpoint)) {
            // set the owning side to null (unless already changed)
            if ($serviceEndpoint->getApplication() === $this) {
                $serviceEndpoint->setApplication(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, TrackingBuffer>
     */
    public function getTrackingBuffers(): Collection
    {
        return $this->trackingBuffers;
    }

    public function addTrackingBuffer(TrackingBuffer $trackingBuffer): static
    {
        if (!$this->trackingBuffers->contains($trackingBuffer)) {
            $this->trackingBuffers->add($trackingBuffer);
            $trackingBuffer->setApplication($this);
        }

        return $this;
    }

    public function removeTrackingBuffer(TrackingBuffer $trackingBuffer): static
    {
        if ($this->trackingBuffers->removeElement($trackingBuffer)) {
            // set the owning side to null (unless already changed)
            if ($trackingBuffer->getApplication() === $this) {
                $trackingBuffer->setApplication(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, Worker>
     */
    public function getWorkers(): Collection
    {
        return $this->workers;
    }

    public function addWorker(Worker $worker): static
    {
        if (!$this->workers->contains($worker)) {
            $this->workers->add($worker);
            $worker->setApplication($this);
        }

        return $this;
    }

    public function removeWorker(Worker $worker): static
    {
        if ($this->workers->removeElement($worker)) {
            // set the owning side to null (unless already changed)
            if ($worker->getApplication() === $this) {
                $worker->setApplication(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, VariableStore>
     */
    public function getVariableStores(): Collection
    {
        return $this->variableStores;
    }

    public function addVariableStore(VariableStore $variableStore): static
    {
        if (!$this->variableStores->contains($variableStore)) {
            $this->variableStores->add($variableStore);
            $variableStore->setApplication($this);
        }

        return $this;
    }

    public function removeVariableStore(VariableStore $variableStore): static
    {
        if ($this->variableStores->removeElement($variableStore)) {
            // set the owning side to null (unless already changed)
            if ($variableStore->getApplication() === $this) {
                $variableStore->setApplication(null);
            }
        }

        return $this;
    }

    public function getColor(): ?string
    {
        return $this->color;
    }

    public function setColor(string $color): static
    {
        $this->color = $color;

        return $this;
    }

    public function allowRead(UserInterface $user): bool
    {
        return in_array('ROLE_ADMIN', $user->getRoles())
            || in_array('application' . $this->getId() . '.read', $user->getRoles());
    }
}
