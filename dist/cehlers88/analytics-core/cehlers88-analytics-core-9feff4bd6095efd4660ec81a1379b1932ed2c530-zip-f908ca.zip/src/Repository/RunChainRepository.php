<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\RunChain;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<RunChain>
 */
class RunChainRepository extends ServiceEntityRepository
{
    public function __construct(
        ManagerRegistry                $registry,
        private EntityManagerInterface $_em
    )
    {
        parent::__construct($registry, RunChain::class);
    }

    public function save(RunChain $runChain, bool $flush = false): RunChain
    {
        $this->_em->persist($runChain);
        if ($flush) $this->_em->flush();
        return $runChain;
    }

    public function findAll(): array
    {
        return parent::findBy([], ['name' => 'ASC']);
    }
}
