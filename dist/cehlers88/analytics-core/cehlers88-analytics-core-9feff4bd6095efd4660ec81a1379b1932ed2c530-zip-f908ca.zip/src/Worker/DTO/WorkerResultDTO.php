<?php

namespace Cehlers88\AnalyticsCore\Worker\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;
use DateTime;

class WorkerResultDTO extends DTO
{
    public const string KEY_WORKING_OBJECTS_COUNT = 'working_objects_count';
    public const string KEY_BENCHMARK = 'benchmark';

    public ?string $error = null;
    public ?int $startedAt = -1;
    public ?int $endedAt = -1;
    public ?float $runtime = 0;
    public ?bool $timedOut = false;
    public ?array $jobResults = [];
    public ?array $workerInfos = [];

    public function __construct()
    {
        $this->startedAt = (new DateTime())->getTimestamp();
    }

    public static function createFromString(string $string): WorkerResultDTO
    {
        if (empty($string)) {
            $result = new self();
            $result->startedAt = -1;
            return $result;
        }
        try {
            $json = json_decode($string, true);
            $result = new self();

            $result->error = $json['error'] ?? '';
            $result->startedAt = $json['startedAt'] ?? null;
            $result->endedAt = $json['endedAt'] ?? null;
            $result->runtime = $json['runtime'] ?? -1;
            $result->timedOut = $json['timedOut'] ?? false;
            $result->jobResults = $json['jobResults'] ?? [];
            $result->workerInfos = $json['workerInfos'] ?? [];

            return $result;
        } catch (\Exception $e) {

        }
        try {
            return unserialize($string);
        } catch (\Exception $e) {

        }
        return new self();
    }

    public static function createFromException(\Throwable $e): WorkerResultDTO
    {
        $result = new self();
        $result->error = $e->getMessage();
        $result->endedAt = (new DateTime())->getTimestamp();

        return $result;

    }

    public function __toString(): string
    {
        return $this->serialize($this);
    }

    public function serialize(): string
    {
        return json_encode([
            'error' => $this->error,
            'startedAt' => $this->startedAt,
            'endedAt' => $this->endedAt,
            'runtime' => $this->runtime,
            'timedOut' => $this->timedOut,
            'jobResults' => $this->jobResults,
            'workerInfos' => $this->workerInfos
        ]);
    }

    public function getFormatedStartedAt(): string
    {
        if ($this->startedAt === -1) {
            return '';
        }

        return (new DateTime())->setTimestamp($this->startedAt)->format('d.m.Y | H:i:s');
    }

    public function getFormattedEndedAt(): string
    {
        if ($this->startedAt === -1) { // if not started, it's not finished'
            return '';
        }
        return (new DateTime())->setTimestamp($this->endedAt)->format('d.m.Y | H:i:s');
    }
}