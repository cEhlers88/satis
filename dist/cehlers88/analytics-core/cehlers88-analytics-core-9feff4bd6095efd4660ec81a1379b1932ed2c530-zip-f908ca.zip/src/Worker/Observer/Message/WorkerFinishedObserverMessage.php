<?php

namespace Cehlers88\AnalyticsCore\Worker\Observer\Message;

use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;
use Cehlers88\AnalyticsCore\Worker\WorkerInterface;

class WorkerFinishedObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'worker.finished';

    public function __construct(
        public WorkerInterface $workerInstance,
        public Worker          $workerEntity,
        public array           $additionalData
    )
    {

    }

    public function getKey(): string
    {
        return self::KEY;
    }
}