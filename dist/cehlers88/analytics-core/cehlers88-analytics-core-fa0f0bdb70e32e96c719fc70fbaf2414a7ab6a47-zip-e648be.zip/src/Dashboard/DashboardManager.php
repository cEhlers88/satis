<?php

namespace Cehlers88\AnalyticsCore\Dashboard;

use Cehlers88\AnalyticsCore\Entity\Dashboard;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Repository\DashboardRepositoryInterface;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Single entry point for everything that reads or changes the dashboards of a
 * user - which one is active, creating, updating and removing them.
 */
class DashboardManager
{
    public const ACTIVE_DASHBOARD_SETTING = 'activeDashboardId';

    public const DEFAULT_DASHBOARD_NAME = 'Dashboard';

    public function __construct(
        private DashboardRepositoryInterface $dashboardRepository,
        private DashboardSettingsProvider $dashboardSettingsProvider,
        private EntityManagerInterface    $entityManager
    )
    {
    }

    /**
     * @return Dashboard[]
     */
    public function getDashboards(User $user): array
    {
        return $this->dashboardRepository->findByUser($user);
    }

    /**
     * Loads one of the user's dashboards, or null when the id does not belong
     * to this user.
     */
    public function getDashboardForUser(User $user, int $dashboardId): ?Dashboard
    {
        return $this->dashboardRepository->findOneByIdAndUser($dashboardId, $user);
    }

    /**
     * Resolves the dashboard the user is currently looking at. Falls back to
     * the first dashboard when the stored id no longer exists.
     */
    public function getActiveDashboard(User $user): ?Dashboard
    {
        $dashboards = $this->getDashboards($user);
        if (count($dashboards) === 0) {
            return null;
        }

        $activeDashboardId = $this->getActiveDashboardId($user);
        if (!is_null($activeDashboardId)) {
            foreach ($dashboards as $dashboard) {
                if ($dashboard->getId() === $activeDashboardId) {
                    return $dashboard;
                }
            }
        }

        return $dashboards[0];
    }

    public function getActiveDashboardId(User $user): ?int
    {
        $activeDashboardId = $user->getSettings()[self::ACTIVE_DASHBOARD_SETTING] ?? null;

        return is_null($activeDashboardId) ? null : (int)$activeDashboardId;
    }

    /**
     * Marks the given dashboard as the one to show on the next dashboard visit.
     */
    public function setActiveDashboard(User $user, ?Dashboard $dashboard, bool $flush = true): static
    {
        $user->setSettings([
            ...$user->getSettings(),
            self::ACTIVE_DASHBOARD_SETTING => $dashboard?->getId(),
        ]);

        if ($flush) {
            $this->entityManager->flush();
        }

        return $this;
    }

    public function createDashboard(
        User   $user,
        string $name = '',
        array  $submittedSettings = [],
        bool   $activate = true
    ): Dashboard
    {
        $dashboard = new Dashboard()
            ->setName($this->normalizeName($name))
            ->setSortIndex($this->dashboardRepository->getNextSortIndex($user))
            ->setSettings($this->dashboardSettingsProvider->normalizeSubmittedSettings($submittedSettings));

        $user->addDashboard($dashboard);

        $this->entityManager->persist($dashboard);
        $this->entityManager->flush();

        if ($activate) {
            $this->setActiveDashboard($user, $dashboard);
        }

        return $dashboard;
    }

    public function updateDashboard(Dashboard $dashboard, string $name, array $submittedSettings): Dashboard
    {
        $dashboard
            ->setName($this->normalizeName($name, $dashboard->getName()))
            ->setSettings($this->dashboardSettingsProvider->normalizeSubmittedSettings($submittedSettings));

        $this->entityManager->flush();

        return $dashboard;
    }

    /**
     * Appends a widget to the dashboard.
     *
     * @param array $widget Raw widget data - see normalizeWidget() for the
     *                      recognized keys.
     */
    public function addWidget(Dashboard $dashboard, array $widget): Dashboard
    {
        return $this->storeWidgets($dashboard, [
            ...$this->getWidgetsWithIds($dashboard),
            $this->normalizeWidget($widget),
        ]);
    }

    /**
     * Removes the widget at the given position. An unknown position leaves the
     * dashboard untouched.
     */
    public function removeWidget(Dashboard $dashboard, int $index): Dashboard
    {
        $widgets = $this->getWidgetsWithIds($dashboard);
        if (!array_key_exists($index, $widgets)) {
            return $dashboard;
        }

        unset($widgets[$index]);

        return $this->storeWidgets($dashboard, array_values($widgets));
    }

    /**
     * Rearranges the widgets, where $order holds the current positions in their
     * new sequence.
     *
     * @throws \InvalidArgumentException When $order is not a permutation of the
     *                                   current positions - dropping or
     *                                   duplicating widgets must never happen.
     */
    public function reorderWidgets(Dashboard $dashboard, array $order): Dashboard
    {
        $widgets = $this->getWidgetsWithIds($dashboard);
        $positions = array_map(intval(...), $order);

        $sortedPositions = $positions;
        sort($sortedPositions);

        if ($sortedPositions !== array_keys($widgets)) {
            throw new \InvalidArgumentException('The given order does not match the widgets of this dashboard');
        }

        return $this->storeWidgets(
            $dashboard,
            array_map(static fn(int $position) => $widgets[$position], $positions)
        );
    }

    /**
     * Widgets carry a stable id so that clients (caches, drag and drop) can
     * address them without relying on their position. Dashboards created
     * before that was introduced get their ids here.
     *
     * @return array<int, array> Re-indexed from zero.
     */
    private function getWidgetsWithIds(Dashboard $dashboard): array
    {
        $widgets = array_values($dashboard->getWidgets());

        foreach ($widgets as $index => $widget) {
            if (!is_array($widget)) {
                unset($widgets[$index]);
                continue;
            }

            if (($widget['id'] ?? '') === '') {
                $widgets[$index]['id'] = $this->generateWidgetId();
            }
        }

        return array_values($widgets);
    }

    private function storeWidgets(Dashboard $dashboard, array $widgets): Dashboard
    {
        $dashboard->setWidgets($widgets);
        $this->entityManager->flush();

        return $dashboard;
    }

    /**
     * Reduces raw widget data down to the keys a dashboard tile understands.
     */
    private function normalizeWidget(array $widget): array
    {
        $name = trim((string)($widget['name'] ?? ''));
        if ($name === '') {
            throw new \InvalidArgumentException('A widget needs a name');
        }

        $accentColor = trim((string)($widget['accentColor'] ?? ''));
        $id = is_scalar($widget['id'] ?? null) ? trim((string)$widget['id']) : '';
        return [
            'id' => preg_match('/^[0-9a-f]{16}$/i', $id) === 1 ? $id : $this->generateWidgetId(),
            'name' => $name,
            'title' => trim((string)($widget['title'] ?? '')),
            // Ends up in a style attribute, so only plain hex values pass.
            'accentColor' => preg_match('/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $accentColor) === 1 ? $accentColor : '',
            'props' => is_array($widget['props'] ?? null) ? $widget['props'] : [],
        ];
    }

    private function generateWidgetId(): string
    {
        return bin2hex(random_bytes(8));
    }

    /**
     * Removes a dashboard. When it was the active one, the first remaining
     * dashboard becomes active.
     */
    public function deleteDashboard(Dashboard $dashboard): static
    {
        $user = $dashboard->getUser();
        $wasActive = !is_null($user) && $this->getActiveDashboardId($user) === $dashboard->getId();

        $user?->removeDashboard($dashboard);
        $this->entityManager->remove($dashboard);
        $this->entityManager->flush();

        if ($wasActive) {
            $this->setActiveDashboard($user, $this->getDashboards($user)[0] ?? null);
        }

        return $this;
    }

    private function normalizeName(string $name, ?string $fallback = null): string
    {
        $name = trim($name);
        if ($name !== '') {
            return mb_substr($name, 0, 255);
        }

        return $fallback ?? self::DEFAULT_DASHBOARD_NAME;
    }
}
