<?php

namespace Cehlers88\AnalyticsCore\Tests\Dashboard;

use Cehlers88\AnalyticsCore\Dashboard\DashboardManager;
use Cehlers88\AnalyticsCore\Dashboard\DashboardSettingProviderInterface;
use Cehlers88\AnalyticsCore\Dashboard\DashboardSettingsProvider;
use Cehlers88\AnalyticsCore\Entity\Dashboard;
use Cehlers88\AnalyticsCore\Repository\DashboardRepositoryInterface;
use Doctrine\ORM\EntityManagerInterface;
use PHPUnit\Framework\TestCase;

class DashboardManagerWidgetsTest extends TestCase
{
    /**
     * DashboardRepositoryInterface decoupled the repository, but the manager is
     * still typed against Doctrine's EntityManagerInterface, which the core does
     * not declare - the embedding application supplies it. These tests therefore
     * only run where that application context exists.
     */
    public static function setUpBeforeClass(): void
    {
        if (!interface_exists(EntityManagerInterface::class)) {
            self::markTestSkipped('Doctrine is not installed; DashboardManager can only be tested in an application context.');
        }
    }

    // ── adding ───────────────────────────────────────────────────────────────

    public function testAddWidgetAppendsToTheEndOfTheDashboard(): void
    {
        $dashboard = new Dashboard()->setWidgets([['id' => 'a', 'name' => 'Core.log']]);

        $this->makeManager()->addWidget($dashboard, ['name' => 'Core.report', 'title' => 'Bericht']);

        $widgets = $dashboard->getWidgets();
        $this->assertCount(2, $widgets);
        $this->assertSame('Core.log', $widgets[0]['name']);
        $this->assertSame('Core.report', $widgets[1]['name']);
        $this->assertSame('Bericht', $widgets[1]['title']);
    }

    public function testAddedWidgetsGetAStableId(): void
    {
        $dashboard = new Dashboard();

        $this->makeManager()->addWidget($dashboard, ['name' => 'Core.log']);

        $this->assertNotSame('', $dashboard->getWidgets()[0]['id'] ?? '');
    }

    public function testWidgetsWithoutAnIdGetOneOnTheFirstChange(): void
    {
        $dashboard = new Dashboard()->setWidgets([['name' => 'Core.log']]);

        $this->makeManager()->addWidget($dashboard, ['name' => 'Core.report']);

        $this->assertNotSame('', $dashboard->getWidgets()[0]['id'] ?? '');
    }

    public function testAServerGeneratedIdIsKept(): void
    {
        $dashboard = new Dashboard();
        $widgetId = bin2hex(random_bytes(8));

        $this->makeManager()->addWidget($dashboard, ['id' => $widgetId, 'name' => 'Core.log']);

        $this->assertSame($widgetId, $dashboard->getWidgets()[0]['id']);
    }

    public function testAClientChosenIdIsReplaced(): void
    {
        $dashboard = new Dashboard();

        // Ids are handed out by the server and clients address widgets by them,
        // so a caller must not be able to pick one.
        $this->makeManager()->addWidget($dashboard, ['id' => '../../etc/passwd', 'name' => 'Core.log']);

        $this->assertMatchesRegularExpression('/^[0-9a-f]{16}$/', $dashboard->getWidgets()[0]['id']);
    }

    public function testANonScalarIdIsReplaced(): void
    {
        $dashboard = new Dashboard();

        $this->makeManager()->addWidget($dashboard, ['id' => ['not', 'a', 'string'], 'name' => 'Core.log']);

        $this->assertMatchesRegularExpression('/^[0-9a-f]{16}$/', $dashboard->getWidgets()[0]['id']);
    }

    public function testOnlyKnownWidgetKeysAreStored(): void
    {
        $dashboard = new Dashboard();

        $this->makeManager()->addWidget($dashboard, [
            'name' => 'Core.log',
            'title' => '  Protokoll  ',
            'accentColor' => '#abc',
            'props' => ['source' => 'system'],
            'somethingElse' => 'dropped',
        ]);

        $widget = $dashboard->getWidgets()[0];
        $this->assertSame(['id', 'name', 'title', 'accentColor', 'props'], array_keys($widget));
        $this->assertSame('Protokoll', $widget['title']);
        $this->assertSame(['source' => 'system'], $widget['props']);
    }

    public function testAnAccentColorThatCouldBreakOutOfTheStyleAttributeIsDropped(): void
    {
        $dashboard = new Dashboard();

        $this->makeManager()->addWidget($dashboard, [
            'name' => 'Core.log',
            'accentColor' => 'red; background: url(x)',
        ]);

        $this->assertSame('', $dashboard->getWidgets()[0]['accentColor']);
    }

    public function testAWidgetWithoutANameIsRejected(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        $this->makeManager()->addWidget(new Dashboard(), ['title' => 'Ohne Name']);
    }

    // ── removing ─────────────────────────────────────────────────────────────

    public function testRemoveWidgetClosesTheGap(): void
    {
        $dashboard = $this->makeDashboardWithWidgets(['a', 'b', 'c']);

        $this->makeManager()->removeWidget($dashboard, 1);

        $this->assertSame(['a', 'c'], array_column($dashboard->getWidgets(), 'id'));
    }

    public function testRemovingAnUnknownPositionChangesNothing(): void
    {
        $dashboard = $this->makeDashboardWithWidgets(['a', 'b']);

        $this->makeManager()->removeWidget($dashboard, 7);

        $this->assertSame(['a', 'b'], array_column($dashboard->getWidgets(), 'id'));
    }

    // ── reordering ───────────────────────────────────────────────────────────

    public function testReorderWidgetsAppliesTheGivenSequence(): void
    {
        $dashboard = $this->makeDashboardWithWidgets(['a', 'b', 'c']);

        $this->makeManager()->reorderWidgets($dashboard, [2, 0, 1]);

        $this->assertSame(['c', 'a', 'b'], array_column($dashboard->getWidgets(), 'id'));
    }

    public function testReorderWidgetsAcceptsPositionsSentAsStrings(): void
    {
        $dashboard = $this->makeDashboardWithWidgets(['a', 'b']);

        $this->makeManager()->reorderWidgets($dashboard, ['1', '0']);

        $this->assertSame(['b', 'a'], array_column($dashboard->getWidgets(), 'id'));
    }

    public function testAnIncompleteOrderIsRejectedSoNoWidgetCanBeLost(): void
    {
        $dashboard = $this->makeDashboardWithWidgets(['a', 'b', 'c']);

        $this->expectException(\InvalidArgumentException::class);

        $this->makeManager()->reorderWidgets($dashboard, [0, 1]);
    }

    public function testADuplicatedPositionIsRejected(): void
    {
        $dashboard = $this->makeDashboardWithWidgets(['a', 'b']);

        $this->expectException(\InvalidArgumentException::class);

        $this->makeManager()->reorderWidgets($dashboard, [0, 0]);
    }

    public function testAnOutOfRangePositionIsRejected(): void
    {
        $dashboard = $this->makeDashboardWithWidgets(['a', 'b']);

        $this->expectException(\InvalidArgumentException::class);

        $this->makeManager()->reorderWidgets($dashboard, [0, 5]);
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    /**
     * @param string[] $widgetIds
     */
    private function makeDashboardWithWidgets(array $widgetIds): Dashboard
    {
        return new Dashboard()->setWidgets(array_map(
            static fn(string $widgetId) => ['id' => $widgetId, 'name' => 'Core.log'],
            $widgetIds
        ));
    }

    private function makeManager(): DashboardManager
    {
        $settingProvider = $this->createStub(DashboardSettingProviderInterface::class);
        $settingProvider->method('getDashboardSettingDefinitions')->willReturn([]);

        return new DashboardManager(
            $this->createStub(DashboardRepositoryInterface::class),
            new DashboardSettingsProvider([$settingProvider]),
            $this->createStub(EntityManagerInterface::class)
        );
    }
}
