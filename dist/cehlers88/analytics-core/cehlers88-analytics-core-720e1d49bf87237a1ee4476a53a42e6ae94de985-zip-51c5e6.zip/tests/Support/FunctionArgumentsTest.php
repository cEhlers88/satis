<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support;

use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Support\FunctionArguments;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class FunctionArgumentsTest extends TestCase
{
    private function resolve(array $declared, array $given): array
    {
        return FunctionArguments::resolve(
            'greet',
            FunctionArguments::declare('greet', $declared),
            $given,
            static fn(mixed $commands): string => 'ran ' . json_encode($commands)
        );
    }

    public function testGivenArgumentsAndDefaultsAreTakenInTheirType(): void
    {
        $values = $this->resolve(
            [['string', 'name'], ['integer', 'times', 2], ['boolean', 'loud', 'false']],
            ['name' => 'Ada', 'times' => '3']
        );

        $this->assertSame(['name' => 'Ada', 'times' => 3, 'loud' => false], $values);
    }

    public function testADefaultFromCommandsIsRunWhenTheArgumentIsMissing(): void
    {
        $values = $this->resolve(
            [['name' => 'today', 'type' => 'string', 'default' => [['date', []]], 'command' => true]],
            []
        );

        $this->assertSame(['today' => 'ran [["date",[]]]'], $values);
    }

    public function testEveryProblemIsNamedAtOnce(): void
    {
        try {
            $this->resolve(
                [['string', 'name'], ['integer', 'times'], ['array', 'tags', []]],
                ['times' => 'often', 'tag' => ['x']]
            );
            $this->fail('the call is invalid');
        } catch (\InvalidArgumentException $e) {
            $this->assertSame(
                'Function "greet": the argument "name" (string) is required but not given; '
                . 'the argument "times" has to be an integer, "often" is not; '
                . 'there is no argument "tag" (declared: name, times, tags).',
                $e->getMessage()
            );
        }
    }

    public function testAnUndefinedVariableCountsAsNotGiven(): void
    {
        $this->expectExceptionMessage('the argument "name" (string) is required but not given');

        $this->resolve([['string', 'name']], ['name' => VariablesProvider::UNDEFINED_VAR]);
    }

    public function testAnInvalidDefaultIsReported(): void
    {
        $this->expectExceptionMessage('the default of "times" has to be an integer, "many" is not');

        $this->resolve([['integer', 'times', 'many']], []);
    }

    public function testWithoutDeclaredArgumentsEverythingIsPassedOn(): void
    {
        $this->assertSame(['a' => 1, 'b' => 'x'], $this->resolve([], ['a' => 1, 'b' => 'x', 'c' => null]));
    }

    public function testASingleDeclarationIsReadAsAListOfOne(): void
    {
        // AbstractMacro::execute hands over a list of one as its only entry
        $this->assertSame(['name'], array_column(FunctionArguments::declare('f', ['string', 'name']), 'name'));
        $this->assertSame(['name'], array_column(FunctionArguments::declare('f', ['name' => 'name', 'type' => 'string']), 'name'));
        $this->assertSame(['a', 'b'], array_column(FunctionArguments::declare('f', '[["string","a"],["integer","b",1]]'), 'name'));
        $this->assertSame([], FunctionArguments::declare('f', null));
    }

    public function testAnArgumentDeclaredTwiceIsRejected(): void
    {
        $this->expectExceptionMessage('Function "f": the argument "Name" is declared twice.');

        FunctionArguments::declare('f', [['string', 'name'], ['integer', 'Name']]);
    }

    public static function values(): array
    {
        return [
            'integer from text' => ['integer', ' 42 ', 42],
            'integer from a whole float' => ['integer', 3.0, 3],
            'integer from a fraction' => ['integer', 3.5, null],
            'float from text' => ['float', '1.5', 1.5],
            'float from integer' => ['float', 2, 2.0],
            'float from words' => ['float', 'abc', null],
            'boolean from text' => ['boolean', 'yes', true],
            'boolean from 0' => ['boolean', 0, false],
            'boolean from words' => ['boolean', 'maybe', null],
            'string from a number' => ['string', 7, '7'],
            'string from a list' => ['string', ['a'], null],
            'array from JSON' => ['array', '{"a":1}', ['a' => 1]],
            'array from text' => ['array', 'abc', null],
            'mixed takes anything' => ['mixed', ['a'], ['a']],
        ];
    }

    #[DataProvider('values')]
    public function testValuesAreCheckedAgainstTheirType(string $type, mixed $given, mixed $expected): void
    {
        if ($expected === null) {
            $this->expectException(\InvalidArgumentException::class);
        }

        $this->assertSame(['value' => $expected], $this->resolve([[$type, 'value']], ['value' => $given]));
    }
}
