<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Support;

use Cehlers88\AnalyticsCore\Support\ProcedureArguments;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class ProcedureArgumentsTest extends TestCase
{
    public function testTheOldFormsAreRead(): void
    {
        $read = ProcedureArguments::read([
            ['string', 'customer'],
            ['integer', 'limit', 10],
            ['command', 'today', [['date', ['format' => 'Y-m-d']]]],
            ['string', ''],
            'nonsense',
        ]);

        $this->assertSame(['customer', 'limit', 'today'], array_column($read, 'name'));
        $this->assertTrue($read[0]['required'], 'without a default an argument has to be given');
        $this->assertSame(['limit', false, 10], [$read[1]['name'], $read[1]['required'], $read[1]['default']]);
        $this->assertTrue($read[2]['command'], 'the type "command" of workers means the default is a command');
        $this->assertSame('mixed', $read[2]['type']);
    }

    public function testWhatIsStoredIsReadBackAsItWasEntered(): void
    {
        $entered = ProcedureArguments::fromInput([
            ['name' => 'customer', 'type' => 'string', 'required' => true, 'description' => ' who '],
            ['name' => 'limit', 'type' => 'integer', 'default' => '25'],
            ['name' => 'today', 'type' => 'string', 'command' => true, 'default' => '[["date",{"format":"Y-m-d"}]]'],
        ]);

        $this->assertSame($entered, ProcedureArguments::read(ProcedureArguments::toStored($entered)));
        $this->assertSame('who', $entered[0]['description']);
        $this->assertNull($entered[0]['default'], 'a required argument has no default');
        $this->assertSame(25, $entered[1]['default']);
        $this->assertSame([['date', ['format' => 'Y-m-d']]], $entered[2]['default']);
    }

    /** @return iterable<string, array{string, mixed, mixed}> */
    public static function defaults(): iterable
    {
        yield 'integer' => ['integer', ' -3 ', -3];
        yield 'float' => ['float', '2.5', 2.5];
        yield 'boolean' => ['boolean', 'off', false];
        yield 'array' => ['array', '{"a":1}', ['a' => 1]];
        yield 'empty array' => ['array', '', []];
        yield 'string' => ['string', ' text ', ' text '];
        yield 'mixed number' => ['mixed', '42', 42];
        yield 'mixed text' => ['mixed', 'hello', 'hello'];
    }

    #[DataProvider('defaults')]
    public function testADefaultTakesTheTypeOfItsArgument(string $type, mixed $entered, mixed $stored): void
    {
        $this->assertSame($stored, ProcedureArguments::fromInput([['name' => 'x', 'type' => $type, 'default' => $entered]])[0]['default']);
    }

    /** @return iterable<string, array{list<array<string, mixed>>}> */
    public static function invalidInput(): iterable
    {
        yield 'no name' => [[['name' => '', 'type' => 'string']]];
        yield 'a name with a space' => [[['name' => 'two words', 'type' => 'string']]];
        yield 'a name twice' => [[['name' => 'a', 'type' => 'string'], ['name' => 'A', 'type' => 'string']]];
        yield 'an unknown type' => [[['name' => 'a', 'type' => 'date']]];
        yield 'no number' => [[['name' => 'a', 'type' => 'integer', 'default' => '1.5']]];
        yield 'no JSON list' => [[['name' => 'a', 'type' => 'array', 'default' => '{nope']]];
        yield 'a command without commands' => [[['name' => 'a', 'type' => 'string', 'command' => true, 'default' => '[]']]];
    }

    /** @param list<array<string, mixed>> $input */
    #[DataProvider('invalidInput')]
    public function testWhatCannotBeStoredIsRefused(array $input): void
    {
        $this->expectException(\InvalidArgumentException::class);

        ProcedureArguments::fromInput($input);
    }
}
