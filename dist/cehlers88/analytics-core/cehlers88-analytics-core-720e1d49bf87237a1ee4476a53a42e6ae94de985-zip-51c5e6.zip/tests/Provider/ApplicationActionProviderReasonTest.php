<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Provider;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\ApplicationAction;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Provider\ApplicationActionProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationActionRepository;
use Doctrine\Common\Collections\ArrayCollection;
use PHPUnit\Framework\TestCase;

/**
 * The reason of an action: set by a start - empty when none is given - and left alone by
 * everything else, so a stopped action still tells why it ran.
 */
class ApplicationActionProviderReasonTest extends TestCase
{
    protected function setUp(): void
    {
        if (!class_exists(ArrayCollection::class)) {
            $this->markTestSkipped('doctrine/collections is not installed');
        }
    }

    private function action(bool $active, string $reason = ''): ApplicationAction
    {
        return (new ApplicationAction())
            ->setName('VACATION')
            ->setDescription('')
            ->setAutoStop(false)
            ->setState($active)
            ->setReason($reason);
    }

    private function provider(ApplicationAction $action): ApplicationActionProvider
    {
        $repository = $this->createStub(ApplicationActionRepository::class);
        $repository->method('findOneBy')->willReturn($action);

        return new ApplicationActionProvider($repository, $this->createStub(MacroEnvironment::class));
    }

    public function testAStartStoresTheReasonItWasGiven(): void
    {
        $action = $this->action(false);

        $result = $this->provider($action)->startAction($this->createStub(Application::class), 'VACATION', 'two weeks off');

        $this->assertTrue($action->isActive());
        $this->assertSame('two weeks off', $action->getReason());
        $this->assertSame('two weeks off', $result['start']['reason']);
    }

    public function testAStartWithoutAReasonStoresAnEmptyOne(): void
    {
        $action = $this->action(false, 'the last time');

        $this->provider($action)->startAction($this->createStub(Application::class), 'VACATION');

        $this->assertSame('', $action->getReason());
    }

    public function testStoppingLeavesTheReason(): void
    {
        $action = $this->action(true, 'two weeks off');

        $this->provider($action)->stopAction($this->createStub(Application::class), 'VACATION');

        $this->assertFalse($action->isActive());
        $this->assertSame('two weeks off', $action->getReason());
    }

    public function testAnActionThatAlreadyRunsKeepsTheReasonItWasStartedWith(): void
    {
        $action = $this->action(true, 'two weeks off');

        $result = $this->provider($action)->startAction($this->createStub(Application::class), 'VACATION', 'something else');

        $this->assertSame('Action already started', $result['start']['message']);
        $this->assertSame('two weeks off', $action->getReason());
    }
}
