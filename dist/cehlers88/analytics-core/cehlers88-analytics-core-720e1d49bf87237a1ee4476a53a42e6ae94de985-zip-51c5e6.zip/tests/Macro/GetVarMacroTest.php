<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\GetVarMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Repository\SharedDataRepository;
use Cehlers88\AnalyticsCore\Repository\VariableStoreRepository;
use PHPUnit\Framework\TestCase;

/**
 * Without a context - or with `auto` - getVar searches GetVarMacro::AUTO_CONTEXTS in order and
 * takes the first that holds the variable.
 */
class GetVarMacroTest extends TestCase
{
    private VariablesProvider $variables;
    private MacroEnvironment $environment;

    protected function setUp(): void
    {
        $this->variables = new VariablesProvider(
            $this->createStub(VariableStoreRepository::class),
            $this->createStub(SharedDataRepository::class)
        );

        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('getVariablesStoreProvider')->willReturn($this->variables);
        $this->environment = $environment;
    }

    private function getVar(array $properties): mixed
    {
        return (new GetVarMacro())->setMacroEnvironment($this->environment)->execute($properties)['returnValue'];
    }

    public function test_auto_is_the_default_context(): void
    {
        $this->variables->setVariable('foo', 'from worker', eMacroVariableContext::WORKER);

        $this->assertSame('from worker', $this->getVar(['name' => 'foo']));
        $this->assertSame('from worker', $this->getVar(['name' => 'foo', 'context' => 'auto']));
    }

    public function test_the_first_context_in_the_order_wins(): void
    {
        $this->variables->setVariable('foo', 'from server', eMacroVariableContext::SERVER);
        $this->variables->setVariable('foo', 'from job', eMacroVariableContext::JOB);
        $this->assertSame('from job', $this->getVar(['name' => 'foo']));

        $this->variables->setArgument('foo', 'from argument');
        $this->assertSame('from argument', $this->getVar(['name' => 'foo']));
    }

    public function test_a_null_value_counts_as_found(): void
    {
        $this->variables->setVariable('foo', null, eMacroVariableContext::JOB);
        $this->variables->setVariable('foo', 'from server', eMacroVariableContext::SERVER);

        $this->assertNull($this->getVar(['name' => 'foo', 'default' => 'fallback']));
    }

    public function test_the_default_when_no_context_holds_the_variable(): void
    {
        $this->assertSame('fallback', $this->getVar(['name' => 'foo', 'default' => 'fallback']));
        $this->assertNull($this->getVar(['name' => 'foo']));
    }

    public function test_request_parameters_are_not_searched(): void
    {
        $_GET['foo'] = 'from request';
        try {
            $this->assertSame('fallback', $this->getVar(['name' => 'foo', 'default' => 'fallback']));
            $this->assertSame('from request', $this->getVar(['name' => 'foo', 'context' => 'get']));
        } finally {
            unset($_GET['foo']);
        }
    }

    public function test_a_named_context_is_read_alone(): void
    {
        $this->variables->setVariable('foo', 'from job', eMacroVariableContext::JOB);
        $this->variables->setVariable('foo', 'from server', eMacroVariableContext::SERVER);

        $this->assertSame('from server', $this->getVar(['name' => 'foo', 'context' => 'server']));
    }
}
