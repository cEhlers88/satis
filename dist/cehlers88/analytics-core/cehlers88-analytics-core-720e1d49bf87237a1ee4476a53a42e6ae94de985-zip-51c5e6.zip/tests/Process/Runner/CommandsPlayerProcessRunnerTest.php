<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Process\Runner;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Process\DTO\StartInfoDTO;
use Cehlers88\AnalyticsCore\Process\ProcessProvider;
use Cehlers88\AnalyticsCore\Process\ProcessResultWorkerProvider;
use Cehlers88\AnalyticsCore\Process\Runner\CommandsPlayerProcessRunner;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\ProcessRepository;
use PHPUnit\Framework\TestCase;

final class CommandsPlayerProcessRunnerTest extends TestCase
{
    private const COMMANDS = [['log', ['message' => 'hallo']]];

    public function testARestartedProcessRunsItsCommandsAndFinishes(): void
    {
        $process = $this->createProcess([
            'commands' => self::COMMANDS,
            'applicationId' => 3,
            'executorName' => 'Debugger (asynchron)',
        ]);

        $played = [];
        $player = $this->createMock(CommandPlayer::class);
        $player->method('run')->willReturnCallback(static function (array|string $commands) use (&$played): string {
            $played[] = $commands;
            echo 'ausgegeben';

            return 'ok';
        });

        $application = $this->createMock(Application::class);
        $applications = $this->createMock(ApplicationRepository::class);
        $applications->method('find')->with(3)->willReturn($application);

        $environment = $this->createEnvironment($player);
        $environment->expects($this->once())->method('setExecutorInfos')->with('Debugger (asynchron)', '', '7');
        $environment->expects($this->once())->method('setApplication')->with($application);

        $states = [];
        $repository = $this->createMock(ProcessRepository::class);
        $repository->method('save')->willReturnCallback(static function (Process $saved) use (&$states): Process {
            $states[] = $saved->getState();

            return $saved;
        });

        $this->createProvider($repository, new CommandsPlayerProcessRunner($environment, $applications))->runProcess($process);

        $this->assertSame([self::COMMANDS], $played);
        // saved as running before the commands run, then as finished
        $this->assertSame([[eRunningState::Running], [eRunningState::Finished]], $states);
        $this->assertNotNull($process->getStartedAt());
        $this->assertNotNull($process->getFinishedAt());
        $this->assertSame(['runner' => 'ok', 'output' => 'ausgegeben'], $process->getDetails()['result']);
    }

    public function testFailingCommandsEndTheProcessInTheErrorState(): void
    {
        $process = $this->createProcess(['commands' => self::COMMANDS]);

        $player = $this->createMock(CommandPlayer::class);
        $player->method('run')->willThrowException(new \Exception('Undefined array key 0'));

        $repository = $this->createMock(ProcessRepository::class);
        $repository->method('save')->willReturnArgument(0);

        $bufferLevel = ob_get_level();
        $this->createProvider($repository, new CommandsPlayerProcessRunner($this->createEnvironment($player)))->runProcess($process);

        $this->assertSame([eRunningState::Error], $process->getState());
        $this->assertSame(['Commands sind fehlgeschlagen: Undefined array key 0'], $process->getDetails()['errors']);
        $this->assertSame($bufferLevel, ob_get_level());
    }

    public function testReadsTheCommandsOfAnOlderCommandConsoleProcess(): void
    {
        $process = (new Process())
            ->setName('MacroExecution')
            ->setState(eRunningState::WillStart)
            ->setDetails(['start_info' => [
                'runner' => CommandsPlayerProcessRunner::class,
                'runner_arguments' => [],
                'runnerArguments' => ['commands' => self::COMMANDS],
            ]]);
        (new \ReflectionProperty($process, 'id'))->setValue($process, 7);

        $player = $this->createMock(CommandPlayer::class);
        $player->expects($this->once())->method('run')->with(self::COMMANDS)->willReturn(null);

        $repository = $this->createMock(ProcessRepository::class);
        $repository->method('save')->willReturnArgument(0);

        $this->createProvider($repository, new CommandsPlayerProcessRunner($this->createEnvironment($player)))->runProcess($process);

        $this->assertSame([eRunningState::Finished], $process->getState());
    }

    public function testAProcessWithoutCommandsFails(): void
    {
        $process = $this->createProcess([]);

        $repository = $this->createMock(ProcessRepository::class);
        $repository->method('save')->willReturnArgument(0);

        $this->createProvider($repository, new CommandsPlayerProcessRunner($this->createEnvironment($this->createMock(CommandPlayer::class))))->runProcess($process);

        $this->assertSame([eRunningState::Error], $process->getState());
        $this->assertSame(['Der Prozess enthält keine Commands zum Ausführen'], $process->getDetails()['errors']);
    }

    public function testLeavesARunningProcessAlone(): void
    {
        $process = $this->createProcess(['commands' => self::COMMANDS])->setState(eRunningState::WillStart, eRunningState::Running);

        $player = $this->createMock(CommandPlayer::class);
        $player->expects($this->never())->method('run');

        $this->createProvider($this->createMock(ProcessRepository::class), new CommandsPlayerProcessRunner($this->createEnvironment($player)))->runProcess($process);

        $this->assertTrue($process->hasState(eRunningState::Running));
    }

    /** @param array<string, mixed> $runnerArguments */
    private function createProcess(array $runnerArguments): Process
    {
        $process = (new Process())
            ->setName('Asynchron')
            ->setState(eRunningState::WillStart)
            ->setStartInfo(StartInfoDTO::create(CommandsPlayerProcessRunner::class, $runnerArguments));
        (new \ReflectionProperty($process, 'id'))->setValue($process, 7);

        return $process;
    }

    private function createEnvironment(CommandPlayer $player): MacroEnvironment&\PHPUnit\Framework\MockObject\MockObject
    {
        $environment = $this->createMock(MacroEnvironment::class);
        $environment->method('getCommandPlayer')->willReturn($player);
        $environment->method('getVariablesStoreProvider')->willReturn($this->createMock(VariablesProvider::class));

        return $environment;
    }

    private function createProvider(ProcessRepository $repository, CommandsPlayerProcessRunner $runner): ProcessProvider
    {
        return new ProcessProvider(
            $repository,
            new ObserverProvider([]),
            new ProcessResultWorkerProvider([]),
            '1 day',
            '1 day',
            '1 day',
            [$runner],
        );
    }
}
