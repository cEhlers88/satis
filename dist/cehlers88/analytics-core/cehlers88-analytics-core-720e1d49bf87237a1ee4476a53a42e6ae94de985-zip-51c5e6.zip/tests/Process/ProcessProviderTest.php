<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Process;

use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\Process\DTO\StartInfoDTO;
use Cehlers88\AnalyticsCore\Process\ProcessProvider;
use Cehlers88\AnalyticsCore\Process\ProcessResultWorkerProvider;
use Cehlers88\AnalyticsCore\Process\Runner\AbstractProcessRunner;
use Cehlers88\AnalyticsCore\Repository\ProcessRepository;
use PHPUnit\Framework\TestCase;

final class ProcessProviderTest extends TestCase
{
    public function testAFailingRunnerEndsTheProcessInTheErrorState(): void
    {
        $process = (new Process())
            ->setState(eRunningState::WillStart, eRunningState::Running)
            ->setStartInfo(StartInfoDTO::create(FailingProcessRunner::class, []));

        $repository = $this->createMock(ProcessRepository::class);
        $repository->expects($this->once())->method('save')->with($process)->willReturn($process);

        $this->createProvider($repository)->runProcess($process);

        $this->assertSame([eRunningState::Error], $process->getState());
        $this->assertNotNull($process->getFinishedAt());
        $this->assertSame(['Command "kaputt" ist fehlgeschlagen'], $process->getDetails()['errors']);
    }

    public function testAnAbortedProcessIsNoLongerRunning(): void
    {
        $process = (new Process())->setState(eRunningState::Running);

        $repository = $this->createMock(ProcessRepository::class);
        $repository->method('find')->with(3)->willReturn($process);
        $repository->expects($this->once())->method('save')->with($process)->willReturn($process);

        $this->createProvider($repository)->setProcessAbort(3, ['aborted' => true]);

        $this->assertSame([eRunningState::Canceled], $process->getState());
        $this->assertNotNull($process->getFinishedAt());
        $this->assertSame(['aborted' => true], $process->getDetails()['result']);
    }

    private function createProvider(ProcessRepository $repository): ProcessProvider
    {
        return new ProcessProvider(
            $repository,
            new ObserverProvider([]),
            new ProcessResultWorkerProvider([]),
            '1 day',
            '1 day',
            '1 day',
        );
    }
}

final class FailingProcessRunner extends AbstractProcessRunner
{
    public function handle(): void
    {
        throw new \RuntimeException('Command "kaputt" ist fehlgeschlagen');
    }
}
