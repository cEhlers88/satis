<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Player;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Command;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Macro\Debugger\SilentDebugger;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Player\MacroPlayer;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

/**
 * A definition is run again - the content of a function on every call, the body of a loop on
 * every pass - so running it must leave its commands in place for the next run.
 */
class CommandPlayerTest extends TestCase
{
    /** What "next" hands out, one value per run. @var list<string> */
    private array $values = [];

    private function player(): CommandPlayer
    {
        $commandFactory = $this->createStub(CommandFactory::class);
        $commandFactory->method('getCommandByName')->willReturnCallback(
            static fn(string $name): Command => (new Command())->setMacro($name)->setNeedPrecompiledArguments(true)
        );

        $macroPlayer = $this->createStub(MacroPlayer::class);
        $macroPlayer->method('executeMacro')->willReturnCallback(function (string $macro, array $args): array {
            return ['returnValue' => $macro === 'next' ? array_shift($this->values) : $args['output']];
        });

        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('getDebugger')->willReturn(new SilentDebugger());
        $environment->method('getMacroPlayer')->willReturn($macroPlayer);

        return (new CommandPlayer($commandFactory))->setMacroEnvironment($environment);
    }

    private function command(string $name, array $properties = []): CommandDTO
    {
        $command = new CommandDTO();
        $command->commandName = $name;
        $command->properties = $properties;

        return $command;
    }

    /** @return array<string, array{PropertyDTO}> */
    public static function outputs(): array
    {
        $next = static function (): CommandDTO {
            $command = new CommandDTO();
            $command->commandName = 'next';

            return $command;
        };
        $subCommand = PropertyDTO::create('output', $next());
        $subCommand->hasSubCommand = true;

        return [
            'a command as value' => [PropertyDTO::create('output', $next())],
            'a property holding a command' => [PropertyDTO::create('output', $subCommand)],
            'a list with a command in it' => [PropertyDTO::create('output', ['a', $next()])],
        ];
    }

    #[DataProvider('outputs')]
    public function testADefinitionRunTwiceRunsItsCommandsTwice(PropertyDTO $output): void
    {
        $definition = $this->command('echo', [$output]);
        $player = $this->player();
        $this->values = ['test1', 'test2'];

        $first = $player->run($definition);
        $second = $player->run($definition);

        $this->assertNotEquals($first, $second);
        $this->assertSame([], $this->values, 'both values were taken');
        $this->assertStringContainsString('test2', json_encode($second));
    }
}
