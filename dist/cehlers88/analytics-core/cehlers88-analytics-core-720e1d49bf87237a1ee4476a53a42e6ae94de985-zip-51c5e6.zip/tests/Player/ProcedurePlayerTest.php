<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Player;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\Procedure;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Player\ProcedurePlayer;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Repository\ProcedureRepository;
use Cehlers88\AnalyticsCore\Repository\SharedDataRepository;
use Cehlers88\AnalyticsCore\Repository\VariableStoreRepository;
use Doctrine\Common\Collections\ArrayCollection;
use PHPUnit\Framework\TestCase;

/**
 * A procedure's properties are its arguments: given or defaulted, commands among them run
 * first, readable in the context "argument" while it runs and gone afterwards.
 */
class ProcedurePlayerTest extends TestCase
{
    private VariablesProvider $variables;

    /** What the procedure's commands saw as arguments, per run. @var list<array<string, mixed>> */
    private array $seen = [];

    protected function setUp(): void
    {
        if (!class_exists(ArrayCollection::class)) {
            $this->markTestSkipped('doctrine/collections is not installed');
        }
        $this->variables = new VariablesProvider(
            $this->createStub(VariableStoreRepository::class),
            $this->createStub(SharedDataRepository::class)
        );
    }

    private function procedure(array $properties, string $name = 'greet', bool $enabled = true): Procedure
    {
        return (new Procedure())
            ->setName($name)
            ->setContent([['MARKER', $name]])
            ->setProperties($properties)
            ->setComments([])
            ->setEnabled($enabled);
    }

    /** @param list<Procedure> $procedures */
    private function player(array $procedures, ?callable $onContent = null): ProcedurePlayer
    {
        $repository = $this->createStub(ProcedureRepository::class);
        $repository->method('findOneBy')->willReturnCallback(static function (array $criteria) use ($procedures) {
            foreach ($procedures as $procedure) {
                if ($procedure->getName() === $criteria['name']) {
                    return $procedure;
                }
            }

            return null;
        });

        $commandPlayer = $this->createStub(CommandPlayer::class);
        $commandPlayer->method('run')->willReturnCallback(function (mixed $definition) use ($onContent) {
            // the content of a procedure: record its arguments
            if (is_array($definition) && ($definition[0][0] ?? null) === 'MARKER') {
                $this->seen[] = array_column(array_map(static fn($argument) => (array)$argument, $this->variables->getVariables(eMacroVariableContext::ARGUMENT)), 'value', 'name');
                if ($onContent !== null) {
                    return $onContent($definition[0][1]);
                }

                return 'ran ' . $definition[0][1];
            }

            // a command that produces a value: ["upper", "text"]
            return strtoupper((string)($definition[0][1] ?? ''));
        });

        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('getVariablesStoreProvider')->willReturn($this->variables);
        $environment->method('getCommandPlayer')->willReturn($commandPlayer);

        return new ProcedurePlayer($environment, $repository);
    }

    public function testGivenArgumentsAndDefaultsAreReadableWhileTheProcedureRuns(): void
    {
        $player = $this->player([$this->procedure([['string', 'name'], ['integer', 'times', 2]])]);

        $result = $player->startProcedure('greet', ['name' => 'Ada']);

        $this->assertSame('ran greet', $result);
        $this->assertSame([['name' => 'Ada', 'times' => 2]], $this->seen);
        $this->assertSame(VariablesProvider::UNDEFINED_VAR, $this->variables->getArgument('name'), 'the arguments are gone once it ran');
    }

    public function testADefaultThatIsACommandIsRunFirst(): void
    {
        $player = $this->player([$this->procedure([['string', 'shout', [['upper', 'hello']], ['required' => false, 'command' => true, 'description' => '']]])]);

        $player->startProcedure('greet', []);

        $this->assertSame([['shout' => 'HELLO']], $this->seen);
    }

    public function testAMissingRequiredArgumentStopsTheProcedure(): void
    {
        $result = $this->player([$this->procedure([['string', 'name']])])->startProcedure('greet', []);

        $this->assertInstanceOf(ErrorDTO::class, $result);
        $this->assertSame([], $this->seen, 'nothing ran');
    }

    public function testAnUnknownOrDisabledProcedureIsAnError(): void
    {
        $player = $this->player([$this->procedure([], 'off', false)]);

        $this->assertInstanceOf(ErrorDTO::class, $player->startProcedure('missing', []));
        $this->assertInstanceOf(ErrorDTO::class, $player->startProcedure('off', []));
    }

    public function testAProcedureInsideAProcedureHasItsOwnArgumentsAndTheOuterOnesAreBackAfterwards(): void
    {
        $outer = $this->procedure([['string', 'who']], 'outer');
        $inner = $this->procedure([['string', 'who']], 'inner');
        $player = null;
        $player = $this->player([$outer, $inner], function (string $name) use (&$player) {
            if ($name === 'outer') {
                $player->startProcedure('inner', ['who' => 'inner value']);

                return $this->variables->getArgument('who');
            }

            return null;
        });

        $result = $player->startProcedure('outer', ['who' => 'outer value']);

        $this->assertSame('outer value', $result, 'the inner procedure took only its own arguments away');
        $this->assertSame('inner value', $this->seen[1]['who'] ?? null);
        $this->assertSame([], $this->variables->getVariables(eMacroVariableContext::ARGUMENT));
    }

    public function testTheArgumentsAreGoneAlsoWhenTheProcedureFails(): void
    {
        $player = $this->player([$this->procedure([['string', 'name']])], static function (): never {
            throw new \RuntimeException('a command failed');
        });

        try {
            $player->startProcedure('greet', ['name' => 'Ada']);
            $this->fail('the failure is passed on');
        } catch (\RuntimeException) {
        }

        $this->assertSame([], $this->variables->getVariables(eMacroVariableContext::ARGUMENT));
    }
}
