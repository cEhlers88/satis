<?php

namespace Cehlers88\AnalyticsCore\Player;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\DTO\ConditionGroupDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\ENUM\eInstructionType;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;

class CommandPlayer
{
    private ?LoggerInterface $_logger = null;
    private MacroEnvironment $macroEnvironment;

    public function __construct(
        private CommandFactory $commandFactory
    )
    {
    }

    /**
     * Whether the definition describes registered commands - run() hands anything else
     * back as it is, so a caller that must not take a definition for a value asks first.
     */
    public function describesCommands(array $definition): bool
    {
        return $definition !== [] && $this->commandFactory->evalDefinitionArray($definition, true) instanceof CommandGroupDTO;
    }

    public function run(CommandGroupDTO|CommandDTO|PropertyDTO|array|string $commandDefinitionArray): mixed
    {
        $result = [];

        if ($commandDefinitionArray instanceof CommandDTO) {
            // A single, already evaluated command (e.g. handed over by a macro
            // which received a nested command definition as argument).
            $commandDefinitionArray = [$commandDefinitionArray];
        }

        if (
            !$commandDefinitionArray instanceof CommandGroupDTO &&
            is_array($commandDefinitionArray) &&
            count($commandDefinitionArray) > 0 &&
            $commandDefinitionArray[0] instanceof CommandDTO
        ) {
            $evaluatedDefinition = new CommandGroupDTO();
            foreach ($commandDefinitionArray as $commandDefinition) {
                $evaluatedDefinition->commands[] = $commandDefinition;
            }
        } else {
            if ($commandDefinitionArray instanceof PropertyDTO) {
                $evaluatedDefinition = new CommandGroupDTO();
                $evaluatedDefinition->commands = [$commandDefinitionArray->value];
            } else if ($commandDefinitionArray instanceof CommandGroupDTO) {
                $evaluatedDefinition = $commandDefinitionArray;
            } else {
                $tmp = $commandDefinitionArray;
                $commandDefinitionArray = is_string($commandDefinitionArray) ? json_decode($commandDefinitionArray, true) : $commandDefinitionArray;
                if (is_null($commandDefinitionArray)) {
                    return $tmp;
                }
                $evaluatedDefinition = $this->commandFactory->evalDefinitionArray($commandDefinitionArray, true);
            }
        }

        if ($evaluatedDefinition instanceof CommandGroupDTO) {
            foreach ($evaluatedDefinition->commands as $commandDto) {
                if (is_null($commandDto)) {
                    $result[] = null;
                    continue;
                }

                $currResult = $this->_executeCommandDto($commandDto);

                if ((!is_array($currResult) || !isset($currResult['__void']) || !$currResult['__void']) &&
                    (!is_string($currResult) || (is_string($currResult) && trim($currResult) !== ''))) {
                    $result[] = $currResult;
                }
            }
        } else {
            $result = $evaluatedDefinition;
        }


        $result = count($result) !== 1 ? $result : $result[0];

        return $result;
    }

    private function _executeCommandDto(CommandDTO $commandDto): mixed
    {
        $resolvedProperties = [];
        $instructionId = $this->macroEnvironment->getNextInstructionId();

        $this->macroEnvironment->getDebugger()->logStart(
            eInstructionType::COMMAND,
            $instructionId,
            $commandDto->commandName,
            $commandDto->properties
        );
        /*
        $this->macroEnvironment->getDebugger()->attachLog(
            eDebuggerLogType::INFO,
            "Additional info for command '".$commandDto->commandName."' (ID:".$instructionId.")",
            [
                'address' => $commandDto->address,
            ]
        );*/

        $commandEntity = $this->commandFactory->getCommandByName($commandDto->commandName);
        if (is_null($commandEntity)) {
            $errorMsg = "Command '" . $commandDto->commandName . "' not found.";
            $this->macroEnvironment->getDebugger()->attachLog(
                eDebuggerLogType::ERROR,
                $errorMsg,
                []
            );
            throw new \Exception($errorMsg);
        }
        $macroName = $commandEntity->getMacro();
        if ($macroName === '') {
            $errorMsg = "Command '" . $commandDto->commandName . "' has no macro defined.";
            $this->macroEnvironment->getDebugger()->attachLog(
                eDebuggerLogType::ERROR,
                $errorMsg,
                []
            );
            throw new \Exception($errorMsg);
        }
        // The results go into copies, never into $commandDto: a definition is run again
        // - the content of a function on every call, the body of a loop on every pass -
        // and has to find its commands there next time, not the values of the last run.
        foreach ($commandDto->properties as $property) {
            if ($property->value instanceof PropertyDTO) {
                $commandProperty = $property->value;
                if ($commandEntity->isNeedPrecompiledArguments() && $commandProperty->hasSubCommand) {

                    $subResult = $this->_executeCommandDto($commandProperty->value);
                    $commandProperty = clone $commandProperty;
                    if (!isset($subResult['__void']) || !$subResult['__void']) {
                        $commandProperty->value = $subResult;
                    }
                    $commandProperty->hasSubCommand = false;
                    $property = clone $property;
                    $property->value = $commandProperty;
                }

                $resolvedProperties[] = $property;
            } else {
                if ($property->value instanceof CommandDTO) {
                    $value = $property->value;
                    if ($commandEntity->isNeedPrecompiledArguments()) {
                        $value = $this->_executeCommandDto($value);
                    }
                    $resolvedProperties[] = PropertyDTO::create($property->name, $value);
                } else {
                    if ($property->value instanceof ConditionGroupDTO) {
                        // A macro that takes its arguments as they are - `if` -
                        // decides the condition itself and stops at the first
                        // value that settles it, so nothing is run ahead of it.
                        if ($commandEntity->isNeedPrecompiledArguments()) {
                            // Handed on as a property of its own, so the
                            // definition keeps its commands for the next run.
                            $property = PropertyDTO::create($property->name, $this->_precompileConditionGroup($property->value), $property->type);
                        }
                    } else {
                        if (is_array($property->value)) {
                            $values = [];
                            foreach ($property->value as $key => $value) {
                                if ($value instanceof CommandDTO && $commandEntity->isNeedPrecompiledArguments()) {
                                    $value = $this->_executeCommandDto($value);
                                }
                                $values[$key] = $value;
                            }
                            $property = clone $property;
                            $property->value = $values;
                        }
                    }
                    $resolvedProperties[] = $property;
                }
            }

        }
        $macroArgs = [];
        foreach ($resolvedProperties as $resolvedProperty) {
            $macroArgs[$resolvedProperty->name] = $resolvedProperty->value;
        }

        // todo: die überschreibung sollte schon beim auswerten der properties passieren um keine möglicherweise ungewollten commands auszuführen die als parameter angegeben wurden
        foreach ($commandEntity->getMacroPropsOverwrites() as $key => $value) {
            $macroArgs[$key] = $value;
        }

        $macroResult = $this->macroEnvironment
            ->getMacroPlayer()
            ->executeMacro($macroName, $macroArgs);

        $hasError = !empty($macroResult['error'] ?? '');
        $errorMessage = $macroResult['error'] ?? $macroResult['message'] ?? 'Unknown macro error';

        if ($hasError) {
            $this->macroEnvironment->getDebugger()->attachLog(
                eDebuggerLogType::ERROR,
                $errorMessage,
                []
            );
        }

        $this->macroEnvironment->getDebugger()->logEnd(
            eInstructionType::COMMAND,
            $instructionId,
            $macroResult
        );

        if ($hasError) {
            throw new \Exception($errorMessage);
        }

        return $macroResult['returnValue'];
    }

    /**
     * The group with every command in it run, nested groups included. A copy:
     * the group may be part of a definition that runs again - inside a loop,
     * say - and has to find its commands there next time.
     */
    private function _precompileConditionGroup(ConditionGroupDTO $group): ConditionGroupDTO
    {
        $values = [];
        foreach ($group->conditionValues as $key => $value) {
            if ($value instanceof CommandDTO) {
                $value = $this->_executeCommandDto($value);
            } else if ($value instanceof ConditionGroupDTO) {
                $value = $this->_precompileConditionGroup($value);
            }
            $values[$key] = $value;
        }

        return ConditionGroupDTO::create($values, $group->type);
    }

    public function setApplication(Application $application): CommandPlayer
    {
        $this->macroEnvironment->setApplication($application);
        return $this;
    }

    public function setMacroEnvironment(MacroEnvironment $macroEnvironment): CommandPlayer
    {
        $this->macroEnvironment = $macroEnvironment;
        return $this;
    }

    public function getApplication(): Application
    {
        return $this->macroEnvironment->getApplication();
    }

    public function getVariablesStoreProvider(): VariablesProvider
    {
        return $this->macroEnvironment->getVariablesStoreProvider();
    }
}