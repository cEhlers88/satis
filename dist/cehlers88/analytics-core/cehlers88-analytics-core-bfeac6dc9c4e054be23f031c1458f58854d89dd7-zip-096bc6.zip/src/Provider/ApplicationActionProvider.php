<?php

namespace Cehlers88\AnalyticsCore\Provider;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\ApplicationAction;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Repository\ApplicationActionRepository;

class ApplicationActionProvider
{
    public function __construct(
        private ApplicationActionRepository $applicationActionRepository,
        private MacroEnvironment            $macroEnvironment
    )
    {

    }

    /**
     * @param string|null $reason why the action is started; stored on the action, empty when
     *                            none is given. An action that already runs keeps the reason
     *                            it was started with.
     */
    public function startAction(Application $application, string $actionName, ?string $reason = null): array
    {
        $result = [
            'start' => [
                'action' => $actionName,
                'message' => ''
            ]
        ];

        $action = $this->applicationActionRepository->findOneBy([
            'application' => $application,
            'name' => $actionName
        ]);

        if (is_null($action)) {
            throw new \Exception(sprintf('No Application-Action with name "%s" in Application %s found',
                $actionName,
                $application->getName()
            ), 404);
        }

        if ($action->isActive()) {
            $result['start']['message'] = 'Action already started';
        } else {
            $action->setState(true);
            $action->setReason($reason);
            $this->applicationActionRepository->save($action);
            $result['start']['reason'] = $action->getReason();

            $startCommands = $action->getStartCommands();
            if (!empty($startCommands)) {
                $this->macroEnvironment->setApplication($application);

                $result['start']['commandsResult'] = $this->macroEnvironment->getCommandPlayer()->run($startCommands);
            }
            $this->onStart($action);

            $result['start']['message'] = 'Action started';

            if ($action->isAutoStop()) {
                $result['end'] = $this->stopAction($application, $actionName);
            }
        }

        return $result;
    }

    public function stopAction(Application $application, string $actionName): array
    {
        $result = [
            'action' => $actionName
        ];
        $action = $this->applicationActionRepository->findOneBy([
            'application' => $application,
            'name' => $actionName
        ]);

        if (is_null($action)) {
            throw new \Exception('Action not found');
        }

        if (!$action->isActive()) {
            $result['message'] = 'Action already stopped';
            return $result;
        }

        $action->setState(false);
        $this->applicationActionRepository->save($action);

        $stopCommands = $action->getStopCommands();
        if (!empty($stopCommands)) {
            $this->macroEnvironment->setApplication($application);
            $result['commandsResult'] = $this->macroEnvironment->getCommandPlayer()->run($stopCommands);
        }
        $this->onStop($action);

        return $result;
    }

    private function onStart(ApplicationAction $action){}
    private function onStop(ApplicationAction $action){}
}