<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Player;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\Command;
use Cehlers88\AnalyticsCore\ENUM\eInstructionType;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Macro\Debugger\IMacroDebugger;
use Cehlers88\AnalyticsCore\Macro\Debugger\SilentDebugger;
use Cehlers88\AnalyticsCore\Macro\GetVarMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\Protector\DemoModeMacroProtector;
use Cehlers88\AnalyticsCore\Macro\ReturnMacro;
use Cehlers88\AnalyticsCore\Macro\SetVarMacro;
use Cehlers88\AnalyticsCore\Macro\ThrowMacro;
use Cehlers88\AnalyticsCore\Macro\TryCatchMacro;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Player\MacroPlayer;
use Cehlers88\AnalyticsCore\Process\ProcessProvider;
use Cehlers88\AnalyticsCore\Provider\MacroExtensionProvider;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\CommandRepository;
use Cehlers88\AnalyticsCore\Repository\ProcessRepository;
use Cehlers88\AnalyticsCore\Repository\SharedDataRepository;
use Cehlers88\AnalyticsCore\Repository\VariableStoreRepository;
use Doctrine\Common\Collections\ArrayCollection;
use PHPUnit\Framework\TestCase;

/**
 * try_catch and throw run by the real players: the errors come out of them the
 * way they do in a run, and the debugger stays in step once one was caught.
 */
class TryCatchRunTest extends TestCase
{
    private CommandPlayer $player;
    private IMacroDebugger $debugger;

    protected function setUp(): void
    {
        if (!class_exists(ArrayCollection::class)) {
            $this->markTestSkipped('doctrine/collections is not installed');
        }

        $definitions = [
            'try_catch' => ['tryCatch', [['array', 'try'], ['array', 'catch', []], ['array', 'finally', []], ['string', 'errorVar', 'error']], false],
            'throw' => ['throw', [['mixed', 'message', ThrowMacro::DEFAULT_MESSAGE]], true],
            'return' => ['return', [['string', 'value']], true],
            'set_var' => ['setVar', [['string', 'name'], ['mixed', 'value'], ['string', 'context', 'JOB']], true],
            'get_var' => ['getVar', [['string', 'name'], ['string', 'context', 'JOB'], ['mixed', 'default', '']], true],
        ];
        $commands = [];
        foreach ($definitions as $name => [$macro, $props, $precompiled]) {
            $commands[] = (new Command())->setName($name)->setMacro($macro)->setMacroProps($props)
                ->setNeedPrecompiledArguments($precompiled)->setResultType('mixed');
        }
        $commandRepository = $this->createStub(CommandRepository::class);
        $commandRepository->method('findAll')->willReturn($commands);

        $macroPlayer = new MacroPlayer(
            [new TryCatchMacro(), new ThrowMacro(), new ReturnMacro(), new SetVarMacro(), new GetVarMacro()],
            [new DemoModeMacroProtector()],
            new MacroExtensionProvider([]),
            $this->createStub(ApplicationRepository::class)
        );
        $this->player = new CommandPlayer(new CommandFactory($commandRepository));
        $this->debugger = new class extends SilentDebugger {
            /** @var list<int> */
            public array $running = [];
            /** @var list<array{int, ?int}> ended, last started */
            public array $outOfStep = [];

            public function logStart(eInstructionType $instructionType, int $instructionId, string $instructionName, mixed $instructionArgs): IMacroDebugger
            {
                $this->running[] = $instructionId;

                return $this;
            }

            public function logEnd(eInstructionType $instructionType, int $instructionId, mixed $instructionResult): IMacroDebugger
            {
                $last = array_pop($this->running);
                if ($last !== $instructionId) {
                    $this->outOfStep[] = [$instructionId, $last];
                }

                return $this;
            }
        };

        $environment = new MacroEnvironment(
            $this->createStub(ApplicationRepository::class),
            new VariablesProvider($this->createStub(VariableStoreRepository::class), $this->createStub(SharedDataRepository::class)),
            $macroPlayer,
            $this->player,
            $this->createStub(ProcessProvider::class),
            $this->createStub(ProcessRepository::class),
            $this->debugger
        );
        $environment->setApplication((new Application())->setName('Test')->setToken('test-token')->setColor('#000000'));
    }

    public function testCatchReadsTheMessageOfAThrowAndFinallyRuns(): void
    {
        $result = $this->player->run(['try_catch', [
            'try' => [
                ['throw', ['message' => 'no customer given']],
                ['return', ['value' => 'not reached']],
            ],
            'catch' => ['return', ['value' => ['get_var', ['name' => 'problem']]]],
            'finally' => ['set_var', ['name' => 'cleanedUp', 'value' => 'yes']],
            'errorVar' => 'problem',
        ]]);

        $this->assertSame('no customer given', $result);
        $this->assertSame('yes', $this->player->run(['get_var', ['name' => 'cleanedUp']]));
        $this->assertSame([], $this->debugger->outOfStep);
        $this->assertSame([], $this->debugger->running);
    }

    public function testAnOuterTryCatchCatchesWhatAnInnerCatchThrowsAgain(): void
    {
        $result = $this->player->run(['try_catch', [
            'try' => ['try_catch', [
                'try' => ['throw', ['message' => 'inner']],
                'catch' => ['throw', ['message' => ['get_var', ['name' => 'error']]]],
            ]],
            'catch' => ['return', ['value' => ['get_var', ['name' => 'outer']]]],
            'errorVar' => 'outer',
        ]]);

        $this->assertSame('inner', $result);
        $this->assertSame([], $this->debugger->outOfStep);
        $this->assertSame([], $this->debugger->running);
    }

    public function testAnUncaughtThrowEndsTheRun(): void
    {
        $this->expectExceptionMessage('uncaught');

        $this->player->run(['throw', ['message' => 'uncaught']]);
    }
}
