<?php

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\AggregateMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class AggregateMacroTest extends TestCase
{
    private const array BOOKINGS = [
        ['category' => 'rent', 'amount' => 800, 'meta' => ['hours' => 1]],
        ['category' => 'food', 'amount' => '45.5', 'meta' => ['hours' => 2]],
        ['category' => 'food', 'amount' => 14.5],
        ['category' => 'misc', 'amount' => 'n/a'],
    ];

    public static function dataProviderForOperations(): array
    {
        return [
            'count of entries' => [['data' => self::BOOKINGS], 4],
            'count of a field skips missing values' => [['data' => self::BOOKINGS, 'field' => 'meta.hours'], 2],
            'sum ignores what is no number' => [['data' => self::BOOKINGS, 'operation' => 'sum', 'field' => 'amount'], 860.0],
            'avg' => [['data' => self::BOOKINGS, 'operation' => 'avg', 'field' => 'amount'], 860 / 3],
            'min' => [['data' => self::BOOKINGS, 'operation' => 'min', 'field' => 'amount'], 14.5],
            'max' => [['data' => self::BOOKINGS, 'operation' => 'MAX', 'field' => 'amount'], 800],
            'nested field' => [['data' => self::BOOKINGS, 'operation' => 'sum', 'field' => 'meta.hours'], 3],
            'plain values' => [['data' => [3, 4, 5], 'operation' => 'sum'], 12],
            'keyed values' => [['data' => ['jan' => 5, 'feb' => 7], 'operation' => 'sum'], 12],
            'single entry reaches the macro unwrapped' => [['data' => [['amount' => 7]], 'operation' => 'sum', 'field' => 'amount'], 7],
            'avg of nothing' => [['data' => [], 'operation' => 'avg'], null],
            'sum of nothing' => [['data' => [], 'operation' => 'sum'], 0],
        ];
    }

    #[DataProvider('dataProviderForOperations')]
    public function test_operation(array $arguments, int|float|null $expected): void
    {
        $result = $this->createMacro()->execute($arguments);

        $this->assertFalse($result['hasError']);
        $this->assertSame($expected, $result['returnValue']);
    }

    public function test_groups_get_a_figure_each(): void
    {
        $grouped = [
            'rent' => [['amount' => 800]],
            'food' => [['amount' => 45.5], ['amount' => 14.5]],
        ];

        $result = $this->createMacro()->execute([
            'data' => $grouped,
            'operation' => 'sum',
            'field' => 'amount',
            'groups' => true,
        ]);

        $this->assertSame(['rent' => 800, 'food' => 60.0], $result['returnValue']);
    }

    public function test_unknown_operation_is_an_error(): void
    {
        $result = $this->createMacro()->execute(['data' => [1, 2], 'operation' => 'median']);

        $this->assertTrue($result['hasError']);
        $this->assertSame(422, $result['error']->number);
    }

    private function createMacro(): AggregateMacro
    {
        $macro = new AggregateMacro();
        $macro->setMacroEnvironment($this->createMock(MacroEnvironment::class));

        return $macro;
    }
}
