<?php

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\SendPushNotificationMacro;
use Cehlers88\AnalyticsCore\Notification\PushNotificationSenderInterface;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class SendPushNotificationMacroTest extends TestCase
{
    public function test_sends_to_a_channel(): void
    {
        $sender = $this->createMock(PushNotificationSenderInterface::class);
        $sender->expects($this->once())
            ->method('send')
            ->with('Backup', 'Backup is done', 'system', null, ['url' => '/dashboard/workers'])
            ->willReturn(['sent' => 2, 'failed' => 0]);

        $result = $this->createMacro($sender)->execute([
            'title' => 'Backup',
            'body' => 'Backup is done',
            'channel' => 'system',
            'url' => '/dashboard/workers',
        ]);

        $this->assertFalse($result['hasError']);
        $this->assertSame(['sent' => 2, 'failed' => 0], $result['returnValue']);
    }

    public function test_sends_to_a_user(): void
    {
        $sender = $this->createMock(PushNotificationSenderInterface::class);
        $sender->expects($this->once())
            ->method('send')
            ->with('Hi', '', null, 7, [])
            ->willReturn(['sent' => 1, 'failed' => 0]);

        $result = $this->createMacro($sender)->execute(['title' => 'Hi', 'userId' => 7]);

        $this->assertFalse($result['hasError']);
    }

    public static function dataProviderForIncompleteArguments(): array
    {
        return [
            'no title' => [['title' => '  ', 'channel' => 'system']],
            'neither channel nor user' => [['title' => 'Hi']],
        ];
    }

    #[DataProvider('dataProviderForIncompleteArguments')]
    public function test_incomplete_arguments_send_nothing(array $arguments): void
    {
        $sender = $this->createMock(PushNotificationSenderInterface::class);
        $sender->expects($this->never())->method('send');

        $result = $this->createMacro($sender)->execute($arguments);

        $this->assertTrue($result['hasError']);
        $this->assertSame(422, $result['error']->number);
    }

    public function test_without_sender_it_is_an_error(): void
    {
        $result = $this->createMacro(null)->execute(['title' => 'Hi', 'channel' => 'system']);

        $this->assertTrue($result['hasError']);
        $this->assertSame(501, $result['error']->number);
    }

    public function test_a_failing_sender_is_an_error(): void
    {
        $sender = $this->createMock(PushNotificationSenderInterface::class);
        $sender->method('send')->willThrowException(new \RuntimeException('VAPID keys missing'));

        $result = $this->createMacro($sender)->execute(['title' => 'Hi', 'channel' => 'system']);

        $this->assertTrue($result['hasError']);
        $this->assertSame('VAPID keys missing', $result['error']->message);
    }

    private function createMacro(?PushNotificationSenderInterface $sender): SendPushNotificationMacro
    {
        $macro = new SendPushNotificationMacro($sender);
        $macro->setMacroEnvironment($this->createMock(MacroEnvironment::class));

        return $macro;
    }
}
