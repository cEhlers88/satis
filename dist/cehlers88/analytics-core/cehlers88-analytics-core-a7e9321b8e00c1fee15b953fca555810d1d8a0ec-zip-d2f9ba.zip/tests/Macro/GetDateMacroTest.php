<?php

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Macro\GetDateMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class GetDateMacroTest extends TestCase
{
    public static function dataProviderForDates(): array
    {
        return [
            'formatted' => [['date' => '2026-10-21 07:30:00', 'format' => 'd.m.Y'], '21.10.2026'],
            'moved back a month' => [['date' => '2026-10-21', 'modify' => '-1 month', 'format' => 'Y-m-d'], '2026-09-21'],
            'first day of last month' => [['date' => '2026-03-31', 'modify' => 'first day of last month', 'format' => 'Y-m-d'], '2026-02-01'],
            'last day of this month' => [['date' => '2024-02-10', 'modify' => 'last day of this month', 'format' => 'Y-m-d'], '2024-02-29'],
            'timestamp in' => [['date' => 1792569600, 'format' => 'Y-m-d H:i', 'timezone' => 'UTC'], '2026-10-21 08:00'],
            'timestamp as text' => [['date' => '1792569600', 'format' => 'Y-m-d H:i', 'timezone' => 'Europe/Berlin'], '2026-10-21 10:00'],
            'timestamp out' => [['date' => '2026-10-21 08:00:00', 'format' => 'U', 'timezone' => 'UTC'], 1792569600],
            'default format' => [['date' => '2026-10-21 07:30:00'], '2026-10-21 07:30:00'],
        ];
    }

    #[DataProvider('dataProviderForDates')]
    public function test_date(array $arguments, string|int $expected): void
    {
        $result = $this->createMacro()->execute($arguments);

        $this->assertFalse($result['hasError']);
        $this->assertSame($expected, $result['returnValue']);
    }

    public function test_now_is_the_default(): void
    {
        $before = time();
        $result = $this->createMacro()->execute(['format' => 'U'])['returnValue'];

        $this->assertGreaterThanOrEqual($before, $result);
        $this->assertLessThanOrEqual(time(), $result);
    }

    public static function dataProviderForInvalidArguments(): array
    {
        return [
            'invalid date' => [['date' => 'no date at all']],
            'invalid modification' => [['modify' => 'whenever it fits']],
            'unknown timezone' => [['timezone' => 'Mars/Olympus']],
        ];
    }

    #[DataProvider('dataProviderForInvalidArguments')]
    public function test_invalid_arguments_are_an_error(array $arguments): void
    {
        $result = $this->createMacro()->execute($arguments);

        $this->assertTrue($result['hasError']);
        $this->assertSame(422, $result['error']->number);
        $this->assertNull($result['returnValue']);
    }

    private function createMacro(): GetDateMacro
    {
        $macro = new GetDateMacro();
        $macro->setMacroEnvironment($this->createMock(MacroEnvironment::class));

        return $macro;
    }
}
