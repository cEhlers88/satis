<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Tests\Macro;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Macro\Exception\ThrownByDefinitionException;
use Cehlers88\AnalyticsCore\Macro\Exception\UncatchableExceptionInterface;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\ThrowMacro;
use Cehlers88\AnalyticsCore\Macro\TryCatchMacro;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Player\MacroPlayer;
use PHPUnit\Framework\TestCase;

class TryCatchMacroTest extends TestCase
{
    /** @var list<string> the commands that ran, in order */
    private array $ran = [];
    /** @var array<string, mixed> the variables setVar wrote */
    private array $variables = [];

    public function test_returns_what_try_returns_when_nothing_fails(): void
    {
        $result = $this->macro()->execute([
            'try' => [$this->command('work')],
            'catch' => [$this->command('handle')],
            'finally' => [$this->command('cleanUp')],
        ]);

        $this->assertSame('work', $result['returnValue']);
        $this->assertSame(['work', 'cleanUp'], $this->ran);
        $this->assertSame([], $this->variables);
    }

    public function test_runs_catch_with_the_message_in_the_error_variable_when_try_fails(): void
    {
        $result = $this->macro()->execute([
            'try' => [$this->command('fail')],
            'catch' => [$this->command('handle')],
            'finally' => [$this->command('cleanUp')],
            'errorVar' => 'problem',
        ]);

        $this->assertSame('handle', $result['returnValue']);
        $this->assertSame(['fail', 'handle', 'cleanUp'], $this->ran);
        $this->assertSame(['problem' => 'fail failed'], $this->variables);
    }

    public function test_the_error_variable_is_named_error_when_not_given(): void
    {
        $this->macro()->execute([
            'try' => [$this->command('fail')],
        ]);

        $this->assertSame(['error' => 'fail failed'], $this->variables);
    }

    public function test_without_catch_the_error_is_swallowed(): void
    {
        $result = $this->macro()->execute([
            'try' => [$this->command('fail')],
        ]);

        $this->assertSame(['__void' => true], $result['returnValue']);
        $this->assertFalse($result['hasError']);
    }

    public function test_an_error_in_catch_is_handed_on_after_finally_ran(): void
    {
        try {
            $this->macro()->execute([
                'try' => [$this->command('fail')],
                'catch' => [$this->command('failAgain')],
                'finally' => [$this->command('cleanUp')],
            ]);
            $this->fail('the error of catch is handed on');
        } catch (\RuntimeException $e) {
            $this->assertSame('failAgain failed', $e->getMessage());
        }

        $this->assertSame(['fail', 'failAgain', 'cleanUp'], $this->ran);
    }

    public function test_a_run_stopped_from_outside_is_not_caught_and_runs_nothing_more(): void
    {
        $this->expectException(RunStopped::class);

        try {
            $this->macro()->execute([
                'try' => [$this->command('abort')],
                'catch' => [$this->command('handle')],
                'finally' => [$this->command('cleanUp')],
            ]);
        } finally {
            $this->assertSame(['abort'], $this->ran);
        }
    }

    public function test_throw_raises_its_message(): void
    {
        $this->expectException(ThrownByDefinitionException::class);
        $this->expectExceptionMessage('no customer given');

        (new ThrowMacro())->execute(['message' => 'no customer given']);
    }

    public function test_throw_writes_a_value_that_is_no_text_as_json(): void
    {
        $this->expectExceptionMessage('{"code":4}');

        (new ThrowMacro())->execute(['message' => ['code' => 4]]);
    }

    public function test_throw_without_a_message_raises_the_default_one(): void
    {
        $this->expectExceptionMessage(ThrowMacro::DEFAULT_MESSAGE);

        (new ThrowMacro())->execute(['message' => '  ']);
    }

    /**
     * A tryCatch whose commands return their own name and write down that they
     * ran - those whose name starts with "fail" throw, "abort" stops the run
     * from outside.
     */
    private function macro(): TryCatchMacro
    {
        $player = $this->createStub(CommandPlayer::class);
        $player->method('run')->willReturnCallback(function (mixed $definition): mixed {
            $command = is_array($definition) ? $definition[0] : $definition;
            $this->ran[] = $command->commandName;

            if ($command->commandName === 'abort') {
                throw new RunStopped('aborted');
            }
            if (str_starts_with($command->commandName, 'fail')) {
                throw new \RuntimeException($command->commandName . ' failed');
            }

            return $command->commandName;
        });

        $macroPlayer = $this->createStub(MacroPlayer::class);
        $macroPlayer->method('executeMacro')->willReturnCallback(function (string $name, array $arguments): array {
            $this->assertSame('setVar', $name);
            $this->variables[$arguments['name']] = $arguments['value'];

            return ['returnValue' => ['__void' => true]];
        });

        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('getCommandPlayer')->willReturn($player);
        $environment->method('getMacroPlayer')->willReturn($macroPlayer);

        $macro = new TryCatchMacro();
        $macro->setMacroEnvironment($environment);

        return $macro;
    }

    private function command(string $name): CommandDTO
    {
        $command = new CommandDTO();
        $command->commandName = $name;

        return $command;
    }
}

final class RunStopped extends \RuntimeException implements UncatchableExceptionInterface
{
}
