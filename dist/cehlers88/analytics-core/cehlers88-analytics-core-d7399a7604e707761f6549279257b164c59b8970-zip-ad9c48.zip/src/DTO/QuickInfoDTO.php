<?php

namespace Cehlers88\AnalyticsCore\DTO;

class QuickInfoDTO extends DTO
{
    /** @var BadgeDTO[] */
    public array $badges = [];
    public ?string $message = null;
    public ?string $icon = null;
    public bool $hasError = false;
    public bool $hasWarning = false;
    public ?float $percentage = null;

    public static function createFromArray(array $definition): static
    {
        return new self();
    }
}