<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 20:16
 */

namespace Cehlers88\AnalyticsCore\Configuration;

use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

class ProcessConfigurationGroup extends AbstractConfigurationGroup
{
    public const KEY = 'process_setup';

    public function __construct(
        private iterable $processRunners,
        private iterable $processResultWorkers
    )
    {
    }

    public function getItems(): array
    {
        return [
            ConfigurationItemDTO::create('name', 'Name'),
            ConfigurationItemDTO::createSelect('state', eRunningState::toKeyValueArray('label'), 'State', eRunningState::New->value, ''),
            ConfigurationItemDTO::createSelect('runner', $this->getProcessRunnerSelectOptions(), 'Runner', eRunningState::New->value, ''),
            ConfigurationItemDTO::createSelect('resultWorker', $this->getProcessResultWorkersSelectOptions(), 'Result worker', eRunningState::New->value, ''),
        ];
    }

    private function getProcessRunnerSelectOptions(): array
    {
        $result = [];
        foreach ($this->processRunners as $processRunner) {
            $result[] = [
                'value' => $processRunner::class,
                'label' => $processRunner::class
            ];
        }
        return $result;
    }

    private function getProcessResultWorkersSelectOptions(): array
    {
        $result = [
            ['value' => '', 'label' => 'None']
        ];
        foreach ($this->processResultWorkers as $processResultWorker) {
            $result[] = [
                'value' => $processResultWorker::class,
                'label' => $processResultWorker::class
            ];
        }
        return $result;
    }

    public function getGroupTitle(): string
    {
        return 'Process settings';
    }

    public function getGroupDescription(): string
    {
        return 'This group contains general settings.';
    }

    public function getKey(): string
    {
        return self::KEY;
    }

    public function getViewContext(): string
    {
        return 'process_setup';
    }
}