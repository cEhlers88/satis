<?php

namespace Cehlers88\AnalyticsCore\Process\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;

class ResultWorkerDefinitionDTO extends DTO
{
    public string $worker = '';
    public array $arguments = [];

    public static function createFromArray(array $data): static
    {
        return self::create(
            $data['worker'] ?? '',
            $data['arguments'] ?? []
        );
    }

    public static function create(string $worker, array $arguments = []): static
    {
        $dto = new static();
        $dto->worker = $worker;
        $dto->arguments = $arguments;

        return $dto;
    }

    public function toArray(): array
    {
        return get_object_vars($this);
    }
}