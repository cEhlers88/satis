<?php

namespace Cehlers88\AnalyticsCore\Worker\Job;

use Analytics\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Entity\Client;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;

class CheckIsFirstVisitJob extends AbstractWorkerJob
{
    private const ACTION_NAME = "FIRST_VISIT";

    public function __construct(
        private ClientRepository         $clientRepository,
        private TrackingBufferRepository $trackingBufferRepository
    )
    {

    }

    public function run(): array
    {
        $client = $this->clientRepository->getByIp($this->getWorkingObject()->getIp());

        if ($client === null && $this->getWorkingObject()->getIp()) {
            $client = new Client();
            $client->setIp($this->getWorkingObject()->getIp());
            $client->setFirstVisit($this->getWorkingObject()->getTimestamp());

            $this->clientRepository->add($client);
        }

        return [];
    }

    public function getDescription(): string
    {
        return 'Dieser Job prüft, ob es sich bei einem Seitenaufruf um den ersten Besuch handelt. Wenn ja, wird die action "' . $this::ACTION_NAME . '" 
        gestartet. Wenn nein, wird nichts gemacht. Zur überprüfung wird die IP-Adresse des Besuchers herangezogen, die in der TrackingBuffer-Entität 
        gespeichert ist. Die IP-Adresse wird mit den IP-Adressen der bisherigen Besuche verglichen. Wenn keine Übereinstimmung gefunden und hat der 
        Client kein Flag übergeben, dass ihn als wiederkehrenden Besucher kennzeichnet, wird die action "' . $this::ACTION_NAME . '" gestartet.';
    }
}