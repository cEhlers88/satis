<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

abstract class AbstractAssembler implements AssemblerInterface
{
    public function many(iterable $entities): array
    {
        $buffer = [];
        foreach ($entities as $entity) {
            $buffer[] = $this->one($entity);
        }
        return $buffer;
    }
}