<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;

class ApplicationView implements ViewInterface
{
    public BadgeDTO $badge;

    public function __construct(
        public int    $id,
        public string $name
    )
    {
        $this->badge = new BadgeDTO();
    }
}