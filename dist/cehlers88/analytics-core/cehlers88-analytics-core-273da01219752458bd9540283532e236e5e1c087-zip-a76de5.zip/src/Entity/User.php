<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\UserRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Security\Core\User\PasswordAuthenticatedUserInterface;
use Symfony\Component\Security\Core\User\UserInterface;

#[ORM\Entity(repositoryClass: UserRepository::class)]
#[ORM\UniqueConstraint(name: 'UNIQ_IDENTIFIER_EMAIL', fields: ['email'])]
/**
 * Entity representing a system user.
 */
class User extends AbstractEntity implements UserInterface, PasswordAuthenticatedUserInterface, EntityInterface
{
    #[ORM\Column(length: 180)]
    private ?string $email = null;

    /**
     * @var list<string> The user roles
     */
    #[ORM\Column]
    private array $roles = [];

    /**
     * @var string The hashed password
     */
    #[ORM\Column]
    private ?string $password = null;

    #[ORM\Column]
    private array $settings = [];

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $adminNote = null;

    #[ORM\OneToMany(targetEntity: NotificationChannel::class, mappedBy: 'user')]
    private Collection $notificationChannels;

    /**
     * @var Collection<int, Dashboard>
     */
    #[ORM\OneToMany(targetEntity: Dashboard::class, mappedBy: 'user')]
    private Collection $dashboards;

    public function __construct()
    {
        $this->notificationChannels = new ArrayCollection();
        $this->dashboards = new ArrayCollection();
    }


    public function getActiveDashboard(): ?Dashboard
    {
        if ($this->getDashboards()->count() === 0) {
            return null;
        }

        $activeDashboardId = $this->getSettings()['activeDashboardId'] ?? null;

        foreach ($this->getDashboards() as $dashboard) {
            if (is_null($activeDashboardId) || $dashboard->getId() === $activeDashboardId) {
                return $dashboard;
            }
        }

        return $this->getDashboards()->first() ?? null;
    }

    /**
     * @return Collection<int, Dashboard>
     */
    public function getDashboards(): Collection
    {
        return $this->dashboards;
    }

    public function getSettings(): array
    {
        return $this->settings;
    }

    public function setSettings(array $settings): static
    {
        $this->settings = $settings;

        return $this;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): static
    {
        $this->email = $email;

        return $this;
    }

    /**
     * A visual identifier that represents this user.
     *
     * @see UserInterface
     */
    public function getUserIdentifier(): string
    {
        return (string)$this->email;
    }

    public function hasRole(string $role): bool
    {
        return in_array($role, $this->getRoles());
    }

    /**
     * @return list<string>
     * @see UserInterface
     *
     */
    public function getRoles(): array
    {
        $roles = $this->roles;
        // guarantee every user at least has ROLE_USER
        $roles[] = 'ROLE_USER';

        return array_unique($roles);
    }

    /**
     * @param list<string> $roles
     */
    public function setRoles(array $roles): static
    {
        $this->roles = $roles;

        return $this;
    }

    /**
     * @see PasswordAuthenticatedUserInterface
     */
    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): static
    {
        $this->password = $password;

        return $this;
    }

    /**
     * @see UserInterface
     */
    public function eraseCredentials(): void
    {
        // If you store any temporary, sensitive data on the user, clear it here
        // $this->plainPassword = null;
    }

    public function getAdminNote(): ?string
    {
        return $this->adminNote;
    }

    public function setAdminNote(?string $adminNote): static
    {
        $this->adminNote = $adminNote;
        return $this;
    }

    public function getNotificationChannels(): Collection
    {
        return $this->notificationChannels;
    }

    public function setNotificationChannels(Collection $notificationChannels): static
    {
        $this->notificationChannels = $notificationChannels;
        return $this;
    }

    public function addDashboard(Dashboard $dashboard): static
    {
        if (!$this->dashboards->contains($dashboard)) {
            $this->dashboards->add($dashboard);
            $dashboard->setUser($this);
        }

        return $this;
    }

    public function removeDashboard(Dashboard $dashboard): static
    {
        if ($this->dashboards->removeElement($dashboard)) {
            // set the owning side to null (unless already changed)
            if ($dashboard->getUser() === $this) {
                $dashboard->setUser(null);
            }
        }

        return $this;
    }
}
