<?php

namespace Cehlers88\AnalyticsCore\Worker;

use Cehlers88\AnalyticsCore\Worker\Job\JobInterface;

/** Interface for background workers. */
interface WorkerInterface
{
    /**
     * Configure the worker with the given properties.
     *
     * @param array $properties Configuration properties.
     * @return static
     */
    public function configure(array $properties): static;

    /**
     * Get the list of required job class names.
     *
     * @return array<string>
     */
    public function getRequiredJobs(): array;

    /** Set a benchmark value. */
    public function setBenchmarkValue(string $key, mixed $value): static;

    /** Get all benchmark data. */
    public function getBenchmark(): array;

    public function getJobByClassName(string $className): ?JobInterface;

    /** Check whether the worker reached its timeout. */
    public function reachedTimeout(): bool;
}