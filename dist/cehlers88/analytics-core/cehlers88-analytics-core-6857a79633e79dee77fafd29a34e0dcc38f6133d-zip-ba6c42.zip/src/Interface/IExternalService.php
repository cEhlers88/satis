<?php

namespace Cehlers88\AnalyticsCore\Interface;

interface IExternalService
{
    public function getServiceRootUrl(): string;
}