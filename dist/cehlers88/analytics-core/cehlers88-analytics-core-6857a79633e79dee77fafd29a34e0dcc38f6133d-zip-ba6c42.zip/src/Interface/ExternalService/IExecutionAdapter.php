<?php

namespace Cehlers88\AnalyticsCore\Interface\ExternalService;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\ENUM\eExternalServiceType;
use Symfony\Component\HttpFoundation\Request;

interface IExecutionAdapter
{
    public function callEntry(string $name, Request $request): mixed;

    public function callFunction(string $name, array $args, array $optionOverrides = []): mixed;

    public function getType(): eExternalServiceType;

    public function registerEntry(string $name, array $methods, array $options): static;

    /**
     * @param string $name
     * @param PropertyDTO[] $properties
     * @return $this
     */
    public function registerFunction(string $name, array $properties, array $options): static;
}