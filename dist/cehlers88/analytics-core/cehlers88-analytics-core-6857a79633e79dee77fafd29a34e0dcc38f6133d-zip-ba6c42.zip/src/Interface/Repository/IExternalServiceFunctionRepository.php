<?php

namespace Cehlers88\AnalyticsCore\Interface\Repository;

interface IExternalServiceFunctionRepository
{
}
