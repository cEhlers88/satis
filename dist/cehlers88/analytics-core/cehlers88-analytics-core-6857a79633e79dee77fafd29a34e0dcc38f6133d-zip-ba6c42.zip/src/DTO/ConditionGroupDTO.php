<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\Support\DTO\DTO;

/**
 * A condition group of a command definition - `["&&", [a, b]]` - once it has
 * been read. The values are commands, literals or further groups.
 *
 * @see \Cehlers88\AnalyticsCore\Support\Condition\ConditionEvaluator
 */
class ConditionGroupDTO extends DTO
{
    public array $conditionValues = [];
    public eConditionType $type = eConditionType::EQUALS;
    /** The operator the group is written with - what an editor writes it back as. */
    public string $typeName = '==';

    public static function create(array $conditionValues, eConditionType $type = eConditionType::EQUALS): ConditionGroupDTO
    {
        $dto = new self();
        $dto->conditionValues = $conditionValues;
        $dto->type = $type;
        $dto->typeName = $type->operator();

        return $dto;
    }

    /**
     * Whether a value is a condition group the way a definition writes it: an
     * operator and the list of its values. A command `[name, {…}]` never is -
     * its properties are no list.
     */
    public static function isDefinition(mixed $value): bool
    {
        return is_array($value)
            && count($value) === 2
            && array_is_list($value)
            && is_string($value[0])
            && is_array($value[1])
            && array_is_list($value[1])
            && eConditionType::tryFromOperator($value[0]) !== null;
    }
}
