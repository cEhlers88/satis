<?php

namespace Cehlers88\AnalyticsCore\Worker;

use Analytics\ENUM\eWorkerCounterKey;
use Analytics\Message\StartHandleWorkerErrorMessage;
use Cehlers88\AnalyticsCore\Entity\Worker;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Repository\WorkerJournalRepository;
use Cehlers88\AnalyticsCore\Repository\WorkerRepository;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
use Cehlers88\AnalyticsCore\Support\Logging\SimpleConsoleLogger;
use Cehlers88\AnalyticsCore\Worker\DTO\WorkerResultDTO;
use Cehlers88\AnalyticsCore\Worker\Observer\Message\WorkerErrorObserverMessage;
use Exception;
use Symfony\Component\DependencyInjection\Attribute\AutowireIterator;
use Symfony\Component\Messenger\MessageBusInterface;

/** Provider for managing worker instances and execution. */
class WorkerProvider
{
    private bool $_debugMode = false;

    private LoggerInterface $_logger;

    //private ?RunChain $runChain = null;

    /**
     * WorkerProvider constructor.
     * @param iterable<WorkerInterface> $workerInstances
     * @param MacroEnvironment $macroEnvironment
     * @param WorkerRepository $workerRepository
     * @param WorkerJournalRepository $workerJournalRepository
     * @param MessageBusInterface $messageBus
     */
    public function __construct(
        #[AutowireIterator('analytics.worker')]
        private iterable                 $workerInstances,
        //private ApplicationContext       $applicationContext,
        private MacroEnvironment         $macroEnvironment,
        private WorkerRepository         $workerRepository,
        //private WorkerJobProvider        $workerJobProvider,
        private WorkerJournalRepository  $workerJournalRepository,
        private MessageBusInterface      $messageBus,
        private ObserverProvider         $observerProvider,
        //private ExecutorProvider         $executorProvider,
        private TrackingBufferRepository $trackingBufferRepository,
    )
    {
        $this->_logger = new SimpleConsoleLogger();
    }

    /** Enable or disable debug mode. */
    public function enableDebugMode(bool $enable = true): static
    {
        $this->_debugMode = $enable;
        return $this;
    }

    /** Get workers that have no matching entity or no matching class. */
    public function getUnrelatedWorkers(): array
    {
        $buffer = [];
        foreach ($this->getWorkers() as $worker) {
            $buffer[] = [
                'hasEntity' => true,
                'name_entity' => $worker->getName(),
                'has_worker' => false,
                'name_worker' => $worker->getWorkerClass()
            ];
        }

        foreach ($this->getWorkerClasses() as $worker) {
            $found = false;
            for ($i = 0; count($buffer) > $i; $i++) {
                if ($buffer[$i]['name_worker'] === get_class($worker)) {
                    $buffer[$i]['has_worker'] = true;
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $buffer[] = [
                    'hasEntity' => false,
                    'name_entity' => '',
                    'has_worker' => true,
                    'name_worker' => get_class($worker)
                ];
            }
        }
        $result = [];
        foreach ($buffer as $entry) {
            if (!$entry['hasEntity'] || !$entry['has_worker']) {
                $result[] = $entry;
            }
        }
        return $result;
    }

    /**
     * @param int[] $applicationIdFilters
     * @return Worker[]|AbstractWorker[]
     */
    public function getWorkers($applicationIdFilters = [], bool $returnInstance = false): array
    {
        return array_reduce(
            (count($applicationIdFilters) === 0 ? $this->workerRepository->findAll() : $this->workerRepository->findBy_applicationIds($applicationIdFilters)),
            function ($carry, $workerEntity) use ($applicationIdFilters, $returnInstance) {
                $carry[] = $returnInstance ? $this->getWorkerInstanceByEntityId($workerEntity->getId()) : $workerEntity;
                return $carry;
            },
            []
        );
    }

    /**
     * Get a worker instance by its entity ID.
     *
     * @param int $workerId The worker entity ID.
     * @return AbstractWorker|null
     */
    public function getWorkerInstanceByEntityId(int $workerId): ?AbstractWorker
    {
        $workerEntity = $this->workerRepository->find($workerId);
        return $this->getWorkerInstanceByName($workerEntity->getWorkerClass());
    }

    /**
     * Get a worker instance by its class name.
     *
     * The tagged services are one shared instance per worker class, but several
     * worker entities may use the same class - so every call hands out a copy of
     * that prototype and the state of one run (properties, jobs, errors, ...)
     * can never leak into the next one.
     *
     * @param string $workerName Fully qualified worker class name.
     * @return AbstractWorker|null
     */
    public function getWorkerInstanceByName(string $workerName): ?AbstractWorker
    {
        /** @var AbstractWorker $worker */
        foreach ($this->workerInstances as $worker) {
            if ($worker->getName() === $workerName) {
                return (clone $worker)
                    ->setMacroPlayer($this->macroEnvironment->getMacroPlayer())
                    ->setTrackingBufferRepository($this->trackingBufferRepository)
                    ->setWorkerRepository($this->workerRepository);
            }
        }
        return null;
    }

    /** Get all registered worker classes. */
    public function getWorkerClasses(): iterable
    {
        return $this->workerInstances;
    }

    /**
     * Get a worker entity by its ID.
     *
     * @param int $workerId The worker entity ID.
     * @return Worker|null
     */
    public function getWorkerById(int $workerId): ?Worker
    {
        return $this->workerRepository->find($workerId);
    }

    /** Set the logger instance. */
    public function setLogger(LoggerInterface $logger): static
    {
        $this->_logger = $logger;
        return $this;
    }

    /**
     * Set the running state of a worker.
     *
     * @param int $workerId The worker entity ID.
     * @param eRunningState $state The new state.
     * @return static
     */
    public function setWorkerState(int $workerId, eRunningState $state): static
    {
        $workerEntity = $this->workerRepository->find($workerId);
        $workerEntity->setState($state);
        $workerEntity->setUpdatedAt(new \DateTime());
        $this->workerRepository->save($workerEntity, true);

        return $this;
    }

    /**
     * Resolve the property definitions for a worker entity.
     *
     * @param Worker $worker The worker entity.
     * @return array
     */
    public function resolveWorkerPropertyDefinition(Worker $worker): array
    {
        $instance = $this->getWorkerInstanceByName($worker->getWorkerClass());
        $result = [];
        foreach ($instance->getProperties() as $property) {
            $result[] = [$property->type, $property->name, $property->value];
        }
        return $result;
    }

    private function _logInfo(string $message, bool $requireDebugMode = false): void
    {
        if ($requireDebugMode === true && !$this->_debugMode) return;
        $this->_logger->info($message);
    }

    /**
     * @param Worker|null $workerEntity
     * @param int $code
     * @param array|Exception $details
     * @param bool $isFatal
     */
    private function _setError(
        string     $source,
        string     $message,
        \Throwable $details,
        ?Worker    $workerEntity = null,
        int        $code = 0,
        bool       $isFatal = false,
    )
    {
        $extendedMessage = sprintf('%sError in %s: "%s"', ($isFatal ? 'Fatal-' : ''), $source, $message);
        $this->_logger->warning($extendedMessage);

        $errorDetails = [
            'exceptionTrace' => $details->getTraceAsString(),
        ];

        $this->observerProvider->dispatch(new WorkerErrorObserverMessage(
            $workerEntity,
            $errorDetails
        ));

        if ($isFatal) {
            $workerEntity
                ->setState(eRunningState::FatalError)
                ->incrementCounter(eWorkerCounterKey::FAILED);
        } else {
            if ($workerEntity->getRestRetries() === 0) {
                $this->_setError('WorkerProvider', 'Worker has no retries left', $details, $workerEntity, 0, true);
                return;
            }
            $workerEntity
                ->addState(eRunningState::Error)
                ->incrementCounter(eWorkerCounterKey::FAILED);
        }
        try {
            $this->workerRepository->save($workerEntity, true);
            $this->workerJournalRepository->addWorkerResult($workerEntity, WorkerResultDTO::createFromException($details));
        } catch (\Throwable $e) {
            $this->_logger->error('Error while save worker error: ' . $e->getMessage(), []);
        }

        $this->messageBus->dispatch(new StartHandleWorkerErrorMessage(
            $details->getMessage(),
            $workerEntity->getId()
        ));
    }
}