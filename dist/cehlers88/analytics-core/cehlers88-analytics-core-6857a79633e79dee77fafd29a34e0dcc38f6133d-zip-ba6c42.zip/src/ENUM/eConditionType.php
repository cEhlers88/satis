<?php

namespace Cehlers88\AnalyticsCore\ENUM;

enum eConditionType: int
{
    case EQUALS = 1;
    case NOT_EQUALS = 2;
    case GREATER_THAN = 3;
    case GREATER_THAN_OR_EQUALS = 4;
    case LESS_THAN = 5;
    case LESS_THAN_OR_EQUALS = 6;
    case CONTAINS = 7;
    case NOT_CONTAINS = 8;
    case STARTS_WITH = 9;
    case ENDS_WITH = 10;
    case OR = 11;
    case AND = 12;
    case XOR = 13;
    case NOT = 14;

    /**
     * Every spelling a condition group may be written with in a command
     * definition - `["&&", [...]]` - lower cased, so a lookup ignores the case.
     * What a type is written back as is operator().
     *
     * Mirrored by assets/Property/PropertyUi.ts of the application.
     */
    private const array OPERATORS = [
        '==' => self::EQUALS,
        '===' => self::EQUALS,
        'equals' => self::EQUALS,
        '!=' => self::NOT_EQUALS,
        '!==' => self::NOT_EQUALS,
        '>' => self::GREATER_THAN,
        '>=' => self::GREATER_THAN_OR_EQUALS,
        '<' => self::LESS_THAN,
        '<=' => self::LESS_THAN_OR_EQUALS,
        'contains' => self::CONTAINS,
        '!contains' => self::NOT_CONTAINS,
        'not contains' => self::NOT_CONTAINS,
        'startswith' => self::STARTS_WITH,
        'starts with' => self::STARTS_WITH,
        'endswith' => self::ENDS_WITH,
        'ends with' => self::ENDS_WITH,
        '||' => self::OR,
        'or' => self::OR,
        '&&' => self::AND,
        'and' => self::AND,
        'xor' => self::XOR,
        '!' => self::NOT,
        'not' => self::NOT,
    ];

    public static function toString(int $value): string
    {
        switch ($value) {
            case self::EQUALS->value:
                return '===';
            case self::NOT_EQUALS->value:
                return '!==';
            case self::GREATER_THAN->value:
                return '>';
            case self::GREATER_THAN_OR_EQUALS->value:
                return '>=';
            case self::LESS_THAN->value:
                return '<';
            case self::LESS_THAN_OR_EQUALS->value:
                return '<=';
            case self::CONTAINS->value:
                return 'contains';
            case self::NOT_CONTAINS->value:
                return 'not contains';
            case self::STARTS_WITH->value:
                return 'starts with';
            case self::ENDS_WITH->value:
                return 'ends with';
            case self::OR->value:
                return 'or';
            case self::AND->value:
                return 'and';
            case self::XOR->value:
                return 'xor';
            case self::NOT->value:
                return 'not';
            default:
                return 'unknown';
        }
    }

    /** The type an operator of a command definition stands for, null for none. */
    public static function tryFromOperator(string $operator): ?self
    {
        return self::OPERATORS[strtolower(trim($operator))] ?? null;
    }

    /**
     * The operator this type is written as in a command definition - unlike
     * toString() always one tryFromOperator() reads back.
     */
    public function operator(): string
    {
        return match ($this) {
            self::EQUALS => '==',
            self::NOT_EQUALS => '!=',
            self::GREATER_THAN => '>',
            self::GREATER_THAN_OR_EQUALS => '>=',
            self::LESS_THAN => '<',
            self::LESS_THAN_OR_EQUALS => '<=',
            self::CONTAINS => 'contains',
            self::NOT_CONTAINS => '!contains',
            self::STARTS_WITH => 'startsWith',
            self::ENDS_WITH => 'endsWith',
            self::OR => '||',
            self::AND => '&&',
            self::XOR => 'xor',
            self::NOT => '!',
        };
    }

    /**
     * Every other spelling this type is read from - operator() is the one it
     * is written as.
     *
     * @return list<string>
     */
    public function aliases(): array
    {
        $canonical = strtolower($this->operator());

        return array_values(array_filter(
            array_keys(array_filter(self::OPERATORS, fn(self $type): bool => $type === $this)),
            static fn(string $spelling): bool => $spelling !== $canonical
        ));
    }

    /** Whether the type combines conditions instead of comparing two values. */
    public function isLogical(): bool
    {
        return in_array($this, [self::AND, self::OR, self::XOR, self::NOT], true);
    }

    public function value(): int
    {
        return $this->value;
    }
}
