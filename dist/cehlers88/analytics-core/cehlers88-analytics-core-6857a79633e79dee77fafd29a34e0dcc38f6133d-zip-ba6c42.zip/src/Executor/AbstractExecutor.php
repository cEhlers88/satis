<?php

namespace Cehlers88\AnalyticsCore\Executor;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Support\AbstractPropertyBag;
use Cehlers88\AnalyticsCore\Support\Profiler;

/** Base class for executors that run processes and workers. */
abstract class AbstractExecutor extends AbstractPropertyBag implements ExecutorInterface
{
    public const int ERR_INVALID = 500001;
    public const int ERR_ON_PRE_START = 500100;
    public const int ERR_ON_START = 500101;
    public const int ERR_ON_END = 500102;
    public const int ERR_WHILE_EXECUTE = 500110;

    public array $environment = [];
    protected bool $isReRun = false;
    protected mixed $lastResult = null;

    /** @var bool */
    protected bool $_logHasOpenGroup = false;

    /** @var Profiler|null */
    protected ?Profiler $_profiler = null;

    /** @var ExecutorProvider|null */
    private ?ExecutorProvider $_executorProvider = null;

    private bool $configured = false;

    /**
     * Execute the full lifecycle: onStart, execute, onEnd.
     *
     */
    final public function run(): void
    {
        if (!$this->isReRun) {
            // Executors are shared services: a previous run must not count as configured.
            $this->configured = false;
            $this->_profiler = new Profiler();
            $this->_profiler->start();

            $this->openLogGroup();
        }

        try {
            $this->configure();
        } catch (\Throwable $e) {
            $this->setError($e->getMessage(), self::ERR_ON_PRE_START, []);
        }

        if (!$this->configured) {
            $this->_profiler->stop();
            $this->logWarning('Executor not configured. -> stopped');
            $this->_closeLogGroup();
            return;
        }

        try {
            $this->preStart();
        } catch (\Throwable $e) {
            $this->setError($e->getMessage(), self::ERR_ON_PRE_START, []);
        }

        if (!$this->isRunnable()) {
            $this->logWarning('Executor is not runnable. -> stop');
            $this->_closeLogGroup();
            return;
        }

        try {
            $this->onStart();
        } catch (\Throwable $e) {
            $this->setError($e->getMessage(), self::ERR_ON_START, [
                'trace' => $e->getTraceAsString(),
            ]);
            $this->logInfo('Error while onStart: ' . $e->getMessage(), true);
        }

        if (!$this->hasError()) {
            try {
                $this->execute();
            } catch (\Throwable $e) {
                $this->setError($e->getMessage(), self::ERR_WHILE_EXECUTE, [
                    'code' => $e->getCode(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                    'trace' => $e->getTraceAsString(),
                ]);
                $this->logInfo('Error while execute ' . self::class . '.: ' . $e->getMessage(), true);
            }
        }

        $this->onEnd();
    }

    /** Open a new log group for this executor. */
    public function openLogGroup(): static
    {
        $this->getLogger()->startGroup('Executor', [
            'name' => $this->getName(),
            'started-at' => $this->_profiler->getStartedAt()->format('Y-m-d H:i:s'),
        ]);
        $this->_logHasOpenGroup = true;
        return $this;
    }

    /** Get the executor name (defaults to class name). */
    public function getName(): string
    {
        return static::class;
    }

    protected function configure(): void
    {
        $this->configured = true;
    }

    /**
     * Hook called after configuration but before validation and runnability checks.
     */
    public function preStart(): void
    {

    }

    /** Determine whether this executor is allowed to run. */
    public function isRunnable(): bool
    {
        if ($this->isDisabled()) {
            $this->logWarning('Executor is disabled. -> stopped', true);
            return false;
        }

        if (!$this->isValid()) {
            $this->logWarning('Executor is invalid.', true);
            return false;
        }
        if ($this->isRunning()) {
            $this->logWarning('Executor is already running. -> stopped', true);
            return false;
        }
        return true;
    }

    public function isDisabled(): bool
    {
        return false;
    }

    abstract public function isRunning(): bool;

    private function _closeLogGroup(): void
    {
        if ($this->_logHasOpenGroup) {
            $this->getLogger()->endGroup('Executor');
        }

        $this->_logHasOpenGroup = false;
    }

    /** Hook called before execution starts. */
    public function onStart(): void
    {
    }

    /**
     * Log an informational message.
     *
     * @param string $message
     * @param bool $onlyInDebugMode
     * @return static
     */
    public function logInfo(string $message, bool $onlyInDebugMode = false): static
    {
        if ($onlyInDebugMode && !$this->getDebugMode()) {
            return $this;
        }

        if (!$this->_logHasOpenGroup) {
            $this->openLogGroup();
        }

        parent::logInfo($message, $onlyInDebugMode);

        return $this;
    }

    /** Perform the main execution logic. */
    abstract protected function execute(): void;

    /** Hook called after execution completes. */
    public function onEnd(): void
    {
        if ($this->wantsToReRun()) {
            return;
        }
        $this->_closeLogGroup();
    }

    public function onError(ErrorDTO $error): void
    {
        if ($this->getDebugMode()) {
            $this->logError($error->message);
        }
    }

    public function getRestExecutionTimeMs(): ?float
    {
        return $this->getRestExecutionTime() * 1000;
    }

    public function getRestExecutionTime(): ?float
    {
        $allowedRuntime = $this->getPropertyValue('allowedRuntime'); // in s
        if (is_null($allowedRuntime)) {
            return null;
        }

        return $allowedRuntime - $this->getProfiler()->getDurationSeconds();
    }

    public function getProfiler(): Profiler
    {
        if (is_null($this->_profiler)) {
            $this->_profiler = new Profiler();
        }

        return $this->_profiler;
    }

    public function getExecutorProvider(): ExecutorProvider
    {
        return $this->_executorProvider;
    }

    /** Set the executor provider. */
    public function setExecutorProvider(ExecutorProvider $executorProvider): static
    {
        $this->_executorProvider = $executorProvider;
        return $this;
    }

    public function getLastResult(): mixed
    {
        return $this->lastResult;
    }
}