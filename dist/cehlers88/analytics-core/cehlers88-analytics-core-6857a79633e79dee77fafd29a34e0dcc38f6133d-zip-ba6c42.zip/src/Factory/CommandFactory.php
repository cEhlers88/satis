<?php

namespace Cehlers88\AnalyticsCore\Factory;

use Cehlers88\AnalyticsCore\Command\DTO\CommandDTO;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\DTO\ConditionGroupDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Command;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiResolver;
use Cehlers88\AnalyticsCore\Repository\CommandRepository;
use Cehlers88\AnalyticsCore\Validator\CommandDefinitionValidator;

class CommandFactory
{
    public const UI_PROPERTY_EXTENDER_KEY = PropertyUiResolver::SETTINGS_PROPERTY_EXTENDER;
    private bool $_enrichUiInfos = false;
    private ?PropertyUiResolver $_propertyUiResolver = null;
    private array $_commands;
    private array $_commandRegister = [];
    private $_commandDtoExtender;
    private CommandDefinitionValidator $_commandDefinitionValidator;

    public function __construct(
        private CommandRepository $commandRepository,
    )
    {
        $this->init();
    }

    private function init()
    {
        $this->_commands = $this->commandRepository->findAll();

        foreach ($this->_commands as $index => $command) {
            $this->_commandRegister[$command->getName()] = $index;
        }

        $this->_commandDefinitionValidator = new CommandDefinitionValidator(array_keys($this->_commandRegister));

        $this->setCommandDtoExtender(function (CommandDto $dto, Command $command) {
            return $dto;
        });
    }

    public function setCommandDtoExtender(callable $_commandDtoExtender): CommandFactory
    {
        $this->_commandDtoExtender = $_commandDtoExtender;
        return $this;
    }

    public function buildCommandDTO(Command $command, bool $includeOptionals = false): CommandDTO
    {
        $dto = new CommandDTO();

        $dto->commandName = $command->getName();
        foreach ($command->getMacroProps() as $macroProp) {
            $property = PropertyDTO::create(
                $macroProp[Command::MACRO_PROPS_INDEX_NAMES],
                ''
            );

            $property->value = $macroProp[Command::MACRO_PROPS_INDEX_TYPES] == 'string' ? "dummy value" : $property->value;
            $property->value = $macroProp[Command::MACRO_PROPS_INDEX_TYPES] == 'int' ? 123456 : $property->value;
            $property->value = $macroProp[Command::MACRO_PROPS_INDEX_TYPES] == 'boolean' ? 'true' : $property->value;

            if (isset($macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE])) {
                $property->value = $macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE];
                $property->isOptional = true;
            } else {
                $property->isOptional = false;
                $property->isDefaultValue = false;
            }

            if ($includeOptionals || !$property->isOptional) {
                $dto->properties[] = $property;
            }
        }

        return $dto;
    }

    public function buildQuickView(Command $command, array $values = []): string
    {
        $html = '';
        $formatArgs = [];
        if (isset($command->getQuickViewFormat()['keyWords'])) {
            foreach ($command->getQuickViewFormat()['keyWords'] as $keyWord) {
                $formatArgs[] = '<span class="keyWord">' . $keyWord . '</span>';
            }
        }

        foreach ($command->getMacroProps() as $macroProp) {
            $value = isset($values[$macroProp[Command::MACRO_PROPS_INDEX_NAMES]]) ? $values[$macroProp[Command::MACRO_PROPS_INDEX_NAMES]] : $macroProp[Command::MACRO_PROPS_INDEX_NAMES];
            $formatArgs[] = '<span class="property" data-name="' . $macroProp[Command::MACRO_PROPS_INDEX_NAMES] . '">' . $value . '</span>';
        }
        if (isset($command->getQuickViewFormat()['definition'])) {
            $html = sprintf($command->getQuickViewFormat()['definition'], ...$formatArgs);
        }
        return $html;
    }

    /**
     * Evaluates a command definition array and returns a CommandGroupDTO object.
     * If the definition is not an array of commands, it will be wrapped in an array.
     *
     * @param array $definition
     * @param bool $returnOriginalIfNotArrayOfCommands
     * @param bool $ignoreMissingCommandArguments
     *
     * @return CommandGroupDTO|array
     */
    public function evalDefinitionArray(
        array $definition,
        bool  $returnOriginalIfNotArrayOfCommands = false,
        bool  $ignoreMissingCommandArguments = false
    ): CommandGroupDTO|array
    {
        $result = new CommandGroupDTO();
        $isArrayOfCommands = false;

        try {
            if (isset($definition[0]) && is_array($definition[0]) && $this->_commandDefinitionValidator->validate($definition[0])) {
                foreach ($definition as $subDefinition) {
                    $result->commands[] = $this->commandDtoByDefinition($subDefinition);
                }
                $isArrayOfCommands = true;
            } else if (isset($definition[0]) && is_string($definition[0]) && $this->_commandDefinitionValidator->validate($definition)) {
                $result->commands = [$this->commandDtoByDefinition($definition)];
                $isArrayOfCommands = true;
            } else if (!$ignoreMissingCommandArguments) {
                // todo: implement possibility to define command/s with missing arguments
                foreach ($definition as $subDefinition) {
                    if (is_string($subDefinition)) {
                        //
                        continue;
                    }
                }
            }
        } catch (\Exception $e) {

        }

        if (!$isArrayOfCommands) {
            if ($returnOriginalIfNotArrayOfCommands) {
                return $definition;
            }
            $result->commands = [$this->commandDtoByDefinition($definition)];
        }
        return $result;
    }

    public function commandDtoByDefinition(array $definition, string $address = ''): ?CommandDTO
    {
        if (count($definition) === 1 && is_string($definition[0]) && $this->_commandDefinitionValidator->isValidCommandName($definition[0])) {
            $command = $this->getCommandByName($definition[0]);
            if ($command === null) {
                return null;
            }

            $dto = new CommandDTO();
            $dto->commandName = $command->getName();
            $dto->properties = [];
            $dto->address = $address;

            foreach ($command->getMacroProps() as $macroProp) {
                $propName = $macroProp[Command::MACRO_PROPS_INDEX_NAMES];
                $propValue = isset($macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE]) ? $macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE] : null;

                $property = $this->_enrichSubCommandCallInProperties(PropertyDTO::create($propName, $propValue, $macroProp[Command::MACRO_PROPS_INDEX_TYPES]));
                $property->isOptional = isset($macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE]);
                $property->isDefaultValue = true;

                $this->_applyPropertyUi($command, $property);

                $dto->properties[] = $property;
            }

            return call_user_func($this->_commandDtoExtender, $dto, $command, $this);
        }

        if (
            !array_is_list($definition)
            || count($definition) !== 2
            || !is_string($definition[0])
            || !is_array($definition[1])
        ) {
            return null;
        }

        if (!$this->_commandDefinitionValidator->validate($definition)) {
            return null;
        }

        $command = $this->getCommandByName($definition[0]);
        if ($command === null) {
            return null;
        }

        $dto = new CommandDTO();
        $dto->commandName = $command->getName();
        $dto->properties = [];
        $dto->address = $address;

        $propOverwrites = $command->getMacroPropsOverwrites();
        foreach ($command->getMacroProps() as $macroProp) {
            $propName = $macroProp[Command::MACRO_PROPS_INDEX_NAMES];
            $propValue = (isset($macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE]) ? $macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE] : '');

            if (isset($definition[1])) {
                $propValue = (is_array($definition[1]) ?
                    (isset($definition[1][$propName]) ? $definition[1][$propName] : $propValue) :
                    (isset($definition[1]->$propName) ? $definition[1]->$propName : $propValue)
                );
            }

            if (isset($propOverwrites[$propName])) {
                $propValue = $propOverwrites[$propName];
                unset($propOverwrites[$propName]);
            }

            $property = $this->_enrichSubCommandCallInProperties(PropertyDTO::create($propName, $propValue, $macroProp[Command::MACRO_PROPS_INDEX_TYPES]));
            $property->isOptional = isset($macroProp[Command::MACRO_PROPS_INDEX_DEFAULT_VALUE]);

            if (is_array($definition[1]) && isset($definition[1][$propName])) {
                unset($definition[1][$propName]);
                $property->isDefaultValue = false;
            } else if (is_object($definition[1]) && isset($definition[1]->$propName)) {
                unset($definition[1]->$propName);
                $property->isDefaultValue = false;
            }

            $this->_applyPropertyUi($command, $property);

            $dto->properties[] = $property;
        }

        foreach ($propOverwrites as $propName => $propValue) {
            $dto->properties[] = $this->_enrichSubCommandCallInProperties(PropertyDTO::create($propName, $propValue));
        }

        foreach ($definition[1] as $propName => $propValue) {
            $dto->unknownProperties[] = $this->_enrichSubCommandCallInProperties(PropertyDTO::create($propName, $propValue));
        }

        return call_user_func($this->_commandDtoExtender, $dto, $command, $this);
    }

    public function getCommandByName(string $name): ?Command
    {
        $index = $this->_commandRegister[$name] ?? null;
        if (is_null($index)) {
            return null;
        }
        return $this->_commands[$index];
    }

    /**
     * Puts the infos of how the property is edited on it - only for the
     * editors that asked for them, a run has no use for them.
     */
    private function _applyPropertyUi(Command $command, PropertyDTO $property): void
    {
        if ($this->_propertyUiResolver !== null) {
            $uiInfos = $this->_propertyUiResolver->resolve($command, $property->name, $property->value);
        } else if ($this->_enrichUiInfos && is_callable($command->getUiSettings()[self::UI_PROPERTY_EXTENDER_KEY] ?? null)) {
            // Without a resolver only the extender the command row names is
            // asked, the way it was before the resolver existed.
            $uiInfos = PropertyUi::normalize(call_user_func(
                $command->getUiSettings()[self::UI_PROPERTY_EXTENDER_KEY],
                MacroPropertyDTO::create($property->name, [], '', $property->value)
            ));
        } else {
            return;
        }

        if ($uiInfos !== []) {
            // Merged, so the defaults an editor relies on stay there.
            $property->ui = [...$property->ui, ...$uiInfos];
        }
    }

    private function _enrichSubCommandCallInProperties(PropertyDTO $propertyDTO): ?PropertyDTO
    {
        // [X] value = "test"
        // [_] value = ["test","test2","test3"]
        // [_] value = ["test",["command",{"prop1":"test","prop2":"test2"}],"test3"]
        // [_] value = ["command",{"prop1":"test","prop2":"test2"}]
        // [_] value = [["command1",{"prop1":"test","prop2":"test2"}],["command2",{"prop1":"test","prop2":"test2"}]]

        if (is_array($propertyDTO->value)) {
            $propertyDTO->value = $this->_recursiveCommandSearch($propertyDTO->value);

            if ($propertyDTO->value instanceof CommandDTO) {
                $propertyDTO->hasSubCommand = true;
            } else {
                if ($propertyDTO->value instanceof ConditionGroupDTO) {
                    $propertyDTO->hasConditionGroups = true;
                } else {
                    foreach ($propertyDTO->value as $value) {
                        if ($value instanceof CommandDTO) {
                            $propertyDTO->hasSubCommand = true;
                        }
                    }
                }
            }
        } else {
            if ($propertyDTO->value instanceof CommandDTO) {
                $propertyDTO->hasSubCommand = true;
            }
        }

        return $propertyDTO;
    }

    private function _recursiveCommandSearch(array $definition, string $address = ''): mixed
    {
        if (ConditionGroupDTO::isDefinition($definition)) {
            return $this->conditionGroupDtoByDefinition($definition);
        }

        if (count($definition) >= 2 && is_string($definition[0] ?? null)) {
            if (isset($this->_commandRegister[$definition[0]])) {
                $resultDto = $this->commandDtoByDefinition($definition, $address);
                return $resultDto;
            }
        } else {
            $innerCounter = 0;
            foreach ($definition as $key => $value) {
                $definition[$key] = is_array($value) && count($value) >= 2 ? $this->_recursiveCommandSearch($value, ($address !== '' ? $address . '-' : '') . $innerCounter) : $value;
                $innerCounter++;
            }
        }
        return $definition;
    }

    /**
     * Reads a condition group - `["&&", [...]]` - with the commands and the
     * groups inside it read as well.
     */
    public function conditionGroupDtoByDefinition(array $definition): ?ConditionGroupDTO
    {
        $type = is_string($definition[0] ?? null) ? eConditionType::tryFromOperator($definition[0]) : null;

        if ($type === null || !is_array($definition[1] ?? null)) {
            return null;
        }

        $values = [];
        foreach ($definition[1] as $value) {
            $values[] = is_array($value) ? $this->_recursiveCommandSearch($value) : $value;
        }

        return ConditionGroupDTO::create($values, $type);
    }

    public function setEnrichUiInfos(bool $enrichUiInfos): CommandFactory
    {
        $this->_enrichUiInfos = $enrichUiInfos;
        return $this;
    }

    /**
     * Puts the infos of how each property is edited on every property that is
     * read from here on - see PropertyUiResolver. Null stops it again.
     */
    public function setPropertyUiResolver(?PropertyUiResolver $propertyUiResolver): CommandFactory
    {
        $this->_propertyUiResolver = $propertyUiResolver;
        return $this;
    }
}
