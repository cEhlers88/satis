<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Support\Condition;

use Cehlers88\AnalyticsCore\DTO\ConditionGroupDTO;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\Support\Property\PropertyConditionResolver;

/**
 * Decides a condition of a command definition.
 *
 * A condition is either a group - `["&&", [...]]`, read or not yet read into a
 * ConditionGroupDTO - or a plain value that is taken for what it is worth:
 *
 *  - `&&`, `||`, `xor` combine the conditions they hold, `!` negates them
 *    (several values read as "not all of them")
 *  - every other operator compares its values pairwise from left to right, so
 *    `["<", [1, $x, 10]]` reads as `1 < $x < 10`; the comparison is the lenient
 *    one of the property conditions, since values typed into an editor arrive
 *    as strings
 *  - a list without an operator holds when every entry does - the shape the
 *    `if` macro was given its conditions in before there were groups
 *  - `true`, a number above zero and the strings "true" and "1" hold
 *
 * Values that still have to run - commands - are handed to $resolve right when
 * they are needed, so `&&` and `||` stop at the first value that decides them.
 */
final class ConditionEvaluator
{
    /**
     * @param callable(mixed): mixed|null $resolve turns a value that still has
     *                                             to run into its result
     */
    public function evaluate(mixed $condition, ?callable $resolve = null): bool
    {
        $condition = $this->resolve($condition, $resolve);

        if ($condition instanceof ConditionGroupDTO) {
            return $this->evaluateGroup($condition->type, $condition->conditionValues, $resolve);
        }

        if (ConditionGroupDTO::isDefinition($condition)) {
            return $this->evaluateGroup(eConditionType::tryFromOperator($condition[0]), $condition[1], $resolve);
        }

        return match (true) {
            is_array($condition) => $this->every($condition, $resolve),
            is_bool($condition) => $condition,
            is_int($condition), is_float($condition) => $condition > 0,
            is_string($condition) => in_array(strtolower(trim($condition)), ['true', '1'], true),
            default => false,
        };
    }

    private function evaluateGroup(eConditionType $type, array $values, ?callable $resolve): bool
    {
        return match ($type) {
            eConditionType::AND => $this->every($values, $resolve),
            eConditionType::OR => $this->any($values, $resolve),
            eConditionType::XOR => $this->countFulfilled($values, $resolve) % 2 === 1,
            eConditionType::NOT => !$this->every($values, $resolve),
            default => $this->compareChain($type, $values, $resolve),
        };
    }

    private function every(array $values, ?callable $resolve): bool
    {
        foreach ($values as $value) {
            if (!$this->evaluate($value, $resolve)) {
                return false;
            }
        }

        return true;
    }

    private function any(array $values, ?callable $resolve): bool
    {
        foreach ($values as $value) {
            if ($this->evaluate($value, $resolve)) {
                return true;
            }
        }

        return false;
    }

    private function countFulfilled(array $values, ?callable $resolve): int
    {
        $count = 0;
        foreach ($values as $value) {
            $count += $this->evaluate($value, $resolve) ? 1 : 0;
        }

        return $count;
    }

    /** A comparison needs something to compare - a single value holds nothing. */
    private function compareChain(eConditionType $type, array $values, ?callable $resolve): bool
    {
        $values = array_values($values);

        if (count($values) < 2) {
            return false;
        }

        $previous = $this->operand($values[0], $resolve);

        for ($index = 1; $index < count($values); $index++) {
            $current = $this->operand($values[$index], $resolve);

            if (!PropertyConditionResolver::compare($previous, $current, $type)) {
                return false;
            }

            $previous = $current;
        }

        return true;
    }

    /** A group inside a comparison stands for whether it holds. */
    private function operand(mixed $value, ?callable $resolve): mixed
    {
        $value = $this->resolve($value, $resolve);

        if ($value instanceof ConditionGroupDTO || ConditionGroupDTO::isDefinition($value)) {
            return $this->evaluate($value, $resolve);
        }

        return $value;
    }

    private function resolve(mixed $value, ?callable $resolve): mixed
    {
        return $resolve === null ? $value : $resolve($value);
    }
}
