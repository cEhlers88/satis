<?php

namespace Cehlers88\AnalyticsCore\Support;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Support\Error\AbstractErrorBag;

/** Base class for property bag implementations. */
abstract class AbstractPropertyBag extends AbstractErrorBag implements PropertyBagInterface
{
    protected array $propertyLoads = [];

    /**
     * @var PropertyDTO[] $properties
     */
    private array $properties = [];

    /**
     * A copy owns its property definitions: the DTOs are mutable, so sharing them
     * would let loading values into the copy overwrite the ones of the original.
     */
    public function __clone()
    {
        $this->properties = array_map(
            static fn(PropertyDTO $property): PropertyDTO => clone $property,
            $this->properties
        );
    }

    public function getGroupedProperties(): array
    {
        $result = [];
        foreach ($this->properties as $property) {
            $groups = empty($property->groups) ? [PropertyBagInterface::GROUP_KEY_DEFAULT] : $property->groups;
            foreach ($groups as $group) {
                $result[$group][] = $property;
            }
        }
        return $result;
    }

    public function getProperties(): array
    {
        return $this->properties;
    }

    public function getPropertiesAsKeyValueArray(): array
    {
        $result = [];
        foreach ($this->properties as $property) {
            $result[$property->name] = $property->value;
        }
        return $result;

    }

    public function getPropertyValue(string $name, mixed $defaultValue = null): mixed
    {
        $property = $this->getProperty($name);

        if ($property === null) {
            return $defaultValue;
        }

        if ($property->isDefaultValue) {
            return $defaultValue ?? $property->value;
        }

        return $property->value;
    }

    public function getProperty(string $name): ?PropertyDTO
    {
        foreach ($this->properties as $property) {
            if ($property->name === $name) {
                return $property;
            }
        }
        return null;
    }

    public function loadPropertyValues(array $properties, bool $createIfNotExist = false): static
    {
        $this->propertyLoads = $properties;
        foreach ($properties as $key => $valueDef) {
            try {
                $this->setPropertyValue($valueDef[1], $valueDef[2]);
            } catch (\InvalidArgumentException $e) {
                if (!$createIfNotExist) {
                    throw $e;
                }
                $property = PropertyDTO::create($valueDef[1], $valueDef[2], $valueDef[0]);
                $property->isDefaultValue = false;
                $this->addProperty($property);
            }
        }

        return $this;
    }

    public function setPropertyValue(string $name, mixed $value, bool $createIfNotExist = false): static
    {
        foreach ($this->properties as $property) {
            if ($property->name === $name) {
                $property->isDefaultValue = $property->isDefaultValue && ($property->value === $value);
                $property->value = $value;
                return $this;
            }
        }

        if ($createIfNotExist) {
            return $this->addProperty(PropertyDTO::create($name, $value));
        }

        throw new \InvalidArgumentException(sprintf('Property "%s" does not exist', $name));
    }

    /**
     * @param PropertyDTO $property
     * @return $this
     * @throws \InvalidArgumentException
     */
    public function addProperty(PropertyDTO $property): static
    {
        if ($this->hasProperty($property->name)) {
            throw new \InvalidArgumentException(sprintf('Property "%s" already exists', $property->name));
        }

        $this->properties[] = $property;
        return $this;
    }

    public function hasProperty(string $name): bool
    {
        return $this->getProperty($name) !== null;
    }

    public function isValid(): bool
    {
        return $this->validate();
    }

    public function validate(): bool
    {
        foreach ($this->properties as $property) {
            if ($property->isDefaultValue && $property->isOptional === false) {
                $this->setError('Property "' . $property->name . '" is required', 404);
                return false;
            }
        }
        return true;
    }
}