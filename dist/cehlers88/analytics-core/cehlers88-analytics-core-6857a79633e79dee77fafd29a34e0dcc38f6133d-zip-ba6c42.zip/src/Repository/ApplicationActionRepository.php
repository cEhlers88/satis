<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\ApplicationAction;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<ApplicationAction>
 *
 * @method ApplicationAction|null find($id, $lockMode = null, $lockVersion = null)
 * @method ApplicationAction|null findOneBy(array $criteria, array $orderBy = null)
 * @method ApplicationAction[]    findAll()
 * @method ApplicationAction[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ApplicationActionRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry, private EntityManagerInterface $entityManager)
    {
        parent::__construct($registry, ApplicationAction::class);
    }

    public function save(ApplicationAction $applicationAction, bool $flush = true)
    {
        $this->entityManager->persist($applicationAction);
        if ($flush) {
            $this->entityManager->flush();;
        }
    }
}
