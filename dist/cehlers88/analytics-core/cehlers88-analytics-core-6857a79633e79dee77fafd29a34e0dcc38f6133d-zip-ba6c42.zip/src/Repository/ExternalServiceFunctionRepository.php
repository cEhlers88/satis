<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\ExternalServiceFunction;
use Cehlers88\AnalyticsCore\Interface\Repository\IExternalServiceFunctionRepository;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<ExternalServiceFunction>
 */
class ExternalServiceFunctionRepository extends ServiceEntityRepository implements IExternalServiceFunctionRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, ExternalServiceFunction::class);
    }

}
