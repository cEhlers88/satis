<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 23.08.2024
 * Time: 23:07
 */

namespace Cehlers88\AnalyticsCore\Macro\ValueHelper;

use Cehlers88\AnalyticsCore\Macro\AbstractMacro;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroValueHelperValidationResultDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\ValueHelperContextDTO;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;

/**
 * Offers the values a property may take while it is edited - named by a macro
 * through PropertyUi::valueHelper() and run by the ValueHelperRunner.
 *
 * A helper is instantiated without arguments: everything it may look at is
 * handed in through the setters - the context always, a macro environment only
 * when the editor runs inside one.
 */
abstract class AbstractValueHelper
{
    protected AbstractMacro $_currentMacro;
    protected MacroEnvironment $_macroEnvironment;
    protected ?ValueHelperContextDTO $_context = null;

    public function getDescription(): string
    {
        return "This helper has no description";
    }

    public function setMacroEnvironment(MacroEnvironment $macroEnvironment): self
    {
        $this->_macroEnvironment = $macroEnvironment;
        return $this;
    }

    public function hasMacroEnvironment(): bool
    {
        return isset($this->_macroEnvironment);
    }

    public function setCurrentMacro(AbstractMacro $macro): self
    {
        $this->_currentMacro = $macro;
        return $this;
    }

    public function setContext(ValueHelperContextDTO $context): self
    {
        $this->_context = $context;
        return $this;
    }

    public function getContext(): ValueHelperContextDTO
    {
        return $this->_context ?? ValueHelperContextDTO::create('', '');
    }

    /**
     * @param MacroPropertyDTO[] $currentProperties
     * @param array $options
     * @return array
     */
    abstract public function getDefinition(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): array;

    /**
     * @param MacroPropertyDTO[] $currentProperties
     * @param array $options
     * @return array
     */
    abstract public function validate(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): MacroValueHelperValidationResultDTO;

    /**
     * @param list<array{value: string, label: string, details?: array}> $selectOptions
     */
    protected function buildSelectDefinition(array $selectOptions, mixed $selected): array
    {
        return $this->buildDefinition('select', [
            'options' => $selectOptions,
            'selected' => $selected
        ]);
    }

    protected function buildOption(string $value, string $label = '', array $details = []): array
    {
        return [
            'details' => $details,
            'value' => $value,
            'label' => $label === '' ? $value : $label,
        ];
    }

    private function buildDefinition(string $type, array $data): array
    {
        return [
            'type' => $type,
            'data' => $data
        ];
    }

    protected function buildInputDefinition(string $inputType, string $name, string $label, mixed $value): array
    {
        return $this->buildDefinition('input', [
            'type' => $inputType,
            'name' => $name,
            'label' => $label,
            'value' => $value
        ]);
    }
}
