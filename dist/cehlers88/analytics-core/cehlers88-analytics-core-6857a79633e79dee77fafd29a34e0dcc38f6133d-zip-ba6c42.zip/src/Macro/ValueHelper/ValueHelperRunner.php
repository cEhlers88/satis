<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\ValueHelper;

use Cehlers88\AnalyticsCore\DTO\ConditionGroupDTO;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\ValueHelperContextDTO;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUi;
use Cehlers88\AnalyticsCore\Macro\PropertyUi\PropertyUiResolver;

/**
 * Runs the value helper of a property that is being edited.
 *
 * Before the helper is asked, the definition is searched for every other
 * property that is edited with the same helper, so a helper can offer what the
 * definition already holds without knowing a single macro.
 */
final class ValueHelperRunner
{
    /** Nothing sensible is nested this deep - a cycle would be. */
    private const int MAX_DEPTH = 64;

    public function __construct(
        private readonly CommandFactory     $commandFactory,
        private readonly PropertyUiResolver $propertyUiResolver
    )
    {
    }

    /**
     * @param string $valueHelperClass the helper the property names
     * @param array $options           the options the property names it with
     *
     * @return array{type: string, data: array}
     *
     * @throws \InvalidArgumentException for a class that is no value helper
     */
    public function run(
        string                $valueHelperClass,
        ValueHelperContextDTO $context,
        array                 $options = [],
        ?MacroEnvironment     $macroEnvironment = null
    ): array
    {
        $valueHelperClass = ltrim($valueHelperClass, '\\');

        if (!is_subclass_of($valueHelperClass, AbstractValueHelper::class)) {
            throw new \InvalidArgumentException(sprintf('"%s" is no value helper', $valueHelperClass));
        }

        $context->occurrences = $this->findOccurrences($context->definition, $valueHelperClass);

        /** @var AbstractValueHelper $valueHelper */
        $valueHelper = new $valueHelperClass();
        $valueHelper->setContext($context);

        if ($macroEnvironment !== null) {
            $valueHelper->setMacroEnvironment($macroEnvironment);
        }

        $command = $this->commandFactory->getCommandByName($context->commandName);
        $macro = $command === null ? null : $this->propertyUiResolver->macroOf($command);

        if ($macro !== null) {
            $valueHelper->setCurrentMacro($macro);
        }

        $currentProperties = [];
        foreach ($context->properties as $name => $value) {
            $currentProperties[] = MacroPropertyDTO::create((string)$name, [], '', $value);
        }

        return $valueHelper->getDefinition(
            MacroPropertyDTO::create($context->propertyName, [], '', $context->properties[$context->propertyName] ?? null),
            $currentProperties,
            $options
        );
    }

    /**
     * Every property of a definition that is edited with the given helper and
     * holds a plain value, together with the properties around it.
     *
     * @return list<array{commandName: string, propertyName: string, value: mixed, properties: array, options: array}>
     */
    public function findOccurrences(mixed $definition, string $valueHelperClass): array
    {
        $occurrences = [];

        $this->walk($definition, function (string $commandName, array $properties) use (&$occurrences, $valueHelperClass): void {
            $command = $this->commandFactory->getCommandByName($commandName);

            if ($command === null) {
                return;
            }

            foreach ($properties as $propertyName => $value) {
                if (!is_scalar($value)) {
                    continue;
                }

                $valueHelper = $this->propertyUiResolver->resolve($command, (string)$propertyName, $value)[PropertyUi::KEY_VALUE_HELPER] ?? null;

                if (($valueHelper['name'] ?? null) !== $valueHelperClass) {
                    continue;
                }

                $occurrences[] = [
                    'commandName' => $commandName,
                    'propertyName' => (string)$propertyName,
                    'value' => $value,
                    'properties' => $properties,
                    'options' => $valueHelper['options'] ?? [],
                ];
            }
        });

        return $occurrences;
    }

    /**
     * Visits every command of a definition - in lists, in the properties of
     * other commands and in condition groups.
     *
     * @param callable(string, array): void $visit
     */
    private function walk(mixed $value, callable $visit, int $depth = 0): void
    {
        if (!is_array($value) || $depth > self::MAX_DEPTH) {
            return;
        }

        if ($this->isCommand($value)) {
            $visit($value[0], $value[1]);
            $value = $value[1];
        } else if (ConditionGroupDTO::isDefinition($value)) {
            $value = $value[1];
        }

        foreach ($value as $entry) {
            $this->walk($entry, $visit, $depth + 1);
        }
    }

    private function isCommand(array $value): bool
    {
        return count($value) === 2
            && array_is_list($value)
            && is_string($value[0])
            && is_array($value[1])
            && ($value[1] === [] || !array_is_list($value[1]))
            && $this->commandFactory->getCommandByName($value[0]) !== null;
    }
}
