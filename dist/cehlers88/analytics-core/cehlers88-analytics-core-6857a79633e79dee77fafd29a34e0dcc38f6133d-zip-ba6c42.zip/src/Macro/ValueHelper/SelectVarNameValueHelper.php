<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 23.08.2024
 * Time: 23:10
 */

namespace Cehlers88\AnalyticsCore\Macro\ValueHelper;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroValueHelperValidationResultDTO;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;

/**
 * The variable names a definition already knows, to pick one instead of typing
 * it again.
 *
 * A variable name is whatever sits in a property that is edited with this
 * helper - the name of a setVar, of a getVar, the `as` of a for - so a macro
 * takes part by naming the helper, nothing is listed here. Also offered: the
 * arguments of the definition and, when the editor runs inside a macro
 * environment, the variables that exist there.
 *
 * Options:
 *  - contextProperty  the sibling property that holds the context (e.g. "context")
 *  - defaultContext   the context when there is no such property or it is empty
 */
class SelectVarNameValueHelper extends AbstractValueHelper
{
    public const string OPTION_CONTEXT_PROPERTY = 'contextProperty';
    public const string OPTION_DEFAULT_CONTEXT = 'defaultContext';

    private const array DEFAULT_OPTIONS = [
        self::OPTION_CONTEXT_PROPERTY => null,
        self::OPTION_DEFAULT_CONTEXT => 'job',
    ];

    /**
     * The contexts a variable may live in, to choose from.
     *
     * @return array<string, string>
     */
    public static function contextOptions(): array
    {
        $options = [];
        foreach (eMacroVariableContext::cases() as $context) {
            $options[$context->value] = ucfirst($context->value);
        }

        return $options;
    }

    public function getDescription(): string
    {
        return "This helper helps you to select a variable name";
    }

    public function getDefinition(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): array
    {
        $context = $this->getContext();
        $currentContext = $this->contextOf($context->properties, $options);
        $found = [];

        foreach ($context->occurrences as $occurrence) {
            $this->addName(
                $found,
                $occurrence['value'] ?? null,
                $this->contextOf($occurrence['properties'] ?? [], $occurrence['options'] ?? $options),
                'definition'
            );
        }

        foreach ($context->arguments as $argument) {
            $this->addName($found, $argument[1] ?? $argument['name'] ?? null, eMacroVariableContext::ARGUMENT->value, 'argument');
        }

        foreach ($this->environmentVariables() as $variableContext => $variables) {
            foreach (array_keys(is_array($variables) ? $variables : []) as $variableName) {
                $this->addName($found, $variableName, strtolower((string)$variableContext), 'environment');
            }
        }

        // The names of the context the property is in come first - they are
        // the ones that can be read from here without naming another context.
        uasort($found, static function (array $left, array $right) use ($currentContext): int {
            $leftOutside = $left['details']['context'] !== $currentContext;
            $rightOutside = $right['details']['context'] !== $currentContext;

            return [$leftOutside, $left['value'], $left['details']['context']]
                <=> [$rightOutside, $right['value'], $right['details']['context']];
        });

        return $this->buildSelectDefinition(array_values($found), $propertyDTO->value ?? '');
    }

    public function validate(MacroPropertyDTO $propertyDTO, array $currentProperties = [], array $options = []): MacroValueHelperValidationResultDTO
    {
        return MacroValueHelperValidationResultDTO::create(true);
    }

    private function addName(array &$found, mixed $name, string $context, string $source): void
    {
        if (!is_string($name) && !is_int($name)) {
            return;
        }

        $name = trim((string)$name);

        if ($name === '' || isset($found[$context . "\0" . $name])) {
            return;
        }

        $found[$context . "\0" . $name] = $this->buildOption($name, $name, [
            'context' => $context,
            'source' => $source,
            'whenSelect' => ['context' => $context],
        ]);
    }

    /** The context a set of properties names, the default one when it names none. */
    private function contextOf(array $properties, array $options): string
    {
        $options = array_replace(self::DEFAULT_OPTIONS, $options);
        $contextProperty = $options[self::OPTION_CONTEXT_PROPERTY];
        $context = is_string($contextProperty) ? ($properties[$contextProperty] ?? null) : null;

        if ($context instanceof eMacroVariableContext) {
            return $context->value;
        }

        return is_string($context) && trim($context) !== ''
            ? strtolower(trim($context))
            : strtolower((string)$options[self::OPTION_DEFAULT_CONTEXT]);
    }

    private function environmentVariables(): array
    {
        if (!$this->hasMacroEnvironment()) {
            return [];
        }

        try {
            return $this->_macroEnvironment->getVariablesStoreProvider()->getAllVariables();
        } catch (\Throwable) {
            // An environment that was not loaded for a run knows no variables.
            return [];
        }
    }
}
