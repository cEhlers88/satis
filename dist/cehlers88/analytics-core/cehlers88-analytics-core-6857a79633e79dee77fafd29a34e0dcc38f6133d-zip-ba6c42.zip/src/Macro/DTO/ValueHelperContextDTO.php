<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

/**
 * Where a value helper is asked from: the property being edited and the
 * definition around it, the way the editor holds it right now.
 */
final class ValueHelperContextDTO extends DTO
{
    public string $commandName = '';

    public string $propertyName = '';

    /** @var array<string, mixed> the properties of the command being edited */
    public array $properties = [];

    /** The whole definition the command sits in. */
    public mixed $definition = null;

    /** @var list<array> the arguments of the definition - [type, name] */
    public array $arguments = [];

    /**
     * Every property of the definition that is edited with the same value
     * helper and holds a plain value - filled in by the ValueHelperRunner.
     *
     * @var list<array{commandName: string, propertyName: string, value: mixed, properties: array, options: array}>
     */
    public array $occurrences = [];

    public static function create(
        string $commandName,
        string $propertyName,
        array  $properties = [],
        mixed  $definition = null,
        array  $arguments = []
    ): self
    {
        $dto = new self();
        $dto->commandName = $commandName;
        $dto->propertyName = $propertyName;
        $dto->properties = $properties;
        $dto->definition = $definition;
        $dto->arguments = array_values(array_filter($arguments, 'is_array'));

        return $dto;
    }
}
