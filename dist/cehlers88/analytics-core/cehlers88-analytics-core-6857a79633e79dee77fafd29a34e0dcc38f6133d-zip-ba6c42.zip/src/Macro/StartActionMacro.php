<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Macro\AbstractMacro;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Repository\ApplicationActionRepository;
use Symfony\Component\Mercure\HubInterface;
use Symfony\Component\Mercure\Update;

class StartActionMacro extends AbstractMacro
{
    private const PROPERTY_ACTION = 'action';
    private const PROPERTY_ACTION_PROPERTIES = 'props';

    public function __construct(
        private ApplicationActionRepository $applicationActionRepository,
        private CommandFactory              $commandFactory,
        private HubInterface                $hub
    )
    {
    }

    public function init(): StartActionMacro
    {
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ACTION, ['string'], 'The action to start'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ACTION_PROPERTIES, ['array'], 'The properties for the action', []));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Starts an action.';
    }

    protected function run(): ?array
    {
        $actionName = $this->getPropertyValue(self::PROPERTY_ACTION);
        $application = $this->getMacroEnvironment()->getApplication();
        $applicationAction = $this->applicationActionRepository->findOneBy([
            'application' => $application,
            'name' => $actionName
        ]);

        if (empty($applicationAction)) {
            return $this->_createRunResult('error', ErrorDTO::create(
                404,
                sprintf('No ApplicationAction with name "%s" in Application %s found', $actionName, $application->getName())));
        }

        $applicationAction->setState(true);
        $this->applicationActionRepository->save($applicationAction);

        $startCommandsResult = null;
        $endCommandsResult = null;

        $startCommands = $applicationAction->getStartCommands();
        if (count($startCommands) > 0) {
            $startCommandsDefinition = $this->commandFactory->evalDefinitionArray($applicationAction->getStartCommands());
            $startCommandsResult = $this->_runCommandDefinition($startCommandsDefinition);
        }

        if ($applicationAction->isAutoStop()) {
            $endCommandsResult = $this->_executeMacro('stopAction', [
                'action' => $actionName
            ])['returnValue'];
        }

        /*
                $this->hub->publish(new Update(
                    'action/start',
                    json_encode(['action' => $actionName, 'properties' => $this->getPropertyValue(self::PROPERTY_ACTION_PROPERTIES)])
                ));

        */
        return $this->_createRunResult([$startCommandsResult, $endCommandsResult]);
    }

    public function getName(): string
    {
        return 'startAction';
    }
}