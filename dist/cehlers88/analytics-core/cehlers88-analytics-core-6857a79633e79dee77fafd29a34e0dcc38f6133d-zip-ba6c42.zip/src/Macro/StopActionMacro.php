<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\AbstractMacro;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Repository\ApplicationActionRepository;
use Symfony\Component\Mercure\HubInterface;
use Symfony\Component\Mercure\Update;

class StopActionMacro extends AbstractMacro
{
    private const PROPERTY_ACTION = 'action';

    public function __construct(
        private HubInterface                $hub,
        private ApplicationActionRepository $applicationActionRepository,
    )
    {
    }

    public function init(): StopActionMacro
    {
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ACTION, ['string'], 'The action to stop'));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Stops an action.';
    }

    protected function run(): ?array
    {
        $actionName = $this->getPropertyValue(self::PROPERTY_ACTION);
        $application = $this->getMacroEnvironment()->getApplication();
        $applicationAction = $this->applicationActionRepository->findOneBy([
            'application' => $application,
            'name' => $actionName
        ]);

        if (empty($applicationAction)) {
            return $this->_createRunResult('error', ErrorDTO::create(
                404,
                sprintf('No ApplicationAction with name "%s" in Application %s found', $actionName, $application->getName())));
        }

        $applicationAction->setState(false);
        $this->applicationActionRepository->save($applicationAction);

        /*$this->hub->publish(new Update(
            'action/stop',
            json_encode(['action' => $actionName])
        ));*/
        return $this->_createRunResult(null);
    }

    public function getName(): string
    {
        return 'stopAction';
    }

}