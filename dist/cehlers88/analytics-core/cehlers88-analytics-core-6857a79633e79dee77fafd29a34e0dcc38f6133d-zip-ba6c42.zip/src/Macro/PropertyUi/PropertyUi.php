<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\PropertyUi;

use Cehlers88\AnalyticsCore\Macro\ValueHelper\AbstractValueHelper;

/**
 * How a property of a command is edited - the contract between a macro and the
 * command editors of the application (the commands view and the code view).
 *
 *     PropertyUi::condition()->displayName('if')
 *     PropertyUi::commands()->displayName('True')->cssClass('is-case case-true')
 *     PropertyUi::create()->valueHelper(SelectVarNameValueHelper::class, ['contextProperty' => 'context'])
 *
 * Every key is optional. Keys this class does not know are passed through, so
 * an editor may be taught more without touching the contract.
 */
final class PropertyUi
{
    /** A single value - text or a command. The default. */
    public const string EDITOR_TEXT = 'text';
    /** One of `options`, nothing else. */
    public const string EDITOR_SELECT = 'select';
    /** A block of commands, e.g. the branches of an `if`. */
    public const string EDITOR_COMMANDS = 'commands';
    /** A condition group - see ConditionEvaluator for what it may hold. */
    public const string EDITOR_CONDITION = 'condition';
    /** A list of cases - `[{"when": …, "commands": […]}, …]`, e.g. the cases of a `switch`. */
    public const string EDITOR_CASES = 'cases';

    public const string KEY_CLASS = 'class';
    public const string KEY_DESCRIPTION = 'description';
    public const string KEY_DISPLAY_NAME = 'displayName';
    public const string KEY_EDITOR = 'editor';
    public const string KEY_OPTIONS = 'options';
    public const string KEY_PLACEHOLDER = 'placeholder';
    public const string KEY_VALUE_HELPER = 'valueHelper';

    private array $infos = [];

    public static function create(): self
    {
        return new self();
    }

    public static function commands(): self
    {
        return self::create()->editor(self::EDITOR_COMMANDS);
    }

    public static function condition(): self
    {
        return self::create()->editor(self::EDITOR_CONDITION);
    }

    /**
     * The infos a provider, a command row or a legacy extender hands in, in the
     * one shape the editors read: a value helper always as `{name, options}`,
     * options always as a value => label map. What cannot be used is dropped.
     */
    public static function normalize(self|array|null $infos): array
    {
        if ($infos === null) {
            return [];
        }

        $infos = $infos instanceof self ? $infos->toArray() : $infos;

        if (array_key_exists(self::KEY_VALUE_HELPER, $infos)) {
            $valueHelper = self::normalizeValueHelper($infos[self::KEY_VALUE_HELPER]);

            if ($valueHelper === null) {
                unset($infos[self::KEY_VALUE_HELPER]);
            } else {
                $infos[self::KEY_VALUE_HELPER] = $valueHelper;
            }
        }

        if (isset($infos[self::KEY_OPTIONS]) && is_array($infos[self::KEY_OPTIONS]) && array_is_list($infos[self::KEY_OPTIONS])) {
            $infos[self::KEY_OPTIONS] = array_combine(
                array_map('strval', $infos[self::KEY_OPTIONS]),
                array_map('strval', $infos[self::KEY_OPTIONS])
            );
        }

        return $infos;
    }

    /**
     * Only a class that really is a value helper is kept: the class name goes
     * to the browser and comes back to be instantiated.
     *
     * @return array{name: class-string<AbstractValueHelper>, options: array}|null
     */
    private static function normalizeValueHelper(mixed $valueHelper): ?array
    {
        $options = [];

        if (is_array($valueHelper)) {
            $options = is_array($valueHelper['options'] ?? null) ? $valueHelper['options'] : [];
            $valueHelper = $valueHelper['name'] ?? $valueHelper['class'] ?? null;
        }

        if (!is_string($valueHelper) || !is_subclass_of($valueHelper, AbstractValueHelper::class)) {
            return null;
        }

        return ['name' => ltrim($valueHelper, '\\'), 'options' => $options];
    }

    public function cssClass(string $class): self
    {
        $this->infos[self::KEY_CLASS] = trim(($this->infos[self::KEY_CLASS] ?? '') . ' ' . $class);
        return $this;
    }

    public function description(string $description): self
    {
        $this->infos[self::KEY_DESCRIPTION] = $description;
        return $this;
    }

    public function displayName(string $displayName): self
    {
        $this->infos[self::KEY_DISPLAY_NAME] = $displayName;
        return $this;
    }

    public function editor(string $editor): self
    {
        $this->infos[self::KEY_EDITOR] = $editor;
        return $this;
    }

    /**
     * Fixed values to choose from. With the select editor nothing else may be
     * chosen, with every other editor they are suggestions.
     *
     * @param array<string, string>|list<string> $options value => label, or plain values
     */
    public function options(array $options): self
    {
        $this->infos[self::KEY_OPTIONS] = $options;
        return $this;
    }

    public function placeholder(string $placeholder): self
    {
        $this->infos[self::KEY_PLACEHOLDER] = $placeholder;
        return $this;
    }

    /**
     * Suggestions that depend on the definition being edited, asked for while
     * the property is edited.
     *
     * @param class-string<AbstractValueHelper> $valueHelper
     */
    public function valueHelper(string $valueHelper, array $options = []): self
    {
        $this->infos[self::KEY_VALUE_HELPER] = ['name' => $valueHelper, 'options' => $options];
        return $this;
    }

    public function with(string $key, mixed $value): self
    {
        $this->infos[$key] = $value;
        return $this;
    }

    public function toArray(): array
    {
        return self::normalize($this->infos);
    }
}
