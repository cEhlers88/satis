<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\Macro\PropertyUi;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

/**
 * A macro that says how its properties are edited in the command editors.
 *
 * Found through the macro a command runs, so a command row needs nothing for
 * it - see PropertyUiResolver for what else is merged in.
 */
interface PropertyUiProviderInterface
{
    /**
     * How one property is edited, null when it is edited the way its value
     * suggests. Static on purpose: it describes the property, not a run, and
     * may be asked without the macro ever being set up.
     *
     * $property carries the name, the types of the command row and the value
     * the property currently holds.
     */
    public static function getPropertyUiInfos(MacroPropertyDTO $property): PropertyUi|array|null;
}
