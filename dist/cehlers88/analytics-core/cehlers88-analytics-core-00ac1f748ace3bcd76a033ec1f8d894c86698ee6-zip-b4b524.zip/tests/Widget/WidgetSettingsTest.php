<?php

namespace Cehlers88\AnalyticsCore\Tests\Widget;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Widget\WidgetSettings;
use PHPUnit\Framework\TestCase;

class WidgetSettingsTest extends TestCase
{
    // ── normalizing ──────────────────────────────────────────────────────────

    public function testValuesAreCastToWhatTheirPropertyDescribes(): void
    {
        $props = $this->makeSettings()->normalize(
            [PropertyDTO::create('limit', 10, 'int', ui: ['min' => 1, 'max' => 50])],
            ['limit' => '80']
        );

        $this->assertSame(['limit' => 50], $props);
    }

    public function testSettingsNoWidgetAsksForAreDropped(): void
    {
        $props = $this->makeSettings()->normalize(
            [PropertyDTO::create('limit', '', 'string')],
            ['limit' => '10', 'somethingElse' => 'nope']
        );

        $this->assertSame(['limit' => '10'], $props);
    }

    public function testAnOptionalSettingThatWasNotAnsweredStaysOutOfTheProps(): void
    {
        $props = $this->makeSettings()->normalize(
            [PropertyDTO::create('keyFilter', '', 'string', isOptional: true)],
            []
        );

        $this->assertSame([], $props);
    }

    /**
     * A checkbox that is switched off is not submitted at all, which is exactly
     * what "false" means for it.
     */
    public function testAnUnsubmittedCheckboxIsStoredAsFalse(): void
    {
        $props = $this->makeSettings()->normalize(
            [PropertyDTO::create('compact', false, 'bool', isOptional: true)],
            []
        );

        $this->assertSame(['compact' => false], $props);
    }

    public function testADottedNameNestsTheValue(): void
    {
        $props = $this->makeSettings()->normalize(
            [
                PropertyDTO::create('source.entity', null, 'string'),
                PropertyDTO::create('source.keyFilter', '', 'string', isOptional: true),
            ],
            ['source' => ['entity' => 'SystemLog', 'keyFilter' => 'checkout']]
        );

        $this->assertSame(['source' => ['entity' => 'SystemLog', 'keyFilter' => 'checkout']], $props);
    }

    public function testAPropertyWithOptionsOnlyAcceptsOneOfThem(): void
    {
        $definition = PropertyDTO::create(
            name: 'source',
            value: null,
            type: 'string',
            ui: ['options' => ['SystemLog' => 'Systemprotokoll']]
        );

        $props = $this->makeSettings()->normalize([$definition], ['source' => 'TrackingBuffer']);

        $this->assertSame(['source' => null], $props);
    }

    // ── settings a widget insists on ─────────────────────────────────────────

    public function testASettingTheWidgetInsistsOnIsReportedWhileItIsUnanswered(): void
    {
        $definition = PropertyDTO::create('source.entity', null, 'string');

        $missing = $this->makeSettings()->findUnsatisfied([$definition], []);

        $this->assertSame([$definition], $missing);
    }

    public function testASettingAnsweredWithNothingIsReported(): void
    {
        $definition = PropertyDTO::create('source.entity', null, 'string');

        $missing = $this->makeSettings()->findUnsatisfied([$definition], ['source' => ['entity' => '  ']]);

        $this->assertSame([$definition], $missing);
    }

    public function testAnAnsweredSettingIsNotReported(): void
    {
        $definition = PropertyDTO::create('source.entity', null, 'string');

        $missing = $this->makeSettings()->findUnsatisfied([$definition], ['source' => ['entity' => 'SystemLog']]);

        $this->assertSame([], $missing);
    }

    /**
     * Props that come back from a widget request are decoded json, so a nested
     * setting arrives as an object rather than an array.
     */
    public function testNestedPropsAreAlsoReadFromObjects(): void
    {
        $definition = PropertyDTO::create('source.entity', null, 'string');

        $missing = $this->makeSettings()->findUnsatisfied(
            [$definition],
            ['source' => (object)['entity' => 'SystemLog']]
        );

        $this->assertSame([], $missing);
    }

    /**
     * A checkbox the widget insists on is a checkbox that has to be ticked.
     */
    public function testACheckboxTheWidgetInsistsOnIsReportedWhileItIsSwitchedOff(): void
    {
        $definition = PropertyDTO::create('confirmed', false, 'bool');

        $this->assertSame([$definition], $this->makeSettings()->findUnsatisfied([$definition], ['confirmed' => false]));
        $this->assertSame([], $this->makeSettings()->findUnsatisfied([$definition], ['confirmed' => true]));
    }

    public function testOptionalSettingsAreNeverReported(): void
    {
        $missing = $this->makeSettings()->findUnsatisfied(
            [PropertyDTO::create('keyFilter', '', 'string', isOptional: true)],
            []
        );

        $this->assertSame([], $missing);
    }

    private function makeSettings(): WidgetSettings
    {
        return new WidgetSettings();
    }
}
