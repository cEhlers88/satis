<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;

/**
 * Turns the values submitted for a widget into the props it is rendered with,
 * and says which of the settings it insists on are still unanswered.
 *
 * A widget describes its settings as PropertyDTOs: the name is the prop the
 * value ends up in, the type says what the value is, and isOptional says
 * whether the widget can be rendered without it. The ui bag carries what the
 * value type does not imply - a selection, the bounds of a number, or an input
 * control of its own choosing.
 *
 * A name may be a dotted path ("source.entity"), which nests the value inside
 * the props - so a widget reading $props['source']->entity describes that
 * setting as "source.entity".
 */
class WidgetSettings
{
    /**
     * Unknown keys are dropped and known ones are cast to the type their
     * property describes, so a widget can never be stored with props of the
     * client's own making.
     *
     * @param PropertyDTO[] $definitions
     */
    public function normalize(array $definitions, array $submittedSettings): array
    {
        $props = [];

        foreach ($definitions as $definition) {
            $submittedValue = $this->readPath($submittedSettings, $definition->name);

            // An unchecked checkbox is not submitted at all, which is exactly
            // what "false" means for it.
            if (is_null($submittedValue) && $this->isBooleanLike($definition)) {
                $props = $this->writePath($props, $definition->name, false);
                continue;
            }

            // An optional setting nobody answered stays out of the props, so
            // the widget keeps deciding what its default is.
            if (is_null($submittedValue) && $definition->isOptional) {
                continue;
            }

            $props = $this->writePath($props, $definition->name, $this->castValue($definition, $submittedValue));
        }

        return $props;
    }

    /**
     * The settings a widget insists on that the given props do not answer - an
     * empty array means the widget has everything it needs.
     *
     * @param PropertyDTO[] $definitions
     *
     * @return PropertyDTO[]
     */
    public function findUnsatisfied(array $definitions, array $props): array
    {
        $unsatisfied = [];

        foreach ($definitions as $definition) {
            if (!$this->isSatisfied($definition, $this->readPath($props, $definition->name))) {
                $unsatisfied[] = $definition;
            }
        }

        return $unsatisfied;
    }

    /**
     * Whether the given value is enough to satisfy the setting. Optional ones
     * are always satisfied, including by nothing at all.
     */
    private function isSatisfied(PropertyDTO $definition, mixed $value): bool
    {
        if ($definition->isOptional) {
            return true;
        }

        if ($this->isBooleanLike($definition)) {
            return $value === true;
        }

        if (is_null($value)) {
            return false;
        }

        return !is_scalar($value) || trim((string)$value) !== '';
    }

    /**
     * Casts a raw (request) value into what the property describes. The default
     * value of the property is what a value that does not fit falls back to.
     */
    private function castValue(PropertyDTO $definition, mixed $value): mixed
    {
        if (is_null($value)) {
            return $definition->value;
        }

        if ($this->isBooleanLike($definition)) {
            return is_scalar($value) ? filter_var($value, FILTER_VALIDATE_BOOL) : $definition->value;
        }

        if (count($definition->ui['options'] ?? []) > 0) {
            return array_key_exists((string)$value, $definition->ui['options']) ? $value : $definition->value;
        }

        return match (strtolower($definition->type)) {
            'int', 'integer', 'float', 'double' => $this->clamp($definition, $value),
            default => is_scalar($value) ? trim((string)$value) : $definition->value,
        };
    }

    private function isBooleanLike(PropertyDTO $definition): bool
    {
        return in_array(strtolower($definition->type), ['bool', 'boolean'], true);
    }

    private function clamp(PropertyDTO $definition, mixed $value): int|float
    {
        $number = is_numeric($value) ? $value + 0 : ($definition->value ?? 0);
        $min = $definition->ui['min'] ?? null;
        $max = $definition->ui['max'] ?? null;

        if (!is_null($min) && $number < $min) {
            $number = $min;
        }
        if (!is_null($max) && $number > $max) {
            $number = $max;
        }

        return in_array(strtolower($definition->type), ['float', 'double'], true) ? (float)$number : (int)$number;
    }

    /**
     * Reads a dotted path out of nested values, where every segment that is not
     * there ends the lookup. Objects are walked as well, because props that
     * came back from a widget request are decoded json.
     */
    private function readPath(array $values, string $path): mixed
    {
        $current = $values;

        foreach (explode('.', $path) as $segment) {
            $current = is_object($current) ? (array)$current : $current;

            if (!is_array($current) || !array_key_exists($segment, $current)) {
                return null;
            }

            $current = $current[$segment];
        }

        return $current;
    }

    /**
     * Writes a value into nested values along a dotted path, creating the
     * intermediate levels on the way.
     */
    private function writePath(array $values, string $path, mixed $value): array
    {
        $segments = explode('.', $path);
        $key = array_shift($segments);

        if (count($segments) === 0) {
            $values[$key] = $value;

            return $values;
        }

        $nested = is_array($values[$key] ?? null) ? $values[$key] : [];
        $values[$key] = $this->writePath($nested, implode('.', $segments), $value);

        return $values;
    }
}
