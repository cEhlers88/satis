<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:40
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

use Cehlers88\AnalyticsCore\Entity\AbstractEntity;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;
use Cehlers88\AnalyticsCore\Repository\CustomEntityRepository;

/** Provider for managing custom object instances. */
class CustomObjectProvider
{
    public function __construct(
        private iterable               $customEntityClasses,
        private CustomEntityRepository $customEntityRepository
    )
    {
    }

    /**
     * @param CustomObjectInterface $customEntity
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClass(CustomObjectInterface $customEntity): array
    {
        return $this->getCustomEntitiesByClassName($customEntity->getClassName());
    }

    /**
     * @param string $className
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClassName(string $className): array
    {
        return $this->getCustomEntitiesBy(['className' => $className]);
    }

    /**
     * @param array<string, mixed> $filters
     * @return CustomObjectInterface[]|CustomEntity[]
     */
    public function getCustomEntitiesBy(array $filters, bool $resolveEntities = true): array
    {
        $result = [];

        foreach ($this->customEntityRepository->findBy($filters) as $entry) {
            if (!$resolveEntities) {
                $result[] = $entry;
                continue;
            }
            $result[] = $this->resolveCustomEntity($entry);
        }

        return $result;
    }

    /**
     * Resolve a CustomEntity into a CustomObjectInterface instance.
     *
     * @param CustomEntity $customEntity The entity to resolve.
     * @return CustomObjectInterface
     */
    public function resolveCustomEntity(CustomEntity $customEntity): CustomObjectInterface
    {
        $className = $customEntity->getClassName();

        /** @var CustomObjectInterface $instance */
        $instance = new $className();
        $instance->load($customEntity);
        $instance->setChildObjects($this->getCustomEntitiesBy(['parentId' => $customEntity->getId()]));

        return $instance;
    }

    public function getCustomEntityByClassNameAndName(string $className, string $name, bool $resolveEntity = true): CustomObjectInterface|CustomEntity|null
    {
        $entity = $this->customEntityRepository->findOneBy(['className' => $className, 'name' => $name]);
        if ($entity === null || !$resolveEntity) {
            return $entity;
        }
        return $this->resolveCustomEntity($entity);
    }

    public function getCustomEntitiesByClassNameAndAttribute(string $className, string $attributeName, string $attributeValue): array
    {
        $entities = $this->customEntityRepository->findByClassAndAttribute($className, $attributeName, $attributeValue);
        return array_map(fn(CustomEntity $entity) => $this->resolveCustomEntity($entity), $entities);
    }

    public function getAttributesOfCustomEntityClass(string $className): array
    {
        return $this->customEntityRepository->findAttributeNamesByClass($className);
    }

    public function getCustomObjectById(int $id, bool $resolveEntity = true): CustomObjectInterface|CustomEntity|null
    {
        return $this->getCustomEntitiesBy(['id' => $id], $resolveEntity)[0];
    }

    /**
     * Get all registered custom entity classes.
     *
     * @return CustomObjectInterface[]
     */
    public function getCustomClasses(): iterable
    {
        return $this->customEntityClasses;
    }

    public function createNewCustomEntity(string $className): CustomObjectInterface
    {
        /** @var CustomObjectInterface $buffer */
        $buffer = new $className();

        $buffer
            ->setCreatedAt(new \DateTimeImmutable())
            ->setModifiedAt(new \DateTimeImmutable());

        return $buffer;
    }

    public function save(CustomObjectInterface|CustomEntity $customEntityToSave): void
    {
        $isNew = $customEntityToSave->getId() === null || $customEntityToSave->getId() <= 0;
        $attrs = [];
        $entity = null;

        if (!$isNew) {
            $entity = $this->customEntityRepository->find($customEntityToSave->getId());
            foreach ($entity->getAttributes() as $attribute) {
                $attrs[$attribute->getName()] = [
                    'obj' => $attribute,
                    'stillExist' => false,
                    'isNew' => false
                ];
            }
        } else {
            $entity = new CustomEntity();
            $entity
                ->setClassName($customEntityToSave->getClassName())
                ->setCreatedAt(new \DateTime());
        }

        foreach ($customEntityToSave->getAttributes() as $attributeName => $attributeValue) {
            if ($attributeValue instanceof CustomEntityAttribute) {
                $attributeName = $attributeValue->getName();
                $attributeValue = $attributeValue->getValue();
            }

            $attrs[$attributeName]['stillExist'] = true;
            $entity->setAttributeValue($attributeName, $attributeValue);
        }

        $entity->setName($customEntityToSave->getName());
        $entity->setParentId($customEntityToSave->getParentId());
        $entity->setModifiedAt(new \DateTime());

        foreach ($attrs as $attributeName => $attribute) {
            if (!$attribute['stillExist']) {
                $entity->removeAttribute($attribute['obj']);
            }
        }

        $this->customEntityRepository->save($entity);
    }
}