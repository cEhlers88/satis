<?php

namespace Cehlers88\AnalyticsCore\Player;

use Cehlers88\AnalyticsCore\DTO\ConditionGroupDTO;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\ENUM\eDebuggerLogType;
use Cehlers88\AnalyticsCore\ENUM\eInstructionType;
use Cehlers88\AnalyticsCore\ENUM\eSelfCheckResult;
use Cehlers88\AnalyticsCore\Macro\AbstractMacro;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Macro\Protector\AbstractMacroProtector;
use Cehlers88\AnalyticsCore\Provider\MacroExtensionProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
use Exception;

class MacroPlayer
{
    private const MACRO_NAME_ARGUMENT_INDEX = 0; //todo: auslagern in .env
    private const MACRO_PROPS_ARGUMENT_INDEX = 1;
    private const array OPERATORS = [
        '==' => eConditionType::EQUALS,
        '===' => eConditionType::EQUALS,
        'equals' => eConditionType::EQUALS,
        '!=' => eConditionType::NOT_EQUALS,
        '>' => eConditionType::GREATER_THAN,
        '>=' => eConditionType::GREATER_THAN_OR_EQUALS,
        '<' => eConditionType::LESS_THAN,
        '<=' => eConditionType::LESS_THAN_OR_EQUALS,
        '&&' => eConditionType::AND,
        'and' => eConditionType::AND,
        '||' => eConditionType::OR,
        'or' => eConditionType::OR,
        'xor' => eConditionType::XOR
    ];
    private string $_macroProtectorName = "demo-mode";
    private eSelfCheckResult $_selfErrorCheckResult = eSelfCheckResult::NotChecked;
    private MacroEnvironment $_macroEnvironment;
    private AbstractMacroProtector $_macroProtector;
    private ?LoggerInterface $_logger = null;
    /** @var array<string, AbstractMacro|null> */
    private array $_macroNameCache = [];

    public function __construct(
        private iterable               $macros,
        private iterable               $macroProtectors,
        private MacroExtensionProvider $_macroExtensionProvider,
        private ApplicationRepository  $_applicationRepository
    )
    {
        $this->_bindMacroExtensions();
        $this->_bindMacroProtector();
    }

    private function _bindMacroExtensions(): void
    {

    }

    private function _bindMacroProtector(): void
    {
        foreach ($this->macroProtectors as $macroProtector) {
            if ($macroProtector->getName() === $this->_macroProtectorName) {
                $this->_macroProtector = $macroProtector;
                break;
            }
        }
    }

    public function getMacros(): iterable
    {
        return $this->macros;
    }

    public function getMacroEnvironment(): MacroEnvironment
    {
        return $this->_macroEnvironment;
    }

    public function setMacroEnvironment(MacroEnvironment $_macroEnvironment): MacroPlayer
    {
        $this->_macroEnvironment = $_macroEnvironment;
        $this->_selfErrorCheckResult = eSelfCheckResult::NotChecked;
        return $this;
    }

    public function getMacroExtensions(): iterable
    {
        return $this->_macroExtensionProvider->getExtensions();
    }

    public function setApplicationById(int $applicationId): MacroPlayer
    {
        return $this->setApplication($this->_applicationRepository->find($applicationId));
    }

    public function setApplication(Application $application): MacroPlayer
    {
        $this->_macroEnvironment->setApplication($application);
        $this->_selfErrorCheckResult = eSelfCheckResult::NotChecked;
        return $this;
    }

    private function _evalMacroCallsInArguments(array $arguments): array
    {
        $result = [];
        foreach ($arguments as $argumentName => $argumentValue) {
            $updatedArgumentValue = false;
            if (is_array($argumentValue)) {
                if (
                    count($argumentValue) === 2 &&
                    isset($argumentValue[self::MACRO_NAME_ARGUMENT_INDEX]) &&
                    is_string($argumentValue[self::MACRO_NAME_ARGUMENT_INDEX])
                ) {
                    if ($this->_isValidMacroName($argumentValue[self::MACRO_NAME_ARGUMENT_INDEX])) {
                        $subMacroResult = $this->executeMacro(
                            $argumentValue[self::MACRO_NAME_ARGUMENT_INDEX],
                            $argumentValue[self::MACRO_PROPS_ARGUMENT_INDEX]
                        );

                        if ($subMacroResult['hasError']) {
                            throw new Exception("Error in child macro: '" . $argumentValue[0] . "'" . $subMacroResult['message']);
                        }
                        if (!isset($subMacroResult['returnValue']['__void']) || !$subMacroResult['returnValue']['__void']) {
                            $result[$argumentName] = $subMacroResult['returnValue'];
                            $updatedArgumentValue = true;
                        }
                    } else if ($this->_isOperator($normalizedOperator = strtolower($argumentValue[self::MACRO_NAME_ARGUMENT_INDEX]))) {
                        foreach ($argumentValue[1] as $key => $value) {
                            if (is_array($value) && count($value) === 2 && is_string($value[0]) && $this->_isValidMacroName($value[0])) {
                                $subMacroResult = $this->executeMacro($value[0], $value[1]);
                                if ($subMacroResult['hasError']) {
                                    throw new Exception("Error in child macro: '" . $value[0] . "'" . $subMacroResult['message']);
                                }
                                $argumentValue[1][$key] = $subMacroResult['returnValue'];

                            }
                        }
                        $argumentValue = ConditionGroupDTO::create(
                            $argumentValue[1],
                            self::OPERATORS[$normalizedOperator]
                        );
                    }
                }
            }

            if (!$updatedArgumentValue) {
                $result[$argumentName] = $argumentValue;
            }
        }
        return $result;
    }

    private function _isValidMacroName(string $macroName): bool
    {
        return !is_null($this->_getMacroByName($macroName));
    }

    private function _getMacroByName(string $macroName): ?AbstractMacro
    {
        $macroName = ltrim($macroName, '\\');

        if (array_key_exists($macroName, $this->_macroNameCache)) {
            return $this->_macroNameCache[$macroName];
        }

        foreach ($this->macros as $macro) {
            if (
                (strpos($macroName, '\\') !== false && get_class($macro) === $macroName) ||
                $macro->getName() === $macroName
            ) {
                return $this->_macroNameCache[$macroName] = $macro;
            }
        }

        return $this->_macroNameCache[$macroName] = null;
    }

    public function executeMacro(string $macroName, array $arguments = []): ?array
    {
        $protectorResult = $this->_macroProtector->isAllowed($macroName, $arguments);
        if (!$protectorResult->isAllowed) {
            die('not allowed');
        }

        $instructionId = $this->_macroEnvironment->getNextInstructionId();
        $this->_macroEnvironment->getDebugger()->logStart(eInstructionType::MACRO, $instructionId, $macroName, $arguments);

        $arguments = $this->_evalMacroCallsInArguments($arguments);
        $executeAble = ($this->_selfErrorCheckResult === eSelfCheckResult::Passed);
        $internalError = [];

        if (!$executeAble) {
            $internalError = $this->_checkForInternalErrors();
            $executeAble = is_null($internalError);
        }

        if ($executeAble) {
            $this->_selfErrorCheckResult = eSelfCheckResult::Passed;
        }

        if ($executeAble) { // execute macro, if possible
            try {
                $macro = $this->_getMacroByName($macroName);
                if ($macro) {
                    $invalidArguments = $macro->findInvalidArguments($arguments);
                    if (count($invalidArguments) === 0) {
                        $result = $macro
                            ->setLogger($this->_logger)
                            ->setMacroEnvironment($this->_macroEnvironment)
                            ->execute($arguments);
                    } else {
                        $parts = [];
                        foreach ($invalidArguments as $invalidArgument) {
                            $parts[] = "Property '" . $invalidArgument . "' is required but not set";
                        }
                        throw new Exception(implode('; ', $parts));
                    }
                } else {
                    $this->_macroEnvironment->getDebugger()->log(eDebuggerLogType::ERROR, "Macro '" . $macroName . "' not found");
                    throw new Exception("Macro '" . $macroName . "' not found");
                }
                $this->_macroEnvironment->getDebugger()->logEnd(eInstructionType::MACRO, $instructionId, $result);
                return $result;
            } catch (Exception $e) {
                $this->_macroEnvironment->getDebugger()->log(eDebuggerLogType::ERROR, "Error in macro: '" . $macroName . "': " . $e->getMessage());
                throw $e;
            }
        } else {
            $this->_macroEnvironment->getDebugger()->log(eDebuggerLogType::ERROR, "Macro: '" . $macroName . "' is not executable.");
        }

        return $internalError;
    }

    private function _checkForInternalErrors(): ?array
    {
        $errorNumber = -1;
        $errorMessage = "";

        if (!$this->_macroEnvironment->hasValidApplication()) {
            $errorNumber = 1;
            $errorMessage = "No valid application defined";
        }

        $result = ($errorNumber > 0 ? ErrorDTO::create($errorNumber, $errorMessage) : null);
        $this->_selfErrorCheckResult = (is_null($result) ? eSelfCheckResult::Passed : eSelfCheckResult::Failed);

        return $result?->toArray();
    }

    public function setLogger(LoggerInterface $logger): MacroPlayer
    {
        $this->_logger = $logger;
        return $this;
    }

    private function _isOperator(string $operator): bool
    {
        return array_key_exists($operator, self::OPERATORS);
    }
}