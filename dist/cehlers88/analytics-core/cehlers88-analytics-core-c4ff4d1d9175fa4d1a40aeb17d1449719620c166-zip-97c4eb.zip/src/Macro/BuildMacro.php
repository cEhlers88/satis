<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class BuildMacro extends AbstractMacro
{
    private const string PROPERTY_VALUE = 'value';
    private const string PROPERTY_TYPE = 'type';

    public function init(): BuildMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TYPE, 'Command[]|string', 'Specify the function-arguments'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'mixed', ''));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Build an object or array of given type with given value(s).';
    }

    public function getName(): string
    {
        return 'build';
    }

    protected function run(): ?array
    {
        $result = null;
        $type = strtolower($this->getPropertyValue(self::PROPERTY_TYPE));

        switch ($type) {
            case 'array':
                $result = [];
                break;
            case 'object':
            case 'stdclass':
                $result = new \stdClass();
        }

        if (is_null($result)) {
            return $this->_createRunResult(null,
                ErrorDTO::create('Invalid type: ' . $type)
            );
        }

        $values = $this->getNormalizedValue();

        foreach ($values as $key => $val) {
            switch ($type) {
                case 'array':
                    switch (gettype($key)) {
                        case 'integer':
                            $result[] = $val;
                            break;
                        case 'string':
                            $result[$key] = $val;
                    }
                    break;
                case 'object':
                case 'stdclass':
                    $result->{$key} = $val;
                    break;
            }
        }

        return $this->_createRunResult($result);
    }

    private function getNormalizedValue(): array
    {
        $value = $this->getPropertyValue(self::PROPERTY_VALUE);
        $result = [];

        if (is_string($value)) {
            try {
                $tmp = json_decode($value, true);
                $value = $tmp;
            } catch (\Exception $e) {
                $value = [$value];
            }
        }

        switch (gettype($value)) {
            case 'object':
                foreach ($value as $key => $val) {
                    $result[$key] = $val;
                }
                break;
            default:
                $result = $value;
        }

        foreach ($result as $key => &$val) {
            $val = $this->_runCommandDefinition($val);
        }

        return $result;
    }
}