<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\AbstractTrackingBuffer;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Entity\TemporaryTrackingBuffer;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\TrackingBufferView;

/** Assembler for converting Tag entities to views. */
class TrackingBufferAssembler extends AbstractAssembler
{
    /**
     * @param AbstractTrackingBuffer $entity
     */
    public function assembleView(EntityInterface|AbstractCustomObject $entity): TrackingBufferView
    {
        $view = new TrackingBufferView();

        $view->id = $entity->getId();
        $view->data = $entity->getData();
        $view->handlerData = $entity->getHandlerData() ?? [];
        $view->timestamp = $entity->getTimestamp();
        $view->createdAt = $entity->getCreatedAt();
        $view->handledAt = $entity->getHandledAt();
        $view->state = $entity->getState();
        $view->note = $entity->getNote();
        $view->application = new ApplicationAssembler()->assembleView($entity->getApplication());

        return $view;
    }

    public function canHandle(string $className): bool
    {
        return
            $className === TrackingBuffer::class ||
            $className === TemporaryTrackingBuffer::class;
    }
}
