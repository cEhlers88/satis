<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\DTO\BadgeDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ApplicationView;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;


/** Assembler for converting Application entities to views. */
class CustomObjectAssembler extends AbstractAssembler
{
    /**
     * @param CustomEntity $entity
     */
    public function assembleView(EntityInterface|AbstractCustomObject $entity): CustomObjectView
    {
        $view = new CustomObjectView(
            id: $entity->getId(),
            className: $entity->getClassName(),
            name: $entity->getName(),
            attributes: $entity->getAttributes(),
            childObjects: $entity->getChildObjects(),
        );

        return $view;
    }

    public function canHandle(string $className): bool
    {
        return $className === CustomEntity::class;
    }
}