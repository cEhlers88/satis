<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ViewInterface;

/** Base class for assemblers that convert entities to views. */
abstract class AbstractAssembler extends \Cehlers88\AnalyticsCore\Presentation\Assembler\AbstractAssembler implements AssemblerInterface
{
    public function assemble(EntityInterface|AbstractCustomObject $entity): ViewInterface
    {
        return $this->assembleView($entity);
    }

    abstract public function assembleView(EntityInterface|AbstractCustomObject $entity): ViewInterface;

    public function getUseFor(): string
    {
        return 'view';
    }
}