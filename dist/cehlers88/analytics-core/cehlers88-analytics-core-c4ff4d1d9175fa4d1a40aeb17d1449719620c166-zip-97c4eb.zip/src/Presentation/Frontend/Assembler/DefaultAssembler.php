<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\DefaultView;

class DefaultAssembler extends AbstractAssembler
{
    public function assembleView(EntityInterface|AbstractCustomObject $entity): DefaultView
    {
        return new DefaultView();
    }

    public function canHandle(string $className): bool
    {
        return false;
    }
}