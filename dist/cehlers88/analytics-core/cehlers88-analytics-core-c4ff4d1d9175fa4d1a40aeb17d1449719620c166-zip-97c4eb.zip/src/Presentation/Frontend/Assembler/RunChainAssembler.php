<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Entity\RunChain;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\RunChainView;

/** Assembler for converting RunChain entities to views. */
class RunChainAssembler extends AbstractAssembler
{
    /**
     * @param RunChain $entity
     */
    public function assembleView(EntityInterface|AbstractCustomObject $entity): RunChainView
    {
        $status = $entity->getStatus() ?? [];

        $view = (new RunChainView())->loadByRunChain($entity);

        $view->status = $status;
        $view->stateString = implode(',', array_map(fn($state) => $state->name, $status));

        return $view;
    }

    public function canHandle(string $className): bool
    {
        return $className === RunChain::class;
    }
}
