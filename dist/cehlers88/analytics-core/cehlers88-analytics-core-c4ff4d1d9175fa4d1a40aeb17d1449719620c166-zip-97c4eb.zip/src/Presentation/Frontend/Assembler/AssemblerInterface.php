<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ViewInterface;

interface AssemblerInterface extends \Cehlers88\AnalyticsCore\Presentation\Assembler\AssemblerInterface
{
    /**
     * Processes the given entity and returns the corresponding view representation.
     *
     * @param EntityInterface $entity The entity to be processed.
     * @return ViewInterface The view representation of the processed entity.
     */
    public function assembleView(EntityInterface|AbstractCustomObject $entity): ViewInterface;
}