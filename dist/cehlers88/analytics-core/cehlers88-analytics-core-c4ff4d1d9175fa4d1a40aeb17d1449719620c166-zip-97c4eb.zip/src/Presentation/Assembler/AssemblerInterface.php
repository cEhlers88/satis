<?php

namespace Cehlers88\AnalyticsCore\Presentation\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;

interface AssemblerInterface
{
    public function configure(array $config): static;

    public function assemble(EntityInterface|AbstractCustomObject $entity): AssembledInterface;

    public function one(EntityInterface|AbstractCustomObject $entity): AssembledInterface;

    /**
     * Processes a collection of entities and returns the resulting array.
     *
     * @param EntityInterface[] $entities The collection of entities to process.
     * @return AssembledInterface[] The processed view-interfaces.
     */
    public function many(iterable $entities): array;

    /**
     * Determines whether the given entity can be handled by the current implementation.
     *
     * @param string $className The class name of the object to check.
     * @return bool True if the entity can be handled, false otherwise.
     */
    public function canHandle(string $className): bool;

    public function getUseFor(): string;
}