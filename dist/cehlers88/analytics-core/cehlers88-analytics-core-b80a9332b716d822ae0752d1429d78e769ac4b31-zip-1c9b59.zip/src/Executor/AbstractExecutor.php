<?php

namespace Cehlers88\AnalyticsCore\Executor;

use Cehlers88\AnalyticsCore\Support\AbstractPropertyBag;
use Cehlers88\AnalyticsCore\Support\Profiler;

/** Base class for executors that run processes and workers. */
abstract class AbstractExecutor extends AbstractPropertyBag implements ExecutorInterface
{
    public const int ERR_INVALID = 500001;
    public const int ERR_ON_PRE_START = 500100;
    public const int ERR_ON_START = 500101;
    public const int ERR_ON_END = 500102;
    public const int ERR_WHILE_EXECUTE = 500110;

    /** @var bool */
    protected bool $_logHasOpenGroup = false;

    /** @var Profiler|null */
    protected ?Profiler $_profiler = null;

    /** @var ExecutorProvider|null */
    private ?ExecutorProvider $_executorProvider = null;

    /**
     * Execute the full lifecycle: onStart, execute, onEnd.
     *
     */
    final public function run(): void
    {
        $this->_profiler = new Profiler();
        $this->_profiler->start();

        $this->configure();

        try {
            $this->preStart();
        } catch (\Throwable $e) {
            $this->setError($e->getMessage(), self::ERR_ON_PRE_START, []);
        }

        if (!$this->isRunnable()) {
            $this->_closeLogGroup();
            return;
        }

        try {
            $this->onStart();
        } catch (\Throwable $e) {
            $this->setError($e->getMessage(), self::ERR_ON_START, [
                'trace' => $e->getTraceAsString(),
            ]);
        }

        if (!$this->hasError()) {
            try {
                $this->execute();
            } catch (\Throwable $e) {
                $this->setError($e->getMessage(), self::ERR_WHILE_EXECUTE, [
                    'trace' => $e->getTraceAsString(),
                ]);
            }
        }

        try {
            $this->onEnd();
        } catch (\Throwable $e) {
            $this->setError($e->getMessage(), self::ERR_ON_END, [
                'trace' => $e->getTraceAsString(),
            ]);
        }

        $this->_closeLogGroup();
    }

    protected function configure()
    {

    }

    /**
     * Hook called after configuration but before validation and runnability checks.
     */
    public function preStart(): void
    {

    }

    /** Determine whether this executor is allowed to run. */
    public function isRunnable(): bool
    {
        if (!$this->isValid()) {
            $this->setError('Invalid', self::ERR_INVALID);
            return false;
        }

        return !$this->isRunning();
    }

    abstract public function isRunning(): bool;

    private function _closeLogGroup(): void
    {
        if ($this->_logHasOpenGroup) {
            $this->getLogger()->removeTabSpace(3);
            parent::logInfo('</Executor>');
        }
        $this->_logHasOpenGroup = false;
    }

    /**
     * Log an informational message.
     *
     * @param string $message
     * @param bool $onlyInDebugMode
     * @return static
     */
    public function logInfo(string $message, bool $onlyInDebugMode = false): static
    {
        if ($onlyInDebugMode && !$this->getDebugMode()) {
            return $this;
        }

        if (!$this->_logHasOpenGroup) {
            $this->openLogGroup();
        }

        parent::logInfo($message, $onlyInDebugMode);

        return $this;
    }

    /** Open a new log group for this executor. */
    public function openLogGroup(): static
    {
        parent::logInfo(sprintf('<Executor name="%s" started-at="%s">',
            $this->getName(),
            $this->_profiler->getStartedAt()->format('Y-m-d H:i:s')
        ));
        $this->getLogger()->addTabSpace(3);
        $this->_logHasOpenGroup = true;
        return $this;
    }

    /** Get the executor name (defaults to class name). */
    public function getName(): string
    {
        return static::class;
    }

    /** Hook called before execution starts. */
    protected function onStart(): void
    {

    }

    /** Perform the main execution logic. */
    abstract protected function execute(): void;

    /** Hook called after execution completes. */
    protected function onEnd(): void
    {

    }

    public function getRestExecutionTimeMs(): ?float
    {
        return $this->getRestExecutionTime() * 1000;
    }

    public function getRestExecutionTime(): ?float
    {
        $allowedRuntime = $this->getPropertyValue('allowedRuntime'); // in s
        if (is_null($allowedRuntime)) {
            return null;
        }

        return $allowedRuntime - $this->getProfiler()->getDurationSeconds();
    }

    public function getProfiler(): Profiler
    {
        if (is_null($this->_profiler)) {
            $this->_profiler = new Profiler();
        }

        return $this->_profiler;
    }

    public function getExecutorProvider(): ExecutorProvider
    {
        return $this->_executorProvider;
    }

    /** Set the executor provider. */
    public function setExecutorProvider(ExecutorProvider $executorProvider): static
    {
        $this->_executorProvider = $executorProvider;
        return $this;
    }
}