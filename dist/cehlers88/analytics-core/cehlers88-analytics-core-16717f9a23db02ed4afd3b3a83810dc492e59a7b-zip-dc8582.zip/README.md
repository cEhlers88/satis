# AnalyticsCore

[![PHPUnit Tests](https://github.com/cEhlers88/AnalyticsCore/actions/workflows/phpunit.yml/badge.svg)](https://github.com/cEhlers88/AnalyticsCore/actions/workflows/phpunit.yml)

A PHP library providing core building blocks for analytics applications, including entity management, background worker orchestration, process execution, logging, configuration, and a frontend presentation layer.

## Requirements

- PHP 8.3 or higher
- ext-curl

## Installation

```bash
composer require cehlers88/analytics-core
```

## Quick Start

```php
use Cehlers88\AnalyticsCore\Executor\AbstractExecutor;
use Cehlers88\AnalyticsCore\Support\Logging\CompositeLogger;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

// Fan-out logger
$logger = new CompositeLogger($consoleLogger, $fileLogger);

// Implement and run an executor
class MyExecutor extends AbstractExecutor
{
    protected function execute(): void
    {
        $this->logInfo('Doing work...');
    }
}

(new MyExecutor())->setLogger($logger)->run();
```

## Documentation

Detailed documentation for each module lives in the [`doc/`](doc/) folder:

| Module | Description |
|--------|-------------|
| [Entities](doc/entities.md) | All 18 Doctrine ORM domain models |
| [Repositories](doc/repositories.md) | Repository layer with notable query methods |
| [Worker System](doc/worker-system.md) | `AbstractWorker`, `WorkerProvider`, jobs, and `WorkerResultDTO` |
| [Process System](doc/process-system.md) | `ProcessProvider`, runners, and result workers |
| [Executor Framework](doc/executor.md) | Lifecycle-managed `AbstractExecutor` with profiling |
| [Observer Pattern](doc/observer.md) | `ObserverProvider`, all built-in lifecycle messages |
| [Configuration](doc/configuration.md) | Group-based, persisted configuration system |
| [Custom Objects](doc/custom-objects.md) | Dynamic entity classes stored in the database |
| [Logging](doc/logging.md) | `LoggerInterface`, `CompositeLogger`, `VoidLogger` |
| [Support Utilities](doc/support.md) | Error handling, profiling, property bags, converters |
| [ENUMs](doc/enums.md) | `eRunningState`, `eTrackingBufferState`, `eInputType` |
| [Presentation Layer](doc/presentation.md) | Assemblers, views, badges, quick status info |
| [Console Commands](doc/commands.md) | `AbstractCommand` with `choice()` helper |

## Project Structure

```
src/
├── AnalyticsCore.php               # Main bundle plugin class
├── Command/                         # Abstract Symfony Console command base
├── Configuration/                   # Variable-store-backed configuration system
│   └── DTO/                         # ConfigurationItemDTO, ConfigurationGroupDTO
├── CustomObject/                    # Dynamic entity framework
├── DTO/                             # Shared DTOs (Badge, Error, Notification, Validation)
├── ENUM/                            # Enumerations
│   └── State/                       # eRunningState, eTrackingBufferState
├── Entity/                          # Doctrine ORM domain models (18 entities)
├── Executor/                        # Lifecycle-based executor framework
│   └── Observer/Message/            # ExecutorStart/End observer messages
├── Observer/                        # Observer pattern (provider + interface)
│   └── Message/                     # ObserverMessageInterface, ErrorObserverMessage
├── Presentation/                    # Frontend presentation layer
│   └── Frontend/
│       ├── Assembler/               # Entity → view DTO assemblers
│       ├── Service/                 # BadgeProvider, QuickStatusInfoProvider
│       └── View/                    # ApplicationView, WorkerView, ProcessView
├── Process/                         # Process orchestration
│   ├── DTO/                         # StartInfoDTO, ResultWorkerDefinitionDTO
│   ├── Exception/                   # RunnerNotFoundException
│   ├── Observer/Message/            # Process lifecycle observer messages
│   ├── ResultWorker/                # Post-execution result processors
│   └── Runner/                      # AbstractProcessRunner, CurlRequestProcessRunner, etc.
├── Repository/                      # Doctrine ORM repositories (15 repositories)
├── Resources/                       # Symfony resource files (services.yaml, etc.)
├── Support/                         # Cross-cutting utilities
│   ├── Error/                       # AbstractErrorBag, ErrorBagInterface
│   └── Logging/                     # AbstractLogger, CompositeLogger, VoidLogger
└── Worker/                          # Worker execution framework
    ├── DTO/                          # WorkerResultDTO, StoreDTO
    ├── Job/                          # AbstractWorkerJob, CheckIsFirstVisitJob
    └── Observer/Message/             # Worker lifecycle observer messages
```

## License

Proprietary

## Author

Christoph Ehlers <webmaster@c-ehlers.de>

## Version

0.3.0
