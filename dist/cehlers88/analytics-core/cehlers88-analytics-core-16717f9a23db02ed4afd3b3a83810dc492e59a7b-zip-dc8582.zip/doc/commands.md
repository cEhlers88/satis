# Console Commands

The `Cehlers88\AnalyticsCore\Command` namespace provides an abstract base class for Symfony Console commands with built-in helpers.

## `AbstractCommand`

Extends Symfony's `Command` and adds:
- Automatic `SymfonyStyle` initialization (available as `$this->_io`)
- `choice()` helper for selecting from a list
- `cls()` for clearing the console (no-op by default)
- A final `execute()` that delegates to your `handle()` method

## Implementing a Command

```php
use Cehlers88\AnalyticsCore\Command\AbstractCommand;

class RunWorkerCommand extends AbstractCommand
{
    protected static $defaultName = 'analytics:run-worker';

    protected function configure(): void
    {
        $this->setDescription('Run a specific analytics worker');
    }

    protected function handle(): int
    {
        // $this->_io is a fully configured SymfonyStyle instance

        $this->_io->title('Run Worker');

        // Built-in choice helper — returns the 'value' field of the selected option
        $workerId = $this->choice(
            question: 'Which worker would you like to run?',
            choices: [
                ['label' => 'Import Worker',  'value' => '1'],
                ['label' => 'Export Worker',  'value' => '2'],
                ['label' => 'Cleanup Worker', 'value' => '3'],
            ],
            default: '1',
        );

        $this->_io->success("Running worker ID: {$workerId}");

        return self::SUCCESS;
    }
}
```

## `choice()` Signature

```php
protected function choice(
    string $question,
    array  $choices,         // each item must have at least 'label' and the $choiceResultField key
    mixed  $default = null,
    string $choiceResultField = 'value',
): mixed
```

The default matching is case-insensitive against both `label` and the field specified by `$choiceResultField`.

## Registering the Command

```yaml
# services.yaml
RunWorkerCommand:
    tags:
        - { name: console.command }
```
