# Custom Objects

The custom object system allows you to define dynamic entity classes that are persisted in the database and resolved at runtime. It lives in the `Cehlers88\AnalyticsCore\CustomObject` namespace.

## Overview

```
AbstractCustomObject      — base class for domain-specific dynamic entities
CustomObjectInterface     — contract for all custom object classes
CustomObjectProvider      — loads and resolves custom objects from the database
```

## Implementing a Custom Object

Extend `AbstractCustomObject` for each type of dynamic entity:

```php
use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

class ProductObject extends AbstractCustomObject
{
    public function getPrice(): float
    {
        return (float) $this->getAttribute('price', 0.0);
    }

    public function getSku(): string
    {
        return (string) $this->getAttribute('sku', '');
    }
}
```

Register it as a Symfony service:

```yaml
# services.yaml
ProductObject:
    tags:
        - { name: analytics.custom_object }
```

## Persisting a Custom Object

Use the `CustomEntity` and `CustomEntityAttribute` entities directly via their repositories:

```php
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttribute;

$entity = new CustomEntity();
$entity->setClassName(ProductObject::class);
$entity->setName('Widget Pro');

$attribute = new CustomEntityAttribute();
$attribute->setName('price');
$attribute->setValue('49.99');
$entity->addAttribute($attribute);

$customEntityRepository->save($entity, flush: true);
```

## Loading Custom Objects

```php
// Load all persisted instances of a class
$products = $customObjectProvider->getCustomEntitiesByClassName(ProductObject::class);

foreach ($products as $product) {
    echo $product->getName();       // "Widget Pro"
    echo $product->getPrice();      // 49.99
    echo $product->getAttribute('sku', 'N/A');
}

// Load by providing an instance (uses the class name automatically)
$products = $customObjectProvider->getCustomEntitiesByClass(new ProductObject());

// Resolve a single CustomEntity database record to its PHP object
$productObject = $customObjectProvider->resolveCustomEntity($customEntityRecord);
```

## `AbstractCustomObject` API

| Method | Description |
|--------|-------------|
| `getName(): string` | The human-readable name of the instance |
| `setName(string): self` | Set the name |
| `getId(): int` | The database ID (`-1` if not persisted) |
| `setId(int): self` | Set the database ID |
| `getAttribute(string, mixed): mixed` | Get an attribute value with optional default |
| `getAttributes(): array` | Get all attributes as an associative array |
| `setAttribute(string, mixed): self` | Set an attribute value |
| `getClassName(): string` | Returns `get_class($this)` |
