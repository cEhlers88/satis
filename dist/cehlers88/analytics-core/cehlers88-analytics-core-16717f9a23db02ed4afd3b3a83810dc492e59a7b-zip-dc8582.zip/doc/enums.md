# ENUMs

All enums live in the `Cehlers88\AnalyticsCore\ENUM` namespace.

## `eRunningState`

A bitwise integer-backed enum used to represent the state of any `AbstractRunnableEntity` (workers, processes, run chains, etc.). An entity can be in **multiple states simultaneously** by combining bits.

```php
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

$process->addState(eRunningState::Running);
$process->hasState(eRunningState::Running); // true
$process->removeState(eRunningState::Running);

// List all cases as key/value pairs
$list = eRunningState::toKeyValueArray('name', 'value');
```

| Case | Value | Description |
|------|-------|-------------|
| `New` | 1 | Just created |
| `NeedsValidation` | 4 | Awaiting validation |
| `Idle` | 8 | Idle, not scheduled |
| `WillStart` | 16 | Scheduled to start |
| `Starting` | 32 | Initialising |
| `Running` | 1024 | Currently executing |
| `StartingSubProcess` | 4096 | Launching a sub-process |
| `RunningSubProcess` | 8192 | Sub-process running |
| `Paused` | 32768 | Suspended |
| `Waiting` | 65536 | Waiting for an external event |
| `ProcessingResult` | 262144 | Processing the result payload |
| `ResultProcessed` | 524288 | Result payload handled |
| `Buffering` | 1048576 | Accumulating data |
| `BufferComplete` | 8388608 | Data accumulation finished |
| `Finishing` | 33554432 | Wrap-up phase |
| `Finished` | 134217728 | Completed successfully |
| `Canceled` | 536870912 | Manually aborted |
| `Error` | 1073741824 | Recoverable error |
| `Invalid` | 34359738368 | Validation failed |
| `InvalidSubProcess` | 137438953472 | Sub-process validation failed |
| `ErrorInSubProcess` | 1099511627776 | Sub-process error |
| `Dangerous` | 2199023255552 | Flagged as dangerous |
| `Suspicious` | 8796093022208 | Flagged as suspicious |
| `NoWork` | 35184372088832 | No working objects found |
| `Timeout` | 140737488355328 | Execution timed out |
| `TimeoutInSubProcess` | 281474976710656 | Sub-process timed out |
| `FatalError` | 1125899906842624 | Non-recoverable error |
| `Maintenance` | 36028797018963968 | Excluded from automatic execution |
| `Unknown` | 1152921504606846976 | Unclassified state |

## `eTrackingBufferState`

Sequential integer enum for tracking the state of `TrackingBuffer` records:

```php
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;

$buffer->setState(eTrackingBufferState::IN_PROGRESS);
```

| Case | Value | Description |
|------|-------|-------------|
| `NEW` | 0 | Newly captured, unprocessed |
| `IN_PROGRESS` | 1 | Currently being processed |
| `PROCESSED_NOT_FINISHED` | 2 | Partially handled |
| `PROCESSED_FINISHED` | 4 | Fully handled |
| `CHILD_PROCESS_STARTED` | 512 | A sub-process was launched |
| `CHILD_PROCESSES_FINISHED` | 1024 | Sub-process completed |
| `CHILD_PROCESS_WAITING` | 2048 | Waiting on sub-process |
| `CHILD_PROCESS_FAILED` | 4096 | Sub-process failed |
| `ERROR` | 8192 | Processing error |

## `eInputType`

String-backed enum for form field types, used primarily in configuration items (see [`configuration.md`](configuration.md)):

```php
use Cehlers88\AnalyticsCore\ENUM\eInputType;

$type = eInputType::fromString('SELECT');
echo $type->value; // "SELECT"
```

| Case | Value |
|------|-------|
| `TEXT_SINGLE_LINE` | `"TEXT_SINGLE_LINE"` |
| `TEXT_MULTI_LINE` | `"TEXT_MULTI_LINE"` |
| `NUMBER` | `"NUMBER"` |
| `DATE` | `"DATE"` |
| `TIME` | `"TIME"` |
| `DATE_TIME` | `"DATE_TIME"` |
| `SELECT` | `"SELECT"` |
| `CHECKBOX` | `"CHECKBOX"` |
| `RADIO` | `"RADIO"` |
| `FILE` | `"FILE"` |
| `BOOLEAN` | `"BOOLEAN"` |
| `PASSWORD` | `"PASSWORD"` |
| `EMAIL` | `"EMAIL"` |
| `URL` | `"URL"` |
| `COLOR` | `"COLOR"` |
| `RANGE` | `"RANGE"` |
| `REPEAT` | `"REPEAT"` |
| `UNIQUE_ID` | `"UNIQUE_ID"` |
