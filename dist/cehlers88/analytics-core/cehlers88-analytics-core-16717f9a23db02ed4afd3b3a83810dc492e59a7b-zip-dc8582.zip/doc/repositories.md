# Repositories

All repositories live in the `Cehlers88\AnalyticsCore\Repository` namespace and extend `AbstractRepository`, which itself extends Doctrine's `ServiceEntityRepository`.

## AbstractRepository

`AbstractRepository` adds a blacklist-based query helper that allows you to exclude specific IDs or states from any query.

## Available Repositories

| Repository | Entity |
|------------|--------|
| `ApplicationRepository` | `Application` |
| `WorkerRepository` | `Worker` |
| `RunChainRepository` | `RunChain` |
| `ProcessRepository` | `Process` |
| `TrackingBufferRepository` | `TrackingBuffer` |
| `ClientRepository` | `Client` |
| `ClientDetailsRepository` | `ClientDetails` |
| `ClientPermissionRepository` | `ClientPermission` |
| `CustomEntityRepository` | `CustomEntity` |
| `CustomEntityAttributeRepository` | `CustomEntityAttribute` |
| `WorkerJournalRepository` | `WorkerJournal` |
| `StatisticsRepository` | `Statistics` |
| `TagRepository` | `Tag` |
| `UserRepository` | `User` |

## Notable Methods

### `WorkerRepository`

```php
// Fetch workers filtered by application IDs
$workers = $workerRepository->findBy_applicationIds([1, 2, 3]);

// Fetch workers of a given priority level, optionally scoped to a RunChain
$workers = $workerRepository->findBy_priority(1, $runChain);

// Fetch workers that are ready to run (respects RunChain ordering and blacklists)
$workers = $workerRepository->fetchWaitingWorkers($runChain, $alreadyExecuted);
```

### `ProcessRepository`

```php
// Find processes that match any of the given states, while excluding others
$processes = $processRepository->findByStates(
    [eRunningState::WillStart, eRunningState::Buffering], // include
    'or',
    [eRunningState::Running, eRunningState::Maintenance]  // exclude
);

// Remove old processes by state
$processRepository->removeByStateAndOlderThan(eRunningState::Finished, '2024-01-01 00:00:00');
```

### `WorkerJournalRepository`

```php
// Append a WorkerResultDTO to the journal for a given worker
$workerJournalRepository->addWorkerResult($workerEntity, $workerResultDTO);
```

### `ClientRepository`

```php
// Look up a client by IP address
$client = $clientRepository->findByIp('192.168.1.1');
```
