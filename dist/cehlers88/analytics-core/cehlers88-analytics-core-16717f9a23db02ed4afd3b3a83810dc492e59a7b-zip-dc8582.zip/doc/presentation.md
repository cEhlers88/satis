# Presentation Layer

The presentation layer converts domain entities into lightweight frontend DTOs. It lives in the `Cehlers88\AnalyticsCore\Presentation` namespace.

## Overview

```
Assembler/                   — entity → view DTO conversion
  AbstractAssembler
  AssemblerInterface
  ApplicationAssembler        → ApplicationView
  WorkerAssembler             → WorkerView
  ProcessAssembler            → ProcessView

View/                        — frontend view DTOs
  ApplicationView
  WorkerView
  ProcessView
  ViewInterface

Service/
  BadgeProvider              — converts running states to BadgeDTO arrays
  QuickStatusInfoProvider    — generates progress/status info for a Process

QuickStatusInfoDTO           — percentage, message, badges, flags
```

## Assemblers

Assemblers convert single entities or collections to view DTOs:

```php
use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\ApplicationAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\WorkerAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\ProcessAssembler;

// Single entity
$appView     = (new ApplicationAssembler())->one($applicationEntity);
$workerView  = (new WorkerAssembler())->one($workerEntity);
$processView = (new ProcessAssembler())->one($processEntity);

// Collection
$appViews = (new ApplicationAssembler())->many([$app1, $app2]);
```

## BadgeProvider

Converts an array of `eRunningState` cases to styled `BadgeDTO` objects for display:

```php
use Cehlers88\AnalyticsCore\Presentation\Frontend\Service\BadgeProvider;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

$badges = (new BadgeProvider())->getBadgesByRunningStates([
    eRunningState::Running,
    eRunningState::Error,
]);

foreach ($badges as $badge) {
    echo $badge->label;    // e.g. "Running"
    echo $badge->color;    // e.g. "#999999"
    echo $badge->cssClass; // e.g. "badge-error"
}
```

## QuickStatusInfoProvider

Generates a progress percentage and status message for a `Process` entity:

```php
use Cehlers88\AnalyticsCore\Presentation\Frontend\Service\QuickStatusInfoProvider;

$info = (new QuickStatusInfoProvider())->generate($processEntity);

echo $info->percentage; // 0–100 (float|null)
echo $info->message;    // status text
$info->hasError;        // bool
$info->hasWarning;      // bool
$info->badges;          // BadgeDTO[]
$info->icon;            // string|null
```

## BadgeDTO

Factory methods for common badge styles:

```php
use Cehlers88\AnalyticsCore\DTO\BadgeDTO;

$badge = BadgeDTO::createSuccess('Active');  // green (#008000), css: badge-success
$badge = BadgeDTO::createWarning('Pending'); // orange (#ff8000), css: badge-warning
$badge = BadgeDTO::createError('Failed');   // red (#ff0000), css: badge-error

// Fully custom
$badge = BadgeDTO::create('Custom Label', '#ff6600', 'my-css-class');
```

| Property | Type | Description |
|----------|------|-------------|
| `name` | string | Lowercased, underscore-separated version of the label |
| `label` | string | Display text |
| `color` | string | Hex color string |
| `cssClass` | string | Optional CSS class |

## QuickStatusInfoDTO

| Property | Type | Description |
|----------|------|-------------|
| `badges` | `BadgeDTO[]` | Status badges |
| `message` | `string\|null` | Status text |
| `icon` | `string\|null` | Icon identifier |
| `hasError` | bool | Whether the entity is in an error state |
| `hasWarning` | bool | Whether the entity has a warning |
| `percentage` | `float\|null` | 0–100 progress percentage |
