# Entities

All entities live in the `Cehlers88\AnalyticsCore\Entity` namespace and are managed by Doctrine ORM.

## Class Hierarchy

```
AbstractEntity
├── AbstractRunnableEntity
│   ├── Application
│   ├── Worker
│   ├── RunChain
│   ├── Process
│   └── TrackingBuffer
├── AbstractEndpointEntity
├── Client
├── ClientDetails
├── ClientPermission
├── CustomEntity
├── CustomEntityAttribute
├── WorkerJournal
├── WorkerJobOptions
├── Tag
├── Statistics
└── User
```

## Base Classes

### `AbstractEntity`

Base for all entities. Provides:
- `id` (int, auto-increment)
- `createdAt` / `updatedAt` (`\DateTime`)
- Tag collections

### `AbstractRunnableEntity`

Extends `AbstractEntity` with:
- Bitwise **state** field (`int`) — combine/test states using `addState()`, `removeState()`, `hasState()`
- `startedAt` / `finishedAt` (`\DateTime|null`)
- `getStateValue()` / `setStateValue()`

### `AbstractEndpointEntity`

Extends `AbstractEntity` for API endpoint models with:
- `name`, `allowedMethods`, `options`

## Domain Entities

| Entity | Extends | Description |
|--------|---------|-------------|
| `Application` | `AbstractRunnableEntity` | Core application. Holds workers, tracking buffers, actions, categories, and service endpoints |
| `Worker` | `AbstractRunnableEntity` | Background worker with job options, counters, run intervals, priority, and state |
| `RunChain` | `AbstractRunnableEntity` | Ordered chain of workers with statistics, color, max runtime, and selectable options |
| `Process` | `AbstractRunnableEntity` | Runnable process with runner class, start arguments, and result worker definition |
| `TrackingBuffer` | `AbstractRunnableEntity` | Event/data capture buffer with JSON payload, state, and handler data |
| `Client` | `AbstractEntity` | Visitor record with IP, first-visit timestamp, permissions, and client details |
| `ClientDetails` | `AbstractEntity` | Additional metadata and tags for a `Client` |
| `ClientPermission` | `AbstractEntity` | Permission rules (many-to-many with clients) |
| `CustomEntity` | `AbstractEntity` | Dynamic entity mapped to a `CustomObjectInterface` implementation |
| `CustomEntityAttribute` | `AbstractEntity` | Typed name/value attribute of a `CustomEntity` |
| `WorkerJournal` | `AbstractEntity` | Execution history for a worker, storing serialized `WorkerResultDTO` |
| `WorkerJobOptions` | `AbstractEntity` | Job-specific option storage for a worker |
| `Tag` | `AbstractEntity` | Categorization tag with many-to-many relation to analytics headers |
| `Statistics` | `AbstractEntity` | Metrics container with an array of detail entries |
| `User` | `AbstractEntity` | Symfony-compatible user with email, roles, hashed password, and settings |

## Working with States

The `AbstractRunnableEntity` uses bitwise integers for state — see [`enums.md`](enums.md) for all `eRunningState` values.

```php
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

$process->addState(eRunningState::Running);
$process->hasState(eRunningState::Running); // true
$process->removeState(eRunningState::Running);
$process->hasState(eRunningState::Running); // false

// An entity can be in multiple states simultaneously
$process->addState(eRunningState::Buffering);
$process->addState(eRunningState::WillStart);
$process->hasState(eRunningState::Buffering); // true
$process->hasState(eRunningState::WillStart);  // true
```

## Working with Process

```php
use Cehlers88\AnalyticsCore\Entity\Process;

$process = new Process();
$process->setRunnerClass(MyRunner::class);

// Set runner arguments (passed to the runner's handle() method)
$process->getStartInfo()->runner_arguments['host'] = 'https://api.example.com';

// Inspect result
$details = $process->getDetails();
$result  = $details['result'] ?? null;
```
