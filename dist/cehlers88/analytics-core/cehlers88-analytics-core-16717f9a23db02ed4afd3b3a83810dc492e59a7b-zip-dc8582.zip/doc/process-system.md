# Process System

The process system orchestrates long-running, stateful operations through pluggable runners and optional post-processing result workers. It lives in the `Cehlers88\AnalyticsCore\Process` namespace.

## Overview

```
ProcessProvider                  — orchestrates process lifecycle
AbstractProcessRunner            — base for pluggable execution strategies
  ├── CurlRequestProcessRunner   — sends HTTP/HTTPS requests via cURL
  └── CommandsPlayerProcessRunner — executes a chain of commands (stub)
AbstractProcessResultWorker      — handles the result after a process finishes
  ├── VoidResultWorker           — no-op; marks the process as result-processed
  └── ModifyTrackingBufferResultWorker — updates a TrackingBuffer based on the result
```

## ProcessProvider

The central service for process lifecycle management:

```php
// Run all processes currently in an executable state
$processProvider->runExecutableProcesses();

// Run a single process entity
$process = $processProvider->runProcess($processEntity);

// Find all currently executable processes
/** @var Process[] $processes */
$processes = $processProvider->findExecutableProcesses(ignoreMaintenanceState: true);

// Mark a process as finished with an optional result payload
$processProvider->setProcessFinished($processId, $result);

// Mark a process as started with optional start info
$processProvider->setProcessStarted($processId, $startInfo);

// Cancel a process
$processProvider->setProcessAbort($processId);

// Update a runner argument on a process
$processProvider->setProcessRunnerArgument($processId, 'host', 'https://api.example.com');

// Clean up old finished/canceled/unfinished processes (uses configured age thresholds)
$processProvider->cleanUp();
```

### Executable States

A process is considered executable when it is in one of these states **and** is **not** in any blocking state:

| Executable | Blocking |
|-----------|---------|
| `WillStart` | `Running` |
| `Buffering` | `FatalError` |
| `BufferComplete` | `Maintenance` (configurable) |
| `Finishing` | |

## Process Runners

Implement `AbstractProcessRunner` to define how a process executes. The runner receives the process entity and must implement `handle()`.

### `CurlRequestProcessRunner`

Sends an HTTP/HTTPS request via cURL. The process transitions through `Buffering → BufferComplete → WillStart → Running → Finishing`.

**Required runner argument:**

| Argument | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `host` | string | ✅ | — | Full URL to request |
| `port` | int | | 80/443 | Port (auto-detected from scheme) |
| `method` | string | | `GET` | HTTP method |
| `headers` | array | | `[]` | HTTP headers |
| `body` | mixed | | `''` | Request body |
| `timeout` | int | | `10` | cURL timeout in seconds |

```php
use Cehlers88\AnalyticsCore\Process\Runner\CurlRequestProcessRunner;

class MyApiRunner extends CurlRequestProcessRunner
{
    // Override to add auth headers, etc.
    protected function enrichHeaders(array $headers): array
    {
        $headers[] = 'Authorization: Bearer ' . $this->getProcess()->getRunnerAttributeValue('token');
        return $headers;
    }

    // Override to transform the request body
    protected function enrichBody(mixed $body): mixed
    {
        return json_encode($body);
    }

    // Override to handle the HTTP response
    protected function handleResponse(string $response, int $statusCode = 200): void
    {
        // Default implementation stores $response and $statusCode in process details
        parent::handleResponse($response, $statusCode);
    }
}
```

Set runner arguments on the process before execution:

```php
$processProvider->setProcessRunnerArgument($processId, 'host', 'https://api.example.com');
$processProvider->setProcessRunnerArgument($processId, 'method', 'POST');
$processProvider->setProcessRunnerArgument($processId, 'token', 'my-api-token');
```

### `CommandsPlayerProcessRunner`

Stub runner for executing macro command chains. Implement `handle()`:

```php
use Cehlers88\AnalyticsCore\Process\Runner\CommandsPlayerProcessRunner;

class MyCommandRunner extends CommandsPlayerProcessRunner
{
    public function handle(): void
    {
        // Execute commands here
    }
}
```

### Custom Runners

```php
use Cehlers88\AnalyticsCore\Process\Runner\AbstractProcessRunner;

class MyCustomRunner extends AbstractProcessRunner
{
    public function getRequiredArguments(): array
    {
        return ['api_key', 'endpoint']; // validated on NeedsValidation state
    }

    public function handle(): void
    {
        $apiKey   = $this->getProcess()->getRunnerAttributeValue('api_key');
        $endpoint = $this->getProcess()->getRunnerAttributeValue('endpoint');

        // ... do work ...

        $this->process->addState(eRunningState::Finishing);
    }
}
```

## Process Result Workers

After a process enters the `Finishing` state, its optional result worker is invoked to process the result payload:

```php
use Cehlers88\AnalyticsCore\Process\ResultWorker\AbstractProcessResultWorker;

class MyResultWorker extends AbstractProcessResultWorker
{
    protected function handleResult(mixed $result): void
    {
        // $result = $process->getDetails()['result']
        // $this->process is available
    }
}
```

Associate a result worker with a process via `ResultWorkerDefinitionDTO`:

```php
use Cehlers88\AnalyticsCore\Process\DTO\ResultWorkerDefinitionDTO;

$definition = new ResultWorkerDefinitionDTO();
$definition->worker = MyResultWorker::class;

$process->setResultWorkerDefinition($definition);
```

## Observer Messages

The process system dispatches these messages via `ObserverProvider` (see [`observer.md`](observer.md)):

| Message | Trigger |
|---------|---------|
| `ProcessStartHandlingObserverMessage` | Before a process is handled |
| `ProcessFinishedHandlingObserverMessage` | After a process is handled |
| `ProcessStartedObserverMessage` | Process transitions to Running |
| `ProcessFinishedObserverMessage` | Process transitions to Finished |
| `ProcessErrorObserverMessage` | Process encounters an error |
