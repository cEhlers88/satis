# Executor Framework

The executor framework provides a structured, lifecycle-managed way to run arbitrary logic. It lives in the `Cehlers88\AnalyticsCore\Executor` namespace.

## Overview

```
AbstractExecutor     — base class with onStart / execute / onEnd lifecycle
ExecutorInterface    — contract for all executors
ExecutorProvider     — DI-managed registry for looking up executors by name
```

## Implementing an Executor

Extend `AbstractExecutor` and implement the `execute()` method. The two lifecycle hooks `onStart()` and `onEnd()` are optional:

```php
use Cehlers88\AnalyticsCore\Executor\AbstractExecutor;

class MyExecutor extends AbstractExecutor
{
    // Called before execute(). Throw an exception to abort.
    protected function onStart(): void
    {
        $this->logInfo('Preparing...');
    }

    // Core logic — must be implemented
    protected function execute(): void
    {
        $this->logInfo('Working...');

        if ($someCondition) {
            $this->setError('Something went wrong', self::ERR_WHILE_EXECUTE);
        }
    }

    // Called after execute() — always runs, even on error
    protected function onEnd(): void
    {
        $this->logInfo('Cleaning up...');
    }

    // Optional: prevent execution under certain conditions
    public function isRunnable(): bool
    {
        return true;
    }
}
```

## Running an Executor

```php
$executor = new MyExecutor();
$executor->setLogger($logger); // optional
$executor->run();

if ($executor->hasError()) {
    echo $executor->getErrorsAsString();
}

// Check how much execution time remains (useful inside execute())
$remainingMs = $executor->getRestExecutionTimeMs();
```

## ExecutorProvider

Register executors as Symfony services and retrieve them by class name:

```php
// In services.yaml, tag your executor:
// MyExecutor:
//     tags:
//         - { name: analytics.executor }

$executor = $executorProvider->getExecutor(MyExecutor::class);

if ($executor !== null) {
    $executor->run();
}
```

## Error Constants

`AbstractExecutor` defines these error codes:

| Constant | Value | Description |
|----------|-------|-------------|
| `ERR_INVALID` | 500001 | Validation failed (`isRunnable()` returned false) |
| `ERR_ON_START` | 500101 | Exception thrown in `onStart()` |
| `ERR_ON_END` | 500102 | Exception thrown in `onEnd()` |
| `ERR_WHILE_EXECUTE` | 500110 | Exception thrown in `execute()` |

## Observer Messages

The executor dispatches these messages via `ObserverProvider` (see [`observer.md`](observer.md)):

| Message | Trigger |
|---------|---------|
| `ExecutorStartObserverMessage` | Executor begins `run()` |
| `ExecutorEndObserverMessage` | Executor finishes `run()` |

## Profiling

`AbstractExecutor` automatically records runtime using `Profiler`. After `run()` completes you can access timing data via the logger output or by checking the executor's internal profiler state.

For standalone profiling of arbitrary code, see [`support.md`](support.md).
