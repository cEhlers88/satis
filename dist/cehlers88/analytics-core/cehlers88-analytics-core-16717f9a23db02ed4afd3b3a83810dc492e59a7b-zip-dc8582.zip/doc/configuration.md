# Configuration System

The configuration system provides group-based, persisted settings backed by the variable store. It lives in the `Cehlers88\AnalyticsCore\Configuration` namespace.

## Overview

```
AbstractConfigurationGroup   — define groups of settings with typed items
ProcessConfigurationGroup    — built-in group for process-related settings
ConfigurationProvider        — load, read, and persist configuration values
GroupInterface               — contract for all configuration groups
```

## Defining a Configuration Group

Extend `AbstractConfigurationGroup` and register it as a Symfony service:

```php
use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;

class MyConfigGroup extends AbstractConfigurationGroup
{
    public function getKey(): string
    {
        return 'my_group';
    }

    public function getGroupTitle(): string
    {
        return 'My Settings';
    }

    public function getItems(): array
    {
        return [
            ConfigurationItemDTO::create('api_url', 'API URL', eInputType::URL),
            ConfigurationItemDTO::create('retry_count', 'Retry Count', eInputType::NUMBER)
                ->setDefaultValue(3),
        ];
    }
}
```

`services.yaml`:
```yaml
MyConfigGroup:
    tags:
        - { name: analytics.configuration }
```

## Reading Configuration Values

```php
// Read a global (server-level) value
$apiUrl = $configurationProvider->getValue('my_group', 'api_url');

// Read a per-application value
$apiUrl = $configurationProvider->getValue('my_group', 'api_url', applicationId: 42);

// With a fallback default
$retries = $configurationProvider->getValue('my_group', 'retry_count', defaultValue: 3);

// Get all configuration groups (including persisted values)
$all = $configurationProvider->getConfigurations();
```

## Persisting Configuration from a Form

```php
// Parse and buffer form data (POST array)
$configurationProvider->loadRequestData($request->request->all());

// Write buffered values to the variable store
$updated = $configurationProvider->persistConfiguration();
```

## ConfigurationItemDTO

| Property | Type | Description |
|----------|------|-------------|
| `key` | string | Unique key within the group |
| `label` | string | Human-readable label |
| `inputType` | `eInputType` | UI input type (see [`enums.md`](enums.md)) |
| `defaultValue` | mixed | Default value if none is stored |
| `needApplication` | bool | Whether the setting is per-application |

## View Contexts

Configuration groups can declare a view context to control where they appear in the UI:

```php
// Default: 'settings'
public function getViewContext(): string
{
    return self::VIEW_CONTEXT_SETTINGS; // 'settings'
}
```
