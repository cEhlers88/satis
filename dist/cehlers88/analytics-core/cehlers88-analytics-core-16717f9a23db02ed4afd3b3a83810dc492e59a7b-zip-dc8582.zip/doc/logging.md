# Logging

The logging system defines a common `LoggerInterface` and ships with several implementations. It lives in the `Cehlers88\AnalyticsCore\Support\Logging` namespace.

## Interface

```php
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;
```

| Method | Description |
|--------|-------------|
| `info(string $message)` | Log an informational message |
| `warning(string $message)` | Log a warning |
| `error(string $message)` | Log an error |
| `log(eDebuggerLogType, string, array)` | Log with an explicit type |
| `progressStart(int $max)` | Start a progress indicator |
| `progressAdvance(int $step)` | Advance the progress indicator |
| `addTabSpace(int $count)` | Increase indentation level |
| `removeTabSpace(int $count)` | Decrease indentation level |
| `addDateTimeToLogMessage(bool)` | Toggle datetime prefix |
| `addTypeToLogMessage(bool)` | Toggle log type prefix |
| `setIgnoreInfoLog(bool)` | Suppress info messages |

## Provided Implementations

### `VoidLogger`

A no-op logger. All calls are silently discarded. Useful as a null object default.

```php
use Cehlers88\AnalyticsCore\Support\Logging\VoidLogger;

$logger = new VoidLogger();
$logger->info('This goes nowhere');
```

### `AbstractLogger`

Base class for concrete loggers. Manages tab spacing, datetime/type prefixes, and optional `willCreateLogHandler` callbacks. Extend this to create a custom logger.

```php
use Cehlers88\AnalyticsCore\Support\Logging\AbstractLogger;

class MyLogger extends AbstractLogger
{
    public function info(string $message): void
    {
        echo str_repeat(' ', $this->tabSpaces) . '[INFO] ' . $message . PHP_EOL;
    }

    public function warning(string $message): void
    {
        echo str_repeat(' ', $this->tabSpaces) . '[WARN] ' . $message . PHP_EOL;
    }

    public function error(string $message): void
    {
        echo str_repeat(' ', $this->tabSpaces) . '[ERROR] ' . $message . PHP_EOL;
    }

    public function progressStart(int $max): void { }
    public function progressAdvance(int $step = 1): void { }
}
```

### `CompositeLogger`

Fan-out logger that broadcasts every call to multiple underlying loggers simultaneously:

```php
use Cehlers88\AnalyticsCore\Support\Logging\CompositeLogger;

$logger = new CompositeLogger($consoleLogger, $fileLogger, $dbLogger);

$logger->info('Sent to all three loggers');
$logger->warning('A warning');
$logger->error('An error');

// Progress bar (delegated to all children)
$logger->progressStart(100);
$logger->progressAdvance(10);

// Indented, structured logging
$logger->addTabSpace(3);
$logger->info('  → step result');
$logger->removeTabSpace(3);

// Retrieve a specific child logger by class
$file = $logger->getLoggerByClass(MyFileLogger::class);
```

## Using a Logger in Your Classes

Classes that extend `AbstractErrorBag` (workers, executors, process runners, etc.) already have a logger slot:

```php
$worker->setLogger($logger);
$executor->setLogger($logger);
$processProvider->setLogger($logger);
```

Logging methods available inside such classes:

```php
$this->logInfo('A message');                    // always
$this->logInfo('Debug-only message', true);     // only in debug mode
$this->logWarning('A warning');
$this->logError('An error');
$this->enableDebugMode(true);
```
