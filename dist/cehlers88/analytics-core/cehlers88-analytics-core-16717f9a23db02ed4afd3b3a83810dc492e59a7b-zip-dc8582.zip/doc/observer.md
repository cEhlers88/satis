# Observer Pattern

The observer system provides a lightweight publish/subscribe mechanism for reacting to lifecycle events. It lives in the `Cehlers88\AnalyticsCore\Observer` namespace.

## Overview

```
ObserverProvider         — dispatches messages to all registered observers
ObserverInterface        — implemented by each observer
ObserverMessageInterface — marker interface for all messages
```

## Dispatching a Message

```php
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\Worker\Observer\Message\WorkerStartedObserverMessage;

$observerProvider->dispatch(new WorkerStartedObserverMessage($workerEntity));
```

## Implementing an Observer

```php
use Cehlers88\AnalyticsCore\Observer\ObserverInterface;
use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;
use Cehlers88\AnalyticsCore\Worker\Observer\Message\WorkerFinishedObserverMessage;

class MyObserver implements ObserverInterface
{
    public function canHandle(ObserverMessageInterface $message): bool
    {
        return $message instanceof WorkerFinishedObserverMessage;
    }

    public function handle(ObserverMessageInterface $message): void
    {
        /** @var WorkerFinishedObserverMessage $message */
        $worker = $message->getWorker();
        // React to the event...
    }
}
```

Register in `services.yaml`:
```yaml
MyObserver:
    tags:
        - { name: analytics.observer }
```

## Built-in Observer Messages

### Worker Messages (`Cehlers88\AnalyticsCore\Worker\Observer\Message`)

| Message | Trigger |
|---------|---------|
| `WorkerStartedObserverMessage` | Worker begins execution |
| `WorkerFinishedObserverMessage` | Worker completes execution |
| `WorkerErrorObserverMessage` | Worker encounters an error |

### Process Messages (`Cehlers88\AnalyticsCore\Process\Observer\Message`)

| Message | Trigger |
|---------|---------|
| `ProcessStartedObserverMessage` | Process transitions to Running |
| `ProcessFinishedObserverMessage` | Process transitions to Finished |
| `ProcessStartHandlingObserverMessage` | Before a process is handled by `ProcessProvider` |
| `ProcessFinishedHandlingObserverMessage` | After a process is handled by `ProcessProvider` |
| `ProcessErrorObserverMessage` | Process encounters an error |

### Executor Messages (`Cehlers88\AnalyticsCore\Executor\Observer\Message`)

| Message | Trigger |
|---------|---------|
| `ExecutorStartObserverMessage` | Executor begins `run()` |
| `ExecutorEndObserverMessage` | Executor finishes `run()` |

### Generic Messages (`Cehlers88\AnalyticsCore\Observer\Message`)

| Message | Trigger |
|---------|---------|
| `ErrorObserverMessage` | Generic/cross-cutting error event |
