# Worker System

The worker system orchestrates background processing against collections of working objects (typically `TrackingBuffer` records). It lives in the `Cehlers88\AnalyticsCore\Worker` namespace.

## Overview

```
AbstractWorker          — base worker; implement getWorkingObjects() and register jobs
  └── WorkerInterface
AbstractWorkerJob       — processes individual working objects
  └── JobInterface
WorkerProvider          — DI-managed registry; executes workers by ID or priority
WorkerResultDTO         — captures the outcome of a single worker execution
```

## Implementing a Worker

Extend `AbstractWorker`, implement `getWorkingObjects()`, and register the service with the `analytics.worker` tag:

```php
use Cehlers88\AnalyticsCore\Worker\AbstractWorker;

class MyWorker extends AbstractWorker
{
    public function getWorkingObjects(): array
    {
        // Return the set of objects to process (e.g. TrackingBuffer records)
        return $this->trackingBufferRepository->findUnprocessed();
    }

    // Optional: override to filter which objects are processed
    public function handleWorkingObjectStart(mixed $workingObject): bool
    {
        return true;
    }

    // Optional: react after each object is handled
    public function handleWorkingObjectEnd(mixed $workingObject, array $jobResults): void
    {
    }
}
```

`services.yaml`:
```yaml
MyWorker:
    tags:
        - { name: analytics.worker }
```

## Implementing a Worker Job

Worker jobs perform the actual logic on each working object:

```php
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Analytics\ENUM\eWorkerJobType;

class MyJob extends AbstractWorkerJob
{
    public eWorkerJobType $type = eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION;

    public function workOnObject(object $object): static
    {
        // Act on $object (typically a TrackingBuffer)
        return $this;
    }

    protected function willHandle(object $workingObject): bool
    {
        // Optional: return false to skip this object
        return true;
    }
}
```

Jobs are attached to workers before execution:

```php
$worker->addJob(new MyJob());
```

## WorkerProvider

`WorkerProvider` is the DI service used to look up and execute workers:

```php
// Fetch a worker instance by its database entity ID
$worker = $workerProvider->getWorkerInstanceByEntityId($workerId);

// Fetch a worker instance by its class name
$worker = $workerProvider->getWorkerInstanceByName(MyWorker::class);

// Execute a single worker by entity ID
$workerProvider->executeWorker($workerId, $logger);

// Execute all waiting workers (respects RunChain ordering and priority)
/** @var Worker[] $executed */
$executed = $workerProvider->executeWaitingWorkers();

// Execute all workers at a given priority level
$workerProvider->executeWorkersByPriorityLevel(1, $logger);

// Change the state of a worker entity
$workerProvider->setWorkerState($workerId, eRunningState::Idle);

// Scope execution to a specific RunChain
$workerProvider->setActiveRunChain($runChainEntity);

// List workers whose entity/class mapping is broken
$unrelated = $workerProvider->getUnrelatedWorkers();

// Resolve a worker's configurable property definitions
$properties = $workerProvider->resolveWorkerPropertyDefinition($workerEntity);
```

## WorkerResultDTO

Returned by `AbstractWorker::execute()` and stored in `WorkerJournal`:

| Field | Type | Description |
|-------|------|-------------|
| `error` | `string\|null` | Error message(s) if any |
| `startedAt` | `int` | Unix timestamp of execution start |
| `endedAt` | `int` | Unix timestamp of execution end |
| `runtime` | `float` | Total runtime in seconds |
| `timedOut` | `bool` | Whether the timeout was reached |
| `jobResults` | `array` | Per-job results |
| `workerInfos` | `array` | Benchmark metadata and working object counts |

```php
// Serialize / deserialize
$serialized = (string) $result;                           // JSON
$restored   = WorkerResultDTO::createFromString($serialized);

// Create from an exception
$result = WorkerResultDTO::createFromException($exception);

// Human-readable timestamps
echo $result->getFormatedStartedAt();   // "20.03.2025 | 12:00:00"
echo $result->getFormattedEndedAt();
```

## Timeout Handling

Set the maximum runtime on the `Worker` entity. The worker checks elapsed time between objects and jobs and stops gracefully when the limit is reached:

```php
$workerEntity->setMaxRuntime(60); // seconds; -1 means no limit
```

When a timeout is detected, `reachedTimeout()` returns `true` and `WorkerResultDTO::$timedOut` is set.
