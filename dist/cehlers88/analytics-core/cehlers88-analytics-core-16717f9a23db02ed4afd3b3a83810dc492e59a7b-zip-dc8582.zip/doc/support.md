# Support Utilities

The `Cehlers88\AnalyticsCore\Support` namespace provides cross-cutting utilities used throughout the library.

## Error Handling — `AbstractErrorBag`

`AbstractErrorBag` is the base for all classes that need structured error accumulation (workers, executors, process runners, etc.).

```php
use Cehlers88\AnalyticsCore\Support\Error\AbstractErrorBag;

class MyService extends AbstractErrorBag
{
    public function process(): void
    {
        if ($somethingWrong) {
            $this->setError('Validation failed', 422, ['field' => 'email']);
        }
    }
}

$service = new MyService();
$service->process();

$service->hasError();          // bool
$service->getErrorsAsString(); // "422: Validation failed"
$service->errors;              // ErrorDTO[]
```

### `ErrorDTO`

| Field | Type | Description |
|-------|------|-------------|
| `number` | int | Error code |
| `message` | string | Human-readable error message |
| `data` | mixed | Additional context (e.g. field name) |

```php
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;

$error = ErrorDTO::create(422, 'Validation failed', ['field' => 'email']);
echo $error->toArray()['error']; // "Validation failed"
echo (string) $error;            // "#422: Validation failed"
```

### Debug Mode

```php
$service->enableDebugMode(true);

// These only log in debug mode when the second argument is true
$this->logInfo('Verbose detail', true);
$this->logWarning('Verbose warning', true);
```

## Profiling — `Profiler`

`Profiler` measures runtime and memory usage of any callable or code block:

```php
use Cehlers88\AnalyticsCore\Support\Profiler;

// Profile a callable
$result = Profiler::run(function () {
    // ... expensive operation ...
    return 42;
});

echo $result['profiler']->getReadableDuration(); // e.g. "120ms"
echo $result['result'];                           // 42
echo $result['hasError'] ? 'error' : 'ok';
// $result['exception'] contains the Throwable if hasError is true

// Manual start/stop
$profiler = new Profiler();
$profiler->start();
// ... work ...
$profiler->stop();

echo $profiler->getDurationMilliseconds();  // float — ms
echo $profiler->getDurationSeconds();       // float — seconds
echo $profiler->getUsedMemoryBytes();       // int — memory delta
echo $profiler->getPeakMemoryBytes();       // int — peak memory since script start
echo $profiler->getStartedAt()->format('Y-m-d H:i:s');
```

## Property Management — `AbstractPropertyBag`

`AbstractPropertyBag` provides typed, validated properties for configurable components (workers, jobs, etc.):

```php
use Cehlers88\AnalyticsCore\Support\AbstractPropertyBag;
use Analytics\DTO\PropertyDTO;

class MyComponent extends AbstractPropertyBag
{
    public function __construct()
    {
        // Register a required property with a default of 30
        $this->addProperty(PropertyDTO::create('timeout', 30));
    }
}

$component = new MyComponent();

// Set a value
$component->setPropertyValue('timeout', 60);

// Get a value (returns default if still default)
$timeout = $component->getPropertyValue('timeout'); // 60

// Validate — ensures all required (non-optional) properties have been set
if (!$component->validate()) {
    echo $component->getErrorsAsString();
}

// Load values in bulk (e.g. from database)
$component->loadPropertyValues([
    [PropertyType::INT, 'timeout', 60],
]);
```

## Converter Utilities — `ConverterUtils`

```php
use Cehlers88\AnalyticsCore\Support\ConverterUtils;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

// Combine enum cases into a single bitmask integer
$mask = ConverterUtils::arrayToBitmask([eRunningState::Running, eRunningState::Buffering]);

// Also works with plain integers
$mask = ConverterUtils::arrayToBitmask([1024, 1048576]);

// Flatten an associative array into a comma-separated key:value string
$str = ConverterUtils::associativeArrayToString(['host' => 'localhost', 'port' => 80]);
// Result: "host:localhost,port:80"
```

## Custom Objects — `AbstractCustomObject` / `CustomObjectProvider`

Dynamic entity classes that are stored in the database and resolved at runtime. See [`custom-objects.md`](custom-objects.md).
