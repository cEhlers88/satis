<?php

namespace Cehlers88\AnalyticsCore\DTO;

/**
 * Data transfer object representing a UI badge.
 */
class BadgeDTO extends DTO
{
    /** @var string $name */
    public string $name = '';
    /** @var string $label */
    public string $label = '';
    /** @var string $color */
    public string $color = '#000000';
    /** @var string $cssClass */
    public string $cssClass = '';

    /**
     * Creates a success badge.
     *
     * @param string $label The badge label.
     * @return BadgeDTO
     */
    public static function createSuccess(string $label): BadgeDTO
    {
        return self::create($label, '#008000', 'badge-success');
    }

    /**
     * Creates a badge with the given parameters.
     *
     * @param string $label The badge label.
     * @param string $color The badge color.
     * @param string $cssClass The CSS class.
     * @return BadgeDTO
     */
    public static function create(string $label, string $color, string $cssClass = ''): BadgeDTO
    {
        $dto = new self();
        $dto->label = $label;
        $dto->name = str_replace(' ', '_', strtolower($label));
        $dto->cssClass = $cssClass;
        $dto->color = $color;
        return $dto;
    }

    /**
     * Creates a warning badge.
     *
     * @param string $label The badge label.
     * @return BadgeDTO
     */
    public static function createWarning(string $label): BadgeDTO
    {
        return self::create($label, '#ff8000', 'badge-warning');
    }

    /**
     * Creates an error badge.
     *
     * @param string $label The badge label.
     * @return BadgeDTO
     */
    public static function createError(string $label): BadgeDTO
    {
        return self::create($label, '#ff0000', 'badge-error');
    }
}