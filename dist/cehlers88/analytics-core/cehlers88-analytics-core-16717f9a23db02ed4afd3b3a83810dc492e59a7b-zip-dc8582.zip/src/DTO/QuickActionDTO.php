<?php

namespace Cehlers88\AnalyticsCore\DTO;

class QuickActionDTO extends DTO
{
    public string $name;
    public string $label;
    public string $icon;
    public string $callback;
}