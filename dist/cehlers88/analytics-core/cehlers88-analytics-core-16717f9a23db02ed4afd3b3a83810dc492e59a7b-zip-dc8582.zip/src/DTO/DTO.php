<?php

namespace Cehlers88\AnalyticsCore\DTO;

/**
 * Base class for data transfer objects.
 */
abstract class DTO
{

}