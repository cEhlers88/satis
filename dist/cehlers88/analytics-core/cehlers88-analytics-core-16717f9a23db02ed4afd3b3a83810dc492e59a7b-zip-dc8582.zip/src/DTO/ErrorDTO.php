<?php

namespace Cehlers88\AnalyticsCore\DTO;

/**
 * Data transfer object representing an error.
 */
class ErrorDTO extends DTO
{
    /** @var int $number */
    public int $number = 0;
    /** @var string $message */
    public string $message = "";
    /** @var mixed $data */
    public mixed $data = null;

    /**
     * Creates an ErrorDTO instance.
     *
     * @param int $errNumber The error number.
     * @param string $errMessage The error message.
     * @param mixed $data Additional error data.
     * @return ErrorDTO
     */
    public static function create(int $errNumber, string $errMessage = "", mixed $data = null): ErrorDTO
    {
        $dto = new self();
        $dto->number = $errNumber;
        $dto->message = $errMessage;
        $dto->data = $data;

        return $dto;
    }

    /**
     * Converts the error to an array representation.
     *
     * @return array
     */
    public function toArray(): array
    {
        return [
            // 'hasError' => ($this->number > 0), // Blödsinn ! Checken ob irgendwo verwendet wird
            'number' => $this->number,
            'error' => $this->message,
            'data' => $this->data
        ];
    }

    /**
     * Returns the string representation of the error.
     */
    public function __toString(): string
    {
        return $this->number > 0 ? sprintf("#%d: %s", $this->number, $this->message) : '';
    }
}