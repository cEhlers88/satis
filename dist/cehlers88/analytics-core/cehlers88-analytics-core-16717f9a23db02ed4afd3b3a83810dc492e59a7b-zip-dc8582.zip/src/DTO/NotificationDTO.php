<?php

namespace Cehlers88\AnalyticsCore\DTO;

/**
 * Data transfer object representing a notification.
 */
class NotificationDTO extends DTO
{

}