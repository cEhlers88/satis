<?php

namespace Cehlers88\AnalyticsCore\DTO;

/**
 * Data transfer object representing a validation result.
 */
class ValidationResultDTO extends DTO
{

}