<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 17:16
 */

namespace Cehlers88\AnalyticsCore\ENUM;

enum eDebuggerLogType
{
    case INFO;
    case WARNING;
    case ERROR;
    case DEBUG;
    case CRITICAL;
}