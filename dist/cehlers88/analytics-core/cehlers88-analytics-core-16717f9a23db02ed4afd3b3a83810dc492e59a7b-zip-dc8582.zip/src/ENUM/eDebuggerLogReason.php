<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 28.05.2024
 * Time: 18:59
 */

namespace Cehlers88\AnalyticsCore\ENUM;

enum eDebuggerLogReason: int
{
    case UNKNOWN = 0;
    case START_DEBUG_SESSION = 10;
    case END_DEBUG_SESSION = 20;
    case INSTRUCTION_START = 30;
    case UPDATE_INSTRUCTION_ARGUMENT = 35;
    case INSTRUCTION_END = 40;
    case INFO = 50;
    case UPDATE_VARIABLE = 60;

    case START_VIEW_GROUP = 70; // e.g. start of a loop
    case END_VIEW_GROUP = 80; // e.g. end of a loop

    case OUTPUT_STREAM = 100;

    case ERROR = 200;

    public static function getTypes(): array
    {
        return [
            'UNKNOWN' => self::UNKNOWN,
            'START_DEBUG_SESSION' => self::START_DEBUG_SESSION,
            'END_DEBUG_SESSION' => self::END_DEBUG_SESSION,
            'INSTRUCTION_START' => self::INSTRUCTION_START,
            'UPDATE_INSTRUCTION_ARGUMENT' => self::UPDATE_INSTRUCTION_ARGUMENT,
            'INSTRUCTION_END' => self::INSTRUCTION_END,
            'INFO' => self::INFO,
            'UPDATE_VARIABLE' => self::UPDATE_VARIABLE,
            'START_VIEW_GROUP' => self::START_VIEW_GROUP,
            'END_VIEW_GROUP' => self::END_VIEW_GROUP,
            'OUTPUT_STREAM' => self::OUTPUT_STREAM,
            'ERROR' => self::ERROR,
        ];
    }
}