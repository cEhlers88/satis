<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\Entity\RunChain;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

/** View representation of a RunChain entity. */
class RunChainView implements ViewInterface
{
    /** @var eRunningState[] */
    public array $status = [];

    public string $stateString = '';
    public int $id = -1;

    public string $name = '';

    public ?string $description = null;

    public string $color = '#000000';

    public ?int $maxRuntime = null;

    public \DateTimeInterface $createdAt;

    public string $statisticDetailsJsonString = '';
    public string $averageInterval = '';

    public function __construct(
        RunChain $runChain
    )
    {
        $this->id = $runChain->getId();
        $this->name = $runChain->getName();
        $this->description = $runChain->getDescription();
        $this->color = $runChain->getColor();
        $this->maxRuntime = $runChain->getMaxRuntime();
        $this->createdAt = $runChain->getCreatedAt();

        $statistics = $runChain->getStatistics();
        if (empty($statistics)) {
            return;
        }

        $this->statisticDetailsJsonString = json_encode($runChain->getStatistics()->getDetails());
    }
}
