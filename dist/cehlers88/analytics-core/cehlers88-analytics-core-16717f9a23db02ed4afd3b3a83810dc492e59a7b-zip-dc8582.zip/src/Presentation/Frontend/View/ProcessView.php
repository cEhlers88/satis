<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Presentation\QuickStatusInfoDTO;

/** View representation of a Process entity. */
class ProcessView implements ViewInterface
{
    public string $runnerName = '';
    public string $resultWorkerName = '';

    /** @var eRunningState[] */
    public array $state = [];

    public ?QuickStatusInfoDTO $quickInfo = null;

    public function __construct(
        public int    $id,
        public string $name,
    )
    {
    }
}
