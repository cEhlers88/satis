<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

/** View representation of an Application entity. */
class DefaultView implements ViewInterface
{
    public function __construct()
    {

    }
}