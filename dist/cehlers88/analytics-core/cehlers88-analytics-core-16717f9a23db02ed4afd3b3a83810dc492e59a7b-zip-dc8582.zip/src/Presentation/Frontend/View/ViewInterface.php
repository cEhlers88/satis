<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

/** Interface for entity view representations. */
interface ViewInterface
{

}