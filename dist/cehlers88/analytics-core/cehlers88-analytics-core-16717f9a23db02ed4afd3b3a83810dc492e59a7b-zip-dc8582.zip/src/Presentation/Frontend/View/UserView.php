<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

/** View representation of an Application entity. */
class UserView implements ViewInterface
{
    public function __construct(
        public int    $id,
        public string $email,
        public array  $roles
    )
    {
    }
}