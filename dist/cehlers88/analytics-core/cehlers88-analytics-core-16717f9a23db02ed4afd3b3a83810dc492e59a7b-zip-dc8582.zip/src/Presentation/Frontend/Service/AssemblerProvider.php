<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Service;

use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\AssemblerInterface;

class AssemblerProvider
{
    public function __construct(
        /** @var AssemblerInterface[] $assemblers */
        private iterable $assemblers
    )
    {

    }

    public function getAssemblerForClass(string $class): ?AssemblerInterface
    {
        foreach ($this->assemblers as $assembler) {
            if ($assembler->canHandle($class)) {
                return $assembler;
            }
        }
        return null;
    }
}