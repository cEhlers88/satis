<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ViewInterface;

/** Base class for assemblers that convert entities to views. */
abstract class AbstractAssembler implements AssemblerInterface
{
    /** @var array<int, callable(ViewInterface, EntityInterface): ViewInterface> */
    protected array $extenders = [];

    /**
     * @param array{extenders?: array<int, callable(ViewInterface, EntityInterface): ViewInterface>} $config
     */
    public function configure(array $config): static
    {
        $this->extenders = $config['extenders'] ?? [];

        return $this;
    }

    public function many(iterable $entities): array
    {
        $buffer = [];
        foreach ($entities as $entity) {
            $buffer[] = $this->one($entity);
        }
        return $buffer;
    }

    final public function one(EntityInterface $entity): ViewInterface
    {
        $view = $this->assembleView($entity);

        foreach ($this->extenders as $extender) {
            $view = $extender($view, $entity);
        }

        return $view;
    }

    abstract public function assembleView(EntityInterface $entity): ViewInterface;

    abstract public function canHandle(string $className): bool;
}