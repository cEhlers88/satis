<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ProcessView;
use Cehlers88\AnalyticsCore\Presentation\QuickStatusInfoDTO;

/** Assembler for converting Process entities to views. */
class ProcessAssembler extends AbstractAssembler
{
    /**
     * @param Process $entity
     */
    public function assembleView(EntityInterface $entity): ProcessView
    {
        $view = new ProcessView(
            id: $entity->getId(),
            name: $entity->getName(),
        );

        $startInfo = $entity->getStartInfo();
        $view->runnerName = $startInfo ? $startInfo->runner : '';

        $resultWorkerDef = $entity->getResultWorkerDefinition();
        $view->resultWorkerName = $resultWorkerDef ? $resultWorkerDef->worker : '';

        $view->state = $entity->getState();
        $view->quickInfo = new QuickStatusInfoDTO();

        return $view;
    }

    public function canHandle(string $className): bool
    {
        return $className === Process::class;
    }
}
