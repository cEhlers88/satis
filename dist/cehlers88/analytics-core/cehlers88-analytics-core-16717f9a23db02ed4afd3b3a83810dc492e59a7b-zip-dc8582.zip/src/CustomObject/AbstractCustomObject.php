<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:21
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

use Cehlers88\AnalyticsCore\Entity\CustomEntity;

/** Base class for custom object implementations. */
abstract class AbstractCustomObject implements CustomObjectInterface
{
    private int $_id = -1;
    private array $_attributes = [];
    private string $_name = '';

    /** Get the fully qualified class name. */
    public function getClassName(): string
    {
        return get_class($this);
    }

    /**
     * @param string $name Attribute name.
     * @param mixed $defaultValue Value returned when attribute is not set.
     * @return mixed
     */
    public function getAttribute(string $name, mixed $defaultValue = null): mixed
    {
        return $this->_attributes[$name] ?? $defaultValue;
    }

    public function load(CustomEntity $customEntity): static
    {
        $this->_id = $customEntity->getId();
        $this->_name = $customEntity->getName();

        foreach ($customEntity->getAttributes() as $attribute) {
            $this->setAttribute($attribute->getName(), $attribute->getValue());
        }

        return $this;
    }

    /** Get the object ID. */
    public function getId(): int
    {
        return $this->_id;
    }

    /** Get the object name. */
    public function getName(): string
    {
        return $this->_name;
    }

    /** Set the object name. */
    public function setName(string $name): self
    {
        $this->_name = $name;
        return $this;
    }

    /** Get all attributes. */
    public function getAttributes(): array
    {
        return $this->_attributes;
    }

    /**
     * @param string $name Attribute name.
     * @param mixed $value Attribute value.
     */
    public function setAttribute(string $name, mixed $value): static
    {
        $this->_attributes[$name] = $value;
        return $this;
    }
}