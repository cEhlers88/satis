<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:40
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Repository\CustomEntityRepository;

/** Provider for managing custom object instances. */
class CustomObjectProvider
{
    public function __construct(
        private iterable               $customEntityClasses,
        private CustomEntityRepository $customEntityRepository
    )
    {
    }

    /**
     * @param CustomObjectInterface $customEntity
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClass(CustomObjectInterface $customEntity): array
    {
        return $this->getCustomEntitiesByClassName($customEntity->getClassName());
    }

    /**
     * @param string $className
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClassName(string $className): array
    {
        $customEntities = [];
        foreach ($this->customEntityRepository->findBy(['className' => $className]) as $customEntity) {
            $customEntities[] = $this->resolveCustomEntity($customEntity);
        }
        return $customEntities;
    }

    /**
     * Resolve a CustomEntity into a CustomObjectInterface instance.
     *
     * @param CustomEntity $customEntity The entity to resolve.
     * @return CustomObjectInterface
     */
    public function resolveCustomEntity(CustomEntity $customEntity): CustomObjectInterface
    {
        $className = $customEntity->getClassName();

        /** @var CustomObjectInterface $instance */
        $instance = new $className();
        $instance->load($customEntity);

        return $instance;
    }

    /** Get all registered custom entity classes. */
    public function getCustomClasses(): iterable
    {
        return $this->customEntityClasses;
    }
}