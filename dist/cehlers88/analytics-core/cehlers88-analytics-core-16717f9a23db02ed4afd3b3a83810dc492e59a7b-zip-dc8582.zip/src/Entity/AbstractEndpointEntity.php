<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Entity\AbstractEntity;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * Base class for endpoint entities with name, description, and options.
 */
class AbstractEndpointEntity extends AbstractEntity
{
    #[ORM\Column]
    protected array $allowedMethods = [];

    #[ORM\Column(type: Types::TEXT)]
    protected ?string $description = null;

    #[ORM\Column(length: 255)]
    protected ?string $name = null;

    #[ORM\Column(nullable: true)]
    protected ?array $options = null;

    /** Returns the allowed HTTP methods. */
    public function getAllowedMethods(): array
    {
        return $this->allowedMethods;
    }

    /** Sets the allowed HTTP methods. */
    public function setAllowedMethods(array $allowedMethods): static
    {
        $this->allowedMethods = $allowedMethods;
        return $this;
    }

    /** Returns the endpoint description. */
    public function getDescription(): ?string
    {
        return $this->description;
    }

    /** Sets the endpoint description. */
    public function setDescription(string $description): static
    {
        $this->description = $description;

        return $this;
    }

    /** Returns the endpoint name. */
    public function getName(): ?string
    {
        return $this->name;
    }

    /** Sets the endpoint name. */
    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    /** Returns the endpoint options. */
    public function getOptions(): array
    {
        return $this->options ?? [];
    }

    /** Sets the endpoint options. */
    public function setOptions(?array $options): static
    {
        $this->options = $options;

        return $this;
    }
}