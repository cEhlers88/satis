<?php

namespace Cehlers88\AnalyticsCore\Executor;

/** Provider for creating and managing executor instances. */
class ExecutorProvider
{
    public function __construct(
        private iterable $executors
    )
    {
    }

    /**
     * Get an executor by name.
     *
     * @param string $executorName
     * @return ExecutorInterface|null
     */
    public function getExecutor(string $executorName): ?ExecutorInterface
    {
        foreach ($this->executors as $executor) {
            /** @var ExecutorInterface $executor */
            if ($executor->getName() === $executorName) {
                $executor->setExecutorProvider($this);
                return $executor;
            }
        }
        return null;
    }
}