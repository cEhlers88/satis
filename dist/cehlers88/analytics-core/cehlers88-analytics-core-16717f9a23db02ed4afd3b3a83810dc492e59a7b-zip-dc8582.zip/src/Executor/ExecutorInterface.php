<?php

namespace Cehlers88\AnalyticsCore\Executor;

use Cehlers88\AnalyticsCore\Support\Profiler;
use Cehlers88\AnalyticsCore\Support\PropertyBagInterface;

/** Interface defining the executor contract. */
interface ExecutorInterface extends PropertyBagInterface
{
    /** Execute the full lifecycle. */
    public function run(): void;

    /** Get remaining allowed execution time in seconds, or null if unlimited. */
    public function getRestExecutionTime(): ?float;

    /** Get remaining allowed execution time in milliseconds, or null if unlimited. */
    public function getRestExecutionTimeMs(): ?float;

    /** Get the executor name. */
    public function getName(): string;

    /** Get the executor provider. */
    public function getExecutorProvider(): ExecutorProvider;

    /** Set the executor provider. */
    public function setExecutorProvider(ExecutorProvider $executorProvider): static;

    public function getProfiler(): Profiler;

    /**
     * Check if the executor is currently running.
     */
    public function isRunning(): bool;

    public function onEnd(): void;

    public function onStart(): void;
}