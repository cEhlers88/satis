<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Analytics\ApplicationContext;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * Repository for TrackingBuffer entities.
 *
 * @extends ServiceEntityRepository<TrackingBuffer>
 *
 * @method TrackingBuffer|null find($id, $lockMode = null, $lockVersion = null)
 * @method TrackingBuffer|null findOneBy(array $criteria, array $orderBy = null)
 * @method TrackingBuffer[]    findAll()
 * @method TrackingBuffer[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class TrackingBufferRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry                $registry,
                                private EntityManagerInterface $entityManager,
                                private ApplicationContext     $applicationContext
    )
    {
        parent::__construct($registry, TrackingBuffer::class);
    }

    public function countUnhandled(int $applicationId): int
    {
        return count($this->getUnhandled($applicationId));
    }

    public function getUnhandled(int $applicationId): array
    {
        return $this->createQueryBuilder('t')
            ->where('t.state != ' . eTrackingBufferState::PROCESSED_FINISHED->value)
            ->andWhere('t.application = :applicationId')
            ->setParameter('applicationId', $applicationId)
            ->getQuery()
            ->getResult();
    }

    /**
     * Return all available key values as array
     * @param int $applicationId
     * @return string[]
     */
    public function getAvailableKeyValues(int $applicationId = -1): array
    {
        $qb = $this->createQueryBuilder('t');
        $qb->select('t.keyValue');
        $qb->distinct();
        if ($applicationId > 0) {
            $qb->andWhere('t.application = :applicationId');
            $qb->setParameter('applicationId', $applicationId);
        }
        $qb->orderBy('t.keyValue', 'ASC');
        $resultArray = [];

        foreach ($qb->getQuery()->getArrayResult() as $row) {
            $resultArray[] = $row['keyValue'];
        }
        return $resultArray;
    }

    /**
     * @param int $applicationId
     * @param int $limit
     * @return TrackingBuffer[]
     */
    public function getUnfinished(int $applicationId, int $limit = -1): array
    {
        $result = $this->createQueryBuilder('t')
            ->where('t.state != ' . eTrackingBufferState::PROCESSED_FINISHED->value)
            ->andWhere('t.state != ' . eTrackingBufferState::ERROR->value)
            ->andWhere('t.application = :applicationId')
            ->setParameter('applicationId', $applicationId);
        if ($limit > 0) {
            $result->setMaxResults($limit);
        }
        return $result->getQuery()
            ->getResult();
    }

    public function findAllLimited($keyFilters = [], $limit = 100)
    {
        $queryBuilder = $this->createQueryBuilder('t')
            ->setMaxResults($limit)
            ->orderBy('t.id', 'DESC');

        if (count($keyFilters) > 0) {
            $queryBuilder->andWhere('t.keyValue IN (:keyFilters)')
                ->setParameter('keyFilters', $keyFilters);
        }

        return $queryBuilder->getQuery()->getResult();
    }

    public function findByAnyDataKeyValue(array $keys, eTrackingBufferState $state = eTrackingBufferState::NEW): array
    {
        return $this->createQueryBuilder('t')
            ->where('t.state = :state')
            ->andWhere('t.keyValue IN (:keys)')
            ->setParameter('state', $state->value)
            ->setParameter('keys', $keys)
            ->getQuery()
            ->getResult();
    }

    public function findByDataLike($needle, $excludeFinished = false, $limit = -1): array
    {
        $result = $this->createQueryBuilder('t')
            ->where('t.data LIKE :needle');
        if ($excludeFinished) {
            $result->andWhere('t.state != ' . eTrackingBufferState::PROCESSED_FINISHED->value);
        }

        $result->setParameter('needle', '%' . $needle . '%');

        if ($limit > 0) {
            $result->setMaxResults($limit);
        }
        return $result->getQuery()->getResult();
    }

    public function createChildBuffer(string $key, $data, TrackingBuffer $parentBuffer, bool $autoSave = false): void
    {
        $parentType = '';
        $trackingBuffer = new TrackingBuffer();
        $trackingBuffer
            ->setApplication($parentBuffer->getApplication())
            ->setState(eTrackingBufferState::NEW)
            ->setTimestamp(new \DateTime())
            ->setData([
                'key' => $key,
                'data' => $data,
            ])
            ->setHandlerData([
                'parent_type' => $parentType,
                'parent_id' => $parentBuffer->getId(),
            ]);

        if (!$autoSave) {
            return;
        }
        $this->trackingBufferRepository->save($trackingBuffer, true);
    }

    public function save(TrackingBuffer $trackingBuffer, bool $flush = false): TrackingBufferRepository
    {
        if (is_null($trackingBuffer->getTimestamp())) {
            $trackingBuffer->setTimestamp(new \DateTime());
        }

        $data = $trackingBuffer->getData();
        if (!isset($data['data'])) {
            $data['data'] = [];
        }
        if (!isset($data['body'])) {
            $data['body'] = [];
        }
        $data['applicationVersion'] = $this->applicationContext->getApplicationVersion();

        $trackingBuffer->setData($data);

        $this->entityManager->persist($trackingBuffer);
        if (!$flush) {
            return $this;
        }

        $this->entityManager->flush();
        return $this;
    }

    public function flush(): TrackingBufferRepository
    {
        $this->entityManager->flush();
        return $this;
    }
}
