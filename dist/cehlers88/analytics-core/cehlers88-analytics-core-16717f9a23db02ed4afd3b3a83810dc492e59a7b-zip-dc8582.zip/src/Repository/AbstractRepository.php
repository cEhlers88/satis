<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;

/** Base class for entity repositories. */
abstract class AbstractRepository extends ServiceEntityRepository
{
    /** @var int[] */
    private array $idBlacklist = [];

    /** Get the list of blacklisted IDs. */
    public function getIdBlacklist(): array
    {
        return $this->idBlacklist;
    }

    /**
     * @param int $id
     * @return static
     */
    public function addIdToBlacklist(int $id): static
    {
        $this->idBlacklist[] = $id;
        return $this;
    }

    /**
     * @param int $id
     * @return static
     */
    public function removeIdFromBlacklist(int $id): static
    {
        $key = array_search($id, $this->idBlacklist);
        if ($key !== false) {
            unset($this->idBlacklist[$key]);
        }
        return $this;
    }

    /** Clear all IDs from the blacklist. */
    public function clearIdBlacklist(): void
    {
        $this->idBlacklist = [];
    }

    protected function createPrefilteredQueryBuilder(string $alias): \Doctrine\ORM\QueryBuilder
    {
        $queryBuilder = $this->createQueryBuilder($alias);

        if (!empty($this->idBlacklist)) {
            $queryBuilder
                ->andWhere($alias . '.id NOT IN (:blacklist)')
                ->setParameter('blacklist', $this->idBlacklist);
        }

        return $queryBuilder;
    }
}