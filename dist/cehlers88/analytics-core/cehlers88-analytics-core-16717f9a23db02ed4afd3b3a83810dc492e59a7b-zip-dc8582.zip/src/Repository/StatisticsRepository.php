<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Analytics\Entity\Statistics;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * Repository for Statistics entities.
 *
 * @extends ServiceEntityRepository<Statistics>
 */
class StatisticsRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Statistics::class);
    }
}
