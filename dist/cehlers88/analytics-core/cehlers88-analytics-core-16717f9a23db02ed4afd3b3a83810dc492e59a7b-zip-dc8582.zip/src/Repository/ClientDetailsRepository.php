<?php

namespace Cehlers88\AnalyticsCore\Repository;

use Cehlers88\AnalyticsCore\Entity\ClientDetails;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * Repository for ClientDetails entities.
 *
 * @extends ServiceEntityRepository<ClientDetails>
 *
 * @method ClientDetails|null find($id, $lockMode = null, $lockVersion = null)
 * @method ClientDetails|null findOneBy(array $criteria, array $orderBy = null)
 * @method ClientDetails[]    findAll()
 * @method ClientDetails[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ClientDetailsRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, ClientDetails::class);
    }

}
