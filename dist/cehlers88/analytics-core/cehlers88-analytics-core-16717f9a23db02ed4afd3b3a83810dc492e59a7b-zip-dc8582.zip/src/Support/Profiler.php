<?php

namespace Cehlers88\AnalyticsCore\Support;

use Analytics\Utils\UnitUtils;
use RuntimeException;

/** Utility class for measuring execution time. */
class Profiler
{
    /** @var \DateTime|null */
    private ?\DateTime $startedAt = null;

    /** @var float|null */
    private ?float $startTimestamp = null;
    /** @var float|null */
    private ?float $endTimestamp = null;

    /** @var int|null */
    private ?int $startMemoryBytes = null;
    /** @var int|null */
    private ?int $endMemoryBytes = null;

    /**
     * Run a callable and return profiling results.
     *
     * @param callable $callable
     * @return array
     */
    public static function run(callable $callable): array
    {
        $exception = null;
        $result = null;

        $profiler = new self();
        $profiler->start();

        try {
            $result = $callable();
        } catch (\Throwable $e) {
            $exception = $e;
        }

        $profiler->stop();

        return [
            'result' => $result,
            'exception' => $exception,
            'hasError' => $exception !== null,
            'profiler' => $profiler,
        ];
    }

    /** Start the profiler. */
    public function start(): void
    {
        $this->startedAt = new \DateTime();
        $this->startTimestamp = microtime(true);
        $this->startMemoryBytes = memory_get_usage(true);

        $this->endTimestamp = null;
        $this->endMemoryBytes = null;
    }

    /** Stop the profiler. */
    public function stop(): void
    {
        $this->endTimestamp = microtime(true);
        $this->endMemoryBytes = memory_get_usage(true);
    }

    /** Get the DateTime when profiling started. */
    public function getStartedAt(): \DateTime
    {
        return $this->startedAt;
    }

    /** Get the duration as a human-readable string. */
    public function getReadableDuration(): string
    {
        return UnitUtils::formatDuration($this->getDurationMilliseconds());
    }

    /** Get the elapsed duration in milliseconds. */
    public function getDurationMilliseconds(): float
    {
        return $this->getDurationSeconds() * 1000;
    }

    /** Get the elapsed duration in seconds. */
    public function getDurationSeconds(): float
    {
        $this->ensureStopped();
        return $this->endTimestamp - $this->startTimestamp;
    }

    private function ensureStopped(): void
    {
        if ($this->startTimestamp === null) {
            throw new RuntimeException('Profiler not started.');
        }

        if ($this->endTimestamp === null || $this->endMemoryBytes === null) {
            $this->stop();
        }
    }

    /** Get the memory used during profiling in bytes. */
    public function getUsedMemoryBytes(): int
    {
        $this->ensureStopped();
        return $this->endMemoryBytes - $this->startMemoryBytes;
    }

    /** Get the memory usage at start in bytes. */
    public function getStartMemoryBytes(): int
    {
        return $this->startMemoryBytes ?? 0;
    }

    /** Get the memory usage at stop in bytes. */
    public function getEndMemoryBytes(): int
    {
        $this->ensureStopped();
        return $this->endMemoryBytes;
    }

    /**
     * @param bool $realUsage
     * @return int
     */
    public function getPeakMemoryBytes(bool $realUsage = true): int
    {
        return memory_get_peak_usage($realUsage);
    }
}
