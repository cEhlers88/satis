<?php

namespace Cehlers88\AnalyticsCore\Support\Error;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Support\Logging\LoggerInterface;

/** Interface for error bag implementations. */
interface ErrorBagInterface
{
    /**
     * Enable or disable debug mode.
     *
     * @param bool $enable
     * @return static
     */
    public function enableDebugMode(bool $enable): static;

    /**
     * Get all errors concatenated as a string.
     *
     * @param string $separator
     * @return string
     */
    public function getErrorsAsString(string $separator = PHP_EOL): string;

    /** Get the logger instance. */
    public function getLogger(): LoggerInterface;

    /** Set the logger instance. */
    public function setLogger(LoggerInterface $logger): static;

    /** Check whether any errors have been recorded. */
    public function hasError(): bool;

    /**
     * @param string $message
     * @param int $code
     * @param array $data
     * @return ErrorDTO
     */
    public function setError(string $message, int $code = -1, array $data = []): ErrorDTO;

    /**
     * @param string $message
     * @param bool $onlyInDebugMode
     * @return static
     */
    public function logInfo(string $message, bool $onlyInDebugMode = false): static;

    /**
     * @param string $message
     * @param bool $onlyInDebugMode
     * @return static
     */
    public function logWarning(string $message, bool $onlyInDebugMode = false): static;

    /**
     * @param string $message
     * @param bool $onlyInDebugMode
     * @return static
     */
    public function logError(string $message, bool $onlyInDebugMode = false): static;

    /** Hook called when an error is recorded. */
    public function onError(ErrorDTO $error): void;
}