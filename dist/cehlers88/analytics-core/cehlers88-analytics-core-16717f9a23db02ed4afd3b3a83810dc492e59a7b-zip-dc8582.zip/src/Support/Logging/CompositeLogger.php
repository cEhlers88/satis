<?php

namespace Cehlers88\AnalyticsCore\Support\Logging;

/**
 * CompositeLogger aggregates multiple logger instances and forwards log messages
 * to each logger that supports the invoked logging method. It allows combining
 * functionality from different loggers and broadcasting log messages.
 */
class CompositeLogger extends AbstractLogger
{
    /** @var LoggerInterface[] $loggers */
    protected array $loggers;

    public function __construct(LoggerInterface ...$loggers)
    {
        $this->setLoggers($loggers);
    }

    public function setLoggers(array $loggers): static
    {
        $this->loggers = $loggers;
        return $this;
    }

    public function addLogger(LoggerInterface $logger): static
    {
        $this->loggers[] = $logger;
        return $this;
    }

    public function getLoggerByClass(string $className): ?LoggerInterface
    {
        foreach ($this->loggers as $logger) {
            if ($logger instanceof $className) {
                return $logger;
            }
        }
        return null;
    }

    public function error(string $message): void
    {
        $this->fanout(__FUNCTION__, $message);
    }

    private function fanout(string $method, mixed ...$args): void
    {
        foreach ($this->loggers as $logger) {
            if (method_exists($logger, $method)) {
                $logger->$method(...$args);
            }
        }
    }

    public function info(string $message): void
    {
        $this->fanout(__FUNCTION__, $message);
    }

    public function progressAdvance(int $step = 1): void
    {
        $this->fanout(__FUNCTION__, $step);
    }

    public function progressStart(int $max): void
    {
        $this->fanout(__FUNCTION__, $max);
    }

    public function warning(string $message): void
    {
        $this->fanout(__FUNCTION__, $message);
    }

    public function setIgnoreInfoLog(bool $ignoreInfoLog = true): static
    {
        $this->fanout(__FUNCTION__, $ignoreInfoLog);
        return $this;
    }
}