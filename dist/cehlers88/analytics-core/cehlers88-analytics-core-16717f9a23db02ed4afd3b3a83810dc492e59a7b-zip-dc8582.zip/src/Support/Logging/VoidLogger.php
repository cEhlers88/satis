<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.09.2024
 * Time: 02:02
 */

namespace Cehlers88\AnalyticsCore\Support\Logging;

/** No-op logger that discards all log messages. */
class VoidLogger extends AbstractLogger
{
    public function info(string $message): void
    {

    }

    public function progressAdvance(int $step = 1): void
    {
        //
    }

    public function error($message): void
    {
    }

    public function progressStart(int $max): void
    {
    }

    public function warning(string $message): void
    {

    }

    public function getBuffer(): array
    {
        return [];
    }


}