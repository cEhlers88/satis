<?php

namespace Cehlers88\AnalyticsCore\Support;

use BackedEnum;

/** Utility class for data type conversions. */
class ConverterUtils
{
    /**
     * @param array<int|BackedEnum> $states
     */
    public static function arrayToBitmask(array $states): int
    {
        $mask = 0;

        foreach ($states as $state) {
            if ($state instanceof BackedEnum) {
                $mask |= $state->value;
            } else {
                $mask |= (int)$state;
            }
        }

        return $mask;
    }

    /**
     * @param array $array
     * @return string
     */
    public static function associativeArrayToString(array $array): string
    {
        $parts = [];
        foreach ($array as $key => $value) {
            $parts[] = $key . ':' . (is_array($value) ? self::associativeArrayToString($value) : $value);
        }
        return implode(',', $parts);
    }
}