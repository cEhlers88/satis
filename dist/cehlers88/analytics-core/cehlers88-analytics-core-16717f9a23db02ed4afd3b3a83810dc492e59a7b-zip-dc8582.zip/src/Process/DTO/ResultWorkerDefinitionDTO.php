<?php

namespace Cehlers88\AnalyticsCore\Process\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;

/** Data transfer object defining a result worker configuration. */
class ResultWorkerDefinitionDTO extends DTO
{
    /** @var string */
    public string $worker = '';
    /** @var array<string, mixed> */
    public array $arguments = [];

    /**
     * @param array<string, mixed> $data
     * @return static
     */
    public static function createFromArray(array $data): static
    {
        return self::create(
            $data['worker'] ?? '',
            $data['arguments'] ?? []
        );
    }

    /**
     * @param string $worker
     * @param array<string, mixed> $arguments
     * @return static
     */
    public static function create(string $worker, array $arguments = []): static
    {
        $dto = new static();
        $dto->worker = $worker;
        $dto->arguments = $arguments;

        return $dto;
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return get_object_vars($this);
    }
}