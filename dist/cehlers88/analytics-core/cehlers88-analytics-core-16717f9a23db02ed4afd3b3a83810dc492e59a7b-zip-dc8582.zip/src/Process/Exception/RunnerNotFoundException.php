<?php

namespace Cehlers88\AnalyticsCore\Process\Exception;

/** Exception thrown when a process runner is not found. */
class RunnerNotFoundException extends \Exception
{
    private string $runner;

    /** @return string */
    public function getRunner(): string
    {
        return $this->runner;
    }

    /** @param string $runner */
    public function setRunner(string $runner): static
    {
        $this->runner = $runner;
        return $this;
    }

}