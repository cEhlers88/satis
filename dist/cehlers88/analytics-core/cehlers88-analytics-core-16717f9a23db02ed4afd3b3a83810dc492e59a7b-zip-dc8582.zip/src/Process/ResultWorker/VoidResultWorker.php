<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

/** No-op result worker that performs no processing. */
class VoidResultWorker extends AbstractProcessResultWorker
{
    public function handleResult(mixed $result): static
    {
        return $this;
    }

}