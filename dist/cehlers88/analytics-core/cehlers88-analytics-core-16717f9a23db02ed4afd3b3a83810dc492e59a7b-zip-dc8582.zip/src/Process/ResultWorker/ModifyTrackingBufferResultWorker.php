<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

/** Result worker that modifies tracking buffer entries. */
class ModifyTrackingBufferResultWorker extends AbstractProcessResultWorker
{
    public function handleResult(mixed $result): static
    {
        return $this;
    }


}