<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\Process\Runner\ProcessRunnerInterface;

/** Interface for process result workers. */
interface ProcessResultWorkerInterface
{
    /** Set the process entity. */
    public function setProcess(Process $process): static;

    /**
     * Handle the result of a process.
     *
     * @param mixed $result
     * @return static
     */
    public function handleResult(mixed $result): static;

    public function setStatusCode(int $statusCode): static;

    public function setRunner(ProcessRunnerInterface $runner): static;
}