<?php

namespace Cehlers88\AnalyticsCore\Process\Observer\Message;

use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;

/** Observer message dispatched when process result handling starts. */
class ProcessStartHandlingObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'process.startHandling';

    public function __construct(
        public Process $processEntity,
        public array   $additionalData = []
    )
    {
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}