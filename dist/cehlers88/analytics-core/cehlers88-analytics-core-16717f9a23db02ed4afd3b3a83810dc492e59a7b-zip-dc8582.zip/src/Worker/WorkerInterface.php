<?php

namespace Cehlers88\AnalyticsCore\Worker;

/** Interface for background workers. */
interface WorkerInterface
{
    /**
     * Configure the worker with the given properties.
     *
     * @param array $properties Configuration properties.
     * @return static
     */
    public function configure(array $properties): static;

    /**
     * Get the list of required job class names.
     *
     * @return array<string>
     */
    public function getRequiredJobs(): array;

    /** Set a benchmark value. */
    public function setBenchmarkValue(string $key, mixed $value): static;

    /** Get all benchmark data. */
    public function getBenchmark(): array;

    /** Check whether the worker reached its timeout. */
    public function reachedTimeout(): bool;
}