<?php

namespace Cehlers88\AnalyticsCore\Worker\Job;

/** Interface for worker jobs. */
interface JobInterface
{

}