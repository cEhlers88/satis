<?php

namespace Cehlers88\AnalyticsCore\Observer;

use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;

/** Provider for managing and notifying observers. */
class ObserverProvider
{
    /**
     * @param iterable<ObserverInterface> $observers
     */
    public function __construct(
        private iterable $observers
    )
    {

    }

    /**
     * Dispatch a message to all observers that can handle it.
     *
     * @param ObserverMessageInterface $message
     * @return void
     */
    public function dispatch(ObserverMessageInterface $message): void
    {
        foreach ($this->observers as $observer) {
            if ($observer->canHandle($message)) {
                $observer->handle($message);
            }
        }
    }
}