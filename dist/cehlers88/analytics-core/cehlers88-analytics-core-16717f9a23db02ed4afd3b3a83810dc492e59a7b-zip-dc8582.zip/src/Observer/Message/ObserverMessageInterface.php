<?php

namespace Cehlers88\AnalyticsCore\Observer\Message;

/** Interface for observer messages. */
interface ObserverMessageInterface
{
    /** Get the unique message key. */
    public function getKey(): string;
}