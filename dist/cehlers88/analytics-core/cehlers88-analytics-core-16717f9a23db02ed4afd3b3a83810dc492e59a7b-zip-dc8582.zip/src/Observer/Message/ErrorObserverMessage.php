<?php

namespace Cehlers88\AnalyticsCore\Observer\Message;

use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;

/** Observer message dispatched when an error occurs. */
class ErrorObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'error';

    public function __construct(
        public \Throwable $exception,
        public string     $context,
        public mixed      $data = null
    )
    {
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}