<?php

namespace Cehlers88\AnalyticsCore\Observer;

use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;

/** Interface for observers that react to system events. */
interface ObserverInterface
{
    /**
     * Determine whether the observer can handle the given message.
     *
     * @param ObserverMessageInterface $message
     * @return bool
     */
    public function canHandle(ObserverMessageInterface $message): bool;

    /**
     * Handle the given observer message.
     *
     * @param ObserverMessageInterface $message
     * @return void
     */
    public function handle(ObserverMessageInterface $message): void;
}