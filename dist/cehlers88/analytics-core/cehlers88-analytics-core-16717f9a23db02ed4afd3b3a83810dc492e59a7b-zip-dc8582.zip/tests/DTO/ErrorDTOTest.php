<?php

namespace Cehlers88\AnalyticsCore\Tests\DTO;

use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use PHPUnit\Framework\TestCase;

class ErrorDTOTest extends TestCase
{
    public function testCreateSetsProperties(): void
    {
        $dto = ErrorDTO::create(42, 'Something went wrong', ['detail' => 'value']);

        $this->assertSame(42, $dto->number);
        $this->assertSame('Something went wrong', $dto->message);
        $this->assertSame(['detail' => 'value'], $dto->data);
    }

    public function testCreateWithDefaultValues(): void
    {
        $dto = ErrorDTO::create(0);

        $this->assertSame(0, $dto->number);
        $this->assertSame('', $dto->message);
        $this->assertNull($dto->data);
    }

    public function testToArrayReturnsExpectedStructure(): void
    {
        $dto = ErrorDTO::create(10, 'Test error', ['key' => 'val']);

        $array = $dto->toArray();

        $this->assertArrayHasKey('number', $array);
        $this->assertArrayHasKey('error', $array);
        $this->assertArrayHasKey('data', $array);
        $this->assertSame(10, $array['number']);
        $this->assertSame('Test error', $array['error']);
        $this->assertSame(['key' => 'val'], $array['data']);
    }

    public function testToStringWithErrorNumber(): void
    {
        $dto = ErrorDTO::create(5, 'Fatal error');

        $this->assertSame('#5: Fatal error', (string)$dto);
    }

    public function testToStringWithZeroNumber(): void
    {
        $dto = ErrorDTO::create(0, 'No error');

        $this->assertSame('', (string)$dto);
    }
}
