<?php

namespace Cehlers88\AnalyticsCore\Tests\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\RunChainAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\RunChainView;
use Cehlers88\AnalyticsCore\Entity\RunChain;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;

class RunChainAssemblerTest extends TestCase
{
    public function testOneMapsRunChainToView(): void
    {
        $runChain = $this->mockRunChain(3, 'nightly-run', 'Runs every night', '#123456', [eRunningState::Idle], 3600);

        $assembler = new RunChainAssembler();
        $view = $assembler->assembleView($runChain);

        $this->assertInstanceOf(RunChainView::class, $view);
        $this->assertSame(3, $view->id);
        $this->assertSame('nightly-run', $view->name);
        $this->assertSame('Runs every night', $view->description);
        $this->assertSame('#123456', $view->color);
        $this->assertSame(3600, $view->maxRuntime);
        $this->assertContains(eRunningState::Idle, $view->status);
        $this->assertNotEmpty($view->stateString);
    }

    private function mockRunChain(
        int     $id,
        string  $name,
        ?string $description,
        string  $color,
        array   $status,
        ?int    $maxRuntime
    ): RunChain
    {
        $runChain = $this->createMock(RunChain::class);
        $runChain->method('getId')->willReturn($id);
        $runChain->method('getName')->willReturn($name);
        $runChain->method('getDescription')->willReturn($description);
        $runChain->method('getColor')->willReturn($color);
        $runChain->method('getStatus')->willReturn($status);
        $runChain->method('getMaxRuntime')->willReturn($maxRuntime);
        $runChain->method('getCreatedAt')->willReturn(new DateTimeImmutable());

        return $runChain;
    }

    public function testOneMapsNullableDescriptionAndStatus(): void
    {
        $runChain = $this->mockRunChain(5, 'chain-a', null, '#aabbcc', [], 300);

        $assembler = new RunChainAssembler();
        $view = $assembler->assembleView($runChain);

        $this->assertNull($view->description);
        $this->assertSame('', $view->stateString);
    }

    public function testManyMapsMultipleRunChainsToViews(): void
    {
        $chains = [
            $this->mockRunChain(1, 'chain-one', null, '#111111', [], 60),
            $this->mockRunChain(2, 'chain-two', 'Second chain', '#222222', [], 120),
        ];

        $assembler = new RunChainAssembler();
        $views = $assembler->many($chains);

        $this->assertCount(2, $views);
        $this->assertSame(1, $views[0]->id);
        $this->assertSame('chain-one', $views[0]->name);
        $this->assertSame(2, $views[1]->id);
        $this->assertSame('chain-two', $views[1]->name);
    }
}
