<?php

namespace Cehlers88\AnalyticsCore\Tests\ENUM\State;

use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use PHPUnit\Framework\TestCase;

class eTrackingBufferStateTest extends TestCase
{
    public function testEnumCasesHaveUniqueValues(): void
    {
        $values = array_map(fn($case) => $case->value, eTrackingBufferState::cases());
        $this->assertSame(count($values), count(array_unique($values)));
    }

    public function testNewStateHasValueZero(): void
    {
        $this->assertSame(0, eTrackingBufferState::NEW->value);
    }

    public function testExpectedCasesExist(): void
    {
        $this->assertSame(0, eTrackingBufferState::NEW->value);
        $this->assertSame(1, eTrackingBufferState::IN_PROGRESS->value);
        $this->assertSame(2, eTrackingBufferState::PROCESSED_NOT_FINISHED->value);
        $this->assertSame(4, eTrackingBufferState::PROCESSED_FINISHED->value);
        $this->assertSame(512, eTrackingBufferState::CHILD_PROCESS_STARTED->value);
        $this->assertSame(1024, eTrackingBufferState::CHILD_PROCESSES_FINISHED->value);
        $this->assertSame(2048, eTrackingBufferState::CHILD_PROCESS_WAITING->value);
        $this->assertSame(4096, eTrackingBufferState::CHILD_PROCESS_FAILED->value);
        $this->assertSame(8192, eTrackingBufferState::ERROR->value);
    }

    public function testFromIntReturnsCorrectCase(): void
    {
        $this->assertSame(eTrackingBufferState::NEW, eTrackingBufferState::from(0));
        $this->assertSame(eTrackingBufferState::IN_PROGRESS, eTrackingBufferState::from(1));
        $this->assertSame(eTrackingBufferState::ERROR, eTrackingBufferState::from(8192));
    }

    public function testTryFromReturnsNullForInvalidValue(): void
    {
        $this->assertNull(eTrackingBufferState::tryFrom(9999));
    }
}
