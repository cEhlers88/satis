<?php

namespace Cehlers88\AnalyticsCore\Tests\ENUM\State;

use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use PHPUnit\Framework\TestCase;

class eRunningStateTest extends TestCase
{
    public function testEnumCasesHaveUniqueValues(): void
    {
        $values = array_map(fn($case) => $case->value, eRunningState::cases());
        $this->assertSame(count($values), count(array_unique($values)));
    }

    public function testBitwiseCombination(): void
    {
        $combined = eRunningState::New->value | eRunningState::Running->value;
        $this->assertSame(1 | (1 << 10), $combined);
    }

    public function testToKeyValueArrayReturnsAllCases(): void
    {
        $result = eRunningState::toKeyValueArray();

        $this->assertIsArray($result);
        $this->assertCount(count(eRunningState::cases()), $result);
    }

    public function testToKeyValueArrayDefaultKeys(): void
    {
        $result = eRunningState::toKeyValueArray();

        foreach ($result as $item) {
            $this->assertArrayHasKey('key', $item);
            $this->assertArrayHasKey('value', $item);
        }
    }

    public function testToKeyValueArrayCustomKeys(): void
    {
        $result = eRunningState::toKeyValueArray('name', 'id');

        foreach ($result as $item) {
            $this->assertArrayHasKey('name', $item);
            $this->assertArrayHasKey('id', $item);
        }
    }

    public function testToKeyValueArrayContainsExpectedStates(): void
    {
        $result = eRunningState::toKeyValueArray();
        $names = array_column($result, 'key');

        $this->assertContains('New', $names);
        $this->assertContains('Running', $names);
        $this->assertContains('Finished', $names);
        $this->assertContains('Error', $names);
        $this->assertContains('FatalError', $names);
        $this->assertContains('Unknown', $names);
    }

    public function testStateValuesArePowersOfTwo(): void
    {
        foreach (eRunningState::cases() as $case) {
            $value = $case->value;
            $this->assertSame(1, substr_count(decbin($value), '1'), sprintf(
                'State %s with value %d is not a power of two',
                $case->name,
                $value
            ));
        }
    }

    public function testNewStateValue(): void
    {
        $this->assertSame(1, eRunningState::New->value);
    }

    public function testUnknownStateValue(): void
    {
        $this->assertSame(1 << 60, eRunningState::Unknown->value);
    }
}
