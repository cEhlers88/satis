<?php

namespace Cehlers88\AnalyticsCore\Tests\ENUM;

use Cehlers88\AnalyticsCore\ENUM\eInputType;
use PHPUnit\Framework\TestCase;

class eInputTypeTest extends TestCase
{
    public function testFromStringReturnsCorrectEnumCase(): void
    {
        $this->assertSame(eInputType::TEXT_SINGLE_LINE, eInputType::fromString('TEXT_SINGLE_LINE'));
        $this->assertSame(eInputType::TEXT_MULTI_LINE, eInputType::fromString('TEXT_MULTI_LINE'));
        $this->assertSame(eInputType::NUMBER, eInputType::fromString('NUMBER'));
        $this->assertSame(eInputType::DATE, eInputType::fromString('DATE'));
        $this->assertSame(eInputType::TIME, eInputType::fromString('TIME'));
        $this->assertSame(eInputType::DATE_TIME, eInputType::fromString('DATE_TIME'));
        $this->assertSame(eInputType::SELECT, eInputType::fromString('SELECT'));
        $this->assertSame(eInputType::CHECKBOX, eInputType::fromString('CHECKBOX'));
        $this->assertSame(eInputType::RADIO, eInputType::fromString('RADIO'));
        $this->assertSame(eInputType::FILE, eInputType::fromString('FILE'));
        $this->assertSame(eInputType::BOOLEAN, eInputType::fromString('BOOLEAN'));
        $this->assertSame(eInputType::PASSWORD, eInputType::fromString('PASSWORD'));
        $this->assertSame(eInputType::EMAIL, eInputType::fromString('EMAIL'));
        $this->assertSame(eInputType::URL, eInputType::fromString('URL'));
        $this->assertSame(eInputType::COLOR, eInputType::fromString('COLOR'));
        $this->assertSame(eInputType::RANGE, eInputType::fromString('RANGE'));
        $this->assertSame(eInputType::REPEAT, eInputType::fromString('REPEAT'));
        $this->assertSame(eInputType::UNIQUE_ID, eInputType::fromString('UNIQUE_ID'));
    }

    public function testFromStringThrowsOnInvalidValue(): void
    {
        $this->expectException(\UnhandledMatchError::class);
        eInputType::fromString('INVALID_TYPE');
    }

    public function testEnumValuesMatchCaseNames(): void
    {
        foreach (eInputType::cases() as $case) {
            $this->assertSame($case->name, $case->value);
        }
    }

    public function testAllCasesAreAccessibleViaFromString(): void
    {
        foreach (eInputType::cases() as $case) {
            $this->assertSame($case, eInputType::fromString($case->value));
        }
    }
}
