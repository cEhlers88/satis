<?php

namespace Cehlers88\AnalyticsCore\Tests\Process\DTO;

use Cehlers88\AnalyticsCore\Process\DTO\StartInfoDTO;
use PHPUnit\Framework\TestCase;

class StartInfoDTOTest extends TestCase
{
    public function testCreateSetsProperties(): void
    {
        $dto = StartInfoDTO::create('MyRunnerClass', ['arg1' => 'value1']);

        $this->assertSame('MyRunnerClass', $dto->runner);
        $this->assertSame(['arg1' => 'value1'], $dto->runner_arguments);
    }

    public function testCreateWithDefaultArguments(): void
    {
        $dto = StartInfoDTO::create('MyRunnerClass');

        $this->assertSame('MyRunnerClass', $dto->runner);
        $this->assertSame([], $dto->runner_arguments);
    }

    public function testCreateFromArrayWithAllKeys(): void
    {
        $data = [
            StartInfoDTO::KEY_RUNNER => 'SomeRunner',
            StartInfoDTO::KEY_RUNNER_ARGUMENTS => ['key' => 'val'],
        ];

        $dto = StartInfoDTO::createFromArray($data);

        $this->assertSame('SomeRunner', $dto->runner);
        $this->assertSame(['key' => 'val'], $dto->runner_arguments);
    }

    public function testCreateFromArrayWithMissingKeys(): void
    {
        $dto = StartInfoDTO::createFromArray([]);

        $this->assertSame('', $dto->runner);
        $this->assertSame([], $dto->runner_arguments);
    }

    public function testToArrayReturnsAllProperties(): void
    {
        $dto = StartInfoDTO::create('RunnerClass', ['a' => 1]);
        $array = $dto->toArray();

        $this->assertArrayHasKey('runner', $array);
        $this->assertArrayHasKey('runner_arguments', $array);
        $this->assertSame('RunnerClass', $array['runner']);
        $this->assertSame(['a' => 1], $array['runner_arguments']);
    }

    public function testRoundTripThroughArray(): void
    {
        $original = StartInfoDTO::create('TestRunner', ['foo' => 'bar']);
        $restored = StartInfoDTO::createFromArray($original->toArray());

        $this->assertSame($original->runner, $restored->runner);
        $this->assertSame($original->runner_arguments, $restored->runner_arguments);
    }
}
