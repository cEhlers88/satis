<?php

namespace Cehlers88\AnalyticsCore\Tests\Support;

use Cehlers88\AnalyticsCore\Support\ConverterUtils;
use PHPUnit\Framework\TestCase;

class ConverterUtilsTest extends TestCase
{
    public function testAssociativeArrayToStringWithFlatArray(): void
    {
        $result = ConverterUtils::associativeArrayToString(['foo' => 'bar', 'baz' => 'qux']);

        $this->assertSame('foo:bar,baz:qux', $result);
    }

    public function testAssociativeArrayToStringWithEmptyArray(): void
    {
        $result = ConverterUtils::associativeArrayToString([]);

        $this->assertSame('', $result);
    }

    public function testAssociativeArrayToStringWithSingleEntry(): void
    {
        $result = ConverterUtils::associativeArrayToString(['key' => 'value']);

        $this->assertSame('key:value', $result);
    }

    public function testAssociativeArrayToStringWithNestedArray(): void
    {
        $result = ConverterUtils::associativeArrayToString(['outer' => ['inner' => 'deep']]);

        $this->assertSame('outer:inner:deep', $result);
    }

    public function testArrayToBitmaskWithIntegers(): void
    {
        $result = ConverterUtils::arrayToBitmask([1, 2, 4]);

        $this->assertSame(7, $result);
    }

    public function testArrayToBitmaskWithEmptyArray(): void
    {
        $result = ConverterUtils::arrayToBitmask([]);

        $this->assertSame(0, $result);
    }
}
