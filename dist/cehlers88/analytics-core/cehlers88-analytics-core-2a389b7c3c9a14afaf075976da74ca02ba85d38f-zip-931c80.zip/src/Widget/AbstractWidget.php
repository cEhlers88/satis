<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 19:32
 */

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Analytics\ENUM\eWidgetType;
use Analytics\Interface\IWidget;
use Cehlers88\AnalyticsCore\Entity\User;

abstract class AbstractWidget implements IWidget
{
    public function enrichProperties(array $properties): array
    {
        return $properties;
    }

    public function getTemplateName(): string
    {
        return $this->getName();
    }

    abstract public function getName(): string;

    public function getPreloadPlaceholders(): array
    {
        return [];
    }

    public function getRequiredStartArguments(): array
    {
        return [];
    }

    public function getRequiredRoles(): array
    {
        return [];
    }

    /**
     * Describes what this widget can be configured with, so that the setup tile
     * can ask for those values while the widget type is being picked.
     *
     * The name of a property is the prop its value ends up in, and a property
     * that is not optional is one the widget can not be rendered without.
     *
     * @return PropertyDTO[]
     */
    public function getSettingDefinitions(): array
    {
        return [];
    }

    /**
     * The settings of a tile that already holds the given values. A widget
     * whose settings depend on what was picked - one switch per chart of the
     * picked custom object, say - adds them here; everything else keeps the
     * static ones.
     *
     * @return PropertyDTO[]
     */
    public function getSettingDefinitionsFor(array $values): array
    {
        return $this->getSettingDefinitions();
    }

    /**
     * The props as they are stored, after the settings the widget declares
     * have been normalized (see WidgetSettings::normalize()).
     *
     * A setting whose value is a structure of its own - the sub widgets of a
     * group, say - is passed through by that normalization as it came; this is
     * where the widget reduces such a value to what it accepts.
     */
    public function normalizeProps(array $props): array
    {
        return $props;
    }

    /**
     * Settings the widget insists on that the given props leave unanswered
     * further down than its own mask - the settings of a sub widget, for
     * instance. Reported with a label that says where they belong.
     *
     * @return PropertyDTO[]
     */
    public function findUnsatisfiedNestedSettings(array $props): array
    {
        return [];
    }

    /**
     * Whether this widget can be picked as the type of a dashboard tile.
     *
     * The setup tile itself and widgets that only ever appear inside another
     * one (a login overlay, for instance) say no here.
     */
    public function isSelectable(): bool
    {
        return true;
    }

    public function getWidgetType(): eWidgetType
    {
        return eWidgetType::DASHBOARD;
    }

    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        return WidgetSubmitResultDTO::createError(404, 'Not implemented');
    }
}