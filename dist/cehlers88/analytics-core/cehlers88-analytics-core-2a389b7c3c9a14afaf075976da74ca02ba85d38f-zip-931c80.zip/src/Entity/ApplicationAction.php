<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Cehlers88\AnalyticsCore\Repository\ApplicationActionRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ApplicationActionRepository::class)]
class ApplicationAction
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'actions')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Application $application = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(type: Types::TEXT)]
    private ?string $description = null;

    #[ORM\Column]
    private array $startCommands = [];

    #[ORM\Column]
    private array $stopCommands = [];

    #[ORM\ManyToMany(targetEntity: Category::class, inversedBy: 'applicationActions')]
    private Collection $categories;

    #[ORM\Column]
    private ?bool $autoStop = null;

    #[ORM\Column]
    private ?bool $state = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $symbol = null;

    /**
     * Why the action was started last - given to startAction, empty when no reason was given.
     * Only a start sets it; stopping leaves it, so it still tells why the action ran.
     */
    #[ORM\Column(type: Types::TEXT)]
    private string $reason = '';

    public function __construct()
    {
        $this->categories = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getApplication(): ?Application
    {
        return $this->application;
    }

    public function setApplication(?Application $application): static
    {
        $this->application = $application;

        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getStartCommands(): array
    {
        return $this->startCommands;
    }

    public function setStartCommands(array $startCommands): static
    {
        $this->startCommands = $startCommands;

        return $this;
    }

    public function getStopCommands(): array
    {
        return $this->stopCommands;
    }

    public function setStopCommands(array $stopCommands): static
    {
        $this->stopCommands = $stopCommands;

        return $this;
    }

    /**
     * @return Collection<int, Category>
     */
    public function getCategories(): Collection
    {
        return $this->categories;
    }

    public function addCategory(Category $category): static
    {
        if (!$this->categories->contains($category)) {
            $this->categories->add($category);
        }

        return $this;
    }

    public function removeCategory(Category $category): static
    {
        $this->categories->removeElement($category);

        return $this;
    }

    public function isAutoStop(): ?bool
    {
        return $this->autoStop;
    }

    public function setAutoStop(bool $autoStop): static
    {
        $this->autoStop = $autoStop;

        return $this;
    }

    public function isActive(): ?bool
    {
        return $this->state;
    }

    public function setState(bool $state): static
    {
        $this->state = $state;

        return $this;
    }

    public function getSymbol(): ?string
    {
        return $this->symbol;
    }

    public function setSymbol(?string $symbol): static
    {
        $this->symbol = $symbol;

        return $this;
    }

    public function getReason(): string
    {
        return $this->reason;
    }

    public function setReason(?string $reason): static
    {
        $this->reason = trim((string)$reason);

        return $this;
    }
}
