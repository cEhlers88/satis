<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Macro\Debugger\IMacroDebugger;
use Cehlers88\AnalyticsCore\Macro\Debugger\SilentDebugger;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroEnvironmentDTO;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Player\MacroPlayer;
use Cehlers88\AnalyticsCore\Process\ProcessProvider;
use Cehlers88\AnalyticsCore\Process\Runner\CommandsPlayerProcessRunner;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\ProcessRepository;

class MacroEnvironment
{
    private ?Application $_application = null;
    private int $_lastInstructionId = 0;
    private array $_configurations = [];
    private bool $_simulationMode = false;
    private bool $_protectedMode = false;
    /** @var array<string, array{content: mixed, arguments: list<array<string, mixed>>}> defined by the macro "function" */
    private array $_functions = [];

    public function __construct(
        private ApplicationRepository $applicationRepository,
        private VariablesProvider     $variablesStoreProvider,
        private MacroPlayer           $macroPlayer,
        private CommandPlayer         $commandPlayer,
        private ProcessProvider       $processProvider,
        private ProcessRepository     $processRepository,
        private IMacroDebugger        $_debugger = new SilentDebugger()
    )
    {
        $this->macroPlayer->setMacroEnvironment($this);
        $this->commandPlayer->setMacroEnvironment($this);
        $this->variablesStoreProvider->setMacroEnvironment($this);
        $this->variablesStoreProvider->setReadonly($this->_simulationMode);
    }

    public function getApplication(): ?Application
    {
        return $this->_application;
    }

    public function setApplication(Application $application): MacroEnvironment
    {
        $this->_application = $application;
        return $this;
    }

    public function getConfigurations(): array
    {
        return $this->_configurations;
    }

    public function getDebugger(): IMacroDebugger
    {
        return $this->_debugger;
    }

    public function getVariablesStoreProvider(): VariablesProvider
    {
        return $this->variablesStoreProvider;
    }

    public function getMacroPlayer(): MacroPlayer
    {
        return $this->macroPlayer;
    }

    public function getCommandPlayer(): CommandPlayer
    {
        return $this->commandPlayer;
    }

    /**
     * @param list<array{name: string, type: string, required: bool, default: mixed, command: bool, description: string}> $arguments
     */
    public function defineFunction(string $name, mixed $content, array $arguments = []): MacroEnvironment
    {
        $this->_functions[$name] = ['content' => $content, 'arguments' => $arguments];
        return $this;
    }

    /** @return array{content: mixed, arguments: list<array<string, mixed>>}|null */
    public function getFunction(string $name): ?array
    {
        return $this->_functions[$name] ?? null;
    }

    public function getNextInstructionId(): int
    {
        return ++$this->_lastInstructionId;
    }

    public function getProcessId(): string
    {
        return $this->_configurations['processId'];
    }

    public function getProcessProvider(): ProcessProvider
    {
        return $this->processProvider;
    }

    public function hasValidApplication(): bool
    {
        return !is_null($this->_application);
    }

    /**
     * The protected mode ("abgesicherter Modus"): critical fragments of macros - booking,
     * sending, saving - do not run, the macros answer as if they had
     * (AbstractMacro::runProtectedFragment). Whoever starts a run decides about it, the
     * examples of a command and the command console, for instance. Independent of the
     * simulation mode, which only keeps the variables from being stored.
     */
    public function isProtectedMode(): bool
    {
        return $this->_protectedMode;
    }

    public function setProtectedMode(bool $protectedMode): MacroEnvironment
    {
        $this->_protectedMode = $protectedMode;
        $this->variablesStoreProvider->setReadonly($this->_protectedMode);
        return $this;
    }

    public function isSimulationMode(): bool
    {
        return $this->_simulationMode;
    }

    public function setSimulationMode(bool $simulationMode): MacroEnvironment
    {
        $this->_simulationMode = $simulationMode;
        $this->variablesStoreProvider->setReadonly($simulationMode);
        return $this;
    }

    public function setDebugger(IMacroDebugger $debugger): MacroEnvironment
    {
        $this->_debugger = $debugger;
        return $this;
    }

    public function setVariablesStoreProvider(VariablesProvider $variablesStoreProvider): MacroEnvironment
    {
        $this->variablesStoreProvider = $variablesStoreProvider;
        return $this;
    }

    public function setMacroPlayer(MacroPlayer $macroPlayer): MacroEnvironment
    {
        $this->macroPlayer = $macroPlayer;
        return $this;
    }

    public function setCommandPlayer(CommandPlayer $commandPlayer): MacroEnvironment
    {
        $this->commandPlayer = $commandPlayer;
        return $this;
    }

    public function setExecutorInfos(string $executorName, string $executorIP, string $processId = ''): MacroEnvironment
    {
        $this->_configurations['executor'] = [
            'name' => $executorName,
            'ip' => $executorIP
        ];

        if ($processId === '') {
            $process = $this->processRepository->createNew(
                'MacroExecution',
                'Running MacroExecutor by ' . $executorName,
                CommandsPlayerProcessRunner::class
            );

            $processId = $this->processRepository->save($process)->getId();
        }
        $this->_configurations['processId'] = $processId;

        return $this;
    }

    public function load(MacroEnvironmentDTO $macroEnvironmentDTO): MacroEnvironment
    {
        $this->setApplication($this->applicationRepository->find($macroEnvironmentDTO->applicationId));

        $lastArgumentContext = '';
        foreach ($macroEnvironmentDTO->arguments as $argument) {
            if ($argument->context !== $lastArgumentContext) {
                $this->variablesStoreProvider->startArgumentsContext();
                $lastArgumentContext = $argument->context;
            }
            $this->variablesStoreProvider->setArgument($argument->name, $argument->value);
        }

        foreach ($macroEnvironmentDTO->variables as $variable) {
            $this->variablesStoreProvider->setVariable($variable->context, $variable->name, $variable->value);
        }

        return $this;
    }
}