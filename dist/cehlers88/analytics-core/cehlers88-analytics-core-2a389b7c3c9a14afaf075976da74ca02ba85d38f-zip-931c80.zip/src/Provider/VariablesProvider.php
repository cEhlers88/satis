<?php

namespace Cehlers88\AnalyticsCore\Provider;

use Cehlers88\AnalyticsCore\Support\DTO\ContextNameValueDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Repository\SharedDataRepository;
use Cehlers88\AnalyticsCore\Repository\VariableStoreRepository;
use Exception;

class VariablesProvider
{
    public const GET_VAR_WILDCARD = "*";
    public const UNDEFINED_VAR = ">#_-UNDEFINED-_#<";
    public const CONSTANT_PREFIX = 'CONSTANT.';
    private ?MacroEnvironment $_macroEnvironment = null;
    private int $_loadedApplicationId = 0;
    private array $_variablesStore = [];
    private bool $_readonly = false;

    /**
     * @var ContextNameValueDTO[]
     */
    private array $_argumentsStore = [];
    private string $_argumentsContext = "";
    /** @var list<string> the contexts a started one replaced - a procedure inside a procedure */
    private array $_outerArgumentsContexts = [];
    private $_changeLogger;

    public function __construct(
        private VariableStoreRepository $_variableStoreRepository,
        private SharedDataRepository    $_sharedDataRepository
    )
    {
        $this->_resetStore();
        $this->setChangeLogger(function () {
            // dummy
        });

        $this
            ->loadServerContext()
            ->loadSharedContext();
    }

    private function _resetStore(): void
    {
        $this->_variablesStore = [
            eMacroVariableContext::ENVIRONMENT->name => [],
            eMacroVariableContext::LOCAL->name => [],
            eMacroVariableContext::JOB->name => [],
            eMacroVariableContext::WORKER->name => [],
            eMacroVariableContext::APPLICATION->name => [],
            eMacroVariableContext::SERVER->name => [],
        ];
    }

    public function setChangeLogger(callable $changeLogger): VariablesProvider
    {
        $this->_changeLogger = $changeLogger;
        return $this;
    }

    public function loadSharedContext(): VariablesProvider
    {
        foreach ($this->_sharedDataRepository->findAll() as $sharedData) {
            $this->_variablesStore[eMacroVariableContext::SHARED->name][$sharedData->getName()] = $sharedData->getValue();
        }
        return $this;
    }

    public function loadServerContext(): VariablesProvider
    {
        foreach ($this->_variableStoreRepository->findBy([
            // the enum, not its name: by the name nothing was ever loaded
            'context' => eMacroVariableContext::SERVER
        ]) as $variableStore) {
            $this->_variablesStore[eMacroVariableContext::SERVER->name][$variableStore->getName()] = $variableStore->getValue()[1];
        }
        return $this;
    }

    public function setVariable(string $variableName, mixed $variableValue, eMacroVariableContext|string $context = eMacroVariableContext::ENVIRONMENT): VariablesProvider
    {
        $contextName = (is_string($context) ? $context : $context->name);
        $oldValue = isset($this->_variablesStore[$contextName][$variableName]) ? $this->_variablesStore[$contextName][$variableName] : self::UNDEFINED_VAR;

        $this->_variablesStore[$contextName][$variableName] = $variableValue;

        call_user_func($this->_changeLogger, $variableName, $variableValue, $oldValue, $contextName);
        return $this;
    }

    /**
     * Creates or updates a constant of the current application - the row the configuration
     * stores for it (CONSTANT.<name> in the application context). It is written at once:
     * save() is only called by worker jobs, and a constant set by a procedure must not be
     * lost. In simulation mode (readonly) nothing is written.
     *
     * @throws Exception without an application there is nothing the constant belongs to
     */
    public function setConstant(string $constantName, mixed $value): VariablesProvider
    {
        $application = $this->getApplication();
        if (is_null($application?->getId())) {
            throw new Exception('Constant ' . $constantName . ' can only be set for an application');
        }

        $storedName = str_starts_with($constantName, self::CONSTANT_PREFIX) ? $constantName : self::CONSTANT_PREFIX . $constantName;
        $stored = $this->_variableStoreRepository->getVariableValue($storedName, eMacroVariableContext::APPLICATION, $application, false);
        $oldValue = is_array($stored) ? ($stored[1] ?? null) : self::UNDEFINED_VAR;

        call_user_func($this->_changeLogger, $storedName, $value, $oldValue, eMacroVariableContext::APPLICATION->name);

        if ($this->_readonly) return $this;

        // a constant the configuration masks as a password stays one
        $type = is_array($stored) && ($stored[0] ?? '') === 'password' && is_string($value) ? 'password' : gettype($value);

        $this->_variableStoreRepository->setVariableValue(eMacroVariableContext::APPLICATION, $storedName, [$type, $value], $application);
        $this->_variableStoreRepository->flush();

        return $this;
    }

    public function clearContext(eMacroVariableContext $context): VariablesProvider
    {
        $this->_variableStoreRepository->deleteBy_applicationAndContext(
            $this->getApplication(),
            $context
        );
        return $this;
    }

    public function getApplication(): ?Application
    {
        return is_null($this->_macroEnvironment) ? null : $this->_macroEnvironment->getApplication();
    }

    public function getConstants(?int $applicationIdFilter = null, bool $returnAssoc = false): array
    {
        $repositoryResult = $this->_variableStoreRepository->findAllConstants($applicationIdFilter);
        if (!$returnAssoc) return $repositoryResult;

        $result = [];
        foreach ($repositoryResult as $constant) {
            if (isset($result[$constant->getName()])) {
                throw new Exception('Duplicate constant name: ' . $constant->getName());
            }

            $result[str_replace('CONSTANT.', '', $constant->getName())] = $constant->getValue()[1];
        }
        return $result;
    }

    public function getVariables(eMacroVariableContext|string $context = eMacroVariableContext::ENVIRONMENT): array
    {
        $context = (is_string($context) ? $context : $context->name);

        if (strtolower($context) === 'get') return $_GET;
        if (strtolower($context) === 'post') return $_POST;
        if (strtolower($context) === eMacroVariableContext::ARGUMENT->value) return $this->_argumentsStore;

        return $this->_variablesStore[$context];
    }

    /**
     * @param string $variableName
     * @param eMacroVariableContext $context
     * @param mixed $defaultValue
     * @return mixed
     * @throws Exception
     */
    public function getVariableValue(
        string                       $variableName,
        eMacroVariableContext|string $context = eMacroVariableContext::ENVIRONMENT,
        mixed                        $defaultValue = self::UNDEFINED_VAR
    ): mixed
    {
        $context = (is_string($context) ? $context : $context->name);

        // A transient application (not persisted yet) has no id and therefore no
        // stored application context to load.
        $applicationId = $this->getApplication()?->getId();
        if (is_null($applicationId)) {
            if ($this->_loadedApplicationId !== 0) {
                $this->_variablesStore[eMacroVariableContext::APPLICATION->name] = [];
                $this->_loadedApplicationId = 0;
            }
        } else if ($this->_loadedApplicationId !== $applicationId) {
            $this->loadApplicationContext($applicationId);
            $this->_loadedApplicationId = $applicationId;
        }

        if (strtolower($context) === eMacroVariableContext::ARGUMENT->value) {
            if ($variableName === self::GET_VAR_WILDCARD) return $this->_argumentsStore;
            return $this->getArgument($variableName);
            // ->value, not ->name: the comparison is against a lower-cased context, and
            // "get" never equals "GET"
        } else if (strtolower($context) === eMacroVariableContext::GET->value) {
            if ($variableName === self::GET_VAR_WILDCARD) return $_GET;
            if (isset($_GET[$variableName])) return $_GET[$variableName];
        } else if (strtolower($context) === eMacroVariableContext::POST->value) {
            if ($variableName === self::GET_VAR_WILDCARD) return $_POST;
            if (isset($_POST[$variableName])) return $_POST[$variableName];
        }

        foreach ($this->_variablesStore as $variableContextName => $contextStore) {
            if (strtolower($variableContextName) !== strtolower($context)) {
                continue;
            }

            if ($variableName === self::GET_VAR_WILDCARD) return $contextStore;

            foreach ($contextStore as $index => $storedVariable) {
                if (is_string($index)) {
                    if ($index === $variableName) {
                        return $storedVariable;
                    }
                    continue;
                }
                if ($storedVariable->getName() !== $variableName) {
                    continue;
                }
                return $storedVariable->getValue()[1];
            }
        }

        $argumentValue = $this->getArgument($variableName);
        if ($argumentValue !== self::UNDEFINED_VAR) return $argumentValue;

        if ($defaultValue !== self::UNDEFINED_VAR) return $defaultValue;

        throw new Exception('Variable ' . $context . '/' . $variableName . ' not found');
    }

    public function loadApplicationContext(int $applicationId): VariablesProvider
    {
        $contextData = $this->_variableStoreRepository->findBy([
            'application' => [
                'id' => $applicationId
            ],
            'context' => eMacroVariableContext::APPLICATION
        ]);
        $this->_variablesStore[eMacroVariableContext::APPLICATION->name] = $contextData;
        return $this;
    }

    public function getArgument(string $name, mixed $defaultValue = self::UNDEFINED_VAR): mixed
    {
        for ($i = count($this->_argumentsStore) - 1; $i >= 0; $i--) {
            $argument = $this->_argumentsStore[$i];
            if ($argument->name === $name) return $argument->value;
        }
        return $defaultValue;
    }

    // environment arguments handling start

    public function removeVariable(string $variableName, eMacroVariableContext $context = eMacroVariableContext::ENVIRONMENT): VariablesProvider
    {
        $newVariables = [];

        foreach ($this->_variablesStore[$context->name] as $storedVariableName => $storedVariableValue) {
            if ($storedVariableName !== $variableName) $newVariables[$storedVariableName] = $storedVariableValue;
        }

        $this->_variablesStore[$context->name] = $newVariables;
        return $this;
    }

    public function save(): VariablesProvider
    {
        if ($this->_readonly) return $this;

        $variables = $this->getAllVariables();
        $self = $this;

        $this->_sharedDataRepository->setAutoFlush(false);
        foreach ($variables[eMacroVariableContext::SHARED->name] as $variableName => $variableValue) {
            $this->_sharedDataRepository->set($variableName, $variableValue);
        }
        $this->_sharedDataRepository->flush();

        if ($this->getApplication() === null) return $this; // after this point, an application is required

        array_map(function ($context) use ($variables, $self) {
            foreach ($variables[$context->name] as $variableName => $variableValue) {
                $self->_variableStoreRepository->setVariableValue($context, $variableName, [gettype($variableValue), $variableValue], $this->getApplication());
            }
        }, [
            eMacroVariableContext::SERVER,
            eMacroVariableContext::APPLICATION
        ]);

        return $this;
    }

    public function getAllVariables(): array
    {
        return [
            ...$this->_variablesStore,
            eMacroVariableContext::GET->name => $_GET,
            eMacroVariableContext::POST->name => $_POST
        ];
    }

    /**
     * Arguments set from here on belong to a new context, until clearArgumentsContext() removes
     * them and the one before is current again. Lookups still see the outer arguments, the
     * newest first.
     */
    public function startArgumentsContext(): VariablesProvider
    {
        $this->_outerArgumentsContexts[] = $this->_argumentsContext;
        $this->_argumentsContext = uniqid('', true);
        return $this;
    }

    // environment arguments handling end

    /** Removes the arguments of the current context and returns to the one it replaced. */
    public function clearArgumentsContext(): VariablesProvider
    {
        $context = $this->_argumentsContext;
        // the filtered list used to be thrown away - every argument stayed and shadowed later ones
        $this->_argumentsStore = array_values(array_filter(
            $this->_argumentsStore,
            static fn($argument): bool => $argument->context !== $context
        ));
        $this->_argumentsContext = array_pop($this->_outerArgumentsContexts) ?? '';

        return $this;
    }

    public function setArgument(string $name, mixed $value): VariablesProvider
    {
        $this->_argumentsStore[] = ContextNameValueDTO::create($this->_argumentsContext, $name, $value);

        call_user_func($this->_changeLogger, $name, $value, null, $this->_argumentsContext);

        return $this;
    }

    public function setReadonly(bool $readonly): VariablesProvider
    { // prevent saving variables to database
        $this->_readonly = $readonly;
        return $this;
    }

    public function setMacroEnvironment(MacroEnvironment $macroEnvironment): VariablesProvider
    {
        $this->_macroEnvironment = $macroEnvironment;
        return $this;
    }
}