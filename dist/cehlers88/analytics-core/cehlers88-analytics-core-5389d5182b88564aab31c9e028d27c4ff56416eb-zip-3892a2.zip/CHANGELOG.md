# Changelog

## [0.1.8](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.7...v0.1.8) (2026-01-21)


### Bug Fixes

* initialize default type for AbstractWorkerJob ([aa409b5](https://github.com/cEhlers88/AnalyticsCore/commit/aa409b5b17539a63cb45d73d200f3dabb7efb9b8))

## [0.1.7](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.6...v0.1.7) (2026-01-21)


### Reverts

* fix: prepend 'TEST' to truncated tracking buffer string ([f59b84c](https://github.com/cEhlers88/AnalyticsCore/commit/f59b84cf7411e6b39e73f50cc64ef7fc5a5d4bc0))

## [0.1.6](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.5...v0.1.6) (2026-01-21)


### Bug Fixes

* prepend 'TEST' to truncated tracking buffer string ([5a68758](https://github.com/cEhlers88/AnalyticsCore/commit/5a68758fc4ccd6544fcfec8281b7c8374059fca4))

## [0.1.5](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.4...v0.1.5) (2026-01-21)


### Miscellaneous Chores

* add workflow to trigger Satis rebuild on release publication ([0ecb93e](https://github.com/cEhlers88/AnalyticsCore/commit/0ecb93ea6b9cac9b5dbd0e95e01d734f1bdfa2b5))

## [0.1.4](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.3...v0.1.4) (2026-01-21)


### Bug Fixes

* Update ClientPermission `permkeys` field type from ARRAY to JSON ([bddfd5e](https://github.com/cEhlers88/AnalyticsCore/commit/bddfd5e267cfec90fdd9624fbb9f054d77ef3102))
* Update service bindings to use `!tagged_iterator` for tagged services ([faf2a03](https://github.com/cEhlers88/AnalyticsCore/commit/faf2a03bb969fac99b2c79e326a7fd031be047d1))

## [0.1.3](https://github.com/cEhlers88/AnalyticsCore/compare/v0.1.2...v0.1.3) (2026-01-20)


### Miscellaneous Chores

* add release-please.yml ([8438a59](https://github.com/cEhlers88/AnalyticsCore/commit/8438a594eb4f9afcfd600fa0ae51d90e88fb76b6))
