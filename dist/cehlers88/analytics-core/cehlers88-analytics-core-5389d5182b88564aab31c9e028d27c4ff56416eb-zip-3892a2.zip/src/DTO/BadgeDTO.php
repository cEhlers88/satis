<?php

namespace Cehlers88\AnalyticsCore\DTO;

class BadgeDTO extends DTO
{
    public string $name = '';
    public string $label = '';
    public string $color = '#000000';
    public string $cssClass = '';

    public static function createSuccess(string $label): BadgeDTO
    {
        return self::create($label, '#008000', 'badge-success');
    }

    public static function create(string $label, string $color, string $cssClass = ''): BadgeDTO
    {
        $dto = new self();
        $dto->label = $label;
        $dto->name = str_replace(' ', '_', strtolower($label));
        $dto->cssClass = $cssClass;
        $dto->color = $color;
        return $dto;
    }

    public static function createWarning(string $label): BadgeDTO
    {
        return self::create($label, '#ff8000', 'badge-warning');
    }

    public static function createError(string $label): BadgeDTO
    {
        return self::create($label, '#ff0000', 'badge-error');
    }
}