<?php

namespace Cehlers88\AnalyticsCore\Entity;

use Analytics\Entity\AnalyticsHeader;
use Analytics\Repository\ClientRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ClientRepository::class)]
class Client extends AbstractEntity
{
    #[ORM\Column(length: 40)]
    private ?string $ip = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $first_visit = null;

    #[ORM\OneToMany(targetEntity: AnalyticsHeader::class, mappedBy: 'client')]
    private Collection $analyticsHeaders;

    #[ORM\OneToMany(targetEntity: ClientDetails::class, mappedBy: 'client', cascade: ['persist', 'remove'])]
    private Collection $clientDetails;

    #[ORM\ManyToMany(targetEntity: ClientPermission::class, inversedBy: 'clients')]
    private Collection $permissions;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $hostname = null;

    #[ORM\Column(length: 30, nullable: true)]
    private ?string $mac = null;

    public function __construct()
    {
        parent::__construct();
        $this->analyticsHeaders = new ArrayCollection();
        $this->clientDetails = new ArrayCollection();
        $this->permissions = new ArrayCollection();
    }

    public function getIp(): ?string
    {
        return $this->ip;
    }

    public function setIp(string $ip): static
    {
        $this->ip = $ip;

        return $this;
    }

    public function getFirstVisit(): ?\DateTimeInterface
    {
        return $this->first_visit;
    }

    public function setFirstVisit(\DateTimeInterface $first_visit): static
    {
        $this->first_visit = $first_visit;

        return $this;
    }

    /**
     * @return Collection<int, AnalyticsHeader>
     */
    public function getAnalyticsHeaders(): Collection
    {
        return $this->analyticsHeaders;
    }

    public function addAnalyticsHeader(AnalyticsHeader $analyticsHeader): static
    {
        if (!$this->analyticsHeaders->contains($analyticsHeader)) {
            $this->analyticsHeaders->add($analyticsHeader);
            $analyticsHeader->setClient($this);
        }

        return $this;
    }

    public function removeAnalyticsHeader(AnalyticsHeader $analyticsHeader): static
    {
        if ($this->analyticsHeaders->removeElement($analyticsHeader)) {
            // set the owning side to null (unless already changed)
            if ($analyticsHeader->getClient() === $this) {
                $analyticsHeader->setClient(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, ClientDetails>
     */
    public function getClientDetails(): Collection
    {
        return $this->clientDetails;
    }

    public function addClientDetail(ClientDetails $clientDetail): static
    {
        if (!$this->clientDetails->contains($clientDetail)) {
            $this->clientDetails->add($clientDetail);
            $clientDetail->setClient($this);
        }

        return $this;
    }

    public function removeClientDetail(ClientDetails $clientDetail): static
    {
        if ($this->clientDetails->removeElement($clientDetail)) {
            // set the owning side to null (unless already changed)
            if ($clientDetail->getClient() === $this) {
                $clientDetail->setClient(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, ClientPermission>
     */
    public function getPermissions(): Collection
    {
        return $this->permissions;
    }

    public function addPermission(ClientPermission $permission): static
    {
        if (!$this->permissions->contains($permission)) {
            $this->permissions->add($permission);
        }

        return $this;
    }

    public function removePermission(ClientPermission $permission): static
    {
        $this->permissions->removeElement($permission);

        return $this;
    }

    public function getHostname(): ?string
    {
        return $this->hostname;
    }

    public function setHostname(?string $hostname): static
    {
        $this->hostname = $hostname;

        return $this;
    }

    public function getMac(): ?string
    {
        return $this->mac;
    }

    public function setMac(?string $mac): static
    {
        $this->mac = $mac;

        return $this;
    }
}
