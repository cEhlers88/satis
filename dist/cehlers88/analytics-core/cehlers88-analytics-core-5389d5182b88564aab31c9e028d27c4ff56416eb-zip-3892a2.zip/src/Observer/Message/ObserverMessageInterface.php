<?php

namespace Cehlers88\AnalyticsCore\Observer\Message;

interface ObserverMessageInterface
{
    public function getKey(): string;
}