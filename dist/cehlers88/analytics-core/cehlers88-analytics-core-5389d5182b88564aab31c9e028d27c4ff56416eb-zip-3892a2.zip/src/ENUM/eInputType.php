<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.01.2026
 * Time: 07:25
 */

namespace Cehlers88\AnalyticsCore\ENUM;
enum eInputType: string
{
    case TEXT_SINGLE_LINE = 'TEXT_SINGLE_LINE';
    case TEXT_MULTI_LINE = 'TEXT_MULTI_LINE';
    case NUMBER = 'NUMBER';
    case DATE = 'DATE';
    case TIME = 'TIME';
    case DATE_TIME = 'DATE_TIME';
    case SELECT = 'SELECT';
    case CHECKBOX = 'CHECKBOX';
    case RADIO = 'RADIO';
    case FILE = 'FILE';
    case BOOLEAN = 'BOOLEAN';
    case PASSWORD = 'PASSWORD';
    case EMAIL = 'EMAIL';
    case URL = 'URL';
    case COLOR = 'COLOR';
    case RANGE = 'RANGE';
    case REPEAT = 'REPEAT';
    case UNIQUE_ID = 'UNIQUE_ID';

    public static function fromString(string $value): eInputType
    {
        return match ($value) {
            'TEXT_SINGLE_LINE' => self::TEXT_SINGLE_LINE,
            'TEXT_MULTI_LINE' => self::TEXT_MULTI_LINE,
            'NUMBER' => self::NUMBER,
            'DATE' => self::DATE,
            'TIME' => self::TIME,
            'DATE_TIME' => self::DATE_TIME,
            'SELECT' => self::SELECT,
            'CHECKBOX' => self::CHECKBOX,
            'RADIO' => self::RADIO,
            'FILE' => self::FILE,
            'BOOLEAN' => self::BOOLEAN,
            'PASSWORD' => self::PASSWORD,
            'EMAIL' => self::EMAIL,
            'URL' => self::URL,
            'COLOR' => self::COLOR,
            'RANGE' => self::RANGE,
            'REPEAT' => self::REPEAT,
            'UNIQUE_ID' => self::UNIQUE_ID,
        };
    }
}