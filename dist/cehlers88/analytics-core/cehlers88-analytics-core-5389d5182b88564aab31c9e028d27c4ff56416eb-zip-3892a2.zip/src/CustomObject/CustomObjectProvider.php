<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:40
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Repository\CustomEntityRepository;

class CustomObjectProvider
{
    public function __construct(
        private iterable               $customEntityClasses,
        private CustomEntityRepository $customEntityRepository
    )
    {
    }

    /**
     * @param CustomObjectInterface $customEntity
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClass(CustomObjectInterface $customEntity): array
    {
        return $this->getCustomEntitiesByClassName($customEntity->getClassName());
    }

    /**
     * @param string $className
     * @return CustomObjectInterface[]|null
     */
    public function getCustomEntitiesByClassName(string $className): array
    {
        $customEntities = [];
        foreach ($this->customEntityRepository->findBy(['className' => $className]) as $customEntity) {
            $customEntities[] = $this->resolveCustomEntity($customEntity);
        }
        return $customEntities;
    }

    public function resolveCustomEntity(CustomEntity $customEntity): CustomObjectInterface
    {
        $className = $customEntity->getClassName();
        $instance = new $className();
        $instance->setName($customEntity->getName());
        foreach ($customEntity->getAttributes() as $attribute) {
            $instance->setAttribute($attribute->getName(), $attribute->getValue());
        }
        return $instance;
    }

    public function getCustomClasses(): iterable
    {
        return $this->customEntityClasses;
    }
}