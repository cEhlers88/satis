<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.01.2026
 * Time: 12:19
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

interface CustomObjectInterface
{
    public function getClassName(): string;

    public function getName(): string;

    public function getAttribute(string $name, mixed $defaultValue = null): mixed;

    public function getAttributes(): array;

    public function getId(): int;

    public function setAttribute(string $name, mixed $value): CustomObjectInterface;

    public function setId(int $id): CustomObjectInterface;
}