<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

class VoidResultWorker extends AbstractProcessResultWorker
{
    public function handleResult(mixed $result): static
    {
        return $this;
    }

}