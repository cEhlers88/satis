<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Service;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

/** Service providing badges based on entity states. */
class BadgeProvider
{
    /**
     * @param eRunningState[] $eRunningStates
     * @return BadgeDTO[]
     */
    public function getBadgesByRunningStates(array $eRunningStates): array
    {
        $buffer = [];

        foreach ($eRunningStates as $state) {
            switch ($state) {
                case eRunningState::Error:
                    $buffer[] = BadgeDTO::create('Error', '#b64654');
                    break;
                case eRunningState::New:
                    $buffer[] = BadgeDTO::create('New', '#ddc010');
                    break;
                case eRunningState::WillStart:
                    $buffer[] = BadgeDTO::create('Will start', '#c7820f');
                    break;
                case eRunningState::Warning:
                    $buffer[] = BadgeDTO::create('Warning', '#a66e24');
                    break;
                case eRunningState::NoWork:
                    $buffer[] = BadgeDTO::create('No work', '#a476de');
                    break;
                case eRunningState::Finished:
                    $buffer[] = BadgeDTO::create('Finished', '#4687b6');
                    break;

                default:
                    $buffer[] = BadgeDTO::create($state->name, '#999999');
                    break;
            }
        }

        return $buffer;
    }
}