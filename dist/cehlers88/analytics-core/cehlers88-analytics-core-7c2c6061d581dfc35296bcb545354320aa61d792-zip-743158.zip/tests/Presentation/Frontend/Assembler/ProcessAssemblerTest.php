<?php

namespace Cehlers88\AnalyticsCore\Tests\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\ProcessAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ProcessView;
use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Process\DTO\ResultWorkerDefinitionDTO;
use Cehlers88\AnalyticsCore\Process\DTO\StartInfoDTO;
use PHPUnit\Framework\TestCase;

class ProcessAssemblerTest extends TestCase
{
    public function testOneWithNullDetailsDoesNotThrow(): void
    {
        $process = $this->createMock(Process::class);
        $process->method('getId')->willReturn(1);
        $process->method('getName')->willReturn('MyProcess');
        $process->method('getStartInfo')->willReturn(null);
        $process->method('getResultWorkerDefinition')->willReturn(null);
        $process->method('getState')->willReturn([eRunningState::New]);

        $assembler = new ProcessAssembler();
        $view = $assembler->one($process);

        $this->assertInstanceOf(ProcessView::class, $view);
        $this->assertSame(1, $view->id);
        $this->assertSame('MyProcess', $view->name);
        $this->assertSame('', $view->resultWorkerName);
        $this->assertSame('', $view->runnerName);
    }

    public function testOneWithDetailsPopulatesRunnerAndResultWorker(): void
    {
        $startInfo = StartInfoDTO::create('MyRunner');
        $resultWorker = ResultWorkerDefinitionDTO::create('MyResultWorker');

        $process = $this->createMock(Process::class);
        $process->method('getId')->willReturn(2);
        $process->method('getName')->willReturn('AnotherProcess');
        $process->method('getStartInfo')->willReturn($startInfo);
        $process->method('getResultWorkerDefinition')->willReturn($resultWorker);
        $process->method('getState')->willReturn([eRunningState::Running]);

        $assembler = new ProcessAssembler();
        $view = $assembler->one($process);

        $this->assertSame('MyRunner', $view->runnerName);
        $this->assertSame('MyResultWorker', $view->resultWorkerName);
    }

    public function testOneSetsStateAndQuickInfo(): void
    {
        $process = $this->createMock(Process::class);
        $process->method('getId')->willReturn(3);
        $process->method('getName')->willReturn('ThirdProcess');
        $process->method('getStartInfo')->willReturn(null);
        $process->method('getResultWorkerDefinition')->willReturn(null);
        $process->method('getState')->willReturn([eRunningState::Running]);
        $process->method('hasState')->willReturnCallback(
            fn(eRunningState $s) => $s === eRunningState::Running
        );

        $assembler = new ProcessAssembler();
        $view = $assembler->one($process);

        $this->assertContains(eRunningState::Running, $view->state);
        $this->assertNotNull($view->quickInfo);
    }
}
