<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;

/** View representation of a RunChain entity. */
class RunChainView implements ViewInterface
{
    /** @var eRunningState[] */
    public array $status = [];
    public string $stateString = '';

    public function __construct(
        public int     $id,
        public string  $name,
        public ?string $description,
        public string  $color,
        public ?int    $maxRuntime,
    )
    {
    }
}
