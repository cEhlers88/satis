<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\DefaultView;

class DefaultAssembler extends AbstractAssembler
{
    public function one(EntityInterface $entity): DefaultView
    {
        return new DefaultView();
    }

    public function canHandle(string $className): bool
    {
        return false;
    }
}