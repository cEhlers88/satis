<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Entity\RunChain;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\RunChainView;

/** Assembler for converting RunChain entities to views. */
class RunChainAssembler extends AbstractAssembler
{
    /**
     * @param RunChain $entity
     */
    public function one(EntityInterface $entity): RunChainView
    {
        $status = $entity->getStatus() ?? [];

        $view = new RunChainView(
            id: $entity->getId(),
            name: $entity->getName(),
            description: $entity->getDescription(),
            color: $entity->getColor(),
            maxRuntime: $entity->getMaxRuntime(),
        );

        $view->status = $status;
        $view->stateString = implode(',', array_map(fn($state) => $state->name, $status));

        return $view;
    }

    public function canHandle(string $className): bool
    {
        return $className === RunChain::class;
    }
}
