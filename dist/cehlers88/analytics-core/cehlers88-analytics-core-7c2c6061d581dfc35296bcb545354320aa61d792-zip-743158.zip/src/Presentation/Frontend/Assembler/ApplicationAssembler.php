<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ApplicationView;


/** Assembler for converting Application entities to views. */
class ApplicationAssembler extends AbstractAssembler
{
    /**
     * @param Application $entity
     */
    public function one(EntityInterface $entity): ApplicationView
    {
        $buffer = new ApplicationView(
            id: $entity->getId(),
            name: $entity->getName(),
            color: $entity->getColor(),
        );

        $buffer->badge = BadgeDTO::create(
            $entity->getName(),
            $entity->getColor()
        );

        return $buffer;
    }

    public function canHandle(string $className): bool
    {
        return $className === Application::class;
    }
}