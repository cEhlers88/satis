<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Entity\Tag;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\TagView;

/** Assembler for converting Tag entities to views. */
class TagAssembler extends AbstractAssembler
{
    /**
     * @param Tag $entity
     */
    public function one(EntityInterface $entity): TagView
    {
        return new TagView(
            id: $entity->getId(),
            name: $entity->getName(),
            color: $entity->getColor(),
        );
    }

    public function canHandle(string $className): bool
    {
        return $className === Tag::class;
    }
}
