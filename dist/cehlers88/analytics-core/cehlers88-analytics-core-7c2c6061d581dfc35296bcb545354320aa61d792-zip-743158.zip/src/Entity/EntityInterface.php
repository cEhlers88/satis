<?php

namespace Cehlers88\AnalyticsCore\Entity;

/**
 * Interface for all entity classes.
 */
interface EntityInterface
{

}