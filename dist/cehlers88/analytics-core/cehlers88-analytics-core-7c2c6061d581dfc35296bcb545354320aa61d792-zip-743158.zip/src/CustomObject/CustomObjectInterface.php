<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 14.01.2026
 * Time: 12:19
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

/** Interface for custom objects. */
interface CustomObjectInterface
{
    /** Get the fully qualified class name. */
    public function getClassName(): string;

    /** Get the object name. */
    public function getName(): string;

    /**
     * @param string $name Attribute name.
     * @param mixed $defaultValue Value returned when attribute is not set.
     * @return mixed
     */
    public function getAttribute(string $name, mixed $defaultValue = null): mixed;

    /** Get all attributes. */
    public function getAttributes(): array;

    /** Get the object ID. */
    public function getId(): int;

    /**
     * @param string $name Attribute name.
     * @param mixed $value Attribute value.
     */
    public function setAttribute(string $name, mixed $value): CustomObjectInterface;

    /** Set the object ID. */
    public function setId(int $id): CustomObjectInterface;
}