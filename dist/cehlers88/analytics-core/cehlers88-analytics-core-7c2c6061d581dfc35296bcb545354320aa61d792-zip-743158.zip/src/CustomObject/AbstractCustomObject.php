<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:21
 */

namespace Cehlers88\AnalyticsCore\CustomObject;

/** Base class for custom object implementations. */
abstract class AbstractCustomObject implements CustomObjectInterface
{
    private int $_id = -1;
    private array $_attributes = [];
    private string $_name = '';

    /** Get the fully qualified class name. */
    public function getClassName(): string
    {
        return get_class($this);
    }

    /** Get the object name. */
    public function getName(): string
    {
        return $this->_name;
    }

    /** Set the object name. */
    public function setName(string $name): self
    {
        $this->_name = $name;
        return $this;
    }

    /**
     * @param string $name Attribute name.
     * @param mixed $defaultValue Value returned when attribute is not set.
     * @return mixed
     */
    public function getAttribute(string $name, mixed $defaultValue = null): mixed
    {
        return $this->_attributes[$name] ?? $defaultValue;
    }

    /** Get all attributes. */
    public function getAttributes(): array
    {
        return $this->_attributes;
    }

    /** Get the object ID. */
    public function getId(): int
    {
        return $this->_id;
    }

    /** Set the object ID. */
    public function setId(int $id): self
    {
        $this->_id = $id;
        return $this;
    }

    /**
     * @param string $name Attribute name.
     * @param mixed $value Attribute value.
     */
    public function setAttribute(string $name, mixed $value): self
    {
        $this->_attributes[$name] = $value;
        return $this;
    }
}