<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 31.08.2024
 * Time: 23:50
 */

namespace Analytics\ServerSideRenderer;

class DashboardTileServerSideRenderer extends AbstractServerSideRenderer {
    public function getKey(): string {
        return 'dashboard-tile';
    }

    public function render(): string {
        return $this->getDataValue('content', '');
    }
}
