<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 31.08.2024
 * Time: 23:50
 */

namespace Analytics\ServerSideRenderer;

class DiagramServerSideRenderer extends AbstractServerSideRenderer
{
    public function getKey(): string
    {
        return 'diagram';
    }

    public function render(): string
    {
        return '<canvas-diagram id="test" value="[[1,2],[11,12]]"></canvas-diagram>';
    }
}
