<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 31.08.2024
 * Time: 23:50
 */

namespace Analytics\ServerSideRenderer;

class DefaultServerSideRenderer extends AbstractServerSideRenderer {
    public function getKey(): string {
        return 'default';
    }

    public function render(): string {
        return '<div>hgfg</div>';
    }
}
