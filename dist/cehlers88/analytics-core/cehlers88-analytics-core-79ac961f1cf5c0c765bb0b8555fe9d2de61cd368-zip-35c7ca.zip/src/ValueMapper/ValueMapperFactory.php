<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper;

use Cehlers88\AnalyticsCore\ValueMapper\Condition\AllOfCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\AnyOfCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\ConditionInterface;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\HeaderCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\NotCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\PathEqualsCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\PathExistsCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\PathMatchesCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Condition\StatusCondition;
use Cehlers88\AnalyticsCore\ValueMapper\Transformer\CastTransformer;
use Cehlers88\AnalyticsCore\ValueMapper\Transformer\DateTransformer;
use Cehlers88\AnalyticsCore\ValueMapper\Transformer\MapTransformer;
use Cehlers88\AnalyticsCore\ValueMapper\Transformer\TransformerInterface;
use Cehlers88\AnalyticsCore\ValueMapper\Transformer\TrimTransformer;

/**
 * Builds value mappers from plain arrays, the form in which definitions are
 * stored (JSON) and edited:
 *
 * ```
 * [
 *   'name' => 'ok_v2',
 *   'priority' => 10,
 *   'conditions' => [
 *     ['type' => 'status', 'value' => '2xx'],
 *     ['type' => 'pathExists', 'path' => 'data.items'],
 *   ],
 *   'rules' => [
 *     ['target' => 'items', 'source' => 'data.items', 'required' => true],
 *     ['target' => 'total', 'source' => 'data.meta.total', 'default' => 0,
 *      'transforms' => [['type' => 'cast', 'to' => 'int']]],
 *     ['target' => 'source', 'const' => 'v2'],
 *   ],
 *   'exclude' => ['items.*.internal'],
 * ]
 * ```
 *
 * Invalid definitions fail here with an InvalidArgumentException rather than
 * later while mapping. Further condition and transformer types can be added
 * with registerCondition() / registerTransformer().
 */
final class ValueMapperFactory
{
    /** @var array<string, callable(array<string, mixed>, self): ConditionInterface> */
    private array $conditionBuilders = [];
    /** @var array<string, callable(array<string, mixed>, self): TransformerInterface> */
    private array $transformerBuilders = [];

    public function __construct()
    {
        $this
            ->registerCondition('status', static fn(array $c) => new StatusCondition(self::requireStatusPatterns($c)))
            ->registerCondition('pathExists', static fn(array $c) => new PathExistsCondition(self::requireString($c, 'path', 'pathExists')))
            ->registerCondition('pathEquals', static fn(array $c) => new PathEqualsCondition(
                self::requireString($c, 'path', 'pathEquals'),
                self::require($c, 'value', 'pathEquals'),
                (bool)($c['strict'] ?? false)
            ))
            ->registerCondition('pathMatches', static fn(array $c) => new PathMatchesCondition(
                self::requireString($c, 'path', 'pathMatches'),
                self::requireString($c, 'pattern', 'pathMatches')
            ))
            ->registerCondition('header', static fn(array $c) => new HeaderCondition(
                self::requireString($c, 'name', 'header'),
                self::optionalString($c, 'value', 'header')
            ))
            ->registerCondition('allOf', static fn(array $c, self $f) => new AllOfCondition(...$f->createConditions(self::requireList($c, 'conditions', 'allOf'))))
            ->registerCondition('anyOf', static fn(array $c, self $f) => new AnyOfCondition(...$f->createConditions(self::requireList($c, 'conditions', 'anyOf'))))
            ->registerCondition('not', static fn(array $c, self $f) => new NotCondition($f->createCondition(self::requireArray($c, 'condition', 'not'))));

        $this
            ->registerTransformer('cast', static fn(array $t) => new CastTransformer(self::requireString($t, 'to', 'cast')))
            ->registerTransformer('trim', static fn(array $t) => self::optionalString($t, 'characters', 'trim') !== null
                ? new TrimTransformer(self::optionalString($t, 'characters', 'trim'))
                : new TrimTransformer())
            ->registerTransformer('map', static fn(array $t) => new MapTransformer(
                self::requireArray($t, 'map', 'map'),
                array_key_exists('default', $t),
                $t['default'] ?? null
            ))
            ->registerTransformer('date', static fn(array $t) => new DateTransformer(
                self::optionalString($t, 'from', 'date'),
                self::optionalString($t, 'to', 'date') ?? \DateTimeInterface::ATOM,
                self::optionalString($t, 'timezone', 'date')
            ));
    }

    /**
     * @param callable(array<string, mixed>, self): ConditionInterface $builder
     */
    public function registerCondition(string $type, callable $builder): static
    {
        $this->conditionBuilders[$type] = $builder;

        return $this;
    }

    /**
     * @param callable(array<string, mixed>, self): TransformerInterface $builder
     */
    public function registerTransformer(string $type, callable $builder): static
    {
        $this->transformerBuilders[$type] = $builder;

        return $this;
    }

    /**
     * @param array<int, array<string, mixed>> $definitions
     */
    public function createMapper(array $definitions): ValueMapper
    {
        $mapper = new ValueMapper();
        foreach (array_values($definitions) as $index => $definition) {
            if (!is_array($definition)) {
                throw new \InvalidArgumentException(sprintf('Definition #%d must be an array.', $index));
            }
            $mapper->addDefinition($this->createDefinition($definition, '#' . $index));
        }

        return $mapper;
    }

    /**
     * @param array<string, mixed> $definition
     */
    public function createDefinition(array $definition, string $fallbackName = 'definition'): ValueMapperDefinition
    {
        $name = isset($definition['name']) && $definition['name'] !== '' ? (string)$definition['name'] : $fallbackName;

        try {
            $conditions = $this->createConditions(self::optionalList($definition, 'conditions', 'definition'));
            $rules = array_map($this->createRule(...), self::optionalList($definition, 'rules', 'definition'));
            $exclude = array_map(self::excludePath(...), self::optionalList($definition, 'exclude', 'definition'));
        } catch (\InvalidArgumentException $e) {
            throw new \InvalidArgumentException(sprintf('Definition "%s": %s', $name, $e->getMessage()), 0, $e);
        }

        $priority = $definition['priority'] ?? 0;
        if (!is_int($priority) && !(is_string($priority) && preg_match('/^-?\d+$/', $priority))) {
            throw new \InvalidArgumentException(sprintf('Definition "%s": "priority" must be an integer.', $name));
        }

        return new ValueMapperDefinition($name, $conditions, $rules, (int)$priority, $exclude);
    }

    /**
     * @param array<string, mixed> $condition
     */
    public function createCondition(array $condition): ConditionInterface
    {
        $type = self::requireString($condition, 'type', 'condition');
        if (!isset($this->conditionBuilders[$type])) {
            throw new \InvalidArgumentException(sprintf('Unknown condition type "%s".', $type));
        }

        return $this->build($this->conditionBuilders[$type], $condition, $type);
    }

    /**
     * @param array<int, mixed> $conditions
     * @return ConditionInterface[]
     */
    public function createConditions(array $conditions): array
    {
        return array_map(function (mixed $condition): ConditionInterface {
            if (!is_array($condition)) {
                throw new \InvalidArgumentException('A condition must be an array.');
            }

            return $this->createCondition($condition);
        }, array_values($conditions));
    }

    /**
     * @param array<string, mixed>|string $transformer a configuration, or just the type
     */
    public function createTransformer(array|string $transformer): TransformerInterface
    {
        if (is_string($transformer)) {
            $transformer = ['type' => $transformer];
        }

        $type = self::requireString($transformer, 'type', 'transformer');
        if (!isset($this->transformerBuilders[$type])) {
            throw new \InvalidArgumentException(sprintf('Unknown transformer type "%s".', $type));
        }

        return $this->build($this->transformerBuilders[$type], $transformer, $type);
    }

    public function createRule(mixed $rule): MappingRule
    {
        if (!is_array($rule)) {
            throw new \InvalidArgumentException('A rule must be an array.');
        }

        $target = $rule['target'] ?? null;
        if (!is_string($target)) {
            throw new \InvalidArgumentException('A rule needs a "target" (use "" for the whole value).');
        }
        if (PathAccessor::containsWildcard($target)) {
            throw new \InvalidArgumentException(sprintf('Rule "%s": a target must not contain "*".', $target));
        }

        $hasSource = array_key_exists('source', $rule);
        $hasConstant = array_key_exists('const', $rule);
        if ($hasSource === $hasConstant) {
            throw new \InvalidArgumentException(sprintf('Rule "%s" needs either "source" or "const".', $target));
        }

        if ($hasConstant) {
            return MappingRule::constant($target, $rule['const']);
        }

        if (!is_string($rule['source'])) {
            throw new \InvalidArgumentException(sprintf('Rule "%s": "source" must be a string.', $target));
        }

        $transforms = self::optionalList($rule, 'transforms', sprintf('rule "%s"', $target));

        return MappingRule::fromSource(
            $target,
            $rule['source'],
            array_map($this->createTransformer(...), $transforms),
            (bool)($rule['required'] ?? false),
            array_key_exists('default', $rule),
            $rule['default'] ?? null
        );
    }

    /**
     * Runs a builder. An option of the wrong type that reaches a typed
     * constructor is still an invalid definition, not a programming error,
     * so callers only ever have to handle InvalidArgumentException.
     */
    private function build(callable $builder, array $config, string $type): object
    {
        try {
            return $builder($config, $this);
        } catch (\TypeError $e) {
            throw new \InvalidArgumentException(sprintf('Invalid options for "%s": %s', $type, $e->getMessage()), 0, $e);
        }
    }

    private static function excludePath(mixed $path): string
    {
        if (!is_string($path) || trim($path) === '') {
            throw new \InvalidArgumentException('"exclude" must be a list of non-empty paths.');
        }

        return $path;
    }

    /**
     * @return int|string|array<int|string>
     */
    private static function requireStatusPatterns(array $config): int|string|array
    {
        $value = self::require($config, 'value', 'status');
        $patterns = is_array($value) ? $value : [$value];

        if ($patterns === []) {
            throw new \InvalidArgumentException('"status": "value" must not be empty.');
        }
        foreach ($patterns as $pattern) {
            if (!is_int($pattern) && !is_string($pattern)) {
                throw new \InvalidArgumentException(sprintf('"status": "value" must be a status pattern or a list of them, got %s.', get_debug_type($pattern)));
            }
        }

        return $value;
    }

    private static function optionalString(array $config, string $key, string $context): ?string
    {
        $value = $config[$key] ?? null;
        if ($value === null) {
            return null;
        }
        if (!is_string($value) && !is_int($value) && !is_float($value)) {
            throw new \InvalidArgumentException(sprintf('"%s": "%s" must be a string.', $context, $key));
        }

        return (string)$value;
    }

    private static function require(array $config, string $key, string $context): mixed
    {
        if (!array_key_exists($key, $config)) {
            throw new \InvalidArgumentException(sprintf('"%s" needs "%s".', $context, $key));
        }

        return $config[$key];
    }

    private static function requireString(array $config, string $key, string $context): string
    {
        $value = self::require($config, $key, $context);
        if (!is_string($value) || $value === '') {
            throw new \InvalidArgumentException(sprintf('"%s": "%s" must be a non-empty string.', $context, $key));
        }

        return $value;
    }

    private static function requireArray(array $config, string $key, string $context): array
    {
        $value = self::require($config, $key, $context);
        if (!is_array($value)) {
            throw new \InvalidArgumentException(sprintf('"%s": "%s" must be an array.', $context, $key));
        }

        return $value;
    }

    private static function requireList(array $config, string $key, string $context): array
    {
        return array_values(self::requireArray($config, $key, $context));
    }

    private static function optionalList(array $config, string $key, string $context): array
    {
        return array_key_exists($key, $config) ? self::requireList($config, $key, $context) : [];
    }
}
