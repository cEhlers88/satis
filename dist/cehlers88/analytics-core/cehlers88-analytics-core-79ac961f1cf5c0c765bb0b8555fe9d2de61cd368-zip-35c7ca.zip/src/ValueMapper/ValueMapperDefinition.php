<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCore\ValueMapper;

use Cehlers88\AnalyticsCore\ValueMapper\Condition\ConditionInterface;

/**
 * One expected shape of a value: the conditions under which it applies (all
 * must match; none means always), the rules that build the mapped value and
 * the paths cut out of it afterwards.
 */
final readonly class ValueMapperDefinition
{
    /** @var ConditionInterface[] */
    public array $conditions;
    /** @var MappingRule[] */
    public array $rules;
    /** @var string[] */
    public array $exclude;

    /**
     * @param ConditionInterface[] $conditions
     * @param MappingRule[] $rules
     * @param string[] $exclude paths removed from the mapped value after the rules ran
     */
    public function __construct(
        public string $name,
        array         $conditions = [],
        array         $rules = [],
        public int    $priority = 0,
        array         $exclude = [],
    )
    {
        $this->conditions = array_values($conditions);
        $this->rules = array_values($rules);
        $this->exclude = array_values($exclude);
    }

    public function matches(MappingSubject $subject): bool
    {
        foreach ($this->conditions as $condition) {
            if (!$condition->matches($subject)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Applies every rule, even after one failed, so the result names all
     * deviations at once and still carries what could be mapped.
     */
    public function apply(MappingSubject $subject): ValueMapperResultDTO
    {
        $data = [];
        $errors = [];

        foreach ($this->rules as $rule) {
            try {
                [$set, $value] = $rule->resolve($subject);
            } catch (ValueMapperException $e) {
                $errors[] = sprintf('%s: %s', $rule->target === '' ? '(root)' : $rule->target, $e->getMessage());
                continue;
            }

            if ($set) {
                $data = PathAccessor::set($data, $rule->target, $value);
            }
        }

        // After the rules, so a rule passing on the whole body ("" → "") can
        // still drop the fields nobody needs.
        foreach ($this->exclude as $path) {
            $data = PathAccessor::remove($data, $path);
        }

        return new ValueMapperResultDTO($data, $this->name, $subject, $errors);
    }
}
