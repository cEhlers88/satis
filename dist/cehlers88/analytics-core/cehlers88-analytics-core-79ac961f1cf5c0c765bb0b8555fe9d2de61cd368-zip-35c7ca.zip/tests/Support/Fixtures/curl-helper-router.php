<?php

// Router for the built-in web server CurlHelperTest starts: /status/<code> answers
// with that status, a JSON body (naming the method and echoing the request body) and a repeated header.
if (!preg_match('#^/status/(\d{3})$#', parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), $matches)) {
    http_response_code(400);
    return;
}

http_response_code((int)$matches[1]);
header('Content-Type: application/json');
header('X-Api-Version: 1');
header('X-Api-Version: 2', false);
header('X-Method: ' . $_SERVER['REQUEST_METHOD']);
$body = ['status' => (int)$matches[1]];
$input = file_get_contents('php://input');
if ($input !== '') {
    $body['method'] = $_SERVER['REQUEST_METHOD'];
    $body['input'] = json_decode($input, true);
}
echo json_encode($body);
