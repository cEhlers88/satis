<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Analytics\Entity\SystemLog;
use Analytics\Repository\SystemLogRepository;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionClauseDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;

class WorkersViewWidget extends AbstractWidget
{
    public function __construct()
    {

    }

    public function getName(): string
    {
        return 'AnalyticsCore.workersView';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]],
            ['height' => '10px', 'boxes' => [.1, .9]]
        ];
    }


    public function getTemplateName(): string
    {
        return 'workersView';
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'viewType',
                value: null,
                type: 'string',
                label: 'View type',
                description: 'Specify the view type (e.g. \'single\', \'multi\', \'or \'other\') to view the data in the dashboard. ',
                ui: [
                    'options' => [
                        'single' => 'Single',
                        'multi' => 'Tracking-Puffer',
                    ],
                ]
            ),
            PropertyDTO::create(
                name: 'source',
                value: '',
                type: 'string',
                isOptional: true,
                conditions: [
                    PropertyConditionDTO::when('viewType', '')->then([
                        PropertyConditionDTO::EFFECT_VISIBLE => false,
                    ]),
                    PropertyConditionDTO::whenAll([
                        PropertyConditionClauseDTO::create('viewType', 'single')
                    ])->then([
                        PropertyConditionDTO::EFFECT_LABEL => 'Worker ID',
                        PropertyConditionDTO::EFFECT_DESCRIPTION => 'Specify the ID of the Worker to view the data in the dashboard.'
                    ]),
                    PropertyConditionDTO::whenAll([
                        PropertyConditionClauseDTO::create('viewType', 'multi')
                    ])->then([
                        PropertyConditionDTO::EFFECT_LABEL => 'Worker IDs',
                        PropertyConditionDTO::EFFECT_DESCRIPTION => 'Specify the comma separated IDs of the Workers to view the data in the dashboard. '
                    ]),
                ]
            )
        ];
    }

    public function enrichProperties(array $properties): array
    {
        return $properties;
    }
}