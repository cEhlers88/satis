<?php

namespace Cehlers88\AnalyticsCore\Widget;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Support\Property\PropertyConditionResolver;
use Cehlers88\AnalyticsCore\Support\Property\PropertyValuePath;

/**
 * Turns the values submitted for a widget into the props it is rendered with,
 * and says which of the settings it insists on are still unanswered.
 *
 * A widget describes its settings as PropertyDTOs: the name is the prop the
 * value ends up in, the type says what the value is, and isOptional says
 * whether the widget can be rendered without it. The ui bag carries what the
 * value type does not imply - a selection, the bounds of a number, or an input
 * control of its own choosing.
 *
 * A name may be a dotted path ("source.entity"), which nests the value inside
 * the props - so a widget reading $props['source']->entity describes that
 * setting as "source.entity".
 *
 * A property may carry conditions on top of that, which say what it looks like
 * while the other properties hold certain values. Everything here works on the
 * properties as those conditions leave them, so a default a condition set is
 * the default that is stored, and a setting a condition took off the mask is
 * never insisted on.
 */
class WidgetSettings
{
    public function __construct(
        private PropertyConditionResolver $conditionResolver = new PropertyConditionResolver()
    )
    {
    }

    /**
     * The properties as the given values leave them - what a mask renders and
     * what everything here judges the values by.
     *
     * @param PropertyDTO[] $definitions
     *
     * @return PropertyDTO[]
     */
    public function resolve(array $definitions, array $values): array
    {
        return $this->conditionResolver->resolve($definitions, $values);
    }

    /**
     * Unknown keys are dropped and known ones are cast to the type their
     * property describes, so a widget can never be stored with props of the
     * client's own making.
     *
     * @param PropertyDTO[] $definitions
     */
    public function normalize(array $definitions, array $submittedSettings): array
    {
        $props = [];

        foreach ($this->resolve($definitions, $submittedSettings) as $definition) {
            // A setting a condition took off the mask is stored with the
            // default it currently declares, so the widget can rely on it
            // being there - and a value submitted for a setting that is not
            // on screen is none of the client's business.
            if (!$definition->isVisible) {
                $props = $this->writePath($props, $definition->name, $definition->value);
                continue;
            }

            $submittedValue = $this->readPath($submittedSettings, $definition->name);

            // An unchecked checkbox is not submitted at all, which is exactly
            // what "false" means for it.
            if (is_null($submittedValue) && $this->isBooleanLike($definition)) {
                $props = $this->writePath($props, $definition->name, false);
                continue;
            }

            // An optional setting nobody answered stays out of the props, so
            // the widget keeps deciding what its default is - unless a
            // condition named the default for exactly this case.
            if (is_null($submittedValue) && $definition->isOptional && !$definition->valueIsConditional()) {
                continue;
            }

            $props = $this->writePath($props, $definition->name, $this->castValue($definition, $submittedValue));
        }

        return $props;
    }

    /**
     * The settings a widget insists on that the given props do not answer - an
     * empty array means the widget has everything it needs.
     *
     * @param PropertyDTO[] $definitions
     *
     * @return PropertyDTO[]
     */
    public function findUnsatisfied(array $definitions, array $props): array
    {
        $unsatisfied = [];

        foreach ($this->resolve($definitions, $props) as $definition) {
            if (!$this->isSatisfied($definition, $this->readPath($props, $definition->name))) {
                $unsatisfied[] = $definition;
            }
        }

        return $unsatisfied;
    }

    /**
     * Whether the given value is enough to satisfy the setting. Optional ones
     * are always satisfied, including by nothing at all.
     */
    private function isSatisfied(PropertyDTO $definition, mixed $value): bool
    {
        // A setting that is not on screen is answered by its own default.
        if ($definition->isOptional || !$definition->isVisible) {
            return true;
        }

        if ($this->isBooleanLike($definition)) {
            return $value === true;
        }

        if (is_null($value)) {
            return false;
        }

        return !is_scalar($value) || trim((string)$value) !== '';
    }

    /**
     * Casts a raw (request) value into what the property describes. The default
     * value of the property is what a value that does not fit falls back to.
     */
    private function castValue(PropertyDTO $definition, mixed $value): mixed
    {
        if (is_null($value)) {
            return $definition->value;
        }

        if ($this->isBooleanLike($definition)) {
            return is_scalar($value) ? filter_var($value, FILTER_VALIDATE_BOOL) : $definition->value;
        }

        if (count($definition->ui['options'] ?? []) > 0) {
            return array_key_exists((string)$value, $definition->ui['options']) ? $value : $definition->value;
        }

        return match (strtolower($definition->type)) {
            'int', 'integer', 'float', 'double' => $this->clamp($definition, $value),
            // A structured value is passed through as it is - casting it to a
            // string would throw the whole structure away.
            'array', 'json' => is_array($value) ? $value : $definition->value,
            default => is_scalar($value) ? trim((string)$value) : $definition->value,
        };
    }

    private function isBooleanLike(PropertyDTO $definition): bool
    {
        return in_array(strtolower($definition->type), ['bool', 'boolean'], true);
    }

    private function clamp(PropertyDTO $definition, mixed $value): int|float
    {
        $number = is_numeric($value) ? $value + 0 : ($definition->value ?? 0);
        $min = $definition->ui['min'] ?? null;
        $max = $definition->ui['max'] ?? null;

        if (!is_null($min) && $number < $min) {
            $number = $min;
        }
        if (!is_null($max) && $number > $max) {
            $number = $max;
        }

        return in_array(strtolower($definition->type), ['float', 'double'], true) ? (float)$number : (int)$number;
    }

    private function readPath(array $values, string $path): mixed
    {
        return PropertyValuePath::read($values, $path);
    }

    private function writePath(array $values, string $path, mixed $value): array
    {
        return PropertyValuePath::write($values, $path, $value);
    }
}
