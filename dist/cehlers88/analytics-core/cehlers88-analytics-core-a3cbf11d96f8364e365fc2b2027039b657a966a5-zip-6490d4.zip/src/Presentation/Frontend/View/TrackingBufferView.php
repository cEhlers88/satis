<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;

/** View representation of a TrackingBuffer entity. */
class TrackingBufferView implements ViewInterface
{
    public int $id;
    public array $data;
    public array $handlerData;
    public \DateTime $timestamp;
    public \DateTime $createdAt;
    public ?\DateTime $handledAt;
    public eTrackingBufferState $state;
    public ApplicationView $application;
    public string $note = '';

    /**
     * Nested tracking buffers pointing at this one as their parent. The tree can
     * be arbitrarily deep, so consumers have to walk it recursively.
     *
     * @var TrackingBufferView[]
     */
    public array $children = [];

    public function getDataOverview(int $maxLength = 300): string
    {
        if (isset($this->handlerData['ui_overview'])) {
            return json_encode([
                'message' => substr($this->handlerData['ui_overview']['message'], 0, $maxLength) . '...'
            ]);
        }
        return json_encode($this->data);
    }

    public function getJsonDefinition(): array
    {
        return [
            'id' => $this->id,
            'state' => $this->state->name,
            'note' => $this->note,
            'handledAt' => $this->handledAt ? $this->handledAt->format('Y-m-d H:i:s') : null,
            'handlerData' => $this->handlerData,
            'dataFingerprint' => $this->data,
            // Part of the fingerprint: the frontend replaces a row as a whole,
            // so a change deeper in the tree has to show up here as well.
            'children' => array_map(
                static fn(self $child): array => $child->getJsonDefinition(),
                $this->children
            ),
        ];
    }

    /** Number of nested tracking buffers, including all deeper levels. */
    public function getDescendantCount(): int
    {
        $count = 0;
        foreach ($this->children as $child) {
            $count += 1 + $child->getDescendantCount();
        }

        return $count;
    }
}
