<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\Support\DTO\DTO;

/**
 * One comparison inside a PropertyConditionDTO: "the property <property> is
 * <type> <value>", where the property is named the way its PropertyDTO is -
 * including a dotted one ("source.entity").
 */
class PropertyConditionClauseDTO extends DTO
{
    public string $property = '';

    public eConditionType $type = eConditionType::EQUALS;

    public string $typeName = '===';

    public mixed $value = null;

    private function __construct()
    {
    }

    public static function create(
        string         $property,
        mixed          $value = null,
        eConditionType $type = eConditionType::EQUALS
    ): static
    {
        $dto = new static();
        $dto->property = $property;
        $dto->value = $value;
        $dto->type = $type;
        $dto->typeName = eConditionType::toString($type->value());

        return $dto;
    }

    /**
     * @param array{property: string, value?: mixed, type?: int|eConditionType} $data
     */
    public static function createFromArray(array $data): static
    {
        $type = $data['type'] ?? eConditionType::EQUALS;

        return static::create(
            (string)($data['property'] ?? ''),
            $data['value'] ?? null,
            $type instanceof eConditionType ? $type : eConditionType::from((int)$type)
        );
    }

    public function toArray(): array
    {
        return [
            'property' => $this->property,
            'type' => $this->type->value(),
            'typeName' => $this->typeName,
            'value' => $this->value,
        ];
    }
}
