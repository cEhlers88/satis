<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class PropertyDTO extends DTO
{
    public bool $allowMonitoring = false;

    public bool $isDefaultValue = true;

    public bool $isOptional = false;

    /**
     * Whether the property is on screen at all. A condition may take it off -
     * see $conditions.
     */
    public bool $isVisible = true;

    /**
     * What the property looks like while other properties hold certain values.
     *
     * @var PropertyConditionDTO[]
     *
     * @see PropertyConditionDTO
     */
    public array $conditions = [];

    public array $groups = [];

    public string $name = '';

    public string $label = '';

    public mixed $value = null;
    public bool $hasSubCommand = false;
    public bool $hasConditionGroups = false;

    public string $type = 'mixed';

    public string $description = '';

    public array $ui = [        // special ui properties
        'class' => '',          // specify additional css-class for this property
        'displayName' => null,  // specify a different display name for this property in the UI
        'input' => null,        // force an input control the value type does not imply ('textarea', 'color', ...)
        'options' => [],        // value => label map; makes the property a selection
        'min' => null,          // lower bound of a numeric property
        'max' => null,          // upper bound of a numeric property
    ];

    /**
     * The property as it was declared, kept on a copy the conditions changed so
     * a mask can always evaluate them again from the declaration itself.
     */
    private ?PropertyDTO $declared = null;

    private function __construct()
    {
    }

    /**
     * @param string $description Explains the property to whoever fills it in.
     * @param array  $ui          Presentation hints on top of the value type -
     *                            see the $ui property.
     * @param PropertyConditionDTO[] $conditions What the property looks like
     *                            while other properties hold certain values.
     */
    public static function create(
        string $name,
        mixed  $value,
        string $type = 'mixed',
        bool   $isOptional = false,
        string $label = '',
        bool   $allowMonitoring = false,
        string $description = '',
        array  $ui = [],
        array  $conditions = []
    ): static
    {
        $dto = new static();
        $dto->allowMonitoring = $allowMonitoring;
        $dto->name = $name;
        $dto->label = empty($label) ? $name : $label;
        $dto->type = $type;
        $dto->value = $value;
        $dto->isOptional = $isOptional;
        $dto->description = $description;
        $dto->ui = [...$dto->ui, ...$ui];
        $dto->conditions = array_values($conditions);
        return $dto;
    }

    /**
     * Creates an instance of the class from the given array.
     *
     * @param array $data An array containing the data to populate the instance.
     *                    Expected keys are in the order of type, name, and optionally value.
     *
     * @return static A new instance of the class populated with the provided data.
     */
    public static function createFromArray(array $data): static
    {
        $dto = new static();
        $dto->type = $data[0];
        $dto->name = $data[1];
        $dto->value = $data[2] ?? null;;
        $dto->isOptional = isset($data[2]);
        return $dto;
    }

    /**
     * The same property with further conditions on it, so a property that is
     * declared elsewhere can still be given one.
     */
    public function withConditions(PropertyConditionDTO ...$conditions): static
    {
        $clone = clone $this;
        $clone->conditions = [...$this->conditions, ...$conditions];

        return $clone;
    }

    /**
     * The property as it looks while the effects of the conditions that are
     * fulfilled apply - what PropertyConditionResolver hands back.
     *
     * @param array<string, mixed> $effects
     *
     * @see PropertyConditionDTO::KNOWN_EFFECTS
     */
    public function withConditionEffects(array $effects): static
    {
        $clone = clone $this;
        $clone->declared = $this->declaredDefinition();

        foreach ($effects as $effect => $value) {
            match ($effect) {
                PropertyConditionDTO::EFFECT_VALUE => $clone->value = $value,
                PropertyConditionDTO::EFFECT_VISIBLE => $clone->isVisible = (bool)$value,
                PropertyConditionDTO::EFFECT_IS_OPTIONAL => $clone->isOptional = (bool)$value,
                PropertyConditionDTO::EFFECT_LABEL => $clone->label = (string)$value,
                PropertyConditionDTO::EFFECT_DESCRIPTION => $clone->description = (string)$value,
                PropertyConditionDTO::EFFECT_UI => $clone->ui = [...$clone->ui, ...$value],
                default => throw new \InvalidArgumentException(sprintf(
                    'Unknown property condition effect "%s"',
                    $effect
                )),
            };
        }

        return $clone;
    }

    /**
     * The property the way it was declared - a property no condition changed is
     * its own declaration.
     *
     * Deliberately not named get*(): a PropertyDTO is serialized by walking its
     * accessors, and a declaration that hands itself back would read as a
     * circular reference.
     */
    public function declaredDefinition(): self
    {
        return $this->declared ?? $this;
    }

    /**
     * Whether the default value of the property is one a condition put there.
     *
     * Such a default is a statement about the case the condition describes, not
     * the fallback the widget would pick on its own - so it is stored even for
     * a property nobody filled in.
     */
    public function valueIsConditional(): bool
    {
        return !is_null($this->declared) && $this->declared->value !== $this->value;
    }

    /**
     * The conditions as plain data, which is how a mask that evaluates them in
     * the browser is given them.
     *
     * @return array<int, array<string, mixed>>
     */
    public function conditionDefinitions(): array
    {
        return array_map(
            static fn(PropertyConditionDTO $condition): array => $condition->toArray(),
            $this->conditions
        );
    }

    /**
     * Everything a mask needs to render the property and to evaluate it again
     * while it is being filled in - the one description both the twig mask and
     * the masks built in the browser follow.
     *
     * @return array<string, mixed>
     */
    public function toDefinitionArray(): array
    {
        return [
            'name' => $this->name,
            'label' => $this->label,
            'type' => $this->type,
            'value' => $this->value,
            'isOptional' => $this->isOptional,
            'isVisible' => $this->isVisible,
            'description' => $this->description,
            'ui' => $this->ui,
            'conditions' => $this->conditionDefinitions(),
        ];
    }

    public function toArray()
    {
        $result = [$this->type, $this->name, $this->value];
        return $result;
    }

    public function toAssociativeArray()
    {
        return [
            'allowMonitoring' => $this->allowMonitoring,
            'label' => $this->label,
            'name' => $this->name,
            'type' => $this->type,
            'value' => $this->value,
            'isOptional' => $this->isOptional,
            'groups' => $this->groups,
            'hasSubCommand' => $this->hasSubCommand,
            'hasConditionGroups' => $this->hasConditionGroups,
            'isVisible' => $this->isVisible,
            'conditions' => $this->conditionDefinitions(),
        ];
    }
}