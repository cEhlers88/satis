<?php

namespace Cehlers88\AnalyticsCore\DTO;

use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\Support\DTO\DTO;

/**
 * What a property looks like while other properties hold certain values.
 *
 * A condition is a set of clauses over *other* properties and the effects that
 * take hold while they are fulfilled - a different default value, another list
 * of options, a property that disappears or stops being required:
 *
 *     PropertyDTO::create('limit', 10, 'int', conditions: [
 *         PropertyConditionDTO::when('mode', 'detailed')->thenValue(100),
 *         PropertyConditionDTO::when('source', 'SystemLog')
 *             ->orWhen('source', 'TrackingBuffer')
 *             ->thenOptions(['1h' => 'Letzte Stunde', '1d' => 'Letzter Tag']),
 *         PropertyConditionDTO::when('mode', 'simple')->thenHidden(),
 *     ])
 *
 * The clauses of one condition are joined by its mode (AND by default, OR or
 * XOR when the condition was built that way). Several conditions on the same
 * property are independent of each other and are applied in the order they are
 * declared, so a later one overrides the effects of an earlier one.
 */
class PropertyConditionDTO extends DTO
{
    public const EFFECT_VALUE = 'value';
    public const EFFECT_VISIBLE = 'visible';
    public const EFFECT_IS_OPTIONAL = 'isOptional';
    public const EFFECT_LABEL = 'label';
    public const EFFECT_DESCRIPTION = 'description';
    public const EFFECT_UI = 'ui';

    /**
     * The effects a condition may declare. Everything else is a typo and is
     * rejected rather than silently ignored.
     */
    public const KNOWN_EFFECTS = [
        self::EFFECT_VALUE,
        self::EFFECT_VISIBLE,
        self::EFFECT_IS_OPTIONAL,
        self::EFFECT_LABEL,
        self::EFFECT_DESCRIPTION,
        self::EFFECT_UI,
    ];

    /** @var PropertyConditionClauseDTO[] */
    public array $clauses = [];

    public eConditionType $mode = eConditionType::AND;

    public string $modeName = 'and';

    /** @var array<string, mixed> */
    public array $effects = [];

    private function __construct()
    {
    }

    public static function when(
        string         $property,
        mixed          $value = null,
        eConditionType $type = eConditionType::EQUALS
    ): static
    {
        $dto = new static();
        $dto->clauses[] = PropertyConditionClauseDTO::create($property, $value, $type);

        return $dto;
    }

    /**
     * A condition that is fulfilled while every one of the given clauses is.
     *
     * @param PropertyConditionClauseDTO[] $clauses
     */
    public static function whenAll(array $clauses): static
    {
        return static::fromClauses($clauses, eConditionType::AND);
    }

    /**
     * A condition that is fulfilled as soon as one of the given clauses is.
     *
     * @param PropertyConditionClauseDTO[] $clauses
     */
    public static function whenAny(array $clauses): static
    {
        return static::fromClauses($clauses, eConditionType::OR);
    }

    /**
     * @param array{clauses?: array, mode?: int|eConditionType, effects?: array} $data
     */
    public static function createFromArray(array $data): static
    {
        $mode = $data['mode'] ?? eConditionType::AND;
        $clauses = [];

        foreach ($data['clauses'] ?? [] as $clause) {
            $clauses[] = $clause instanceof PropertyConditionClauseDTO
                ? $clause
                : PropertyConditionClauseDTO::createFromArray($clause);
        }

        return static::fromClauses(
            $clauses,
            $mode instanceof eConditionType ? $mode : eConditionType::from((int)$mode)
        )->then($data['effects'] ?? []);
    }

    /**
     * @param PropertyConditionClauseDTO[] $clauses
     */
    private static function fromClauses(array $clauses, eConditionType $mode): static
    {
        $dto = new static();
        $dto->clauses = array_values($clauses);
        $dto->mode = $mode;
        $dto->modeName = eConditionType::toString($mode->value());

        return $dto;
    }

    public function andWhen(
        string         $property,
        mixed          $value = null,
        eConditionType $type = eConditionType::EQUALS
    ): static
    {
        return $this->addClause(PropertyConditionClauseDTO::create($property, $value, $type), eConditionType::AND);
    }

    public function orWhen(
        string         $property,
        mixed          $value = null,
        eConditionType $type = eConditionType::EQUALS
    ): static
    {
        return $this->addClause(PropertyConditionClauseDTO::create($property, $value, $type), eConditionType::OR);
    }

    /**
     * The effects that take hold while the condition is fulfilled.
     *
     * @param array<string, mixed> $effects
     */
    public function then(array $effects): static
    {
        foreach ($effects as $effect => $value) {
            if (!in_array($effect, self::KNOWN_EFFECTS, true)) {
                throw new \InvalidArgumentException(sprintf(
                    'Unknown property condition effect "%s", known are: %s',
                    $effect,
                    implode(', ', self::KNOWN_EFFECTS)
                ));
            }

            if ($effect === self::EFFECT_UI && !is_array($value)) {
                throw new \InvalidArgumentException('The "ui" effect of a property condition must be an array.');
            }

            // The ui bag is merged rather than replaced, so two conditions can
            // each say their part about the same property.
            $this->effects[$effect] = $effect === self::EFFECT_UI
                ? [...($this->effects[self::EFFECT_UI] ?? []), ...$value]
                : $value;
        }

        return $this;
    }

    public function thenValue(mixed $value): static
    {
        return $this->then([self::EFFECT_VALUE => $value]);
    }

    /**
     * @param array<string|int, string> $options value => label
     */
    public function thenOptions(array $options): static
    {
        return $this->then([self::EFFECT_UI => ['options' => $options]]);
    }

    public function thenUi(array $ui): static
    {
        return $this->then([self::EFFECT_UI => $ui]);
    }

    public function thenHidden(): static
    {
        return $this->then([self::EFFECT_VISIBLE => false]);
    }

    public function thenVisible(): static
    {
        return $this->then([self::EFFECT_VISIBLE => true]);
    }

    public function thenRequired(): static
    {
        return $this->then([self::EFFECT_IS_OPTIONAL => false]);
    }

    public function thenOptional(): static
    {
        return $this->then([self::EFFECT_IS_OPTIONAL => true]);
    }

    public function thenLabel(string $label): static
    {
        return $this->then([self::EFFECT_LABEL => $label]);
    }

    public function thenDescription(string $description): static
    {
        return $this->then([self::EFFECT_DESCRIPTION => $description]);
    }

    public function toArray(): array
    {
        return [
            'mode' => $this->mode->value(),
            'modeName' => $this->modeName,
            'clauses' => array_map(
                static fn(PropertyConditionClauseDTO $clause): array => $clause->toArray(),
                $this->clauses
            ),
            'effects' => $this->effects,
        ];
    }

    /**
     * A condition joins its clauses one way; asking for both is a contradiction
     * rather than a precedence question this has to answer.
     */
    private function addClause(PropertyConditionClauseDTO $clause, eConditionType $mode): static
    {
        if (count($this->clauses) > 1 && $this->mode !== $mode) {
            throw new \InvalidArgumentException(
                'A property condition joins its clauses one way - use two conditions instead of mixing "and" and "or".'
            );
        }

        $this->clauses[] = $clause;
        $this->mode = $mode;
        $this->modeName = eConditionType::toString($mode->value());

        return $this;
    }
}
