<?php

namespace Cehlers88\AnalyticsCore\Support\Property;

use Cehlers88\AnalyticsCore\DTO\PropertyConditionClauseDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;

/**
 * Turns the properties as they were declared into the properties as they are
 * right now: with the conditions that the current values fulfill applied.
 *
 * Whoever renders or validates a set of PropertyDTOs asks this first, so a
 * condition means the same everywhere - in the mask, in what is stored, and in
 * what is insisted on.
 *
 * A condition may look at a property whose own default a condition changed, so
 * the values are resolved again until they stop moving. A set of conditions
 * that keeps contradicting itself gives up after MAX_PASSES rounds and keeps
 * what it had - a declaration that never settles is a bug in the declaration,
 * not a reason to loop forever.
 */
class PropertyConditionResolver
{
    private const MAX_PASSES = 10;

    /**
     * @param PropertyDTO[]        $definitions
     * @param array<string, mixed> $values The values the properties currently
     *                                     hold, nested the way their names say.
     *
     * @return PropertyDTO[] Keyed like the definitions that went in.
     */
    public function resolve(array $definitions, array $values): array
    {
        if (!$this->hasConditions($definitions)) {
            return $definitions;
        }

        $resolved = $definitions;
        $effectiveValues = $this->effectiveValues($definitions, $values);

        for ($pass = 0; $pass < self::MAX_PASSES; ++$pass) {
            $resolved = [];

            foreach ($definitions as $key => $definition) {
                $resolved[$key] = $this->applyConditions($definition, $effectiveValues, $values);
            }

            $nextValues = $this->effectiveValues($resolved, $values);
            if ($nextValues === $effectiveValues) {
                break;
            }

            $effectiveValues = $nextValues;
        }

        return $resolved;
    }

    /**
     * The properties of one definition after the conditions it declares - the
     * short way in for a caller that resolves a single property.
     *
     * @param PropertyDTO[] $definitions The properties the conditions may look
     *                                   at; the property itself is enough when
     *                                   its conditions only read submitted
     *                                   values.
     */
    public function resolveOne(PropertyDTO $definition, array $values, array $definitions = []): PropertyDTO
    {
        $definitions = $definitions === [] ? [$definition] : $definitions;
        $resolved = $this->resolve($definitions, $values);

        foreach ($resolved as $candidate) {
            if ($candidate->name === $definition->name) {
                return $candidate;
            }
        }

        return $definition;
    }

    /**
     * Whether the given values fulfill the condition.
     */
    public function isFulfilled(PropertyConditionDTO $condition, array $effectiveValues, array $values = []): bool
    {
        if ($condition->clauses === []) {
            return false;
        }

        $fulfilled = array_map(
            fn(PropertyConditionClauseDTO $clause): bool => self::compare(
                $this->valueOf($clause->property, $effectiveValues, $values),
                $clause->value,
                $clause->type
            ),
            $condition->clauses
        );

        return match ($condition->mode) {
            eConditionType::OR => in_array(true, $fulfilled, true),
            // Chained xor: fulfilled by an odd number of its clauses, which for
            // the usual two clauses is "one of them, not both".
            eConditionType::XOR => count(array_filter($fulfilled)) % 2 === 1,
            default => !in_array(false, $fulfilled, true),
        };
    }

    /**
     * Compares a value the way a condition type says.
     *
     * The values of a mask arrive as strings, so the comparison is a lenient
     * one: "1" is the 1 a property declared, and "true" is its true. An
     * expected value that is a list is fulfilled by any of its entries, which
     * is how a condition says "one of".
     *
     * The joining types (and, or, xor) are no comparison and are never
     * fulfilled - they say how the clauses of a condition are joined.
     */
    public static function compare(mixed $actual, mixed $expected, eConditionType $type): bool
    {
        return match ($type) {
            eConditionType::EQUALS => self::equals($actual, $expected),
            eConditionType::NOT_EQUALS => !self::equals($actual, $expected),
            eConditionType::GREATER_THAN => self::compareOrder($actual, $expected) === 1,
            eConditionType::GREATER_THAN_OR_EQUALS => in_array(self::compareOrder($actual, $expected), [0, 1], true),
            eConditionType::LESS_THAN => self::compareOrder($actual, $expected) === -1,
            eConditionType::LESS_THAN_OR_EQUALS => in_array(self::compareOrder($actual, $expected), [0, -1], true),
            eConditionType::CONTAINS => self::contains($actual, $expected),
            eConditionType::NOT_CONTAINS => !self::contains($actual, $expected),
            eConditionType::STARTS_WITH => self::isString($actual) && self::isString($expected)
                && str_starts_with((string)$actual, (string)$expected),
            eConditionType::ENDS_WITH => self::isString($actual) && self::isString($expected)
                && str_ends_with((string)$actual, (string)$expected),
            default => false,
        };
    }

    /**
     * @param PropertyDTO[] $definitions
     */
    private function hasConditions(array $definitions): bool
    {
        foreach ($definitions as $definition) {
            if ($definition->conditions !== []) {
                return true;
            }
        }

        return false;
    }

    /**
     * What every property holds right now: the value that was submitted for it,
     * or the default it currently declares.
     *
     * @param PropertyDTO[] $definitions
     *
     * @return array<string, mixed> Keyed by property name, dotted ones included.
     */
    private function effectiveValues(array $definitions, array $values): array
    {
        $effectiveValues = [];

        foreach ($definitions as $definition) {
            $submitted = PropertyValuePath::read($values, $definition->name);
            $effectiveValues[$definition->name] = is_null($submitted) ? $definition->value : $submitted;
        }

        return $effectiveValues;
    }

    /**
     * A clause may look at a property that is not declared next to it - the
     * values it was resolved with are then the only place to find it.
     */
    private function valueOf(string $property, array $effectiveValues, array $values): mixed
    {
        return array_key_exists($property, $effectiveValues)
            ? $effectiveValues[$property]
            : PropertyValuePath::read($values, $property);
    }

    private function applyConditions(PropertyDTO $definition, array $effectiveValues, array $values): PropertyDTO
    {
        if ($definition->conditions === []) {
            return $definition;
        }

        $effects = [];

        foreach ($definition->conditions as $condition) {
            if (!$this->isFulfilled($condition, $effectiveValues, $values)) {
                continue;
            }

            foreach ($condition->effects as $effect => $value) {
                $effects[$effect] = $effect === PropertyConditionDTO::EFFECT_UI
                    ? [...($effects[PropertyConditionDTO::EFFECT_UI] ?? []), ...$value]
                    : $value;
            }
        }

        return $effects === [] ? $definition : $definition->withConditionEffects($effects);
    }

    private static function equals(mixed $actual, mixed $expected): bool
    {
        // A list of expected values is fulfilled by any of them.
        if (is_array($expected) && !is_array($actual)) {
            foreach ($expected as $candidate) {
                if (self::equals($actual, $candidate)) {
                    return true;
                }
            }

            return false;
        }

        if (is_bool($actual) || is_bool($expected)) {
            return self::toBool($actual) === self::toBool($expected);
        }

        if (is_null($actual) || is_null($expected)) {
            return self::isEmpty($actual) && self::isEmpty($expected);
        }

        if (is_array($actual) || is_array($expected)) {
            return $actual == $expected;
        }

        if (is_numeric($actual) && is_numeric($expected)) {
            return $actual + 0 == $expected + 0;
        }

        return (string)$actual === (string)$expected;
    }

    /**
     * -1, 0 or 1 the way a comparison reads, or null when the two values are
     * not to be put in an order at all.
     */
    private static function compareOrder(mixed $actual, mixed $expected): ?int
    {
        if (is_numeric($actual) && is_numeric($expected)) {
            return $actual + 0 <=> $expected + 0;
        }

        if (!self::isString($actual) || !self::isString($expected)) {
            return null;
        }

        return strcmp((string)$actual, (string)$expected) <=> 0;
    }

    private static function contains(mixed $actual, mixed $expected): bool
    {
        if (is_array($actual)) {
            foreach ($actual as $entry) {
                if (self::equals($entry, $expected)) {
                    return true;
                }
            }

            return false;
        }

        if (!self::isString($actual) || !self::isString($expected)) {
            return false;
        }

        return str_contains((string)$actual, (string)$expected);
    }

    private static function isString(mixed $value): bool
    {
        return is_scalar($value);
    }

    private static function isEmpty(mixed $value): bool
    {
        return is_null($value) || $value === '' || $value === [];
    }

    private static function toBool(mixed $value): bool
    {
        return is_scalar($value) ? filter_var($value, FILTER_VALIDATE_BOOL) : !self::isEmpty($value);
    }
}
