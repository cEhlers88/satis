<?php

namespace Cehlers88\AnalyticsCore\Support\Property;

/**
 * Reads and writes the values a PropertyDTO is named after.
 *
 * A name may be a dotted path ("source.entity"), which nests the value inside
 * the values it belongs to - so a widget reading $props['source']->entity
 * describes that setting as "source.entity".
 */
class PropertyValuePath
{
    /**
     * Reads a dotted path out of nested values, where every segment that is not
     * there ends the lookup. Objects are walked as well, because values that
     * came back from a request are decoded json.
     */
    public static function read(array $values, string $path): mixed
    {
        // A dotted name may also be a key of its own, which is how a mask that
        // keeps its values flat still finds them.
        if (array_key_exists($path, $values)) {
            return $values[$path];
        }

        $current = $values;

        foreach (explode('.', $path) as $segment) {
            $current = is_object($current) ? (array)$current : $current;

            if (!is_array($current) || !array_key_exists($segment, $current)) {
                return null;
            }

            $current = $current[$segment];
        }

        return $current;
    }

    /**
     * Writes a value into nested values along a dotted path, creating the
     * intermediate levels on the way.
     */
    public static function write(array $values, string $path, mixed $value): array
    {
        $segments = explode('.', $path);
        $key = array_shift($segments);

        if (count($segments) === 0) {
            $values[$key] = $value;

            return $values;
        }

        $nested = is_array($values[$key] ?? null) ? $values[$key] : [];
        $values[$key] = self::write($nested, implode('.', $segments), $value);

        return $values;
    }
}
