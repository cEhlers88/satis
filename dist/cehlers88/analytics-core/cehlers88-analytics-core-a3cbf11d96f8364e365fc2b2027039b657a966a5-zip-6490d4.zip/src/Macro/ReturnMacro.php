<?php

namespace Cehlers88\AnalyticsCore\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;

class ReturnMacro extends AbstractMacro
{
    private const string PROPERTY_VALUE = 'value';

    public function init(): ReturnMacro
    {
        $this->_source = 'CoreBundle';
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_VALUE, 'string', 'Specify the value to be returned'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Return a given value.';
    }

    public function getName(): string
    {
        return 'return';
    }

    protected function run(): ?array
    {
        return $this->_createRunResult(
            $this->_runCommandDefinition($this->getPropertyValue(self::PROPERTY_VALUE))
        );
    }
}