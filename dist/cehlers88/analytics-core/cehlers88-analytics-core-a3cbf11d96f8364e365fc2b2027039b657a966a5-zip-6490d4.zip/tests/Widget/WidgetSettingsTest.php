<?php

namespace Cehlers88\AnalyticsCore\Tests\Widget;

use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Widget\WidgetSettings;
use PHPUnit\Framework\TestCase;

class WidgetSettingsTest extends TestCase
{
    // ── normalizing ──────────────────────────────────────────────────────────

    public function testValuesAreCastToWhatTheirPropertyDescribes(): void
    {
        $props = $this->makeSettings()->normalize(
            [PropertyDTO::create('limit', 10, 'int', ui: ['min' => 1, 'max' => 50])],
            ['limit' => '80']
        );

        $this->assertSame(['limit' => 50], $props);
    }

    public function testSettingsNoWidgetAsksForAreDropped(): void
    {
        $props = $this->makeSettings()->normalize(
            [PropertyDTO::create('limit', '', 'string')],
            ['limit' => '10', 'somethingElse' => 'nope']
        );

        $this->assertSame(['limit' => '10'], $props);
    }

    public function testAnOptionalSettingThatWasNotAnsweredStaysOutOfTheProps(): void
    {
        $props = $this->makeSettings()->normalize(
            [PropertyDTO::create('keyFilter', '', 'string', isOptional: true)],
            []
        );

        $this->assertSame([], $props);
    }

    /**
     * A checkbox that is switched off is not submitted at all, which is exactly
     * what "false" means for it.
     */
    public function testAnUnsubmittedCheckboxIsStoredAsFalse(): void
    {
        $props = $this->makeSettings()->normalize(
            [PropertyDTO::create('compact', false, 'bool', isOptional: true)],
            []
        );

        $this->assertSame(['compact' => false], $props);
    }

    public function testADottedNameNestsTheValue(): void
    {
        $props = $this->makeSettings()->normalize(
            [
                PropertyDTO::create('source.entity', null, 'string'),
                PropertyDTO::create('source.keyFilter', '', 'string', isOptional: true),
            ],
            ['source' => ['entity' => 'SystemLog', 'keyFilter' => 'checkout']]
        );

        $this->assertSame(['source' => ['entity' => 'SystemLog', 'keyFilter' => 'checkout']], $props);
    }

    public function testAPropertyWithOptionsOnlyAcceptsOneOfThem(): void
    {
        $definition = PropertyDTO::create(
            name: 'source',
            value: null,
            type: 'string',
            ui: ['options' => ['SystemLog' => 'Systemprotokoll']]
        );

        $props = $this->makeSettings()->normalize([$definition], ['source' => 'TrackingBuffer']);

        $this->assertSame(['source' => null], $props);
    }

    // ── settings a widget insists on ─────────────────────────────────────────

    public function testASettingTheWidgetInsistsOnIsReportedWhileItIsUnanswered(): void
    {
        $definition = PropertyDTO::create('source.entity', null, 'string');

        $missing = $this->makeSettings()->findUnsatisfied([$definition], []);

        $this->assertSame([$definition], $missing);
    }

    public function testASettingAnsweredWithNothingIsReported(): void
    {
        $definition = PropertyDTO::create('source.entity', null, 'string');

        $missing = $this->makeSettings()->findUnsatisfied([$definition], ['source' => ['entity' => '  ']]);

        $this->assertSame([$definition], $missing);
    }

    public function testAnAnsweredSettingIsNotReported(): void
    {
        $definition = PropertyDTO::create('source.entity', null, 'string');

        $missing = $this->makeSettings()->findUnsatisfied([$definition], ['source' => ['entity' => 'SystemLog']]);

        $this->assertSame([], $missing);
    }

    /**
     * Props that come back from a widget request are decoded json, so a nested
     * setting arrives as an object rather than an array.
     */
    public function testNestedPropsAreAlsoReadFromObjects(): void
    {
        $definition = PropertyDTO::create('source.entity', null, 'string');

        $missing = $this->makeSettings()->findUnsatisfied(
            [$definition],
            ['source' => (object)['entity' => 'SystemLog']]
        );

        $this->assertSame([], $missing);
    }

    /**
     * A checkbox the widget insists on is a checkbox that has to be ticked.
     */
    public function testACheckboxTheWidgetInsistsOnIsReportedWhileItIsSwitchedOff(): void
    {
        $definition = PropertyDTO::create('confirmed', false, 'bool');

        $this->assertSame([$definition], $this->makeSettings()->findUnsatisfied([$definition], ['confirmed' => false]));
        $this->assertSame([], $this->makeSettings()->findUnsatisfied([$definition], ['confirmed' => true]));
    }

    public function testOptionalSettingsAreNeverReported(): void
    {
        $missing = $this->makeSettings()->findUnsatisfied(
            [PropertyDTO::create('keyFilter', '', 'string', isOptional: true)],
            []
        );

        $this->assertSame([], $missing);
    }

    public function testStructuredValuesSurviveNormalizing(): void
    {
        $commands = [['name' => 'echo', 'output' => 'zu hoch']];

        $props = $this->makeSettings()->normalize(
            [PropertyDTO::create('onMax', [], 'array', isOptional: true)],
            ['onMax' => $commands]
        );

        $this->assertSame(['onMax' => $commands], $props);
    }

    public function testStructuredSettingsFallBackToTheirDefaultWhenNotAnArray(): void
    {
        $props = $this->makeSettings()->normalize(
            [PropertyDTO::create('onMax', [], 'array')],
            ['onMax' => 'nope']
        );

        $this->assertSame(['onMax' => []], $props);
    }

    // ── conditions ───────────────────────────────────────────────────────────

    public function testASettingIsStoredWithTheDefaultAConditionGaveIt(): void
    {
        $props = $this->makeSettings()->normalize(
            [
                PropertyDTO::create('mode', 'simple', 'string'),
                PropertyDTO::create('limit', 10, 'int', isOptional: true, conditions: [
                    PropertyConditionDTO::when('mode', 'detailed')->thenValue(100),
                ]),
            ],
            ['mode' => 'detailed']
        );

        $this->assertSame(['mode' => 'detailed', 'limit' => 100], $props);
    }

    public function testOnlyTheOptionsAConditionPutThereAreAccepted(): void
    {
        $definitions = [
            PropertyDTO::create('source', 'log', 'string'),
            PropertyDTO::create('range', '1h', 'string', ui: ['options' => ['1h' => 'Stunde']], conditions: [
                PropertyConditionDTO::when('source', 'tracking')->thenOptions(['1d' => 'Tag']),
            ]),
        ];

        $this->assertSame(
            ['source' => 'tracking', 'range' => '1d'],
            $this->makeSettings()->normalize($definitions, ['source' => 'tracking', 'range' => '1d'])
        );
        // The hour the property declares is no longer one of the options the
        // picked source offers, so it falls back to the default.
        $this->assertSame(
            ['source' => 'tracking', 'range' => '1h'],
            $this->makeSettings()->normalize($definitions, ['source' => 'tracking', 'range' => '1h'])
        );
    }

    /**
     * A setting that is not on the mask is stored with the default it declares
     * - the widget can rely on it being there - and a value submitted for it is
     * none of the client's business.
     */
    public function testASettingAConditionTookOffTheMaskKeepsItsDefault(): void
    {
        $props = $this->makeSettings()->normalize(
            [
                PropertyDTO::create('useDefaults', true, 'bool', isOptional: true),
                PropertyDTO::create('limit', 10, 'int', conditions: [
                    PropertyConditionDTO::when('useDefaults', true)->thenHidden(),
                ]),
            ],
            ['useDefaults' => true, 'limit' => 999]
        );

        $this->assertSame(['useDefaults' => true, 'limit' => 10], $props);
    }

    public function testASettingAConditionTookOffTheMaskIsNeverReported(): void
    {
        $missing = $this->makeSettings()->findUnsatisfied(
            [
                PropertyDTO::create('useDefaults', true, 'bool', isOptional: true),
                PropertyDTO::create('endpoint', '', 'string', conditions: [
                    PropertyConditionDTO::when('useDefaults', true)->thenHidden(),
                ]),
            ],
            ['useDefaults' => true]
        );

        $this->assertSame([], $missing);
    }

    public function testASettingAConditionInsistsOnIsReportedWhileItIsBlank(): void
    {
        $definitions = [
            PropertyDTO::create('mode', 'simple', 'string'),
            PropertyDTO::create('endpoint', '', 'string', isOptional: true, conditions: [
                PropertyConditionDTO::when('mode', 'remote')->thenRequired(),
            ]),
        ];

        $missing = $this->makeSettings()->findUnsatisfied($definitions, ['mode' => 'remote']);

        $this->assertSame(['endpoint'], array_map(static fn(PropertyDTO $p): string => $p->name, $missing));
        $this->assertSame([], $this->makeSettings()->findUnsatisfied($definitions, ['mode' => 'simple']));
    }

    private function makeSettings(): WidgetSettings
    {
        return new WidgetSettings();
    }
}
