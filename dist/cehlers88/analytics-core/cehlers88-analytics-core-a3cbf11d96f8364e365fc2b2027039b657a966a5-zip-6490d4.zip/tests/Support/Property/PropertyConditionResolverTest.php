<?php

namespace Cehlers88\AnalyticsCore\Tests\Support\Property;

use Cehlers88\AnalyticsCore\DTO\PropertyConditionClauseDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\Support\Property\PropertyConditionResolver;
use PHPUnit\Framework\TestCase;

class PropertyConditionResolverTest extends TestCase
{
    // ── effects ──────────────────────────────────────────────────────────────

    public function testAFulfilledConditionChangesTheDefaultValue(): void
    {
        $definitions = [
            PropertyDTO::create('mode', 'simple', 'string', ui: ['options' => ['simple' => 'Simple', 'detailed' => 'Detailed']]),
            PropertyDTO::create('limit', 10, 'int', conditions: [
                PropertyConditionDTO::when('mode', 'detailed')->thenValue(100),
            ]),
        ];

        $this->assertSame(10, $this->resolveNamed($definitions, [])['limit']->value);
        $this->assertSame(100, $this->resolveNamed($definitions, ['mode' => 'detailed'])['limit']->value);
    }

    public function testAFulfilledConditionChangesTheOptions(): void
    {
        $definitions = [
            PropertyDTO::create('source', 'log', 'string'),
            PropertyDTO::create('range', '1h', 'string', ui: ['options' => ['1h' => 'Stunde']], conditions: [
                PropertyConditionDTO::when('source', 'tracking')->thenOptions(['1d' => 'Tag', '7d' => 'Woche']),
            ]),
        ];

        $resolved = $this->resolveNamed($definitions, ['source' => 'tracking'])['range'];

        $this->assertSame(['1d' => 'Tag', '7d' => 'Woche'], $resolved->ui['options']);
        // The rest of the ui bag is left alone by an effect that only speaks
        // about the options.
        $this->assertNull($resolved->ui['input']);
    }

    public function testAFulfilledConditionTakesThePropertyOffTheMask(): void
    {
        $definitions = [
            PropertyDTO::create('useDefaults', true, 'bool', isOptional: true),
            PropertyDTO::create('limit', 10, 'int', conditions: [
                PropertyConditionDTO::when('useDefaults', true)->thenHidden(),
            ]),
        ];

        $this->assertFalse($this->resolveNamed($definitions, ['useDefaults' => true])['limit']->isVisible);
        $this->assertTrue($this->resolveNamed($definitions, ['useDefaults' => false])['limit']->isVisible);
    }

    public function testAFulfilledConditionChangesWhetherThePropertyIsInsistedOn(): void
    {
        $definitions = [
            PropertyDTO::create('mode', 'simple', 'string'),
            PropertyDTO::create('endpoint', '', 'string', isOptional: true, conditions: [
                PropertyConditionDTO::when('mode', 'remote')->thenRequired()->thenLabel('Endpunkt (Pflicht)'),
            ]),
        ];

        $resolved = $this->resolveNamed($definitions, ['mode' => 'remote'])['endpoint'];

        $this->assertFalse($resolved->isOptional);
        $this->assertSame('Endpunkt (Pflicht)', $resolved->label);
        $this->assertTrue($this->resolveNamed($definitions, ['mode' => 'simple'])['endpoint']->isOptional);
    }

    public function testTheDeclarationSurvivesTheConditionsThatWereAppliedToIt(): void
    {
        $definition = PropertyDTO::create('limit', 10, 'int', conditions: [
            PropertyConditionDTO::when('mode', 'detailed')->thenValue(100),
        ]);

        $resolved = new PropertyConditionResolver()->resolveOne($definition, ['mode' => 'detailed']);

        $this->assertSame(100, $resolved->value);
        $this->assertSame(10, $resolved->declaredDefinition()->value);
    }

    public function testAnUnknownEffectIsRejectedWhereItIsDeclared(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        PropertyConditionDTO::when('mode', 'detailed')->then(['valeu' => 100]);
    }

    // ── how the clauses are joined ───────────────────────────────────────────

    public function testEveryClauseOfAnAndConditionHasToBeFulfilled(): void
    {
        $definitions = [
            PropertyDTO::create('mode', '', 'string'),
            PropertyDTO::create('source', '', 'string'),
            PropertyDTO::create('limit', 10, 'int', conditions: [
                PropertyConditionDTO::when('mode', 'detailed')->andWhen('source', 'log')->thenValue(100),
            ]),
        ];

        $this->assertSame(10, $this->resolveNamed($definitions, ['mode' => 'detailed'])['limit']->value);
        $this->assertSame(100, $this->resolveNamed($definitions, ['mode' => 'detailed', 'source' => 'log'])['limit']->value);
    }

    public function testOneClauseOfAnOrConditionIsEnough(): void
    {
        $definitions = [
            PropertyDTO::create('source', '', 'string'),
            PropertyDTO::create('limit', 10, 'int', conditions: [
                PropertyConditionDTO::when('source', 'log')->orWhen('source', 'tracking')->thenValue(100),
            ]),
        ];

        $this->assertSame(100, $this->resolveNamed($definitions, ['source' => 'tracking'])['limit']->value);
        $this->assertSame(10, $this->resolveNamed($definitions, ['source' => 'chat'])['limit']->value);
    }

    public function testMixingAndWithOrInOneConditionIsRejected(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        PropertyConditionDTO::when('a', 1)->orWhen('b', 2)->andWhen('c', 3);
    }

    public function testTheLastFulfilledConditionHasTheSay(): void
    {
        $definitions = [
            PropertyDTO::create('mode', '', 'string'),
            PropertyDTO::create('limit', 10, 'int', conditions: [
                PropertyConditionDTO::when('mode', 'detailed')->thenValue(100),
                PropertyConditionDTO::when('mode', 'detailed')->thenValue(200),
            ]),
        ];

        $this->assertSame(200, $this->resolveNamed($definitions, ['mode' => 'detailed'])['limit']->value);
    }

    // ── the values the conditions are read against ───────────────────────────

    public function testAConditionReadsWhatTheMaskSubmitted(): void
    {
        $definitions = [
            PropertyDTO::create('compact', false, 'bool'),
            PropertyDTO::create('limit', 10, 'int', conditions: [
                // A checkbox arrives as "1", a number as "80" - a condition
                // still means the value the property declared.
                PropertyConditionDTO::when('compact', true)->thenValue(5),
            ]),
        ];

        $this->assertSame(5, $this->resolveNamed($definitions, ['compact' => '1'])['limit']->value);
    }

    public function testAConditionMayNameSeveralValuesAtOnce(): void
    {
        $definitions = [
            PropertyDTO::create('source', '', 'string'),
            PropertyDTO::create('limit', 10, 'int', conditions: [
                PropertyConditionDTO::when('source', ['log', 'tracking'])->thenValue(100),
            ]),
        ];

        $this->assertSame(100, $this->resolveNamed($definitions, ['source' => 'log'])['limit']->value);
        $this->assertSame(10, $this->resolveNamed($definitions, ['source' => 'chat'])['limit']->value);
    }

    public function testAConditionMayCompareTheOrderOfNumbers(): void
    {
        $definitions = [
            PropertyDTO::create('limit', 10, 'int'),
            PropertyDTO::create('hint', '', 'string', isOptional: true, conditions: [
                PropertyConditionDTO::whenAll([
                    PropertyConditionClauseDTO::create('limit', 100, eConditionType::GREATER_THAN),
                ])->thenDescription('Viele Zeilen werden langsam geladen.'),
            ]),
        ];

        $this->assertSame(
            'Viele Zeilen werden langsam geladen.',
            $this->resolveNamed($definitions, ['limit' => '250'])['hint']->description
        );
        $this->assertSame('', $this->resolveNamed($definitions, ['limit' => '50'])['hint']->description);
    }

    public function testADottedPropertyIsReadOutOfTheNestedValues(): void
    {
        $definitions = [
            PropertyDTO::create('source.entity', '', 'string'),
            PropertyDTO::create('source.keyFilter', '', 'string', isOptional: true, conditions: [
                PropertyConditionDTO::when('source.entity', 'SystemLog')->thenValue('checkout'),
            ]),
        ];

        $resolved = $this->resolveNamed($definitions, ['source' => ['entity' => 'SystemLog']]);

        $this->assertSame('checkout', $resolved['source.keyFilter']->value);
    }

    /**
     * A condition may look at a property whose own default a condition changed,
     * which only settles once the values stopped moving.
     */
    public function testAConditionSeesTheDefaultAnotherConditionSet(): void
    {
        $definitions = [
            PropertyDTO::create('mode', 'detailed', 'string'),
            PropertyDTO::create('limit', 10, 'int', conditions: [
                PropertyConditionDTO::when('mode', 'detailed')->thenValue(100),
            ]),
            PropertyDTO::create('hint', '', 'string', isOptional: true, conditions: [
                PropertyConditionDTO::when('limit', 100)->thenValue('Viele Zeilen'),
            ]),
        ];

        $this->assertSame('Viele Zeilen', $this->resolveNamed($definitions, [])['hint']->value);
    }

    public function testConditionsThatKeepContradictingEachOtherStillReturn(): void
    {
        $definitions = [
            PropertyDTO::create('a', 0, 'int', conditions: [
                PropertyConditionDTO::when('b', 0)->thenValue(1),
                PropertyConditionDTO::when('b', 1)->thenValue(0),
            ]),
            PropertyDTO::create('b', 0, 'int', conditions: [
                PropertyConditionDTO::when('a', 1)->thenValue(1),
                PropertyConditionDTO::when('a', 0)->thenValue(0),
            ]),
        ];

        $resolved = $this->resolveNamed($definitions, []);

        $this->assertContains($resolved['a']->value, [0, 1]);
    }

    public function testPropertiesWithoutConditionsAreHandedBackUntouched(): void
    {
        $definitions = [PropertyDTO::create('limit', 10, 'int')];

        $this->assertSame($definitions, new PropertyConditionResolver()->resolve($definitions, ['limit' => 20]));
    }

    /**
     * @param PropertyDTO[] $definitions
     *
     * @return array<string, PropertyDTO>
     */
    private function resolveNamed(array $definitions, array $values): array
    {
        $resolved = [];

        foreach (new PropertyConditionResolver()->resolve($definitions, $values) as $definition) {
            $resolved[$definition->name] = $definition;
        }

        return $resolved;
    }
}
