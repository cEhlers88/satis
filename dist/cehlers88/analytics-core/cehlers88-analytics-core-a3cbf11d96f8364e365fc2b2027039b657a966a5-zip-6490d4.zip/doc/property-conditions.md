# Property Conditions

A `PropertyDTO` describes one setting: a widget setting, a monitoring rule argument, a command
property. A **condition** says what that property looks like *while other properties hold certain
values* — another default, another list of options, a property that is off the mask or is suddenly
insisted on.

Conditions are declared next to the property, evaluated on the server by
`Support\Property\PropertyConditionResolver`, and evaluated again in the browser by
`assets/Property/PropertyConditions.ts` in the application shell, so a mask never asks for something
the server would drop.

---

## Declaring

```php
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;

public function getSettingDefinitions(): array
{
    return [
        PropertyDTO::create(
            name: 'mode',
            value: 'simple',
            type: 'string',
            label: 'Modus',
            ui: ['options' => ['simple' => 'Einfach', 'detailed' => 'Detailliert']]
        ),

        PropertyDTO::create(
            name: 'limit',
            value: 10,
            type: 'int',
            isOptional: true,
            label: 'Zeilen',
            ui: ['min' => 1, 'max' => 500],
            conditions: [
                // A different default - and a setting that has to be answered -
                // for the detailed mode.
                PropertyConditionDTO::when('mode', 'detailed')
                    ->thenValue(100)
                    ->thenRequired(),
            ]
        ),

        PropertyDTO::create(
            name: 'endpoint',
            value: '',
            type: 'string',
            isOptional: true,
            label: 'Endpunkt',
            conditions: [
                // Only the remote mode has an endpoint at all.
                PropertyConditionDTO::when('mode', 'remote', eConditionType::NOT_EQUALS)
                    ->thenHidden(),
            ]
        ),
    ];
}
```

A property that is declared elsewhere can be given a condition afterwards:

```php
$definition = $definition->withConditions(
    PropertyConditionDTO::when('source', 'tracking')->thenOptions(['1d' => 'Tag', '7d' => 'Woche'])
);
```

## The clauses

`PropertyConditionDTO::when($property, $value, $type)` opens a condition with one clause;
`->andWhen(...)` and `->orWhen(...)` add further ones. A condition joins its clauses **one way** —
mixing `and` with `or` throws, use two conditions instead. `whenAll()` / `whenAny()` take a list of
`PropertyConditionClauseDTO`s for the same thing.

The `$property` of a clause is the name of another property, a dotted one (`source.entity`)
included. `$type` is an `eConditionType`:

| Type                                          | Fulfilled while                                                          |
|-----------------------------------------------|--------------------------------------------------------------------------|
| `EQUALS` / `NOT_EQUALS`                       | the value is (not) the expected one; a **list** as expected value means "one of" |
| `GREATER_THAN`, `GREATER_THAN_OR_EQUALS`, …   | numbers by their size, everything else by its text                        |
| `CONTAINS` / `NOT_CONTAINS`                   | a list holds the value, or a text holds the substring                     |
| `STARTS_WITH` / `ENDS_WITH`                   | the text begins / ends with the expected one                              |
| `AND`, `OR`, `XOR`                            | no comparison — these say how the clauses of a condition are joined        |

The comparison is deliberately lenient, because the values of a mask arrive as strings: `"1"` is the
`true` a checkbox declared, `"10"` is the `10` a number declared.

## The effects

| Effect                    | Method                            | Meaning                                              |
|---------------------------|-----------------------------------|------------------------------------------------------|
| `value`                   | `thenValue($value)`               | The default value while the condition holds          |
| `visible`                 | `thenHidden()` / `thenVisible()`  | Whether the property is on the mask at all           |
| `isOptional`              | `thenRequired()` / `thenOptional()` | Whether it has to be answered                      |
| `label`                   | `thenLabel($label)`               | Another label                                        |
| `description`             | `thenDescription($text)`          | Another hint under the field                         |
| `ui`                      | `thenOptions($options)`, `thenUi($ui)` | Merged into the ui bag — options, min, max, input, class |

`then([...])` takes the effects as an array and rejects an unknown key rather than ignoring it.
Several conditions on one property are applied in the order they are declared, so a later one
overrides an earlier one; `ui` is merged rather than replaced.

## What the effects mean for the stored values

`Widget\WidgetSettings` works on the properties as their conditions leave them:

- **A default a condition set is stored** — even for an optional setting nobody filled in. The
  condition names the default for exactly this case, unlike the fallback the widget would pick.
- **A property that is off the mask keeps its (resolved) default** and a value submitted for it is
  ignored — it is not the client's business to fill in a field nobody can see.
- **A property that is off the mask is never insisted on**, and one a condition made required is.
- **Only the options a condition put there are accepted**; anything else falls back to the default.

## Resolving

```php
use Cehlers88\AnalyticsCore\Support\Property\PropertyConditionResolver;

$resolved = new PropertyConditionResolver()->resolve($definitions, $values);   // PropertyDTO[]
$one      = new PropertyConditionResolver()->resolveOne($definition, $values); // PropertyDTO
```

`WidgetSettings::resolve()` and `Provider\WidgetProvider::getResolvedSettingDefinitions()` are the
usual ways in; `normalize()` and `findUnsatisfied()` resolve on their own.

A resolved property is a copy: `declaredDefinition()` hands back the property as it was declared,
and `valueIsConditional()` says whether its default is one a condition put there. A condition may
look at a property whose own default a condition changed, so the values are resolved again until
they stop moving — and after ten rounds regardless, because a declaration that never settles is a
bug in the declaration.

## In the mask

`templates/widget/_settingFields.html.twig` renders the properties the way the stored values leave
them and hands the declaration along as `data-setting-conditions`, which the `<setting-fields>`
element of the application shell evaluates again on every edit: a field that no longer applies
disappears, a default that belongs to a case arrives with the case, a selection is rebuilt. A value
somebody typed is theirs and is never overwritten.

`PropertyDTO::toDefinitionArray()` is that description as plain data — the same payload the
monitoring-rule mask of the application shell builds its fields from.
