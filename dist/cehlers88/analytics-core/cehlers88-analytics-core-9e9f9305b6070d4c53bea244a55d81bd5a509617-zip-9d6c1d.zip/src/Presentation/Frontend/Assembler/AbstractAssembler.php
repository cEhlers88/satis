<?php

namespace Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ViewInterface;

/** Base class for assemblers that convert entities to views. */
abstract class AbstractAssembler implements AssemblerInterface
{
    public function many(iterable $entities): array
    {
        $buffer = [];
        foreach ($entities as $entity) {
            $buffer[] = $this->one($entity);
        }
        return $buffer;
    }

    abstract public function one(EntityInterface $entity): ViewInterface;

    abstract public function canHandle(string $className): bool;
}