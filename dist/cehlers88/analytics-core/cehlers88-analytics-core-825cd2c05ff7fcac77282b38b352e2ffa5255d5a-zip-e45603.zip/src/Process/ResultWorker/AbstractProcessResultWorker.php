<?php

namespace Cehlers88\AnalyticsCore\Process\ResultWorker;

use Cehlers88\AnalyticsCore\Entity\Process;
use Cehlers88\AnalyticsCore\ENUM\State\eRunningState;
use Cehlers88\AnalyticsCore\Process\Runner\ProcessRunnerInterface;
use Cehlers88\AnalyticsCore\Support\AbstractPropertyBag;

/** Base class for process result workers. */
abstract class AbstractProcessResultWorker extends AbstractPropertyBag implements ProcessResultWorkerInterface
{
    /** @var Process */
    protected Process $process;

    private int $statusCode = -1;
    private ProcessRunnerInterface $runner;

    /**
     * Run the result worker for the given process.
     *
     * @param Process $process
     * @param mixed $result
     * @param int $statusCode
     * @return static
     */
    public function run(Process $process, mixed $result, int $statusCode = -1): static
    {
        echo "Running result worker for process {$process->getId()}\n";
        $this
            ->setProcess($process)
            ->setStatusCode($statusCode)
            ->handleResult($result);

        $this->process
            ->removeState(eRunningState::ProcessingResult)
            ->addState(eRunningState::ResultProcessed);

        return $this;
    }

    public function setStatusCode(int $statusCode): static
    {
        $this->statusCode = $statusCode;
        return $this;
    }

    /** Set the process entity. */
    public function setProcess(Process $process): static
    {
        $this->process = $process;
        return $this;
    }

    public function setRunner(ProcessRunnerInterface $runner): static
    {
        $this->runner = $runner;
        return $this;
    }
}