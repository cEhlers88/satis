<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 06.09.2024
 * Time: 03:25
 */

namespace Cehlers88\AnalyticsCore\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\ValidationResultDTO;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Symfony\Component\HttpFoundation\Request;

abstract class AbstractServiceEndpointRunner implements ServiceEndpointRunnerInterface
{
    protected bool $hasError = false;
    protected ?string $errorMessage = null;
    protected ?User $user = null;

    private array $rawEndpoints = [];

    /** @var EndpointDefinitionDTO[]|null */
    private ?array $endpointDefinitions = null;

    public function canHandle(string $endpoint, Request $request): bool
    {
        foreach ($this->getEndpointDefinitions() as $endpointDefinition) {
            if (
                ($endpointDefinition->name === $endpoint || in_array($endpoint, $endpointDefinition->aliases))
                && in_array($request->getMethod(), $endpointDefinition->methods)
            ) {
                return true;
            }
        }

        return false;
    }

    final public function getEndpointDefinitions(): array
    {
        if (is_null($this->endpointDefinitions)) {
            $this->_generateEndpointDefinitions();
        }
        return $this->endpointDefinitions;
    }

    private function _generateEndpointDefinitions(): void
    {
        $this->endpointDefinitions = [];

        $endpoints = $this->getEndpoints();
        if (is_string($endpoints)) {
            $endpoints = [$endpoints];
        }

        $namePrefix = empty($this->getBundleName()) ? '' : $this->getBundleName() . '.';

        foreach ($endpoints as $endpoint) {
            if (is_string($endpoint)) {
                $dto = new EndpointDefinitionDTO();
                $dto->name = $endpoint;
                $dto->methods = ['GET', 'POST'];
            } else if ($endpoint instanceof EndpointDefinitionDTO) {
                $dto = $endpoint;
            } else {
                throw new \InvalidArgumentException('Invalid endpoint definition');
            }

            $dto->name = $namePrefix . $dto->name;

            $this->endpointDefinitions[] = $dto;
        }
    }

    public function getEndpoints(): mixed
    {
        return $this->rawEndpoints;
    }

    public function getBundleName(): string
    {
        return '';
    }

    public function runEndpoint(string $endpointName, Request $request): ServiceEndpointRunnerResultDTO
    {
        if (!$this->checkUserIsAllowedToRunEndpoint()) {
            return ServiceEndpointRunnerResultDTO::createError('Permission denied', 401);
        }

        $validationResult = $this->validate($endpointName, $request);
        if (!$validationResult->isValid) {
            return ServiceEndpointRunnerResultDTO::createError(
                'Invalid' . (!empty($validationResult->message) ? ': ' . $validationResult->message : '')
            );
        }

        return $this->handleRequest($endpointName, $request);
    }

    private function checkUserIsAllowedToRunEndpoint(): bool
    {
        if (count($this->getRequiredRoles()) === 0) {
            return true;
        }
        if (is_null($this->getUser())) {
            return false;
        }
        if ($this->getUser()->hasRole('ROLE_ADMIN')) {
            return true;
        }

        $notAllowedRoles = array_diff($this->getRequiredRoles(), $this->getUser()->getRoles());
        return count($notAllowedRoles) === 0;
    }

    public function getRequiredRoles(): array
    {
        return [];
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): AbstractServiceEndpointRunner
    {
        $this->user = $user;
        return $this;
    }

    public function validate(string $endpointName, Request $request): ValidationResultDTO
    {
        $requestData = $request->isMethod('GET')
            ? $request->query->all()
            : ($request->getContent() !== '' ? $request->toArray() : $request->request->all());

        foreach ($this->getEndpointDefinitions() as $endpointDefinition) {
            if ($endpointDefinition->name === $endpointName || in_array($endpointName, $endpointDefinition->aliases)) {
                foreach ($endpointDefinition->parameters as $parameter) {
                    if ($parameter->isOptional) continue;
                    if (!array_key_exists($parameter->name, $requestData)) return ValidationResultDTO::create(false, 'Missing parameter \'' . $parameter->name . '\'');
                }
                return ValidationResultDTO::create(true);
            }
        }
        return ValidationResultDTO::create(false, 'Endpoint not found');
    }

    public function handleRequest(string $endpointName, Request $request): ServiceEndpointRunnerResultDTO
    {
        $requestData = $request->isMethod('GET')
            ? $request->query->all()
            : ($request->getContent() !== '' ? $request->toArray() : $request->request->all());

        foreach ($this->getEndpointDefinitions() as $endpointDefinition) {
            if (
                ($endpointDefinition->name === $endpointName ||
                    in_array($endpointName, $endpointDefinition->aliases))
                &&
                in_array($request->getMethod(), $endpointDefinition->methods)
            ) {
                return call_user_func($endpointDefinition->handler, $requestData);
            }
        }
        return ServiceEndpointRunnerResultDTO::createError('Not implemented');
    }

    public function getDescription(string $endpointName, array $methods): string
    {
        foreach ($this->getEndpointDefinitions() as $endpointDefinition) {
            if ($endpointDefinition->name === $endpointName) {
                foreach ($methods as $method) {
                    if (in_array($method, $endpointDefinition->methods)) {
                        return $endpointDefinition->description;
                    }
                }
            }
        }
        return '';
    }

    public function getErrorMessage(): ?string
    {
        return $this->errorMessage;
    }

    public function hasError(): bool
    {
        return $this->hasError;
    }

    public function setError(?string $errorMessage = null): AbstractServiceEndpointRunner
    {
        $this->hasError = !is_null($errorMessage);
        $this->errorMessage = $errorMessage;
        return $this;
    }

    protected function registerEndpoint(EndpointDefinitionDTO $endpointDefinition): AbstractServiceEndpointRunner
    {
        $this->rawEndpoints[] = $endpointDefinition;
        return $this;
    }
}