<?php

namespace Cehlers88\AnalyticsCore\Support;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Support\Error\AbstractErrorBag;

abstract class AbstractPropertyHolder extends AbstractPropertyBag
{

    /*public function loadPropertyValues(array $properties, bool $allowCreation = false): static
    {
        $this->propertyLoads = $properties;
        foreach ($properties as $key => $valueDef) {
            try {
                $this->setPropertyValue($valueDef[1], $valueDef[2]);
            } catch (\InvalidArgumentException $e) {
                if (!$allowCreation) {
                    throw $e;
                }
                $property = PropertyDTO::create($valueDef[1], $valueDef[2], $valueDef[0]);
                $property->isDefaultValue = false;
                $this->addProperty($property);
            }
        }

        return $this;
    }

    public function setPropertyValue(string $name, mixed $value): static
    {
        foreach ($this->properties as $property) {
            if ($property->name === $name) {
                $property->isDefaultValue = $property->isDefaultValue && ($property->value === $value);
                $property->value = $value;
                return $this;
            }
        }

        throw new \InvalidArgumentException(sprintf('Property "%s" does not exist', $name));
    }*/
}