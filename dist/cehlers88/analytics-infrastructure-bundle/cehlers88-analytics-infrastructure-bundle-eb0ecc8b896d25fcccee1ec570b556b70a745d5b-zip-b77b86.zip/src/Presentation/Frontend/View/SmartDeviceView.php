<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ViewInterface;

/** View representation of an Application entity. */
class SmartDeviceView extends CustomObjectView implements ViewInterface
{

}