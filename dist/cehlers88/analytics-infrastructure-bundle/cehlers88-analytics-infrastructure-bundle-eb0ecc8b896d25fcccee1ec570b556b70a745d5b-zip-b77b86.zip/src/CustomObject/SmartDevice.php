<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;

class SmartDevice extends AbstractCustomObject
{
    public function getTileTemplate(): ?string
    {
        switch ($this->getDeviceType()) {
            case 'environment':
                return 'customObject/tile/smartDevice_environment.html.twig';
            case 'plotter_3d':
                return 'customObject/tile/smartDevice_plotter.html.twig';
            case 'power_adapter':
                return 'customObject/tile/smartDevice_power_adapter.html.twig';
            case 'sensor':
                return 'customObject/tile/smartDevice_sensor.html.twig';
        }
        return null;
    }

    public function getDeviceType(): string
    {
        return $this->getAttribute('device_type', '');
    }

    public function getTileDetails(): array
    {
        $result = ['childObjects' => []];

        return $result;
    }
}