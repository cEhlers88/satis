window.addEventListener('event-switch-changed', (e: any) => {
    switch (e.details.eventName) {
        case 'toggle-power':
            console.log('toggle-power');
            break;
    }
});