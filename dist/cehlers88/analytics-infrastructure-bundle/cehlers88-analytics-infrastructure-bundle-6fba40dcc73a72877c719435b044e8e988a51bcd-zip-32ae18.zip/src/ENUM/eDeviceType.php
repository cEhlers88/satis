<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 30.05.2024
 * Time: 18:02
 */

namespace Cehlers88\AnalyticsInfrastructureBundle\ENUM;

enum eDeviceType:int {
    case UNKNOWN = 0;
    case DESKTOP = 1;
    case LAPTOP = 2;
    case TABLET = 3;
    case SMARTPHONE = 4;
    case SERVER = 5;
    case NETWORK_DEVICE = 6;
    case PRINTER = 7;
    case SMART_HOME_DEVICE = 10;
    case SMART_TV = 11;
    case SMART_WATCH = 12;
    case SMART_GLASSES = 13;
    case SMART_SPEAKER = 14;
    case SMART_DISPLAY = 15;
    case SMART_SENSOR = 16;
    case SCANNER = 25;
    case CAMERA = 26;
    case GAMING_CONSOLE = 40;

    public static function getLabel(eDeviceType $type):string {
        return match ($type) {
            self::UNKNOWN => 'Unknown',
            self::DESKTOP => 'Desktop',
            self::LAPTOP => 'Laptop',
            self::TABLET => 'Tablet',
            self::SMARTPHONE => 'Smartphone',
            self::SERVER => 'Server',
            self::NETWORK_DEVICE => 'Network device',
            self::PRINTER => 'Printer',
            self::SMART_HOME_DEVICE => 'Smart home device',
            self::SMART_TV => 'Smart TV',
            self::SMART_WATCH => 'Smart watch',
            self::SMART_GLASSES => 'Smart glasses',
            self::SMART_SPEAKER => 'Smart speaker',
            self::SMART_DISPLAY => 'Smart display',
            self::SMART_SENSOR => 'Smart sensor',
            self::SCANNER => 'Scanner',
            self::CAMERA => 'Camera',
            self::GAMING_CONSOLE => 'Gaming console',
            default => 'Unknown'
        };
    }
}
