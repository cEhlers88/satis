# Changelog

## [0.1.16](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.15...v0.1.16) (2026-03-29)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.3.13 ([#32](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/32)) ([b35f566](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b35f566e5123bddbb0475fc5358296ee01006433))
* **deps:** update dependency cehlers88/analytics-core to v1.4.1 ([#34](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/34)) ([1ca5dd4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/1ca5dd4636bb58b87796a891a76aa0c986778eb4))
* **deps:** update dependency cehlers88/analytics-core to v1.6.0 ([#35](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/35)) ([ed23a1b](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/ed23a1bd02ed171466280e033b6af3f81f37f0eb))

## [0.1.15](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.14...v0.1.15) (2026-03-24)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.1.3 ([#28](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/28)) ([bade42f](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/bade42f6c3dd1d37859d74cfaa9e9259f3e453fa))
* **deps:** update dependency cehlers88/analytics-core to v1.3.5 ([#30](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/30)) ([b037900](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b037900f3d48ce30dbcabee9b2dfc1b673e6f23b))
* **deps:** update dependency cehlers88/analytics-core to v1.3.6 ([#31](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/31)) ([34bcf2c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/34bcf2cdf848e75375ffdebe72cad4eae5614482))
* Upgraded the analytics-core package to v1.3.7 to include the latest changes and improvements. Updated the associated reference, distribution URL, and checksum to match the new version. ([bddf86d](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/bddf86d6406c783d4529890d733f8f2401de2a65))

## [0.1.14](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.13...v0.1.14) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([37e24ac](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/37e24acb693d5b58d5eaacb2dc3f191319a7ceab))

## [0.1.13](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.12...v0.1.13) (2026-03-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.5.4 ([#23](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/23)) ([650b624](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/650b6240f080b128f9e9c489f29c6733f8776020))
* **deps:** update dependency cehlers88/analytics-core to v0.5.5 ([#24](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/24)) ([a87c32b](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a87c32b0c66ace0122d026f1a44f0be6a8934491))

## [0.1.12](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.11...v0.1.12) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.5 ([#21](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/21)) ([09957a0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/09957a0a91bfcf8302caf9bce8b54cdc77976b13))

## [0.1.11](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.10...v0.1.11) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.4.2 ([#19](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/19)) ([278691c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/278691c39e3c071681c040cda600d489024229ad))

## [0.1.10](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.9...v0.1.10) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([8ecdc76](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/8ecdc7624709e15b6bba8d9c04fc30c46ba5bfad))

## [0.1.9](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.8...v0.1.9) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([916b58c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/916b58c23d8847704f03c5770f37c8d909170d18))

## [0.1.8](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.7...v0.1.8) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.4 ([#15](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/15)) ([ca61503](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/ca61503589e3885b000bf1ba3affb3e75790f1d8))

## [0.1.7](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.6...v0.1.7) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.1 ([#13](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/13)) ([edb5436](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/edb5436e90dd7a9bac8febce5b72acd6cee40399))

## [0.1.6](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.5...v0.1.6) (2026-03-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#9](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/9)) ([6c384c0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/6c384c0ec5f37bb4f8b68fbac95f17ad3d2ad403))

## [0.1.5](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.4...v0.1.5) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.2 ([#7](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/7)) ([92be449](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/92be449445828f0ae85d0c42a733a0e0f4ff7373))

## [0.1.4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.3...v0.1.4) (2026-01-21)


### Miscellaneous Chores

* add GitHub workflow to trigger Satis rebuild on release ([7f77f56](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/7f77f56f68fe25a212e0c14c0a5f15bd57cceb29))
* **deps:** update dependency cehlers88/analytics-core to v0.1.5 ([#4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/4)) ([2270bbe](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/2270bbe68cc3c63a598a8b579dc7d8e0f907a1f1))

## [0.1.3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.2...v0.1.3) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([#2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/2)) ([605516c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/605516c331d6857b814273f0adbe6333c8a26f5e)) ([3da16e3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/3da16e312e59b09de63dd1a0d3c1c226407ce307))
## [0.1.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([a367bbd](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a367bbd335655fe509fe8c3f83609ac53da0520a))
