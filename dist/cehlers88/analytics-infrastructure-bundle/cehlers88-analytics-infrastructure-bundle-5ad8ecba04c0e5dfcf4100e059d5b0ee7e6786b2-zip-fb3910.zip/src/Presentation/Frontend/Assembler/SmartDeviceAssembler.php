<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\CustomObjectAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDevice;
use Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\View\SmartDeviceView;

class SmartDeviceAssembler extends CustomObjectAssembler
{
    protected string $viewClass = SmartDeviceView::class;

    public function canHandle(string $className): bool
    {
        return $className === SmartDevice::class;
    }

    /*public function assemble(EntityInterface|AbstractCustomObject $entity): ViewInterface
    {
        $attributes = [];



        $view = new SmartDeviceView(
            id: $entity->getId(),
            className: $entity->getClassName(),
            name: $entity->getName(),
            attributes: $attributes,
            childObjects: $this->many($entity->getChildObjects()),
        );


        $monitoringBuffer = [];

        foreach ($entity->getMonitorings() as $field => $monitorings) {
            $monitoringBuffer[$field] = $monitorings;
        }

        $view->monitorings = $monitoringBuffer;


        return $view;
    }*/

    protected function enrichView(EntityInterface|AbstractCustomObject $entity, CustomObjectView $view): CustomObjectView
    {
        $possibleChildIds = [
            'power_adapter_id',
            'heater_power_adapter_id'
        ];

        foreach ($possibleChildIds as $childId) {
            $id = $view->attributes[$childId] ?? null;

            if (!empty($id)) {
                $view->childObjects[] = $this->assembleView($this->customObjectProvider->getCustomObjectById($id));
            }
        }

        if (isset($view->attributes['software_version'])) {
            $view->titleBadgeText = $view->attributes['software_version'];
        }

        return $view;
    }
}