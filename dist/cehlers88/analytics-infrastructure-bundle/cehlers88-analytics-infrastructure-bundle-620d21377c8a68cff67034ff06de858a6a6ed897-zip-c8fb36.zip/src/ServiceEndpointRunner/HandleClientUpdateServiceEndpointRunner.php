<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Analytics\Recorder\TrackingRecorder;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\Entity\ClientDetails;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;
use Cehlers88\AnalyticsInfrastructureBundle\Configuration\GeneralConfigurationGroup;
use Symfony\Component\HttpFoundation\Request;

class HandleClientUpdateServiceEndpointRunner extends AbstractServiceEndpointRunner
{

    public function __construct(
        private TrackingRecorder      $trackingRecorder,
        private ClientRepository      $clientRepository,
        private ConfigurationProvider $configurationProvider
    )
    {
    }

    public function getEndpoints(): mixed
    {
        return "handle_client_update";
    }

    public function handleRequest(Request $request): mixed
    {
        $requestData = $request->toArray();
        $trackRequest = true;

        switch ($requestData['event']) {
            case 'cast_device_update':
                $snapshot = $requestData['snapshot'];

                $client = $this->clientRepository->getByIp($snapshot['host']);
                if (empty($client)) {
                    return ServiceEndpointRunnerResultDTO::createError('Client not found', 504);
                }
                $castInfo = new ClientDetails();
                $castInfo->setTag('cast_info');
                $castInfoExist = false;

                foreach ($client->getClientDetails() as $clientDetail) {
                    if ($clientDetail->getTag() === 'cast_info') {
                        $castInfo = $clientDetail;
                        $castInfoExist = true;
                        break;
                    }
                }
                $currentCastInfo = json_decode($castInfo->getInfos() ?? '[]', true);
                if ($currentCastInfo['title'] === $snapshot['title']) {
                    $trackRequest = false;
                }

                $castInfo->setInfos(json_encode($snapshot));

                if (!$castInfoExist) {
                    $client->addClientDetail($castInfo);
                }
                $this->clientRepository->add($client);


                break;
        }

        if ($trackRequest) {
            $this->trackingRecorder->track(
                $this->getCastsApplicationId(), [
                    'data' => $requestData,
                    'key' => 'CLIENT_UPDATE'
                ]
            );
        }

        return ServiceEndpointRunnerResultDTO::createSuccess($request->toArray(), 'Client-Update-Handler');
    }

    private function getCastsApplicationId(): int
    {
        return (int)$this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'castsApplicationId');
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }
}