<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 06.09.2024
 * Time: 03:51
 */

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Analytics\Recorder\TrackingRecorder;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\Entity\Client;
use Cehlers88\AnalyticsCore\Entity\ClientDetails;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;
use Cehlers88\AnalyticsInfrastructureBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsInfrastructureBundle\Entity\Device;
use Cehlers88\AnalyticsInfrastructureBundle\ENUM\eDeviceState;
use Cehlers88\AnalyticsInfrastructureBundle\ENUM\eDeviceType;
use Cehlers88\AnalyticsInfrastructureBundle\Repository\DeviceRepository;
use Symfony\Component\HttpFoundation\Request;

class HandleMqttUpdateServiceEndpointRunner extends AbstractServiceEndpointRunner
{
    public function __construct(
        private ApplicationRepository $applicationRepository,
        private ClientRepository      $clientRepository,
        private DeviceRepository      $deviceRepository,
        private TrackingRecorder      $trackingRecorder,
        private ConfigurationProvider $configurationProvider
    )
    {
    }

    public function handleRequest(Request $request): mixed
    {
        $responseText = 'handle_mqtt_update';
        if (!$this->validate()) {
            return ['error'];
        }

        $mqttApplication = $this->applicationRepository->find($this->getMqttApplicationId());
        $devices = json_decode($request->request->get('devices', '[]'), true);
        $deviceTrackInfos = [];

        foreach ($devices as $device) {
            unset($device['quickInfo']);
            $deviceTrackInfos[] = $device;

            if (!isset($device['stats'])) {
                continue;
            }
            $client = null;
            $stats = $device['stats'];
            $ip = '?.?.?.?';
            $mac = null;

            if (array_key_exists('ip', $stats) && !empty($stats['ip'])) {
                $ip = $stats['ip'];
                $client = $this->clientRepository->getByIp($ip);
            }

            if (!$client) {
                if (array_key_exists('mac', $stats)) {
                    $mac = $this->normalizeMac($stats['mac']);
                    $client = $this->clientRepository->getByMac($mac);
                }
            }

            if (!$client) {
                if (
                    array_key_exists('online', $stats) &&
                    $stats['online'] === 0
                ) {
                    continue;
                }

                $client = new Client();
                $client->setFirstVisit(new \DateTime());
            }

            $client
                ->setIp($ip)
                ->setMac($mac)
                ->setHostname(array_key_exists('hn', $device['stats']) ? $device['stats']['hn'] : null);

            if ($ip !== '?.?.?.?' || $mac !== null || $client->getHostname() !== null) {
                $mqttDetails = null;
                $generalDetails = null;
                $generalDetailsData = [
                    'service_urls' => []
                ];

                foreach ($client->getClientDetails() as $clientDetail) {
                    if ($clientDetail->getTag() === 'mqtt_device') {
                        $mqttDetails = $clientDetail;
                    }
                    if ($clientDetail->getTag() === 'general') {
                        $generalDetails = $clientDetail;
                    }
                }

                if (is_null($mqttDetails)) {
                    $mqttDetails = new ClientDetails();
                    $mqttDetails
                        ->setTag('mqtt_device');
                    $client->addClientDetail($mqttDetails);
                }
                if (is_null($generalDetails)) {
                    $generalDetails = new ClientDetails();
                    $generalDetails
                        ->setTag('general');
                    $client->addClientDetail($generalDetails);
                }

                $mqttDetails->setInfos(json_encode($device['stats']));

                $generalDetails->setInfos(json_encode($generalDetailsData));

                $this->clientRepository->add($client);
                $device['analyticsClientId'] = $client->getId();

                $this->_updateDeviceInfos($client, $device['stats']);
            }
        }

        if (count($deviceTrackInfos) > 0) {
            $this->trackingRecorder->track($mqttApplication, [
                "data" => [
                    "device_infos" => $deviceTrackInfos,
                ],
                "key" => "MQTT_TRACKING"
            ]);
        }

        return [$responseText];
    }

    public function validate(): bool
    {
        if ($this->getMqttApplicationId() > 0) {
            return true;
        }
        $this->setError('No valid application id configured for mqtt application.');
        return false;
    }

    private function getMqttApplicationId(): int
    {
        return (int)$this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'mqttApplicationId');
    }

    /**
     * Normalizes a MAC address to a format like "XX:XX:XX:XX:XX:XX"
     *
     * @param string $mac
     * @return string
     */
    private function normalizeMac(string $mac): string
    {
        $mac = strtoupper(str_replace(['-', '.'], '', $mac));
        $mac = preg_replace('/[^A-F0-9]/', '', $mac);

        return implode(':', str_split($mac, 2));
    }

    private function _updateDeviceInfos(Client $client, array $clientStats)
    {
        $deviceEntity = $this->deviceRepository->findOneBy(['client' => $client]);
        if ($deviceEntity === null) {
            $deviceEntity = new Device();
            $deviceEntity->setClient($client);
        }
        $deviceEntity
            ->setState($clientStats['online'] === 1 ? eDeviceState::ONLINE : eDeviceState::OFFLINE)
            ->setType(eDeviceType::SMART_SENSOR);

        $this->deviceRepository->add($deviceEntity);
    }

    public function getDescription(): string
    {
        return 'Verarbeitet mqtt-updates';
    }

    public function getEndpoints(): mixed
    {
        return "handle_mqtt_update";
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }
}