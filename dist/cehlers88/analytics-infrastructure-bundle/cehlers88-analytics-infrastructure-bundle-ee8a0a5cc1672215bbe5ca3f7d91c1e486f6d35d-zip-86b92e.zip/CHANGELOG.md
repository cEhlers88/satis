# Changelog

## [0.1.3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.2...v0.1.3) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([#2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/2)) ([605516c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/605516c331d6857b814273f0adbe6333c8a26f5e)) ([3da16e3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/3da16e312e59b09de63dd1a0d3c1c226407ce307))
## [0.1.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([a367bbd](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a367bbd335655fe509fe8c3f83609ac53da0520a))
