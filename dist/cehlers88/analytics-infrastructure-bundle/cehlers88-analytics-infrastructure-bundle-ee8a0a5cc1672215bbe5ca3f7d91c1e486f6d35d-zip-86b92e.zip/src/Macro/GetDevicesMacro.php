<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Macro;


use Cehlers88\AnalyticsInfrastructureBundle\Repository\DeviceRepository;

class GetDevicesMacro extends AbstractInfrastructureMacro {

    public function __construct(
        private DeviceRepository $deviceRepository
    ) {}

    protected function run(): ?array {
        return $this->_createRunResult($this->deviceRepository->findAll());
    }

    public function _init(): GetDevicesMacro {
        return $this;
    }

    public function getDescription(): string {
        return 'Get all registered devices.';
    }

    public function getName(): string {
        return 'getDevices';
    }
}