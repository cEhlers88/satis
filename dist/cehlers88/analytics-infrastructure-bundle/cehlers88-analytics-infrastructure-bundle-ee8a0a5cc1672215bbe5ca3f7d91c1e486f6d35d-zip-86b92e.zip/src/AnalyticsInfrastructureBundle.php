<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 12:00
 */
namespace Cehlers88\AnalyticsInfrastructureBundle;

use Analytics\AbstractBundlePlugin;
use Analytics\DTO\UI\MenuItemDTO;
use Cehlers88\AnalyticsInfrastructureBundle\ENUM\EPermission;

class AnalyticsInfrastructureBundle extends AbstractBundlePlugin {

    public function getDescription():string {
        return 'Bundle zur Verwaltung von verschiedenen Peripheriegeräten.';
    }
    public function getMenuItems():array {
        return [
            MenuItemDTO::create('Dokumentverwaltung', 'analytics_documents_documents', [], '', [])
        ];
    }
    public function getPermissions():array {
        return EPermission::getPermissions();
    }
    public function getVersion():string {
        return '1.0.0';
    }
    public function handleInstall():array {
        return [];
    }

    public static function getBundleName():string {
        return (new AnalyticsInfrastructureBundle())->getName();
    }
}