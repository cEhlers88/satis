<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Worker;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Worker\AbstractWorker;

class GrowboxManagementWorker extends AbstractWorker
{
    public function __construct()
    {
        $this
            ->addProperty(PropertyDTO::create('environment_device_id', 0, 'int'))
            ->addProperty(PropertyDTO::create('min_temp', 0, 'int', false, 'Min. Temperature'))
            ->addProperty(PropertyDTO::create('max_temp', 0, 'int'))
            ->addProperty(PropertyDTO::create('min_humidity', 0, 'int'))
            ->addProperty(PropertyDTO::create('max_humidity', 0, 'int'))
            ->addProperty(PropertyDTO::create('min_co2', 0, 'int'))
            ->addProperty(PropertyDTO::create('max_co2', 0, 'int'));
    }

    public function getWorkingObjects(): array
    {
        return [];
    }

    public function handleWorkingObjects($workingObjects): array
    {
        return [];
    }

    private function sendFanOnCommand(): void
    {
        $command = [
            'action' => 'fan_on',
            'until' => [
                [
                    'key' => 'temp',
                    'operator' => '>',
                    'value' => $this->getPropertyValue('min_temp', 0)
                ],
                [
                    'key' => 'co2',
                    'operator' => '>',
                    'value' => $this->getPropertyValue('min_co2', 0)
                ]
            ]
        ];
    }

    private function sendTempOnCommand(): void
    {
        $tempToReach = ($this->getPropertyValue('max_temp', 0) -
                $this->getPropertyValue('min_temp', 0)) / 2;
        $tempToReach += $this->getPropertyValue('min_temp', 0);

        $command = [
            'action' => 'temp_on',
            'until' => [
                [
                    'key' => 'temp',
                    'operator' => '<',
                    'value' => $tempToReach
                ]
            ]
        ];
    }

    private function sendWaterDustOnCommand(): void
    {
        $command = [
            'action' => 'water_dust_on',
            'until' => [
                [
                    'key' => 'humidity',
                    'operator' => '<',
                    'value' => $this->getPropertyValue('max_humidity', 0)
                ]
            ]
        ];
    }
}