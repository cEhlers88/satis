<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\ClientDetails;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Cehlers88\AnalyticsCore\Recorder\TrackingRecorder;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;
use Cehlers88\AnalyticsInfrastructureBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsInfrastructureBundle\CustomObject\LanService;
use Symfony\Component\HttpFoundation\Request;

class LanServiceInfoEndpointRunner extends AbstractServiceEndpointRunner
{
    private const array REQUIRED_ROLES = ['IS_LAN_DEVICE'];

    public function __construct(
        private CustomObjectProvider $customObjectProvider,
        private AssemblerProvider    $assemblerProvider,
    )
    {
        $this->registerEndpoint(EndpointDefinitionDTO::create('lan_service_info', ['POST'], [
            PropertyDTO::create('service_name', null, 'string')
        ], self::REQUIRED_ROLES, "Endpunkt zur Aufnahme von Serviceinformationen aus dem LAN.", [$this, 'handlePostServiceInfoRequest']));

        $this->registerEndpoint(EndpointDefinitionDTO::create('lan_service_info', ['GET'], [
            PropertyDTO::create('service_name', null, 'string')
        ], self::REQUIRED_ROLES, 'Endpunkt zum Abfragen von Informationen zu Services innerhalb des LAN', [$this, 'handleGetServiceInfoRequest']));
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }

    public function handleGetServiceInfoRequest(array $requestData): ServiceEndpointRunnerResultDTO
    {
        $serviceName = $requestData['service_name'];

        /** @var LanService $lanService */
        $lanService = $this->customObjectProvider->getCustomEntityByClassNameAndName(
            LanService::class,
            $serviceName,
            false
        );

        if (empty($lanService)) {
            return ServiceEndpointRunnerResultDTO::createError('Service \'' . $serviceName . '\' not found', 504);
        }

        return ServiceEndpointRunnerResultDTO::createSuccess(
            $this->assemblerProvider->getAssemblerForClass($lanService::class)
                ->one($lanService),
            'Get Service Info'
        );
    }

    public function handlePostServiceInfoRequest(array $requestData): ServiceEndpointRunnerResultDTO
    {
        $serviceName = $requestData['service_name'];

        $dateTime = new \DateTimeImmutable();

        /** @var LanService $lanService */
        $lanService = $this->customObjectProvider->getCustomEntityByClassNameAndName(
            LanService::class,
            $serviceName
        );

        if (empty($lanService)) {
            return ServiceEndpointRunnerResultDTO::createError('Service \'' . $serviceName . '\' not found', 504);
        }

        $lanService->setLastSeen($dateTime);

        return ServiceEndpointRunnerResultDTO::createSuccess($lanService, 'Get Service Info');
    }
}