<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

class LanService extends AbstractCustomObject
{
    public function setLastSeen(\DateTimeImmutable $lastSeen)
    {
        $this->setAttribute('lastSeen', $lastSeen->format('Y-m-d H:i:s'));
    }
}