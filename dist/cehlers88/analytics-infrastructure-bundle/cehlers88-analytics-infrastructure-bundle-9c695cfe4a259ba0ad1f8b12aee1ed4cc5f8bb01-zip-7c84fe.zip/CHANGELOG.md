# Changelog

## [1.6.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.5.0...v1.6.0) (2026-05-03)


### Features

* Style cast_info tile as a proper dashboard widget ([#65](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/65)) ([8a170c1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/8a170c1f27e47e5a2542bb99e23fabf1739ecf0a))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.5 ([#67](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/67)) ([1457604](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/14576048d742c545def02901e187395552491d45))

## [1.5.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.4.0...v1.5.0) (2026-05-03)


### Features

* Add cast_info template to display power state and debug data ([8304a43](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/8304a4353a85c92ba47b79eb623ab44d93d1b409))
* Add MQTT device template for displaying power state and data debug output ([d273cf5](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/d273cf56ee220ea6e2eb81711954cc1191e243b2))
* Improve mqtt_device dashboard tile: replace raw dump with structured smart-plug view ([#63](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/63)) ([49b910f](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/49b910f2924148cb77285c5f22b84bb64b700c6f))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.4 ([#60](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/60)) ([e4dd540](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/e4dd540b6fff7b79c1e115bca26aab5daa88c090))

## [1.4.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.3.1...v1.4.0) (2026-05-03)


### Features

* Improve tracking logic in service endpoint runners and refine `TrackingRecorder` usage ([762cc8c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/762cc8c90efc8ba107accae18922257ecf007d8c))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.2 ([#59](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/59)) ([014b774](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/014b77411ce11c03e2e01ec7fd8d82b41cce3ca0))
* Update branch alias format in composer.json files ([3ed87a0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/3ed87a0bca25ab9bb978a7f9df7d5d8daa3b9cc1))

## [1.3.1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.3.0...v1.3.1) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.1 ([#56](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/56)) ([784e9c6](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/784e9c67c798cd12af698b691eb3d76df36859c2))

## [1.3.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.2.0...v1.3.0) (2026-05-03)


### Features

* Add Chromecast application support to GeneralConfigurationGroup ([475b783](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/475b78329b1d1d84c338cad455520197d964928b))
* Enhance `HandleClientUpdateServiceEndpointRunner` to handle `cast_info` client details update logic ([6454c7c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/6454c7cbc3768162f19809974810195404c18bd1))
* Extend `HandleClientUpdateServiceEndpointRunner` with client fetching and application ID retrieval logic, update IP placeholder in `HandleMqttUpdateServiceEndpointRunner` ([7f5f855](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/7f5f855b4e8d95c22df4ad86f6c2a63e0f08154d))
* Refine `HandleClientUpdateServiceEndpointRunner` to skip redundant tracking for identical `cast_info` updates ([fc79de3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/fc79de3e703ca4cd552978e386bd182257befc77))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.25.1 ([#55](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/55)) ([5d4c114](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/5d4c1140650343c720625df88330bc7f32312219))
* Replace `AbstractServiceEndpointRunnerInterface` with `AbstractServiceEndpointRunner` in service runners and update `HandleClientUpdateServiceEndpointRunner` logic ([585937a](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/585937a537bc3e31f70d4392fbe0effa8aa60027))

## [1.2.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.1.3...v1.2.0) (2026-05-03)


### Features

* Add `HandleClientUpdateServiceEndpointRunner`, refactor `HandleMqttUpdateServiceEndpointRunner`, and enhance MQTT processing logic ([1013846](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/10138466dbd49aab43cc3740bc06daa39432ae34))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.23.1 ([#52](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/52)) ([b9da4ee](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b9da4ee9802bc07837516e1de3bc3f7fd9affcf4))

## [1.1.3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.1.2...v1.1.3) (2026-05-02)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.21.0 ([#49](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/49)) ([15b3a69](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/15b3a69b489d35392a9bcc3dd5da2a7b6f3941eb))
* **deps:** update dependency cehlers88/analytics-core to v1.22.1 ([#51](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/51)) ([f8f6a35](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/f8f6a35856a3e106faf81b0af328fe0c474d289d))

## [1.1.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.1.1...v1.1.2) (2026-04-26)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.20.0 ([#45](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/45)) ([7e52b8b](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/7e52b8b9c8664a1e818aa6b6e734feb0874123e6))
* **deps:** update googleapis/release-please-action action to v5 ([#47](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/47)) ([6bd1027](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/6bd1027b0e0970a2e16b4f856bf31f94cee61dbf))

## [1.1.1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.1.0...v1.1.1) (2026-04-20)


### Miscellaneous Chores

* Replace logWarning with setError in `FetchFritzboxClientListWorker` ([e8bfbca](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/e8bfbca42b172395969fd19770f5309adfadaac6))
* Update placeholder file to include latest analytics-core dependency adjustments ([de0c7a0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/de0c7a0ad2c8ab148046eb83e3fbf576d7b936d7))

## [1.1.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.0.2...v1.1.0) (2026-04-19)


### Features

* Refactor `FetchFritzboxClientListWorker` to enhance client fetching logic and integrate FritzBox TR-064 SOAP handling ([1568140](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/156814066b213ce2d91fee06efa21fc70bf33660))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.16.1 ([#41](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/41)) ([a5d46eb](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a5d46ebff5adf4c01100f58d02f4550d1c43273f))
* Upgrade analytics-core to v1.17.0 and update composer.lock with new reference, distribution URL, and checksum ([11b6579](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/11b6579623355a8219fdd7fb316a669bd6c7d942))

## [1.0.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.0.1...v1.0.2) (2026-04-13)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.15.0 ([#36](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/36)) ([067078a](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/067078a6df28faaeb432da8abdfcbec8898ba79b))
* **deps:** update dependency cehlers88/analytics-core to v1.16.0 ([#40](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/40)) ([442c22d](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/442c22d6923b202b7621ba1435f99f0a55dfb364))

## [1.0.1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.0.0...v1.0.1) (2026-04-06)


### Miscellaneous Chores

* Update analytics-core dependency to "1.*[@dev](https://github.com/dev)" and adjust branch alias to "1.x.x-dev" in composer.json ([d88b577](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/d88b5771b1e6085568555022a1fa86a6c85b508d))

## [1.0.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.16...v1.0.0) (2026-04-06)


### ⚠ BREAKING CHANGES

* Upgrade analytics-core to v1.11.0 and update method signature in HandleMqttUpdateServiceEndpointRunner

### Features

* Upgrade analytics-core to v1.11.0 and update method signature in HandleMqttUpdateServiceEndpointRunner ([dcb5aa2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/dcb5aa2361803d3eac8a1aee79444a5b667abf92))

## [0.1.16](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.15...v0.1.16) (2026-03-29)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.3.13 ([#32](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/32)) ([b35f566](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b35f566e5123bddbb0475fc5358296ee01006433))
* **deps:** update dependency cehlers88/analytics-core to v1.4.1 ([#34](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/34)) ([1ca5dd4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/1ca5dd4636bb58b87796a891a76aa0c986778eb4))
* **deps:** update dependency cehlers88/analytics-core to v1.6.0 ([#35](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/35)) ([ed23a1b](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/ed23a1bd02ed171466280e033b6af3f81f37f0eb))

## [0.1.15](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.14...v0.1.15) (2026-03-24)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.1.3 ([#28](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/28)) ([bade42f](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/bade42f6c3dd1d37859d74cfaa9e9259f3e453fa))
* **deps:** update dependency cehlers88/analytics-core to v1.3.5 ([#30](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/30)) ([b037900](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b037900f3d48ce30dbcabee9b2dfc1b673e6f23b))
* **deps:** update dependency cehlers88/analytics-core to v1.3.6 ([#31](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/31)) ([34bcf2c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/34bcf2cdf848e75375ffdebe72cad4eae5614482))
* Upgraded the analytics-core package to v1.3.7 to include the latest changes and improvements. Updated the associated reference, distribution URL, and checksum to match the new version. ([bddf86d](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/bddf86d6406c783d4529890d733f8f2401de2a65))

## [0.1.14](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.13...v0.1.14) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([37e24ac](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/37e24acb693d5b58d5eaacb2dc3f191319a7ceab))

## [0.1.13](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.12...v0.1.13) (2026-03-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.5.4 ([#23](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/23)) ([650b624](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/650b6240f080b128f9e9c489f29c6733f8776020))
* **deps:** update dependency cehlers88/analytics-core to v0.5.5 ([#24](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/24)) ([a87c32b](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a87c32b0c66ace0122d026f1a44f0be6a8934491))

## [0.1.12](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.11...v0.1.12) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.5 ([#21](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/21)) ([09957a0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/09957a0a91bfcf8302caf9bce8b54cdc77976b13))

## [0.1.11](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.10...v0.1.11) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.4.2 ([#19](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/19)) ([278691c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/278691c39e3c071681c040cda600d489024229ad))

## [0.1.10](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.9...v0.1.10) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([8ecdc76](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/8ecdc7624709e15b6bba8d9c04fc30c46ba5bfad))

## [0.1.9](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.8...v0.1.9) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([916b58c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/916b58c23d8847704f03c5770f37c8d909170d18))

## [0.1.8](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.7...v0.1.8) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.4 ([#15](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/15)) ([ca61503](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/ca61503589e3885b000bf1ba3affb3e75790f1d8))

## [0.1.7](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.6...v0.1.7) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.1 ([#13](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/13)) ([edb5436](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/edb5436e90dd7a9bac8febce5b72acd6cee40399))

## [0.1.6](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.5...v0.1.6) (2026-03-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#9](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/9)) ([6c384c0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/6c384c0ec5f37bb4f8b68fbac95f17ad3d2ad403))

## [0.1.5](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.4...v0.1.5) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.2 ([#7](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/7)) ([92be449](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/92be449445828f0ae85d0c42a733a0e0f4ff7373))

## [0.1.4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.3...v0.1.4) (2026-01-21)


### Miscellaneous Chores

* add GitHub workflow to trigger Satis rebuild on release ([7f77f56](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/7f77f56f68fe25a212e0c14c0a5f15bd57cceb29))
* **deps:** update dependency cehlers88/analytics-core to v0.1.5 ([#4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/4)) ([2270bbe](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/2270bbe68cc3c63a598a8b579dc7d8e0f907a1f1))

## [0.1.3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.2...v0.1.3) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([#2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/2)) ([605516c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/605516c331d6857b814273f0adbe6333c8a26f5e)) ([3da16e3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/3da16e312e59b09de63dd1a0d3c1c226407ce307))
## [0.1.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([a367bbd](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a367bbd335655fe509fe8c3f83609ac53da0520a))
