# AnalyticsInfrastructureBundle

A Symfony bundle for managing peripheral devices and infrastructure within the [Analytics](https://github.com/cEhlers88) platform. It provides MQTT device tracking, device state management, and seamless integration with the Analytics Core.

## Requirements

- PHP 8.1+
- Symfony 6.0+
- [`cehlers88/analytics-core`](https://github.com/cEhlers88/analytics-core) `^0.3`

## Installation

Install the bundle via Composer. Because the package is hosted on a private Satis repository, add the repository to your `composer.json` first:

```json
{
    "repositories": [
        {
            "type": "composer",
            "url": "https://cehlers88.github.io/satis"
        }
    ]
}
```

Then require the bundle:

```bash
composer require cehlers88/analytics-infrastructure-bundle
```

Register the bundle in your Symfony application (e.g. `config/bundles.php`):

```php
return [
    // ...
    Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle::class => ['all' => true],
];
```

## Database Setup

Run the Doctrine migrations to create the required `infrastructure_device` table:

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

## Configuration

The bundle exposes its settings through the Analytics Core configuration UI under the key `infrastructureBundle.general`. The following options are available:

| Option | Type | Description |
|---|---|---|
| `mqttApplicationId` | select | The Analytics application used to track MQTT device updates. |
| `networkBridges` | repeat | A list of network bridges (name + address) that act as gateways between networks. |

Example configuration (if set programmatically):

```yaml
# The configuration is managed through the Analytics UI,
# but the internal key used by the bundle is:
# infrastructureBundle.general
#
# mqttApplicationId: <id of the analytics application>
# networkBridges:
#   - name: "My Bridge"
#     address: "192.168.1.1"
```

## Features

### Device Tracking via MQTT

The bundle receives device lists from an MQTT source through the `handle_mqtt_update` service endpoint. For each device, it:

1. Looks up or creates a `Client` record by IP or MAC address.
2. Creates or updates a `Device` entity linked to that client.
3. Sets the device state to **Online** or **Offline** based on the payload.
4. Stores the raw MQTT stats as `ClientDetails` with the tag `mqtt_device`.
5. Records a tracking event via `TrackingRecorder` against the configured MQTT application.

#### MQTT Update Endpoint

**Endpoint name:** `handle_mqtt_update`

**Method:** `POST`

**Payload (form-encoded or JSON):**

```json
{
    "devices": [
        {
            "stats": {
                "ip":     "192.168.1.100",
                "mac":    "AA:BB:CC:DD:EE:FF",
                "hn":     "my-device",
                "online": 1
            }
        }
    ]
}
```

| Field | Type | Description |
|---|---|---|
| `stats.ip` | string | IP address of the device. |
| `stats.mac` | string | MAC address of the device. |
| `stats.hn` | string | Hostname of the device. |
| `stats.online` | int | `1` = online, `0` = offline. |

### Device Types (`eDeviceType`)

| Value | Label |
|---|---|
| `0` | Unknown |
| `1` | Desktop |
| `2` | Laptop |
| `3` | Tablet |
| `4` | Smartphone |
| `5` | Server |
| `6` | Network device |
| `7` | Printer |
| `10` | Smart home device |
| `11` | Smart TV |
| `12` | Smart watch |
| `13` | Smart glasses |
| `14` | Smart speaker |
| `15` | Smart display |
| `16` | Smart sensor |
| `25` | Scanner |
| `26` | Camera |
| `40` | Gaming console |

### Device States (`eDeviceState`)

| Value | Label |
|---|---|
| `0` | Unknown |
| `1` | Offline |
| `2` | Online |
| `3` | Error |

### Macros

#### `getDevices`

Returns all registered `Device` entities from the database.

**Usage in Analytics templates/reports:**

```
{{ macro('getDevices') }}
```

### Client Info Extender

The bundle automatically adds two columns to the Analytics client overview:

- **Device Type** – the type of the device (e.g. *Smart sensor*, *Laptop*).
- **Device State** – the current state of the device (e.g. *Online*, *Offline*).

### Permissions

| Permission | Description |
|---|---|
| `ACCESS_INFRASTRUCTURE` | Grants access to the Infrastructure module. |

## Project Structure

```
src/
├── AnalyticsInfrastructureBundle.php   # Bundle entry point
├── ClientInfoExtender/
│   └── DeviceClientInfoExtender.php    # Adds device columns to client overview
├── Configuration/
│   └── GeneralConfigurationGroup.php   # Bundle configuration (MQTT app, bridges)
├── ENUM/
│   ├── eDeviceState.php                # Device state enum (Unknown/Offline/Online/Error)
│   ├── eDeviceType.php                 # Device type enum (18 types)
│   └── EPermission.php                 # Bundle permission enum
├── Entity/
│   └── Device.php                      # Doctrine entity mapped to `infrastructure_device`
├── Macro/
│   ├── AbstractInfrastructureMacro.php # Base class for bundle macros
│   └── GetDevicesMacro.php             # Macro: returns all devices
├── Repository/
│   └── DeviceRepository.php            # Doctrine repository for Device
├── Resources/
│   └── config/
│       └── services.yaml               # Symfony DI configuration
├── ServiceEndpointRunner/
│   └── HandleMqttUpdateServiceEndpointRunner.php  # MQTT update handler
└── Worker/
    └── AnalyzeMqttDevicesWorker.php    # Background worker (planned)
```

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a full version history.

## License

This project is proprietary software. See [LICENSE](LICENSE) for details.
