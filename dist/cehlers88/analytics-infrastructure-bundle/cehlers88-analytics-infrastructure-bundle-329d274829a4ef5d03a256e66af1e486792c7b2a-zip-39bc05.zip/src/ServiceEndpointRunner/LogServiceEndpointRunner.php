<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;
use Cehlers88\AnalyticsInfrastructureBundle\ENUM\eRemoteLogLevel;
use Cehlers88\AnalyticsInfrastructureBundle\RemoteDebugger\RemoteLogStore;
use Cehlers88\AnalyticsInfrastructureBundle\Security\Role\IsLanDeviceRole;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Nimmt Log- und Fehlermeldungen von Geräten und Services aus dem lokalen Netz
 * entgegen und legt sie im {@see RemoteLogStore} ab, aus dem das
 * Remote-Debugger Tool sie anzeigt.
 */
class LogServiceEndpointRunner extends AbstractServiceEndpointRunner
{
    public function __construct(
        private readonly RemoteLogStore $remoteLogStore,
        private readonly RequestStack   $requestStack
    )
    {
        $parameterMessage = PropertyDTO::create('message', 'Dies ist die Nachricht, die geloggt wird', 'string');
        $parameterMessage->description = 'Message to log';

        $parameterData = PropertyDTO::create('data', ['foo' => 'xyz'], 'mixed', true);
        $parameterData->description = 'Data to log';

        $parameterGroupKey = PropertyDTO::create('groupKey', 'x/y/z', 'string', true);
        $parameterGroupKey->description = 'Key to group log entries';

        $this->registerEndpoint(EndpointDefinitionDTO::create(
            'log',
            ['POST'],
            [
                $parameterMessage,
                $parameterData,
                $parameterGroupKey,
                PropertyDTO::create('level', 'unknown', 'info | warning | debug', true),
            ],
            [],
            'Endpunkt zum loggen von Nachrichten innerhalb des lokalen Netzwerks',
            [$this, 'handleLogRequest']
        ));

        $this->registerEndpoint(EndpointDefinitionDTO::create(
            'error',
            ['POST'],
            [
                PropertyDTO::create('number', -1, 'int'),
                $parameterMessage,
                $parameterData,
                $parameterGroupKey,
                PropertyDTO::create('level', 'unknown', 'warning | exception | fatal | unknown', true),
                PropertyDTO::create('priority', 1, 'int', true)
            ],
            [],
            'Endpunkt zum loggen von Fehlern innerhalb des lokalen Netzwerks',
            [$this, 'handleErrorRequest']
        ));
    }


    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }

    public function getRequiredRoles(): array
    {
        return [
            RoleDTO::create(IsLanDeviceRole::NAME)
        ];
    }

    public function handleLogRequest(array $requestData): ServiceEndpointRunnerResultDTO
    {
        return $this->_storeEntry('log', $requestData, eRemoteLogLevel::INFO);
    }

    public function handleErrorRequest(array $requestData): ServiceEndpointRunnerResultDTO
    {
        return $this->_storeEntry('error', $requestData, eRemoteLogLevel::ERROR);
    }

    private function _storeEntry(string $type, array $requestData, eRemoteLogLevel $defaultLevel): ServiceEndpointRunnerResultDTO
    {
        try {
            $storedEntry = $this->remoteLogStore->append([
                'type' => $type,
                'level' => eRemoteLogLevel::fromValue($requestData['level'] ?? null, $defaultLevel)->value,
                'message' => $requestData['message'] ?? '',
                'data' => $requestData['data'] ?? null,
                'groupKey' => $requestData['groupKey'] ?? '',
                'number' => $requestData['number'] ?? null,
                'priority' => $requestData['priority'] ?? null,
                'source' => $this->requestStack->getCurrentRequest()?->getClientIp() ?? '',
            ]);
        } catch (\Throwable $throwable) {
            return ServiceEndpointRunnerResultDTO::createError(
                'Log entry could not be stored',
                500
            );
        }

        return ServiceEndpointRunnerResultDTO::createSuccess(
            [
                'id' => $storedEntry['id'],
                'sequence' => $storedEntry['sequence'],
                'level' => $storedEntry['level'],
                'receivedAt' => $storedEntry['receivedAt'],
            ],
            'Entry logged'
        );
    }
}
