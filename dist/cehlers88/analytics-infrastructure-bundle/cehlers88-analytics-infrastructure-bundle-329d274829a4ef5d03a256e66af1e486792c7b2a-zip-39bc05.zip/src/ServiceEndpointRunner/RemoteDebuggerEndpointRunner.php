<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;
use Cehlers88\AnalyticsInfrastructureBundle\ENUM\eRemoteLogLevel;
use Cehlers88\AnalyticsInfrastructureBundle\RemoteDebugger\RemoteLogStore;

/**
 * Serverseitiger Teil des Remote-Debugger Tools. Liefert die Logeinträge, die
 * entfernte Geräte an die Log-Endpunkte des Bundles geschickt haben, und leert
 * den Puffer auf Wunsch wieder.
 *
 * Das Tool fragt den Endpunkt beim Öffnen einmal vollständig ab und danach beim
 * automatischen Nachladen nur noch mit `since`, damit immer nur die neuen
 * Einträge über die Leitung gehen.
 */
class RemoteDebuggerEndpointRunner extends AbstractServiceEndpointRunner
{
    public function __construct(
        private readonly RemoteLogStore $remoteLogStore
    )
    {
        $parameterSince = PropertyDTO::create('since', 0, 'int', true);
        $parameterSince->description = 'Nur Einträge mit einer höheren Sequenznummer, für das Nachladen';

        $parameterLimit = PropertyDTO::create('limit', RemoteLogStore::DEFAULT_LIMIT, 'int', true);
        $parameterLimit->description = 'Anzahl der zurückgegebenen Einträge (max. ' . RemoteLogStore::MAX_LIMIT . ')';

        $parameterLevels = PropertyDTO::create('levels', [], 'array', true);
        $parameterLevels->description = 'Nur diese Level: ' . implode(', ', eRemoteLogLevel::getValues());

        $parameterGroupKey = PropertyDTO::create('groupKey', '', 'string', true);
        $parameterGroupKey->description = 'Gruppenschlüssel, wird als Präfix verglichen';

        $parameterSearch = PropertyDTO::create('search', '', 'string', true);
        $parameterSearch->description = 'Volltextsuche über Nachricht, Gruppe, Quelle und Daten';

        $logsEndpoint = EndpointDefinitionDTO::create(
            'remote_debugger_logs',
            ['GET', 'POST'],
            [
                $parameterSince,
                $parameterLimit,
                $parameterLevels,
                $parameterGroupKey,
                $parameterSearch,
            ],
            [],
            'Endpunkt zum Lesen der Logeinträge entfernter Geräte für das Remote-Debugger Tool.',
            [$this, 'handleLogsRequest']
        );
        $logsEndpoint->aliases = ['remoteDebuggerLogs'];

        $clearEndpoint = EndpointDefinitionDTO::create(
            'remote_debugger_clear',
            ['POST'],
            [],
            [],
            'Endpunkt zum Leeren des Logpuffers des Remote-Debugger Tools.',
            [$this, 'handleClearRequest']
        );
        $clearEndpoint->aliases = ['remoteDebuggerClear'];

        $this->registerEndpoint($logsEndpoint);
        $this->registerEndpoint($clearEndpoint);
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }

    public function getRequiredRoles(): array
    {
        return [
            RoleDTO::create('AUTHENTICATED_USER')
        ];
    }

    public function handleLogsRequest(array $requestData): ServiceEndpointRunnerResultDTO
    {
        $result = $this->remoteLogStore->read([
            'since' => is_numeric($requestData['since'] ?? null) ? (int)$requestData['since'] : 0,
            'limit' => is_numeric($requestData['limit'] ?? null) ? (int)$requestData['limit'] : RemoteLogStore::DEFAULT_LIMIT,
            'levels' => $this->_readLevels($requestData['levels'] ?? null),
            'groupKey' => is_scalar($requestData['groupKey'] ?? null) ? (string)$requestData['groupKey'] : '',
            'search' => is_scalar($requestData['search'] ?? null) ? (string)$requestData['search'] : '',
        ]);

        return ServiceEndpointRunnerResultDTO::createSuccess($result);
    }

    public function handleClearRequest(array $requestData): ServiceEndpointRunnerResultDTO
    {
        try {
            $removedCount = $this->remoteLogStore->clear();
        } catch (\Throwable $throwable) {
            return ServiceEndpointRunnerResultDTO::createError(
                'Log entries could not be removed',
                500
            );
        }

        return ServiceEndpointRunnerResultDTO::createSuccess(
            ['removed' => $removedCount],
            $removedCount . ' entries removed'
        );
    }

    /**
     * Die Level kommen je nach Aufrufer als Liste oder als kommagetrennte
     * Zeichenkette (`?levels=error,warning`) an.
     *
     * @return string[]
     */
    private function _readLevels(mixed $levels): array
    {
        if (is_string($levels)) {
            $levels = explode(',', $levels);
        }

        if (!is_array($levels)) {
            return [];
        }

        $knownLevels = eRemoteLogLevel::getValues();

        return array_values(array_filter(
            array_map(
                static fn(mixed $level): string => is_scalar($level) ? strtolower(trim((string)$level)) : '',
                $levels
            ),
            static fn(string $level): bool => in_array($level, $knownLevels, true)
        ));
    }
}
