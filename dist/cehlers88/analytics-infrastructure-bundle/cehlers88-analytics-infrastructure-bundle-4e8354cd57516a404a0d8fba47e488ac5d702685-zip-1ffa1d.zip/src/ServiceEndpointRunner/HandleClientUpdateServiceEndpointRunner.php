<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunnerInterface;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;
use Symfony\Component\HttpFoundation\Request;

class HandleClientUpdateServiceEndpointRunner extends AbstractServiceEndpointRunnerInterface
{

    public function getEndpoints(): mixed
    {
        return "handle_client_update";
    }

    public function handleRequest(Request $request): mixed
    {
        return "okay";
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }
}