<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 13.09.2024
 * Time: 12:32
 */

namespace Cehlers88\AnalyticsInfrastructureBundle\Worker;

use Analytics\Entity\AnalyticsDetails;
use Analytics\Entity\AnalyticsHeader;
use Analytics\Entity\Client;
use Analytics\Entity\TrackingBuffer;
use Analytics\Repository\AnalyticsDetailsRepository;
use Analytics\Repository\AnalyticsHeaderRepository;
use Analytics\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Worker\AbstractWorker;

class AnalyzeMqttDevicesWorker extends AbstractWorker
{/*
    private mixed $analyticsDetails = null;
    private mixed $previousLastFullHour = null;
    private string $previousHeaderTitle = '';
    public function __construct(
        protected TrackingBufferRepository $trackingBufferRepository,
        private AnalyticsDetailsRepository $analyticsDetailsRepository,
        private AnalyticsHeaderRepository $analyticsHeaderRepository
    )
    {

    }
    private function generateAnalyzeHeaderTitle($timestamp): string {
        $monthName = date('F', $timestamp);
        return 'MQTT DEVICES - ' . $monthName . ' ' . date('Y', $timestamp);
    }
    private function getAnalyticsDetailEntity($datetime):AnalyticsDetails{
        $lastFullHour = date('Y-m-d H:00:00', $datetime->getTimestamp());

        if($this->previousLastFullHour !== $lastFullHour) {
            $headerTitle = $this->generateAnalyzeHeaderTitle($datetime->getTimestamp());

            $analyticsHeader = $this->analyticsHeaderRepository->findOneBy(['title'=>$headerTitle]);

            if(!$analyticsHeader) {
                $previousHeader = $this->analyticsHeaderRepository->findOneBy(['title'=>$this->previousHeaderTitle]) ?? new AnalyticsHeader();
                $analyticsHeader = new AnalyticsHeader();
                $analyticsHeader
                    ->setCreatedAt($datetime)
                    ->setTitle($headerTitle)
                    ->setRequiredPermissions($previousHeader->getRequiredPermissions())
                    ->setClient($previousHeader->getClient())
                ;

                foreach ($previousHeader->getCategories() as $category){
                    $analyticsHeader->addCategory($category);
                }

                $this->analyticsHeaderRepository->save($analyticsHeader);
            }

            $found = false;
            foreach ($analyticsHeader->getAnalyticsDetails() as $analyticsDetail) {
                if($analyticsDetail->getCreatedAt()->format('Y-m-d H:00:00') === $lastFullHour){
                    $this->analyticsDetails = $analyticsDetail;
                    $found = true;
                }
            }

            if(!$found){
                $this->analyticsDetails = new AnalyticsDetails();
                $this->analyticsDetails
                    ->setAnalyticsHeader($analyticsHeader)
                    ->setCreatedAt(new \DateTime($lastFullHour))
                    ->setData([
                        'headers'=>[
                            ['name' => 'time', 'type'=> 'time']
                        ],
                        'subDataGroups'=>[
                            'entries' => [],
                            'relatesTo' => Client::class
                        ],
                        'data'=>[],
                    ])
                    ->setDataType('table_data')
                    ->setTags(['mqtt_device_infos'])
                    ;
            }
            $this->previousHeaderTitle = $headerTitle;
        }

        $this->previousLastFullHour = $lastFullHour;
        return $this->analyticsDetails;
    }

    private function insertDeviceInfosIntoDataTable($time, $deviceInfos, array $dataTable): array {
        $buffer = [];
        foreach ($deviceInfos as $deviceInfo){
            if(array_key_exists('analyticsClientId', $deviceInfo)){
                foreach ($deviceInfo['functions'] as $deviceFunction){
                    switch($deviceFunction['type']){
                        case 'sensor':
                            $sortIndex = -1;
                            if(!array_key_exists($deviceFunction['name'], $buffer)){
                                $buffer[$deviceFunction['name']] = [
                                    'suffix' => (isset($deviceFunction['unit']) ? $deviceFunction['unit'] : ''),
                                    'values' => []
                                ];
                            }

                            foreach ($dataTable['subDataGroups']['entries'] as $index => $entry){
                                if($entry === $deviceInfo['analyticsClientId']){
                                    $sortIndex = $index;
                                    break;
                                }
                            }

                            if($sortIndex === -1){
                                $sortIndex = count($dataTable['subDataGroups']['entries']);
                                $dataTable['subDataGroups']['entries'][] = $deviceInfo['analyticsClientId'];
                            }

                            $buffer[$deviceFunction['name']]['values'][] = [$sortIndex, $deviceFunction['value']];
                            break;
                        default:
                            //echo "unknwon typ".$deviceFunction['type'].PHP_EOL;
                    }
                }
            }
        }

        $newDataRow = [$time];
        foreach ($buffer as $name => $bufferEntry){
            $hIndex = -1;
            $values = $bufferEntry['values'];
            foreach ($dataTable['headers'] as $headerIndex => $header){
                if($header['name'] === $name){
                    $hIndex = $headerIndex;
                    break;
                }
            }
            if($hIndex === -1){
                $hIndex = count($dataTable['headers']);
                $dataTable['headers'][] = ['name' => $name, 'type' => 'number', 'suffix' => $bufferEntry['suffix']];
            }

            if(!isset($newDataRow[$hIndex])){
                $newDataRow[$hIndex] = [];
            }

            foreach ($values as $value){
                $newDataRow[$hIndex][$value[0]] = $value[1];
            }
        }
        $dataTable['data'][] = $newDataRow;

        return $dataTable;
    }

    public function handleWorkingObjects($workingObjects): array {
        $result = [];
        $this->previousLastFullHour = null;
        $this->getLogger()->progressStart(count($workingObjects));
        /** @var TrackingBuffer $workingObject *//*
        foreach ($workingObjects as $workingObject) {
            $workingObject->setState(eTrackingBufferState::IN_PROGRESS->value);
            $entity = $this->getAnalyticsDetailEntity($workingObject->getTimestamp());
            $entity->setData($this->insertDeviceInfosIntoDataTable(
                $workingObject->getTimestamp()->format('i:s'),
                $workingObject->getData()['device_infos'],
                $entity->getData()
            ));
            $this->analyticsDetailsRepository->save($entity);
            $workingObject->setState(eTrackingBufferState::PROCESSED_FINISHED->value);
            $this->getLogger()->progressAdvance();

        }
        return $result;
    }

    public function getName(): string {
        return "AnalyzeMqttDevicesWorker";
    }*/

    public function getWorkingObjects(): array
    {
        return [];
        //return $this->trackingBufferRepository->getUnfinished($this->getApplicationId(),100);
    }
}