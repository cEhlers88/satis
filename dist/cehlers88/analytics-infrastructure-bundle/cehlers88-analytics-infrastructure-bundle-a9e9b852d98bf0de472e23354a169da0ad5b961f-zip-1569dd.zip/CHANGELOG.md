# Changelog

## [1.20.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.19.0...v1.20.0) (2026-09-27)


### Features

* Standardize tool layouts and interactions with adaptable ribbon menus ([17867c4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/17867c4eea8aea33fcce9c6a8f514c7a65e9112f))

## [1.19.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.18.0...v1.19.0) (2026-09-26)


### Features

* Replace disparate toolbar implementations with unified ribbon menus in tools ([8182137](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/8182137fd6b1d5583e76b421b3a6ab58b2e859d4))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.42.7 ([#118](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/118)) ([5859e69](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/5859e69219416ab4cf74fef42815dcb0ea0d69ac))

## [1.18.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.17.1...v1.18.0) (2026-09-19)


### Features

* Add teaser SVG for AnalyticsInfrastructureBundle visuals ([cd2a37f](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/cd2a37fbe58fd999bf46bdbbf626385148f86aa1))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.42.5 ([#116](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/116)) ([4ce2ec9](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/4ce2ec997ca59d56a2985255ce9b6377caa0b3ba))

## [1.17.1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.17.0...v1.17.1) (2026-09-18)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.42.3 ([#114](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/114)) ([f5d43c3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/f5d43c37473e565c330f532f837a065f12590e32))

## [1.17.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.16.1...v1.17.0) (2026-09-13)


### Features

* Add `Remote Debugger` tool showing the logs of remote devices ([#113](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/113)) ([05ebefc](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/05ebefccc0f893b8067b1e4248908bb9a7a6c2f2))


### Bug Fixes

* Update `lanService.html.twig` and `LanServiceInfoEndpointRunner` for improved compatibility and cleanup ([c20bd3e](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/c20bd3ef1300561d5f589f06809348b1803777c7))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.42.0 ([#112](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/112)) ([4744688](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/4744688c924ffc173deac61acbf5099239881acc))

## [1.16.1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.16.0...v1.16.1) (2026-09-11)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.41.1 ([#108](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/108)) ([bbb4c94](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/bbb4c9482c598a56ef9f2a50b2eedc84858cd0ee))

## [1.16.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.15.0...v1.16.0) (2026-08-27)


### Features

* Add WebSocket Console tool for realtime debugging in Analytics … ([#105](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/105)) ([c13d571](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/c13d571a03b382c32a8befba0c8c673567b89b8f))


### Bug Fixes

* **websocket-probe:** repair frame assembly and reinstate the size limit ([#107](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/107)) ([c2f6368](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/c2f63680e3cc6d74de48cfd19e80497d9be25c01))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.13 ([#103](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/103)) ([4579de3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/4579de3b0608511a5724aaa16b5943af061919bf))
* **deps:** update dependency cehlers88/analytics-core to v1.40.0 ([#106](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/106)) ([9015d2d](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/9015d2d73f5a6d1eb88ff95f6f2a58656e01ef14))

## [1.15.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.14.0...v1.15.0) (2026-08-23)


### Features

* Add `canvas-diagram` component to `smartDevice_sensor.html.twig` for enhanced data visualization ([27155ca](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/27155ca9c9d3db866301ec1d26ef12cb102fa1be))
* Add `LanServiceView` and `LanServiceAssembler` for `LanService` representation and assembly ([de766c5](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/de766c5f6b16573a7505d1000173709a3fca43c6))
* Add `SendMqttCommandMacro` for sending commands to MQTT-Broker ([31329d5](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/31329d549d3a8acf2678aa2643b917ace9a625a6))
* Add API Fetcher tool for HTTP debugging in Analytics dashboard ([#102](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/102)) ([737acd1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/737acd11b2f31524d6ed58c298ba78af63e8c2a4))
* Add API Fetcher tool template for enhanced request management and debugging ([a5842ad](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a5842ade1c80ee0b139ffad35ff9f4a1d3c7bccd))
* Add conditional rendering of `canvas-diagram` in `smartDevice_power_adapter` and `smartDevice_sensor` templates ([63af925](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/63af925eab7d65b442af17b5bf6a6d7558e82356))
* Add error buffering and exception handling in `HandleMqttUpdateServiceEndpointRunner` ([a1036ae](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a1036ae96475a81535957ea63b68d8c74e75f195))
* Enhance `HandleMqttUpdateServiceEndpointRunner` with history tracking and new attribute mapping ([2f756d7](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/2f756d759f698ec2b74e2d671de91ae14bcbdcdb))
* Enhance `SmartDeviceView` and `SmartDeviceAssembler` with new attribute handling and improved interactions ([ed4346e](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/ed4346ec1cd3374cf2c48f1ac3329e8ccc73b9c5))
* Enhance API Fetcher tool with interactive request history and execution logic ([63b938b](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/63b938b6cd9685fb5dbea78d3ba05173e75b8d6d))
* Enhance templates with improved state handling and expanded attribute rendering ([b30c783](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b30c7839ae57070b5bdbaabbb6d203d074bf4190))
* Extend `SendMqttCommandMacro` with property support, MQTT gateway assembly, and command execution ([9c4bf27](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/9c4bf272dbea66c8fa8c5573e51a6fa9cd581d99))
* Refactor `SmartDeviceAssembler::enrichView` for dynamic child object assembly and improved attribute handling ([ff0bebb](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/ff0bebba6d8ea6d05b98d384750e0535f7b071cb))


### Bug Fixes

* Add validation for empty child objects and correct property access in `SendMqttCommandMacro` ([26bd899](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/26bd89934307503932efe323b142896705987831))
* Correct `attributes` to `attribute` property access in multiple templates for consistent data handling ([43eb4f3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/43eb4f3fefc512421c8a1559329d60eae2a4ed9f))
* Correct monitoring buffer assignment in `SmartDeviceAssembler` to resolve incorrect mapping ([c679242](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/c679242a6ebe35e60f0af77e35c6b6439b55b929))
* Correct property access in `SmartDeviceView` for `attribute` object fields ([353de05](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/353de058a23ecb973a2fadc540d463b6dca38652))
* Refactor variable assignment to improve readability in `LanServiceInfoEndpointRunner` ([de6d5c0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/de6d5c0d053bb0af9a3cc33be188054591fc1782))
* Remove unused return statement from `HandleMqttUpdateServiceEndpointRunner::handlePostRequest` ([f8c8f9e](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/f8c8f9e235d5c4196a3d3a1e42e6597c0ae45716))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.12 ([#101](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/101)) ([ec33539](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/ec3353917fd683fc57a274d327c55b6f3baebcc5))

## [1.14.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.13.0...v1.14.0) (2026-08-14)


### Features

* Add attribute templates and template paths for `SmartDevice` types ([91d3117](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/91d31175999b657326bd74619b9476f78d967f34))
* Enhance `SmartDevice` assembly and MQTT handling with new attributes and monitoring updates ([8a5122b](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/8a5122b11bbb33c280fa42a3ab86d5ca42018cc9))


### Bug Fixes

* Adjust `SmartDevice` template spacing and add margin for metric container ([7efe6ae](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/7efe6ae08df585c3de9815024aab08eab1a1499a))
* Improve fallback handling for `SmartDevice` templates and attributes ([48c5ef4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/48c5ef41040376e9aaaede9f1dc938c8fa1caa44))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.11 ([#99](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/99)) ([8243ae8](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/8243ae8b01131e8f01292d186bc90478917c111a))

## [1.13.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.12.0...v1.13.0) (2026-08-11)


### Features

* Add `IsLanDeviceRole` and `MagicRoleIsLanDevice` for local network device handling ([aa71304](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/aa71304e4be1833b5a30f443d2b9bc2046cfb942))
* Add `LogServiceEndpointRunner`, extend LAN service roles, and introduce new SmartDevice types ([558e596](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/558e59647c2bfd6810d0a01dffadde4bba05d3d5))
* Add role-based access control for service endpoints and update role definitions ([a88a9fe](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a88a9febd501e806efcf569377455f286257daae))
* Add service tags for `CustomObjectInterface` and `MagicRoleInterface`, update service configuration ([f30b7f9](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/f30b7f9b7a0460dab8c705c8f10447dfd52e008d))
* Expand MQTT handling with new attributes and endpoint alias ([f54561c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/f54561cd5c5d0381a51f0e76685af324b9713f6f))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.10 ([#97](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/97)) ([c57b72c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/c57b72cccf7159b9857622a964bf0558ced87920))

## [1.12.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.11.1...v1.12.0) (2026-07-20)


### Features

* Add `getTileDetails` to `SmartDevice`, new configuration item, and fix typo in tile template ([b71357f](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b71357f846a68cb5a5d1be4cf8b9c5cd3b5bda46))
* Add `SmartDeviceAssembler`, enhance child object rendering, and update templates ([d161dab](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/d161dab249529824a4723ea5a2c032f0fb4f4e15))
* Extend `LanService` with state logic and integrate `setLastSeen` updates in MQTT runners ([c1883ff](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/c1883ff6fd3fcaaa541d9a6c36353b16175cdc02))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.8 ([#94](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/94)) ([7a62e50](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/7a62e501e6d1e42888d63af3ef1c01cc2d67fbc3))

## [1.11.1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.11.0...v1.11.1) (2026-07-13)


### Miscellaneous Chores

* Configure Renovate ([#91](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/91)) ([39f7f85](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/39f7f854c99e40c59af128c9448320dbcfef177f))
* **deps:** update dependency cehlers88/analytics-core to v1.39.6 ([#90](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/90)) ([ac596d1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/ac596d11159c274e5291aeea6585b303d504cfcd))

## [1.11.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.10.0...v1.11.0) (2026-07-12)


### Features

* Add support for `plotter_3d` device type and enhance handling of SmartDevice attributes ([b817d4e](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b817d4e62b903c457bff74fdb9ebd810935962f3))

## [1.10.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.9.0...v1.10.0) (2026-07-12)


### Features

* Add custom tile templates and device type handling for `SmartDevice` ([7a9f5e0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/7a9f5e08f738e60ec0701364bce587cc8cd5ba56))
* Add handlers for POST and GET endpoints in `LanServiceInfoEndpointRunner` ([b972dcb](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b972dcb42614fb46b3abac837011be0fa04bee32))
* Add tile template for `power_adapter` and update metric display logic ([80dcf33](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/80dcf33e76664ea1d19453a84267270fa9086425))
* Enhance `HandleMqttUpdateServiceEndpointRunner` with `CustomObjectProvider` integration ([a4517b3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a4517b336bc03fe130de4c74e29f3ef81f366c09))
* Introduce `GrowboxManagementWorker` for environment control logic ([ec8a0e8](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/ec8a0e8a5c177df5954c3fd16cfebecb60d17926))


### Miscellaneous Chores

* Bump `cehlers88/analytics-core` to v1.39.5 in `composer.lock` ([3b58224](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/3b58224d77a9e89adaee8ea76c5e9f2f50d231c8))
* Enhance `LanServiceInfoEndpointRunner` with role-based access and assembler integration ([e7fe8f8](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/e7fe8f87be9291fa9b8174904d5bd3aa4ac4f5ef))
* Update service endpoint runners with typed `handleRequest` and validation refinements ([2817328](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/281732843c5e3340ad2f40728f4b205346cf4e5c))

## [1.9.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.8.7...v1.9.0) (2026-07-10)


### Features

* Add `LanServiceInfoEndpointRunner` and enhance `LanService` with `setLastSeen` method ([cd2b5bc](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/cd2b5bc8496ab217c0dbf0b70dd1a90b694a2c39))


### Miscellaneous Chores

* Add `LanService` custom object extending `AbstractCustomObject` ([f8d33fa](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/f8d33fab7d2de9c472dc6ee052a29be74887d5d7))
* **deps:** update dependency cehlers88/analytics-core to v1.39.3 ([#86](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/86)) ([d95de3a](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/d95de3afde060fddfd8ead0ca35813aa4abdfea3))

## [1.8.7](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.8.6...v1.8.7) (2026-06-21)


### Miscellaneous Chores

* Delete obsolete Analytics entities and their repositories. ([07d72f2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/07d72f292810ba82c07ce6599cc1dcaed60b6cd2))

## [1.8.6](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.8.5...v1.8.6) (2026-06-21)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.1 ([#83](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/83)) ([392cfbd](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/392cfbd031e36b686a341f672469227ed939f244))
* Refactor imports to use AbstractMacro from AnalyticsCore ([b05421c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b05421cc4b579340811df13731e3a181c521f61c))
* Replaced imports of `MenuItemDTO` with the correct path `Cehlers88\AnalyticsCore\Support\DTO\UI\MenuItemDTO` in multiple bundles. This ensures consistency and resolves potential namespace issues. ([050a0aa](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/050a0aad959120808d6a87381937675b184f408b))
* Update service definitions to use `MacroInterface` with `analytics.macro` tag and remove outdated macro config ([edb4dc5](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/edb4dc5961b572a3d39c902300e0000a2e6f597f))

## [1.8.5](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.8.4...v1.8.5) (2026-06-14)


### Miscellaneous Chores

* bump `cehlers88/analytics-core` to v1.38.8 in composer.lock ([b253b84](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b253b840e012eb25eacc404d72dc6c0b34b57069))

## [1.8.4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.8.3...v1.8.4) (2026-06-14)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.38.7 ([#80](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/80)) ([bfb5740](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/bfb57409e21f6640d96da1381b522834954d567a))

## [1.8.3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.8.2...v1.8.3) (2026-05-24)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.38.2 ([#78](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/78)) ([031e737](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/031e737107593ac307a3129fc27729c8d1ce065a))

## [1.8.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.8.1...v1.8.2) (2026-05-17)


### Miscellaneous Chores

* Bump `cehlers88/analytics-core` to v1.38.0 in composer.lock ([06587ad](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/06587ad398aec3e0ec85f9a8502087fa1d9bed8a))
* refactor: Update `PropertyDTO` import path in `FetchFritzboxClientListWorker` to use `AnalyticsCore` namespace ([20e231e](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/20e231e5bb6a8139b2556d9dc230ff72fcfe7b4d))

## [1.8.1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.8.0...v1.8.1) (2026-05-16)


### Miscellaneous Chores

* Bump `cehlers88/analytics-core` to v1.37.0 in composer.lock ([544137e](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/544137e7be26216e01ca06a02d47ff7804fb04d5))

## [1.8.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.7.0...v1.8.0) (2026-05-16)


### Features

* Introduce `SmartDevice` custom object and register it as a service in the bundle configuration ([090d2ce](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/090d2ce61b7d3fcaf8cafac4735ae259959262e2))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.36.0 ([#74](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/74)) ([f306898](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/f306898cde34ac592cd86df2452e788db3b4d4c3))

## [1.7.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.6.2...v1.7.0) (2026-05-16)


### Features

* Expand `GeneralConfigurationGroup` with new gateway configurations and optimize application select setup ([88db0ca](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/88db0cad7dbb2ec0ef52d68a9de5dd3543868260))


### Miscellaneous Chores

* Bump `cehlers88/analytics-core` to v1.34.0 in composer.lock ([4e25ecc](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/4e25ecccd0934e55a4073dccb3834f02c7b77d3d))

## [1.6.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.6.1...v1.6.2) (2026-05-15)


### Bug Fixes

* Ensure `playerState` is set before checking for BUFFERING in `HandleClientUpdateServiceEndpointRunner` ([06749f4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/06749f4707323e3af77c4e14ed8f34a0a165c8a7))

## [1.6.1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.6.0...v1.6.1) (2026-05-10)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.30.0 ([#69](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/69)) ([5977eb9](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/5977eb9972b8606635ac8170466e151e2f604a64))

## [1.6.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.5.0...v1.6.0) (2026-05-03)


### Features

* Style cast_info tile as a proper dashboard widget ([#65](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/65)) ([8a170c1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/8a170c1f27e47e5a2542bb99e23fabf1739ecf0a))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.5 ([#67](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/67)) ([1457604](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/14576048d742c545def02901e187395552491d45))

## [1.5.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.4.0...v1.5.0) (2026-05-03)


### Features

* Add cast_info template to display power state and debug data ([8304a43](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/8304a4353a85c92ba47b79eb623ab44d93d1b409))
* Add MQTT device template for displaying power state and data debug output ([d273cf5](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/d273cf56ee220ea6e2eb81711954cc1191e243b2))
* Improve mqtt_device dashboard tile: replace raw dump with structured smart-plug view ([#63](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/63)) ([49b910f](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/49b910f2924148cb77285c5f22b84bb64b700c6f))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.4 ([#60](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/60)) ([e4dd540](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/e4dd540b6fff7b79c1e115bca26aab5daa88c090))

## [1.4.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.3.1...v1.4.0) (2026-05-03)


### Features

* Improve tracking logic in service endpoint runners and refine `TrackingRecorder` usage ([762cc8c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/762cc8c90efc8ba107accae18922257ecf007d8c))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.2 ([#59](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/59)) ([014b774](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/014b77411ce11c03e2e01ec7fd8d82b41cce3ca0))
* Update branch alias format in composer.json files ([3ed87a0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/3ed87a0bca25ab9bb978a7f9df7d5d8daa3b9cc1))

## [1.3.1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.3.0...v1.3.1) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.1 ([#56](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/56)) ([784e9c6](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/784e9c67c798cd12af698b691eb3d76df36859c2))

## [1.3.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.2.0...v1.3.0) (2026-05-03)


### Features

* Add Chromecast application support to GeneralConfigurationGroup ([475b783](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/475b78329b1d1d84c338cad455520197d964928b))
* Enhance `HandleClientUpdateServiceEndpointRunner` to handle `cast_info` client details update logic ([6454c7c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/6454c7cbc3768162f19809974810195404c18bd1))
* Extend `HandleClientUpdateServiceEndpointRunner` with client fetching and application ID retrieval logic, update IP placeholder in `HandleMqttUpdateServiceEndpointRunner` ([7f5f855](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/7f5f855b4e8d95c22df4ad86f6c2a63e0f08154d))
* Refine `HandleClientUpdateServiceEndpointRunner` to skip redundant tracking for identical `cast_info` updates ([fc79de3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/fc79de3e703ca4cd552978e386bd182257befc77))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.25.1 ([#55](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/55)) ([5d4c114](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/5d4c1140650343c720625df88330bc7f32312219))
* Replace `AbstractServiceEndpointRunnerInterface` with `AbstractServiceEndpointRunner` in service runners and update `HandleClientUpdateServiceEndpointRunner` logic ([585937a](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/585937a537bc3e31f70d4392fbe0effa8aa60027))

## [1.2.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.1.3...v1.2.0) (2026-05-03)


### Features

* Add `HandleClientUpdateServiceEndpointRunner`, refactor `HandleMqttUpdateServiceEndpointRunner`, and enhance MQTT processing logic ([1013846](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/10138466dbd49aab43cc3740bc06daa39432ae34))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.23.1 ([#52](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/52)) ([b9da4ee](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b9da4ee9802bc07837516e1de3bc3f7fd9affcf4))

## [1.1.3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.1.2...v1.1.3) (2026-05-02)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.21.0 ([#49](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/49)) ([15b3a69](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/15b3a69b489d35392a9bcc3dd5da2a7b6f3941eb))
* **deps:** update dependency cehlers88/analytics-core to v1.22.1 ([#51](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/51)) ([f8f6a35](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/f8f6a35856a3e106faf81b0af328fe0c474d289d))

## [1.1.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.1.1...v1.1.2) (2026-04-26)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.20.0 ([#45](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/45)) ([7e52b8b](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/7e52b8b9c8664a1e818aa6b6e734feb0874123e6))
* **deps:** update googleapis/release-please-action action to v5 ([#47](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/47)) ([6bd1027](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/6bd1027b0e0970a2e16b4f856bf31f94cee61dbf))

## [1.1.1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.1.0...v1.1.1) (2026-04-20)


### Miscellaneous Chores

* Replace logWarning with setError in `FetchFritzboxClientListWorker` ([e8bfbca](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/e8bfbca42b172395969fd19770f5309adfadaac6))
* Update placeholder file to include latest analytics-core dependency adjustments ([de0c7a0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/de0c7a0ad2c8ab148046eb83e3fbf576d7b936d7))

## [1.1.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.0.2...v1.1.0) (2026-04-19)


### Features

* Refactor `FetchFritzboxClientListWorker` to enhance client fetching logic and integrate FritzBox TR-064 SOAP handling ([1568140](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/156814066b213ce2d91fee06efa21fc70bf33660))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.16.1 ([#41](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/41)) ([a5d46eb](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a5d46ebff5adf4c01100f58d02f4550d1c43273f))
* Upgrade analytics-core to v1.17.0 and update composer.lock with new reference, distribution URL, and checksum ([11b6579](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/11b6579623355a8219fdd7fb316a669bd6c7d942))

## [1.0.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.0.1...v1.0.2) (2026-04-13)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.15.0 ([#36](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/36)) ([067078a](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/067078a6df28faaeb432da8abdfcbec8898ba79b))
* **deps:** update dependency cehlers88/analytics-core to v1.16.0 ([#40](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/40)) ([442c22d](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/442c22d6923b202b7621ba1435f99f0a55dfb364))

## [1.0.1](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v1.0.0...v1.0.1) (2026-04-06)


### Miscellaneous Chores

* Update analytics-core dependency to "1.*[@dev](https://github.com/dev)" and adjust branch alias to "1.x.x-dev" in composer.json ([d88b577](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/d88b5771b1e6085568555022a1fa86a6c85b508d))

## [1.0.0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.16...v1.0.0) (2026-04-06)


### ⚠ BREAKING CHANGES

* Upgrade analytics-core to v1.11.0 and update method signature in HandleMqttUpdateServiceEndpointRunner

### Features

* Upgrade analytics-core to v1.11.0 and update method signature in HandleMqttUpdateServiceEndpointRunner ([dcb5aa2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/dcb5aa2361803d3eac8a1aee79444a5b667abf92))

## [0.1.16](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.15...v0.1.16) (2026-03-29)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.3.13 ([#32](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/32)) ([b35f566](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b35f566e5123bddbb0475fc5358296ee01006433))
* **deps:** update dependency cehlers88/analytics-core to v1.4.1 ([#34](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/34)) ([1ca5dd4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/1ca5dd4636bb58b87796a891a76aa0c986778eb4))
* **deps:** update dependency cehlers88/analytics-core to v1.6.0 ([#35](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/35)) ([ed23a1b](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/ed23a1bd02ed171466280e033b6af3f81f37f0eb))

## [0.1.15](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.14...v0.1.15) (2026-03-24)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.1.3 ([#28](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/28)) ([bade42f](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/bade42f6c3dd1d37859d74cfaa9e9259f3e453fa))
* **deps:** update dependency cehlers88/analytics-core to v1.3.5 ([#30](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/30)) ([b037900](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/b037900f3d48ce30dbcabee9b2dfc1b673e6f23b))
* **deps:** update dependency cehlers88/analytics-core to v1.3.6 ([#31](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/31)) ([34bcf2c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/34bcf2cdf848e75375ffdebe72cad4eae5614482))
* Upgraded the analytics-core package to v1.3.7 to include the latest changes and improvements. Updated the associated reference, distribution URL, and checksum to match the new version. ([bddf86d](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/bddf86d6406c783d4529890d733f8f2401de2a65))

## [0.1.14](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.13...v0.1.14) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([37e24ac](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/37e24acb693d5b58d5eaacb2dc3f191319a7ceab))

## [0.1.13](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.12...v0.1.13) (2026-03-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.5.4 ([#23](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/23)) ([650b624](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/650b6240f080b128f9e9c489f29c6733f8776020))
* **deps:** update dependency cehlers88/analytics-core to v0.5.5 ([#24](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/24)) ([a87c32b](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a87c32b0c66ace0122d026f1a44f0be6a8934491))

## [0.1.12](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.11...v0.1.12) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.5 ([#21](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/21)) ([09957a0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/09957a0a91bfcf8302caf9bce8b54cdc77976b13))

## [0.1.11](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.10...v0.1.11) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.4.2 ([#19](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/19)) ([278691c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/278691c39e3c071681c040cda600d489024229ad))

## [0.1.10](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.9...v0.1.10) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([8ecdc76](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/8ecdc7624709e15b6bba8d9c04fc30c46ba5bfad))

## [0.1.9](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.8...v0.1.9) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([916b58c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/916b58c23d8847704f03c5770f37c8d909170d18))

## [0.1.8](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.7...v0.1.8) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.4 ([#15](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/15)) ([ca61503](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/ca61503589e3885b000bf1ba3affb3e75790f1d8))

## [0.1.7](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.6...v0.1.7) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.1 ([#13](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/13)) ([edb5436](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/edb5436e90dd7a9bac8febce5b72acd6cee40399))

## [0.1.6](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.5...v0.1.6) (2026-03-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#9](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/9)) ([6c384c0](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/6c384c0ec5f37bb4f8b68fbac95f17ad3d2ad403))

## [0.1.5](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.4...v0.1.5) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.2 ([#7](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/7)) ([92be449](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/92be449445828f0ae85d0c42a733a0e0f4ff7373))

## [0.1.4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.3...v0.1.4) (2026-01-21)


### Miscellaneous Chores

* add GitHub workflow to trigger Satis rebuild on release ([7f77f56](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/7f77f56f68fe25a212e0c14c0a5f15bd57cceb29))
* **deps:** update dependency cehlers88/analytics-core to v0.1.5 ([#4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/4)) ([2270bbe](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/2270bbe68cc3c63a598a8b579dc7d8e0f907a1f1))

## [0.1.3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.2...v0.1.3) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([#2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/2)) ([605516c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/605516c331d6857b814273f0adbe6333c8a26f5e)) ([3da16e3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/3da16e312e59b09de63dd1a0d3c1c226407ce307))
## [0.1.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([a367bbd](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a367bbd335655fe509fe8c3f83609ac53da0520a))
