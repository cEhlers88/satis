<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsInfrastructureBundle\Minecraft;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Widget\AbstractWidget;

/**
 * Dashboard tile of a Minecraft server: status, who is online and since when, everyone who
 * was ever there (with play time), the latest joins and quits, TPS, memory and version.
 *
 * The data comes from the plugin in minecraft-plugin/ through MinecraftEventEndpointRunner
 * and is kept in a MinecraftServer custom object; this widget only reads it
 * (MinecraftServerOverview). The template renders itself again when a custom object is saved
 * (every heartbeat, i.e. once a minute) and when the tab comes back into view.
 */
class MinecraftServerWidget extends AbstractWidget
{
    public function __construct(
        private readonly CustomObjectProvider $customObjectProvider,
    )
    {
    }

    public function getName(): string
    {
        return 'AnalyticsInfrastructureBundle.minecraftServer';
    }

    public function getTemplateName(): string
    {
        return 'minecraftServer';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '14px', 'boxes' => [.5, .2]],
            ['height' => '28px', 'boxes' => [.3, .3, .3]],
            ['height' => '10px', 'boxes' => [.4]],
            ['height' => '24px', 'boxes' => [.9]],
            ['height' => '24px', 'boxes' => [.9]],
        ];
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'server',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Server',
                description: 'Welcher Minecraft-Server gezeigt wird. Ein Server erscheint hier, sobald sein Plugin das erste Mal gemeldet hat. Leer: der erste.',
                ui: ['options' => ['' => '– erster Server –'] + $this->serverChoices()],
            ),
            PropertyDTO::create(
                name: 'offlineAfter',
                value: MinecraftServerOverview::DEFAULT_OFFLINE_AFTER_SECONDS,
                type: 'int',
                isOptional: true,
                label: 'Nicht erreichbar nach (Sekunden)',
                description: 'Meldet das Plugin so lange nichts, gilt der Server als nicht erreichbar. Das Plugin meldet sich standardmäßig jede Minute.',
                ui: ['min' => 30],
            ),
            PropertyDTO::create(
                name: 'knownPlayersLimit',
                value: 20,
                type: 'int',
                isOptional: true,
                label: 'Spieler in „Alle Spieler“',
                description: 'Wie viele der Spieler, die jemals da waren, gelistet werden - die zuletzt gesehenen zuerst. 0 blendet die Liste aus.',
                ui: ['min' => 0, 'max' => 300],
            ),
            PropertyDTO::create(
                name: 'eventsLimit',
                value: 8,
                type: 'int',
                isOptional: true,
                label: 'Letzte Ereignisse',
                description: 'Wie viele Joins, Quits, Starts und Stopps gezeigt werden. 0 blendet sie aus.',
                ui: ['min' => 0, 'max' => 50],
            ),
            PropertyDTO::create(
                name: 'showHeads',
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Spielerköpfe zeigen',
                description: 'Lädt die Köpfe der Skins von mc-heads.net - dabei erfährt dieser Dienst die UUIDs der Spieler. Aus: Anfangsbuchstaben.',
            ),
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $server = $this->server((string)($properties['server'] ?? ''));

        $properties['minecraft'] = $server === null ? null : MinecraftServerOverview::build(
            $server->getName(),
            $server->getAttributes(),
            new \DateTimeImmutable(),
            self::int($properties['offlineAfter'] ?? null, MinecraftServerOverview::DEFAULT_OFFLINE_AFTER_SECONDS, 30, 86400),
            self::int($properties['knownPlayersLimit'] ?? null, 20, 0, MinecraftServerState::MAX_KNOWN_PLAYERS),
            self::int($properties['eventsLimit'] ?? null, 8, 0, MinecraftServerState::RECENT_EVENTS),
        );
        $properties['minecraftServerMissing'] = $server === null && (string)($properties['server'] ?? '') !== '';
        $properties['minecraftShowHeads'] = self::isOn($properties['showHeads'] ?? true);
        $properties['minecraftTokenConstant'] = MinecraftEventEndpointRunner::TOKEN_CONSTANT;
        $properties['minecraftEndpoint'] = '/api/se/' . MinecraftEventEndpointRunner::ALIAS;

        return $properties;
    }

    /** The picked server, the first one when none is picked; null when there is none (any more). */
    private function server(string $id): ?MinecraftServer
    {
        $servers = $this->servers();
        if ($id === '') {
            return $servers[array_key_first($servers)] ?? null;
        }

        return $servers[(int)$id] ?? null;
    }

    /** @return array<int, MinecraftServer> id => server, by name */
    private function servers(): array
    {
        $servers = [];
        foreach ($this->customObjectProvider->getCustomEntitiesByClassName(MinecraftServer::class) as $server) {
            if ($server instanceof MinecraftServer) {
                $servers[$server->getId()] = $server;
            }
        }
        uasort($servers, static fn(MinecraftServer $a, MinecraftServer $b): int => strnatcasecmp($a->getName(), $b->getName()));

        return $servers;
    }

    /** @return array<int, string> */
    private function serverChoices(): array
    {
        return array_map(static fn(MinecraftServer $server): string => $server->getName(), $this->servers());
    }

    private static function int(mixed $value, int $default, int $min, int $max): int
    {
        return is_numeric($value) ? max($min, min($max, (int)$value)) : $default;
    }

    /** A switch as the mask stores it: true, 1, "1", "true" or "on". */
    private static function isOn(mixed $value): bool
    {
        return in_array(is_string($value) ? strtolower($value) : $value, [true, 1, '1', 'true', 'on'], true);
    }
}
