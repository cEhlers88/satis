<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsInfrastructureBundle\Minecraft;

/**
 * Applies one event of the Minecraft plugin to the attributes of a MinecraftServer - plain
 * arrays in, plain arrays out, no container, so the rules can be checked without one.
 *
 * Every event of the plugin carries the full list of the players online at that moment
 * ("players"). That list is the truth: a join or quit that got lost is made up for by the
 * next heartbeat (every minute). The plugin sends asynchronously, so an older snapshot can
 * arrive after a newer one - a snapshot older than the last applied one only adds to the
 * history and the known players, it never changes who is online.
 *
 * Attributes (all strings, as custom object attributes are stored):
 *   status            "online" | "offline" ("offline" only after a clean server_stop - a
 *                     server that just stops reporting is told apart by last_seen_at,
 *                     see MinecraftServerOverview)
 *   last_seen_at      when the plugin last reported - time of arrival here, the only time
 *                     not taken from the Minecraft server's clock
 *   last_snapshot_at  occurred_at of the player list that is applied
 *   started_at / stopped_at
 *   version, software, motd, max_players, online_mode, tps (JSON [1m, 5m, 15m]), mspt,
 *   memory_used_mb, memory_max_mb, worlds (JSON), plugin_version
 *   online_players    JSON [{uuid, name, since, world}]
 *   known_players     JSON {uuid: {uuid, name, first_seen, last_seen, sessions, playtime}}
 *                     - playtime in seconds of the finished sessions; the running one is
 *                     added when shown
 *   recent_events     JSON [{type, at, uuid?, name?}], newest first
 *   peak_players / peak_players_at
 *
 * Times are UTC "Y-m-d\TH:i:s\Z", so the strings compare like the times.
 */
final class MinecraftServerState
{
    public const string EVENT_SERVER_START = 'server_start';
    public const string EVENT_HEARTBEAT = 'heartbeat';
    public const string EVENT_PLAYER_JOIN = 'player_join';
    public const string EVENT_PLAYER_QUIT = 'player_quit';
    public const string EVENT_SERVER_STOP = 'server_stop';

    public const array EVENTS = [
        self::EVENT_SERVER_START,
        self::EVENT_HEARTBEAT,
        self::EVENT_PLAYER_JOIN,
        self::EVENT_PLAYER_QUIT,
        self::EVENT_SERVER_STOP,
    ];

    public const array JSON_ATTRIBUTES = ['online_players', 'known_players', 'recent_events', 'tps', 'worlds'];

    /** Events kept for the history of the tile (heartbeats are not kept). */
    public const int RECENT_EVENTS = 50;
    /**
     * Players remembered. An attribute is a TEXT column (64 KB) and one player takes about
     * 180 bytes - the ones not seen for the longest time make room first.
     */
    public const int MAX_KNOWN_PLAYERS = 300;
    /** More players than this in one snapshot are cut off (a private server never gets there). */
    public const int MAX_ONLINE_PLAYERS = 200;
    /**
     * How far the clock of the Minecraft server may be off before its times are not trusted
     * and the time of arrival is taken instead.
     */
    public const int MAX_CLOCK_SKEW_SECONDS = 600;

    public const string TIME_FORMAT = 'Y-m-d\TH:i:s\Z';

    /**
     * @param array<string, mixed> $attributes the current attributes of the server
     * @param array<string, mixed> $event      the body the plugin sent (see the README)
     *
     * @return array<string, string> the attributes to set (only the ones that change)
     */
    public static function apply(array $attributes, array $event, \DateTimeImmutable $now): array
    {
        $type = (string)($event['event'] ?? '');
        if (!in_array($type, self::EVENTS, true)) {
            throw new \InvalidArgumentException(sprintf('Unknown event "%s"', $type));
        }

        $at = self::eventTime($event['occurred_at'] ?? null, $now);
        $previousSeen = (string)($attributes['last_seen_at'] ?? '');
        $lastSnapshot = (string)($attributes['last_snapshot_at'] ?? '');
        $isCurrent = strcmp($at, $lastSnapshot) >= 0;

        $online = self::onlineByUuid(self::decode($attributes['online_players'] ?? null));
        $known = self::decode($attributes['known_players'] ?? null);
        $recent = self::decode($attributes['recent_events'] ?? null);

        $player = self::player($event['player'] ?? null);
        // a stopping server has nobody online any more, whatever the list says
        $snapshot = $type === self::EVENT_SERVER_STOP
            ? []
            : self::snapshot($event['players'] ?? null, $at);

        // everyone in the event becomes (or stays) a known player
        foreach ([...array_values($snapshot), ...($player === null ? [] : [$player])] as $seen) {
            $known = self::remember($known, $seen['uuid'], $seen['name'], $at);
        }

        $changes = [];

        if ($isCurrent) {
            // Who left: the time they left is known for a quit; a server that starts again
            // went down (or crashed) some time after it was last seen; for everything else
            // the quit got lost somewhere before this event.
            foreach ($online as $uuid => $entry) {
                if (isset($snapshot[$uuid])) {
                    continue;
                }
                $leftAt = match (true) {
                    $type === self::EVENT_SERVER_START && $previousSeen !== '' => $previousSeen,
                    default => $at,
                };
                $known = self::closeSession($known, $uuid, (string)($entry['since'] ?? ''), $leftAt);
            }
            // Who came: a new session, starting when the plugin says they joined.
            foreach ($snapshot as $uuid => $entry) {
                $knownSince = isset($online[$uuid]) ? (string)($online[$uuid]['since'] ?? '') : null;
                if ($knownSince !== null && !($entry['joined'] && strcmp($entry['since'], $knownSince) > 0)) {
                    // still the same session - keep the start the server already knows
                    $snapshot[$uuid]['since'] = $knownSince !== '' ? $knownSince : $entry['since'];
                    continue;
                }
                if ($knownSince !== null) {
                    // The plugin names a later join than the one known here: the quit in between
                    // got lost. The old session ends where the player was last confirmed online,
                    // so the time away does not count as play time.
                    $leftAt = min($entry['since'], max($lastSnapshot, $knownSince));
                    $known = self::closeSession($known, $uuid, $knownSince, $leftAt);
                }
                $known = self::openSession($known, $uuid, $entry['since']);
            }
            // "joined" was only needed to tell the sessions apart
            $snapshot = array_map(static fn(array $entry): array => array_diff_key($entry, ['joined' => true]), $snapshot);
            foreach ($snapshot as $uuid => $entry) {
                $known[$uuid]['last_seen'] = max((string)($known[$uuid]['last_seen'] ?? ''), $at);
            }

            $changes['online_players'] = self::encode(array_values($snapshot));
            $changes['last_snapshot_at'] = $at;

            $count = count($snapshot);
            if ($count > (int)($attributes['peak_players'] ?? 0)) {
                $changes['peak_players'] = (string)$count;
                $changes['peak_players_at'] = $at;
            }

            $changes['status'] = $type === self::EVENT_SERVER_STOP ? 'offline' : 'online';
            if ($type === self::EVENT_SERVER_START) {
                $changes['started_at'] = $at;
            }
            if ($type === self::EVENT_SERVER_STOP) {
                $changes['stopped_at'] = $at;
            }
            // the server's own start time (in every event) beats the time the start event arrived
            $changes = self::info($event['info'] ?? null, $at) + $changes;
            if (is_string($event['plugin_version'] ?? null)) {
                $changes['plugin_version'] = self::text($event['plugin_version'], 40);
            }
        }

        if ($type !== self::EVENT_HEARTBEAT) {
            $entry = ['type' => $type, 'at' => $at];
            if ($player !== null) {
                $entry['uuid'] = $player['uuid'];
                $entry['name'] = $player['name'];
            }
            $recent[] = $entry;
            // newest first, by when it happened - not by when it arrived
            usort($recent, static fn(array $a, array $b): int => strcmp((string)($b['at'] ?? ''), (string)($a['at'] ?? '')));
            $changes['recent_events'] = self::encode(array_slice($recent, 0, self::RECENT_EVENTS));
        }

        $changes['known_players'] = self::encode(self::trimKnown($known));
        // by the clock of this installation, not the Minecraft server's: MinecraftServerOverview
        // compares it with "now" here to tell whether the server still reports
        $changes['last_seen_at'] = max($previousSeen, self::format($now));

        return $changes;
    }

    /** The time the plugin gives, unless it is missing or too far from the time of arrival. */
    public static function eventTime(mixed $value, \DateTimeImmutable $now): string
    {
        $time = self::parseTime($value);
        if ($time === null || abs($time->getTimestamp() - $now->getTimestamp()) > self::MAX_CLOCK_SKEW_SECONDS) {
            $time = $now;
        }

        return self::format($time);
    }

    public static function parseTime(mixed $value): ?\DateTimeImmutable
    {
        if (!is_string($value) || trim($value) === '') {
            return null;
        }
        try {
            return (new \DateTimeImmutable($value))->setTimezone(new \DateTimeZone('UTC'));
        } catch (\Exception) {
            return null;
        }
    }

    public static function format(\DateTimeInterface $time): string
    {
        return \DateTimeImmutable::createFromInterface($time)->setTimezone(new \DateTimeZone('UTC'))->format(self::TIME_FORMAT);
    }

    /** A JSON attribute as array - an empty one for anything that is not JSON. */
    public static function decode(mixed $value): array
    {
        if (is_array($value)) {
            return $value;
        }
        if (!is_string($value) || $value === '') {
            return [];
        }
        $decoded = json_decode($value, true);

        return is_array($decoded) ? $decoded : [];
    }

    public static function encode(array $value): string
    {
        return (string)json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    /** A Minecraft uuid, with or without dashes, lower case with dashes; null for anything else. */
    public static function uuid(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }
        $hex = strtolower(str_replace('-', '', trim($value)));
        if (preg_match('/^[0-9a-f]{32}$/', $hex) !== 1) {
            return null;
        }

        return substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-' . substr($hex, 12, 4) . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20);
    }

    /** @return array{uuid: string, name: string}|null */
    private static function player(mixed $value): ?array
    {
        if (!is_array($value)) {
            return null;
        }
        $uuid = self::uuid($value['uuid'] ?? null);
        if ($uuid === null) {
            return null;
        }

        return ['uuid' => $uuid, 'name' => self::name($value['name'] ?? null, $uuid)];
    }

    /** @return array<string, array{uuid: string, name: string, since: string, joined: bool, world: string}> */
    private static function snapshot(mixed $players, string $at): array
    {
        if (!is_array($players)) {
            return [];
        }
        $snapshot = [];
        foreach (array_slice($players, 0, self::MAX_ONLINE_PLAYERS) as $value) {
            $player = self::player($value);
            if ($player === null) {
                continue;
            }
            // joined_at may be hours ago, so no skew check here - but a session cannot have
            // started after the snapshot that shows it
            $joined = self::parseTime(is_array($value) ? ($value['joined_at'] ?? null) : null);
            $since = $joined === null ? $at : self::format($joined);
            if (strcmp($since, $at) > 0) {
                $since = $at;
            }
            $snapshot[$player['uuid']] = $player + [
                'since' => $since,
                // whether the plugin itself said when the player joined
                'joined' => $joined !== null,
                'world' => self::text(is_array($value) ? ($value['world'] ?? '') : '', 64),
            ];
        }

        return $snapshot;
    }

    /** @return array<string, array<string, mixed>> */
    private static function onlineByUuid(array $list): array
    {
        $online = [];
        foreach ($list as $entry) {
            $uuid = is_array($entry) ? self::uuid($entry['uuid'] ?? null) : null;
            if ($uuid !== null) {
                $online[$uuid] = $entry;
            }
        }

        return $online;
    }

    private static function remember(array $known, string $uuid, string $name, string $at): array
    {
        $entry = is_array($known[$uuid] ?? null) ? $known[$uuid] : [
            'uuid' => $uuid,
            'name' => $name,
            'first_seen' => $at,
            'last_seen' => $at,
            'sessions' => 0,
            'playtime' => 0,
        ];
        // names can change - the newest one wins
        if (strcmp($at, (string)($entry['last_seen'] ?? '')) >= 0) {
            $entry['name'] = $name;
            $entry['last_seen'] = $at;
        }
        if (strcmp($at, (string)($entry['first_seen'] ?? $at)) < 0) {
            $entry['first_seen'] = $at;
        }
        $known[$uuid] = $entry;

        return $known;
    }

    private static function openSession(array $known, string $uuid, string $since): array
    {
        $known[$uuid]['sessions'] = (int)($known[$uuid]['sessions'] ?? 0) + 1;
        if (strcmp($since, (string)($known[$uuid]['first_seen'] ?? $since)) < 0) {
            $known[$uuid]['first_seen'] = $since;
        }

        return $known;
    }

    private static function closeSession(array $known, string $uuid, string $since, string $leftAt): array
    {
        if (!isset($known[$uuid])) {
            return $known;
        }
        $start = self::parseTime($since);
        $end = self::parseTime($leftAt);
        if ($start !== null && $end !== null && $end > $start) {
            $known[$uuid]['playtime'] = (int)($known[$uuid]['playtime'] ?? 0) + ($end->getTimestamp() - $start->getTimestamp());
        }
        $known[$uuid]['last_seen'] = max((string)($known[$uuid]['last_seen'] ?? ''), $leftAt);

        return $known;
    }

    private static function trimKnown(array $known): array
    {
        if (count($known) <= self::MAX_KNOWN_PLAYERS) {
            return $known;
        }
        uasort($known, static fn(array $a, array $b): int => strcmp((string)($b['last_seen'] ?? ''), (string)($a['last_seen'] ?? '')));

        return array_slice($known, 0, self::MAX_KNOWN_PLAYERS, true);
    }

    /** @return array<string, string> */
    private static function info(mixed $info, string $at): array
    {
        if (!is_array($info)) {
            return [];
        }
        $changes = [];
        $startedAt = self::parseTime($info['started_at'] ?? null);
        if ($startedAt !== null && strcmp(self::format($startedAt), $at) <= 0) {
            $changes['started_at'] = self::format($startedAt);
        }
        foreach (['version' => 40, 'software' => 120, 'motd' => 200] as $key => $length) {
            if (is_scalar($info[$key] ?? null)) {
                $changes[$key] = self::text($info[$key], $length);
            }
        }
        foreach (['max_players', 'memory_used_mb', 'memory_max_mb'] as $key) {
            if (is_numeric($info[$key] ?? null)) {
                $changes[$key] = (string)max(0, (int)$info[$key]);
            }
        }
        if (is_numeric($info['mspt'] ?? null)) {
            $changes['mspt'] = (string)round((float)$info['mspt'], 2);
        }
        if (is_bool($info['online_mode'] ?? null)) {
            $changes['online_mode'] = $info['online_mode'] ? '1' : '0';
        }
        if (is_array($info['tps'] ?? null)) {
            $tps = array_values(array_map(
                static fn(mixed $value): float => round(min(20.0, max(0.0, (float)$value)), 2),
                array_filter(array_slice($info['tps'], 0, 3), 'is_numeric')
            ));
            $changes['tps'] = self::encode($tps);
        }
        if (is_array($info['worlds'] ?? null)) {
            $worlds = [];
            foreach (array_slice($info['worlds'], 0, 20) as $world) {
                if (!is_array($world) || !is_scalar($world['name'] ?? null)) {
                    continue;
                }
                $worlds[] = [
                    'name' => self::text($world['name'], 64),
                    'environment' => self::text($world['environment'] ?? '', 20),
                    'players' => max(0, (int)($world['players'] ?? 0)),
                ];
            }
            $changes['worlds'] = self::encode($worlds);
        }

        return $changes;
    }

    private static function name(mixed $value, string $uuid): string
    {
        $name = self::text($value, 32);

        return $name === '' ? substr($uuid, 0, 8) : $name;
    }

    private static function text(mixed $value, int $length): string
    {
        if (!is_scalar($value)) {
            return '';
        }
        // the motd may carry §-colour codes - they mean nothing outside the game
        $text = preg_replace('/§[0-9a-fk-orx]/iu', '', (string)$value) ?? '';
        $text = trim(preg_replace('/\s+/u', ' ', $text) ?? '');

        return mb_substr($text, 0, $length);
    }
}
