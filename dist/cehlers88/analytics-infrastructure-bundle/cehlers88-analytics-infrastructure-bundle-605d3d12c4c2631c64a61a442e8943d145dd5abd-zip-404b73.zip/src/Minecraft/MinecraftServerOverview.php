<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsInfrastructureBundle\Minecraft;

/**
 * What the widget shows of a server: the attributes MinecraftServerState keeps, read at a
 * given moment - who is online and for how long, everyone who was ever there with their
 * play time (the running session included), the latest joins and quits and the server's
 * own numbers. Plain arrays, so the template needs no logic and this can be checked
 * without the container.
 *
 * The status:
 *   online       the plugin reported within the last $offlineAfterSeconds
 *   unreachable  it was online, but has not reported for longer - crashed, network gone,
 *                plugin removed; the player list is then shown as "zuletzt online"
 *   offline      it said goodbye (server_stop)
 *   unknown      it never reported
 */
final class MinecraftServerOverview
{
    public const string STATUS_ONLINE = 'online';
    public const string STATUS_UNREACHABLE = 'unreachable';
    public const string STATUS_OFFLINE = 'offline';
    public const string STATUS_UNKNOWN = 'unknown';

    public const int DEFAULT_OFFLINE_AFTER_SECONDS = 180;

    /**
     * @param array<string, mixed> $attributes the attributes of a MinecraftServer
     *
     * @return array<string, mixed>
     */
    public static function build(
        string             $name,
        array              $attributes,
        \DateTimeImmutable $now,
        int                $offlineAfterSeconds = self::DEFAULT_OFFLINE_AFTER_SECONDS,
        int                $knownPlayersLimit = 20,
        int                $eventsLimit = 8,
    ): array
    {
        $lastSeen = MinecraftServerState::parseTime($attributes['last_seen_at'] ?? null);
        $status = match (true) {
            $lastSeen === null => self::STATUS_UNKNOWN,
            ($attributes['status'] ?? '') === 'offline' => self::STATUS_OFFLINE,
            $now->getTimestamp() - $lastSeen->getTimestamp() > max(30, $offlineAfterSeconds) => self::STATUS_UNREACHABLE,
            default => self::STATUS_ONLINE,
        };
        // While unreachable nobody knows when the players left - their time counts up to the
        // last report, not up to now.
        $countUntil = $status === self::STATUS_ONLINE ? $now : ($lastSeen ?? $now);

        $online = [];
        foreach (MinecraftServerState::decode($attributes['online_players'] ?? null) as $player) {
            if (!is_array($player) || !is_string($player['uuid'] ?? null)) {
                continue;
            }
            $since = MinecraftServerState::parseTime($player['since'] ?? null);
            $online[$player['uuid']] = [
                'uuid' => $player['uuid'],
                'name' => (string)($player['name'] ?? ''),
                'world' => (string)($player['world'] ?? ''),
                'since' => $since,
                'seconds' => $since === null ? 0 : max(0, $countUntil->getTimestamp() - $since->getTimestamp()),
            ];
        }
        if ($status === self::STATUS_OFFLINE) {
            $online = [];
        }
        // longest online first
        uasort($online, static fn(array $a, array $b): int => $b['seconds'] <=> $a['seconds']);

        $known = [];
        foreach (MinecraftServerState::decode($attributes['known_players'] ?? null) as $uuid => $player) {
            if (!is_array($player)) {
                continue;
            }
            $current = $online[$uuid] ?? null;
            $known[] = [
                'uuid' => (string)$uuid,
                'name' => (string)($player['name'] ?? ''),
                'firstSeen' => MinecraftServerState::parseTime($player['first_seen'] ?? null),
                'lastSeen' => MinecraftServerState::parseTime($player['last_seen'] ?? null),
                'sessions' => (int)($player['sessions'] ?? 0),
                'playtime' => (int)($player['playtime'] ?? 0) + ($current['seconds'] ?? 0),
                'online' => $current !== null && $status === self::STATUS_ONLINE,
            ];
        }
        // the ones online first, then by when they were last there
        usort($known, static function (array $a, array $b): int {
            if ($a['online'] !== $b['online']) {
                return $a['online'] ? -1 : 1;
            }

            return ($b['lastSeen']?->getTimestamp() ?? 0) <=> ($a['lastSeen']?->getTimestamp() ?? 0);
        });

        $events = [];
        foreach (array_slice(MinecraftServerState::decode($attributes['recent_events'] ?? null), 0, max(0, $eventsLimit)) as $event) {
            if (!is_array($event)) {
                continue;
            }
            $events[] = [
                'type' => (string)($event['type'] ?? ''),
                'at' => MinecraftServerState::parseTime($event['at'] ?? null),
                'name' => (string)($event['name'] ?? ''),
                'uuid' => (string)($event['uuid'] ?? ''),
            ];
        }

        $tps = array_values(array_filter(MinecraftServerState::decode($attributes['tps'] ?? null), 'is_numeric'));
        $startedAt = MinecraftServerState::parseTime($attributes['started_at'] ?? null);
        $memoryMax = (int)($attributes['memory_max_mb'] ?? 0);

        return [
            'name' => $name,
            'serverId' => (string)($attributes[MinecraftServer::ATTRIBUTE_SERVER_ID] ?? ''),
            'status' => $status,
            'lastSeen' => $lastSeen,
            'secondsSinceLastSeen' => $lastSeen === null ? null : max(0, $now->getTimestamp() - $lastSeen->getTimestamp()),
            'startedAt' => $startedAt,
            'uptimeSeconds' => $status === self::STATUS_ONLINE && $startedAt !== null ? max(0, $now->getTimestamp() - $startedAt->getTimestamp()) : null,
            'stoppedAt' => MinecraftServerState::parseTime($attributes['stopped_at'] ?? null),
            'version' => (string)($attributes['version'] ?? ''),
            'software' => (string)($attributes['software'] ?? ''),
            'motd' => (string)($attributes['motd'] ?? ''),
            'pluginVersion' => (string)($attributes['plugin_version'] ?? ''),
            'maxPlayers' => (int)($attributes['max_players'] ?? 0),
            'onlineMode' => ($attributes['online_mode'] ?? '1') !== '0',
            'tps' => $tps === [] ? null : round((float)$tps[0], 1),
            'tpsAll' => array_map(static fn(mixed $value): float => round((float)$value, 1), $tps),
            'mspt' => is_numeric($attributes['mspt'] ?? null) ? (float)$attributes['mspt'] : null,
            'memoryUsedMb' => (int)($attributes['memory_used_mb'] ?? 0),
            'memoryMaxMb' => $memoryMax,
            'memoryShare' => $memoryMax > 0 ? min(1.0, (int)($attributes['memory_used_mb'] ?? 0) / $memoryMax) : null,
            'worlds' => MinecraftServerState::decode($attributes['worlds'] ?? null),
            'peakPlayers' => (int)($attributes['peak_players'] ?? 0),
            'peakPlayersAt' => MinecraftServerState::parseTime($attributes['peak_players_at'] ?? null),
            'online' => array_values($online),
            'onlineCount' => count($online),
            'known' => array_slice($known, 0, max(0, $knownPlayersLimit)),
            'knownCount' => count($known),
            'events' => $events,
        ];
    }
}
