<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsInfrastructureBundle\Minecraft;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

/**
 * A Minecraft server that reports to this installation through the plugin in
 * minecraft-plugin/ - created by MinecraftEventEndpointRunner on its first event, one per
 * server_id (the "server-id" of the plugin's config.yml). The name is only set then and may
 * be changed freely; the server is recognised by its server_id.
 *
 * Everything the plugin reports lives in attributes of this one object (MinecraftServerState
 * knows them). Lists and maps are JSON strings (MinecraftServerState::JSON_ATTRIBUTES): custom
 * objects cannot be deleted from here, so there is no child object per player.
 *
 * Everything about Minecraft is in src/Minecraft/ and templates/widget/minecraftServer.html.twig
 * (plus a block in services.yaml) so it can move to a bundle of its own by copying.
 */
class MinecraftServer extends AbstractCustomObject
{
    public const string ATTRIBUTE_SERVER_ID = 'server_id';

    public function getServerId(): string
    {
        return (string)$this->getAttribute(self::ATTRIBUTE_SERVER_ID, '');
    }

    public function setServerId(string $serverId): static
    {
        return $this->setAttribute(self::ATTRIBUTE_SERVER_ID, $serverId);
    }
}
