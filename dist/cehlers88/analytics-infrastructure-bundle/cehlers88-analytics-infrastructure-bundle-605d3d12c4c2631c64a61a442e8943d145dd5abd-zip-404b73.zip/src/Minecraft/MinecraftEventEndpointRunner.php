<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsInfrastructureBundle\Minecraft;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;
use Symfony\Component\HttpFoundation\Request;

/**
 * Empfängt die Meldungen des Minecraft-Plugins (minecraft-plugin/):
 *
 *   POST /api/se/minecraftServerEvent
 *   Header X-Analytics-Token: <Wert der Konstante MINECRAFT_SERVER_TOKEN>
 *   Body   JSON, siehe README ("Minecraft server status")
 *
 * The endpoint is public like every /api/se call - the plugin cannot sign in. What keeps
 * strangers out is the token, compared with the constant MINECRAFT_SERVER_TOKEN (settings →
 * Constants). Without that constant every call is refused, never accepted. The token travels
 * in a header of its own, not as "Authorization: Bearer": the JWT firewall of /api would take
 * a bearer token for a JWT and refuse the request before it gets here.
 *
 * The event is applied at once (MinecraftServerState) to the MinecraftServer custom object of
 * its server_id, created on the server's first event. Saving the object fires the
 * DatabaseChanged event the dashboard gets through Mercure, so the widget follows live.
 */
final class MinecraftEventEndpointRunner extends AbstractServiceEndpointRunner
{
    public const string ENDPOINT = 'minecraft_server_event';
    public const string ALIAS = 'minecraftServerEvent';
    public const string TOKEN_CONSTANT = 'MINECRAFT_SERVER_TOKEN';
    public const string TOKEN_HEADER = 'X-Analytics-Token';
    /** A heartbeat with 100 players is about 15 KB - anything far above is no plugin. */
    public const int MAX_BODY_BYTES = 262144;

    public function __construct(
        private readonly CustomObjectProvider  $customObjectProvider,
        private readonly ConfigurationProvider $configurationProvider,
    )
    {
    }

    public function getEndpoints(): mixed
    {
        $endpoint = EndpointDefinitionDTO::create(
            self::ENDPOINT,
            ['POST'],
            [],
            [],
            'Meldungen des Minecraft-Plugins (Serverstart/-stopp, Join/Quit, Heartbeat mit Spielerliste). '
            . 'Token im Header ' . self::TOKEN_HEADER . ', geprüft gegen die Konstante ' . self::TOKEN_CONSTANT . '.'
        )
            ->withSuccessExample(['server' => 'survival', 'event' => 'heartbeat', 'online' => 2], 'Minecraft event received')
            ->withErrorExample('Invalid token', 401);
        $endpoint->aliases = [self::ALIAS];

        return [$endpoint];
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }

    /** The plugin cannot sign in - the token is the authentication. */
    public function getRequiredRoles(): array
    {
        return [];
    }

    public function handleRequest(string $endpointName, Request $request): ServiceEndpointRunnerResultDTO
    {
        $expected = $this->token();
        if ($expected === '') {
            // not the plugin's fault - it keeps sending and gets through once the constant is set
            return ServiceEndpointRunnerResultDTO::createError(sprintf('Token not configured (constant %s)', self::TOKEN_CONSTANT), 503);
        }
        $given = trim((string)$request->headers->get(self::TOKEN_HEADER, ''));
        if ($given === '' || !hash_equals($expected, $given)) {
            return ServiceEndpointRunnerResultDTO::createError('Invalid token', 401);
        }

        $body = $request->getContent();
        if (strlen($body) > self::MAX_BODY_BYTES) {
            return ServiceEndpointRunnerResultDTO::createError('Body too large', 413);
        }
        $event = json_decode($body, true);
        if (!is_array($event)) {
            return ServiceEndpointRunnerResultDTO::createError('Body is no JSON object', 400);
        }

        $serverId = self::serverId($event['server']['id'] ?? null);
        if ($serverId === null) {
            return ServiceEndpointRunnerResultDTO::createError('server.id missing or invalid (a-z, 0-9, "-", "_", "." - up to 64)', 400);
        }
        if (!in_array($event['event'] ?? null, MinecraftServerState::EVENTS, true)) {
            return ServiceEndpointRunnerResultDTO::createError('Unknown event, expected one of ' . implode(', ', MinecraftServerState::EVENTS), 400);
        }

        // The list is what the stored state follows - without one, an empty list would be
        // assumed and everybody online would be signed off.
        if (!is_array($event['players'] ?? null) || !array_is_list($event['players'])) {
            return ServiceEndpointRunnerResultDTO::createError('players missing: every event carries the list of the players online', 400);
        }

        // Read, apply and save belong together: two events of one server arriving at the same
        // moment would otherwise both start from the same old state, and the one saving last
        // would undo the other (or both would create the server).
        $lock = $this->lock($serverId);
        try {
            $server = $this->findOrCreate($serverId, $event['server']['name'] ?? null);
            $changes = MinecraftServerState::apply($server->getAttributes(), $event, new \DateTimeImmutable());
            foreach ($changes as $name => $value) {
                $server->setAttribute($name, $value);
            }
            $this->customObjectProvider->save($server);
        } finally {
            if (is_resource($lock)) {
                flock($lock, LOCK_UN);
                fclose($lock);
            }
        }

        return ServiceEndpointRunnerResultDTO::createSuccess([
            'server' => $serverId,
            'event' => $event['event'],
            'online' => count(MinecraftServerState::decode($server->getAttribute('online_players'))),
        ], 'Minecraft event received');
    }

    /**
     * An exclusive lock per server id, held until it is released (or the request ends). A
     * lock file is enough: the plugin reports to one installation on one machine. Without a
     * writable temp directory the event is applied unlocked rather than refused.
     *
     * @return resource|null
     */
    private function lock(string $serverId): mixed
    {
        $file = @fopen(sys_get_temp_dir() . '/analytics-minecraft-' . hash('sha256', $serverId) . '.lock', 'c');
        if ($file === false) {
            return null;
        }
        if (!flock($file, LOCK_EX)) {
            fclose($file);

            return null;
        }

        return $file;
    }

    /** The server of the id; a new one is named after what the plugin calls it. */
    private function findOrCreate(string $serverId, mixed $name): MinecraftServer
    {
        foreach ($this->customObjectProvider->getCustomEntitiesByClassNameAndAttribute(MinecraftServer::class, MinecraftServer::ATTRIBUTE_SERVER_ID, $serverId) as $server) {
            if ($server instanceof MinecraftServer) {
                return $server;
            }
        }

        /** @var MinecraftServer $server */
        $server = $this->customObjectProvider->createNewCustomEntity(MinecraftServer::class);
        $name = is_string($name) ? trim($name) : '';
        $server->setName(mb_substr($name !== '' ? $name : 'Minecraft ' . $serverId, 0, 120));
        $server->setServerId($serverId);

        return $server;
    }

    private static function serverId(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }
        $value = strtolower(trim($value));

        return preg_match('/^[a-z0-9._-]{1,64}$/', $value) === 1 ? $value : null;
    }

    /** The constant of the server (settings → Constants), '' when it is not set. */
    private function token(): string
    {
        foreach ([ConfigurationProvider::KEY_CONSTANTS, strtolower(ConfigurationProvider::KEY_CONSTANTS)] as $prefix) {
            $value = $this->configurationProvider->getValue($prefix, self::TOKEN_CONSTANT, -1, '');
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
        }

        return '';
    }
}
