# AnalyticsStatus – Minecraft-Plugin

Meldet den Status eines Minecraft-Servers an Analytics: Start und Stopp des Servers, jeden
Beitritt und jedes Verlassen und einmal pro Minute einen Heartbeat mit der Liste der Spieler,
TPS, Arbeitsspeicher, Version und Welten. In Analytics zeigt das die Kachel
**AnalyticsInfrastructureBundle.minecraftServer**.

Das Plugin liegt vorerst im Infrastructure-Bundle, ist aber eigenständig: Der Ordner
`minecraft-plugin/` kann so, wie er ist, in ein eigenes Repository umziehen. Vom PHP-Code des
Bundles hängt hier nichts ab – die einzige Verbindung ist das JSON-Format weiter unten.

## Voraussetzungen

- Server: Paper, Purpur oder Spigot ab Minecraft 1.18 (TPS und MSPT gibt es nur auf Paper und Ablegern)
- Zum Bauen: Java 17 oder neuer und Maven

## Bauen und installieren

```bash
cd minecraft-plugin
mvn package
```

1. `target/analytics-minecraft-status-1.0.0.jar` in den Ordner `plugins/` des Servers kopieren
   und den Server starten. Dabei entsteht `plugins/AnalyticsStatus/config.yml`.
2. In Analytics unter *Einstellungen → Konstanten* die Konstante `MINECRAFT_SERVER_TOKEN`
   anlegen – ein langes, zufälliges Geheimnis, z. B. aus `openssl rand -hex 32`.
3. In `plugins/AnalyticsStatus/config.yml` `url` (deine Analytics-Adresse +
   `/api/se/minecraftServerEvent`), denselben `token` und eine `server-id` eintragen.
4. Im Spiel oder in der Konsole: `/analyticsstatus reload`, danach `/analyticsstatus` – dort
   steht, ob die letzte Meldung ankam (und wenn nicht, warum).
5. Im Dashboard eine Kachel vom Typ *AnalyticsInfrastructureBundle.minecraftServer* anlegen.

| Befehl | |
|---|---|
| `/analyticsstatus` | Ziel, Server-ID und Ergebnis der letzten Meldung |
| `/analyticsstatus reload` | `config.yml` neu einlesen |
| `/analyticsstatus send` | sofort einen Heartbeat senden (zum Testen) |

Berechtigung: `analyticsstatus.admin` (Standard: Operatoren und Konsole). Alias: `/astatus`.

## Aufbau des Codes

```
src/main/resources/plugin.yml    Steckbrief: Name, Hauptklasse, Befehl, Berechtigung
src/main/resources/config.yml    Vorlage der Konfiguration (mit Erklärungen)
src/main/java/de/cehlers/analytics/minecraft/
  AnalyticsStatusPlugin.java     Einstieg: Start, Stopp, Heartbeat-Timer, Befehl
  PluginSettings.java            die Werte aus der config.yml
  StatusCollector.java           sammelt die Daten, baut die Meldung
  PlayerListener.java            reagiert auf Join und Quit
  AnalyticsClient.java           sendet die Meldung per HTTP
```

Jede Datei ist ausführlich kommentiert. Die drei häufigsten Erweiterungen:

- **Weitere Angabe zum Server melden:** in `StatusCollector.collectServerInfo()` eine Zeile
  `info.put("name", wert)` ergänzen.
- **Weiteres Ereignis melden:** in `PlayerListener` eine Methode mit `@EventHandler` ergänzen
  (die Anleitung steht im Kommentar der Klasse).
- **Neue Einstellung:** `config.yml` + `PluginSettings` (ebenfalls dort beschrieben).

Damit Analytics etwas Neues auch anzeigt, muss es dort ausgewertet werden:
`src/Minecraft/MinecraftServerState.php` (speichern), `MinecraftServerOverview.php` (aufbereiten)
und `templates/widget/minecraftServer.html.twig` (anzeigen). Unbekannte Felder werden bis dahin
ignoriert, ein unbekanntes `event` wird mit HTTP 400 abgelehnt.

## Das Format der Meldungen

`POST <url>` mit `Content-Type: application/json` und dem Header `X-Analytics-Token: <token>`.

```json
{
  "event": "player_join",
  "occurred_at": "2026-11-11T13:20:00Z",
  "plugin_version": "1.0.0",
  "server": { "id": "survival", "name": "Survival" },
  "player": { "uuid": "069a79f4-44e9-4726-a5be-fca90e38aaf5", "name": "Notch" },
  "players": [
    { "uuid": "069a79f4-44e9-4726-a5be-fca90e38aaf5", "name": "Notch",
      "joined_at": "2026-11-11T13:20:00Z", "world": "world" }
  ],
  "info": {
    "version": "1.21.4", "software": "Paper", "motd": "Willkommen!",
    "max_players": 20, "online_mode": true, "started_at": "2026-11-11T11:29:00Z",
    "memory_used_mb": 2870, "memory_max_mb": 6144,
    "tps": [19.97, 19.9, 19.95], "mspt": 11.4,
    "worlds": [ { "name": "world", "environment": "NORMAL", "players": 1 } ]
  }
}
```

| `event` | Wann | `player` |
|---|---|---|
| `server_start` | Plugin wurde geladen | – |
| `heartbeat` | alle `heartbeat-seconds` | – |
| `player_join` | Spieler ist beigetreten | der Spieler |
| `player_quit` | Spieler ist gegangen (steht nicht mehr in `players`) | der Spieler |
| `server_stop` | Server fährt herunter | – |

`players` ist in **jeder** Meldung die vollständige Liste der Spieler, die gerade online sind.
Geht eine Meldung verloren, stimmt der Stand nach dem nächsten Heartbeat wieder. Stürzt der
Server ab (kein `server_stop`), zeigt Analytics ihn nach drei Minuten ohne Meldung als „nicht
erreichbar“.

Antworten: `200` angekommen · `400` Meldung fehlerhaft · `401` Token falsch ·
`503` Konstante `MINECRAFT_SERVER_TOKEN` in Analytics nicht gesetzt.

## Hinweise

- Gesendet wird im Hintergrund und immer nur eine Meldung gleichzeitig, in der Reihenfolge,
  in der sie entstanden sind. Der Server wartet nie auf Analytics. Nur beim Herunterfahren
  wartet er höchstens `timeout-seconds` auf die Abschiedsmeldung.
- Ist Analytics nicht erreichbar, steht das einmal im Server-Log (nicht jede Minute) und noch
  einmal, sobald es wieder klappt. Verpasste Meldungen werden nicht nachgeholt.
- Der Token wird im Klartext übertragen – `url` deshalb mit `https://` verwenden.
