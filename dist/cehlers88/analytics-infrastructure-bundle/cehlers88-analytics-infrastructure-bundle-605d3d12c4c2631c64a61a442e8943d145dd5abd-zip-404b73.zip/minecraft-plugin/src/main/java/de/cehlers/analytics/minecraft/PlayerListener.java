package de.cehlers.analytics.minecraft;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Reagiert auf Ereignisse im Spiel.
 *
 * So funktionieren Events in Bukkit/Paper:
 *   - Die Klasse implementiert das (leere) Interface Listener.
 *   - Jede Methode mit @EventHandler wird vom Server aufgerufen, sobald das Ereignis eintritt,
 *     das als Parameter angegeben ist. Der Name der Methode ist egal - der Parametertyp zaehlt.
 *   - Angemeldet wird der Listener einmal in AnalyticsStatusPlugin.onEnable().
 *
 * WEITERES EREIGNIS MELDEN (z. B. Tod eines Spielers):
 *   1. hier eine Methode mit @EventHandler und dem passenden Event (PlayerDeathEvent) ergaenzen,
 *   2. in StatusCollector einen neuen EVENT_...-Namen anlegen,
 *   3. in Analytics den Namen in MinecraftServerState::EVENTS aufnehmen und auswerten.
 */
public class PlayerListener implements Listener {

    private final AnalyticsStatusPlugin plugin;
    private final StatusCollector collector;

    public PlayerListener(AnalyticsStatusPlugin plugin, StatusCollector collector) {
        this.plugin = plugin;
        this.collector = collector;
    }

    /**
     * Ein Spieler hat den Server betreten.
     * MONITOR = "nur zuschauen": Diese Methode laeuft nach allen anderen Plugins und aendert nichts am Event.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event) {
        collector.rememberJoin(event.getPlayer());
        plugin.send(collector.buildEvent(StatusCollector.EVENT_PLAYER_JOIN, event.getPlayer(), null));
    }

    /** Ein Spieler hat den Server verlassen (auch bei Kick oder Verbindungsabbruch). */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        // Der Spieler steht in diesem Moment noch in Bukkit.getOnlinePlayers() - deshalb wird er
        // als dritter Parameter mitgegeben und aus der Online-Liste der Meldung herausgelassen.
        plugin.send(collector.buildEvent(StatusCollector.EVENT_PLAYER_QUIT, event.getPlayer(), event.getPlayer()));
        collector.forgetPlayer(event.getPlayer());
    }
}
