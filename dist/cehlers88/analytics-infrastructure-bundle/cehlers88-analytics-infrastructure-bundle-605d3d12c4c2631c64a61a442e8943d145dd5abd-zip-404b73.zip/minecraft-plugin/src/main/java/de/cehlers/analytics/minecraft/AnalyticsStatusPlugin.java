package de.cehlers.analytics.minecraft;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;

/**
 * Hauptklasse des Plugins - der Einstiegspunkt (in der plugin.yml unter "main" eingetragen).
 *
 * Der Server ruft auf:
 *   onEnable()   beim Start des Servers (und nach einem Reload),
 *   onDisable()  beim Herunterfahren,
 *   onCommand()  wenn jemand /analyticsstatus eingibt.
 *
 * Aufgabenteilung der Klassen:
 *   AnalyticsStatusPlugin  startet und stoppt alles (diese Datei)
 *   PluginSettings         die Werte aus der config.yml
 *   StatusCollector        sammelt die Daten und baut die Meldung
 *   PlayerListener         reagiert auf Join und Quit
 *   AnalyticsClient        schickt die Meldung per HTTP an Analytics
 */
public class AnalyticsStatusPlugin extends JavaPlugin {

    /** Ein Tick ist 1/20 Sekunde - der Scheduler von Bukkit rechnet in Ticks. */
    private static final long TICKS_PER_SECOND = 20L;

    // Diese drei werden in start() gesetzt und bei einem Reload neu erzeugt.
    private PluginSettings settings;
    private StatusCollector collector;
    private AnalyticsClient client;

    /** true, sobald die Konfiguration vollstaendig ist und gesendet wird. */
    private boolean active = false;

    @Override
    public void onEnable() {
        // Kopiert die mitgelieferte config.yml nach plugins/AnalyticsStatus/, falls dort noch keine liegt.
        saveDefaultConfig();
        start();
    }

    @Override
    public void onDisable() {
        if (active) {
            // Hier bewusst warten: Nach onDisable() ist der Server weg, die Abschiedsmeldung
            // kaeme sonst nie an.
            client.sendAndWait(collector.buildEvent(StatusCollector.EVENT_SERVER_STOP));
        }
        stop();
    }

    /**
     * /analyticsstatus          zeigt den Zustand
     * /analyticsstatus reload   liest die config.yml neu
     * /analyticsstatus send     sendet sofort einen Heartbeat (zum Testen)
     *
     * Der Befehl und seine Berechtigung stehen in der plugin.yml.
     *
     * @return true = Befehl verstanden; bei false zeigt der Server den "usage"-Text aus der plugin.yml
     */
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // args sind die Woerter nach dem Befehl; ohne Wort wird der Zustand gezeigt.
        String action = args.length == 0 ? "status" : args[0].toLowerCase();

        switch (action) {
            case "reload" -> {
                stop();
                reloadConfig(); // liest die Datei neu von der Festplatte
                start();
                sender.sendMessage(active
                        ? "[AnalyticsStatus] Konfiguration neu geladen."
                        : "[AnalyticsStatus] Konfiguration unvollstaendig: " + settings.problem());
                return true;
            }
            case "send" -> {
                if (!active) {
                    sender.sendMessage("[AnalyticsStatus] Nicht aktiv: " + settings.problem());
                    return true;
                }
                send(collector.buildEvent(StatusCollector.EVENT_HEARTBEAT));
                sender.sendMessage("[AnalyticsStatus] Gesendet - Ergebnis gleich mit /" + label + " ansehen.");
                return true;
            }
            case "status" -> {
                sender.sendMessage("[AnalyticsStatus] Ziel: " + settings.url());
                sender.sendMessage("[AnalyticsStatus] Server-ID: " + settings.serverId()
                        + ", Heartbeat alle " + settings.heartbeatSeconds() + " s");
                sender.sendMessage(active
                        ? "[AnalyticsStatus] Letzte Meldung: " + client.getLastResult()
                        : "[AnalyticsStatus] Nicht aktiv: " + settings.problem());
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    /**
     * Schickt eine Meldung ab, ohne den Server aufzuhalten.
     * Wird vom PlayerListener und vom Heartbeat benutzt.
     */
    public void send(Map<String, Object> payload) {
        if (active) {
            client.sendAsync(payload);
        }
    }

    /** Liest die Konfiguration und setzt alles in Gang. */
    private void start() {
        settings = PluginSettings.from(getConfig());

        String problem = settings.problem();
        if (problem != null) {
            // Ohne gueltige Konfiguration bleibt das Plugin geladen, tut aber nichts.
            active = false;
            getLogger().warning(problem + " Es wird nichts gesendet. Danach: /analyticsstatus reload");
            return;
        }

        collector = new StatusCollector(settings, getDescription().getVersion());
        client = new AnalyticsClient(settings, getLogger());
        active = true;

        // Den Listener anmelden - ab jetzt ruft der Server onPlayerJoin()/onPlayerQuit() auf.
        getServer().getPluginManager().registerEvents(new PlayerListener(this, collector), this);

        // Einmal melden, dass der Server (wieder) da ist ...
        send(collector.buildEvent(StatusCollector.EVENT_SERVER_START));

        // ... und danach regelmaessig einen Heartbeat. runTaskTimer fuehrt die Aufgabe im
        // Main-Thread aus (dort darf die Bukkit-API benutzt werden): erst nach "period" Ticks,
        // dann immer wieder im selben Abstand.
        long period = settings.heartbeatSeconds() * TICKS_PER_SECOND;
        getServer().getScheduler().runTaskTimer(
                this,
                () -> send(collector.buildEvent(StatusCollector.EVENT_HEARTBEAT)),
                period,
                period
        );

        getLogger().info("Melde an " + settings.url() + " als \"" + settings.serverId() + "\".");
    }

    /** Haelt Heartbeat und Listener an (beim Herunterfahren und vor einem Reload). */
    private void stop() {
        getServer().getScheduler().cancelTasks(this); // alle Timer dieses Plugins
        HandlerList.unregisterAll(this);              // alle Listener dieses Plugins
        if (client != null) {
            client.close();                           // Hintergrund-Thread des Versands beenden
            client = null;
        }
        active = false;
    }
}
