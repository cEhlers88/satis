package de.cehlers.analytics.minecraft;

import com.google.gson.Gson;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;

/**
 * Schickt die Meldungen per HTTP-POST als JSON an Analytics.
 *
 * Wichtig fuer Minecraft: Der Server rechnet alles in EINEM Thread (dem "Main-Thread"), 20-mal
 * pro Sekunde. Wuerde dieser Thread auf eine Antwort aus dem Internet warten, stuende das Spiel
 * so lange still. Deshalb sendet {@link #sendAsync} im Hintergrund und kehrt sofort zurueck.
 * Nur beim Herunterfahren wird gewartet ({@link #sendAndWait}), weil der Server danach weg ist.
 *
 * Die Meldungen gehen nacheinander raus, immer nur eine gleichzeitig und in der Reihenfolge, in
 * der sie entstanden sind. Wuerden mehrere gleichzeitig gesendet, koennte eine aeltere Meldung
 * NACH einer neueren bei Analytics ankommen (z. B. ein Heartbeat nach dem "server_stop") und den
 * neueren Stand ueberschreiben.
 */
public class AnalyticsClient {

    /** Name des Headers, in dem der Token steht - so erwartet es der Endpunkt in Analytics. */
    private static final String TOKEN_HEADER = "X-Analytics-Token";

    private final PluginSettings settings;
    private final Logger logger;

    /** Der HTTP-Client von Java selbst (seit Java 11) - keine zusaetzliche Bibliothek noetig. */
    private final HttpClient httpClient;

    /**
     * Die Warteschlange fuer den Versand: EIN Hintergrund-Thread arbeitet die Meldungen der Reihe
     * nach ab. Warten mehr als 100 (Analytics lange nicht erreichbar), faellt die aelteste weg -
     * jede Meldung enthaelt ohnehin den kompletten Stand.
     */
    private final ExecutorService queue = new ThreadPoolExecutor(
            1, 1,                                   // genau ein Thread
            0L, TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<>(100),         // hoechstens 100 wartende Meldungen
            runnable -> {
                Thread thread = new Thread(runnable, "AnalyticsStatus-Sender");
                thread.setDaemon(true);             // haelt den Server beim Beenden nicht auf
                return thread;
            },
            new ThreadPoolExecutor.DiscardOldestPolicy()
    );

    /** Gson macht aus Java-Objekten (Map, List, String, Zahl ...) JSON-Text. Der Server bringt es mit. */
    private final Gson gson = new Gson();

    /**
     * Ergebnis des letzten Versuchs, fuer /analyticsstatus.
     * AtomicReference, weil der Hintergrund-Thread schreibt und der Main-Thread liest.
     */
    private final AtomicReference<String> lastResult = new AtomicReference<>("noch nichts gesendet");

    /** Merkt sich, ob der letzte Versuch geklappt hat - damit das Log nicht jede Minute dieselbe Warnung zeigt. */
    private volatile boolean lastSendFailed = false;

    public AnalyticsClient(PluginSettings settings, Logger logger) {
        this.settings = settings;
        this.logger = logger;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(settings.timeoutSeconds()))
                .build();
    }

    /**
     * Sendet im Hintergrund: Die Meldung kommt in die Warteschlange, die Methode kehrt sofort
     * zurueck. Das Ergebnis landet in {@link #handleResponse} bzw. {@link #handleFailure}.
     *
     * @param payload die Meldung, so wie {@link StatusCollector} sie gebaut hat
     */
    public void sendAsync(Map<String, Object> payload) {
        queue.execute(() -> sendNow(payload));
    }

    /**
     * Sendet und wartet, bis die Meldung (und alles, was noch davor in der Warteschlange steht)
     * verschickt ist. Nur fuer onDisable(): Danach ist der Server weg, und ein paar Sekunden
     * Warten stoeren beim Herunterfahren nicht. Der Client ist danach nicht mehr benutzbar.
     */
    public void sendAndWait(Map<String, Object> payload) {
        queue.execute(() -> sendNow(payload));
        close();
    }

    /**
     * Beendet den Hintergrund-Thread, nachdem er die wartenden Meldungen verschickt hat -
     * gewartet wird hoechstens zweimal die eingestellte Wartezeit.
     */
    public void close() {
        queue.shutdown(); // nimmt nichts Neues mehr an, arbeitet den Rest aber noch ab
        try {
            if (!queue.awaitTermination(settings.timeoutSeconds() * 2L, TimeUnit.SECONDS)) {
                queue.shutdownNow();
            }
        } catch (InterruptedException error) {
            // Java-Konvention: die Unterbrechung nicht verschlucken, sondern weitermelden
            Thread.currentThread().interrupt();
            queue.shutdownNow();
        }
    }

    /** Verschickt eine Meldung und wartet auf die Antwort. Laeuft im Hintergrund-Thread. */
    private void sendNow(Map<String, Object> payload) {
        String event = String.valueOf(payload.get("event"));
        try {
            HttpResponse<String> response = httpClient.send(buildRequest(payload), HttpResponse.BodyHandlers.ofString());
            handleResponse(event, response);
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            handleFailure(event, error);
        } catch (Exception error) {
            // alles andere: kein Netz, Timeout, ungueltige Adresse ... - nie den Thread abstuerzen lassen
            handleFailure(event, error);
        }
    }

    /** Text fuer /analyticsstatus. */
    public String getLastResult() {
        return lastResult.get();
    }

    private HttpRequest buildRequest(Map<String, Object> payload) {
        String json = gson.toJson(payload);
        if (settings.debug()) {
            logger.info("Sende an Analytics: " + json);
        }
        return HttpRequest.newBuilder()
                .uri(URI.create(settings.url()))
                .timeout(Duration.ofSeconds(settings.timeoutSeconds()))
                .header("Content-Type", "application/json")
                .header(TOKEN_HEADER, settings.token())
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();
    }

    private void handleResponse(String event, HttpResponse<String> response) {
        int status = response.statusCode();
        // 200-299 = Erfolg
        if (status >= 200 && status < 300) {
            lastResult.set("OK (" + event + ", HTTP " + status + ")");
            if (lastSendFailed) {
                logger.info("Analytics ist wieder erreichbar.");
            }
            lastSendFailed = false;
            return;
        }

        // Die haeufigsten Fehler verstaendlich erklaeren; der Rest zeigt die Antwort des Servers.
        String hint = switch (status) {
            case 401 -> "Token stimmt nicht mit der Konstante MINECRAFT_SERVER_TOKEN in Analytics ueberein.";
            case 503 -> "In Analytics ist die Konstante MINECRAFT_SERVER_TOKEN noch nicht gesetzt.";
            case 404 -> "Adresse falsch? Erwartet wird .../api/se/minecraftServerEvent";
            default -> shorten(response.body());
        };
        reportProblem(event, "HTTP " + status + " - " + hint);
    }

    private void handleFailure(String event, Throwable error) {
        reportProblem(event, error.getClass().getSimpleName() + ": " + error.getMessage());
    }

    private void reportProblem(String event, String message) {
        lastResult.set("FEHLER (" + event + "): " + message);
        // Nur beim ersten Fehlschlag warnen, nicht bei jedem Heartbeat erneut.
        if (!lastSendFailed || settings.debug()) {
            logger.warning("Meldung an Analytics fehlgeschlagen: " + message);
        }
        lastSendFailed = true;
    }

    private static String shorten(String text) {
        if (text == null) {
            return "";
        }
        return text.length() <= 200 ? text : text.substring(0, 200) + "...";
    }
}
