package de.cehlers.analytics.minecraft;

import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.lang.management.ManagementFactory;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Sammelt, was gemeldet wird, und baut daraus die Meldung.
 *
 * Eine Meldung ist eine Map (Name -> Wert); Gson macht daraus spaeter JSON. Beispiel:
 *
 *   {
 *     "event": "player_join",
 *     "occurred_at": "2026-11-11T13:20:00Z",
 *     "plugin_version": "1.0.0",
 *     "server":  { "id": "survival", "name": "Survival" },
 *     "player":  { "uuid": "...", "name": "Notch" },            (nur bei player_join / player_quit)
 *     "players": [ { "uuid": "...", "name": "Notch", "joined_at": "...", "world": "world" } ],
 *     "info":    { "version": "1.21.4", "software": "Paper", "started_at": "...", "tps": [20.0, 20.0, 20.0], ... }
 *   }
 *
 * JEDE Meldung enthaelt die komplette Liste der Spieler, die gerade online sind. Geht einmal eine
 * Meldung verloren, stimmt der Stand in Analytics spaetestens nach dem naechsten Heartbeat wieder.
 *
 * ACHTUNG: Alle Methoden hier muessen im Main-Thread des Servers aufgerufen werden - die
 * Bukkit-API (Bukkit.getOnlinePlayers() usw.) darf nicht aus Hintergrund-Threads benutzt werden.
 * Events und runTaskTimer() laufen automatisch im Main-Thread.
 *
 * WEITERE INFORMATIONEN MELDEN: in {@link #collectServerInfo()} eine Zeile info.put("name", wert)
 * ergaenzen. Analytics ignoriert unbekannte Felder, bis sie dort ausgewertet werden
 * (MinecraftServerState::info() im Bundle).
 */
public class StatusCollector {

    // Die Namen der Ereignisse - Analytics kennt genau diese fuenf.
    public static final String EVENT_SERVER_START = "server_start";
    public static final String EVENT_HEARTBEAT = "heartbeat";
    public static final String EVENT_PLAYER_JOIN = "player_join";
    public static final String EVENT_PLAYER_QUIT = "player_quit";
    public static final String EVENT_SERVER_STOP = "server_stop";

    private final PluginSettings settings;
    private final String pluginVersion;

    /**
     * Wann welcher Spieler beigetreten ist (UUID -> Zeitpunkt). Bukkit selbst merkt sich das nicht.
     * ConcurrentHashMap ist die Variante von HashMap, die auch bei mehreren Threads sicher ist.
     */
    private final Map<UUID, Instant> joinTimes = new ConcurrentHashMap<>();

    public StatusCollector(PluginSettings settings, String pluginVersion) {
        this.settings = settings;
        this.pluginVersion = pluginVersion;
    }

    /** Vom PlayerListener beim Beitritt aufgerufen. */
    public void rememberJoin(Player player) {
        joinTimes.put(player.getUniqueId(), Instant.now());
    }

    /** Vom PlayerListener beim Verlassen aufgerufen. */
    public void forgetPlayer(Player player) {
        joinTimes.remove(player.getUniqueId());
    }

    /**
     * Baut eine Meldung ohne bestimmten Spieler (Start, Heartbeat, Stopp).
     */
    public Map<String, Object> buildEvent(String event) {
        return buildEvent(event, null, null);
    }

    /**
     * Baut eine Meldung.
     *
     * @param event         einer der EVENT_...-Namen oben
     * @param subject       der Spieler, um den es geht (bei Join/Quit), sonst null
     * @param leavingPlayer ein Spieler, der NICHT in der Online-Liste stehen soll, sonst null.
     *                      Noetig beim Quit: Wenn das Quit-Event feuert, fuehrt Bukkit den
     *                      Spieler noch als online.
     */
    public Map<String, Object> buildEvent(String event, Player subject, Player leavingPlayer) {
        // LinkedHashMap behaelt die Reihenfolge der Eintraege - das JSON bleibt so gut lesbar.
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("event", event);
        payload.put("occurred_at", timestamp(Instant.now()));
        payload.put("plugin_version", pluginVersion);

        Map<String, Object> server = new LinkedHashMap<>();
        server.put("id", settings.serverId());
        server.put("name", settings.serverName());
        payload.put("server", server);

        if (subject != null) {
            Map<String, Object> player = new LinkedHashMap<>();
            player.put("uuid", subject.getUniqueId().toString());
            player.put("name", subject.getName());
            payload.put("player", player);
        }

        payload.put("players", collectOnlinePlayers(leavingPlayer));
        payload.put("info", collectServerInfo());
        return payload;
    }

    /** Die Liste der Spieler, die gerade online sind. */
    private List<Map<String, Object>> collectOnlinePlayers(Player leavingPlayer) {
        List<Map<String, Object>> players = new ArrayList<>();

        for (Player player : Bukkit.getOnlinePlayers()) {
            if (leavingPlayer != null && player.getUniqueId().equals(leavingPlayer.getUniqueId())) {
                continue; // dieser Spieler geht gerade - nicht mehr mitzaehlen
            }

            // computeIfAbsent: den gemerkten Zeitpunkt nehmen - gibt es keinen (z. B. weil das
            // Plugin im laufenden Betrieb neu geladen wurde), ihn ermitteln, eintragen und nehmen.
            Instant joinedAt = joinTimes.computeIfAbsent(player.getUniqueId(), uuid -> loginTimeOf(player));

            Map<String, Object> entry = new LinkedHashMap<>();
            entry.put("uuid", player.getUniqueId().toString());
            entry.put("name", player.getName());
            entry.put("joined_at", timestamp(joinedAt));
            entry.put("world", player.getWorld().getName());
            players.add(entry);
        }
        return players;
    }

    /**
     * Wann der Spieler sich angemeldet hat, wenn das Plugin es nicht selbst miterlebt hat.
     * Paper kennt den Zeitpunkt (getLastLogin(), Millisekunden seit 1970), Spigot nicht - dort
     * bleibt nur "jetzt". Analytics sieht einen spaeteren Beitritt als neue Sitzung an, deshalb
     * ist der echte Zeitpunkt besser.
     */
    private static Instant loginTimeOf(Player player) {
        Object lastLogin = callIfAvailable(player, "getLastLogin");
        if (lastLogin instanceof Long millis && millis > 0) {
            return Instant.ofEpochMilli(millis);
        }
        return Instant.now();
    }

    /**
     * Angaben zum Server selbst. HIER ERWEITERN, wenn Analytics mehr wissen soll.
     */
    private Map<String, Object> collectServerInfo() {
        Server server = Bukkit.getServer();
        Map<String, Object> info = new LinkedHashMap<>();

        // getBukkitVersion() liefert z. B. "1.21.4-R0.1-SNAPSHOT" - nur der Teil vor dem Minus interessiert.
        info.put("version", server.getBukkitVersion().split("-")[0]);
        info.put("software", server.getName()); // "Paper", "Spigot", "Purpur" ...
        info.put("motd", server.getMotd());
        info.put("max_players", server.getMaxPlayers());
        info.put("online_mode", server.getOnlineMode());

        // Seit wann der Server laeuft (Start der Java-VM). Steht in jeder Meldung, damit die
        // Laufzeit in Analytics auch dann stimmt, wenn die Start-Meldung verloren ging.
        info.put("started_at", timestamp(Instant.ofEpochMilli(ManagementFactory.getRuntimeMXBean().getStartTime())));

        // Arbeitsspeicher der Java-VM in Megabyte.
        Runtime runtime = Runtime.getRuntime();
        long megabyte = 1024L * 1024L;
        info.put("memory_used_mb", (runtime.totalMemory() - runtime.freeMemory()) / megabyte);
        info.put("memory_max_mb", runtime.maxMemory() / megabyte);

        // TPS (Ticks pro Sekunde, 20 = perfekt) und MSPT (Millisekunden pro Tick) gibt es nur
        // auf Paper und dessen Ablegern, nicht auf reinem Spigot - siehe callIfAvailable().
        Object tps = callIfAvailable(server, "getTPS");
        if (tps instanceof double[] values) {
            List<Double> rounded = new ArrayList<>();
            for (double value : values) {
                rounded.add(Math.round(value * 100.0) / 100.0); // auf 2 Nachkommastellen
            }
            info.put("tps", rounded); // [letzte Minute, 5 Minuten, 15 Minuten]
        }
        Object mspt = callIfAvailable(server, "getAverageTickTime");
        if (mspt instanceof Double value) {
            info.put("mspt", Math.round(value * 100.0) / 100.0);
        }

        // Die Welten mit der Anzahl ihrer Spieler.
        List<Map<String, Object>> worlds = new ArrayList<>();
        for (World world : server.getWorlds()) {
            Map<String, Object> entry = new LinkedHashMap<>();
            entry.put("name", world.getName());
            entry.put("environment", world.getEnvironment().name()); // NORMAL, NETHER, THE_END
            entry.put("players", world.getPlayers().size());
            worlds.add(entry);
        }
        info.put("worlds", worlds);

        return info;
    }

    /**
     * Ruft eine Methode ohne Parameter auf, falls es sie gibt - sonst kommt null zurueck.
     *
     * Wozu: getTPS() existiert nur auf Paper. Ein direkter Aufruf server.getTPS() wuerde das
     * Plugin auf Spigot mit einem NoSuchMethodError abstuerzen lassen. Ueber "Reflection"
     * (die Methode per Namen suchen) laesst sich vorher pruefen, ob sie da ist.
     */
    private static Object callIfAvailable(Object target, String methodName) {
        try {
            return target.getClass().getMethod(methodName).invoke(target);
        } catch (ReflectiveOperationException | RuntimeException notAvailable) {
            return null;
        }
    }

    /**
     * Zeitpunkt als Text in UTC, z. B. "2026-11-11T13:20:00Z" (ISO 8601).
     * truncatedTo schneidet die Nachkommastellen der Sekunden ab.
     */
    private static String timestamp(Instant instant) {
        return instant.truncatedTo(ChronoUnit.SECONDS).toString();
    }
}
