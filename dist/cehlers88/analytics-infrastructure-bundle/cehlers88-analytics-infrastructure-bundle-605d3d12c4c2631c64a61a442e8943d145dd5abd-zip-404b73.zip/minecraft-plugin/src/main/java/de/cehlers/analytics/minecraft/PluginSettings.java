package de.cehlers.analytics.minecraft;

import org.bukkit.configuration.file.FileConfiguration;

import java.net.URI;

/**
 * Die Werte aus der config.yml, einmal eingelesen und danach unveraenderlich.
 *
 * Ein "record" ist eine Kurzschreibweise fuer eine Klasse, die nur Daten haelt: Java erzeugt
 * Konstruktor und Lese-Methoden selbst. Gelesen wird z. B. mit settings.url() (mit Klammern!).
 *
 * Neue Einstellung hinzufuegen:
 *   1. in src/main/resources/config.yml eintragen (mit Kommentar),
 *   2. hier in der Liste der Felder ergaenzen,
 *   3. unten in from() aus der Konfiguration lesen.
 */
public record PluginSettings(
        String url,
        String token,
        String serverId,
        String serverName,
        int heartbeatSeconds,
        int timeoutSeconds,
        boolean debug
) {
    /** Der Platzhalter aus der mitgelieferten config.yml - damit wird nie gesendet. */
    public static final String TOKEN_PLACEHOLDER = "CHANGE-ME";

    /**
     * Liest die Einstellungen aus der geladenen config.yml.
     * Der zweite Wert bei getString/getInt ist der Standard, falls der Eintrag fehlt.
     */
    public static PluginSettings from(FileConfiguration config) {
        return new PluginSettings(
                config.getString("url", "").trim(),
                config.getString("token", "").trim(),
                config.getString("server-id", "minecraft").trim().toLowerCase(),
                config.getString("server-name", "Minecraft").trim(),
                // Math.max: nie oefter als alle 15 Sekunden, auch wenn jemand 1 eintraegt
                Math.max(15, config.getInt("heartbeat-seconds", 60)),
                Math.max(1, config.getInt("timeout-seconds", 5)),
                config.getBoolean("debug", false)
        );
    }

    /**
     * Prueft, ob mit diesen Einstellungen gesendet werden kann.
     *
     * @return null, wenn alles passt - sonst ein Text, der sagt, was fehlt
     */
    public String problem() {
        if (!url.startsWith("https://") && !url.startsWith("http://")) {
            return "\"url\" in der config.yml muss mit https:// (oder http://) beginnen.";
        }
        // Die Adresse muss sich auch wirklich zerlegen lassen und einen Servernamen enthalten -
        // "https://" allein wuerde sonst erst beim Senden scheitern.
        try {
            if (URI.create(url).getHost() == null) {
                return "\"url\" in der config.yml enthaelt keinen Servernamen.";
            }
        } catch (IllegalArgumentException invalid) {
            return "\"url\" in der config.yml ist keine gueltige Adresse.";
        }
        if (token.isEmpty() || token.equals(TOKEN_PLACEHOLDER)) {
            return "\"token\" in der config.yml ist noch nicht gesetzt.";
        }
        // Derselbe Aufbau, den Analytics fuer die Kennung verlangt.
        if (!serverId.matches("[a-z0-9._-]{1,64}")) {
            return "\"server-id\" darf nur a-z, 0-9, Punkt, Minus und Unterstrich enthalten (hoechstens 64 Zeichen).";
        }
        return null;
    }
}
