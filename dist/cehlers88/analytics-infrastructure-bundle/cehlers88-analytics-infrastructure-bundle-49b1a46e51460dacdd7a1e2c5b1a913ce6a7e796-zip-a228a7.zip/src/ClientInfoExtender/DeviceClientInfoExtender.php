<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 15:01
 */


namespace Cehlers88\AnalyticsInfrastructureBundle\ClientInfoExtender;

use Analytics\Builder\ClientInfoExtender\AbstractClientInfoExtender;
use Cehlers88\AnalyticsCore\Entity\Client;
use Cehlers88\AnalyticsInfrastructureBundle\ENUM\eDeviceType;
use Cehlers88\AnalyticsInfrastructureBundle\Repository\DeviceRepository;

class DeviceClientInfoExtender extends AbstractClientInfoExtender
{
    public function __construct(
        private DeviceRepository $deviceRepository
    )
    {

    }

    public function getOverviewColumns(?Client $currentClient = null): array
    {
        $stateColumn = ['label' => 'Device state', 'value' => ''];
        $typeColumn = ['label' => 'Device type', 'value' => eDeviceType::getLabel(eDeviceType::UNKNOWN)];

        if (!is_null($currentClient)) {
            $device = $this->deviceRepository->findOneBy(['client' => $currentClient]);
            if ($device !== null) {
                $stateColumn['value'] = $device->getStateString();
                $typeColumn['value'] = $device->getTypeString();
            }
        }

        return [
            $typeColumn,
            $stateColumn,
        ];
    }
}