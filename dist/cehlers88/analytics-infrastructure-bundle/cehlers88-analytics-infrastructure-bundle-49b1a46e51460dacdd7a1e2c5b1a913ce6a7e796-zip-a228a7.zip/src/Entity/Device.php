<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Entity;

use Cehlers88\AnalyticsCore\Entity\Client;
use Cehlers88\AnalyticsInfrastructureBundle\ENUM\eDeviceState;
use Cehlers88\AnalyticsInfrastructureBundle\ENUM\eDeviceType;
use Cehlers88\AnalyticsInfrastructureBundle\Repository\DeviceRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: DeviceRepository::class)]
#[ORM\Table(name: 'infrastructure_device')]
class Device
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?Client $client = null;

    #[ORM\Column]
    private ?eDeviceType $type = null;

    #[ORM\Column]
    private ?eDeviceState $state = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getClient(): ?Client
    {
        return $this->client;
    }

    public function setClient(?Client $client): static
    {
        $this->client = $client;

        return $this;
    }

    public function getType(): ?eDeviceType
    {
        return $this->type;
    }

    public function setType(eDeviceType $type): static
    {
        $this->type = $type;

        return $this;
    }

    public function getTypeString(): string
    {
        return eDeviceType::getLabel($this->type);
    }

    public function getState(): ?eDeviceState
    {
        return $this->state;
    }

    public function setState(eDeviceState $state): static
    {
        $this->state = $state;

        return $this;
    }

    public function getStateString(): string
    {
        return eDeviceState::getLabel($this->state);
    }
}
