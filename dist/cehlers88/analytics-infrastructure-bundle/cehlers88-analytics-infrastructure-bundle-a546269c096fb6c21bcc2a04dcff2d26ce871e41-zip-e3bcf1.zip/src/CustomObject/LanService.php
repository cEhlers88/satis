<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

class LanService extends AbstractCustomObject
{
    const string ATTRIBUTE_INACTIVE_AFTER = 'inactive_after';
    const string ATTRIBUTE_LAST_SEEN_AT = 'last_seen_at';

    public function getTileDetails(): array
    {
        return [
            'state' => $this->getState(),
        ];
    }

    public function getState(): string
    {
        $lastSeen = $this->getLastSeen();
        $inactiveAfterMinutes = $this->getAttribute(self::ATTRIBUTE_INACTIVE_AFTER);

        if (empty($lastSeen) || empty($inactiveAfterMinutes)) {
            return 'inactive';
        }

        $inactiveAfter = $lastSeen->add(new \DateInterval('PT' . $inactiveAfterMinutes . 'M'));
        if ($inactiveAfter > new \DateTimeImmutable()) {
            return 'active';
        }

        return 'inactive';
    }

    public function getLastSeen(): ?\DateTimeImmutable
    {
        return $this->getAttribute(self::ATTRIBUTE_LAST_SEEN_AT) ?
            new \DateTimeImmutable($this->getAttribute(self::ATTRIBUTE_LAST_SEEN_AT)) :
            null;

    }

    public function getTileTemplate(): ?string
    {
        return 'customObject/tile/lanService.html.twig';
    }

    public function setLastSeen(\DateTimeImmutable $lastSeen)
    {
        $this->setAttribute(
            self::ATTRIBUTE_LAST_SEEN_AT,
            $lastSeen->format('Y-m-d H:i:s')
        );
    }
}