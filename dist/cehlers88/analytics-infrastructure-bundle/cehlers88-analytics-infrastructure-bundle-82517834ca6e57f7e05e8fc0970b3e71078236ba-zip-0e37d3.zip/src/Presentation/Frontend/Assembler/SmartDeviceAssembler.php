<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttributeMonitoring;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\CustomObjectAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ViewInterface;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDevice;
use Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\View\SmartDeviceView;

class SmartDeviceAssembler extends CustomObjectAssembler
{
    public function __construct(
        private CustomObjectProvider $customObjectProvider,
        private ClientRepository     $clientRepository,
        private AssemblerProvider    $assemblerProvider
    )
    {
    }

    public function canHandle(string $className): bool
    {
        return $className === SmartDevice::class;
    }

    public function assemble(EntityInterface|AbstractCustomObject $entity): ViewInterface
    {
        $attributes = [];

        $entityAttributes = $entity->getAttributes();
        foreach ($entityAttributes as $key => $attribute) {
            $name = is_string($attribute) ? $key : $attribute->getName();
            $value = is_string($attribute) ? $attribute : $attribute->getValue();

            switch ($name) {
                case 'client_id':
                    $client = $this->clientRepository->find($value);
                    if (empty($client)) break;
                    $attributes['client'] = $this->assemblerProvider
                        ->getAssemblerForClass($client::class)
                        ->one($client);
                    break;
                default:
                    $attributes[$name] = $value;
            }
        }

        $view = new SmartDeviceView(
            id: $entity->getId(),
            className: $entity->getClassName(),
            name: $entity->getName(),
            attributes: $attributes,
            childObjects: $this->many($entity->getChildObjects()),
        );

        $view->templatePath = $entity->getTileTemplate() ?? '';
        $monitoringBuffer = [];

        foreach ($entity->getMonitorings() as $field => $monitorings) {
            $monitoringBuffer[$field] = $monitorings;
        }

        $view->monitorings = $monitoringBuffer;

        $possibleChildIds = [
            'power_adapter_id',
            'heater_power_adapter_id'
        ];

        foreach ($possibleChildIds as $childId) {
            $id = $attributes[$childId] ?? null;

            if (!empty($id)) {
                $view->childObjects[] = $this->assembleView($this->customObjectProvider->getCustomObjectById($id));
            }
        }

        return $view;
    }
}