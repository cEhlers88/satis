<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;

/**
 * Serverseitiger Teil des API-Fetcher Tools. Führt eine vom Tool
 * zusammengestellte HTTP-Anfrage vom Server aus, damit auch Endpunkte
 * angefragt werden können, die der Browser nicht erreicht (kein CORS,
 * nur im LAN erreichbar, ...).
 */
class ApiFetcherEndpointRunner extends AbstractServiceEndpointRunner
{
    public const DEFAULT_TIMEOUT = 30;
    public const CONNECT_TIMEOUT = 5;
    public const MAX_TIMEOUT = 120;

    private const ALLOWED_METHODS = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS'];
    private const ALLOWED_SCHEMES = ['http', 'https'];
    private const TRANSFER_FORM_DATA = 'form-data';

    public function __construct()
    {
        $parameterUrl = PropertyDTO::create('url', 'https://example.com/api', 'string');
        $parameterUrl->description = 'Die anzufragende URL (http oder https)';

        $parameterMethod = PropertyDTO::create('method', 'GET', implode(' | ', self::ALLOWED_METHODS), true);
        $parameterMethod->description = 'HTTP-Methode der Anfrage';

        $parameterHeaders = PropertyDTO::create('headers', ['Content-Type' => 'application/json'], 'array', true);
        $parameterHeaders->description = 'Header der Anfrage, entweder als Map oder als Liste aus name/value';

        $parameterBody = PropertyDTO::create('body', null, 'string', true);
        $parameterBody->description = 'Body der Anfrage';

        $parameterTimeout = PropertyDTO::create('timeout', self::DEFAULT_TIMEOUT, 'int', true);
        $parameterTimeout->description = 'Timeout der Anfrage in Sekunden';

        $parameterTransfer = PropertyDTO::create('transfer', 'json', 'string', true);
        $parameterTransfer->description = 'Art der Übertragung. Bei \'' . self::TRANSFER_FORM_DATA
            . '\' werden die Argumente als multipart/form-data gesendet, sonst wird der Body verwendet.';

        $parameterArguments = PropertyDTO::create('arguments', [['name' => 'foo', 'value' => 'bar']], 'array', true);
        $parameterArguments->description = 'Argumente als Liste aus name/value, genutzt bei der Übertragung als '
            . self::TRANSFER_FORM_DATA;

        $endpoint = EndpointDefinitionDTO::create(
            'api_fetcher_request',
            ['POST'],
            [
                $parameterUrl,
                $parameterMethod,
                $parameterHeaders,
                $parameterBody,
                $parameterTimeout,
                $parameterTransfer,
                $parameterArguments,
            ],
            [],
            'Endpunkt zum serverseitigen Ausführen einer HTTP-Anfrage des API-Fetcher Tools.',
            [$this, 'handleFetchRequest']
        );
        $endpoint->aliases = ['apiFetcherRequest'];

        $this->registerEndpoint($endpoint);
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }

    public function getRequiredRoles(): array
    {
        return [
            RoleDTO::create('AUTHENTICATED_USER')
        ];
    }

    public function handleFetchRequest(array $requestData): ServiceEndpointRunnerResultDTO
    {
        $url = is_string($requestData['url'] ?? null) ? trim($requestData['url']) : '';
        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            return ServiceEndpointRunnerResultDTO::createError('Invalid url', 400);
        }

        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        if (!in_array($scheme, self::ALLOWED_SCHEMES, true)) {
            return ServiceEndpointRunnerResultDTO::createError(
                'Unsupported scheme \'' . $scheme . '\'. Allowed schemes: ' . implode(', ', self::ALLOWED_SCHEMES),
                400
            );
        }

        $method = strtoupper((string)($requestData['method'] ?? 'GET'));
        if (!in_array($method, self::ALLOWED_METHODS, true)) {
            return ServiceEndpointRunnerResultDTO::createError('Unsupported method \'' . $method . '\'', 400);
        }

        $headers = $this->normalizeRequestHeaders($requestData['headers'] ?? []);
        $body = $this->normalizeRequestBody($requestData['body'] ?? null);
        $timeout = min(max((int)($requestData['timeout'] ?? self::DEFAULT_TIMEOUT), 1), self::MAX_TIMEOUT);
        $formFields = null;

        if (($requestData['transfer'] ?? '') === self::TRANSFER_FORM_DATA) {
            $formFields = $this->normalizeFormFields($requestData['arguments'] ?? []);
            $body = null;
            // curl generates the Content-Type including the multipart boundary
            $headers = array_filter(
                $headers,
                static fn(string $name): bool => strtolower($name) !== 'content-type',
                ARRAY_FILTER_USE_KEY
            );
        }

        return ServiceEndpointRunnerResultDTO::createSuccess(
            $this->runRequest($url, $method, $headers, $body, $timeout, $formFields)
        );
    }

    /**
     * Accepts headers as map (name => value) as well as list of ['name' => ..., 'value' => ...].
     *
     * @return array<string, string>
     */
    private function normalizeRequestHeaders(mixed $headers): array
    {
        if (!is_array($headers)) {
            return [];
        }

        $normalizedHeaders = [];
        foreach ($headers as $key => $header) {
            if (is_array($header)) {
                $name = (string)($header['name'] ?? '');
                $value = (string)($header['value'] ?? '');
            } else {
                $name = (string)$key;
                $value = is_scalar($header) ? (string)$header : json_encode($header);
            }

            $name = trim($name);
            if ($name === '') {
                continue;
            }

            $normalizedHeaders[$name] = $value;
        }

        return $normalizedHeaders;
    }

    /**
     * @return array<string, string>
     */
    private function normalizeFormFields(mixed $arguments): array
    {
        if (!is_array($arguments)) {
            return [];
        }

        $formFields = [];
        foreach ($arguments as $key => $argument) {
            if (is_array($argument)) {
                $name = (string)($argument['name'] ?? '');
                $value = (string)($argument['value'] ?? '');
            } else {
                $name = (string)$key;
                $value = is_scalar($argument) ? (string)$argument : json_encode($argument);
            }

            $name = trim($name);
            if ($name === '') {
                continue;
            }

            $formFields[$name] = $value;
        }

        return $formFields;
    }

    private function normalizeRequestBody(mixed $body): ?string
    {
        if (is_null($body) || $body === '') {
            return null;
        }

        return is_string($body) ? $body : json_encode($body);
    }

    /**
     * @param array<string, string> $headers
     * @param array<string, string>|null $formFields multipart fields, used instead of the body
     */
    private function runRequest(
        string  $url,
        string  $method,
        array   $headers,
        ?string $body,
        int     $timeout,
        ?array  $formFields = null
    ): array
    {
        $responseHeaders = [];
        $statusText = '';

        $curlHandle = curl_init();
        curl_setopt($curlHandle, CURLOPT_URL, $url);
        curl_setopt($curlHandle, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curlHandle, CURLOPT_CONNECTTIMEOUT, self::CONNECT_TIMEOUT);
        curl_setopt($curlHandle, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($curlHandle, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($curlHandle, CURLOPT_NOBODY, $method === 'HEAD');
        curl_setopt($curlHandle, CURLOPT_HTTPHEADER, array_map(
            static fn(string $name, string $value): string => $name . ': ' . $value,
            array_keys($headers),
            array_values($headers)
        ));
        curl_setopt($curlHandle, CURLOPT_HEADERFUNCTION, function ($handle, string $headerLine) use (&$responseHeaders, &$statusText): int {
            $trimmedHeaderLine = trim($headerLine);

            if (str_starts_with($trimmedHeaderLine, 'HTTP/')) {
                // a new status line resets the collected headers (redirects, 100-continue, ...)
                $responseHeaders = [];
                $statusLineParts = explode(' ', $trimmedHeaderLine, 3);
                $statusText = $statusLineParts[2] ?? '';
            } elseif (str_contains($trimmedHeaderLine, ':')) {
                [$name, $value] = explode(':', $trimmedHeaderLine, 2);
                $responseHeaders[] = [
                    'name' => trim($name),
                    'value' => trim($value),
                ];
            }

            return strlen($headerLine);
        });

        if (!in_array($method, ['GET', 'HEAD'], true)) {
            if (!is_null($formFields)) {
                curl_setopt($curlHandle, CURLOPT_POSTFIELDS, $formFields);
            } elseif (!is_null($body)) {
                curl_setopt($curlHandle, CURLOPT_POSTFIELDS, $body);
            }
        }

        $startedAt = microtime(true);
        $responseBody = curl_exec($curlHandle);
        $durationMs = round((microtime(true) - $startedAt) * 1000, 2);

        if ($responseBody === false) {
            $errorMessage = curl_error($curlHandle);
            curl_close($curlHandle);

            return [
                'url' => $url,
                'method' => $method,
                'statusCode' => 0,
                'statusText' => 'Error',
                'headers' => [],
                'body' => '',
                'size' => 0,
                'durationMs' => $durationMs,
                'errorMessage' => $errorMessage === '' ? 'Request failed' : $errorMessage,
            ];
        }

        $statusCode = (int)curl_getinfo($curlHandle, CURLINFO_HTTP_CODE);
        curl_close($curlHandle);

        return [
            'url' => $url,
            'method' => $method,
            'statusCode' => $statusCode,
            'statusText' => $statusText,
            'headers' => $responseHeaders,
            'body' => (string)$responseBody,
            'size' => strlen((string)$responseBody),
            'durationMs' => $durationMs,
            'errorMessage' => null,
        ];
    }
}
