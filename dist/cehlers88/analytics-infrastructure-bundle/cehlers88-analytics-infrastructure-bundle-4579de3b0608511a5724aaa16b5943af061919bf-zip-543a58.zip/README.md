# AnalyticsInfrastructureBundle

A Symfony bundle for managing peripheral devices and infrastructure within the [Analytics](https://github.com/cEhlers88) platform. It provides MQTT device tracking, device state management, and seamless integration with the Analytics Core.

## Requirements

- PHP 8.1+
- Symfony 6.0+
- [`cehlers88/analytics-core`](https://github.com/cEhlers88/analytics-core) `^0.3`

## Installation

Install the bundle via Composer. Because the package is hosted on a private Satis repository, add the repository to your `composer.json` first:

```json
{
    "repositories": [
        {
            "type": "composer",
            "url": "https://cehlers88.github.io/satis"
        }
    ]
}
```

Then require the bundle:

```bash
composer require cehlers88/analytics-infrastructure-bundle
```

Register the bundle in your Symfony application (e.g. `config/bundles.php`):

```php
return [
    // ...
    Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle::class => ['all' => true],
];
```

## Database Setup

Run the Doctrine migrations to create the required `infrastructure_device` table:

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

## Configuration

The bundle exposes its settings through the Analytics Core configuration UI under the key `infrastructureBundle.general`. The following options are available:

| Option | Type | Description |
|---|---|---|
| `mqttApplicationId` | select | The Analytics application used to track MQTT device updates. |
| `networkBridges` | repeat | A list of network bridges (name + address) that act as gateways between networks. |

Example configuration (if set programmatically):

```yaml
# The configuration is managed through the Analytics UI,
# but the internal key used by the bundle is:
# infrastructureBundle.general
#
# mqttApplicationId: <id of the analytics application>
# networkBridges:
#   - name: "My Bridge"
#     address: "192.168.1.1"
```

## Features

### Device Tracking via MQTT

The bundle receives device lists from an MQTT source through the `handle_mqtt_update` service endpoint. For each device, it:

1. Looks up or creates a `Client` record by IP or MAC address.
2. Creates or updates a `Device` entity linked to that client.
3. Sets the device state to **Online** or **Offline** based on the payload.
4. Stores the raw MQTT stats as `ClientDetails` with the tag `mqtt_device`.
5. Records a tracking event via `TrackingRecorder` against the configured MQTT application.

### FritzBox Client List Worker

The `FetchFritzboxClientListWorker` fetches a client list from the FritzBox gateway.  
By default it uses `192.168.178.1` and requests `/clientlist` (tries HTTPS first, then HTTP for host-only entries).  
Optional override: set `ANALYTICS_FRITZBOX_GATEWAYS` as a comma-separated list of gateway hosts/URLs.

#### MQTT Update Endpoint

**Endpoint name:** `handle_mqtt_update`

**Method:** `POST`

**Payload (form-encoded or JSON):**

```json
{
    "devices": [
        {
            "stats": {
                "ip":     "192.168.1.100",
                "mac":    "AA:BB:CC:DD:EE:FF",
                "hn":     "my-device",
                "online": 1
            }
        }
    ]
}
```

| Field | Type | Description |
|---|---|---|
| `stats.ip` | string | IP address of the device. |
| `stats.mac` | string | MAC address of the device. |
| `stats.hn` | string | Hostname of the device. |
| `stats.online` | int | `1` = online, `0` = offline. |

### API Fetcher Tool

The bundle ships the `apiFetcher` tool for the Analytics dashboard (`/dashboard/tools`, listed as a
tile and opened in a modal). It is a small HTTP client for debugging APIs and consists of the template
`templates/tool/apiFetcher.html.twig`, its script `templates/tool/script/apiFetcher.js.twig`, the tile
teaser `templates/tool/teaser/apiFetcher.html.twig` and the `api_fetcher_request` service endpoint.

Features:

- Compact request bar (method, URL, sender, send) with headers, arguments and a raw body
  behind tabs, each showing how many entries are defined.
- The transfer of the arguments is selectable (see below) and the `Content-Type` header follows the
  selected mode as long as it is not edited by hand.
- Requests can be sent by the browser (*Send as Client*) or by the server (*Send as Server*), which
  allows requesting endpoints that the browser cannot reach (CORS, LAN-only services, ...).
- The URL field is a `suggest-input`: predefined requests can be searched and taken over (see
  below), free URLs and methods keep working exactly as before.
- Every request is logged in the request history with timestamp, method, status code, response type
  and duration (in seconds from one second on). Entries can be selected, re-sent, taken over into
  the form or removed. Switching between entries keeps the selected response view.
- The history can be filtered by URL and reduced to failed requests; the displayed columns are
  toggled in the collapsible *Columns* section.
- Responses are shown as raw body and rendered body (`json-viewer` for JSON, sandboxed frame for
  HTML) together with status, size and response headers.
- Request, options (including the selected response view) and history are stored per tool in the
  `localStorage` of the browser
  (`analytics.tool.apiFetcher.state`) and restored on the next visit. *Reset* clears the request,
  *Clear* the history; when both are empty the stored entry is removed. Stored response bodies are
  truncated at 50.000 characters, at most 50 requests are kept, and if the storage is full the
  bodies and finally the history are dropped.

#### Transfer modes

| Mode | Transfer | Content-Type |
|---|---|---|
| `Automatic` | Query parameters for `GET`, `HEAD`, `OPTIONS` and `DELETE`, otherwise a JSON body. A raw body wins. | `application/json` for a JSON body |
| `JSON body` | Arguments as JSON body, a raw body is sent unchanged. | `application/json` |
| `Form data (multipart)` | Arguments as multipart body (`FormData` in the browser, curl on the server). | set automatically including the boundary |
| `Form data (urlencoded)` | Arguments url encoded in the body. | `application/x-www-form-urlencoded` |
| `Query parameters` | Arguments appended to the URL, no body. | none |
| `Raw body` | Only the raw body. | taken from the headers |

`GET` and `HEAD` cannot carry a body, therefore the arguments of those requests are always sent as
query parameters. A `Content-Type` header that was entered by hand is never overwritten.

#### Predefined requests

The tool renders the template variable `requestTemplates` into the page and offers its entries as
suggestions while the URL is typed. Taking one over fills url, method, headers, arguments, transfer
mode and body; everything stays editable afterwards.

```php
'templateData' => [
    'requestTemplates' => [
        [
            'label' => 'AnalyticsInfrastructureBundle.log',  // shown in the suggestion
            'description' => 'Endpunkt zum loggen von Nachrichten',
            'url' => 'https://example.com/api/se/AnalyticsInfrastructureBundle.log',
            'method' => 'POST',
            'headers' => [],                                  // list of name/value entries
            'args' => [['name' => 'message', 'value' => 'Hello']],
            'transfer' => 'auto',
            'body' => '',
        ],
    ],
],
```

The Analytics application fills this list with every endpoint provided by a `ServiceEndpointRunner`
(`DashboardController::buildServiceEndpointRequestTemplates()`), including the documented parameters
as prepared arguments. Without the variable the URL field behaves like a plain input.

#### API Fetcher Endpoint

**Endpoint name:** `AnalyticsInfrastructureBundle.api_fetcher_request` (alias `apiFetcherRequest`)

**Method:** `POST`

**Required role:** `AUTHENTICATED_USER`

**Payload (JSON):**

```json
{
    "url": "https://example.com/api/endpoint",
    "method": "POST",
    "headers": {
        "Content-Type": "application/json"
    },
    "body": "{\"foo\":\"bar\"}",
    "timeout": 30
}
```

| Field | Type | Description |
|---|---|---|
| `url` | string | The requested URL. Only `http` and `https` are allowed. |
| `method` | string | One of `GET`, `POST`, `PUT`, `DELETE`, `PATCH`, `HEAD`, `OPTIONS`. Defaults to `GET`. |
| `headers` | array | Request headers, either as map (`name: value`) or as list of `name`/`value` entries. |
| `body` | string | Raw request body. Arrays are encoded as JSON. Ignored for `GET` and `HEAD`. |
| `timeout` | int | Timeout in seconds (1-120, default 30). |
| `transfer` | string | Transfer mode. With `form-data` the `arguments` are sent as multipart body and the `Content-Type` is generated by curl, otherwise `body` is used. |
| `arguments` | array | Arguments as list of `name`/`value` entries, used for `transfer` = `form-data`. |

The endpoint answers with the result of the executed request. Transport errors (unreachable host,
timeout, ...) are not reported as endpoint errors but as `errorMessage` inside the result data, so
the tool can display them like any other response:

```json
{
    "statusCode": 200,
    "statusText": "OK",
    "headers": [{"name": "Content-Type", "value": "application/json"}],
    "body": "{}",
    "size": 2,
    "durationMs": 42.13,
    "url": "https://example.com/api/endpoint",
    "method": "POST",
    "errorMessage": null
}
```

### Device Types (`eDeviceType`)

| Value | Label |
|---|---|
| `0` | Unknown |
| `1` | Desktop |
| `2` | Laptop |
| `3` | Tablet |
| `4` | Smartphone |
| `5` | Server |
| `6` | Network device |
| `7` | Printer |
| `10` | Smart home device |
| `11` | Smart TV |
| `12` | Smart watch |
| `13` | Smart glasses |
| `14` | Smart speaker |
| `15` | Smart display |
| `16` | Smart sensor |
| `25` | Scanner |
| `26` | Camera |
| `40` | Gaming console |

### Device States (`eDeviceState`)

| Value | Label |
|---|---|
| `0` | Unknown |
| `1` | Offline |
| `2` | Online |
| `3` | Error |

### Macros

#### `getDevices`

Returns all registered `Device` entities from the database.

**Usage in Analytics templates/reports:**

```
{{ macro('getDevices') }}
```

### Client Info Extender

The bundle automatically adds two columns to the Analytics client overview:

- **Device Type** – the type of the device (e.g. *Smart sensor*, *Laptop*).
- **Device State** – the current state of the device (e.g. *Online*, *Offline*).

### Permissions

| Permission | Description |
|---|---|
| `ACCESS_INFRASTRUCTURE` | Grants access to the Infrastructure module. |

## Project Structure

```
src/
├── AnalyticsInfrastructureBundle.php   # Bundle entry point
├── ClientInfoExtender/
│   └── DeviceClientInfoExtender.php    # Adds device columns to client overview
├── Configuration/
│   └── GeneralConfigurationGroup.php   # Bundle configuration (MQTT app, bridges)
├── ENUM/
│   ├── eDeviceState.php                # Device state enum (Unknown/Offline/Online/Error)
│   ├── eDeviceType.php                 # Device type enum (18 types)
│   └── EPermission.php                 # Bundle permission enum
├── Entity/
│   └── Device.php                      # Doctrine entity mapped to `infrastructure_device`
├── Macro/
│   ├── AbstractInfrastructureMacro.php # Base class for bundle macros
│   └── GetDevicesMacro.php             # Macro: returns all devices
├── Repository/
│   └── DeviceRepository.php            # Doctrine repository for Device
├── Resources/
│   └── config/
│       └── services.yaml               # Symfony DI configuration
├── ServiceEndpointRunner/
│   └── HandleMqttUpdateServiceEndpointRunner.php  # MQTT update handler
└── Worker/
    ├── AnalyzeMqttDevicesWorker.php      # MQTT analysis worker (planned)
    └── FetchFritzboxClientListWorker.php # Fetches client lists from FritzBox gateway 192.168.178.1
```

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a full version history.

## License

This project is proprietary software. See [LICENSE](LICENSE) for details.
