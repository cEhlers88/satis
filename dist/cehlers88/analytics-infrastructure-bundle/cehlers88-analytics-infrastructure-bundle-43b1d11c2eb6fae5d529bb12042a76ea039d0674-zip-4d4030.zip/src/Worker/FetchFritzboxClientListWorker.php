<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Worker;

use Analytics\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Client;
use Cehlers88\AnalyticsCore\Entity\ClientDetails;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use Cehlers88\AnalyticsCore\Worker\AbstractWorker;
use SimpleXMLElement;

class FetchFritzboxClientListWorker extends AbstractWorker
{
    public function __construct(
        private ClientRepository $clientRepository
    )
    {
        $this
            ->addProperty(PropertyDTO::create('gateway', ''))
            ->addProperty(PropertyDTO::create('username', ''))
            ->addProperty(PropertyDTO::create('password', ''));
    }

    public function getWorkingObjects(): array
    {
        $gateway = $this->clientRepository->find($this->getPropertyValue('gateway'));
        return [
            $gateway->getIp()
        ];
    }

    public function handleWorkingObjects($workingObjects): array
    {
        $clientList = [];
        $ipList = [];
        $needsToFlush = false;

        foreach ($workingObjects as $gateway) {
            $clients = $this->fetchClientList((string)$gateway);
            if (empty($clients)) {
                $this->logWarning(sprintf('Failed to fetch client list for "%s".', $this->sanitizeUrlForLogs((string)$gateway)));
                continue;
            }

            $this->logInfo(sprintf('Found %d clients on "%s".', count($clients), $this->sanitizeUrlForLogs((string)$gateway)));

            foreach ($clients as $clientData) {
                if (empty($clientData['ip'])) {
                    continue;
                }
                $ip = $clientData['ip'];
                unset($clientData['ip']);
                $ipList[] = $ip;

                $clientList[$ip] = [
                    'data' => $clientData,
                    'gateway' => (string)$gateway,
                    'entityId' => -1
                ];
            }
        }

        $storedClients = $this->clientRepository->findBy(['ip' => $ipList]);

        foreach ($storedClients as $storedClient) {
            $clientList[$storedClient->getIp()]['entityId'] = $storedClient->getId();
        }

        foreach ($clientList as $ip => &$client) {
            if ($client['entityId'] <= 0) {
                $clientEntity = new Client();
                $clientEntity
                    ->setIp($ip)
                    ->setFirstVisit(new \DateTime());

                $needsToFlush = true;
            } else {
                $clientEntity = $this->clientRepository->find($client['entityId']);
            }

            $clientEntity
                ->setMac($client['data']['macAddress'] ?? null)
                ->setHostname($client['data']['hostName'] ?? null);

            $networkInfoExist = false;
            $networkInfoClientDetails = new ClientDetails();
            $networkInfoClientDetails->setTag('network_info');

            foreach ($clientEntity->getClientDetails() as $clientDetail) {
                switch ($clientDetail->getTag()) {
                    case 'network_info':
                        $networkInfoExist = true;
                        $networkInfoClientDetails = $clientDetail;
                        break;
                }
            }

            $storedInfos = json_decode($networkInfoClientDetails->getInfos() ?? '[]', true);
            $hasInfoChanges = false;
            $changedFields = [];
            foreach ($client['data'] as $key => $value) {
                if (!isset($storedInfos[$key]) || $storedInfos[$key] !== $value) {
                    $hasInfoChanges = true;
                    $changedFields[] = $key;
                }
            }

            if (count($changedFields) > 0) {
                if (count($changedFields) === 1) {
                    $this->addResultMessage(sprintf('Attribute "%s" of Client #%s was changed', $changedFields[0], $clientEntity->getId()));
                } else {
                    $this->addResultMessage(sprintf('Attributes "%s" of Client #%s were changed', implode('", "', $changedFields), $clientEntity->getId()));
                }
            }

            if ($hasInfoChanges) {
                $networkInfoClientDetails->setInfos(json_encode($client['data']));
                if (!$networkInfoExist) {
                    $clientEntity->addClientDetail($networkInfoClientDetails);
                }

                $this->clientRepository->add($clientEntity, false);
                $needsToFlush = true;
            }
        }

        if ($needsToFlush) {
            $this->clientRepository->flush();
        }

        return $clientList;
    }

    private function fetchClientList(string $gateway): ?array
    {
        $host = $this->normalizeGatewayHost($gateway);
        if ($host === null) {
            return null;
        }

        $username = $this->getPropertyValue('username');
        $password = $this->getPropertyValue('password');

        if ($username === '' || $password === '') {
            $this->logWarning('Missing FritzBox credentials.');
            return null;
        }

        return $this->fetchHostsViaSoapClient($host, $username, $password);
    }

    private function normalizeGatewayHost(string $gateway): ?string
    {
        $gateway = trim($gateway);
        if ($gateway === '') {
            return null;
        }

        if (!str_contains($gateway, '://')) {
            return rtrim($gateway, '/');
        }

        $parts = parse_url($gateway);
        if (!is_array($parts) || empty($parts['host'])) {
            $this->logWarning(sprintf('FritzBox gateway "%s" is invalid.', $this->sanitizeUrlForLogs($gateway)));
            return null;
        }

        return (string)$parts['host'];
    }

    private function sanitizeUrlForLogs(string $url): string
    {
        $parts = parse_url($url);
        if (!is_array($parts)) {
            return '[malformed URL]';
        }

        unset($parts['user'], $parts['pass']);
        return $this->buildUrl($parts);
    }

    private function buildUrl(array $parts): string
    {
        $scheme = isset($parts['scheme']) ? $parts['scheme'] . '://' : '';
        $user = $parts['user'] ?? '';
        $pass = isset($parts['pass']) ? ':' . $parts['pass'] : '';
        $auth = $user !== '' ? $user . $pass . '@' : '';
        $host = $parts['host'] ?? '';
        $port = isset($parts['port']) ? ':' . $parts['port'] : '';
        $path = $parts['path'] ?? '';
        $query = isset($parts['query']) ? '?' . $parts['query'] : '';
        $fragment = isset($parts['fragment']) ? '#' . $parts['fragment'] : '';

        return $scheme . $auth . $host . $port . $path . $query . $fragment;
    }

    private function fetchHostsViaSoapClient(string $host, string $username, string $password): ?array
    {
        if (!class_exists(\SoapClient::class)) {
            $this->logWarning('PHP extension "soap" is required for FritzBox TR-064.');
            return null;
        }

        $location = sprintf('http://%s:49000/upnp/control/hosts', $host);
        $uri = 'urn:dslforum-org:service:Hosts:1';

        try {
            $client = new \SoapClient(null, [
                'location' => $location,
                'uri' => $uri,
                'login' => $username,
                'password' => $password,
                'authentication' => SOAP_AUTHENTICATION_DIGEST,
                'trace' => true,
                'exceptions' => true,
                'cache_wsdl' => WSDL_CACHE_NONE,
                'noroot' => true,
            ]);

            $countResult = $client->__soapCall('GetHostNumberOfEntries', []);
            $count = isset($countResult->NewHostNumberOfEntries)
                ? (int)$countResult->NewHostNumberOfEntries
                : (is_numeric($countResult) ? (int)$countResult : 0);

            $result = [];

            for ($index = 0; $index < $count; $index++) {
                $entry = $client->__soapCall(
                    'GetGenericHostEntry',
                    [new \SoapParam($index, 'NewIndex')]
                );

                $entryArr = [
                    'index' => $index,
                    'ip' => $entry->NewIPAddress ?? $entry['NewIPAddress'] ?? null,
                    'macAddress' => $entry->NewMACAddress ?? $entry['NewMACAddress'] ?? null,
                    'hostName' => $entry->NewHostName ?? $entry['NewHostName'] ?? null,
                    'interfaceType' => $entry->NewInterfaceType ?? $entry['NewInterfaceType'] ?? null,
                    'active' => ($entry->NewActive ?? $entry['NewActive'] ?? '0') === '1',
                    'addressSource' => $entry->NewAddressSource ?? $entry['NewAddressSource'] ?? null,
                    'leaseTimeRemaining' => $entry->NewLeaseTimeRemaining ?? $entry['NewLeaseTimeRemaining'] ?? null,
                ];

                $result[] = $entryArr;
            }

            return $result;
        } catch (\SoapFault $e) {
            if (isset($client)) {
                $this->logWarning(sprintf('FritzBox SOAP last request: %s', $client->__getLastRequest()));
                $this->logWarning(sprintf('FritzBox SOAP last response: %s', $client->__getLastResponse()));
            }

            $this->logWarning(sprintf('FritzBox SOAP fault: %s', $e->getMessage()));
            return null;
        } catch (\Throwable $e) {
            $this->logWarning(sprintf('FritzBox request failed: %s', $e->getMessage()));
            return null;
        }
    }
}