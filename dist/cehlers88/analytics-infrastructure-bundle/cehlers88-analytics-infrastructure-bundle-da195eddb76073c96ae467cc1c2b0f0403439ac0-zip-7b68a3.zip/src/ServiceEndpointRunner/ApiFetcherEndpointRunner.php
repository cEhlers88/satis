<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\Security\Role\AdminRole;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;

/**
 * Serverseitiger Teil des API-Fetcher Tools. Führt eine vom Tool
 * zusammengestellte HTTP-Anfrage vom Server aus, damit auch Endpunkte
 * angefragt werden können, die der Browser nicht erreicht (kein CORS,
 * nur im LAN erreichbar, ...).
 */
class ApiFetcherEndpointRunner extends AbstractServiceEndpointRunner
{
    public const DEFAULT_TIMEOUT = 30;
    public const CONNECT_TIMEOUT = 5;
    public const MAX_TIMEOUT = 120;
    /** Maximum response body size in bytes (10 MB). */
    public const MAX_RESPONSE_SIZE = 10 * 1024 * 1024;

    private const ALLOWED_METHODS = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS'];
    private const ALLOWED_SCHEMES = ['http', 'https'];
    private const TRANSFER_FORM_DATA = 'form-data';

    public function __construct()
    {
        $parameterUrl = PropertyDTO::create('url', 'https://example.com/api', 'string');
        $parameterUrl->description = 'Die anzufragende URL (http oder https)';

        $parameterMethod = PropertyDTO::create('method', 'GET', implode(' | ', self::ALLOWED_METHODS), true);
        $parameterMethod->description = 'HTTP-Methode der Anfrage';

        $parameterHeaders = PropertyDTO::create('headers', ['Content-Type' => 'application/json'], 'array', true);
        $parameterHeaders->description = 'Header der Anfrage, entweder als Map oder als Liste aus name/value';

        $parameterBody = PropertyDTO::create('body', null, 'string', true);
        $parameterBody->description = 'Body der Anfrage';

        $parameterTimeout = PropertyDTO::create('timeout', self::DEFAULT_TIMEOUT, 'int', true);
        $parameterTimeout->description = 'Timeout der Anfrage in Sekunden';

        $parameterTransfer = PropertyDTO::create('transfer', 'json', 'string', true);
        $parameterTransfer->description = 'Art der Übertragung. Bei \'' . self::TRANSFER_FORM_DATA
            . '\' werden die Argumente als multipart/form-data gesendet, sonst wird der Body verwendet.';

        $parameterArguments = PropertyDTO::create('arguments', [['name' => 'foo', 'value' => 'bar']], 'array', true);
        $parameterArguments->description = 'Argumente als Liste aus name/value, genutzt bei der Übertragung als '
            . self::TRANSFER_FORM_DATA;

        $endpoint = EndpointDefinitionDTO::create(
            'api_fetcher_request',
            ['POST'],
            [
                $parameterUrl,
                $parameterMethod,
                $parameterHeaders,
                $parameterBody,
                $parameterTimeout,
                $parameterTransfer,
                $parameterArguments,
            ],
            [],
            'Endpunkt zum serverseitigen Ausführen einer HTTP-Anfrage des API-Fetcher Tools.',
            [$this, 'handleFetchRequest']
        );
        $endpoint->aliases = ['apiFetcherRequest'];

        $this->registerEndpoint($endpoint);
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }

    public function getRequiredRoles(): array
    {
        return [
            RoleDTO::create('AUTHENTICATED_USER')
        ];
    }

    public function handleFetchRequest(array $requestData): ServiceEndpointRunnerResultDTO
    {
        $url = is_string($requestData['url'] ?? null) ? trim($requestData['url']) : '';
        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            return ServiceEndpointRunnerResultDTO::createError('Invalid url', 400);
        }

        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        if (!in_array($scheme, self::ALLOWED_SCHEMES, true)) {
            return ServiceEndpointRunnerResultDTO::createError(
                'Unsupported scheme \'' . $scheme . '\'. Allowed schemes: ' . implode(', ', self::ALLOWED_SCHEMES),
                400
            );
        }

        // parse_url keeps the brackets of an IPv6 literal ([fd00::1]), filter_var does not accept them
        $host = trim((string)parse_url($url, PHP_URL_HOST), '[]');
        if ($host === '' || strtolower($host) === 'localhost') {
            return ServiceEndpointRunnerResultDTO::createError('Unsupported host', 400);
        }

        // A hostname is checked by the addresses it resolves to, and curl is pinned to
        // the checked one - otherwise a name pointing into the LAN would pass the IP check.
        $pinnedResolve = null;
        $addresses = filter_var($host, FILTER_VALIDATE_IP) ? [$host] : $this->resolveHost($host);
        if ($addresses === []) {
            return ServiceEndpointRunnerResultDTO::createError('Could not resolve host \'' . $host . '\'', 400);
        }
        foreach ($addresses as $address) {
            $refusal = $this->refuseIpHost($address);
            if (!is_null($refusal)) {
                return ServiceEndpointRunnerResultDTO::createError($refusal, 400);
            }
        }
        if ($addresses[0] !== $host) {
            $port = parse_url($url, PHP_URL_PORT) ?: ($scheme === 'https' ? 443 : 80);
            $pinnedAddress = str_contains($addresses[0], ':') ? '[' . $addresses[0] . ']' : $addresses[0];
            $pinnedResolve = $host . ':' . $port . ':' . $pinnedAddress;
        }

        $method = strtoupper((string)($requestData['method'] ?? 'GET'));
        if (!in_array($method, self::ALLOWED_METHODS, true)) {
            return ServiceEndpointRunnerResultDTO::createError('Unsupported method \'' . $method . '\'', 400);
        }

        $headers = $this->normalizeRequestHeaders($requestData['headers'] ?? []);
        $body = $this->normalizeRequestBody($requestData['body'] ?? null);
        $timeout = min(max((int)($requestData['timeout'] ?? self::DEFAULT_TIMEOUT), 1), self::MAX_TIMEOUT);
        $formFields = null;

        if (($requestData['transfer'] ?? '') === self::TRANSFER_FORM_DATA) {
            $formFields = $this->normalizeFormFields($requestData['arguments'] ?? []);
            $body = null;
            // curl generates the Content-Type including the multipart boundary
            $headers = array_filter(
                $headers,
                static fn(string $name): bool => strtolower($name) !== 'content-type',
                ARRAY_FILTER_USE_KEY
            );
        }

        return ServiceEndpointRunnerResultDTO::createSuccess(
            $this->runRequest($url, $method, $headers, $body, $timeout, $formFields, $pinnedResolve)
        );
    }

    /**
     * Administrators may reach devices in the LAN (private ranges) - that is what
     * the server path is for. Reserved ranges stay closed for everyone: loopback
     * is the server itself and link-local holds cloud metadata services.
     */
    private function refuseIpHost(string $host): ?string
    {
        if (!filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_RES_RANGE)) {
            return 'Refusing to access reserved IP ranges';
        }

        if (!$this->isAdmin() && !filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE)) {
            return 'Refusing to access private IP ranges (allowed for administrators only)';
        }

        return null;
    }

    /**
     * The IPv4 and IPv6 addresses of a hostname; empty when it does not resolve.
     *
     * @return string[]
     */
    private function resolveHost(string $host): array
    {
        $addresses = gethostbynamel($host) ?: [];
        foreach (@dns_get_record($host, DNS_AAAA) ?: [] as $record) {
            if (isset($record['ipv6'])) {
                $addresses[] = $record['ipv6'];
            }
        }

        return array_values(array_unique($addresses));
    }

    private function isAdmin(): bool
    {
        return in_array(AdminRole::NAME, $this->getUser()?->getRoles() ?? [], true);
    }

    /**
     * Accepts headers as map (name => value) as well as list of ['name' => ..., 'value' => ...].
     *
     * @return array<string, string>
     */
    private function normalizeRequestHeaders(mixed $headers): array
    {
        if (!is_array($headers)) {
            return [];
        }

        $normalizedHeaders = [];
        foreach ($headers as $key => $header) {
            if (is_array($header)) {
                $name = (string)($header['name'] ?? '');
                $value = (string)($header['value'] ?? '');
            } else {
                $name = (string)$key;
                $value = is_scalar($header) ? (string)$header : json_encode($header);
            }

            $name = trim($name);
            $value = is_string($value) ? $value : (string)$value;

            if ($name === '' || str_contains($name, ':') || preg_match('/[\r\n]/', $name) || preg_match('/[\r\n]/', $value)) {
                continue;
            }

            $normalizedHeaders[$name] = trim($value);
        }

        return $normalizedHeaders;
    }

    /**
     * @return array<string, string>
     */
    private function normalizeFormFields(mixed $arguments): array
    {
        if (!is_array($arguments)) {
            return [];
        }

        $formFields = [];
        foreach ($arguments as $key => $argument) {
            if (is_array($argument)) {
                $name = (string)($argument['name'] ?? '');
                $value = (string)($argument['value'] ?? '');
            } else {
                $name = (string)$key;
                $value = is_scalar($argument) ? (string)$argument : json_encode($argument);
            }

            $name = trim($name);
            if ($name === '') {
                continue;
            }

            $formFields[$name] = $value;
        }

        return $formFields;
    }

    private function normalizeRequestBody(mixed $body): ?string
    {
        if (is_null($body) || $body === '') {
            return null;
        }

        return is_string($body) ? $body : json_encode($body);
    }

    /**
     * @param array<string, string> $headers
     * @param array<string, string>|null $formFields multipart fields, used instead of the body
     * @param string|null $pinnedResolve host:port:address entry that keeps curl on the checked address
     */
    private function runRequest(
        string  $url,
        string  $method,
        array   $headers,
        ?string $body,
        int     $timeout,
        ?array  $formFields = null,
        ?string $pinnedResolve = null
    ): array
    {
        $responseHeaders = [];
        $statusText = '';

        $curlHandle = curl_init();
        curl_setopt($curlHandle, CURLOPT_URL, $url);
        if (!is_null($pinnedResolve)) {
            curl_setopt($curlHandle, CURLOPT_RESOLVE, [$pinnedResolve]);
        }
        curl_setopt($curlHandle, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curlHandle, CURLOPT_CONNECTTIMEOUT, self::CONNECT_TIMEOUT);
        curl_setopt($curlHandle, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($curlHandle, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($curlHandle, CURLOPT_NOBODY, $method === 'HEAD');
        curl_setopt($curlHandle, CURLOPT_MAXFILESIZE, self::MAX_RESPONSE_SIZE);
        curl_setopt($curlHandle, CURLOPT_HTTPHEADER, array_map(
            static fn(string $name, string $value): string => $name . ': ' . $value,
            array_keys($headers),
            array_values($headers)
        ));
        curl_setopt($curlHandle, CURLOPT_HEADERFUNCTION, function ($handle, string $headerLine) use (&$responseHeaders, &$statusText): int {
            $trimmedHeaderLine = trim($headerLine);

            if (str_starts_with($trimmedHeaderLine, 'HTTP/')) {
                // a new status line resets the collected headers (redirects, 100-continue, ...)
                $responseHeaders = [];
                $statusLineParts = explode(' ', $trimmedHeaderLine, 3);
                $statusText = $statusLineParts[2] ?? '';
            } elseif (str_contains($trimmedHeaderLine, ':')) {
                [$name, $value] = explode(':', $trimmedHeaderLine, 2);
                $responseHeaders[] = [
                    'name' => trim($name),
                    'value' => trim($value),
                ];
            }

            return strlen($headerLine);
        });

        if (!in_array($method, ['GET', 'HEAD'], true)) {
            if (!is_null($formFields)) {
                curl_setopt($curlHandle, CURLOPT_POSTFIELDS, $formFields);
            } elseif (!is_null($body)) {
                curl_setopt($curlHandle, CURLOPT_POSTFIELDS, $body);
            }
        }

        $startedAt = microtime(true);
        $responseBody = curl_exec($curlHandle);
        $durationMs = round((microtime(true) - $startedAt) * 1000, 2);

        if ($responseBody === false) {
            $curlErrno = curl_errno($curlHandle);
            $errorMessage = curl_error($curlHandle);
            curl_close($curlHandle);

            if ($curlErrno === CURLE_FILESIZE_EXCEEDED) {
                $errorMessage = sprintf(
                    'Response aborted: body exceeded the maximum allowed size of %d bytes.',
                    self::MAX_RESPONSE_SIZE
                );
            } elseif ($errorMessage === '') {
                $errorMessage = 'Request failed';
            }

            return [
                'url' => $url,
                'method' => $method,
                'statusCode' => 0,
                'statusText' => 'Error',
                'headers' => [],
                'body' => '',
                'size' => 0,
                'durationMs' => $durationMs,
                'errorMessage' => $errorMessage,
            ];
        }

        $statusCode = (int)curl_getinfo($curlHandle, CURLINFO_HTTP_CODE);
        curl_close($curlHandle);

        return [
            'url' => $url,
            'method' => $method,
            'statusCode' => $statusCode,
            'statusText' => $statusText,
            'headers' => $responseHeaders,
            'body' => (string)$responseBody,
            'size' => strlen((string)$responseBody),
            'durationMs' => $durationMs,
            'errorMessage' => null,
        ];
    }
}
