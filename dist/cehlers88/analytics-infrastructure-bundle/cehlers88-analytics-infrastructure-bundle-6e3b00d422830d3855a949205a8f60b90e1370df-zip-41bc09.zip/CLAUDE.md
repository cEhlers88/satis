# CLAUDE.md

Guidance for AI assistants working in this repository.

## What this repository is

`cehlers88/analytics-infrastructure-bundle` is a **Symfony bundle plugin** for the proprietary
[Analytics](https://github.com/cEhlers88) platform. It manages peripheral devices and infrastructure:
MQTT smart devices, LAN services, FritzBox client lists, Chromecast updates, plus three dashboard
debugging tools (API Fetcher, WebSocket Console, Remote Debugger).

It is a **library, not an application**: there is no `bin/console`, no kernel, no entry point.
Everything here is loaded by a host Analytics application that registers the bundle in its
`config/bundles.php`. The public-facing documentation lives in `README.md` and is unusually
detailed — treat it as the contract for endpoints and tools.

Key facts:

| | |
|---|---|
| Package type | `symfony-bundle`, license `proprietary` |
| PSR-4 root | `Cehlers88\AnalyticsInfrastructureBundle\` → `src/` |
| Hard dependency | `cehlers88/analytics-core` (`1.*@dev`, currently locked to `v1.40.0`) |
| PHP | **8.4+** (analytics-core requires `>=8.4`; the code uses PHP 8.4 `new Foo()->bar()` and typed class constants). The README's "PHP 8.1+" is stale. |
| Distribution | private Satis at `https://cehlers88.github.io/satis` |
| Versioning | release-please, conventional commits |

## Environment reality check (read before you try to build)

**`composer install` will not work in a sandboxed session.** `analytics-core` resolves to a private
GitHub repository and needs credentials; it also requires `ext-soap`, which is typically absent.
Both of these fail:

```
composer install                                   # ext-soap missing
composer install --ignore-platform-req=ext-soap    # git clone of cEhlers88/AnalyticsCore needs auth
```

Consequences you must plan around:

- There is **no `vendor/`**. Every `Cehlers88\AnalyticsCore\*` symbol is unresolvable locally.
  You cannot verify signatures of core base classes/DTOs by reading them — infer them from how
  existing code in this repo already calls them, and stay consistent with those call sites.
- There are **no tests, no PHPUnit, no PHPStan, no PHP-CS-Fixer, no linter config, no JS/TS build**.
  `assets/infrastructure_bundle.ts` is never compiled here; the host application bundles it.
- **Do not invent build/test commands** and do not claim a change is "tested". The only verification
  available in this repo is a syntax check:

```bash
find . -name "*.php" -not -path "./.git/*" -print0 | xargs -0 -n1 php -l
```

Run that after every PHP edit. For Twig/JS-in-Twig changes, re-read the diff carefully — nothing
will catch a mistake for you.

- If you accidentally create a partial `vendor/` directory, delete it. It is not gitignored
  (there is no `.gitignore` at all), so a stray `vendor/` would be committed.

## Layout

```
src/
├── AnalyticsInfrastructureBundle.php     # AbstractBundlePlugin: name, version, menu, permissions
├── ClientInfoExtender/                   # extra columns in the Analytics client overview
├── Configuration/                        # config groups rendered in the Analytics settings UI
├── CustomObject/                         # AbstractCustomObject subclasses (SmartDevice, LanService)
│   └── SmartDeviceType/                  # plain attribute-template helpers, not custom objects
├── ENUM/                                 # eDeviceState, eDeviceType, EPermission
├── Entity/                               # Doctrine: Device → table `infrastructure_device`
├── Macro/                                # macros callable from Analytics templates/reports
├── Presentation/Frontend/{Assembler,View}/  # entity → view assembly for the dashboard
├── RemoteDebugger/                       # RemoteLogStore: file ring buffer of the remote logs
├── Repository/                           # DeviceRepository
├── Resources/config/services.yaml        # the whole DI wiring for the bundle
├── Security/{Role,MagicRole}/            # IS_LAN_DEVICE role + its magic-role resolver
├── ServiceEndpointRunner/                # HTTP endpoints exposed under /api/se/...
└── Worker/                               # background workers run by the Analytics worker runner
assets/infrastructure_bundle.ts           # tiny event listener, compiled by the host app
public/css/mqtt_device.css                # asset served by the host app
templates/
├── clientDetails/                        # per-tag client detail tiles (cast_info, mqtt_device, ...)
├── customObject/tile/                    # tile templates returned by getTileTemplate()
└── tool/                                 # dashboard tools: page + script/ + teaser/
```

## How things get registered (`src/Resources/config/services.yaml`)

This file is the single source of DI truth. It is short but load-bearing — read it before adding
any new class, because **registration is mostly automatic by interface or by directory**.

`_instanceof` auto-tagging (just implement the interface and the class is wired):

| Implements | Gets tag |
|---|---|
| `AnalyticsCore\Macro\MacroInterface` | `analytics.macro` |
| `AnalyticsCore\Worker\WorkerInterface` | `analytics.worker` |
| `AnalyticsCore\Presentation\Assembler\AssemblerInterface` | `analytics.assemblers` |
| `AnalyticsCore\CustomObject\CustomObjectInterface` | `custom_object` |
| `AnalyticsCore\Security\MagicRole\MagicRoleInterface` | `magic_role` |

Directory-based tagging (drop a class in the folder and it is registered `public: true`):

| Directory | Tag |
|---|---|
| `Configuration/` | `analytics.configuration` |
| `ServiceEndpointRunner/` | `analytics.service_endpoint_runner` |
| `ClientInfoExtender/` | `client_info_extender` |

`src/` is loaded wholesale with `Entity/` excluded. **New classes therefore need no YAML changes** —
only add to `services.yaml` if you introduce a genuinely new extension-point directory (there is a
commented-out `Widget/` block showing the pattern).

## Extension points — how to add each kind of thing

**Service endpoint** (`src/ServiceEndpointRunner/*`) — extend `AbstractServiceEndpointRunner`.
Two styles coexist; both are fine, follow the neighbouring file:

- register in the constructor via `$this->registerEndpoint(EndpointDefinitionDTO::create(...))`
  (newer: `ApiFetcherEndpointRunner`, `WebsocketProbeEndpointRunner`, `LogServiceEndpointRunner`,
  `LanServiceInfoEndpointRunner`), or
- override `getEndpoints()` returning an array of DTOs (older: `HandleMqttUpdateServiceEndpointRunner`,
  `HandleClientUpdateServiceEndpointRunner`).

Conventions that matter:

- `getBundleName()` must return `AnalyticsInfrastructureBundle::getBundleName()`. The public endpoint
  name becomes `AnalyticsInfrastructureBundle.<endpoint_name>`; `$endpoint->aliases = ['camelCase']`
  adds the short form the JS actually calls (`/api/se/apiFetcherRequest`).
- Endpoint names are `snake_case`; aliases are `camelCase`.
- Declare every parameter as a `PropertyDTO` with a `->description`. Analytics reads these to build
  the API documentation *and* the API Fetcher's predefined-request list, so an undocumented
  parameter is invisible to users.
- Roles: either `getRequiredRoles()` (applies to all endpoints of the runner, e.g.
  `LogServiceEndpointRunner` → `IS_LAN_DEVICE`) or per-endpoint `RoleDTO`/`ExtendedRoleDTO::createAnyOf(...)`.
- Return `ServiceEndpointRunnerResultDTO::createSuccess($data, $message)` /
  `createError($message, $httpStatus)`. Note the deliberate split in the two tool endpoints:
  **transport failures are returned as `errorMessage` inside a successful result**, not as endpoint
  errors, so the frontend can render them like any other response. Preserve that.
- Optional `validate(string $endpointName, Request $request): ValidationResultDTO` for preconditions
  (see `HandleMqttUpdateServiceEndpointRunner`, which requires a configured MQTT application).

**Macro** (`src/Macro/*`) — extend `AbstractInfrastructureMacro` (which sets `_source = "InfrastructureBundle"`),
implement `_init()`, `run()`, `getName()`, `getDescription()`. Declare inputs with
`MacroPropertyDTO::create(...)` inside `_init()`. Return via `$this->_createRunResult(...)`.
Called from Analytics templates as `{{ macro('getDevices') }}`.

**Worker** (`src/Worker/*`) — extend `AbstractWorker`, declare configuration with
`$this->addProperty(PropertyDTO::create(...))` in the constructor, implement `getWorkingObjects()`
and `handleWorkingObjects($workingObjects)`. Use `$this->logInfo/logWarning` and
`$this->getLogger()->progressStart/progressAdvance` for long runs.

**Custom object** (`src/CustomObject/*`) — extend `AbstractCustomObject`. Attributes are
free-form key/value pairs (`getAttribute`/`setAttribute`), so:

- `getAttributeTemplates()` returns the named attribute presets offered in the UI. `SmartDevice`
  composes them from the plain helper classes in `SmartDeviceType/` (`SensorDevice`,
  `EnvironmentDevice`, `PowerAdapterDevice` — these are *not* custom objects and are not DI services).
- `getTileTemplate()` returns a Twig path under `templates/`, dispatched on the `device_type`
  attribute. Prefer the helper's `TEMPLATES_PATH` constant over a literal string.
- `getTileDetails()` returns extra data for the tile.

**Assembler + View** (`src/Presentation/Frontend/*`) — an assembler extends `CustomObjectAssembler`,
sets `protected string $viewClass`, implements `canHandle(string $className)` and `enrichView()`.
The view extends `CustomObjectView` and may implement `getUserInteractions()` to surface actionable
warnings in the dashboard (see `SmartDeviceView`: missing `device_type`, missing `topic`, known-bad
firmware). Interactions are arrays with `subject`/`level`/`message`, optional `formFields` and
`actions` bound to Analytics frontend functions like `set_custom_entity_attributes`.

**Configuration** (`src/Configuration/*`) — extend `AbstractConfigurationGroup`, expose a
`public const string KEY` (`GeneralConfigurationGroup::KEY === 'infrastructureBundle.general'`) and
build items with `ConfigurationItemDTO::create/createSelect/createRepeat` or
`ConfigurationSuggestItemDTO::createSuggest`. Read values elsewhere via
`ConfigurationProvider::getValue(GeneralConfigurationGroup::KEY, 'itemName')` — always through the
`KEY` constant, never a hard-coded string.

**Security** — `Security/Role/IsLanDeviceRole` declares `IS_LAN_DEVICE` with `isMagicRole() = true`;
`Security/MagicRole/MagicRoleIsLanDevice` resolves it (loopback, `192.168.*`, or the application's
configured WAN IP). Reference roles by the `NAME` constant.

**Entity** — `Device` is the only Doctrine entity, mapped to `infrastructure_device`, with enum
columns `eDeviceType`/`eDeviceState` and a `ManyToOne` to core's `Client`. Schema changes are applied
in the host app via `doctrine:migrations:diff` + `migrate`; there are no migration files in this repo.

## Dashboard tools (API Fetcher, WebSocket Console, Remote Debugger)

Each tool is a set of four files plus a service endpoint, and the host app registers it in its tool
list (registration array documented in `README.md`):

```
templates/tool/<name>.html.twig            # the modal page
templates/tool/script/<name>.js.twig       # behaviour, an IIFE using {{ toolName }}
templates/tool/teaser/<name>.html.twig     # inline SVG tile illustration (viewBox 0 0 320 160)
src/ServiceEndpointRunner/<X>EndpointRunner.php   # the server-side half
```

Shared conventions — follow them when touching or adding a tool:

- The script is one `(() => { ... })()` IIFE. DOM ids are prefixed with the tool name
  (`byId = (suffix) => document.getElementById(TOOL + '-' + suffix)`).
- State persists in `localStorage` under `analytics.tool.<toolName>.state` with a `STORAGE_VERSION`,
  a debounced save, capped entry counts and bodies truncated at 50 000 chars, degrading (drop bodies,
  then drop history) when the quota is hit.
- Templates render a `templateData` variable of predefined entries (`requestTemplates` /
  `endpointTemplates`) into a `suggest-input`; the tool must keep working when the variable is absent.
- The API Fetcher and the WebSocket Console offer a client-side path (browser `fetch`/`WebSocket`)
  and a server-side path (`/api/se/apiFetcherRequest`, `/api/se/websocketProbe`) for endpoints the
  browser cannot reach.
- The Remote Debugger is read-only and server-backed: it polls `/api/se/remoteDebuggerLogs` with the
  sequence number of the newest entry it holds, so following only transfers the new entries. Its
  data comes from `RemoteDebugger\RemoteLogStore`, a ring buffer file under `var/` that
  `LogServiceEndpointRunner` fills - the store is the seam for a later, persistent implementation,
  so keep new features behind its four methods instead of reading the file elsewhere.

**Security invariants in the server-side halves — never relax these without being asked:**

- scheme allowlist (`http`/`https`; `ws`/`wss`),
- refusal of `localhost` and private/reserved IP ranges
  (`FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE`),
- HTTP method allowlist, timeout clamps (`MAX_TIMEOUT` 120 s / 30 s),
- size caps (`MAX_RESPONSE_SIZE` 10 MB, `MAX_MESSAGE_SIZE` 2 MB, `MAX_MESSAGES` 50),
- `WebsocketProbeEndpointRunner` implements RFC 6455 by hand (masked client frames, continuation
  frames, close/ping/pong opcodes). Frame assembly here has already been the subject of a bug fix
  (`c2f6368`) — change it only with a clear reason and re-read the frame loop end to end.

## Twig conventions

- Custom elements provided by the host app are used directly in templates: `<canvas-diagram>`,
  `<json-viewer>`, `<suggest-input>`. They take attributes, often JSON-encoded
  (`value="{{ {key: monitoring.statistics}|json_encode }}"`).
- Live-updating values are marked with `class="js-contain-ajax-fragment"` plus
  `data-fragment-entity` / `data-fragment-entity-id` / `data-fragment-field`.
- Tile templates support a `shortView` flag; the established idiom is
  `{% set isShortView = (shortView is defined) and (shortView != false and shortView != 'false') %}`.
- Access custom object attributes as `customObject.attribute.<name>` where available; some existing templates still use `customObject.attributes` (legacy), so follow the surrounding template and use `?? default` / `is defined` guards as needed.
- Utility classes are Bootstrap-like (`d-flex`, `gap-1`, `flex-1`, `mb-1`) plus local ones
  (`metric-box`, `metric-value`, `metric-label`). Labels go through `|trans`.

## Code style in this repo

- Constructor property promotion for all dependencies; fluent setters returning `static`/`$this`.
- Enums: device enums are lowercase-`e` prefixed (`eDeviceType`, `eDeviceState`) with a static
  `getLabel()` `match`; the permission enum is `EPermission` with a static `getPermissions()`.
  Follow the existing prefix rather than "fixing" it.
- Comments and user-visible descriptions are **mixed German and English**. Endpoint/config
  descriptions and class docblocks are typically German, labels and log messages English. Match the
  surrounding file instead of translating existing text.
- Older files carry a `Created by PhpStorm` header block; new files generally don't. Don't add or
  strip these.
- Some private methods are underscore-prefixed (`_updateDeviceInfos`, `_createRunResult`). Keep the
  local convention.
- The MQTT payload uses short keys that are remapped to attribute names in
  `HandleMqttUpdateServiceEndpointRunner::_updateDeviceInfos()` (`cur_E` → `energy`, `cur_Et` →
  `energy_total`, `cur_P` → `power`, `temperature` → `temp`, `power_state` → `state`, …). Add new
  sensor keys there.

**There is dead and disabled code on purpose.** Examples: `if (count($deviceTrackInfos) > 0 && false)`,
an unconditional `return;` mid-method in `_updateDeviceInfos()`, commented-out `mqttDetails` blocks,
`GrowboxManagementWorker`'s unused `sendFanOnCommand()`/`sendTempOnCommand()`, the commented `Widget/`
DI block. This is work-in-progress scaffolding, not accidents — **do not clean it up opportunistically**.
Remove it only when the task actually asks for it.

## Git / release workflow

- **Conventional commits are mandatory** — release-please parses them.
  `feat:`, `fix:`, `refactor:`, `chore(deps):`, optional scope (`fix(websocket-probe): ...`).
  House style: imperative-ish subject with backticked identifiers, e.g.
  ``feat: Add `SendMqttCommandMacro` for sending commands to MQTT-Broker``.
- **Never hand-edit `CHANGELOG.md` or bump versions.** `.github/workflows/release-please.yml`
  (`release-type: php`) opens the release PR and writes the changelog on pushes to `main`.
  Publishing a release fires `.github/workflows/trigger-satis.yml`, which rebuilds the Satis index.
- CI runs **no tests and no linting** — nothing will catch a broken change before it ships.
  Correspondingly, review your own diff harder than usual.
- `composer.lock` is committed. Dependency bumps come from Renovate (`renovate.json`,
  `config:recommended`); don't update `analytics-core` by hand unless asked.
- Update `README.md` whenever you change an endpoint's name/parameters/response, a tool's behaviour
  or storage keys, a configuration item, or an enum value. The README documents all of these in
  detail and is the only user-facing documentation.

### Known inconsistencies (leave alone unless asked)

- `AnalyticsInfrastructureBundle::getVersion()` returns a hard-coded `'1.0.0'` while the package is
  at 1.16.0.
- `getMenuItems()` returns a "Dokumentverwaltung" item pointing at `analytics_documents_documents`,
  which belongs to a different bundle.
- `README.md` states PHP 8.1+ / analytics-core `^0.3`; the lock file requires PHP 8.4 and
  analytics-core 1.40. Fix these only as an explicit task.

## Working agreement

- Branch work as instructed by the session; commit with a conventional-commit subject; push with
  `git push -u origin <branch>`.
- Before finishing a PHP change: run the `php -l` sweep above and state that this is a syntax check
  only, not a test run.
- Prefer minimal, local changes. This bundle is one plugin inside a larger platform whose core you
  cannot see from here — cross-cutting refactors are risky and hard to verify.
