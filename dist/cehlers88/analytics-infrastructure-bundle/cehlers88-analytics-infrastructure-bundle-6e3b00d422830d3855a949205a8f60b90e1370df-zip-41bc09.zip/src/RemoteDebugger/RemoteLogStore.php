<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\RemoteDebugger;

use Cehlers88\AnalyticsInfrastructureBundle\ENUM\eRemoteLogLevel;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Ablage der Logeinträge, die entfernte Geräte und Services an die Log-Endpunkte
 * des Bundles schicken, und Lesequelle des Remote-Debugger Tools.
 *
 * Die Einträge liegen als JSON-Lines in einer einzigen Datei unterhalb von
 * `var/`, die als Ringpuffer betrieben wird: ist {@see self::MAX_ENTRIES}
 * erreicht, fallen die ältesten Zeilen weg. Damit braucht der Remote-Debugger
 * keine Tabelle und keine Migration; soll er später dauerhaft speichern, wird
 * diese Klasse gegen eine Entity-basierte Ablage getauscht - die Endpunkte
 * kennen nur die vier Methoden dieser Klasse.
 */
class RemoteLogStore
{
    /** Anzahl der Einträge, die die Datei höchstens behält. */
    public const int MAX_ENTRIES = 2000;

    /** Länge, auf die eine Nachricht gekürzt wird. */
    public const int MAX_MESSAGE_LENGTH = 4000;

    /** Länge der JSON-Darstellung von `data`, darüber wird sie verworfen. */
    public const int MAX_DATA_LENGTH = 20000;

    public const int DEFAULT_LIMIT = 200;
    public const int MAX_LIMIT = 1000;

    private const string FILE_PATH = '/var/infrastructure/remote-debugger.jsonl';

    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir
    )
    {
    }

    /**
     * Hängt einen Eintrag an und gibt ihn so zurück, wie er gespeichert wurde.
     *
     * @param array $entry Rohdaten eines Logaufrufs, siehe _normalizeEntry()
     */
    public function append(array $entry): array
    {
        $handle = $this->_openFile();
        if ($handle === null) {
            return $this->_normalizeEntry($entry, 0);
        }

        $lines = $this->_readLines($handle);
        $storedEntry = $this->_normalizeEntry($entry, $this->_readLastSequence($lines) + 1);

        $lines[] = json_encode($storedEntry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $this->_writeLines($handle, $lines);
        $this->_closeFile($handle);

        return $storedEntry;
    }

    /**
     * Liest die gespeicherten Einträge, optional gefiltert.
     *
     * @param array $filter {
     *     @var string[] $levels    nur diese Level (Werte von eRemoteLogLevel)
     *     @var string   $search    Volltextsuche über Nachricht, Gruppe, Quelle und Daten
     *     @var string   $groupKey  Gruppenschlüssel, als Präfix verglichen
     *     @var int      $since     nur Einträge mit einer höheren Sequenznummer
     *     @var int      $limit     Anzahl der zurückgegebenen Einträge
     * }
     */
    public function read(array $filter = []): array
    {
        $entries = $this->_readEntries();
        $levelCounts = array_fill_keys(eRemoteLogLevel::getValues(), 0);

        foreach ($entries as $entry) {
            $level = $entry['level'] ?? eRemoteLogLevel::INFO->value;
            $levelCounts[$level] = ($levelCounts[$level] ?? 0) + 1;
        }

        $matchingEntries = array_values(array_filter(
            $entries,
            fn(array $entry): bool => $this->_matchesFilter($entry, $filter)
        ));

        $limit = min(max((int)($filter['limit'] ?? self::DEFAULT_LIMIT), 1), self::MAX_LIMIT);
        $lastEntry = end($entries);

        return [
            'entries' => array_slice($matchingEntries, -$limit),
            'total' => count($entries),
            'matched' => count($matchingEntries),
            'lastSequence' => $lastEntry === false ? 0 : (int)($lastEntry['sequence'] ?? 0),
            'levelCounts' => $levelCounts,
            'maxEntries' => self::MAX_ENTRIES,
            'file' => ltrim(self::FILE_PATH, '/'),
        ];
    }

    /** Leert den Ringpuffer und meldet, wie viele Einträge entfernt wurden. */
    public function clear(): int
    {
        $handle = $this->_openFile();
        if ($handle === null) {
            return 0;
        }

        $removedCount = count($this->_readLines($handle));
        $this->_writeLines($handle, []);
        $this->_closeFile($handle);

        return $removedCount;
    }

    public function getFilePath(): string
    {
        return $this->projectDir . self::FILE_PATH;
    }

    /**
     * Bringt einen Logaufruf in die Form, in der er gespeichert wird. Alles,
     * was ein Gerät nicht mitschickt, bekommt einen Standardwert - der Store
     * lehnt keinen Eintrag ab, ein kaputter Aufruf soll im Tool sichtbar sein.
     */
    private function _normalizeEntry(array $entry, int $sequence): array
    {
        $data = $entry['data'] ?? null;
        $encodedData = $data === null ? '' : json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        if ($encodedData !== '' && strlen($encodedData) > self::MAX_DATA_LENGTH) {
            $data = ['_truncated' => 'Data of ' . strlen($encodedData) . ' bytes was dropped by the log store.'];
        }

        $message = is_scalar($entry['message'] ?? null) ? trim((string)$entry['message']) : '';

        return [
            'sequence' => $sequence,
            'id' => bin2hex(random_bytes(8)),
            'receivedAt' => new \DateTimeImmutable()->format(\DateTimeInterface::ATOM),
            'type' => ($entry['type'] ?? 'log') === 'error' ? 'error' : 'log',
            'level' => eRemoteLogLevel::fromValue(
                $entry['level'] ?? null,
                eRemoteLogLevel::fromValue($entry['type'] ?? null)
            )->value,
            'message' => mb_substr($message, 0, self::MAX_MESSAGE_LENGTH),
            'groupKey' => is_scalar($entry['groupKey'] ?? null) ? trim((string)$entry['groupKey']) : '',
            'source' => is_scalar($entry['source'] ?? null) ? trim((string)$entry['source']) : '',
            'number' => isset($entry['number']) && is_numeric($entry['number']) ? (int)$entry['number'] : null,
            'priority' => isset($entry['priority']) && is_numeric($entry['priority']) ? (int)$entry['priority'] : null,
            'data' => $data,
        ];
    }

    private function _matchesFilter(array $entry, array $filter): bool
    {
        if ((int)($entry['sequence'] ?? 0) <= (int)($filter['since'] ?? 0)) {
            return false;
        }

        $levels = array_filter((array)($filter['levels'] ?? []));
        if (count($levels) > 0 && !in_array($entry['level'] ?? '', $levels, true)) {
            return false;
        }

        $groupKey = trim((string)($filter['groupKey'] ?? ''));
        if ($groupKey !== '' && !str_starts_with(mb_strtolower($entry['groupKey'] ?? ''), mb_strtolower($groupKey))) {
            return false;
        }

        $search = trim((string)($filter['search'] ?? ''));
        if ($search === '') {
            return true;
        }

        $haystack = mb_strtolower(implode(' ', [
            $entry['message'] ?? '',
            $entry['groupKey'] ?? '',
            $entry['source'] ?? '',
            json_encode($entry['data'] ?? null, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
        ]));

        return str_contains($haystack, mb_strtolower($search));
    }

    /**
     * @return array[] Alle gespeicherten Einträge, aufsteigend nach Sequenznummer.
     */
    private function _readEntries(): array
    {
        $handle = $this->_openFile();
        if ($handle === null) {
            return [];
        }

        $lines = $this->_readLines($handle);
        $this->_closeFile($handle);

        $entries = [];
        foreach ($lines as $line) {
            $entry = json_decode($line, true);
            if (is_array($entry)) {
                $entries[] = $entry;
            }
        }

        return $entries;
    }

    /**
     * Öffnet die Puffer-Datei und sperrt sie exklusiv, damit sich gleichzeitige
     * Logaufrufe mehrerer Geräte nicht überschreiben.
     *
     * @return resource|null
     */
    private function _openFile()
    {
        $filePath = $this->getFilePath();
        $directory = dirname($filePath);

        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            return null;
        }

        $handle = fopen($filePath, 'c+');
        if ($handle === false) {
            return null;
        }

        if (!flock($handle, LOCK_EX)) {
            fclose($handle);
            return null;
        }

        return $handle;
    }

    /**
     * @param resource $handle
     * @return string[]
     */
    private function _readLines($handle): array
    {
        rewind($handle);
        $content = stream_get_contents($handle);

        if (!is_string($content) || trim($content) === '') {
            return [];
        }

        return array_values(array_filter(explode("\n", $content), static fn(string $line): bool => trim($line) !== ''));
    }

    /**
     * Schreibt den Puffer neu und kürzt ihn dabei auf MAX_ENTRIES Zeilen.
     *
     * @param resource $handle
     * @param string[] $lines
     */
    private function _writeLines($handle, array $lines): void
    {
        $lines = array_slice($lines, -self::MAX_ENTRIES);

        rewind($handle);
        ftruncate($handle, 0);

        if (count($lines) > 0) {
            fwrite($handle, implode("\n", $lines) . "\n");
        }

        fflush($handle);
    }

    /**
     * @param string[] $lines
     */
    private function _readLastSequence(array $lines): int
    {
        $lastLine = end($lines);
        if ($lastLine === false) {
            return 0;
        }

        $entry = json_decode($lastLine, true);

        return is_array($entry) ? (int)($entry['sequence'] ?? 0) : 0;
    }

    /**
     * @param resource $handle
     */
    private function _closeFile($handle): void
    {
        flock($handle, LOCK_UN);
        fclose($handle);
    }
}
