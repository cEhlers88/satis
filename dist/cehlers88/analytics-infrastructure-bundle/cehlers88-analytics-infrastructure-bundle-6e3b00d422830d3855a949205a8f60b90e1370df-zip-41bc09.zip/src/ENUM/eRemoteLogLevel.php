<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ENUM;

/**
 * Schweregrad eines Logeintrags, den ein entferntes Gerät an die Log-Endpunkte
 * des Bundles geschickt hat. Die Geräte liefern sehr unterschiedliche
 * Bezeichnungen (`warn`, `exception`, `fatal`, ...), deshalb werden sie über
 * {@see self::fromValue()} auf diese fünf Stufen abgebildet.
 */
enum eRemoteLogLevel: string
{
    case DEBUG = 'debug';
    case INFO = 'info';
    case WARNING = 'warning';
    case ERROR = 'error';
    case CRITICAL = 'critical';

    public static function fromValue(mixed $value, eRemoteLogLevel $default = self::INFO): eRemoteLogLevel
    {
        if ($value instanceof eRemoteLogLevel) {
            return $value;
        }

        return match (strtolower(trim(is_scalar($value) ? (string)$value : ''))) {
            'debug', 'trace', 'verbose' => self::DEBUG,
            'info', 'information', 'notice', 'log' => self::INFO,
            'warn', 'warning' => self::WARNING,
            'err', 'error', 'exception' => self::ERROR,
            'critical', 'fatal', 'emergency', 'alert' => self::CRITICAL,
            default => $default
        };
    }

    public static function getLabel(eRemoteLogLevel $level): string
    {
        return match ($level) {
            self::DEBUG => 'Debug',
            self::INFO => 'Info',
            self::WARNING => 'Warning',
            self::ERROR => 'Error',
            self::CRITICAL => 'Critical',
            default => 'Info'
        };
    }

    /**
     * @return string[] Alle Stufen als Wert, von der leisesten zur lautesten.
     */
    public static function getValues(): array
    {
        return array_map(static fn(eRemoteLogLevel $level): string => $level->value, self::cases());
    }
}
