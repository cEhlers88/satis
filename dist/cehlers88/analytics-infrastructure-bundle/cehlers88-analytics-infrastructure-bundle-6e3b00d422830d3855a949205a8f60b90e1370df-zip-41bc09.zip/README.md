# AnalyticsInfrastructureBundle

A Symfony bundle for managing peripheral devices and infrastructure within the [Analytics](https://github.com/cEhlers88) platform. It provides MQTT device tracking, device state management, and seamless integration with the Analytics Core.

## Requirements

- PHP 8.1+
- Symfony 6.0+
- [`cehlers88/analytics-core`](https://github.com/cEhlers88/analytics-core) `^0.3`

## Installation

Install the bundle via Composer. Because the package is hosted on a private Satis repository, add the repository to your `composer.json` first:

```json
{
    "repositories": [
        {
            "type": "composer",
            "url": "https://cehlers88.github.io/satis"
        }
    ]
}
```

Then require the bundle:

```bash
composer require cehlers88/analytics-infrastructure-bundle
```

Register the bundle in your Symfony application (e.g. `config/bundles.php`):

```php
return [
    // ...
    Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle::class => ['all' => true],
];
```

## Database Setup

Run the Doctrine migrations to create the required `infrastructure_device` table:

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

## Configuration

The bundle exposes its settings through the Analytics Core configuration UI under the key `infrastructureBundle.general`. The following options are available:

| Option | Type | Description |
|---|---|---|
| `mqttApplicationId` | select | The Analytics application used to track MQTT device updates. |
| `networkBridges` | repeat | A list of network bridges (name + address) that act as gateways between networks. |

Example configuration (if set programmatically):

```yaml
# The configuration is managed through the Analytics UI,
# but the internal key used by the bundle is:
# infrastructureBundle.general
#
# mqttApplicationId: <id of the analytics application>
# networkBridges:
#   - name: "My Bridge"
#     address: "192.168.1.1"
```

## Features

### Device Tracking via MQTT

The bundle receives device lists from an MQTT source through the `handle_mqtt_update` service endpoint. For each device, it:

1. Looks up or creates a `Client` record by IP or MAC address.
2. Creates or updates a `Device` entity linked to that client.
3. Sets the device state to **Online** or **Offline** based on the payload.
4. Stores the raw MQTT stats as `ClientDetails` with the tag `mqtt_device`.
5. Records a tracking event via `TrackingRecorder` against the configured MQTT application.

### FritzBox Client List Worker

The `FetchFritzboxClientListWorker` fetches a client list from the FritzBox gateway.  
By default it uses `192.168.178.1` and requests `/clientlist` (tries HTTPS first, then HTTP for host-only entries).  
Optional override: set `ANALYTICS_FRITZBOX_GATEWAYS` as a comma-separated list of gateway hosts/URLs.

#### MQTT Update Endpoint

**Endpoint name:** `handle_mqtt_update`

**Method:** `POST`

**Payload (form-encoded or JSON):**

```json
{
    "devices": [
        {
            "stats": {
                "ip":     "192.168.1.100",
                "mac":    "AA:BB:CC:DD:EE:FF",
                "hn":     "my-device",
                "online": 1
            }
        }
    ]
}
```

| Field | Type | Description |
|---|---|---|
| `stats.ip` | string | IP address of the device. |
| `stats.mac` | string | MAC address of the device. |
| `stats.hn` | string | Hostname of the device. |
| `stats.online` | int | `1` = online, `0` = offline. |

### API Fetcher Tool

The bundle ships the `apiFetcher` tool for the Analytics dashboard (`/dashboard/tools`, listed as a
tile and opened in a modal). It is a small HTTP client for debugging APIs and consists of the template
`templates/tool/apiFetcher.html.twig`, its script `templates/tool/script/apiFetcher.js.twig`, the tile
teaser `templates/tool/teaser/apiFetcher.html.twig` and the `api_fetcher_request` service endpoint.

Features:

- Compact request bar (method, URL, sender, send) with headers, arguments and a raw body
  behind tabs, each showing how many entries are defined.
- The transfer of the arguments is selectable (see below) and the `Content-Type` header follows the
  selected mode as long as it is not edited by hand.
- Requests can be sent by the browser (*Send as Client*) or by the server (*Send as Server*), which
  allows requesting endpoints that the browser cannot reach (CORS, LAN-only services, ...).
- The URL field is a `suggest-input`: predefined requests can be searched and taken over (see
  below), free URLs and methods keep working exactly as before.
- Every request is logged in the request history with timestamp, method, status code, response type
  and duration (in seconds from one second on). Entries can be selected, re-sent, taken over into
  the form or removed. Switching between entries keeps the selected response view.
- The history can be filtered by URL and reduced to failed requests; the displayed columns are
  toggled in the collapsible *Columns* section.
- Responses are shown as raw body and rendered body (`json-viewer` for JSON, sandboxed frame for
  HTML) together with status, size and response headers.
- Request, options (including the selected response view) and history are stored per tool in the
  `localStorage` of the browser
  (`analytics.tool.apiFetcher.state`) and restored on the next visit. *Reset* clears the request,
  *Clear* the history; when both are empty the stored entry is removed. Stored response bodies are
  truncated at 50.000 characters, at most 50 requests are kept, and if the storage is full the
  bodies and finally the history are dropped.

#### Transfer modes

| Mode | Transfer | Content-Type |
|---|---|---|
| `Automatic` | Query parameters for `GET`, `HEAD`, `OPTIONS` and `DELETE`, otherwise a JSON body. A raw body wins. | `application/json` for a JSON body |
| `JSON body` | Arguments as JSON body, a raw body is sent unchanged. | `application/json` |
| `Form data (multipart)` | Arguments as multipart body (`FormData` in the browser, curl on the server). | set automatically including the boundary |
| `Form data (urlencoded)` | Arguments url encoded in the body. | `application/x-www-form-urlencoded` |
| `Query parameters` | Arguments appended to the URL, no body. | none |
| `Raw body` | Only the raw body. | taken from the headers |

`GET` and `HEAD` cannot carry a body, therefore the arguments of those requests are always sent as
query parameters. A `Content-Type` header that was entered by hand is never overwritten.

#### Predefined requests

The tool renders the template variable `requestTemplates` into the page and offers its entries as
suggestions while the URL is typed. Taking one over fills url, method, headers, arguments, transfer
mode and body; everything stays editable afterwards.

```php
'templateData' => [
    'requestTemplates' => [
        [
            'label' => 'AnalyticsInfrastructureBundle.log',  // shown in the suggestion
            'description' => 'Endpunkt zum loggen von Nachrichten',
            'url' => 'https://example.com/api/se/AnalyticsInfrastructureBundle.log',
            'method' => 'POST',
            'headers' => [],                                  // list of name/value entries
            'args' => [['name' => 'message', 'value' => 'Hello']],
            'transfer' => 'auto',
            'body' => '',
        ],
    ],
],
```

The Analytics application fills this list with every endpoint provided by a `ServiceEndpointRunner`
(`DashboardController::buildServiceEndpointRequestTemplates()`), including the documented parameters
as prepared arguments. Without the variable the URL field behaves like a plain input.

#### API Fetcher Endpoint

**Endpoint name:** `AnalyticsInfrastructureBundle.api_fetcher_request` (alias `apiFetcherRequest`)

**Method:** `POST`

**Required role:** `AUTHENTICATED_USER`

**Payload (JSON):**

```json
{
    "url": "https://example.com/api/endpoint",
    "method": "POST",
    "headers": {
        "Content-Type": "application/json"
    },
    "body": "{\"foo\":\"bar\"}",
    "timeout": 30
}
```

| Field | Type | Description |
|---|---|---|
| `url` | string | The requested URL. Only `http` and `https` are allowed. |
| `method` | string | One of `GET`, `POST`, `PUT`, `DELETE`, `PATCH`, `HEAD`, `OPTIONS`. Defaults to `GET`. |
| `headers` | array | Request headers, either as map (`name: value`) or as list of `name`/`value` entries. |
| `body` | string | Raw request body. Arrays are encoded as JSON. Ignored for `GET` and `HEAD`. |
| `timeout` | int | Timeout in seconds (1-120, default 30). |
| `transfer` | string | Transfer mode. With `form-data` the `arguments` are sent as multipart body and the `Content-Type` is generated by curl, otherwise `body` is used. |
| `arguments` | array | Arguments as list of `name`/`value` entries, used for `transfer` = `form-data`. |

The endpoint answers with the result of the executed request. Transport errors (unreachable host,
timeout, ...) are not reported as endpoint errors but as `errorMessage` inside the result data, so
the tool can display them like any other response:

```json
{
    "statusCode": 200,
    "statusText": "OK",
    "headers": [{"name": "Content-Type", "value": "application/json"}],
    "body": "{}",
    "size": 2,
    "durationMs": 42.13,
    "url": "https://example.com/api/endpoint",
    "method": "POST",
    "errorMessage": null
}
```

### WebSocket Console Tool

The bundle ships the `websocketConsole` tool for the Analytics dashboard (`/dashboard/tools`, listed
as a tile and opened in a modal). It is the counterpart of the API Fetcher for bidirectional
connections and consists of the template `templates/tool/websocketConsole.html.twig`, its script
`templates/tool/script/websocketConsole.js.twig`, the tile teaser
`templates/tool/teaser/websocketConsole.html.twig` and the `websocket_probe` service endpoint.

Features:

- Connection bar (URL, subprotocols, sender, connect/disconnect, send) with the payload, JSON fields
  and handshake headers behind tabs; the connection state is shown as badge.
- The browser keeps the connection open (*Connect as Client*), incoming messages arrive live. As
  alternative the server opens a short-lived connection per message (*Probe from Server*), which
  reaches endpoints the browser refuses (`ws://` on an https dashboard, no CORS, LAN-only devices).
- The message format is selectable (see below); JSON payloads can be composed from name/value
  fields, binary frames are entered and displayed as hex.
- The URL field is a `suggest-input`: predefined endpoints can be searched and taken over (see
  below), free URLs keep working.
- Every sent and received message and every connection event is logged with timestamp, direction,
  type and size. Entries can be selected, sent again, taken over into the composer or removed.
- The log can be filtered by content and reduced to messages without connection events; the
  displayed columns and *Follow log* are toggled in the collapsible *Columns* section.
- Messages are shown as raw body and rendered body (`json-viewer` for JSON, grouped hex dump for
  binary frames) together with direction, size and timestamp.
- *Reconnect* re-opens a connection that was closed unexpectedly, up to five times with three
  seconds delay. A pending reconnect is stopped with *Disconnect*.
- Composer, options (including the selected message view) and log are stored per tool in the
  `localStorage` of the browser (`analytics.tool.websocketConsole.state`) and restored on the next
  visit; the connection itself is never restored. *Reset* clears the composer, *Clear* the log; when
  both are empty the stored entry is removed. Stored message bodies are truncated at 50.000
  characters, at most 200 entries are kept, and if the storage is full the bodies and finally the
  log are dropped.

#### Message formats

| Format | Sent frame | Fields |
|---|---|---|
| `Text` | The payload unchanged as text frame. | ignored |
| `JSON` | The fields as JSON object; without fields the payload itself, which has to be valid JSON. | used |
| `Binary (hex)` | The payload read as hex string (whitespace allowed) as binary frame. | ignored |

Received binary frames are logged as hex string as well, the rendered view groups them into bytes
and lines of 16 bytes. `Ctrl`/`Cmd` + `Enter` in the payload field sends the message; *Send* on a
closed connection opens the connection first and sends the message afterwards.

#### Predefined endpoints

The tool renders the template variable `endpointTemplates` into the page and offers its entries as
suggestions while the URL is typed. Taking one over fills url, subprotocols, format, fields and
payload; everything stays editable afterwards.

```php
'templateData' => [
    'endpointTemplates' => [
        [
            'label' => 'Mercure hub',                    // shown in the suggestion
            'description' => 'Realtime updates of the dashboard',
            'url' => 'wss://example.com/.well-known/mercure',
            'protocols' => ['mercure'],                  // offered subprotocols
            'format' => 'json',                          // text | json | binary
            'fields' => [['name' => 'topic', 'value' => 'infrastructure/device']],
            'headers' => [],                             // handshake headers, server probe only
            'payload' => '',
        ],
    ],
],
```

Without the variable the URL field behaves like a plain input.

#### Registering the tool

The tool is registered in the tool list of the Analytics application, next to the API Fetcher:

```php
[
    'description' => 'Talk to a websocket endpoint',
    'icon' => null,
    'image' => null,
    'teaser' => 'teaser/websocketConsole.html.twig',
    'name' => 'websocketConsole',
    'scripts' => ['script/websocketConsole.js.twig'],
    'styles' => [],
    'title' => 'WebSocket Console',
    'template' => 'websocketConsole.html.twig',
    'templateData' => ['endpointTemplates' => []],
]
```

#### WebSocket Probe Endpoint

**Endpoint name:** `AnalyticsInfrastructureBundle.websocket_probe` (alias `websocketProbe`)

**Method:** `POST`

**Required role:** `AUTHENTICATED_USER`

The endpoint opens a WebSocket connection (RFC 6455 handshake, masked client frames), sends the
optional message, collects the incoming messages until the timeout is reached and closes the
connection again. Because the endpoint is stateless every call is an own connection, a permanently
open connection is only possible in the browser.

**Payload (JSON):**

```json
{
    "url": "wss://example.com/socket",
    "message": "{\"topic\":\"infrastructure/device\"}",
    "format": "text",
    "protocols": ["mercure"],
    "headers": {
        "Authorization": "Bearer ..."
    },
    "timeout": 5
}
```

| Field | Type | Description |
|---|---|---|
| `url` | string | The requested URL. Only `ws` and `wss` are allowed. |
| `message` | string | Message that is sent after the handshake. Without it the endpoint only listens. |
| `format` | string | `text` (default) or `binary`; a binary message is expected as hex string. |
| `protocols` | array | Offered subprotocols (`Sec-WebSocket-Protocol`), as list or comma separated string. |
| `headers` | array | Additional handshake headers, either as map (`name: value`) or as list of `name`/`value` entries. The headers of the handshake itself cannot be overwritten. |
| `timeout` | int | Seconds that incoming messages are collected (1-30, default 5). |

Like the API Fetcher the endpoint refuses `localhost` and private or reserved IP ranges, at most 50
messages are collected and a single frame may not exceed 2 MB. Connection and handshake errors are
not reported as endpoint errors but as `errorMessage` inside the result data, so the tool can
display them like any other event:

```json
{
    "url": "wss://example.com/socket",
    "statusCode": 101,
    "statusText": "Switching Protocols",
    "headers": [{"name": "Sec-WebSocket-Accept", "value": "..."}],
    "protocol": "mercure",
    "messages": [{"type": "Text", "body": "{}", "size": 2, "offsetMs": 12.4}],
    "closeCode": 1000,
    "closeReason": "",
    "durationMs": 512.4,
    "errorMessage": null
}
```

### Remote Debugger Tool

The bundle ships the `remoteDebugger` tool for the Analytics dashboard (`/dashboard/tools`, listed as
a tile and opened in a modal). It shows the log entries that devices and services of the local
network sent to the log endpoints of the bundle and consists of the template
`templates/tool/remoteDebugger.html.twig`, its script `templates/tool/script/remoteDebugger.js.twig`,
the tile teaser `templates/tool/teaser/remoteDebugger.html.twig`, the `RemoteLogStore` and the
`remote_debugger_logs` / `remote_debugger_clear` service endpoints.

This is the base of the tool: it displays what arrives, nothing more.

Features:

- Entries are listed newest first with time, level, group key, message and the source address; an
  entry opens on click and shows the sent data in a `json-viewer` together with sequence number,
  type, timestamp, error number and priority.
- Filter by level (the chips carry the number of stored entries per level), by group key (compared
  as a prefix, so `growbox/` matches `growbox/pump`) and by a full text search over message, group
  key, source and data.
- *Follow* reloads every 2 to 30 seconds and puts only the new entries in front of the list, so an
  opened entry stays open. A tool whose modal is closed or whose browser tab is in the background
  does not poll.
- *Clear* empties the buffer on the server for everybody, *Refresh* reads it again with the current
  filter.
- Filter, level selection, follow mode and interval are stored in the `localStorage` of the browser
  (`analytics.tool.remoteDebugger.state`); the entries themselves always come from the server.

#### Log storage

`RemoteDebugger\RemoteLogStore` keeps the entries as JSON lines in
`var/infrastructure/remote-debugger.jsonl` of the host application and runs that file as a ring
buffer: the newest 2.000 entries are kept, older ones fall out. A message is cut at 4.000 characters,
a `data` payload whose JSON representation exceeds 20.000 characters is replaced by a `_truncated`
note. Every entry carries a `sequence` that keeps counting past the cap, which is what the tool uses
to load only the entries it has not seen yet.

Because the store is a file, the tool needs no table and no migration. Should the entries have to
survive longer or become searchable in SQL, this class is the single place to exchange - the
endpoints only use `append()`, `read()`, `clear()` and `getFilePath()`.

A stored entry looks like this:

```json
{
    "sequence": 42,
    "id": "9f2c1d4e7b0a5c31",
    "receivedAt": "2026-09-11T16:25:00+00:00",
    "type": "error",
    "level": "critical",
    "message": "Sensor timeout after 3 retries",
    "groupKey": "growbox/sensor",
    "source": "192.168.1.9",
    "number": 42,
    "priority": 3,
    "data": {"retries": 3}
}
```

The levels the devices send (`warn`, `exception`, `fatal`, `notice`, ...) are mapped onto
`debug`, `info`, `warning`, `error` and `critical` by `eRemoteLogLevel::fromValue()`; an unknown
level becomes `info` on `AnalyticsInfrastructureBundle.log` and `error` on
`AnalyticsInfrastructureBundle.error`.

#### Log Endpoints

**Endpoint names:** `AnalyticsInfrastructureBundle.log` and `AnalyticsInfrastructureBundle.error`

**Method:** `POST`

**Required role:** `IS_LAN_DEVICE`

Both endpoints write into the `RemoteLogStore` and answer with the stored entry:

| Parameter | Type | Endpoint | Description |
|---|---|---|---|
| `message` | string | both | The message, required. |
| `data` | mixed | both | Free payload, shown in the tool as JSON. |
| `groupKey` | string | both | Groups entries, e.g. `growbox/pump`. |
| `level` | string | both | `info`, `warning`, `debug` / `warning`, `exception`, `fatal`. |
| `number` | int | error | Error number, required on `error`. |
| `priority` | int | error | Priority of the error. |

```json
{
    "hasError": false,
    "statusCode": 200,
    "message": "Entry logged",
    "data": {"id": "9f2c1d4e7b0a5c31", "sequence": 42, "level": "critical", "receivedAt": "2026-09-11T16:25:00+00:00"}
}
```

The source address is not taken from the payload but from the request itself.

#### Remote Debugger Endpoints

**Endpoint name:** `AnalyticsInfrastructureBundle.remote_debugger_logs` (alias `remoteDebuggerLogs`)

**Methods:** `GET`, `POST`

**Required role:** `AUTHENTICATED_USER`

**Payload (JSON), every parameter optional:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `since` | int | `0` | Only entries with a higher sequence number. |
| `limit` | int | `200` | Number of returned entries, at most 1.000. |
| `levels` | array\|string | `[]` | Only these levels, as a list or comma separated. An empty list means every level. |
| `groupKey` | string | `''` | Group key, compared as a prefix. |
| `search` | string | `''` | Full text over message, group key, source and data. |

```json
{
    "entries": [],
    "total": 128,
    "matched": 12,
    "lastSequence": 128,
    "levelCounts": {"debug": 4, "info": 100, "warning": 20, "error": 3, "critical": 1},
    "maxEntries": 2000,
    "file": "var/infrastructure/remote-debugger.jsonl"
}
```

`entries` holds the newest `limit` entries that match the filter, oldest first. `total` and
`levelCounts` always count the whole buffer, `matched` the entries behind the filter.

**Endpoint name:** `AnalyticsInfrastructureBundle.remote_debugger_clear` (alias `remoteDebuggerClear`)

**Method:** `POST`

**Required role:** `AUTHENTICATED_USER`

Empties the buffer and answers with `{"removed": <count>}`.

#### Registering the tool

The tool is registered in the tool list of the Analytics application, next to the API Fetcher:

```php
[
    'description' => 'Show the log entries remote devices sent to the infrastructure bundle',
    'icon' => null,
    'image' => null,
    'teaser' => 'teaser/remoteDebugger.html.twig',
    'name' => 'remoteDebugger',
    'scripts' => ['script/remoteDebugger.js.twig'],
    'styles' => [],
    'title' => 'Remote Debugger',
    'template' => 'remoteDebugger.html.twig',
    'templateData' => [],
]
```

### Device Types (`eDeviceType`)

| Value | Label |
|---|---|
| `0` | Unknown |
| `1` | Desktop |
| `2` | Laptop |
| `3` | Tablet |
| `4` | Smartphone |
| `5` | Server |
| `6` | Network device |
| `7` | Printer |
| `10` | Smart home device |
| `11` | Smart TV |
| `12` | Smart watch |
| `13` | Smart glasses |
| `14` | Smart speaker |
| `15` | Smart display |
| `16` | Smart sensor |
| `25` | Scanner |
| `26` | Camera |
| `40` | Gaming console |

### Device States (`eDeviceState`)

| Value | Label |
|---|---|
| `0` | Unknown |
| `1` | Offline |
| `2` | Online |
| `3` | Error |

### Macros

#### `getDevices`

Returns all registered `Device` entities from the database.

**Usage in Analytics templates/reports:**

```
{{ macro('getDevices') }}
```

### Client Info Extender

The bundle automatically adds two columns to the Analytics client overview:

- **Device Type** – the type of the device (e.g. *Smart sensor*, *Laptop*).
- **Device State** – the current state of the device (e.g. *Online*, *Offline*).

### Permissions

| Permission | Description |
|---|---|
| `ACCESS_INFRASTRUCTURE` | Grants access to the Infrastructure module. |

## Project Structure

```
src/
├── AnalyticsInfrastructureBundle.php   # Bundle entry point
├── ClientInfoExtender/
│   └── DeviceClientInfoExtender.php    # Adds device columns to client overview
├── Configuration/
│   └── GeneralConfigurationGroup.php   # Bundle configuration (MQTT app, bridges)
├── ENUM/
│   ├── eDeviceState.php                # Device state enum (Unknown/Offline/Online/Error)
│   ├── eDeviceType.php                 # Device type enum (18 types)
│   ├── eRemoteLogLevel.php             # Log level enum of the Remote Debugger
│   └── EPermission.php                 # Bundle permission enum
├── Entity/
│   └── Device.php                      # Doctrine entity mapped to `infrastructure_device`
├── Macro/
│   ├── AbstractInfrastructureMacro.php # Base class for bundle macros
│   └── GetDevicesMacro.php             # Macro: returns all devices
├── RemoteDebugger/
│   └── RemoteLogStore.php              # Ring buffer of the logs of remote devices
├── Repository/
│   └── DeviceRepository.php            # Doctrine repository for Device
├── Resources/
│   └── config/
│       └── services.yaml               # Symfony DI configuration
├── ServiceEndpointRunner/
│   ├── HandleMqttUpdateServiceEndpointRunner.php  # MQTT update handler
│   ├── LogServiceEndpointRunner.php               # Log endpoints of the local network
│   └── RemoteDebuggerEndpointRunner.php           # Read side of the Remote Debugger tool
└── Worker/
    ├── AnalyzeMqttDevicesWorker.php      # MQTT analysis worker (planned)
    └── FetchFritzboxClientListWorker.php # Fetches client lists from FritzBox gateway 192.168.178.1
```

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a full version history.

## License

This project is proprietary software. See [LICENSE](LICENSE) for details.
