<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\ClientDetails;
use Cehlers88\AnalyticsCore\Recorder\TrackingRecorder;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;
use Cehlers88\AnalyticsInfrastructureBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsInfrastructureBundle\CustomObject\LanService;
use Symfony\Component\HttpFoundation\Request;

class LanServiceInfoEndpointRunner extends AbstractServiceEndpointRunner
{

    public function __construct(
        private CustomObjectProvider $customObjectProvider,
    )
    {
    }

    public function getEndpoints(): mixed
    {
        //return "";
        return [
            EndpointDefinitionDTO::create('lan_service_info', ['POST'], [
                PropertyDTO::create('service_name', null, 'string')
            ])
        ];
    }

    public function getDescription(): string
    {
        return "Endpunkt zur Aufnahme von Serviceinformationen aus dem LAN.";
    }

    public function handleRequest(Request $request): mixed
    {
        $dateTime = new \DateTimeImmutable();
        $requestData = $request->toArray();

        $serviceName = $requestData['service_name'] ?? null;

        if (empty($serviceName)) {
            return ServiceEndpointRunnerResultDTO::createError('Service name is missing');
        }

        /** @var LanService $lanService */
        $lanService = $this->customObjectProvider->getCustomEntityByClassNameAndName(
            LanService::class,
            $serviceName
        );

        if (empty($lanService)) {
            return ServiceEndpointRunnerResultDTO::createError('Service not found');
        }

        $lanService->setLastSeen($dateTime);

        return ServiceEndpointRunnerResultDTO::createSuccess($request->toArray(), 'Lan-Service-Info-Handler');
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }

    public function getRequiredRoles(): array
    {
        return ['IS_LAN_DEVICE'];
    }
}