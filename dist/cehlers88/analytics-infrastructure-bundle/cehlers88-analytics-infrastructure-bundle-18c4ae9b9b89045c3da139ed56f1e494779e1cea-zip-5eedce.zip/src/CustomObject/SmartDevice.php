<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDeviceType\EnvironmentDevice;
use Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDeviceType\PowerAdapterDevice;
use Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDeviceType\SensorDevice;

class SmartDevice extends AbstractCustomObject
{
    public function getAttributeTemplates(): array
    {
        return [
            ...SensorDevice::getAttributeTemplates(),
            ...EnvironmentDevice::getAttributeTemplates(),
        ];
    }

    public function getTileTemplate(): ?string
    {
        switch ($this->getDeviceType()) {
            case 'environment':
                return 'customObject/tile/smartDevice_environment.html.twig';
            case 'plotter_3d':
                return 'customObject/tile/smartDevice_plotter.html.twig';
            case 'power_adapter':
                return PowerAdapterDevice::TEMPLATES_PATH;
            case 'sensor':
                return SensorDevice::TEMPLATES_PATH;
        }
        return null;
    }

    public function getDeviceType(): string
    {
        return $this->getAttribute('device_type', '');
    }

    public function getTileDetails(): array
    {
        $result = ['childObjects' => []];

        return $result;
    }
}