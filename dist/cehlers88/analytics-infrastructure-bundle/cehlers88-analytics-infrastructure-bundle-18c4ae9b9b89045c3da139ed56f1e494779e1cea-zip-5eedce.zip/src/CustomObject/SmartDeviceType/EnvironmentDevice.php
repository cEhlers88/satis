<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDeviceType;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;

class EnvironmentDevice
{
    public static function getAttributeTemplates(): array
    {
        return [
            [
                'name' => 'Environment',
                'attributes' => [
                    'device_type' => 'environment',
                    'environment_type' => 'divers',
                    'managed_devices' => '[{"id":"", "type":"powerAdapter"}]'
                ]
            ],
            [
                'name' => 'Plotter 2D',
                'attributes' => [
                    'device_type' => 'environment',
                    'environment_type' => 'plotter_2d',
                    'managed_devices' => '[{"id":"", "type":"powerAdapter"}]'
                ]
            ],
            [
                'name' => 'Plotter 3D',
                'attributes' => [
                    'device_type' => 'environment',
                    'environment_type' => 'plotter_3d',
                    'managed_devices' => '[{"id":"", "type":"powerAdapter"}]'
                ]
            ]
        ];
    }

    public function getAttributes(): array
    {
        $attrEnvironment = PropertyDTO::create(
            'environment_type',
            'divers'
        );

        return [
            $attrEnvironment
        ];
    }

    public function getAvailableEnvironmentTypes(): array
    {
        return [
            'plotter_2d',
            'plotter_3d',
            'divers'
        ];
    }
}