<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDeviceType;

class SensorDevice
{
    public const string TEMPLATES_PATH = 'customObject/tile/smartDevice_sensor.html.twig';

    public static function getAttributeTemplates(): array
    {
        return [
            [
                'name' => 'Temperature sensor',
                'attributes' => [
                    'device_type' => 'sensor',
                    'label' => 'Temperature',
                    'sensor_type' => 'temperature',
                    'unit' => '°C',
                    'value' => '0'
                ]
            ],
            [
                'name' => 'Humidity sensor',
                'attributes' => [
                    'device_type' => 'sensor',
                    'label' => 'Humidity',
                    'sensor_type' => 'humidity',
                    'unit' => '%',
                    'value' => '0'
                ]
            ],
            [
                'name' => 'CO2 sensor',
                'attributes' => [
                    'device_type' => 'sensor',
                    'label' => 'CO2',
                    'sensor_type' => 'co2',
                    'unit' => 'ppm',
                    'value' => '0'
                ]
            ],
        ];
    }
}