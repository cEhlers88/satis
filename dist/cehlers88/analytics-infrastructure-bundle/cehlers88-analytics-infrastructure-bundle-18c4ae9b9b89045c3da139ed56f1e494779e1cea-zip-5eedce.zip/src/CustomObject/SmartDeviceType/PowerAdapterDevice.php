<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDeviceType;

class PowerAdapterDevice
{
    public const string TEMPLATES_PATH = 'customObject/tile/smartDevice_power_adapter.html.twig';

    public static function getAttributeTemplates(): array
    {
        return [
            [
                'name' => 'Power adapter',
                'attributes' => [
                    'device_type' => 'power_adapter',
                    'label' => 'Power',
                    'energy' => 0,
                    'energy_daily' => 0,
                    'energy_total' => 0,
                ]
            ]
        ];
    }
}