<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Security\MagicRole;

use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Security\MagicRole\AbstractMagicRole;

class MagicRoleIsLanDevice extends AbstractMagicRole
{

    public function __construct(
        private VariablesProvider $variablesProvider
    )
    {
    }

    public function canHandle(string $roleName)
    {
        return $roleName === 'IS_LAN_DEVICE';
    }

    public function checkRole(RoleDTO $role): bool
    {
        return
            str_contains($this->getClientIp(), '127.0.0.1') ||
            str_contains($this->getClientIp(), '192.168.') ||
            $this->getClientIp() === $this->getApplicationWanIp();
    }

    private function getApplicationWanIp(): string
    {
        $application = $this->getApplication();
        if (empty($application)) return '';

        return $this->variablesProvider->getConstants($application->getId(), true)['wanIp'] ?? '';
    }
}