<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Security\Role;

use Cehlers88\AnalyticsCore\Security\Role\RoleInterface;

class IsLanDeviceRole implements RoleInterface
{
    public const NAME = 'IS_LAN_DEVICE';

    public function getName(): string
    {
        return self::NAME;
    }

    public function getDescription(): string
    {
        return 'Rolle für Geräte und Services im lokalen Netzwerk.';
    }

    public function isMagicRole(): bool
    {
        return true;
    }
}