<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Macro;


use Analytics\Presentation\Frontend\View\ClientView;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Cehlers88\AnalyticsInfrastructureBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\View\LanServiceView;
use Cehlers88\AnalyticsInfrastructureBundle\Repository\DeviceRepository;

class SendMqttCommandMacro extends AbstractInfrastructureMacro
{

    const PROPERTY_TOPIC = 'topic';
    const PROPERTY_COMMAND = 'command';

    public function __construct(
        private readonly AssemblerProvider     $assemblerProvider,
        private readonly ConfigurationProvider $configurationProvider,
        private readonly CustomObjectProvider  $customObjectProvider
    )
    {
    }

    public function _init(): SendMqttCommandMacro
    {
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TOPIC, 'string', 'Specify the topic to send the command to'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_COMMAND, 'string', 'Specify the command to send'));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Send MQTT command to MQTT-Broker.';
    }

    public function getName(): string
    {
        return 'sendMqttCommand';
    }

    protected function run(): ?array
    {
        $mqttGatewayId = $this->configurationProvider->getValue(
            GeneralConfigurationGroup::KEY,
            'mqttGateway'
        );

        if (empty($mqttGatewayId)) {
            return $this->_createRunResult('Fehler', ErrorDTO::create('No MQTT Gateway configured.'));
        }

        $mqttGateway = $this->customObjectProvider->getCustomObjectById($mqttGatewayId);
        if (empty($mqttGateway)) {
            throw new \Exception('MQTT Gateway not found');
        }
        /** @var LanServiceView $assembledGateway */
        $assembledGateway = $this->assemblerProvider->getAssemblerForClass($mqttGateway::class)
            ->one($mqttGateway);

        if(empty($assembledGateway->childObjects)) {
            throw new \Exception('No devices found in MQTT-Gateway(#'.$assembledGateway->id.'). Please create a device in the MQTT-Gateway and try again.');
        }

        $url = 'http://' . $assembledGateway->childObjects[$assembledGateway->childMap->client]->ip;
        $url .= ':' . $assembledGateway->attribute->frontend_port . '/api/command';
        $command = $this->getPropertyValue(self::PROPERTY_COMMAND);

        // post "command" to url using curl
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'topic' => $this->getPropertyValue(self::PROPERTY_TOPIC),
            'command' => $command,
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $output = curl_exec($ch);
        if ($output === false) {
            $error = curl_error($ch);
            curl_close($ch);
            return $this->_createRunResult($error);
        }
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        curl_close($ch);

        return $this->_createRunResult($output);
    }
}