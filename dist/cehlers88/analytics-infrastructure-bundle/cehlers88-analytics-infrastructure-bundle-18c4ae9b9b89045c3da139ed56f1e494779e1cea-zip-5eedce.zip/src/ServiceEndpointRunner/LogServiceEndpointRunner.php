<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;
use Cehlers88\AnalyticsInfrastructureBundle\Security\Role\IsLanDeviceRole;

class LogServiceEndpointRunner extends AbstractServiceEndpointRunner
{
    public function __construct()
    {
        $parameterMessage = PropertyDTO::create('message', 'Dies ist die Nachricht, die geloggt wird', 'string');
        $parameterMessage->description = 'Message to log';

        $parameterData = PropertyDTO::create('data', ['foo' => 'xyz'], 'mixed', true);
        $parameterData->description = 'Data to log';

        $parameterGroupKey = PropertyDTO::create('groupKey', 'x/y/z', 'string', true);
        $parameterGroupKey->description = 'Key to group log entries';

        $this->registerEndpoint(EndpointDefinitionDTO::create(
            'log',
            ['POST'],
            [
                $parameterMessage,
                $parameterData,
                $parameterGroupKey,
                PropertyDTO::create('level', 'unknown', 'info | warning | debug', true),
            ],
            [],
            'Endpunkt zum loggen von Nachrichten innerhalb des lokalen Netzwerks'
        ));

        $this->registerEndpoint(EndpointDefinitionDTO::create(
            'error',
            ['POST'],
            [
                PropertyDTO::create('number', -1, 'int'),
                $parameterMessage,
                $parameterData,
                $parameterGroupKey,
                PropertyDTO::create('level', 'unknown', 'warning | exception | fatal | unknown', true),
                PropertyDTO::create('priority', 1, 'int', true)
            ],
            [],
            'Endpunkt zum loggen von Fehlern innerhalb des lokalen Netzwerks'
        ));
    }


    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }

    public function getRequiredRoles(): array
    {
        return [
            RoleDTO::create(IsLanDeviceRole::NAME)
        ];
    }
}