<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;

/**
 * Serverseitiger Teil des WebSocket-Console Tools. Öffnet eine kurzlebige
 * WebSocket-Verbindung vom Server aus, sendet optional eine Nachricht und
 * sammelt die eintreffenden Nachrichten bis zum Timeout ein.
 *
 * Damit lassen sich Endpunkte prüfen, die der Browser nicht erreicht
 * (Mixed-Content bei ws:// auf einer https-Seite, fehlendes CORS, ...).
 * Eine dauerhafte Verbindung ist über den zustandslosen Endpunkt nicht
 * möglich, jeder Aufruf ist eine eigene Verbindung.
 */
class WebsocketProbeEndpointRunner extends AbstractServiceEndpointRunner
{
    public const DEFAULT_TIMEOUT = 5;
    public const CONNECT_TIMEOUT = 5;
    public const MAX_TIMEOUT = 30;
    /** Maximum size of a single incoming message in bytes (2 MB). */
    public const MAX_MESSAGE_SIZE = 2 * 1024 * 1024;
    /** Maximum number of collected messages per probe. */
    public const MAX_MESSAGES = 50;

    private const HANDSHAKE_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
    private const ALLOWED_SCHEMES = ['ws', 'wss'];
    private const FORMAT_BINARY = 'binary';

    private const OPCODE_CONTINUATION = 0x0;
    private const OPCODE_TEXT = 0x1;
    private const OPCODE_BINARY = 0x2;
    private const OPCODE_CLOSE = 0x8;
    private const OPCODE_PING = 0x9;
    private const OPCODE_PONG = 0xA;

    public function __construct()
    {
        $parameterUrl = PropertyDTO::create('url', 'wss://example.com/socket', 'string');
        $parameterUrl->description = 'Die anzufragende WebSocket-URL (ws oder wss)';

        $parameterMessage = PropertyDTO::create('message', null, 'string', true);
        $parameterMessage->description = 'Nachricht, die nach dem Verbindungsaufbau gesendet wird';

        $parameterFormat = PropertyDTO::create('format', 'text', 'text | binary', true);
        $parameterFormat->description = 'Art der gesendeten Nachricht. Bei \'' . self::FORMAT_BINARY
            . '\' wird die Nachricht als Hex-String erwartet und als Binary-Frame gesendet.';

        $parameterProtocols = PropertyDTO::create('protocols', [], 'array', true);
        $parameterProtocols->description = 'Liste der angebotenen Subprotokolle (Sec-WebSocket-Protocol)';

        $parameterHeaders = PropertyDTO::create('headers', [], 'array', true);
        $parameterHeaders->description = 'Zusätzliche Header des Handshakes, als Map oder als Liste aus name/value';

        $parameterTimeout = PropertyDTO::create('timeout', self::DEFAULT_TIMEOUT, 'int', true);
        $parameterTimeout->description = 'Zeit in Sekunden, die auf eintreffende Nachrichten gewartet wird';

        $endpoint = EndpointDefinitionDTO::create(
            'websocket_probe',
            ['POST'],
            [
                $parameterUrl,
                $parameterMessage,
                $parameterFormat,
                $parameterProtocols,
                $parameterHeaders,
                $parameterTimeout,
            ],
            [],
            'Endpunkt zum serverseitigen Öffnen einer WebSocket-Verbindung des WebSocket-Console Tools.',
            [$this, 'handleProbeRequest']
        );
        $endpoint->aliases = ['websocketProbe'];

        $this->registerEndpoint($endpoint);
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }

    public function getRequiredRoles(): array
    {
        return [
            RoleDTO::create('AUTHENTICATED_USER')
        ];
    }

    public function handleProbeRequest(array $requestData): ServiceEndpointRunnerResultDTO
    {
        $url = is_string($requestData['url'] ?? null) ? trim($requestData['url']) : '';
        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            return ServiceEndpointRunnerResultDTO::createError('Invalid url', 400);
        }

        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        if (!in_array($scheme, self::ALLOWED_SCHEMES, true)) {
            return ServiceEndpointRunnerResultDTO::createError(
                'Unsupported scheme \'' . $scheme . '\'. Allowed schemes: ' . implode(', ', self::ALLOWED_SCHEMES),
                400
            );
        }

        $host = (string)parse_url($url, PHP_URL_HOST);
        if ($host === '' || strtolower($host) === 'localhost') {
            return ServiceEndpointRunnerResultDTO::createError('Unsupported host', 400);
        }

        if (filter_var($host, FILTER_VALIDATE_IP) && !filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return ServiceEndpointRunnerResultDTO::createError('Refusing to access private or reserved IP ranges', 400);
        }

        $format = ($requestData['format'] ?? 'text') === self::FORMAT_BINARY ? self::FORMAT_BINARY : 'text';
        $message = $this->normalizeMessage($requestData['message'] ?? null, $format);

        if ($format === self::FORMAT_BINARY && is_null($message) && !is_null($requestData['message'] ?? null)) {
            return ServiceEndpointRunnerResultDTO::createError('The binary message is not a valid hex string', 400);
        }

        return ServiceEndpointRunnerResultDTO::createSuccess($this->runProbe(
            $url,
            $message,
            $format,
            $this->normalizeProtocols($requestData['protocols'] ?? []),
            $this->normalizeHandshakeHeaders($requestData['headers'] ?? []),
            min(max((int)($requestData['timeout'] ?? self::DEFAULT_TIMEOUT), 1), self::MAX_TIMEOUT)
        ));
    }

    /**
     * Binary messages are transferred as hex string, so they survive the JSON payload.
     */
    private function normalizeMessage(mixed $message, string $format): ?string
    {
        if (is_null($message) || $message === '') {
            return null;
        }

        // json_encode() gives up on malformed UTF-8, recursion and NAN/INF, and
        // its false would travel on as the message itself.
        $encoded = is_string($message) ? $message : json_encode($message);
        if ($encoded === false) {
            return null;
        }

        $message = $encoded;

        if ($format !== self::FORMAT_BINARY) {
            return $message;
        }

        $hexMessage = preg_replace('/\s+/', '', $message);
        if (!is_string($hexMessage) || $hexMessage === '' || !ctype_xdigit($hexMessage) || strlen($hexMessage) % 2 !== 0) {
            return null;
        }

        return hex2bin($hexMessage);
    }

    /**
     * @param array<int, string> $protocols
     * @param array<string, string> $headers
     */
    private function runProbe(
        string  $url,
        ?string $message,
        string  $format,
        array   $protocols,
        array   $headers,
        int     $timeout
    ): array
    {
        $startedAt = microtime(true);
        $result = [
            'url' => $url,
            'statusCode' => 0,
            'statusText' => '',
            'headers' => [],
            'protocol' => '',
            'messages' => [],
            'closeCode' => null,
            'closeReason' => '',
            'durationMs' => 0.0,
            'errorMessage' => null,
        ];

        $socket = $this->openSocket($url, $errorMessage);
        if (is_null($socket)) {
            $result['durationMs'] = $this->durationSince($startedAt);
            $result['errorMessage'] = $errorMessage;

            return $result;
        }

        try {
            $handshake = $this->runHandshake($socket, $url, $protocols, $headers);

            $result['statusCode'] = $handshake['statusCode'];
            $result['statusText'] = $handshake['statusText'];
            $result['headers'] = $handshake['headers'];
            $result['protocol'] = $handshake['protocol'];

            if (!is_null($handshake['errorMessage'])) {
                $result['durationMs'] = $this->durationSince($startedAt);
                $result['errorMessage'] = $handshake['errorMessage'];

                return $result;
            }

            if (!is_null($message)) {
                $opcode = $format === self::FORMAT_BINARY ? self::OPCODE_BINARY : self::OPCODE_TEXT;
                fwrite($socket, $this->buildFrame($message, $opcode));
            }

            $collected = $this->collectMessages($socket, $startedAt, $timeout);
            $result['messages'] = $collected['messages'];
            $result['closeCode'] = $collected['closeCode'];
            $result['closeReason'] = $collected['closeReason'];
            $result['errorMessage'] = $collected['errorMessage'];

            if (is_null($collected['closeCode'])) {
                // 1000 = normal closure
                fwrite($socket, $this->buildFrame(pack('n', 1000), self::OPCODE_CLOSE));
            }
        } finally {
            fclose($socket);
        }

        $result['durationMs'] = $this->durationSince($startedAt);

        return $result;
    }

    /**
     * @param resource|null $socket
     */
    private function openSocket(string $url, ?string &$errorMessage)
    {
        $isSecure = strtolower((string)parse_url($url, PHP_URL_SCHEME)) === 'wss';
        $host = (string)parse_url($url, PHP_URL_HOST);
        $port = (int)(parse_url($url, PHP_URL_PORT) ?: ($isSecure ? 443 : 80));
        $address = ($isSecure ? 'ssl://' : 'tcp://') . $host . ':' . $port;

        $context = stream_context_create($isSecure ? ['ssl' => ['SNI_enabled' => true, 'peer_name' => $host, 'verify_peer' => true, 'verify_peer_name' => true]] : []);
        $socket = @stream_socket_client(
            $address,
            $errorNumber,
            $errorText,
            self::CONNECT_TIMEOUT,
            STREAM_CLIENT_CONNECT,
            $context
        );

        if ($socket === false) {
            $errorMessage = 'Unable to connect to ' . $address . ($errorText !== '' ? ': ' . $errorText : '');

            return null;
        }

        stream_set_timeout($socket, self::CONNECT_TIMEOUT);
        $errorMessage = null;

        return $socket;
    }

    private function durationSince(float $startedAt): float
    {
        return round((microtime(true) - $startedAt) * 1000, 2);
    }

    /**
     * @param resource $socket
     * @param array<int, string> $protocols
     * @param array<string, string> $headers
     *
     * @return array{statusCode: int, statusText: string, headers: array<int, array{name: string, value: string}>, protocol: string, errorMessage: string|null}
     */
    private function runHandshake($socket, string $url, array $protocols, array $headers): array
    {
        $handshakeKey = base64_encode(random_bytes(16));
        $host = (string)parse_url($url, PHP_URL_HOST);
        $port = parse_url($url, PHP_URL_PORT);
        $path = (string)(parse_url($url, PHP_URL_PATH) ?: '/');
        $query = (string)parse_url($url, PHP_URL_QUERY);

        $requestLines = [
            'GET ' . $path . ($query !== '' ? '?' . $query : '') . ' HTTP/1.1',
            'Host: ' . $host . ($port ? ':' . $port : ''),
            'Upgrade: websocket',
            'Connection: Upgrade',
            'Sec-WebSocket-Key: ' . $handshakeKey,
            'Sec-WebSocket-Version: 13',
        ];

        if ($protocols !== []) {
            $requestLines[] = 'Sec-WebSocket-Protocol: ' . implode(', ', $protocols);
        }

        foreach ($headers as $name => $value) {
            $requestLines[] = $name . ': ' . $value;
        }

        fwrite($socket, implode("\r\n", $requestLines) . "\r\n\r\n");

        $statusCode = 0;
        $statusText = '';
        $responseHeaders = [];

        while (($line = fgets($socket)) !== false) {
            $line = trim($line);

            if ($line === '') {
                break;
            }

            if (str_starts_with($line, 'HTTP/')) {
                $statusLineParts = explode(' ', $line, 3);
                $statusCode = (int)($statusLineParts[1] ?? 0);
                $statusText = $statusLineParts[2] ?? '';
            } elseif (str_contains($line, ':')) {
                [$name, $value] = explode(':', $line, 2);
                $responseHeaders[] = ['name' => trim($name), 'value' => trim($value)];
            }
        }

        $handshake = [
            'statusCode' => $statusCode,
            'statusText' => $statusText,
            'headers' => $responseHeaders,
            'protocol' => $this->findHeaderValue($responseHeaders, 'Sec-WebSocket-Protocol'),
            'errorMessage' => null,
        ];

        if ($statusCode !== 101) {
            $handshake['errorMessage'] = $statusCode === 0
                ? 'The endpoint did not answer the handshake.'
                : 'The endpoint refused the upgrade and answered with ' . $statusCode . ' ' . $statusText . '.';

            return $handshake;
        }

        $expectedAccept = base64_encode(sha1($handshakeKey . self::HANDSHAKE_GUID, true));
        if ($this->findHeaderValue($responseHeaders, 'Sec-WebSocket-Accept') !== $expectedAccept) {
            $handshake['errorMessage'] = 'The endpoint answered with an invalid Sec-WebSocket-Accept header.';
        }

        return $handshake;
    }

    /**
     * @param array<int, array{name: string, value: string}> $headers
     */
    private function findHeaderValue(array $headers, string $name): string
    {
        $searchedName = strtolower($name);

        foreach ($headers as $header) {
            if (strtolower($header['name']) === $searchedName) {
                return $header['value'];
            }
        }

        return '';
    }

    private function buildFrame(string $payload, int $opcode): string
    {
        $payloadLength = strlen($payload);
        $mask = random_bytes(4);
        $frame = chr(0x80 | $opcode);

        if ($payloadLength < 126) {
            $frame .= chr(0x80 | $payloadLength);
        } elseif ($payloadLength < 65536) {
            $frame .= chr(0x80 | 126) . pack('n', $payloadLength);
        } else {
            $frame .= chr(0x80 | 127) . pack(
                'N2',
                ($payloadLength >> 32) & 0xFFFFFFFF,
                $payloadLength & 0xFFFFFFFF
            );
        }

        return $frame . $mask . $this->applyMask($payload, $mask);
    }

    private function applyMask(string $payload, string $mask): string
    {
        $payloadLength = strlen($payload);
        if ($payloadLength === 0) {
            return '';
        }

        return $payload ^ substr(str_repeat($mask, intdiv($payloadLength, 4) + 1), 0, $payloadLength);
    }

    /**
     * Reads incoming frames until the timeout is reached, the connection is
     * closed or too many messages were collected.
     *
     * @param resource $socket
     *
     * @return array{messages: array<int, array{type: string, body: string, size: int, offsetMs: float}>, closeCode: int|null, closeReason: string, errorMessage: string|null}
     */
    private function collectMessages($socket, float $startedAt, int $timeout): array
    {
        $deadline = microtime(true) + $timeout;
        $messages = [];
        $closeCode = null;
        $closeReason = '';
        $errorMessage = null;
        $fragments = '';
        $fragmentOpcode = null;

        while (count($messages) < self::MAX_MESSAGES) {
            $remainingSeconds = $deadline - microtime(true);
            if ($remainingSeconds <= 0) {
                break;
            }

            $readStreams = [$socket];
            $writeStreams = [];
            $exceptStreams = [];
            $selected = @stream_select(
                $readStreams,
                $writeStreams,
                $exceptStreams,
                (int)$remainingSeconds,
                (int)(fmod($remainingSeconds, 1) * 1000000)
            );

            if ($selected === false) {
                $errorMessage = 'Reading from the connection failed.';
                break;
            }

            if ($selected === 0) {
                break;
            }

            $frame = $this->readFrame($socket, $deadline, $errorMessage);
            if (is_null($frame)) {
                break;
            }

            if ($frame['opcode'] === self::OPCODE_PING) {
                fwrite($socket, $this->buildFrame($frame['payload'], self::OPCODE_PONG));
                continue;
            }

            if ($frame['opcode'] === self::OPCODE_PONG) {
                continue;
            }

            if ($frame['opcode'] === self::OPCODE_CLOSE) {
                if (strlen($frame['payload']) >= 2) {
                    $closeCode = unpack('n', substr($frame['payload'], 0, 2))[1];
                    $closeReason = substr($frame['payload'], 2);
                } else {
                    $closeCode = 1005;
                }
                break;
            }

            if ($frame['opcode'] === self::OPCODE_CONTINUATION) {
                if (is_null($fragmentOpcode)) {
                    // a continuation without a start frame, there is nothing to append to
                    continue;
                }
                $fragments .= $frame['payload'];
            } else {
                $fragments = $frame['payload'];
                $fragmentOpcode = $frame['opcode'];
            }

            // Every single frame is checked against the limit while it is read,
            // but a message split across frames could pass that check over and
            // over and still add up to more than we are willing to hold.
            if (strlen($fragments) > self::MAX_MESSAGE_SIZE) {
                $errorMessage = sprintf(
                    'Message aborted: payload exceeded the maximum allowed size of %d bytes.',
                    self::MAX_MESSAGE_SIZE
                );
                break;
            }

            if (!$frame['isFinal']) {
                continue;
            }

            $isBinary = $fragmentOpcode === self::OPCODE_BINARY;
            $messages[] = [
                'type' => $isBinary ? 'Binary' : 'Text',
                'body' => $isBinary ? bin2hex($fragments) : $fragments,
                'size' => strlen($fragments),
                'offsetMs' => $this->durationSince($startedAt),
            ];

            $fragments = '';
            $fragmentOpcode = null;
        }

        return [
            'messages' => $messages,
            'closeCode' => $closeCode,
            'closeReason' => $closeReason,
            'errorMessage' => $errorMessage,
        ];
    }

    /**
     * @param resource $socket
     *
     * @return array{isFinal: bool, opcode: int, payload: string}|null
     */
    private function readFrame($socket, float $deadline, ?string &$errorMessage): ?array
    {
        $header = $this->readBytes($socket, 2, $deadline);
        if (is_null($header)) {
            return null;
        }

        $firstByte = ord($header[0]);
        $secondByte = ord($header[1]);
        $isMasked = ($secondByte & 0x80) === 0x80;
        $payloadLength = $secondByte & 0x7F;

        if ($payloadLength === 126) {
            $extendedLength = $this->readBytes($socket, 2, $deadline);
            if (is_null($extendedLength)) {
                return null;
            }
            $payloadLength = unpack('n', $extendedLength)[1];
        } elseif ($payloadLength === 127) {
            $extendedLength = $this->readBytes($socket, 8, $deadline);
            if (is_null($extendedLength)) {
                return null;
            }
            $lengthParts = unpack('N2', $extendedLength);
            $payloadLength = ($lengthParts[1] << 32) + $lengthParts[2];
        }

        if ($payloadLength > self::MAX_MESSAGE_SIZE) {
            $errorMessage = sprintf(
                'Message aborted: a frame exceeded the maximum allowed size of %d bytes.',
                self::MAX_MESSAGE_SIZE
            );

            return null;
        }

        $mask = '';
        if ($isMasked) {
            $mask = $this->readBytes($socket, 4, $deadline);
            if (is_null($mask)) {
                return null;
            }
        }

        $payload = $payloadLength > 0 ? $this->readBytes($socket, $payloadLength, $deadline) : '';
        if (is_null($payload)) {
            return null;
        }

        return [
            'isFinal' => ($firstByte & 0x80) === 0x80,
            'opcode' => $firstByte & 0x0F,
            'payload' => $isMasked ? $this->applyMask($payload, $mask) : $payload,
        ];
    }

    /**
     * @param resource $socket
     */
    private function readBytes($socket, int $length, float $deadline): ?string
    {
        $buffer = '';

        while (strlen($buffer) < $length) {
            $remainingSeconds = $deadline - microtime(true);
            if ($remainingSeconds <= 0 || feof($socket)) {
                return null;
            }

            stream_set_timeout($socket, max((int)$remainingSeconds, 1));
            $chunk = fread($socket, $length - strlen($buffer));

            if ($chunk === false || $chunk === '') {
                return null;
            }

            $buffer .= $chunk;
        }

        return $buffer;
    }

    /**
     * @return array<int, string>
     */
    private function normalizeProtocols(mixed $protocols): array
    {
        if (is_string($protocols)) {
            $protocols = explode(',', $protocols);
        }

        if (!is_array($protocols)) {
            return [];
        }

        $normalizedProtocols = [];
        foreach ($protocols as $protocol) {
            if (!is_scalar($protocol)) {
                continue;
            }

            $protocol = trim((string)$protocol);
            if ($protocol !== '' && preg_match('/^[!#$%&\'*+\-.^_`|~0-9A-Za-z]+$/', $protocol)) {
                $normalizedProtocols[] = $protocol;
            }
        }

        return $normalizedProtocols;
    }

    /**
     * Accepts headers as map (name => value) as well as list of ['name' => ..., 'value' => ...].
     * The headers of the handshake itself cannot be overwritten.
     *
     * @return array<string, string>
     */
    private function normalizeHandshakeHeaders(mixed $headers): array
    {
        if (!is_array($headers)) {
            return [];
        }

        $reservedHeaders = ['host', 'upgrade', 'connection', 'sec-websocket-key', 'sec-websocket-version', 'sec-websocket-protocol'];
        $normalizedHeaders = [];

        foreach ($headers as $key => $header) {
            if (is_array($header)) {
                $name = (string)($header['name'] ?? '');
                $value = (string)($header['value'] ?? '');
            } else {
                $name = (string)$key;
                $value = is_scalar($header) ? (string)$header : (string)json_encode($header);
            }

            $name = trim($name);

            if ($name === '' || str_contains($name, ':') || preg_match('/[\r\n]/', $name) || preg_match('/[\r\n]/', $value)) {
                continue;
            }

            if (in_array(strtolower($name), $reservedHeaders, true)) {
                continue;
            }

            $normalizedHeaders[$name] = trim($value);
        }

        return $normalizedHeaders;
    }
}
