<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\DTO\ExtendedRoleDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\Entity\ClientDetails;
use Cehlers88\AnalyticsCore\Recorder\TrackingRecorder;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use Cehlers88\AnalyticsCore\Security\Role\AdminRole;
use Cehlers88\AnalyticsCore\Security\Role\IsClientRole;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;
use Cehlers88\AnalyticsInfrastructureBundle\Configuration\GeneralConfigurationGroup;
use Symfony\Component\HttpFoundation\Request;

class HandleClientUpdateServiceEndpointRunner extends AbstractServiceEndpointRunner
{

    public function __construct(
        private TrackingRecorder      $trackingRecorder,
        private ClientRepository      $clientRepository,
        private ConfigurationProvider $configurationProvider
    )
    {
    }

    public function getEndpoints(): mixed
    {
        return [
            EndpointDefinitionDTO::create("handle_client_update", ['POST'], [], [
                ExtendedRoleDTO::createAnyOf(
                    RoleDTO::create(AdminRole::NAME),
                    RoleDTO::create(IsClientRole::NAME . '2')
                )
            ], '', [$this, 'handlePostRequest'])
        ];
    }

    public function handlePostRequest(array $requestData): ServiceEndpointRunnerResultDTO
    {
        $trackRequest = true;

        switch ($requestData['event']) {
            case 'cast_device_update':
                $snapshot = $requestData['snapshot'];

                $client = $this->clientRepository->getByIp($snapshot['host']);
                if (empty($client)) {
                    return ServiceEndpointRunnerResultDTO::createError('Client not found', 504);
                }
                $castInfo = $client->getClientDetailsByTag('cast_info');
                if (is_null($castInfo)) {
                    $castInfo = new ClientDetails();
                    $castInfo->setTag('cast_info');
                    $castInfoExist = false;
                } else {
                    $castInfoExist = true;
                }

                $currentCastInfo = json_decode($castInfo->getInfos() ?? '[]', true);

                if (!array_key_exists('title', $snapshot)) {
                    if (
                        isset($snapshot['playerState']) &&
                        $snapshot['playerState'] === 'BUFFERING'
                    ) {
                        $trackRequest = false;
                    }
                    $snapshot['title'] = '';
                }

                if ($trackRequest && $currentCastInfo['title'] === $snapshot['title']) {
                    $trackRequest = false;
                }

                $castInfo->setInfos(json_encode($snapshot));

                if (!$castInfoExist) {
                    $client->addClientDetail($castInfo);
                }
                $this->clientRepository->save($client);


                break;
        }

        if ($trackRequest) {
            $this->trackingRecorder->track(
                $this->getCastsApplicationId(), [
                    'data' => $requestData,
                    'key' => 'CLIENT_UPDATE'
                ]
            );
        }

        return ServiceEndpointRunnerResultDTO::createSuccess($requestData, 'Client-Update-Handler');
    }

    private function getCastsApplicationId(): int
    {
        return (int)$this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'castsApplicationId');
    }

    public function getRequiredRoles(): array
    {
        return [];
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }
}