<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ViewInterface;

/** View representation of an Application entity. */
class SmartDeviceView extends CustomObjectView implements ViewInterface
{
    public function __construct(int $id, string $className, string $name, array $attributes, array $childObjects)
    {
        parent::__construct($id, $className, $name, $attributes, $childObjects);
    }

    public function getUserInteractions(): array
    {
        $interactions = parent::getUserInteractions();

        if (!isset($this->attribute->device_type)) {
            $interactions[] = [
                'subject' => 'Missing device type',
                'level' => 'error',
                'message' => 'You have to specify a device type for this device.',
                'formFields' => [
                    'deviceType' => [
                        'label' => 'Device type',
                        'type' => 'select',
                        'options' => [
                            'environment' => 'Environment',
                            'plotter_2d' => 'Plotter 2D',
                            'power_adapter' => 'Power adapter',
                            'sensor' => 'Sensor',
                        ]
                    ]
                ],
                'actions' => [
                    [
                        'label' => 'Save',
                        'function' => 'set_custom_entity_attributes',
                        'functionArguments' => [
                            'device_type' => ['source' => 'formField', 'sourceDetails' => 'Device type'],
                            'entityId' => $this->id
                        ]
                    ]
                ]
            ];
        } else {
            if (isset($this->attribute->software_version)) {
                switch ($this->attribute->software_version) {
                    case '14.1.0':
                        $interactions[] = [
                            'subject' => 'Update necessary!',
                            'level' => 'warning',
                            'message' => 'This version has some problems. Please update now the device firmware!',
                        ];
                }
            }
            if (!isset($this->attribute->topic) && !($this->config['ignoreMissingTopic'] ?? false)) {
                $interactions[] = [
                    'subject' => 'Topic not defined',
                    'level' => 'warning',
                    'message' => 'For this device is no topic defined. Specify a topic to receive data from this device.',
                    'formFields' => [
                        'topic' => [
                            'label' => 'Topic',
                            'type' => 'text',
                        ]
                    ],
                    'actions' => [
                        [
                            'label' => 'Not necessary',
                            'function' => 'set_custom_entity_config',
                            'functionArguments' => [
                                'entityId' => $this->id,
                                'configs' => [
                                    'ignoreMissingTopic' => true
                                ]
                            ]
                        ],
                        [
                            'label' => 'Save',
                            'function' => 'set_custom_entity_attributes',
                            'functionArguments' => [
                                'topic' => ['source' => 'formField', 'sourceDetails' => 'Topic'],
                                'entityId' => $this->id
                            ]
                        ]
                    ]
                ];
            }
        }

        return $interactions;
    }
}