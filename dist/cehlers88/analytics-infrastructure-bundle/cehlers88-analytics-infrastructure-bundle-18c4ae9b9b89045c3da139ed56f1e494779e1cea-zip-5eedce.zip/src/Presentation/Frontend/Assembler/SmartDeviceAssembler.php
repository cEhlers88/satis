<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectAttributeJson;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\CustomObjectAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDevice;
use Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\View\SmartDeviceView;

class SmartDeviceAssembler extends CustomObjectAssembler
{
    protected string $viewClass = SmartDeviceView::class;

    public function canHandle(string $className): bool
    {
        return $className === SmartDevice::class;
    }

    protected function enrichView(EntityInterface|AbstractCustomObject $entity, CustomObjectView $view): CustomObjectView
    {
        /** @var CustomObjectAttributeJson $attribute */
        foreach ($view->attributes as $attribute) {
            if ($attribute->name === 'software_version') {
                $view->titleBadgeText = $attribute->value;
            }
            if (str_ends_with($attribute->name, 'adapter_id')) {
                $id = $attribute->value;
                if (empty($id)) {
                    continue;
                }
                $childObject = $this->customObjectProvider->getCustomObjectById($id);
                if (empty($childObject)) {
                    continue;
                }
                $view->childMap->{$attribute->name} = count($view->childObjects);
                $view->childObjects[] = $this->assembleView($childObject);
            }
        }

        return $view;
    }
}