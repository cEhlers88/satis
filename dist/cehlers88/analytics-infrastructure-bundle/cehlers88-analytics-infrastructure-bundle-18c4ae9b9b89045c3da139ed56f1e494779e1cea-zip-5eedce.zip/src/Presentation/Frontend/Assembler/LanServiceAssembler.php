<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\CustomEntityAttributeMonitoring;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\CustomObjectAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ViewInterface;
use Cehlers88\AnalyticsCore\Presentation\Service\AssemblerProvider;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use Cehlers88\AnalyticsInfrastructureBundle\CustomObject\LanService;
use Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDevice;
use Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\View\LanServiceView;
use Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\View\SmartDeviceView;

class LanServiceAssembler extends CustomObjectAssembler
{
    protected string $viewClass = LanServiceView::class;

    public function canHandle(string $className): bool
    {
        return $className === LanService::class;
    }

    /**
     * @param LanService|AbstractCustomObject $entity
     * @param CustomObjectView $view
     * @return LanServiceView
     */
    protected function enrichView(EntityInterface|AbstractCustomObject $entity, CustomObjectView $view): CustomObjectView
    {
        $view->titlePrefix = $entity->getState() ? '&#128994;' : '&#128308;';
        return $view;
    }
}