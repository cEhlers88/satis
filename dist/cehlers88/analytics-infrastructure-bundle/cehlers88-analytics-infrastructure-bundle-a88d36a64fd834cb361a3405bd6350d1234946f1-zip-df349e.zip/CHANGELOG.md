# Changelog

## [0.1.4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.3...v0.1.4) (2026-01-21)


### Miscellaneous Chores

* add GitHub workflow to trigger Satis rebuild on release ([7f77f56](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/7f77f56f68fe25a212e0c14c0a5f15bd57cceb29))
* **deps:** update dependency cehlers88/analytics-core to v0.1.5 ([#4](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/4)) ([2270bbe](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/2270bbe68cc3c63a598a8b579dc7d8e0f907a1f1))

## [0.1.3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.2...v0.1.3) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([#2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/issues/2)) ([605516c](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/605516c331d6857b814273f0adbe6333c8a26f5e)) ([3da16e3](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/3da16e312e59b09de63dd1a0d3c1c226407ce307))
## [0.1.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([a367bbd](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a367bbd335655fe509fe8c3f83609ac53da0520a))
