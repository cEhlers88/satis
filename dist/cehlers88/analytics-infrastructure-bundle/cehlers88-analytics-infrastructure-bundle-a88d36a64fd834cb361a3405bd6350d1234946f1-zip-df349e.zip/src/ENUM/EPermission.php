<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 12:00
 */

namespace Cehlers88\AnalyticsInfrastructureBundle\ENUM;

enum EPermission : string {
    case ACCESS_INFRASTRUCTURE = 'ACCESS_INFRASTRUCTURE';

    public static function getPermissions():array {
        return [
            self::ACCESS_INFRASTRUCTURE->value,
        ];
    }
}