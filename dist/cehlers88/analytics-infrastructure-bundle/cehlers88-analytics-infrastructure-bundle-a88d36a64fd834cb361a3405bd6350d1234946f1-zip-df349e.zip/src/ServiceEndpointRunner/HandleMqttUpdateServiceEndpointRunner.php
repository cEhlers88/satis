<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 06.09.2024
 * Time: 03:51
 */

namespace Cehlers88\AnalyticsInfrastructureBundle\ServiceEndpointRunner;

use Analytics\Recorder\TrackingRecorder;
use Analytics\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\Entity\Client;
use Cehlers88\AnalyticsCore\Entity\ClientDetails;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\ClientRepository;
use Cehlers88\AnalyticsInfrastructureBundle\AnalyticsInfrastructureBundle;
use Cehlers88\AnalyticsInfrastructureBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsInfrastructureBundle\Entity\Device;
use Cehlers88\AnalyticsInfrastructureBundle\ENUM\eDeviceState;
use Cehlers88\AnalyticsInfrastructureBundle\ENUM\eDeviceType;
use Cehlers88\AnalyticsInfrastructureBundle\Repository\DeviceRepository;
use Symfony\Component\HttpFoundation\Request;

class HandleMqttUpdateServiceEndpointRunner extends AbstractServiceEndpointRunner
{
    public function __construct(
        private ApplicationRepository $applicationRepository,
        private ClientRepository      $clientRepository,
        private DeviceRepository      $deviceRepository,
        private TrackingRecorder      $trackingRecorder,
        private ConfigurationProvider $configurationProvider
    )
    {
    }

    public function handleRequest(Request $request): mixed
    {
        if (!$this->validate()) {
            return ['error'];
        }

        $mqttApplication = $this->applicationRepository->find($this->getMqttApplicationId());
        $devices = json_decode($request->get('devices', '[]'), true);
        $deviceTrackInfos = [];

        foreach ($devices as $device) {
            unset($device['quickInfo']);
            if ($device['stats']) {
                $client = null;
                if (array_key_exists('ip', $device['stats']) && $device['stats']['ip'] !== '') {
                    $client = $this->clientRepository->getByIp($device['stats']['ip']);
                }

                if (!$client) {
                    if (array_key_exists('mac', $device['stats'])) {
                        $client = $this->clientRepository->getByMac($device['stats']['mac']);
                    }
                }

                if (!$client) {
                    $client = new Client();
                    $client->setFirstVisit(new \DateTime());
                }

                $client
                    ->setIp(array_key_exists('ip', $device['stats']) ? $device['stats']['ip'] : 'X.X.X.X')
                    ->setMac(array_key_exists('mac', $device['stats']) ? $device['stats']['mac'] : null)
                    ->setHostname(array_key_exists('hn', $device['stats']) ? $device['stats']['hn'] : null);
                if ($client->getIp() !== 'X.X.X.X' || $client->getMac() !== null || $client->getHostname() !== null) {
                    $mqttDetails = null;
                    $generalDetails = null;
                    $generalDetailsData = [
                        'service_urls' => []
                    ];

                    foreach ($client->getClientDetails() as $clientDetail) {
                        if ($clientDetail->getTag() === 'mqtt_device') {
                            $mqttDetails = $clientDetail;
                        }
                        if ($clientDetail->getTag() === 'general') {
                            $generalDetails = $clientDetail;
                        }
                    }

                    if (is_null($mqttDetails)) {
                        $mqttDetails = new ClientDetails();
                        $mqttDetails
                            ->setTag('mqtt_device');
                        $client->addClientDetail($mqttDetails);
                    }
                    if (is_null($generalDetails)) {
                        $generalDetails = new ClientDetails();
                        $generalDetails
                            ->setTag('general');
                        $client->addClientDetail($generalDetails);
                    }

                    $mqttDetails->setInfos(json_encode($device['stats']));

                    $generalDetails->setInfos(json_encode($generalDetailsData));

                    $this->clientRepository->add($client);
                    $device['analyticsClientId'] = $client->getId();

                    $this->_updateDeviceInfos($client, $device['stats']);
                }
            }
            $deviceTrackInfos[] = $device;
        }

        if (count($deviceTrackInfos) > 0) {
            $this->trackingRecorder->track($mqttApplication, [
                "device_infos" => $deviceTrackInfos,
                "key" => "MQTT_TRACKING"
            ]);
        }

        return ["ok"];
    }

    public function validate(): bool
    {
        if ($this->getMqttApplicationId() > 0) {
            return true;
        }
        $this->setError('No valid application id configured for mqtt application.');
        return false;
    }

    private function getMqttApplicationId(): int
    {
        return (int)$this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'mqttApplicationId');
    }

    private function _updateDeviceInfos(Client $client, array $clientStats)
    {
        $deviceEntity = $this->deviceRepository->findOneBy(['client' => $client]);
        if ($deviceEntity === null) {
            $deviceEntity = new Device();
            $deviceEntity->setClient($client);
        }
        $deviceEntity
            ->setState($clientStats['online'] === 1 ? eDeviceState::ONLINE : eDeviceState::OFFLINE)
            ->setType(eDeviceType::SMART_SENSOR);

        $this->deviceRepository->add($deviceEntity);
    }

    public function getDescription(): string
    {
        return 'Dieser Endpunkt wird aufgerufen, wenn ein neues MQTT-Update-Request empfangen wird.';
    }

    public function getEndpoint(): string
    {
        return "handle_mqtt_update";
    }

    public function getBundleName(): string
    {
        return AnalyticsInfrastructureBundle::getBundleName();
    }
}