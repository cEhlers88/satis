<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 30.05.2024
 * Time: 17:52
 */

namespace Cehlers88\AnalyticsInfrastructureBundle\ENUM;

enum eDeviceState : int
{
    case UNKNOWN = 0;
    case OFFLINE = 1;
    case ONLINE = 2;
    case ERROR = 3;

    public static function getLabel(eDeviceState $state): string
    {
        return match ($state) {
            self::UNKNOWN => 'Unknown',
            self::OFFLINE => 'Offline',
            self::ONLINE => 'Online',
            self::ERROR => 'Error',
            default => 'Unknown'
        };
    }
}
