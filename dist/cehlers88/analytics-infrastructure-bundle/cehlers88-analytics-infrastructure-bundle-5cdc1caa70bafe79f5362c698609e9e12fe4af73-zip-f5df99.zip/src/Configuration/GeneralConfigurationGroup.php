<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 12:03
 */

namespace Cehlers88\AnalyticsInfrastructureBundle\Configuration;

use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;

class GeneralConfigurationGroup extends AbstractConfigurationGroup
{
    public const string KEY = 'infrastructureBundle.general';

    public function __construct(
        private ApplicationRepository $applicationRepository
    )
    {
    }

    public function getItems(): array
    {
        $applicationSelect = ConfigurationItemDTO::create('mqttApplicationId', 'MQTT Application', eInputType::SELECT);
        $applicationSelect->children = $this->getApplicationOptions();

        return [
            $applicationSelect,
            ConfigurationItemDTO::createRepeat('networkBridges', 'Network bridges', [
                ConfigurationItemDTO::create('name', 'Name', eInputType::TEXT_SINGLE_LINE, 'Bridge name'),
                ConfigurationItemDTO::create('address', 'Address', eInputType::TEXT_SINGLE_LINE, 'x/y=123')
            ], 'Netzwerkbrücken dienen als Gateway zwischen zwei Netzwerken. Über eine Netzwerkbrücke können Geräte in einem Netzwerk erreicht werden, die sich ausserhalb des eigenen Netzwerkes befinden.'),
        ];
    }

    private function getApplicationOptions(): array
    {
        $result = [['label' => 'None', 'value' => '']];
        array_map(function ($application) use (&$result) {
            $result[] = ['value' => $application->getId(), 'label' => $application->getName()];
        }, $this->applicationRepository->findAll());
        return $result;
    }

    public function getGroupTitle(): string
    {
        return 'Allgemeine Infrastruktureinstellungen';
    }

    public function getGroupDescription(): string
    {
        return 'Allgemeine Einstellungen für das Infrastrukturmodul';
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}