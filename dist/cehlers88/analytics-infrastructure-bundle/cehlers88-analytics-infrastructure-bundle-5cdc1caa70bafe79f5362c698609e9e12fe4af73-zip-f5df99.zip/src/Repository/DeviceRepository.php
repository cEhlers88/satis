<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Repository;

use Cehlers88\AnalyticsInfrastructureBundle\Entity\Device;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Device>
 */
class DeviceRepository extends ServiceEntityRepository {
    public function __construct(
        ManagerRegistry $registry,
        private EntityManagerInterface $_em
    ) {
        parent::__construct($registry, Device::class);
    }

    public function add(Device $device): DeviceRepository {
        $this->_em->persist($device);
        $this->_em->flush();
        return $this;
    }
}
