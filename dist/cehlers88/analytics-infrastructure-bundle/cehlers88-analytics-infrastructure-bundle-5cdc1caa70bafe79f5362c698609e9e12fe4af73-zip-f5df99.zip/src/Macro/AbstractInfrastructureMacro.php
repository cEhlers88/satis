<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 19:34
 */

namespace Cehlers88\AnalyticsInfrastructureBundle\Macro;

use Analytics\Macro\AbstractMacro;

abstract class AbstractInfrastructureMacro extends AbstractMacro {
    abstract protected function _init():AbstractInfrastructureMacro;
    public function init():AbstractInfrastructureMacro {
        $this->_source = "InfrastructureBundle";
        return $this->_init();
    }
}