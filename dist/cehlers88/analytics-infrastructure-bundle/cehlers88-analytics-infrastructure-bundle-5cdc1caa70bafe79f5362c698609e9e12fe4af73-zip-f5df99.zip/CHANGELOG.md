# Changelog

## [0.1.2](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([a367bbd](https://github.com/cEhlers88/AnalyticsInfrastructureBundle/commit/a367bbd335655fe509fe8c3f83609ac53da0520a))
