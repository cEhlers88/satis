<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDeviceType;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;

class EnvironmentDevice
{
    public function getAttributes(): array
    {
        $attrEnvironment = PropertyDTO::create(
            'environment_type',
            'divers',
        );

        return [];
    }

    public function getAvailableEnvironmentTypes(): array
    {
        return [
            'plotter_2d',
            'plotter_3d',
            'divers'
        ];
    }
}