<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDeviceType;

class SensorDevice
{

}