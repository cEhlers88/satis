<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\Security\MagicRole;

use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\Security\MagicRole\MagicRoleInterface;
use Symfony\Component\Security\Core\User\UserInterface;

class MagicRoleIsLanDevice implements MagicRoleInterface
{
    private ?string $clientIp = null;

    public function canHandle(string $roleName)
    {
        return $roleName === 'IS_LAN_DEVICE';
    }

    public function setRoleResolver(callable $roleResolver): MagicRoleInterface
    {
        return $this;
    }

    public function checkRole(RoleDTO $role): bool
    {
        return str_contains($this->clientIp, '127.0.0.1') || str_contains($this->clientIp, '192.168.');
    }

    public function setUser(?UserInterface $user): MagicRoleInterface
    {
        return $this;
    }

    public function setClientIp(?string $ip): MagicRoleInterface
    {
        $this->clientIp = $ip;
        return $this;
    }
}