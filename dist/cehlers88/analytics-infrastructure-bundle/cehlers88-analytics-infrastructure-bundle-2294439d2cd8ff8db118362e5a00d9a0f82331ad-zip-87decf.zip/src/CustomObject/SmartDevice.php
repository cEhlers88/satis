<?php

namespace Cehlers88\AnalyticsInfrastructureBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

class SmartDevice extends AbstractCustomObject
{

}