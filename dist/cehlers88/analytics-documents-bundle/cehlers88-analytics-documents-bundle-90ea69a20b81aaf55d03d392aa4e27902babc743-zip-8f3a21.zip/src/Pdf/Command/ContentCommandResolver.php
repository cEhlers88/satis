<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Command;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\Column;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\ContentRow;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\DocumentContent;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\HeadingColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\ReportColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TableColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TextColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Report\ReportHtmlWriter;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Report\SubReportProviderInterface;

/**
 * Turns a DocumentContent whose columns hold commands into one of plain text: every command
 * column is replaced by the same column with what its commands answered. The rows are
 * resolved top to bottom, so a command can use a variable an earlier one set.
 *
 * Report columns are rendered here as well - by the application (SubReportProviderInterface),
 * in the same order and environment, on their own source or on what their commands answer.
 */
class ContentCommandResolver
{
    public function __construct(
        private readonly CommandResolver             $commandResolver,
        /** null: the application offers no reports */
        private readonly ?SubReportProviderInterface $subReports = null,
    )
    {
    }

    public function resolve(DocumentContent $content): DocumentContent
    {
        $rows = [];
        foreach ($content->rows as $rowIndex => $row) {
            $columns = [];
            foreach ($row->columns as $columnIndex => $column) {
                $where = count($row->columns) > 1
                    ? sprintf('Zeile %d, Spalte %d:', $rowIndex + 1, $columnIndex + 1)
                    : sprintf('Zeile %d:', $rowIndex + 1);
                $columns[] = match (true) {
                    $column instanceof ReportColumn => $this->renderReport($column, $where),
                    $column->commands() === null => $column,
                    default => $this->resolveColumn($column, $where),
                };
            }
            $rows[] = new ContentRow($columns, $row->widths, $row->gap, $row->spaceAfter, $row->pageBreakBefore);
        }

        return new DocumentContent($content->settings, $rows);
    }

    private function resolveColumn(Column $column, string $where): Column
    {
        $commands = $column->commands();

        return match (true) {
            $column instanceof TextColumn => new TextColumn($column->style, $this->commandResolver->text($commands, $where)),
            $column instanceof HeadingColumn => new HeadingColumn(
                $column->style,
                trim($this->commandResolver->text($commands, $where)),
                $column->level,
                $column->rule,
            ),
            // read like cells the browser sent, so the limits of a table hold for the answer too
            $column instanceof TableColumn => TableColumn::read([
                'cells' => $this->commandResolver->table($commands, $where),
                'headerRow' => $column->headerRow,
                'borders' => $column->borders,
                'striped' => $column->striped,
            ], $column->style, $where),
            default => $column,
        };
    }

    private function renderReport(ReportColumn $column, string $where): ReportColumn
    {
        if ($this->subReports === null) {
            throw new PdfCreatorException(trim($where . ' Berichte stehen hier nicht zur Verfügung'), 422);
        }
        if ($column->reportId <= 0) {
            throw new PdfCreatorException(trim($where . ' Es ist noch kein Bericht gewählt'));
        }
        $definition = $column->commands();
        $source = $definition === null ? null : $this->commandResolver->value($definition, $where);
        // the report's own source is evaluated in the environment of the PDF as well
        $this->commandResolver->start();
        $writer = new ReportHtmlWriter();

        try {
            $found = $this->subReports->render($column->reportId, $writer, $definition === null, $source);
        } catch (PdfCreatorException $exception) {
            throw new PdfCreatorException(trim($where . ' ' . $exception->getMessage()), $exception->getStatusCode(), $exception);
        } catch (\Throwable $exception) {
            throw new PdfCreatorException(trim(sprintf('%s Der Bericht konnte nicht erstellt werden: %s', $where, $exception->getMessage())), 422, $exception);
        }
        if (!$found) {
            throw new PdfCreatorException(trim(sprintf('%s Den Bericht %d gibt es nicht (mehr)', $where, $column->reportId)), 404);
        }

        return new ReportColumn($column->style, $column->reportId, null, $writer->html());
    }
}
