<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

/**
 * A sub report: one of the reports stored in the application, rendered into the column
 * (SubReportProviderInterface). It runs on its own source - or, in command mode, on what
 * the commands of the column answer, so the same report can stand in a document several
 * times with different data.
 */
final readonly class ReportColumn extends Column
{
    public function __construct(
        TextStyle $style,
        /** 0: none chosen yet - a draft may hold that, a PDF is refused */
        public int $reportId,
        /** @var array<mixed>|string|null commands whose answer is the source; null: the report's own */
        public array|string|null $sourceDefinition = null,
        /** the rendered report - set by ContentCommandResolver */
        public ?string $html = null,
    )
    {
        parent::__construct($style);
    }

    /** @param array<string, mixed> $data */
    public static function read(array $data, TextStyle $style, string $where, array|string|null $commands = null): self
    {
        return new self($style, Input::int($data['reportId'] ?? null, 0, PHP_INT_MAX, 0, $where . ' Bericht'), $commands);
    }

    public function commands(): array|string|null
    {
        return $this->sourceDefinition;
    }

    public function isRendered(): bool
    {
        return $this->html !== null;
    }

    public function textLength(): int
    {
        return $this->html === null ? 0 : mb_strlen(html_entity_decode(strip_tags($this->html), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    }
}
