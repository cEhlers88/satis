<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Command\CommandResolver;

/**
 * One column of a row: text, a heading, an image, a table or a report (the "type" the
 * browser sends). Every column carries its own TextStyle.
 */
abstract readonly class Column
{
    public const TYPES = ['text', 'heading', 'image', 'table', 'report'];
    /** Where the content of text, heading and table - and the source of a report - comes from. */
    public const SOURCES = ['text', 'commands'];

    public function __construct(
        public TextStyle $style,
    )
    {
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data, string $where): self
    {
        $type = Input::choice($data['type'] ?? null, self::TYPES, 'text', $where . ' Typ');
        $style = TextStyle::fromArray(Input::map($data['style'] ?? null, $where . ' Format'), $where);
        $commands = $type !== 'image' && Input::choice($data['source'] ?? null, self::SOURCES, 'text', $where . ' Quelle') === 'commands'
            ? CommandResolver::definition($data['commands'] ?? null, $where)
            : null;

        return match ($type) {
            'text' => new TextColumn($style, Input::text($data['text'] ?? '', $where . ' Text'), $commands),
            'heading' => new HeadingColumn(
                $style,
                trim(Input::text($data['text'] ?? '', $where . ' Überschrift', 500)),
                Input::int($data['level'] ?? null, 1, 3, 2, $where . ' Ebene'),
                Input::bool($data['rule'] ?? false),
                $commands,
            ),
            'image' => ImageColumn::read($data, $style, $where),
            'table' => TableColumn::read($data, $style, $where, $commands),
            'report' => ReportColumn::read($data, $style, $where, $commands),
        };
    }

    /** Commands that give the content - resolved by ContentCommandResolver before the layout. */
    public function commands(): array|string|null
    {
        return null;
    }

    /** Characters of text in it - they count against PdfCreator::MAX_TEXT_LENGTH. */
    public function textLength(): int
    {
        return 0;
    }
}
