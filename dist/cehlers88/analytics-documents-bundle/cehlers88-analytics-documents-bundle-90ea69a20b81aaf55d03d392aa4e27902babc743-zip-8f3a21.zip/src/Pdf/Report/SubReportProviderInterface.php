<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Report;

/**
 * The reports a column of the PDF-Creator can embed ("Bericht" columns).
 *
 * Reports - their definition and how their panels are rendered - belong to the
 * application, not to this bundle, so the application implements this interface. Without
 * an implementation the tool does not offer the column type, and a document that still
 * holds one is refused.
 */
interface SubReportProviderInterface
{
    /** @return list<array{id: int, title: string}> the stored reports, ordered for a choice */
    public function reports(): array;

    /**
     * Renders a stored report into $writer.
     *
     * With $ownSource the report evaluates the source it was stored with; otherwise $source -
     * what the commands of the column answered - replaces it, which is what lets one report
     * be embedded several times with different data. Commands run in the environment of the
     * PDF (application 1, its JOB variables), so a report can read what an earlier row set.
     *
     * @return bool false when there is no report with this id
     */
    public function render(int $reportId, ReportHtmlWriter $writer, bool $ownSource = true, mixed $source = null): bool;
}
