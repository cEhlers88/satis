<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Report;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\HeadingColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;

/**
 * Writes a report as HTML for the PDF-Creator: the same classes as the columns of the
 * document (ContentHtml), so a report looks like the rest of the PDF - headings in the accent
 * colour, tables like table columns.
 *
 * The report renderer of the application describes what it shows through these calls and
 * never writes markup itself. The panels of a report line stand side by side; how many there
 * are is only known when the line ends, which is why blocks are collected on a stack and
 * put together when they are closed.
 */
final class ReportHtmlWriter
{
    /** HTML of a single report; far more than MAX_TEXT_LENGTH of text needs. */
    public const MAX_BYTES = 2097152;
    /**
     * On the table of panels side by side: like columns side by side, dompdf cannot continue
     * it on the next page, so ContentHtml turns it into the row marker PdfCreator watches.
     * Text never carries it - the quotes would have been escaped.
     */
    public const SIDE_BY_SIDE_MARKER = 'data-report-line=""';
    private const LINE = 'line';
    private const PANEL = 'panel';

    /** @var list<array{role: string, html: string, cells: list<string>}> the root first */
    private array $blocks = [['role' => '', 'html' => '', 'cells' => []]];
    private int $bytes = 0;

    /**
     * Opens a nested area: a report line ("line"), one of its panels ("panel") or any other
     * area of a panel (the body of a group or a sub report). Every call is closed by end().
     */
    public function begin(string $role): self
    {
        $this->blocks[] = ['role' => $role, 'html' => '', 'cells' => []];

        return $this;
    }

    public function end(): self
    {
        if (count($this->blocks) === 1) {
            return $this;
        }
        $block = array_pop($this->blocks);
        $parent = &$this->blocks[array_key_last($this->blocks)];

        if ($block['role'] === self::PANEL && $parent['role'] === self::LINE) {
            $parent['cells'][] = $block['html'];

            return $this;
        }
        $closed = self::close($block);
        // the wrappers count as well - a report of nothing but empty lines is large too
        $this->count(strlen($closed) - strlen($block['html']) - array_sum(array_map(strlen(...), $block['cells'])));
        $parent['html'] .= $closed;

        return $this;
    }

    /** @param int $level 1-6, as in the report editor - the PDF knows three sizes */
    public function heading(int $level, string $text): self
    {
        $size = HeadingColumn::SIZES[max(1, min(3, $level))];

        return $this->append(sprintf('<div class="heading" style="font-size: %dpt;">%s</div>', $size, self::escape($text)));
    }

    public function text(string $text): self
    {
        return $this->append('<div class="pre">' . self::escape($text) . '</div>');
    }

    /**
     * @param list<string>|list<list<string>> $headers one header row, or several
     * @param list<list<mixed>>               $rows
     */
    public function table(array $headers, array $rows): self
    {
        $headerRows = $headers === [] ? [] : (is_array(reset($headers)) ? $headers : [$headers]);
        $cells = static fn(array $row, string $tag): string => implode('', array_map(
            static fn(mixed $cell): string => sprintf('<%1$s class="pre">%2$s</%1$s>', $tag, self::escape(self::stringify($cell))),
            $row
        ));

        $html = '<table class="data borders">';
        if ($headerRows !== []) {
            $html .= '<thead>' . implode('', array_map(static fn(array $row): string => '<tr>' . $cells($row, 'th') . '</tr>', $headerRows)) . '</thead>';
        }
        $html .= '<tbody>' . implode('', array_map(
            static fn(mixed $row): string => '<tr>' . $cells(is_array($row) ? array_values($row) : [$row], 'td') . '</tr>',
            $rows
        )) . '</tbody></table>';

        return $this->append($html);
    }

    /** Something the reader should know about - not part of the report's data. */
    public function note(string $text, bool $isError = false): self
    {
        return $this->append(sprintf('<div class="report-note%s">%s</div>', $isError ? ' error' : '', self::escape($text)));
    }

    /** What was written - blocks left open (a renderer that failed half way) are closed. */
    public function html(): string
    {
        while (count($this->blocks) > 1) {
            $this->end();
        }

        return $this->blocks[0]['html'];
    }

    private function append(string $html): self
    {
        $this->count(strlen($html));
        $this->blocks[array_key_last($this->blocks)]['html'] .= $html;

        return $this;
    }

    private function count(int $bytes): void
    {
        $this->bytes += $bytes;
        if ($this->bytes > self::MAX_BYTES) {
            throw new PdfCreatorException('Der Bericht ist zu umfangreich für ein PDF', 413);
        }
    }

    /** @param array{role: string, html: string, cells: list<string>} $block */
    private static function close(array $block): string
    {
        if ($block['role'] !== self::LINE) {
            return '<div class="report-block">' . $block['html'] . '</div>';
        }
        // anything written into the line outside of a panel comes first
        $cells = $block['cells'];
        if (count($cells) <= 1) {
            return '<div class="report-line">' . $block['html'] . ($cells[0] ?? '') . '</div>';
        }
        // panels side by side share the width evenly, as in the report editor
        $width = rtrim(rtrim(number_format(100 / count($cells), 3, '.', ''), '0'), '.');
        $last = count($cells) - 1;
        $html = '';
        foreach ($cells as $index => $cell) {
            $html .= sprintf(
                '<td style="width: %s%%; vertical-align: top; padding-left: %s; padding-right: %s;">%s</td>',
                $width,
                $index === 0 ? '0' : '2mm',
                $index === $last ? '0' : '2mm',
                $cell
            );
        }

        return '<div class="report-line">' . $block['html'] . '<table class="columns" ' . self::SIDE_BY_SIDE_MARKER . '><tr>' . $html . '</tr></table></div>';
    }

    private static function stringify(mixed $value): string
    {
        return match (true) {
            $value === null => '',
            is_bool($value) => $value ? 'true' : 'false',
            is_scalar($value), $value instanceof \Stringable => (string)$value,
            default => (string)json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        };
    }

    private static function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
