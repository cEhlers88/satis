<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\ContentRow;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\DocumentContent;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\ReportColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TextColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TextStyle;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Report\ReportHtmlWriter;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadData;
use Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf\Letterhead\LetterheadDataTest;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\PdfCreator;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class PdfCreatorTest extends TestCase
{
    public function testTextBecomesAPdf(): void
    {
        $pdf = (new PdfCreator())->fromText("Grüße aus Köln\n\n    eingerückt <b>kein HTML</b>", 'Brief');

        $this->assertStringStartsWith('%PDF-', $pdf);
        $this->assertStringContainsString('%%EOF', $pdf);
    }

    #[DataProvider('logoPositions')]
    public function testTextBecomesAPdfOnALetterhead(string $logoPosition): void
    {
        $letterhead = LetterheadData::fromArray([
            'name' => 'Firma',
            'headerText' => "Muster GmbH\nStraße 1",
            'logo' => 'data:image/png;base64,' . base64_encode(LetterheadDataTest::png(60, 20)),
            'logoPosition' => $logoPosition,
            'footerText' => 'IBAN DE00 <b>0000</b>',
            'pageNumbers' => true,
        ]);

        $pdf = (new PdfCreator())->fromText(str_repeat("Zeile\n", 200), 'Brief', $letterhead);

        $this->assertStringStartsWith('%PDF-', $pdf);
        // the logo is embedded as image
        $this->assertStringContainsString('/Subtype /Image', $pdf);
    }

    public static function logoPositions(): iterable
    {
        yield 'left' => ['left'];
        yield 'center' => ['center'];
        yield 'right' => ['right'];
    }

    public function testLetterheadWithoutHeaderAndFooterIsJustMargins(): void
    {
        $pdf = (new PdfCreator())->fromText('Text', '', LetterheadData::fromArray(['name' => 'Leer', 'marginTop' => 10, 'marginBottom' => 15]));

        $this->assertStringStartsWith('%PDF-', $pdf);
    }

    public function testColumnsSideBySideThatDoNotFitOnAPageAreRefused(): void
    {
        $content = DocumentContent::fromArray(['rows' => [
            ['columns' => [['text' => 'Einleitung']]],
            ['columns' => [['text' => str_repeat('Lorem ipsum dolor sit amet. ', 400)], ['text' => 'kurz']]],
        ]]);

        try {
            (new PdfCreator())->fromContent($content);
            $this->fail('The row should have been refused');
        } catch (PdfCreatorException $exception) {
            $this->assertSame(422, $exception->getStatusCode());
            $this->assertStringContainsString('Zeile 2', $exception->getMessage());
        }
    }

    public function testLongTextInOneColumnContinuesOnTheNextPages(): void
    {
        $content = DocumentContent::fromArray(['rows' => [
            ['columns' => [['text' => str_repeat("Lorem ipsum dolor sit amet.\n", 300)]]],
            ['columns' => [['type' => 'table', 'cells' => array_fill(0, 150, ['a', 'b'])]]],
        ]]);

        $this->assertStringStartsWith('%PDF-', (new PdfCreator())->fromContent($content));
    }

    public function testARenderedReportBecomesPartOfThePdf(): void
    {
        $writer = (new ReportHtmlWriter())
            ->begin('line')->begin('panel')->heading(1, 'Bericht')->end()->end()
            ->begin('line')
            ->begin('panel')->table(['Monat', 'Umsatz'], array_fill(0, 40, ['Januar', '1.000 €']))->end()
            ->begin('panel')->note('Keine Daten')->end()
            ->end();
        $content = new DocumentContent(DocumentContent::fromArray([])->settings, [
            new ContentRow([new ReportColumn(new TextStyle(), 1, null, $writer->html())], [1]),
        ]);

        $this->assertStringStartsWith('%PDF-', (new PdfCreator())->fromContent($content));
    }

    public function testReportPanelsSideBySideThatDoNotFitOnAPageAreRefused(): void
    {
        $writer = (new ReportHtmlWriter())
            ->begin('line')
            ->begin('panel')->text(str_repeat("Lorem ipsum dolor sit amet.\n", 120))->end()
            ->begin('panel')->text('kurz')->end()
            ->end();
        $content = new DocumentContent(DocumentContent::fromArray([])->settings, [
            new ContentRow([new TextColumn(new TextStyle(), 'Einleitung')], [1]),
            new ContentRow([new ReportColumn(new TextStyle(), 1, null, $writer->html())], [1]),
        ]);

        try {
            (new PdfCreator())->fromContent($content);
            $this->fail('The report line should have been refused');
        } catch (PdfCreatorException $exception) {
            $this->assertSame(422, $exception->getStatusCode());
            $this->assertStringContainsString('Zeile 2', $exception->getMessage());
        }
    }

    public function testARenderedReportCountsAgainstTheTextLimit(): void
    {
        $writer = new ReportHtmlWriter();
        for ($i = 0; $i < 11; $i++) {
            $writer->text(str_repeat('x', 10000));
        }
        $content = new DocumentContent(DocumentContent::fromArray([])->settings, [
            new ContentRow([new ReportColumn(new TextStyle(), 1, null, $writer->html())], [1]),
        ]);

        $this->expectException(PdfCreatorException::class);
        $this->expectExceptionMessage('länger als');
        (new PdfCreator())->fromContent($content);
    }

    #[DataProvider('refusedTexts')]
    public function testRefusesTextItCannotTurnIntoAPdf(string $text, int $statusCode): void
    {
        try {
            (new PdfCreator())->fromText($text);
            $this->fail('The text should have been refused');
        } catch (PdfCreatorException $exception) {
            $this->assertSame($statusCode, $exception->getStatusCode());
        }
    }

    public static function refusedTexts(): iterable
    {
        yield 'empty' => ['', 400];
        yield 'only whitespace' => [" \n\t\r\n ", 400];
        yield 'invalid utf-8' => ["abc\xC3\x28", 400];
        yield 'too long' => [str_repeat('a', PdfCreator::MAX_TEXT_LENGTH + 1), 413];
    }

    #[DataProvider('fileNames')]
    public function testFileNameIsSafe(string $wanted, string $expected): void
    {
        $this->assertSame($expected, PdfCreator::fileName($wanted));
    }

    public static function fileNames(): iterable
    {
        yield 'empty' => ['', PdfCreator::DEFAULT_FILE_NAME];
        yield 'only dots' => [' .. ', PdfCreator::DEFAULT_FILE_NAME];
        yield 'extension added' => ['Rechnung', 'Rechnung.pdf'];
        yield 'extension kept once' => ['Rechnung.PDF', 'Rechnung.pdf'];
        yield 'other dots stay' => ['v1.2', 'v1.2.pdf'];
        yield 'umlauts stay' => ['Grüße', 'Grüße.pdf'];
        yield 'no directories' => ['../../etc/passwd', 'passwd.pdf'];
        yield 'no windows directories' => ['C:\\temp\\brief', 'brief.pdf'];
        yield 'reserved characters' => ['a:b*c?"<d>|', 'abcd.pdf'];
        yield 'control characters' => ["a\nb\x00c", 'abc.pdf'];
    }
}
