<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf\Command;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Command\CommandResolver;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Command\ContentCommandResolver;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\DocumentContent;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\HeadingColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\ReportColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TableColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TextColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Report\ReportHtmlWriter;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Report\SubReportProviderInterface;
use PHPUnit\Framework\TestCase;

class ContentCommandResolverTest extends TestCase
{
    public function testCommandColumnsBecomePlainOnes(): void
    {
        $content = DocumentContent::fromArray(['rows' => [
            ['columns' => [['type' => 'heading', 'source' => 'commands', 'commands' => ['title', []], 'level' => 1]]],
            ['columns' => [
                ['type' => 'text', 'text' => 'bleibt'],
                ['type' => 'text', 'source' => 'commands', 'commands' => ['body', []], 'style' => ['bold' => true]],
            ]],
            ['columns' => [['type' => 'table', 'source' => 'commands', 'commands' => ['rows', []], 'headerRow' => false]]],
        ]]);
        $commands = $this->createStub(CommandResolver::class);
        $commands->method('text')->willReturnCallback(static fn(array $definition, string $where): string => $definition[0] . ' @ ' . $where);
        $commands->method('table')->willReturn([['a', 'b'], ['c']]);

        $resolved = (new ContentCommandResolver($commands))->resolve($content);

        $heading = $resolved->rows[0]->columns[0];
        $this->assertInstanceOf(HeadingColumn::class, $heading);
        $this->assertSame('title @ Zeile 1:', $heading->text);
        $this->assertSame(1, $heading->level);
        $this->assertNull($heading->commands());
        $this->assertSame('bleibt', $resolved->rows[1]->columns[0]->text);
        $text = $resolved->rows[1]->columns[1];
        $this->assertInstanceOf(TextColumn::class, $text);
        $this->assertSame('body @ Zeile 2, Spalte 2:', $text->text);
        $this->assertTrue($text->style->bold);
        $table = $resolved->rows[2]->columns[0];
        $this->assertInstanceOf(TableColumn::class, $table);
        $this->assertSame([['a', 'b'], ['c', '']], $table->cells);
        $this->assertFalse($table->headerRow);
    }

    public function testContentWithOnlyCommandsIsNotEmpty(): void
    {
        $this->assertFalse(DocumentContent::fromArray(['rows' => [['columns' => [['source' => 'commands', 'commands' => ['x', []]]]]]])->isEmpty());
    }

    public function testReportColumnsAreRenderedOnTheirOwnSource(): void
    {
        $content = DocumentContent::fromArray(['rows' => [['columns' => [['type' => 'report', 'reportId' => 7, 'style' => ['italic' => true]]]]]]);
        $commands = $this->createMock(CommandResolver::class);
        $commands->expects($this->never())->method('value');
        $commands->expects($this->once())->method('start');
        $reports = $this->createMock(SubReportProviderInterface::class);
        $reports->expects($this->once())->method('render')
            ->with(7, $this->isInstanceOf(ReportHtmlWriter::class), true, null)
            ->willReturnCallback(static function (int $id, ReportHtmlWriter $writer): bool {
                $writer->begin('line')->begin('panel')->text('Bericht ' . $id)->end()->end();

                return true;
            });

        $column = (new ContentCommandResolver($commands, $reports))->resolve($content)->rows[0]->columns[0];

        $this->assertInstanceOf(ReportColumn::class, $column);
        $this->assertSame('<div class="report-line"><div class="pre">Bericht 7</div></div>', $column->html);
        $this->assertSame(9, $column->textLength());
        $this->assertTrue($column->style->italic);
        $this->assertNull($column->commands());
    }

    public function testTheCommandsOfAReportColumnGiveItsSource(): void
    {
        $content = DocumentContent::fromArray(['rows' => [['columns' => [
            ['type' => 'report', 'reportId' => '3', 'source' => 'commands', 'commands' => ['orders', []]],
        ]]]]);
        $commands = $this->createStub(CommandResolver::class);
        $commands->method('value')->willReturn([['id' => 1], ['id' => 2]]);
        $reports = $this->createMock(SubReportProviderInterface::class);
        $reports->expects($this->once())->method('render')
            ->with(3, $this->anything(), false, [['id' => 1], ['id' => 2]])
            ->willReturn(true);

        $column = (new ContentCommandResolver($commands, $reports))->resolve($content)->rows[0]->columns[0];

        $this->assertSame('', $column->html);
    }

    public function testReportColumnsAreRefusedWithoutReports(): void
    {
        $content = DocumentContent::fromArray(['rows' => [['columns' => [['type' => 'report', 'reportId' => 1]]]]]);

        $this->expectException(PdfCreatorException::class);
        $this->expectExceptionMessage('Zeile 1: Berichte stehen hier nicht zur Verfügung');

        (new ContentCommandResolver($this->createStub(CommandResolver::class)))->resolve($content);
    }

    public function testAReportColumnNeedsAReport(): void
    {
        $content = DocumentContent::fromArray(['rows' => [['columns' => [['type' => 'text', 'text' => 'x'], ['type' => 'report']]]]]);

        $this->expectException(PdfCreatorException::class);
        $this->expectExceptionMessage('Zeile 1, Spalte 2: Es ist noch kein Bericht gewählt');

        (new ContentCommandResolver($this->createStub(CommandResolver::class), $this->createStub(SubReportProviderInterface::class)))->resolve($content);
    }

    public function testAMissingOrFailingReportIsReported(): void
    {
        $content = DocumentContent::fromArray(['rows' => [['columns' => [['type' => 'report', 'reportId' => 9]]]]]);
        $reports = $this->createStub(SubReportProviderInterface::class);
        $reports->method('render')->willReturn(false);

        try {
            (new ContentCommandResolver($this->createStub(CommandResolver::class), $reports))->resolve($content);
            $this->fail('A missing report has to be refused');
        } catch (PdfCreatorException $exception) {
            $this->assertSame('Zeile 1: Den Bericht 9 gibt es nicht (mehr)', $exception->getMessage());
            $this->assertSame(404, $exception->getStatusCode());
        }

        $failing = $this->createStub(SubReportProviderInterface::class);
        $failing->method('render')->willThrowException(new \RuntimeException('Quelle kaputt'));
        $this->expectException(PdfCreatorException::class);
        $this->expectExceptionMessage('Zeile 1: Der Bericht konnte nicht erstellt werden: Quelle kaputt');

        (new ContentCommandResolver($this->createStub(CommandResolver::class), $failing))->resolve($content);
    }

    public function testAReportColumnWithoutReportIsEmpty(): void
    {
        $this->assertTrue(DocumentContent::fromArray(['rows' => [['columns' => [['type' => 'report']]]]])->isEmpty());
        $this->assertFalse(DocumentContent::fromArray(['rows' => [['columns' => [['type' => 'report', 'reportId' => 2]]]]])->isEmpty());
    }
}
