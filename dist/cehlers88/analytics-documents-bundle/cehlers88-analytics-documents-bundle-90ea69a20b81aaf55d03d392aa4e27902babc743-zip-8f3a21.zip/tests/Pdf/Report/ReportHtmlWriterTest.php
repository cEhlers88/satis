<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf\Report;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Report\ReportHtmlWriter;
use PHPUnit\Framework\TestCase;

class ReportHtmlWriterTest extends TestCase
{
    public function testALineOfOnePanelIsABlock(): void
    {
        $html = (new ReportHtmlWriter())
            ->begin('line')->begin('panel')->heading(1, 'Umsatz <2026>')->text("eins\nzwei")->end()->end()
            ->html();

        $this->assertSame(
            '<div class="report-line"><div class="heading" style="font-size: 20pt;">Umsatz &lt;2026&gt;</div><div class="pre">eins' . "\n" . 'zwei</div></div>',
            $html
        );
    }

    public function testPanelsOfALineStandSideBySide(): void
    {
        $html = (new ReportHtmlWriter())
            ->begin('line')
            ->begin('panel')->text('links')->end()
            ->begin('panel')->text('mitte')->end()
            ->begin('panel')->text('rechts')->end()
            ->end()
            ->html();

        $this->assertStringContainsString('<table class="columns" ' . ReportHtmlWriter::SIDE_BY_SIDE_MARKER . '><tr>', $html);
        $this->assertSame(3, substr_count($html, 'width: 33.333%'));
        $this->assertMatchesRegularExpression('/padding-left: 0;[^>]*>.*links/', $html);
    }

    public function testNestedBodiesAndTables(): void
    {
        $html = (new ReportHtmlWriter())
            ->begin('line')->begin('panel')
            ->begin('body')->table(['Name', 'Wert'], [['a', 1], ['b', null], ['c', ['x' => true]]])->end()
            ->end()->end()
            ->html();

        $this->assertStringContainsString('<div class="report-block"><table class="data borders">', $html);
        $this->assertStringContainsString('<thead><tr><th class="pre">Name</th><th class="pre">Wert</th></tr></thead>', $html);
        $this->assertStringContainsString('<td class="pre">1</td>', $html);
        $this->assertStringContainsString('<td class="pre"></td>', $html);
        $this->assertStringContainsString('<td class="pre">{&quot;x&quot;:true}</td>', $html);
    }

    public function testSeveralHeaderRows(): void
    {
        $html = (new ReportHtmlWriter())->table([['A', 'B'], ['a', 'b']], [])->html();

        $this->assertSame(2, substr_count($html, '<tr><th'));
    }

    public function testNotesAndHeadingLevelsBeyondThree(): void
    {
        $html = (new ReportHtmlWriter())->note('Keine Daten')->note('Kaputt', true)->heading(6, 'klein')->html();

        $this->assertStringContainsString('<div class="report-note">Keine Daten</div>', $html);
        $this->assertStringContainsString('<div class="report-note error">Kaputt</div>', $html);
        $this->assertStringContainsString('font-size: 12pt;', $html);
    }

    public function testBlocksLeftOpenAreClosed(): void
    {
        $html = (new ReportHtmlWriter())->begin('line')->begin('panel')->text('halb')->html();

        $this->assertSame('<div class="report-line"><div class="pre">halb</div></div>', $html);
    }

    public function testAnEndTooManyIsIgnored(): void
    {
        $this->assertSame('<div class="pre">x</div>', (new ReportHtmlWriter())->end()->text('x')->end()->html());
    }

    public function testTheMarkerOfPanelsSideBySideCannotComeFromText(): void
    {
        $html = (new ReportHtmlWriter())->text(ReportHtmlWriter::SIDE_BY_SIDE_MARKER)->html();

        $this->assertStringNotContainsString(ReportHtmlWriter::SIDE_BY_SIDE_MARKER, $html);
    }

    public function testEmptyBlocksCountAgainstTheLimit(): void
    {
        $writer = new ReportHtmlWriter();
        $this->expectException(PdfCreatorException::class);

        for ($i = 0; $i < 100000; $i++) {
            $writer->begin('line')->end();
        }
    }

    public function testAReportTooLargeIsRefused(): void
    {
        $writer = new ReportHtmlWriter();
        $this->expectException(PdfCreatorException::class);
        $this->expectExceptionMessage('zu umfangreich');

        $text = str_repeat('x', 100000);
        for ($i = 0; $i < 30; $i++) {
            $writer->text($text);
        }
    }
}
