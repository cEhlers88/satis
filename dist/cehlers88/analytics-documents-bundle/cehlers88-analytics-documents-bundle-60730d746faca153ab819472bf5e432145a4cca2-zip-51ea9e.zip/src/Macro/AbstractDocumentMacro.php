<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 19:34
 */

namespace Cehlers88\AnalyticsDocumentsBundle\Macro;

use Analytics\Macro\AbstractMacro;

abstract class AbstractDocumentMacro extends AbstractMacro {
    abstract protected function _init():AbstractDocumentMacro;
    public function init():AbstractDocumentMacro {
        $this->_source = "DocumentsBundle";
        return $this->_init();
    }
}