<?php

namespace Cehlers88\AnalyticsDocumentsBundle\Macro;

use Analytics\DTO\Macro\MacroPropertyDTO;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;

class GetDocumentInfosMacro extends AbstractDocumentMacro {
    private const FILE_ID = 'fileId';

    public function __construct(
        private DocumentRepository $documentRepository
    ) {

    }

    protected function run(): ?array {
        $fileEntity = $this->documentRepository->find($this->getPropertyValue(GetDocumentInfosMacro::FILE_ID));
        return $this->_createRunResult([
            'name' => $fileEntity->getName(),
            'path' => $fileEntity->getWorkspace()->getPath() .'/'. $fileEntity->getPath(),
            'attributes' => $fileEntity->getAttributes(),
            'categories' => $fileEntity->getCategories(),
        ]);
    }

    public function _init(): GetDocumentInfosMacro {
        $this
            ->setProperty(MacroPropertyDTO::create(GetDocumentInfosMacro::FILE_ID,'int','Specify the fileId', -1))
        ;
        return $this;
    }

    public function getDescription(): string {
        return '';
    }

    public function getName(): string {
        return 'getDocumentInfos';
    }
}