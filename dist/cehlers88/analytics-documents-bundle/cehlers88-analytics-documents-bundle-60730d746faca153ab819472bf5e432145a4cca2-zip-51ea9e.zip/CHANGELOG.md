# Changelog

## [0.1.1](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([6b1fc84](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/6b1fc846fe3ca819c8167e17b107feb496140b10))
