# Changelog

## [0.1.2](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([00fc73b](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/00fc73be578d47e100a2ea1a64161dcc99a5ed5e))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([a6093fb](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/a6093fb856758c2212f23770f995781c9a7c3dc1))

## [0.1.1](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([6b1fc84](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/6b1fc846fe3ca819c8167e17b107feb496140b10))
