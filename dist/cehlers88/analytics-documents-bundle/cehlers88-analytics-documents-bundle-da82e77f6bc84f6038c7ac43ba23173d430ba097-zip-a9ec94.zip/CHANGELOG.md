# Changelog

## [0.1.22](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.21...v0.1.22) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.1 ([#50](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/50)) ([4efe6ba](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/4efe6ba78fe5579113e07879f688a6941ae34622))

## [0.1.21](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.20...v0.1.21) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.25.1 ([#48](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/48)) ([2b6b1f1](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/2b6b1f196e9c94c2cb0fa71523bb188d4a471fe8))
* update analytics-core dependency to 1.*[@dev](https://github.com/dev) and adjust branch alias to 1.x-dev ([d19901e](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/d19901e11f64c505dfa794053fcf7726a4a14377))

## [0.1.20](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.19...v0.1.20) (2026-05-02)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.21.0 ([#45](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/45)) ([89b5f3c](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/89b5f3cdfc593bb5cde90a427314989a64dd25bf))
* **deps:** update dependency cehlers88/analytics-core to v1.22.1 ([#47](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/47)) ([b857d72](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/b857d7271c2977b11960b88e7311e806cf0effdf))

## [0.1.19](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.18...v0.1.19) (2026-04-26)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.20.0 ([#42](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/42)) ([bd57d67](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/bd57d677b9299f1408af864a04ae0eaa4271227b))
* **deps:** update googleapis/release-please-action action to v5 ([#43](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/43)) ([f5f2272](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/f5f22728a6e960798ac67d8b447f1285f7c18904))

## [0.1.18](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.17...v0.1.18) (2026-04-19)


### Miscellaneous Chores

* improve code style and formatting in AnalyticsDocumentsBundle ([c9caca0](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/c9caca0f2a5d33406902a84199006de26969abed))

## [0.1.17](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.16...v0.1.17) (2026-04-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.16.1 ([#38](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/38)) ([9433357](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/94333571918e853d3404948d7ab1505c3a557441))
* **deps:** update dependency cehlers88/analytics-core to v1.17.0 ([#40](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/40)) ([fa3afc9](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/fa3afc9d903aa78362e6eaee6807559f37368f73))

## [0.1.16](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.15...v0.1.16) (2026-04-13)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.15.0 ([#35](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/35)) ([c426588](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/c426588b4c3e157ac6cc7ceccfb27ce4126f4ee2))
* **deps:** update dependency cehlers88/analytics-core to v1.16.0 ([#37](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/37)) ([2fc7edd](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/2fc7edd5b5a44cbeb8470375639d299dbf14f467))

## [0.1.15](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.14...v0.1.15) (2026-03-29)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.3.10 ([#30](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/30)) ([0e10f46](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/0e10f463680441dbacbb4a4d74efe6b34d980301))
* **deps:** update dependency cehlers88/analytics-core to v1.3.13 ([#32](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/32)) ([7dcb388](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/7dcb388932d2608e1c54faccab8d93c500533ff1))
* **deps:** update dependency cehlers88/analytics-core to v1.4.1 ([#33](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/33)) ([db6f28b](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/db6f28b139b208c29cfa476b7c946e8fca1d6d6c))
* **deps:** update dependency cehlers88/analytics-core to v1.6.0 ([#34](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/34)) ([f51c2e2](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/f51c2e2911d983817ee4744a58a8acb374693d70))

## [0.1.14](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.13...v0.1.14) (2026-03-24)


### Miscellaneous Chores

* Upgraded the analytics-core package to v1.3.7 to include the latest changes and improvements. Updated the associated reference, distribution URL, and checksum to match the new version. ([13ffd1c](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/13ffd1ce2c131aacc5a82718c78019c4c5fec6b9))

## [0.1.13](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.12...v0.1.13) (2026-03-24)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.1.3 ([#26](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/26)) ([284f720](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/284f72055aef6c3d8cb0d86bc444e6711c19716c))
* **deps:** update dependency cehlers88/analytics-core to v1.3.6 ([#28](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/28)) ([ce42670](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/ce426705d99413197f0fa4a31800c5453cbcd16e))

## [0.1.12](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.11...v0.1.12) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([245cce1](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/245cce1be52464b545eb2c3603fc805e701c6bc1))

## [0.1.11](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.10...v0.1.11) (2026-03-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.5.4 ([#21](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/21)) ([c691ae4](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/c691ae447d946b498f72ccb3c503c0373f8ef624))
* **deps:** update dependency cehlers88/analytics-core to v0.5.5 ([#23](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/23)) ([cd72a5f](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/cd72a5f438673122d92e7fac996af9b9abb8abc8))

## [0.1.10](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.9...v0.1.10) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.5 ([#20](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/20)) ([56c7d0b](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/56c7d0bf1d044976bd88e53e4126bcaf2c6e0543))
* **deps:** update dependency cehlers88/analytics-core to v0.4.2 ([#18](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/18)) ([8cb1800](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/8cb180059dc07a0cd75013cc3839198d00ee4970))

## [0.1.9](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.8...v0.1.9) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([ab5c3cf](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/ab5c3cfae0a4cfa9e0b1d263bbed098f047a3a19))

## [0.1.8](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.7...v0.1.8) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([93f6ff1](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/93f6ff16d745cef1ee12bd6da7e1655ba4535bdc))

## [0.1.7](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.6...v0.1.7) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#11](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/11)) ([8e35884](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/8e35884edf6dd36f333a43ac7e54ebe376814442))
* **deps:** update dependency cehlers88/analytics-core to v0.3.1 ([#13](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/13)) ([f18a53c](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/f18a53c2fe3283987d21bc07b8b5c63145b1ab57))

## [0.1.6](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.5...v0.1.6) (2026-03-19)


### Miscellaneous Chores

* bump analytics-core dependency to ^0.3 in composer.json ([bdbe964](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/bdbe96426a53579dc5e39f352235bf0d4f7c95bf))

## [0.1.5](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.4...v0.1.5) (2026-01-22)


### Miscellaneous Chores

* Update dependency versions for analytics-core ([bf25e4b](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/bf25e4b951c43aa218e61e28a94cb79ab958fdd2))

## [0.1.4](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.3...v0.1.4) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.2.0@dev ([#7](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/7)) ([8378af3](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/8378af3a8d7a1a5de117dbd3692c2ffd1b3664e1))
* **deps:** update dependency cehlers88/analytics-core to v0.2.1 ([#6](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/6)) ([226e1d5](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/226e1d5e4a523d2319491eaeceb0ff8b0a78e317))

## [0.1.3](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.2...v0.1.3) (2026-01-21)


### Miscellaneous Chores

* add GitHub workflow to trigger Satis rebuild on release ([2c855c9](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/2c855c99dd5618e07a68b8ecc581b283fc1a9fa0))
* **deps:** update dependency cehlers88/analytics-core to v0.1.5 ([#4](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/4)) ([658cacc](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/658cacc4abb705cdd9fca10e68f7d06edcc93433))

## [0.1.2](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([00fc73b](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/00fc73be578d47e100a2ea1a64161dcc99a5ed5e))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([a6093fb](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/a6093fb856758c2212f23770f995781c9a7c3dc1))

## [0.1.1](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([6b1fc84](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/6b1fc846fe3ca819c8167e17b107feb496140b10))
