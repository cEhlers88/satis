<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetImporter;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PHPUnit\Framework\TestCase;

class SpreadsheetImporterTest extends TestCase
{
    public function testAppendSheetsKeepsTitlesUnique(): void
    {
        $target = new Spreadsheet();
        $target->getActiveSheet()->setTitle('Januar');
        $source = new Spreadsheet();
        $source->getActiveSheet()->setTitle('Tabelle1')->setCellValue('A1', 'x')->getStyle('A1')->getFont()->setBold(true);

        $titles = (new SpreadsheetImporter())->appendSheets($target, $source, 'Januar');

        $this->assertSame(['Januar (2)'], $titles);
        $this->assertSame('x', $target->getSheet(1)->getCell('A1')->getValue());
        $this->assertTrue($target->getSheet(1)->getStyle('A1')->getFont()->getBold());
    }

    public function testAppendRowsSkipsTheHeaderAndCalculatesFormulas(): void
    {
        $target = new Spreadsheet();
        $target->getActiveSheet()->fromArray([['Monat', 'Betrag'], ['Jan', 5]]);
        $source = new Spreadsheet();
        $source->getActiveSheet()->fromArray([['Monat', 'Betrag'], ['Feb', 7], ['Mär', '=B2*2']]);

        $appended = (new SpreadsheetImporter())->appendRows($target->getActiveSheet(), $source->getActiveSheet(), true);

        $this->assertSame(2, $appended);
        $this->assertSame([['Jan', 5], ['Feb', 7], ['Mär', 14]], $target->getActiveSheet()->rangeToArray('A2:B4', null, false, false));
    }

    public function testAppendRowsIntoAnEmptySheetStartsAtTheTop(): void
    {
        $target = new Spreadsheet();
        $source = new Spreadsheet();
        $source->getActiveSheet()->fromArray([['a', 'b']]);

        (new SpreadsheetImporter())->appendRows($target->getActiveSheet(), $source->getActiveSheet(), false);

        $this->assertSame('a', $target->getActiveSheet()->getCell('A1')->getValue());
    }
}
