<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\ENUM\ESpreadsheetFormat;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\CsvOptions;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\WorkbookNotFoundException;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetIo;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetStorage;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

class SpreadsheetStorageTest extends SpreadsheetTestCase
{
    private string $directory;

    protected function setUp(): void
    {
        $this->directory = $this->temporaryDirectory();
    }

    private function storage(int $maxWorkbooks = 5, int $undoSteps = 3): SpreadsheetStorage
    {
        return new SpreadsheetStorage(new SpreadsheetIo(100000), $this->directory, $maxWorkbooks, $undoSteps, 30);
    }

    private function spreadsheet(string $value): Spreadsheet
    {
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getActiveSheet()->setCellValue('A1', $value);

        return $spreadsheet;
    }

    public function testCreateListAndOpen(): void
    {
        $storage = $this->storage();

        $meta = $storage->create(7, "  Umsätze\n2026 ", $this->spreadsheet('x'), ESpreadsheetFormat::CSV, new CsvOptions(';'));

        $this->assertMatchesRegularExpression('/^[a-f0-9]{16}$/', $meta->id);
        $this->assertSame('Umsätze 2026', $meta->name);
        $this->assertSame([$meta->id], array_map(static fn($workbook) => $workbook->id, $storage->list(7)));
        $this->assertSame([], $storage->list(8), 'another user sees nothing');
        $this->assertSame(';', $storage->get(7, $meta->id)->csvOptions->delimiter);
        $this->assertSame('x', $storage->open(7, $meta->id)->getActiveSheet()->getCell('A1')->getValue());
    }

    public function testWorkbooksOfOtherUsersAreNotFound(): void
    {
        $storage = $this->storage();
        $meta = $storage->create(7, 'Mine', $this->spreadsheet('x'), ESpreadsheetFormat::XLSX, new CsvOptions());

        $this->expectException(WorkbookNotFoundException::class);
        $storage->open(8, $meta->id);
    }

    public function testInvalidIdsNeverReachThePath(): void
    {
        $this->expectException(WorkbookNotFoundException::class);
        $this->storage()->get(7, '../7/0123456789abcdef');
    }

    public function testModifyKeepsUndoStepsAndChecksTheRevision(): void
    {
        $storage = $this->storage(undoSteps: 2);
        $meta = $storage->create(7, 'Book', $this->spreadsheet('v0'), ESpreadsheetFormat::XLSX, new CsvOptions());

        for ($step = 1; $step <= 3; ++$step) {
            [$meta, $result] = $storage->modify(7, $meta->id, static function (Spreadsheet $spreadsheet) use ($step): string {
                $spreadsheet->getActiveSheet()->setCellValue('A1', 'v' . $step);

                return 'done ' . $step;
            }, $meta->revision);
            $this->assertSame('done ' . $step, $result);
        }

        $this->assertSame(3, $meta->revision);
        $this->assertSame(2, $meta->undoSteps, 'the oldest undo step was dropped');

        try {
            $storage->modify(7, $meta->id, static fn() => null, 1);
            $this->fail('An outdated revision must be refused.');
        } catch (SpreadsheetToolException $exception) {
            $this->assertSame(409, $exception->getStatusCode());
        }

        $meta = $storage->undo(7, $meta->id);
        $this->assertSame('v2', $storage->open(7, $meta->id)->getActiveSheet()->getCell('A1')->getValue());
        $this->assertSame(4, $meta->revision);
        $meta = $storage->undo(7, $meta->id);
        $this->assertSame('v1', $storage->open(7, $meta->id)->getActiveSheet()->getCell('A1')->getValue());
        $this->assertSame(0, $meta->undoSteps);

        $this->expectException(SpreadsheetToolException::class);
        $storage->undo(7, $meta->id);
    }

    public function testNothingIsWrittenWhenTheChangeFails(): void
    {
        $storage = $this->storage();
        $meta = $storage->create(7, 'Book', $this->spreadsheet('before'), ESpreadsheetFormat::XLSX, new CsvOptions());

        try {
            $storage->modify(7, $meta->id, static function (Spreadsheet $spreadsheet): void {
                $spreadsheet->getActiveSheet()->setCellValue('A1', 'after');
                throw new SpreadsheetToolException('nope');
            });
        } catch (SpreadsheetToolException) {
        }

        $meta = $storage->get(7, $meta->id);
        $this->assertSame(0, $meta->revision);
        $this->assertSame(0, $meta->undoSteps);
        $this->assertSame('before', $storage->open(7, $meta->id)->getActiveSheet()->getCell('A1')->getValue());
    }

    public function testRenameDeleteAndLimit(): void
    {
        $storage = $this->storage(maxWorkbooks: 2);
        $first = $storage->create(7, 'One', $this->spreadsheet('1'), ESpreadsheetFormat::XLSX, new CsvOptions());
        $storage->create(7, 'Two', $this->spreadsheet('2'), ESpreadsheetFormat::XLSX, new CsvOptions());

        $this->assertSame('Renamed', $storage->rename(7, $first->id, 'Renamed')->name);

        try {
            $storage->create(7, 'Three', $this->spreadsheet('3'), ESpreadsheetFormat::XLSX, new CsvOptions());
            $this->fail('The limit must hold.');
        } catch (SpreadsheetToolException $exception) {
            $this->assertSame(409, $exception->getStatusCode());
        }

        $storage->delete(7, $first->id);
        $this->assertCount(1, $storage->list(7));
        $this->assertDirectoryDoesNotExist($this->directory . '/7/' . $first->id);
    }

    public function testUntouchedWorkbooksExpire(): void
    {
        $storage = $this->storage();
        $meta = $storage->create(7, 'Old', $this->spreadsheet('x'), ESpreadsheetFormat::XLSX, new CsvOptions());
        $metaFile = $this->directory . '/7/' . $meta->id . '/meta.json';
        $data = json_decode((string)file_get_contents($metaFile), true);
        $data['updatedAt'] = (new \DateTimeImmutable('-31 days'))->format(DATE_ATOM);
        file_put_contents($metaFile, json_encode($data));

        $this->assertSame([], $storage->list(7));
        $this->assertDirectoryDoesNotExist($this->directory . '/7/' . $meta->id);
    }
}
