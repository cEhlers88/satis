<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\CellValueParser;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetInspector;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PHPUnit\Framework\TestCase;

class SpreadsheetInspectorTest extends TestCase
{
    public function testReadCellsGivesShownAndEditableValues(): void
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'Name')->getStyle('A1')->getFont()->setBold(true);
        $sheet->getCell('B1')->setValueExplicit('42', DataType::TYPE_STRING);
        $sheet->setCellValue('A2', 99.9);
        $sheet->setCellValue('B2', '=A2*2');
        CellValueParser::setCellFromInput($sheet->getCell('C2'), '2026-09-17');
        $sheet->mergeCells('A3:B3');

        $cells = (new SpreadsheetInspector())->readCells($spreadsheet, 0, 1, 3, 1, 3);

        $this->assertSame(3, $cells['totalRows']);
        $this->assertSame(['A', 'B', 'C'], array_column($cells['columns'], 'letter'));
        [$name, $text] = $cells['rows'][0]['cells'];
        $this->assertSame(['bold' => true], $cells['styles']->{$name['x']});
        $this->assertSame("'42", $text['e'], 'a text that looks like a number keeps its apostrophe');
        [, $formula, $date] = $cells['rows'][1]['cells'];
        $this->assertSame('199.8', $formula['v']);
        $this->assertSame('99.9', $cells['rows'][1]['cells'][0]['e']);
        $this->assertSame('99.9', $cells['rows'][1]['cells'][0]['v']);
        $this->assertSame('=A2*2', $formula['e']);
        $this->assertSame('2026-09-17', $date['e']);
        $this->assertSame('d', $date['t']);
        $this->assertSame(['A3:B3'], $cells['merges']);
    }

    public function testColumnStatistics(): void
    {
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getActiveSheet()->fromArray([
            ['Stadt', 'Betrag'],
            ['Köln', 10],
            ['Bonn', 30],
            ['Köln', null],
            ['Köln', '=B2+B3'],
        ]);

        $statistics = (new SpreadsheetInspector())->columnStatistics($spreadsheet, 0, true);
        [$city, $amount] = $statistics['columns'];

        $this->assertSame(4, $statistics['rows']);
        $this->assertSame('Stadt', $city['name']);
        $this->assertSame(4, $city['texts']);
        $this->assertSame(2, $city['distinct']);
        $this->assertSame(['value' => 'Köln', 'count' => 3], $city['top'][0]);
        $this->assertSame(3, $amount['numbers']);
        $this->assertSame(1, $amount['empty']);
        $this->assertSame(1, $amount['formulas']);
        $this->assertSame(40, $amount['max']);
        $this->assertSame(80, $amount['sum']);
    }
}
