<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\ENUM\ESpreadsheetFormat;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\CellValueParser;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\CsvOptions;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetIo;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

class SpreadsheetIoTest extends SpreadsheetTestCase
{
    public function testCsvDelimiterAndEncodingAreDetected(): void
    {
        $path = $this->temporaryFile(mb_convert_encoding("Name;Ort;Betrag\nMüller;Köln;12\nSchäfer;Düsseldorf;7\n", 'Windows-1252', 'UTF-8'));

        $loaded = (new SpreadsheetIo(1000))->load($path, ESpreadsheetFormat::CSV);
        $sheet = $loaded->spreadsheet->getActiveSheet();

        $this->assertSame(';', $loaded->csvOptions->delimiter);
        $this->assertSame('Windows-1252', $loaded->csvOptions->encoding);
        $this->assertSame('Köln', $sheet->getCell('B2')->getValue());
        $this->assertSame(12, $sheet->getCell('C2')->getValue());
    }

    public function testFilesAboveTheCellLimitAreRefused(): void
    {
        $path = $this->temporaryFile(str_repeat("a,b,c,d\n", 10));

        try {
            (new SpreadsheetIo(20))->load($path, ESpreadsheetFormat::CSV);
            $this->fail('The file is larger than the limit.');
        } catch (SpreadsheetToolException $exception) {
            $this->assertSame(413, $exception->getStatusCode());
        }
    }

    public function testBrokenXlsxIsRefusedWithoutDetails(): void
    {
        $path = $this->temporaryFile('not a zip', 'xlsx');

        try {
            (new SpreadsheetIo(1000))->load($path, ESpreadsheetFormat::XLSX);
            $this->fail('A broken file must not load.');
        } catch (SpreadsheetToolException $exception) {
            $this->assertSame('The file could not be read as XLSX.', $exception->getMessage());
            $this->assertStringNotContainsString($path, $exception->getMessage());
        }
    }

    public function testCsvExportWithDecimalCommaDatesAndBom(): void
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->fromArray([['Artikel', 'Preis', 'Datum', 'Summe'], ['Äpfel; rot', 99.9, null, null]]);
        CellValueParser::setCellFromInput($sheet->getCell('C2'), '2026-09-17');
        $sheet->setCellValue('D2', '=B2*2');
        $path = $this->temporaryDirectory() . '/out.csv';

        (new SpreadsheetIo(1000))->save($spreadsheet, $path, ESpreadsheetFormat::CSV, new CsvOptions(';', '"', 'UTF-8', true, ','));

        $this->assertSame(
            "\xEF\xBB\xBFArtikel;Preis;Datum;Summe\r\n\"Äpfel; rot\";99,9;2026-09-17;199,8\r\n",
            file_get_contents($path)
        );
    }

    public function testCsvExportInWindows1252(): void
    {
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getActiveSheet()->setCellValue('A1', 'Größe');
        $path = $this->temporaryDirectory() . '/out.csv';

        (new SpreadsheetIo(1000))->save($spreadsheet, $path, ESpreadsheetFormat::CSV, new CsvOptions(encoding: 'Windows-1252'));

        $this->assertSame(mb_convert_encoding("Größe\r\n", 'Windows-1252', 'UTF-8'), file_get_contents($path));
    }

    public function testJsonExportUsesTheHeaderRow(): void
    {
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getActiveSheet()->fromArray([['id', 'name', 'name', ''], [1, 'Anna', 'A.', true]]);
        $path = $this->temporaryDirectory() . '/out.json';

        (new SpreadsheetIo(1000))->save($spreadsheet, $path, ESpreadsheetFormat::JSON, sheetIndex: 0);

        $this->assertSame(
            [['id' => 1, 'name' => 'Anna', 'name_2' => 'A.', 'D' => true]],
            json_decode((string)file_get_contents($path), true)
        );
    }

    public function testXlsxRoundTrip(): void
    {
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getActiveSheet()->setTitle('Daten')->setCellValue('A1', '=1+2');
        $spreadsheet->createSheet()->setTitle('Zweites');
        $path = $this->temporaryDirectory() . '/out.xlsx';
        $io = new SpreadsheetIo(1000);

        $io->save($spreadsheet, $path, ESpreadsheetFormat::XLSX);
        $loaded = $io->load($path, ESpreadsheetFormat::XLSX)->spreadsheet;

        $this->assertSame(['Daten', 'Zweites'], $loaded->getSheetNames());
        $this->assertSame(3, $loaded->getSheet(0)->getCell('A1')->getCalculatedValue());
    }

    public function testTheCellLimitFollowsTheMemoryLimit(): void
    {
        $memoryLimit = ini_get('memory_limit');
        ini_set('memory_limit', '256M');

        try {
            $this->assertSame(223696, (new SpreadsheetIo(1000000))->maxCells());
            $this->assertSame(1000, (new SpreadsheetIo(1000))->maxCells());
        } finally {
            ini_set('memory_limit', $memoryLimit);
        }
    }
}
