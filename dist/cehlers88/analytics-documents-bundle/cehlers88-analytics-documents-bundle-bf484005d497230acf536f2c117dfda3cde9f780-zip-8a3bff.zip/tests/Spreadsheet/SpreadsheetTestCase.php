<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Spreadsheet;

use PHPUnit\Framework\TestCase;

abstract class SpreadsheetTestCase extends TestCase
{
    private array $temporaryPaths = [];

    protected function tearDown(): void
    {
        foreach (array_reverse($this->temporaryPaths) as $path) {
            $this->remove($path);
        }
        $this->temporaryPaths = [];
    }

    protected function temporaryDirectory(): string
    {
        $directory = sys_get_temp_dir() . '/xlsm-test-' . bin2hex(random_bytes(6));
        mkdir($directory, 0777, true);
        $this->temporaryPaths[] = $directory;

        return $directory;
    }

    protected function temporaryFile(string $content, string $extension = 'csv'): string
    {
        $path = $this->temporaryDirectory() . '/file.' . $extension;
        file_put_contents($path, $content);

        return $path;
    }

    private function remove(string $path): void
    {
        if (is_dir($path) && !is_link($path)) {
            foreach (scandir($path) ?: [] as $entry) {
                if ($entry !== '.' && $entry !== '..') {
                    $this->remove($path . '/' . $entry);
                }
            }
            @rmdir($path);

            return;
        }
        @unlink($path);
    }
}
