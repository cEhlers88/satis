<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\CellValueParser;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class CellValueParserTest extends TestCase
{
    public static function inputs(): iterable
    {
        yield 'integer' => ['42', 42, DataType::TYPE_NUMERIC];
        yield 'decimal' => ['-3.25', -3.25, DataType::TYPE_NUMERIC];
        yield 'leading zero stays text' => ['00123', '00123', DataType::TYPE_STRING];
        yield 'apostrophe keeps text' => ["'42", '42', DataType::TYPE_STRING];
        yield 'boolean' => ['true', true, DataType::TYPE_BOOL];
        yield 'formula' => ['=SUM(A1:A3)', '=SUM(A1:A3)', DataType::TYPE_FORMULA];
        yield 'text' => ['Hamburg', 'Hamburg', DataType::TYPE_STRING];
        yield 'percent' => ['12.5%', 0.125, DataType::TYPE_NUMERIC];
    }

    #[DataProvider('inputs')]
    public function testSetCellFromInput(string $input, mixed $expectedValue, string $expectedType): void
    {
        $cell = (new Spreadsheet())->getActiveSheet()->getCell('A1');

        CellValueParser::setCellFromInput($cell, $input);

        $this->assertSame($expectedValue, $cell->getValue());
        $this->assertSame($expectedType, $cell->getDataType());
    }

    public function testIsoDateBecomesDateWithFormat(): void
    {
        $cell = (new Spreadsheet())->getActiveSheet()->getCell('A1');

        CellValueParser::setCellFromInput($cell, '2026-09-17 08:30');

        $this->assertTrue(Date::isDateTime($cell));
        $this->assertSame('2026-09-17 08:30:00', Date::excelToDateTimeObject($cell->getValue())->format('Y-m-d H:i:s'));
        $this->assertSame(CellValueParser::DATE_TIME_FORMAT, $cell->getStyle()->getNumberFormat()->getFormatCode());
    }

    public function testInvalidIsoDateStaysText(): void
    {
        $cell = (new Spreadsheet())->getActiveSheet()->getCell('A1');

        CellValueParser::setCellFromInput($cell, '2026-02-30');

        $this->assertSame('2026-02-30', $cell->getValue());
    }

    public function testEmptyInputClearsValueButKeepsFormat(): void
    {
        $cell = (new Spreadsheet())->getActiveSheet()->getCell('A1');
        $cell->setValue(5)->getStyle()->getFont()->setBold(true);

        CellValueParser::setCellFromInput($cell, '');

        $this->assertNull($cell->getValue());
        $this->assertTrue($cell->getStyle()->getFont()->getBold());
    }

    public static function localizedNumbers(): iterable
    {
        yield 'german' => ['1.234,56', ',', '.', 1234.56];
        yield 'german without thousands' => ['-0,5', ',', '.', -0.5];
        yield 'english' => ['1,234.5', '.', ',', 1234.5];
        yield 'integer' => ['12.000', ',', '.', 12000];
        yield 'percent' => ['19 %', ',', '.', 0.19];
        yield 'wrong grouping' => ['1.23,4', ',', '.', null];
        yield 'currency' => ['12,00 €', ',', '.', null];
        yield 'text' => ['abc', ',', '.', null];
    }

    #[DataProvider('localizedNumbers')]
    public function testParseLocalizedNumber(string $text, string $decimal, string $thousands, int|float|null $expected): void
    {
        $this->assertSame($expected, CellValueParser::parseLocalizedNumber($text, $decimal, $thousands));
    }

    public function testParseGermanDate(): void
    {
        [$serial, $format] = CellValueParser::parseGermanDate('17.09.26');

        $this->assertSame('2026-09-17', Date::excelToDateTimeObject($serial)->format('Y-m-d'));
        $this->assertSame(CellValueParser::DATE_FORMAT, $format);
        $this->assertNull(CellValueParser::parseGermanDate('31.02.2026'));
    }

    public function testNumberToTextKeepsFifteenSignificantDigits(): void
    {
        $this->assertSame('99.9', CellValueParser::numberToText(99.9));
        $this->assertSame('0.3', CellValueParser::numberToText(0.1 + 0.2));
        $this->assertSame('-1234.5', CellValueParser::numberToText(-1234.5));
        $this->assertSame('1E+20', CellValueParser::numberToText(1e20));
        $this->assertSame('42', CellValueParser::numberToText(42));
    }
}
