<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\AddSheetOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\AutoFilterOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\AutoSizeColumnsOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\CleanTextOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\ClearRangeOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\ConvertTextOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\DeleteColumnsOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\DeleteRowsOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\DeleteSheetOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\DuplicateSheetOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\FindReplaceOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\FreezePaneOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\InsertColumnsOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\InsertRowsOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\MergeCellsOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\MoveSheetOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\RemoveDuplicatesOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\RenameSheetOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\SetCellsOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\SortRangeOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\SplitColumnOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\StyleRangeOperation;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetOperationRunner;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PHPUnit\Framework\TestCase;

class OperationsTest extends TestCase
{
    private function runner(): SpreadsheetOperationRunner
    {
        return new SpreadsheetOperationRunner([
            new SetCellsOperation(), new ClearRangeOperation(),
            new InsertRowsOperation(), new DeleteRowsOperation(), new InsertColumnsOperation(), new DeleteColumnsOperation(),
            new AddSheetOperation(), new RenameSheetOperation(), new DeleteSheetOperation(), new DuplicateSheetOperation(), new MoveSheetOperation(),
            new SortRangeOperation(), new RemoveDuplicatesOperation(), new FindReplaceOperation(), new CleanTextOperation(),
            new ConvertTextOperation(), new SplitColumnOperation(),
            new StyleRangeOperation(), new MergeCellsOperation(), new FreezePaneOperation(), new AutoFilterOperation(), new AutoSizeColumnsOperation(),
        ]);
    }

    /** @param list<array<mixed>> $rows */
    private function spreadsheet(array $rows): Spreadsheet
    {
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getActiveSheet()->fromArray($rows, null, 'A1', true);

        return $spreadsheet;
    }

    private function values(Spreadsheet $spreadsheet, string $range, int $sheet = 0): array
    {
        return $spreadsheet->getSheet($sheet)->rangeToArray($range, null, true, false);
    }

    public function testRunnerRefusesUnknownOperations(): void
    {
        $this->expectException(SpreadsheetToolException::class);
        $this->expectExceptionMessage('Operation 1: unknown type.');

        $this->runner()->apply(new Spreadsheet(), [['type' => 'formatHardDisk']]);
    }

    public function testRunnerPrefixesErrorsWithTheOperation(): void
    {
        $this->expectExceptionMessage('insertRows: "row" must be between 1 and 1048576.');

        $this->runner()->apply(new Spreadsheet(), [['type' => 'insertRows', 'row' => 0]]);
    }

    public function testSetCellsAndClearRange(): void
    {
        $spreadsheet = new Spreadsheet();

        $results = $this->runner()->apply($spreadsheet, [
            ['type' => 'setCells', 'cells' => [
                ['cell' => 'a1', 'value' => '10'],
                ['cell' => 'A2', 'value' => '=A1*3'],
                ['cell' => 'B1', 'value' => "'007"],
            ]],
            ['type' => 'clearRange', 'range' => 'B1', 'what' => 'contents'],
        ]);

        $this->assertSame([['type' => 'setCells', 'cells' => 3], ['type' => 'clearRange', 'cells' => 1]], $results);
        $this->assertSame([[10, null], [30, null]], $this->values($spreadsheet, 'A1:B2'));
    }

    public function testRowsAndColumnsMoveReferences(): void
    {
        $spreadsheet = $this->spreadsheet([[1, 2, '=A1+B1']]);

        $this->runner()->apply($spreadsheet, [
            ['type' => 'insertRows', 'row' => 1, 'count' => 2],
            ['type' => 'insertColumns', 'column' => 'A'],
        ]);

        $this->assertSame('=B3+C3', $spreadsheet->getActiveSheet()->getCell('D3')->getValue());
        $this->runner()->apply($spreadsheet, [
            ['type' => 'deleteColumns', 'column' => 'A'],
            ['type' => 'deleteRows', 'row' => 1, 'count' => 2],
        ]);
        $this->assertSame([[1, 2, 3]], $this->values($spreadsheet, 'A1:C1'));
    }

    public function testSheetOperations(): void
    {
        $spreadsheet = $this->spreadsheet([['x']]);
        $spreadsheet->getActiveSheet()->setTitle('Data');

        $results = $this->runner()->apply($spreadsheet, [
            ['type' => 'duplicateSheet', 'sheet' => 0],
            ['type' => 'addSheet', 'title' => 'Summary', 'index' => 0],
            ['type' => 'renameSheet', 'sheet' => 1, 'title' => 'Data (2)'],
            ['type' => 'moveSheet', 'sheet' => 0, 'index' => 2],
        ]);

        $this->assertSame('Data (2)', $results[0]['title']);
        $this->assertSame('Data (3)', $results[2]['title'], 'renaming onto a taken title picks the next free one');
        $this->assertSame(['Data (3)', 'Data (2)', 'Summary'], $spreadsheet->getSheetNames());
        $this->assertSame('x', $spreadsheet->getSheetByName('Data (2)')->getCell('A1')->getValue());

        $this->runner()->apply($spreadsheet, [['type' => 'deleteSheet', 'sheet' => 2], ['type' => 'deleteSheet', 'sheet' => 1]]);
        $this->expectExceptionMessage('deleteSheet: A workbook keeps at least one sheet.');
        $this->runner()->apply($spreadsheet, [['type' => 'deleteSheet', 'sheet' => 0]]);
    }

    public function testInvalidSheetTitleIsRefused(): void
    {
        $this->expectExceptionMessage('renameSheet: A sheet title must not contain');

        $this->runner()->apply(new Spreadsheet(), [['type' => 'renameSheet', 'sheet' => 0, 'title' => 'a/b']]);
    }

    public function testSortMovesFormulasAndStylesWithTheirRows(): void
    {
        $spreadsheet = $this->spreadsheet([
            ['Name', 'Menge', 'Doppelt'],
            ['Item 10', 3, '=B2*2'],
            ['item 2', null, '=B3*2'],
            ['Item 1', 3, '=B4*2'],
            ['Apfel', 1, '=B5*2'],
        ]);
        $spreadsheet->getActiveSheet()->getStyle('A5')->getFont()->setBold(true);

        $this->runner()->apply($spreadsheet, [[
            'type' => 'sort',
            'headerRow' => true,
            'keys' => [['column' => 'B', 'direction' => 'desc'], ['column' => 'A']],
        ]]);

        $sheet = $spreadsheet->getActiveSheet();
        $this->assertSame(['Item 1', 'Item 10', 'Apfel', 'item 2'], array_column($this->values($spreadsheet, 'A2:A5'), 0));
        $this->assertSame([6, 6, 2, 0], array_column($this->values($spreadsheet, 'C2:C5'), 0));
        $this->assertSame('=B4*2', $sheet->getCell('C4')->getValue());
        $this->assertTrue($sheet->getStyle('A4')->getFont()->getBold());
        $this->assertSame('Name', $sheet->getCell('A1')->getValue());
    }

    public function testSortOrdersNumbersBeforeTextsAndEmptyLast(): void
    {
        $this->assertLessThan(0, SortRangeOperation::compare(5, 'a', 1));
        $this->assertGreaterThan(0, SortRangeOperation::compare(5, 'a', -1));
        $this->assertGreaterThan(0, SortRangeOperation::compare(null, 'a', 1));
        $this->assertGreaterThan(0, SortRangeOperation::compare('', 'a', -1));
    }

    public function testRemoveDuplicates(): void
    {
        $spreadsheet = $this->spreadsheet([
            ['Mail', 'Name'],
            ['a@example.org', 'Anna'],
            ['b@example.org', 'Ben'],
            ['A@example.org', 'Anna B.'],
            ['b@example.org', 'Ben'],
        ]);

        $results = $this->runner()->apply($spreadsheet, [
            ['type' => 'removeDuplicates', 'columns' => ['A'], 'ignoreCase' => true],
        ]);

        $this->assertSame(['type' => 'removeDuplicates', 'removed' => 2, 'rows' => 2], $results[0]);
        $this->assertSame([['a@example.org', 'Anna'], ['b@example.org', 'Ben'], [null, null], [null, null]], $this->values($spreadsheet, 'A2:B5'));
        $this->assertSame(3, $spreadsheet->getActiveSheet()->getHighestDataRow());
    }

    public function testFindReplace(): void
    {
        $spreadsheet = $this->spreadsheet([['Muster GmbH', 'GMBH', 2024, '="GmbH"']]);
        $spreadsheet->createSheet()->setCellValue('A1', 'Andere GmbH');

        $results = $this->runner()->apply($spreadsheet, [
            ['type' => 'findReplace', 'search' => 'gmbh', 'replace' => 'AG $1', 'allSheets' => true],
            ['type' => 'findReplace', 'search' => '20(\d\d)', 'replace' => '19$1', 'regex' => true, 'wholeCell' => true],
        ]);

        $this->assertSame(['type' => 'findReplace', 'cells' => 3, 'replacements' => 3], $results[0]);
        $sheet = $spreadsheet->getActiveSheet();
        $this->assertSame('Muster AG $1', $sheet->getCell('A1')->getValue(), 'a literal replacement has no back references');
        $this->assertSame(1924, $sheet->getCell('C1')->getValue(), 'a number stays a number');
        $this->assertSame('="GmbH"', $sheet->getCell('D1')->getValue(), 'formulas are left alone by default');
        $this->assertSame('Andere AG $1', $spreadsheet->getSheet(1)->getCell('A1')->getValue());
    }

    public function testInvalidRegexIsRefused(): void
    {
        $this->expectExceptionMessage('findReplace: The regular expression is invalid.');

        $this->runner()->apply(new Spreadsheet(), [['type' => 'findReplace', 'search' => '(', 'regex' => true]]);
    }

    public function testCleanAndConvertTexts(): void
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        foreach (['A1' => "  1.234,50\u{00A0}", 'A2' => '17.09.2026', 'A3' => ' viel   zu  viel ', 'A4' => '12 %', 'A5' => 'EUR 5'] as $cell => $text) {
            $sheet->getCell($cell)->setValueExplicit($text, 's');
        }

        $results = $this->runner()->apply($spreadsheet, [
            ['type' => 'cleanText', 'case' => 'none'],
            ['type' => 'convertText', 'decimalSeparator' => ',', 'thousandsSeparator' => '.'],
        ]);

        $this->assertSame(['type' => 'cleanText', 'cells' => 2], $results[0]);
        $this->assertSame(['type' => 'convertText', 'numbers' => 2, 'dates' => 1], $results[1]);
        $this->assertSame(1234.5, $sheet->getCell('A1')->getValue());
        $this->assertSame('2026-09-17', Date::excelToDateTimeObject($sheet->getCell('A2')->getValue())->format('Y-m-d'));
        $this->assertSame('viel zu viel', $sheet->getCell('A3')->getValue());
        $this->assertSame(0.12, $sheet->getCell('A4')->getValue());
        $this->assertSame('EUR 5', $sheet->getCell('A5')->getValue());
    }

    public function testSplitColumn(): void
    {
        $spreadsheet = $this->spreadsheet([
            ['Adresse', 'Land'],
            ['Hauptstr. 1, 50667, Köln', 'DE'],
            ['Ring 2, 1010', 'AT'],
        ]);

        $results = $this->runner()->apply($spreadsheet, [['type' => 'splitColumn', 'column' => 'A', 'delimiter' => ',']]);

        $this->assertSame(['type' => 'splitColumn', 'columns' => 2, 'rows' => 2], $results[0]);
        $this->assertSame([
            ['Adresse', 'Adresse (2)', 'Adresse (3)', 'Land'],
            ['Hauptstr. 1', 50667, 'Köln', 'DE'],
            ['Ring 2', 1010, null, 'AT'],
        ], $this->values($spreadsheet, 'A1:D3'));
    }

    public function testFormattingAndView(): void
    {
        $spreadsheet = $this->spreadsheet([['Kopf', 'Zeile'], [1, 2]]);

        $this->runner()->apply($spreadsheet, [
            ['type' => 'style', 'range' => 'A1:B1', 'bold' => true, 'fill' => '#1f4e79', 'color' => 'FFFFFF', 'align' => 'center', 'borders' => 'bottom'],
            ['type' => 'style', 'range' => 'B:B', 'numberFormat' => '#,##0.00'],
            ['type' => 'mergeCells', 'range' => 'A1:B1'],
            ['type' => 'freezePane', 'cell' => 'A2'],
            ['type' => 'autoFilter'],
            ['type' => 'autoSizeColumns', 'width' => 20],
        ]);

        $sheet = $spreadsheet->getActiveSheet();
        $style = $sheet->getStyle('B1');
        $this->assertTrue($style->getFont()->getBold());
        $this->assertSame(Fill::FILL_SOLID, $style->getFill()->getFillType());
        $this->assertSame('1F4E79', $style->getFill()->getStartColor()->getRGB());
        $this->assertSame('#,##0.00', $sheet->getStyle('B2')->getNumberFormat()->getFormatCode());
        $this->assertSame(['A1:B1' => 'A1:B1'], $sheet->getMergeCells());
        $this->assertNull($sheet->getCell('B1')->getValue(), 'merging empties the hidden cells');
        $this->assertSame('A2', $sheet->getFreezePane());
        $this->assertSame('A1:B2', $sheet->getAutoFilter()->getRange());
        $this->assertSame(20.0, $sheet->getColumnDimension('B')->getWidth());

        $this->runner()->apply($spreadsheet, [
            ['type' => 'mergeCells', 'range' => 'A1', 'merge' => false],
            ['type' => 'freezePane'],
            ['type' => 'autoFilter', 'remove' => true],
            ['type' => 'style', 'range' => 'A1', 'fill' => ''],
        ]);
        $this->assertSame([], $sheet->getMergeCells());
        $this->assertNull($sheet->getFreezePane());
        $this->assertSame('', $sheet->getAutoFilter()->getRange());
        $this->assertSame(Fill::FILL_NONE, $sheet->getStyle('A1')->getFill()->getFillType());
    }

    public function testSortRefusesMergedCells(): void
    {
        $spreadsheet = $this->spreadsheet([['h'], [2], [1]]);
        $spreadsheet->getActiveSheet()->mergeCells('A2:B2');

        $this->expectExceptionMessage('sort: Rows with merged cells cannot be sorted');
        $this->runner()->apply($spreadsheet, [['type' => 'sort']]);
    }

    public function testHugeRangesAreRefused(): void
    {
        $this->expectExceptionMessage('style: "range" covers more than');

        $this->runner()->apply(new Spreadsheet(), [['type' => 'style', 'range' => 'A1:Z100000', 'bold' => true]]);
    }
}
