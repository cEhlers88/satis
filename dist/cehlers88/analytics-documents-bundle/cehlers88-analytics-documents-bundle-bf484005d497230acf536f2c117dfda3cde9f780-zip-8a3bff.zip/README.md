# AnalyticsDocumentsBundle

A Symfony bundle for document management within the Analytics platform. It provides entities, repositories, macros, and configuration for organizing and accessing documents in workspaces.

## Requirements

- PHP 8.4+
- Symfony 8.x
- `cehlers88/analytics-core` 1.x
- `phpoffice/phpspreadsheet` ^5.10 (Excel-Manipulator)
- Doctrine ORM

## Installation

Install the bundle via Composer using the custom Satis repository:

```bash
composer require cehlers88/analytics-documents-bundle
```

> **Note:** This package is served from the private Satis repository at `https://cehlers88.github.io/satis`. Ensure your `composer.json` includes this repository:
>
> ```json
> {
>   "repositories": [
>     {
>       "type": "composer",
>       "url": "https://cehlers88.github.io/satis"
>     }
>   ]
> }
> ```

### Registering the Bundle

If your application does not use Symfony Flex auto-discovery, register the bundle manually in `config/bundles.php`:

```php
return [
    // ...
    Cehlers88\AnalyticsDocumentsBundle\AnalyticsDocumentsBundle::class => ['all' => true],
];
```

### Database Migrations

After installation, generate and run the Doctrine migrations to create the required database tables:

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

Or use the schema update command (not recommended for production):

```bash
php bin/console doctrine:schema:update --force
```

## Overview

The bundle integrates with `cehlers88/analytics-core` and registers itself as a bundle plugin (`AbstractBundlePlugin`). It provides:

| Feature | Description |
|---|---|
| **Entities** | `Document` and `Workspace` Doctrine ORM entities |
| **Repositories** | `DocumentRepository` and `WorkspaceRepository` for querying the database |
| **Macros** | Automation macros for retrieving, setting, and merging document data |
| **Configuration** | A configuration group for defining workspace paths and aliases |
| **Permissions** | An `ACCESS_DOCUMENTS` permission to control bundle access |
| **Menu Item** | Registers a "Dokumentverwaltung" (Document Management) entry in the Analytics menu |
| **Excel-Manipulator** | A dashboard tool to open, edit, create and export XLSX, XLS, ODS and CSV files (see below) |

## Entities

### Document

Represents a file registered in the system.

| Property | Type | Description |
|---|---|---|
| `id` | `int` | Auto-generated primary key |
| `name` | `string` | Human-readable name of the document |
| `path` | `string` | Relative file path within the workspace |
| `attributes` | `array` | Arbitrary key-value metadata stored as JSON |
| `registeredAt` | `DateTimeImmutable` | Timestamp when the document was registered |
| `categories` | `Collection<Category>` | Many-to-many relation to Analytics `Category` entities |
| `workspace` | `Workspace` | Many-to-one relation to the owning `Workspace` |

The full path to the document file is constructed by combining the workspace path with the document path:

```php
$fullPath = $document->getWorkspace()->getPath() . '/' . $document->getPath();
```

### Workspace

Represents a container that groups documents under a shared root path.

| Property | Type | Description |
|---|---|---|
| `id` | `int` | Auto-generated primary key |
| `name` | `string` | Human-readable workspace name |
| `path` | `string` | Filesystem root path of this workspace |
| `documents` | `Collection<Document>` | One-to-many relation to its `Document` entities |

## Repositories

Both repositories extend Symfony's `ServiceEntityRepository` and are auto-wired via Doctrine's `ManagerRegistry`.

### DocumentRepository

```php
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;

// Find a document by ID
$document = $documentRepository->find($id);

// Find all documents
$documents = $documentRepository->findAll();

// Use standard Doctrine criteria
$documents = $documentRepository->findBy(['workspace' => $workspace]);
```

### WorkspaceRepository

```php
use Cehlers88\AnalyticsDocumentsBundle\Repository\WorkspaceRepository;

// Find a workspace by ID
$workspace = $workspaceRepository->find($id);

// Find a workspace by name
$workspace = $workspaceRepository->findOneBy(['name' => 'My Workspace']);
```

## Macros

Macros are automation components tagged with `macro` in the service container. They extend `AbstractDocumentMacro` which sets the macro source to `"DocumentsBundle"`.

### GetDocumentInfosMacro

**Name:** `getDocumentInfos`

Retrieves metadata for a document by its ID.

| Property | Type | Default | Description |
|---|---|---|---|
| `fileId` | `int` | `-1` | ID of the document to retrieve |

**Output:**

| Key | Type | Description |
|---|---|---|
| `name` | `string` | Document name |
| `path` | `string` | Full path (workspace path + document path) |
| `attributes` | `array` | Document attributes |
| `categories` | `Collection` | Associated categories |

### SetDocumentInfosMacro

**Name:** `setDocumentInfos`

Sets or creates document metadata. *(Work in progress)*

| Property | Type | Default | Description |
|---|---|---|---|
| `fileId` | `int` | `-1` | ID of an existing document, or `-1` to create a new one |
| `fullPath` | `string` | `-1` | Full filesystem path of the document |
| `workspaceId` | `int` | `-1` | ID of the target workspace |

### MergeDocumentsMacro

**Name:** `mergeDocuments`

Merges document data. *(Work in progress)*

| Property | Type | Default | Description |
|---|---|---|---|
| `fileId` | `int` | `-1` | ID of the source document |
| `fullPath` | `string` | `-1` | Full filesystem path |
| `workspaceId` | `int` | `-1` | ID of the target workspace |

## Excel-Manipulator

A tool for `/dashboard/tools` that reads and writes spreadsheets with PhpSpreadsheet.
The bundle brings all of it; the application lists the tool in its tools page and
imports the bundle's templates and controllers:

```yaml
# config/packages/twig.yaml
twig:
  paths:
    'vendor/cehlers88/analytics-documents-bundle/templates': ~

# config/routes/analytics_documents.yaml
analytics_documents_bundle:
  resource: '@AnalyticsDocumentsBundle/Controller/'
  type: attribute
```

| Part | Where |
|---|---|
| Mask and styles | `templates/tool/excelManipulator.html.twig` |
| Script | `templates/tool/script/excelManipulator.js.twig` |
| Tile illustration | `templates/tool/teaser/excelManipulator.html.twig` |
| JSON backend | `Controller/SpreadsheetToolController` under `/admin_api/documents/spreadsheets` (`ROLE_DASHBOARD` or `ROLE_ADMIN`, CSRF token `excel_manipulator` in `X-CSRF-Token`) |
| Working copies and undo | `Spreadsheet/SpreadsheetStorage` - `{directory}/{userId}/{workbookId}/` |
| Reading and writing | `Spreadsheet/SpreadsheetIo` - XLSX, XLSM, XLS, ODS, CSV in; XLSX, XLS, ODS, CSV, JSON out |
| Grid data, column statistics | `Spreadsheet/SpreadsheetInspector` |
| Changes | `Spreadsheet/Operation/*Operation`, applied by `SpreadsheetOperationRunner` |

What the tool does - the grid, the panels, undo, import and export - is described in
the application's `docs/dashboard-tools.md`.

### Operations

Every change is an operation `{"type": "…", …arguments}` sent to
`POST /admin_api/documents/spreadsheets/{id}/operations`. A list is applied all or
nothing and is one undo step.

| Type | Arguments |
|---|---|
| `setCells` | `sheet`, `cells: [{cell, value}]` - values read like typed text (`=` formula, `'` text, ISO dates) |
| `clearRange` | `sheet`, `range`, `what: contents\|formats\|all` |
| `insertRows` / `deleteRows` | `sheet`, `row`, `count` |
| `insertColumns` / `deleteColumns` | `sheet`, `column`, `count` |
| `addSheet` / `renameSheet` / `duplicateSheet` / `moveSheet` / `deleteSheet` | `sheet`, `title`, `index` |
| `sort` | `sheet`, `range`, `headerRow`, `keys: [{column, direction}]` (up to 3) |
| `removeDuplicates` | `sheet`, `range`, `headerRow`, `columns`, `ignoreCase` |
| `findReplace` | `sheet`, `allSheets`, `range`, `search`, `replace`, `matchCase`, `wholeCell`, `regex`, `inFormulas` |
| `cleanText` | `sheet`, `range`, `trim`, `collapseSpaces`, `removeLineBreaks`, `case` |
| `convertText` | `sheet`, `range`, `numbers`, `dates`, `decimalSeparator`, `thousandsSeparator` |
| `splitColumn` | `sheet`, `column`, `delimiter`, `headerRow`, `maxParts` |
| `style` | `sheet`, `range`, `bold`, `italic`, `underline`, `strike`, `fontSize`, `color`, `fill`, `numberFormat`, `align`, `verticalAlign`, `wrap`, `borders` |
| `mergeCells` | `sheet`, `range`, `merge` |
| `freezePane` | `sheet`, `cell` (none releases) |
| `autoFilter` | `sheet`, `range`, `remove` |
| `autoSizeColumns` | `sheet`, `range`, `width` (none fits to content) |

A range is `A1:C5`, `B2`, `A:C` or `2:4`; without one the used range of the sheet is
taken. A new operation is a class implementing
`Spreadsheet\Operation\SpreadsheetOperationInterface` - the tag
`analytics_documents.spreadsheet_operation` is set by `services.yaml`.

### Parameters

| Parameter | Default |
|---|---|
| `analytics_documents.spreadsheet.directory` | `%kernel.project_dir%/var/spreadsheets` |
| `analytics_documents.spreadsheet.max_file_size` | `20971520` (20 MB) |
| `analytics_documents.spreadsheet.max_cells` | `1000000`, and never more than `memory_limit` holds (about 1.2 KB per cell) |
| `analytics_documents.spreadsheet.max_workbooks` | `30` per user |
| `analytics_documents.spreadsheet.undo_steps` | `20` per workbook |
| `analytics_documents.spreadsheet.retention_days` | `30` |

### Tests

```bash
vendor/bin/phpunit
```

## Configuration

The bundle provides the `GeneralConfigurationGroup` which registers under the key `documentsBundle.general` in the Analytics configuration UI.

| Key | Type | Default | Description |
|---|---|---|---|
| `workspaceRoot` | Text | *(empty)* | Filesystem root path shared by all workspaces |
| `workspaceRootAliases` | Repeatable | *(empty)* | Alternative aliases for the workspace root path |
| `documentRoots` | Repeatable | *(empty)* | List of workspace definitions (see below) |

Each entry in `documentRoots` supports:

| Key | Type | Default | Description |
|---|---|---|---|
| `id` | Unique ID | *(auto)* | Unique identifier for the workspace definition |
| `name` | Text | `Workspace name` | Display name |
| `description` | Multi-line Text | *(empty)* | Optional description |
| `path` | Text | `/var/workspace` | Filesystem path for this workspace |

## Permissions

The bundle defines the following permission via `EPermission`:

| Permission | Value | Description |
|---|---|---|
| `ACCESS_DOCUMENTS` | `ACCESS_DOCUMENTS` | Grants access to the document management module |

Permissions are automatically registered with the Analytics core when the bundle is loaded.

## Services

All bundle services are auto-wired and auto-configured. The `services.yaml` configuration:

- Auto-wires all classes in the bundle namespace
- **Excludes** entity classes from the service container
- Tags all `Macro\*` classes with the `macro` tag
- Tags all `Configuration\*` classes with the `analytics.configuration` tag

## License

MIT License — Copyright (c) 2024 Christoph Ehlers. See [LICENSE](LICENSE) for details.

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a history of releases and changes.
