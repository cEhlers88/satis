<?php

namespace Cehlers88\AnalyticsDocumentsBundle\Controller;

use Cehlers88\AnalyticsCore\DTO\ResultDTO;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsDocumentsBundle\ENUM\ESpreadsheetFormat;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\CsvOptions;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetImporter;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetInspector;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetIo;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetOperationRunner;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetStorage;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\WorkbookMeta;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\Exception\JsonException;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Routing\Attribute\Route;

/**
 * The backend of the Excel-Manipulator tool (/dashboard/tools).
 *
 * No route carries a user id: every action works on the working copies of the user
 * of the session. Changes need the CSRF token "excel_manipulator" in the
 * X-CSRF-Token header. Every answer is a ResultDTO, except the export, which is the
 * file itself.
 */
#[Route('/admin_api/documents/spreadsheets', name: 'analytics_documents_admin_api_spreadsheets_')]
final class SpreadsheetToolController extends AbstractController
{
    public const CSRF_TOKEN_ID = 'excel_manipulator';
    public const CSRF_HEADER = 'X-CSRF-Token';
    private const ID = '[a-f0-9]{16}';

    public function __construct(
        private readonly SpreadsheetStorage         $storage,
        private readonly SpreadsheetIo              $io,
        private readonly SpreadsheetInspector       $inspector,
        private readonly SpreadsheetOperationRunner $operationRunner,
        private readonly SpreadsheetImporter        $importer,
        #[Autowire('%analytics_documents.spreadsheet.max_file_size%')]
        private readonly int                        $maxFileSize,
    )
    {
    }

    /** The working copies of the user and what the tool can do. */
    #[Route('', name: 'list', methods: ['GET'])]
    public function list(): Response
    {
        return $this->handle(function (): Response {
            $userId = $this->userId();

            return $this->success('Workbooks', [
                'workbooks' => array_map(static fn(WorkbookMeta $meta) => $meta->toArray(), $this->storage->list($userId)),
                'limits' => [
                    'maxFileSize' => $this->effectiveMaxFileSize(),
                    'maxCells' => $this->io->maxCells(),
                    'maxRows' => SpreadsheetInspector::MAX_ROWS,
                    'maxColumns' => SpreadsheetInspector::MAX_COLUMNS,
                ],
                'extensions' => ESpreadsheetFormat::readableExtensions(),
                'operations' => $this->operationRunner->names(),
            ]);
        });
    }

    /** @param callable(): Response $action */
    private function handle(callable $action): Response
    {
        try {
            return $action();
        } catch (SpreadsheetToolException $exception) {
            return $this->json(ResultDTO::createError($exception->getMessage(), $exception->getStatusCode()), $exception->getStatusCode());
        }
    }

    private function userId(): int
    {
        if (!$this->isGranted('ROLE_DASHBOARD') && !$this->isGranted('ROLE_ADMIN')) {
            throw $this->createAccessDeniedException();
        }
        $user = $this->getUser();
        if (!$user instanceof User || $user->getId() === null) {
            throw $this->createAccessDeniedException('Workbooks belong to a stored user.');
        }

        return $user->getId();
    }

    private function success(string $message, mixed $data = [], int $statusCode = 200): Response
    {
        return $this->json(ResultDTO::createSuccess($message, $data, $statusCode), $statusCode);
    }

    /** The configured limit, but never more than PHP itself accepts. */
    private function effectiveMaxFileSize(): int
    {
        $limits = [$this->maxFileSize];
        foreach (['upload_max_filesize', 'post_max_size'] as $setting) {
            $bytes = SpreadsheetIo::iniBytes((string)ini_get($setting));
            if ($bytes > 0) {
                $limits[] = $bytes;
            }
        }

        return min($limits);
    }

    /** Multipart: "file" plus, for CSV, "delimiter", "enclosure" and "encoding" (each "auto" by default). */
    #[Route('/upload', name: 'upload', methods: ['POST'])]
    public function upload(Request $request): Response
    {
        return $this->handle(function () use ($request): Response {
            $userId = $this->userId();
            $this->checkCsrfToken($request);
            [$file, $format] = $this->uploadedFile($request);

            $loaded = $this->io->load($file->getPathname(), $format, CsvOptions::fromArray($request->request->all()));
            $name = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
            $meta = $this->storage->create($userId, $name, $loaded->spreadsheet, $format, $loaded->csvOptions);

            return $this->workbookResponse('Workbook uploaded', $meta, $loaded->spreadsheet, 201);
        });
    }

    private function checkCsrfToken(Request $request): void
    {
        $token = $request->headers->get(self::CSRF_HEADER);
        if (!is_string($token) || $token === '' || !$this->isCsrfTokenValid(self::CSRF_TOKEN_ID, $token)) {
            throw new SpreadsheetToolException('Invalid CSRF token', 403);
        }
    }

    /** @return array{UploadedFile, ESpreadsheetFormat} */
    private function uploadedFile(Request $request): array
    {
        $file = $request->files->get('file');
        if (!$file instanceof UploadedFile) {
            throw new SpreadsheetToolException('No file was sent - or it was larger than the server accepts.', 413);
        }
        if (!$file->isValid()) {
            throw new SpreadsheetToolException('The upload failed: ' . $file->getErrorMessage(), 400);
        }
        if ($file->getSize() > $this->effectiveMaxFileSize()) {
            throw new SpreadsheetToolException(sprintf('The file is larger than %d MB.', intdiv($this->effectiveMaxFileSize(), 1048576)), 413);
        }

        $format = ESpreadsheetFormat::fromFileName($file->getClientOriginalName());
        if ($format === null) {
            throw new SpreadsheetToolException(sprintf('Only %s files can be opened.', implode(', ', ESpreadsheetFormat::readableExtensions())), 415);
        }

        return [$file, $format];
    }

    /**
     * Expected JSON body: {"name": "…", "text": "a;b\n1;2", "delimiter": ";"} - without
     * a text the workbook starts with an empty sheet.
     */
    #[Route('', name: 'create', methods: ['POST'])]
    public function create(Request $request): Response
    {
        return $this->handle(function () use ($request): Response {
            $userId = $this->userId();
            $this->checkCsrfToken($request);
            $body = $this->readBody($request);

            $name = is_string($body['name'] ?? null) ? $body['name'] : 'Workbook';
            $text = $body['text'] ?? '';
            if (!is_string($text)) {
                throw new SpreadsheetToolException('"text" must be a string.');
            }

            if (trim($text) === '') {
                $spreadsheet = new Spreadsheet();
                $spreadsheet->getActiveSheet()->setTitle('Sheet1');
                $meta = $this->storage->create($userId, $name, $spreadsheet, ESpreadsheetFormat::XLSX, new CsvOptions());
            } else {
                if (strlen($text) > $this->effectiveMaxFileSize()) {
                    throw new SpreadsheetToolException('The text is too long.', 413);
                }
                $loaded = $this->io->loadCsvText($text, CsvOptions::fromArray($body));
                $spreadsheet = $loaded->spreadsheet;
                $meta = $this->storage->create($userId, $name, $spreadsheet, ESpreadsheetFormat::CSV, $loaded->csvOptions);
            }

            return $this->workbookResponse('Workbook created', $meta, $spreadsheet, 201);
        });
    }

    /** @return array<string, mixed> */
    private function readBody(Request $request): array
    {
        try {
            return $request->toArray();
        } catch (JsonException) {
            throw new SpreadsheetToolException('The request body must be a JSON object.');
        }
    }

    /** @param array<string, mixed> $extra */
    private function workbookResponse(string $message, WorkbookMeta $meta, Spreadsheet $spreadsheet, int $statusCode = 200, array $extra = []): Response
    {
        return $this->success($message, [
            'workbook' => $meta->toArray(),
            ...$this->inspector->describe($spreadsheet),
            ...$extra,
        ], $statusCode);
    }

    #[Route('/{workbookId}', name: 'show', requirements: ['workbookId' => self::ID], methods: ['GET'])]
    public function show(string $workbookId): Response
    {
        return $this->handle(function () use ($workbookId): Response {
            $userId = $this->userId();
            $meta = $this->storage->get($userId, $workbookId);

            return $this->workbookResponse('Workbook', $meta, $this->storage->open($userId, $workbookId));
        });
    }

    /** Expected JSON body: {"name": "…"} */
    #[Route('/{workbookId}', name: 'rename', requirements: ['workbookId' => self::ID], methods: ['PATCH'])]
    public function rename(Request $request, string $workbookId): Response
    {
        return $this->handle(function () use ($request, $workbookId): Response {
            $userId = $this->userId();
            $this->checkCsrfToken($request);
            $name = $this->readBody($request)['name'] ?? null;
            if (!is_string($name)) {
                throw new SpreadsheetToolException('"name" must be a string.');
            }

            return $this->success('Workbook renamed', ['workbook' => $this->storage->rename($userId, $workbookId, $name)->toArray()]);
        });
    }

    #[Route('/{workbookId}', name: 'delete', requirements: ['workbookId' => self::ID], methods: ['DELETE'])]
    public function delete(Request $request, string $workbookId): Response
    {
        return $this->handle(function () use ($request, $workbookId): Response {
            $userId = $this->userId();
            $this->checkCsrfToken($request);
            $this->storage->delete($userId, $workbookId);

            return $this->success('Workbook deleted');
        });
    }

    /** ?row=1&rows=100&column=1&columns=26 - a window of cells for the grid. */
    #[Route('/{workbookId}/sheets/{sheet}/cells', name: 'cells', requirements: ['workbookId' => self::ID, 'sheet' => '\d+'], methods: ['GET'])]
    public function cells(Request $request, string $workbookId, int $sheet): Response
    {
        return $this->handle(function () use ($request, $workbookId, $sheet): Response {
            $userId = $this->userId();
            $meta = $this->storage->get($userId, $workbookId);
            $cells = $this->inspector->readCells(
                $this->storage->open($userId, $workbookId),
                $sheet,
                $request->query->getInt('row', 1),
                $request->query->getInt('rows', 100),
                $request->query->getInt('column', 1),
                $request->query->getInt('columns', 26),
            );

            return $this->success('Cells', ['revision' => $meta->revision, ...$cells]);
        });
    }

    /** ?headerRow=1 */
    #[Route('/{workbookId}/sheets/{sheet}/statistics', name: 'statistics', requirements: ['workbookId' => self::ID, 'sheet' => '\d+'], methods: ['GET'])]
    public function statistics(Request $request, string $workbookId, int $sheet): Response
    {
        return $this->handle(function () use ($request, $workbookId, $sheet): Response {
            $userId = $this->userId();

            return $this->success('Column statistics', $this->inspector->columnStatistics(
                $this->storage->open($userId, $workbookId),
                $sheet,
                $request->query->getBoolean('headerRow', true),
            ));
        });
    }

    /**
     * Expected JSON body: {"revision": 4, "operations": [{"type": "setCells", …}, …]}
     *
     * The operations are applied in order and kept together - all or none, one undo
     * step. A revision other than the current one is answered with 409.
     */
    #[Route('/{workbookId}/operations', name: 'operations', requirements: ['workbookId' => self::ID], methods: ['POST'])]
    public function operations(Request $request, string $workbookId): Response
    {
        return $this->handle(function () use ($request, $workbookId): Response {
            $userId = $this->userId();
            $this->checkCsrfToken($request);
            $body = $this->readBody($request);
            $operations = $body['operations'] ?? null;
            if (!is_array($operations)) {
                throw new SpreadsheetToolException('"operations" must be a list.');
            }

            $spreadsheet = null;
            [$meta, $results] = $this->storage->modify(
                $userId,
                $workbookId,
                function (Spreadsheet $workbook) use ($operations, &$spreadsheet): array {
                    $spreadsheet = $workbook;

                    return $this->operationRunner->apply($workbook, array_values($operations));
                },
                $this->optionalRevision($body['revision'] ?? null),
            );

            return $this->workbookResponse('Operations applied', $meta, $spreadsheet, extra: ['results' => $results]);
        });
    }

    private function optionalRevision(mixed $revision): ?int
    {
        if ($revision === null || $revision === '') {
            return null;
        }
        if (is_string($revision) && preg_match('/^\d+$/D', $revision) === 1) {
            return (int)$revision;
        }
        if (!is_int($revision)) {
            throw new SpreadsheetToolException('"revision" must be a whole number.');
        }

        return $revision;
    }

    #[Route('/{workbookId}/undo', name: 'undo', requirements: ['workbookId' => self::ID], methods: ['POST'])]
    public function undo(Request $request, string $workbookId): Response
    {
        return $this->handle(function () use ($request, $workbookId): Response {
            $userId = $this->userId();
            $this->checkCsrfToken($request);
            $meta = $this->storage->undo($userId, $workbookId);

            return $this->workbookResponse('Change undone', $meta, $this->storage->open($userId, $workbookId));
        });
    }

    /**
     * Multipart: "file", "mode" (sheets: every sheet of the file is added; rows: the
     * rows of its first sheet are appended to "sheet"), "skipHeaderRow", "revision"
     * and the CSV options of the upload.
     */
    #[Route('/{workbookId}/import', name: 'import', requirements: ['workbookId' => self::ID], methods: ['POST'])]
    public function import(Request $request, string $workbookId): Response
    {
        return $this->handle(function () use ($request, $workbookId): Response {
            $userId = $this->userId();
            $this->checkCsrfToken($request);
            [$file, $format] = $this->uploadedFile($request);
            $mode = $request->request->getString('mode', 'sheets');
            if (!in_array($mode, ['sheets', 'rows'], true)) {
                throw new SpreadsheetToolException('"mode" must be "sheets" or "rows".');
            }
            $targetSheet = $request->request->getInt('sheet');
            $skipHeaderRow = $request->request->getBoolean('skipHeaderRow');
            $revision = $this->optionalRevision($request->request->get('revision'));

            $source = $this->io->load($file->getPathname(), $format, CsvOptions::fromArray($request->request->all()))->spreadsheet;
            $baseTitle = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);

            $spreadsheet = null;
            [$meta, $result] = $this->storage->modify(
                $userId,
                $workbookId,
                function (Spreadsheet $workbook) use ($source, $mode, $targetSheet, $skipHeaderRow, $baseTitle, &$spreadsheet): array {
                    $spreadsheet = $workbook;
                    if ($mode === 'sheets') {
                        return ['sheets' => $this->importer->appendSheets($workbook, $source, $baseTitle)];
                    }

                    return ['rows' => $this->importer->appendRows(
                        SpreadsheetInspector::sheet($workbook, $targetSheet),
                        $source->getSheet(0),
                        $skipHeaderRow
                    )];
                },
                $revision,
            );

            return $this->workbookResponse('File imported', $meta, $spreadsheet, extra: ['results' => [$result]]);
        });
    }

    /**
     * ?format=xlsx|xls|ods|csv|json and, depending on it, sheet, delimiter, enclosure,
     * encoding, bom, decimalSeparator (CSV) and headerRow (JSON).
     */
    #[Route('/{workbookId}/export', name: 'export', requirements: ['workbookId' => self::ID], methods: ['GET'])]
    public function export(Request $request, string $workbookId): Response
    {
        return $this->handle(function () use ($request, $workbookId): Response {
            $userId = $this->userId();
            $meta = $this->storage->get($userId, $workbookId);
            $format = ESpreadsheetFormat::tryFrom($request->query->getString('format', $meta->sourceFormat->value))
                ?? throw new SpreadsheetToolException('Unsupported export format.');

            $spreadsheet = $this->storage->open($userId, $workbookId);
            $sheet = $request->query->has('sheet') && $request->query->getString('sheet') !== ''
                ? $request->query->getInt('sheet')
                : ($format === ESpreadsheetFormat::CSV ? $spreadsheet->getActiveSheetIndex() : null);

            $csvOptions = CsvOptions::fromArray($request->query->all());
            $path = tempnam(sys_get_temp_dir(), 'xlsm');
            if ($path === false) {
                throw new SpreadsheetToolException('The export could not be prepared.', 500);
            }

            try {
                $this->io->save(
                    $spreadsheet,
                    $path,
                    $format,
                    $csvOptions,
                    $format->keepsWorkbook() ? null : $sheet,
                    $request->query->getBoolean('headerRow', true),
                );
            } catch (\Throwable $exception) {
                @unlink($path);
                throw $exception;
            }

            $fileName = $meta->name;
            if (!$format->keepsWorkbook() && $sheet !== null && $spreadsheet->getSheetCount() > 1) {
                $fileName .= ' - ' . $spreadsheet->getSheet($sheet)->getTitle();
            }
            $fileName = trim((string)preg_replace('/[\x00-\x1F\x7F\/\\\\:*?"<>|]+/u', '_', $fileName)) . '.' . $format->value;

            $contentType = $format === ESpreadsheetFormat::CSV
                ? $format->mimeType() . '; charset=' . ($csvOptions->encoding ?? 'UTF-8')
                : $format->mimeType();
            $response = new BinaryFileResponse($path, 200, ['Content-Type' => $contentType], false);
            $response->deleteFileAfterSend();
            $response->setContentDisposition(
                ResponseHeaderBag::DISPOSITION_ATTACHMENT,
                $fileName,
                (string)preg_replace('/[^A-Za-z0-9._ -]+/', '_', $fileName)
            );
            $response->headers->set('X-Content-Type-Options', 'nosniff');

            return $response;
        });
    }
}
