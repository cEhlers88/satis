<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Cell\Cell;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\DefaultValueBinder;
use PhpOffice\PhpSpreadsheet\RichText\RichText;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Throwable;

/**
 * Everything the Excel-Manipulator shows of a workbook: the sheets, a window of
 * cells for the grid and a summary per column.
 *
 * The grid is paged - a sheet can have a million rows, the browser gets at most
 * MAX_ROWS x MAX_COLUMNS cells per request. Styles are sent once per style index
 * instead of once per cell, since most cells of a sheet share a handful of them.
 */
final class SpreadsheetInspector
{
    public const MAX_ROWS = 500;
    public const MAX_COLUMNS = 100;
    private const MAX_MERGES = 500;
    private const MAX_DISTINCT = 10000;
    private const TOP_VALUES = 5;
    private const ERROR_VALUES = ['#NULL!', '#DIV/0!', '#VALUE!', '#REF!', '#NAME?', '#NUM!', '#N/A', '#ERROR'];

    public static function sheet(Spreadsheet $spreadsheet, int $index): Worksheet
    {
        if ($index < 0 || $index >= $spreadsheet->getSheetCount()) {
            throw new SpreadsheetToolException('The sheet does not exist.', 404);
        }

        return $spreadsheet->getSheet($index);
    }

    /** @return array<string, mixed> */
    public function describe(Spreadsheet $spreadsheet): array
    {
        $sheets = [];
        foreach ($spreadsheet->getWorksheetIterator() as $index => $sheet) {
            $sheets[] = [
                'index' => $index,
                'title' => $sheet->getTitle(),
                'rows' => $sheet->getHighestDataRow(),
                'columns' => Coordinate::columnIndexFromString($sheet->getHighestDataColumn()),
                'lastColumn' => $sheet->getHighestDataColumn(),
                'hidden' => $sheet->getSheetState() !== Worksheet::SHEETSTATE_VISIBLE,
                'freezePane' => $sheet->getFreezePane(),
                'autoFilter' => $sheet->getAutoFilter()->getRange() ?: null,
                'merges' => count($sheet->getMergeCells()),
                'tabColor' => $sheet->isTabColorSet() ? substr($sheet->getTabColor()->getRGB(), -6) : null,
            ];
        }

        return [
            'sheets' => $sheets,
            'activeSheet' => $spreadsheet->getActiveSheetIndex(),
        ];
    }

    /** @return array<string, mixed> */
    public function readCells(Spreadsheet $spreadsheet, int $sheetIndex, int $firstRow, int $rows, int $firstColumn, int $columns): array
    {
        $sheet = self::sheet($spreadsheet, $sheetIndex);
        $firstRow = max(1, $firstRow);
        $firstColumn = max(1, $firstColumn);
        $lastRow = $firstRow + max(1, min(self::MAX_ROWS, $rows)) - 1;
        $lastColumn = $firstColumn + max(1, min(self::MAX_COLUMNS, $columns)) - 1;

        $columnInfo = [];
        for ($column = $firstColumn; $column <= $lastColumn; ++$column) {
            $letter = Coordinate::stringFromColumnIndex($column);
            $dimension = $sheet->columnDimensionExists($letter) ? $sheet->getColumnDimension($letter) : null;
            $columnInfo[] = [
                'index' => $column,
                'letter' => $letter,
                'width' => $dimension !== null && $dimension->getWidth() > 0 ? $dimension->getWidth() : null,
                'hidden' => $dimension !== null && !$dimension->getVisible(),
            ];
        }

        $styles = [];
        $rowInfo = [];
        for ($row = $firstRow; $row <= $lastRow; ++$row) {
            $cells = [];
            for ($column = $firstColumn; $column <= $lastColumn; ++$column) {
                if (!$sheet->cellExists([$column, $row])) {
                    $cells[] = null;
                    continue;
                }
                $cell = $sheet->getCell([$column, $row]);
                $entry = $this->describeCell($cell);
                $xfIndex = $cell->getXfIndex();
                if ($xfIndex > 0) {
                    $styles[$xfIndex] ??= $this->describeStyle($cell);
                    if ($styles[$xfIndex] !== []) {
                        $entry['x'] = $xfIndex;
                    }
                }
                $cells[] = $entry['v'] === '' && $entry['e'] === '' && !isset($entry['x']) ? null : $entry;
            }
            $dimension = $sheet->rowDimensionExists($row) ? $sheet->getRowDimension($row) : null;
            $rowInfo[] = [
                'index' => $row,
                'height' => $dimension !== null && $dimension->getRowHeight() > 0 ? $dimension->getRowHeight() : null,
                'hidden' => $dimension !== null && !$dimension->getVisible(),
                'cells' => $cells,
            ];
        }

        return [
            'sheet' => $sheetIndex,
            'firstRow' => $firstRow,
            'firstColumn' => $firstColumn,
            'totalRows' => $sheet->getHighestDataRow(),
            'totalColumns' => Coordinate::columnIndexFromString($sheet->getHighestDataColumn()),
            'columns' => $columnInfo,
            'rows' => $rowInfo,
            'styles' => (object)array_filter($styles),
            'merges' => array_slice(array_values($sheet->getMergeCells()), 0, self::MAX_MERGES),
            'freezePane' => $sheet->getFreezePane(),
            'autoFilter' => $sheet->getAutoFilter()->getRange() ?: null,
        ];
    }

    /**
     * A summary per column of the used range: how many cells are filled, of which
     * type, the range of the numbers and dates and the most frequent values.
     *
     * @return array<string, mixed>
     */
    public function columnStatistics(Spreadsheet $spreadsheet, int $sheetIndex, bool $headerRow): array
    {
        $sheet = self::sheet($spreadsheet, $sheetIndex);
        $highestRow = $sheet->getHighestDataRow();
        $highestColumn = min(Coordinate::columnIndexFromString($sheet->getHighestDataColumn()), 1000);
        $firstRow = $headerRow ? 2 : 1;

        $columns = [];
        for ($column = 1; $column <= $highestColumn; ++$column) {
            $name = null;
            if ($headerRow && $sheet->cellExists([$column, 1])) {
                $name = trim((string)SpreadsheetIo::exportValue($sheet->getCell([$column, 1])));
            }

            $statistics = [
                'column' => Coordinate::stringFromColumnIndex($column),
                'name' => $name === '' ? null : $name,
                'filled' => 0,
                'empty' => 0,
                'numbers' => 0,
                'texts' => 0,
                'dates' => 0,
                'booleans' => 0,
                'formulas' => 0,
                'errors' => 0,
                'min' => null,
                'max' => null,
                'sum' => null,
                'average' => null,
                'firstDate' => null,
                'lastDate' => null,
                'maxLength' => null,
                'distinct' => 0,
                'distinctCapped' => false,
                'top' => [],
            ];
            $frequencies = [];

            for ($row = $firstRow; $row <= $highestRow; ++$row) {
                $cell = $sheet->cellExists([$column, $row]) ? $sheet->getCell([$column, $row]) : null;
                $value = $cell === null ? null : SpreadsheetIo::exportValue($cell);
                if ($value === null || $value === '') {
                    ++$statistics['empty'];
                    continue;
                }

                ++$statistics['filled'];
                if ($cell->getDataType() === DataType::TYPE_FORMULA) {
                    ++$statistics['formulas'];
                }

                $isNumericCell = in_array($cell->getDataType(), [DataType::TYPE_NUMERIC, DataType::TYPE_FORMULA], true);
                if (is_string($value) && $isNumericCell && Date::isDateTimeFormat($cell->getStyle()->getNumberFormat())) {
                    ++$statistics['dates'];
                    $statistics['firstDate'] = $statistics['firstDate'] === null ? $value : min($statistics['firstDate'], $value);
                    $statistics['lastDate'] = $statistics['lastDate'] === null ? $value : max($statistics['lastDate'], $value);
                } elseif (is_int($value) || is_float($value)) {
                    ++$statistics['numbers'];
                    $statistics['min'] = $statistics['min'] === null ? $value : min($statistics['min'], $value);
                    $statistics['max'] = $statistics['max'] === null ? $value : max($statistics['max'], $value);
                    $statistics['sum'] = ($statistics['sum'] ?? 0) + $value;
                } elseif (is_bool($value)) {
                    ++$statistics['booleans'];
                } elseif ($cell->getDataType() === DataType::TYPE_ERROR || is_string($value) && in_array($value, self::ERROR_VALUES, true)) {
                    ++$statistics['errors'];
                } else {
                    ++$statistics['texts'];
                    $statistics['maxLength'] = max($statistics['maxLength'] ?? 0, mb_strlen((string)$value));
                }

                $key = is_bool($value) ? ($value ? 'TRUE' : 'FALSE') : (string)$value;
                if (isset($frequencies[$key])) {
                    ++$frequencies[$key];
                } elseif (count($frequencies) < self::MAX_DISTINCT) {
                    $frequencies[$key] = 1;
                } else {
                    $statistics['distinctCapped'] = true;
                }
            }

            if ($statistics['numbers'] > 0) {
                $statistics['average'] = $statistics['sum'] / $statistics['numbers'];
            }
            $statistics['distinct'] = count($frequencies);
            arsort($frequencies);
            foreach (array_slice($frequencies, 0, self::TOP_VALUES, true) as $value => $count) {
                $statistics['top'][] = ['value' => (string)$value, 'count' => $count];
            }

            $columns[] = $statistics;
        }

        return [
            'sheet' => $sheetIndex,
            'rows' => max(0, $highestRow - $firstRow + 1),
            'headerRow' => $headerRow,
            'columns' => $columns,
        ];
    }

    /** @return array{v: string, e: string, t: string} shown value, value to edit, data type */
    private function describeCell(Cell $cell): array
    {
        $dataType = $cell->getDataType();

        try {
            $shown = $cell->getFormattedValue();
            // PhpSpreadsheet shows every digit of a double in the General format
            if ($cell->getStyle()->getNumberFormat()->getFormatCode() === NumberFormat::FORMAT_GENERAL) {
                $value = $dataType === DataType::TYPE_FORMULA ? $cell->getCalculatedValue() : $cell->getValue();
                if (is_float($value)) {
                    $shown = CellValueParser::numberToText($value);
                }
            }
        } catch (Throwable) {
            $shown = (string)($cell->getOldCalculatedValue() ?? '#ERROR');
        }

        return [
            'v' => $shown,
            'e' => self::editValue($cell),
            't' => $dataType === DataType::TYPE_NUMERIC && Date::isDateTime($cell) ? 'd' : $dataType,
        ];
    }

    /**
     * The text that, typed into the cell again, gives the same cell: formulas as
     * formulas, dates as ISO dates, and text that would be read as something else
     * (a number, a formula) behind an apostrophe.
     */
    public static function editValue(Cell $cell): string
    {
        $value = $cell->getValue();

        if ($value === null) {
            return '';
        }
        if ($value instanceof RichText) {
            $value = $value->getPlainText();
        }
        if (is_bool($value)) {
            return $value ? 'TRUE' : 'FALSE';
        }
        if ($cell->getDataType() === DataType::TYPE_FORMULA) {
            return (string)$value;
        }
        if (is_int($value) || is_float($value)) {
            if (Date::isDateTime($cell)) {
                $dateTime = Date::excelToDateTimeObject($value);
                if (floor((float)$value) === (float)$value) {
                    return $dateTime->format('Y-m-d');
                }

                return $value < 1 ? $dateTime->format('H:i:s') : $dateTime->format('Y-m-d H:i:s');
            }

            return CellValueParser::numberToText($value);
        }

        $text = (string)$value;
        if ($text !== '' && (
            $text[0] === "'"
            || DefaultValueBinder::dataTypeForValue($text) !== DataType::TYPE_STRING
            || CellValueParser::looksLikeDate($text)
            || in_array(strtoupper($text), ['TRUE', 'FALSE'], true)
        )) {
            return "'" . $text;
        }

        return $text;
    }

    /** @return array<string, mixed> only what differs from a plain cell */
    private function describeStyle(Cell $cell): array
    {
        $style = $cell->getStyle();
        $font = $style->getFont();
        $description = [];

        if ($font->getBold()) {
            $description['bold'] = true;
        }
        if ($font->getItalic()) {
            $description['italic'] = true;
        }
        if ($font->getUnderline() !== null && $font->getUnderline() !== Font::UNDERLINE_NONE) {
            $description['underline'] = true;
        }
        if ($font->getStrikethrough()) {
            $description['strike'] = true;
        }
        $fontColor = substr($font->getColor()->getRGB(), -6);
        if ($fontColor !== '' && strtoupper($fontColor) !== '000000') {
            $description['color'] = strtoupper($fontColor);
        }
        if ($style->getFill()->getFillType() === Fill::FILL_SOLID) {
            $description['fill'] = strtoupper(substr($style->getFill()->getStartColor()->getRGB(), -6));
        }
        $horizontal = $style->getAlignment()->getHorizontal();
        if ($horizontal !== null && $horizontal !== Alignment::HORIZONTAL_GENERAL) {
            $description['align'] = $horizontal;
        }
        if ($style->getAlignment()->getWrapText()) {
            $description['wrap'] = true;
        }
        $formatCode = $style->getNumberFormat()->getFormatCode();
        if ($formatCode !== null && $formatCode !== NumberFormat::FORMAT_GENERAL) {
            $description['format'] = $formatCode;
        }

        return $description;
    }
}
