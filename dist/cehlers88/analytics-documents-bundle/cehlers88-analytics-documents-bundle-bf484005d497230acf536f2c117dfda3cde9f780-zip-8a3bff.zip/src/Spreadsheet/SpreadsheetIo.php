<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\ENUM\ESpreadsheetFormat;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Cell\Cell;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Reader\BaseReader;
use PhpOffice\PhpSpreadsheet\Reader\Csv as CsvReader;
use PhpOffice\PhpSpreadsheet\Reader\Ods as OdsReader;
use PhpOffice\PhpSpreadsheet\Reader\Xls as XlsReader;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx as XlsxReader;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Shared\StringHelper;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Writer\Ods as OdsWriter;
use PhpOffice\PhpSpreadsheet\Writer\Xls as XlsWriter;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx as XlsxWriter;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Throwable;

/**
 * Reads and writes the files of the Excel-Manipulator.
 *
 * Before a file is loaded its size in cells is taken from the reader's worksheet
 * list, which only scans the file: a file that is small on disk can still unpack into
 * more than the memory limit. PhpSpreadsheet 5 needs about 600 bytes per cell to hold
 * a workbook and about as much again while writing it, so the limit is the configured
 * number of cells or what memory_limit allows, whichever is lower.
 */
final class SpreadsheetIo
{
    private const BYTES_PER_CELL = 1200;

    public function __construct(
        #[Autowire('%analytics_documents.spreadsheet.max_cells%')]
        private readonly int $maxCells,
    ) {
    }

    public function maxCells(): int
    {
        $memoryLimit = self::iniBytes((string)ini_get('memory_limit'));

        return $memoryLimit > 0 ? min($this->maxCells, intdiv($memoryLimit, self::BYTES_PER_CELL)) : $this->maxCells;
    }

    /** "512M" as bytes; 0 for no limit or an unreadable value. */
    public static function iniBytes(string $value): int
    {
        if (preg_match('/^\s*(\d+)\s*([kmg]?)\s*$/i', $value, $matches) !== 1) {
            return 0;
        }

        return (int)$matches[1] * match (strtolower($matches[2])) {
            'g' => 1073741824,
            'm' => 1048576,
            'k' => 1024,
            default => 1,
        };
    }

    public function load(string $path, ESpreadsheetFormat $format, CsvOptions $csvOptions = new CsvOptions()): LoadedSpreadsheet
    {
        if (!$format->canRead()) {
            throw new SpreadsheetToolException(sprintf('%s files cannot be opened.', strtoupper($format->value)));
        }

        $reader = $this->createReader($format, $path, $csvOptions);

        try {
            $cells = 0;
            foreach ($reader->listWorksheetInfo($path) as $info) {
                $cells += $info['totalRows'] * $info['totalColumns'];
            }
        } catch (Throwable $exception) {
            throw new SpreadsheetToolException(sprintf('The file could not be read as %s.', strtoupper($format->value)), 422, $exception);
        }
        if ($cells > $this->maxCells()) {
            throw new SpreadsheetToolException(sprintf(
                'The file has %s cells, more than the %s this tool opens.',
                number_format($cells),
                number_format($this->maxCells())
            ), 413);
        }

        try {
            $spreadsheet = $reader->load($path);
        } catch (Throwable $exception) {
            throw new SpreadsheetToolException(sprintf('The file could not be read as %s.', strtoupper($format->value)), 422, $exception);
        }

        if ($reader instanceof CsvReader) {
            // the detection names Windows-1252 by its short name
            $encoding = $reader->getInputEncoding() === 'CP1252' ? 'Windows-1252' : $reader->getInputEncoding();
            $csvOptions = new CsvOptions(
                $reader->getDelimiter(),
                $reader->getEnclosure(),
                in_array($encoding, CsvOptions::ENCODINGS, true) ? $encoding : null,
            );
        }

        return new LoadedSpreadsheet($spreadsheet, $csvOptions);
    }

    /** CSV that was pasted rather than uploaded. */
    public function loadCsvText(string $text, CsvOptions $csvOptions): LoadedSpreadsheet
    {
        $path = tempnam(sys_get_temp_dir(), 'xlsm');
        if ($path === false || file_put_contents($path, $text) === false) {
            throw new SpreadsheetToolException('The text could not be taken over.', 500);
        }

        try {
            // pasted text is UTF-8 whatever the options say
            return $this->load($path, ESpreadsheetFormat::CSV, new CsvOptions($csvOptions->delimiter, $csvOptions->enclosure, 'UTF-8'));
        } finally {
            @unlink($path);
        }
    }

    /**
     * @param int|null $sheetIndex CSV and JSON: the sheet to write, JSON writes all of them for null
     * @param bool     $headerRow  JSON: the first row names the fields of the records
     */
    public function save(
        Spreadsheet        $spreadsheet,
        string             $path,
        ESpreadsheetFormat $format,
        CsvOptions         $csvOptions = new CsvOptions(),
        ?int               $sheetIndex = null,
        bool               $headerRow = true,
        bool               $preCalculate = true,
    ): void {
        if ($sheetIndex !== null && ($sheetIndex < 0 || $sheetIndex >= $spreadsheet->getSheetCount())) {
            throw new SpreadsheetToolException('The sheet does not exist.', 404);
        }

        try {
            match ($format) {
                ESpreadsheetFormat::CSV => $this->writeCsv($spreadsheet->getSheet($sheetIndex ?? 0), $path, $csvOptions),
                ESpreadsheetFormat::JSON => $this->writeJson($spreadsheet, $path, $sheetIndex, $headerRow),
                default => $this->createWriter($spreadsheet, $format, $preCalculate)->save($path),
            };
        } catch (SpreadsheetToolException $exception) {
            throw $exception;
        } catch (Throwable $exception) {
            throw new SpreadsheetToolException(sprintf('The workbook could not be written as %s.', strtoupper($format->value)), 500, $exception);
        }
    }

    /**
     * The value of a cell the way a CSV or JSON consumer expects it: formulas
     * calculated, dates as ISO strings, rich text as plain text.
     */
    public static function exportValue(Cell $cell): mixed
    {
        try {
            $value = $cell->getCalculatedValue();
        } catch (Throwable) {
            $value = $cell->getOldCalculatedValue() ?? '#ERROR';
        }

        if ((is_int($value) || is_float($value)) && Date::isDateTime($cell, $value)) {
            $dateTime = Date::excelToDateTimeObject($value);
            $formatCode = $cell->getStyle()->getNumberFormat()->getFormatCode();

            if (floor((float)$value) === (float)$value) {
                return $dateTime->format('Y-m-d');
            }

            return $value < 1 && !preg_match('/[dy]/i', $formatCode)
                ? $dateTime->format('H:i:s')
                : $dateTime->format('Y-m-d\TH:i:s');
        }

        if (is_object($value) && method_exists($value, 'getPlainText')) {
            return $value->getPlainText();
        }

        return $value;
    }

    private function createReader(ESpreadsheetFormat $format, string $path, CsvOptions $csvOptions): BaseReader
    {
        $reader = match ($format) {
            ESpreadsheetFormat::XLSX => new XlsxReader(),
            ESpreadsheetFormat::XLS => new XlsReader(),
            ESpreadsheetFormat::ODS => new OdsReader(),
            ESpreadsheetFormat::CSV => new CsvReader(),
            default => throw new SpreadsheetToolException('Unsupported format.'),
        };

        if ($reader instanceof CsvReader) {
            $reader->setDelimiter($csvOptions->delimiter);
            $reader->setEnclosure($csvOptions->enclosure);
            $reader->setInputEncoding($csvOptions->encoding ?? CsvReader::guessEncoding($path));
        } else {
            $reader->setReadEmptyCells(false);
            $reader->setIncludeCharts(true);
        }

        return $reader;
    }

    private function createWriter(Spreadsheet $spreadsheet, ESpreadsheetFormat $format, bool $preCalculate): XlsxWriter|XlsWriter|OdsWriter
    {
        $writer = match ($format) {
            ESpreadsheetFormat::XLSX => new XlsxWriter($spreadsheet),
            ESpreadsheetFormat::XLS => new XlsWriter($spreadsheet),
            ESpreadsheetFormat::ODS => new OdsWriter($spreadsheet),
            default => throw new SpreadsheetToolException('Unsupported format.'),
        };
        $writer->setPreCalculateFormulas($preCalculate);
        if ($writer instanceof XlsxWriter) {
            $writer->setIncludeCharts(true);
        }

        return $writer;
    }

    /**
     * Written by hand instead of with PhpSpreadsheet's CSV writer, which knows
     * neither a decimal comma nor dates in a form other programs read back.
     */
    private function writeCsv(Worksheet $sheet, string $path, CsvOptions $options): void
    {
        $handle = fopen('php://temp', 'w+b');
        if ($handle === false) {
            throw new SpreadsheetToolException('The CSV file could not be written.', 500);
        }

        $highestRow = $sheet->getHighestDataRow();
        $highestColumn = Coordinate::columnIndexFromString($sheet->getHighestDataColumn());
        $delimiter = $options->delimiter ?? ';';

        // the separators are static in PhpSpreadsheet - formatted numbers follow them
        $decimalSeparator = StringHelper::getDecimalSeparator();
        $thousandsSeparator = StringHelper::getThousandsSeparator();
        StringHelper::setDecimalSeparator($options->decimalSeparator);
        StringHelper::setThousandsSeparator($options->decimalSeparator === ',' ? '.' : ',');

        try {
            for ($row = 1; $row <= $highestRow; ++$row) {
                $line = [];
                for ($column = 1; $column <= $highestColumn; ++$column) {
                    $line[] = $sheet->cellExists([$column, $row])
                        ? $this->csvValue($sheet->getCell([$column, $row]), $options)
                        : '';
                }
                fputcsv($handle, $line, $delimiter, $options->enclosure, '', "\r\n");
            }
        } finally {
            StringHelper::setDecimalSeparator($decimalSeparator);
            StringHelper::setThousandsSeparator($thousandsSeparator);
        }

        rewind($handle);
        $content = (string)stream_get_contents($handle);
        fclose($handle);

        $encoding = $options->encoding ?? 'UTF-8';
        if ($encoding !== 'UTF-8') {
            $content = (string)mb_convert_encoding($content, $encoding, 'UTF-8');
        }
        if ($options->useBom) {
            $content = match ($encoding) {
                'UTF-8' => "\xEF\xBB\xBF",
                'UTF-16LE' => "\xFF\xFE",
                default => '',
            } . $content;
        }

        if (file_put_contents($path, $content) === false) {
            throw new SpreadsheetToolException('The CSV file could not be written.', 500);
        }
    }

    private function csvValue(Cell $cell, CsvOptions $options): string
    {
        $value = self::exportValue($cell);

        if (is_bool($value)) {
            return $value ? 'TRUE' : 'FALSE';
        }
        if (is_int($value) || is_float($value)) {
            // plain numbers are written in full precision, formatted ones as they are shown
            if ($cell->getStyle()->getNumberFormat()->getFormatCode() !== NumberFormat::FORMAT_GENERAL) {
                return $cell->getFormattedValue();
            }
            $text = CellValueParser::numberToText($value);

            return $options->decimalSeparator === ',' ? str_replace('.', ',', $text) : $text;
        }

        return (string)$value;
    }

    private function writeJson(Spreadsheet $spreadsheet, string $path, ?int $sheetIndex, bool $headerRow): void
    {
        if ($sheetIndex !== null) {
            $data = $this->sheetRecords($spreadsheet->getSheet($sheetIndex), $headerRow);
        } else {
            $data = [];
            foreach ($spreadsheet->getWorksheetIterator() as $sheet) {
                $data[$sheet->getTitle()] = $this->sheetRecords($sheet, $headerRow);
            }
        }

        $json = json_encode(
            $data,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR
        );

        if (file_put_contents($path, $json) === false) {
            throw new SpreadsheetToolException('The JSON file could not be written.', 500);
        }
    }

    /** @return list<array<int|string, mixed>> */
    private function sheetRecords(Worksheet $sheet, bool $headerRow): array
    {
        $highestRow = $sheet->getHighestDataRow();
        $highestColumn = Coordinate::columnIndexFromString($sheet->getHighestDataColumn());

        $keys = [];
        for ($column = 1; $column <= $highestColumn; ++$column) {
            $keys[$column] = $column - 1;
        }

        $firstRow = 1;
        if ($headerRow) {
            $keys = [];
            $used = [];
            for ($column = 1; $column <= $highestColumn; ++$column) {
                $name = trim((string)($sheet->cellExists([$column, 1]) ? self::exportValue($sheet->getCell([$column, 1])) : ''));
                if ($name === '') {
                    $name = Coordinate::stringFromColumnIndex($column);
                }
                $unique = $name;
                for ($suffix = 2; isset($used[$unique]); ++$suffix) {
                    $unique = $name . '_' . $suffix;
                }
                $used[$unique] = true;
                $keys[$column] = $unique;
            }
            $firstRow = 2;
        }

        $records = [];
        for ($row = $firstRow; $row <= $highestRow; ++$row) {
            $record = [];
            for ($column = 1; $column <= $highestColumn; ++$column) {
                $record[$keys[$column]] = $sheet->cellExists([$column, $row])
                    ? self::exportValue($sheet->getCell([$column, $row]))
                    : null;
            }
            $records[] = $record;
        }

        return $records;
    }
}
