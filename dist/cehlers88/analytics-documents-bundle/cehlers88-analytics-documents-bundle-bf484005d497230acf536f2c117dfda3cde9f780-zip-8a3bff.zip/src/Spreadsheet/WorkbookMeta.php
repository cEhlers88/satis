<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\ENUM\ESpreadsheetFormat;
use DateTimeImmutable;
use DateTimeInterface;

/**
 * What the Excel-Manipulator keeps next to a working copy: its name, where it came
 * from and a revision that counts the changes, so a client that edits an outdated
 * state (a second tab) is refused instead of writing into shifted rows.
 */
final readonly class WorkbookMeta
{
    public function __construct(
        public string             $id,
        public string             $name,
        public ESpreadsheetFormat $sourceFormat,
        public CsvOptions         $csvOptions,
        public DateTimeImmutable  $createdAt,
        public DateTimeImmutable  $updatedAt,
        public int                $revision = 0,
        public int                $undoSteps = 0,
        public int                $fileSize = 0,
    ) {
    }

    public function with(
        ?string            $name = null,
        ?DateTimeImmutable $updatedAt = null,
        ?int               $revision = null,
        ?int               $undoSteps = null,
        ?int               $fileSize = null,
    ): self {
        return new self(
            $this->id,
            $name ?? $this->name,
            $this->sourceFormat,
            $this->csvOptions,
            $this->createdAt,
            $updatedAt ?? $this->updatedAt,
            $revision ?? $this->revision,
            $undoSteps ?? $this->undoSteps,
            $fileSize ?? $this->fileSize,
        );
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'sourceFormat' => $this->sourceFormat->value,
            'csvOptions' => $this->csvOptions->toArray(),
            'createdAt' => $this->createdAt->format(DateTimeInterface::ATOM),
            'updatedAt' => $this->updatedAt->format(DateTimeInterface::ATOM),
            'revision' => $this->revision,
            'undoSteps' => $this->undoSteps,
            'fileSize' => $this->fileSize,
        ];
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): ?self
    {
        try {
            return new self(
                (string)$data['id'],
                (string)$data['name'],
                ESpreadsheetFormat::from((string)$data['sourceFormat']),
                CsvOptions::fromArray(is_array($data['csvOptions'] ?? null) ? $data['csvOptions'] : []),
                new DateTimeImmutable((string)$data['createdAt']),
                new DateTimeImmutable((string)$data['updatedAt']),
                (int)($data['revision'] ?? 0),
            );
        } catch (\Throwable) {
            return null;
        }
    }
}
