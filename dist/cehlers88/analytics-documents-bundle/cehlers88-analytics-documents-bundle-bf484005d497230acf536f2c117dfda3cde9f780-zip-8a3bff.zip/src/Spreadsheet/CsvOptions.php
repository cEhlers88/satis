<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;

/**
 * How a CSV file is read or written. Only a closed set of delimiters and encodings
 * is accepted - they end up in iconv/mbstring calls, and a free text there would
 * only produce files nobody can open.
 */
final readonly class CsvOptions
{
    public const DELIMITERS = [',', ';', "\t", '|', ':'];
    public const ENCLOSURES = ['"', "'"];
    public const ENCODINGS = ['UTF-8', 'UTF-16LE', 'Windows-1252', 'ISO-8859-1', 'ISO-8859-15'];
    public const DECIMAL_SEPARATORS = ['.', ','];

    /**
     * @param string|null $delimiter        null: detected on reading, ";" on writing
     * @param string|null $encoding         null: detected on reading, UTF-8 on writing
     * @param string      $decimalSeparator writing only: how plain numbers are written
     */
    public function __construct(
        public ?string $delimiter = null,
        public string  $enclosure = '"',
        public ?string $encoding = null,
        public bool    $useBom = false,
        public string  $decimalSeparator = '.',
    ) {
        if ($delimiter !== null && !in_array($delimiter, self::DELIMITERS, true)) {
            throw new SpreadsheetToolException('Unsupported CSV delimiter.');
        }
        if (!in_array($enclosure, self::ENCLOSURES, true)) {
            throw new SpreadsheetToolException('Unsupported CSV enclosure.');
        }
        if ($encoding !== null && !in_array($encoding, self::ENCODINGS, true)) {
            throw new SpreadsheetToolException('Unsupported CSV encoding.');
        }
        if (!in_array($decimalSeparator, self::DECIMAL_SEPARATORS, true)) {
            throw new SpreadsheetToolException('Unsupported decimal separator.');
        }
    }

    /**
     * Reads the options from request parameters; empty values and "auto" mean
     * "detect", "tab" is accepted for the tab character.
     *
     * @param array<string, mixed> $values
     */
    public static function fromArray(array $values): self
    {
        $text = static function (string $key) use ($values): ?string {
            $value = $values[$key] ?? null;
            if ($value === null || $value === '' || $value === 'auto') {
                return null;
            }
            if (!is_string($value)) {
                throw new SpreadsheetToolException(sprintf('"%s" must be a string.', $key));
            }

            return $value;
        };

        $delimiter = $text('delimiter');
        if ($delimiter === 'tab' || $delimiter === '\t') {
            $delimiter = "\t";
        }

        return new self(
            $delimiter,
            $text('enclosure') ?? '"',
            $text('encoding'),
            filter_var($values['bom'] ?? false, FILTER_VALIDATE_BOOL),
            $text('decimalSeparator') ?? '.',
        );
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'delimiter' => $this->delimiter === "\t" ? 'tab' : $this->delimiter,
            'enclosure' => $this->enclosure,
            'encoding' => $this->encoding,
            'bom' => $this->useBom,
            'decimalSeparator' => $this->decimalSeparator,
        ];
    }
}
