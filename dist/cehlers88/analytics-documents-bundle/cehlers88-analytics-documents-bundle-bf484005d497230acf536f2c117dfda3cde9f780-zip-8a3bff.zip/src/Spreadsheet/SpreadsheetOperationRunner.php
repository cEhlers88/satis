<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\OperationArguments;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\SpreadsheetOperationInterface;
use PhpOffice\PhpSpreadsheet\Exception as PhpSpreadsheetException;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use Symfony\Component\DependencyInjection\Attribute\AutowireIterator;
use Throwable;

/**
 * Applies a list of operations to a workbook, one after the other. The storage
 * keeps the workbook only when all of them went through, so a list is all or
 * nothing - and a single undo step.
 */
final class SpreadsheetOperationRunner
{
    public const MAX_OPERATIONS = 100;

    /** @var array<string, SpreadsheetOperationInterface> */
    private array $operations = [];

    /** @param iterable<SpreadsheetOperationInterface> $operations */
    public function __construct(
        #[AutowireIterator('analytics_documents.spreadsheet_operation')]
        iterable $operations,
    ) {
        foreach ($operations as $operation) {
            $this->operations[$operation->getName()] = $operation;
        }
        ksort($this->operations);
    }

    /** @return list<string> */
    public function names(): array
    {
        return array_keys($this->operations);
    }

    /**
     * @param list<mixed> $operations each {"type": "…", …arguments}
     * @return list<array<string, mixed>> the result of every operation
     */
    public function apply(Spreadsheet $spreadsheet, array $operations): array
    {
        if ($operations === [] || !array_is_list($operations)) {
            throw new SpreadsheetToolException('"operations" must be a non-empty list.');
        }
        if (count($operations) > self::MAX_OPERATIONS) {
            throw new SpreadsheetToolException(sprintf('At most %d operations can be sent at once.', self::MAX_OPERATIONS));
        }

        $results = [];
        foreach ($operations as $position => $definition) {
            $type = is_array($definition) ? ($definition['type'] ?? null) : null;
            if (!is_string($type) || !isset($this->operations[$type])) {
                throw new SpreadsheetToolException(sprintf('Operation %d: unknown type.', $position + 1));
            }

            try {
                $result = $this->operations[$type]->apply($spreadsheet, new OperationArguments($definition));
            } catch (SpreadsheetToolException $exception) {
                throw new SpreadsheetToolException(sprintf('%s: %s', $type, $exception->getMessage()), $exception->getStatusCode(), $exception);
            } catch (PhpSpreadsheetException $exception) {
                // PhpSpreadsheet's own messages ("Invalid cell coordinate …") say what went wrong
                throw new SpreadsheetToolException(sprintf('%s: %s', $type, $exception->getMessage()), 422, $exception);
            } catch (Throwable $exception) {
                // anything else may name files of the server
                throw new SpreadsheetToolException(sprintf('%s failed.', $type), 500, $exception);
            }

            $results[] = ['type' => $type, ...$result];
        }

        return $results;
    }
}
