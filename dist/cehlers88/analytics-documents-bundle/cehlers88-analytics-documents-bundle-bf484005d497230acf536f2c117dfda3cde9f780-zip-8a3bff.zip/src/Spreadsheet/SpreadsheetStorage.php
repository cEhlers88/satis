<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\ENUM\ESpreadsheetFormat;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\WorkbookNotFoundException;
use DateTimeImmutable;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Throwable;

/**
 * Keeps the working copies of the Excel-Manipulator, one directory per user:
 *
 *     {directory}/{userId}/{workbookId}/meta.json          name, source, revision
 *     {directory}/{userId}/{workbookId}/workbook.xlsx      the current state
 *     {directory}/{userId}/{workbookId}/history/{n}.xlsx   the states before, for undo
 *
 * Whatever was uploaded is kept as XLSX - it is the format PhpSpreadsheet reads back
 * with the least loss - and the source format is only remembered as the default for
 * the export. Ids are random hex strings and checked before they become part of a
 * path. Every change runs under an exclusive lock of its workbook and replaces the
 * file by renaming a temporary one, so a reader never sees half a workbook.
 *
 * Working copies are scratch space, not an archive: whatever was not touched for
 * the retention period is removed the next time the user lists their workbooks.
 */
final class SpreadsheetStorage
{
    public const MAX_NAME_LENGTH = 120;
    private const ID_PATTERN = '/^[a-f0-9]{16}$/D';
    private const META_FILE = 'meta.json';
    private const WORKBOOK_FILE = 'workbook.xlsx';
    private const HISTORY_DIRECTORY = 'history';
    private const LOCK_FILE = '.lock';

    public function __construct(
        private readonly SpreadsheetIo $io,
        #[Autowire('%analytics_documents.spreadsheet.directory%')]
        private readonly string        $directory,
        #[Autowire('%analytics_documents.spreadsheet.max_workbooks%')]
        private readonly int           $maxWorkbooks,
        #[Autowire('%analytics_documents.spreadsheet.undo_steps%')]
        private readonly int           $undoSteps,
        #[Autowire('%analytics_documents.spreadsheet.retention_days%')]
        private readonly int           $retentionDays,
    ) {
    }

    /** @return list<WorkbookMeta> the most recently changed first */
    public function list(int $userId): array
    {
        $directory = $this->userDirectory($userId);
        $expiredBefore = new DateTimeImmutable(sprintf('-%d days', max(1, $this->retentionDays)));
        $workbooks = [];

        foreach (is_dir($directory) ? (scandir($directory) ?: []) : [] as $entry) {
            if (!$this->isId($entry)) {
                continue;
            }
            $meta = $this->readMeta($directory . '/' . $entry);
            if ($meta === null) {
                continue;
            }
            if ($meta->updatedAt < $expiredBefore) {
                $this->removeDirectory($directory . '/' . $entry);
                continue;
            }
            $workbooks[] = $meta;
        }

        usort($workbooks, static fn(WorkbookMeta $left, WorkbookMeta $right): int => $right->updatedAt <=> $left->updatedAt);

        return $workbooks;
    }

    public function create(int $userId, string $name, Spreadsheet $spreadsheet, ESpreadsheetFormat $sourceFormat, CsvOptions $csvOptions): WorkbookMeta
    {
        if (count($this->list($userId)) >= $this->maxWorkbooks) {
            throw new SpreadsheetToolException(sprintf('At most %d workbooks can be open at a time - delete one first.', $this->maxWorkbooks), 409);
        }

        $id = bin2hex(random_bytes(8));
        $workbookDirectory = $this->userDirectory($userId) . '/' . $id;
        $this->ensureDirectory($workbookDirectory . '/' . self::HISTORY_DIRECTORY);

        $now = new DateTimeImmutable();
        $meta = new WorkbookMeta($id, self::normalizeName($name), $sourceFormat, $csvOptions, $now, $now);

        try {
            $this->writeWorkbook($workbookDirectory, $spreadsheet);
            $this->writeMeta($workbookDirectory, $meta);
        } catch (Throwable $exception) {
            $this->removeDirectory($workbookDirectory);
            throw $exception;
        }

        return $this->completeMeta($workbookDirectory, $meta);
    }

    public function get(int $userId, string $workbookId): WorkbookMeta
    {
        $workbookDirectory = $this->workbookDirectory($userId, $workbookId);
        $meta = $this->readMeta($workbookDirectory);
        if ($meta === null) {
            throw new WorkbookNotFoundException();
        }

        return $this->completeMeta($workbookDirectory, $meta);
    }

    public function open(int $userId, string $workbookId): Spreadsheet
    {
        $workbookDirectory = $this->workbookDirectory($userId, $workbookId);
        if (!is_file($workbookDirectory . '/' . self::WORKBOOK_FILE)) {
            throw new WorkbookNotFoundException();
        }

        return $this->io->load($workbookDirectory . '/' . self::WORKBOOK_FILE, ESpreadsheetFormat::XLSX)->spreadsheet;
    }

    /**
     * Loads the workbook, hands it to $change and keeps the result - with the state
     * before as an undo step. Nothing is written when $change throws.
     *
     * @template T
     * @param callable(Spreadsheet): T $change
     * @param int|null $expectedRevision the revision the client worked on, null skips the check
     * @return array{WorkbookMeta, T}
     */
    public function modify(int $userId, string $workbookId, callable $change, ?int $expectedRevision = null): array
    {
        $workbookDirectory = $this->workbookDirectory($userId, $workbookId);

        return $this->locked($workbookDirectory, function () use ($workbookDirectory, $change, $expectedRevision): array {
            $meta = $this->readMeta($workbookDirectory) ?? throw new WorkbookNotFoundException();
            if ($expectedRevision !== null && $expectedRevision !== $meta->revision) {
                throw new SpreadsheetToolException('The workbook was changed elsewhere in the meantime - reload it first.', 409);
            }

            $spreadsheet = $this->io->load($workbookDirectory . '/' . self::WORKBOOK_FILE, ESpreadsheetFormat::XLSX)->spreadsheet;
            $result = $change($spreadsheet);

            $historyFile = sprintf('%s/%s/%010d.xlsx', $workbookDirectory, self::HISTORY_DIRECTORY, $meta->revision);
            $this->ensureDirectory(dirname($historyFile));
            if (!copy($workbookDirectory . '/' . self::WORKBOOK_FILE, $historyFile)) {
                throw new SpreadsheetToolException('The undo step could not be kept.', 500);
            }

            $this->writeWorkbook($workbookDirectory, $spreadsheet);
            $meta = $meta->with(updatedAt: new DateTimeImmutable(), revision: $meta->revision + 1);
            $this->writeMeta($workbookDirectory, $meta);
            $this->trimHistory($workbookDirectory);

            return [$this->completeMeta($workbookDirectory, $meta), $result];
        });
    }

    /** Takes back the latest change. */
    public function undo(int $userId, string $workbookId): WorkbookMeta
    {
        $workbookDirectory = $this->workbookDirectory($userId, $workbookId);

        return $this->locked($workbookDirectory, function () use ($workbookDirectory): WorkbookMeta {
            $meta = $this->readMeta($workbookDirectory) ?? throw new WorkbookNotFoundException();
            $history = $this->historyFiles($workbookDirectory);
            if ($history === []) {
                throw new SpreadsheetToolException('There is nothing to undo.', 409);
            }

            if (!rename(array_pop($history), $workbookDirectory . '/' . self::WORKBOOK_FILE)) {
                throw new SpreadsheetToolException('The change could not be taken back.', 500);
            }
            // the revision keeps counting up: a client on the undone state must reload as well
            $meta = $meta->with(updatedAt: new DateTimeImmutable(), revision: $meta->revision + 1);
            $this->writeMeta($workbookDirectory, $meta);

            return $this->completeMeta($workbookDirectory, $meta);
        });
    }

    public function rename(int $userId, string $workbookId, string $name): WorkbookMeta
    {
        $workbookDirectory = $this->workbookDirectory($userId, $workbookId);

        return $this->locked($workbookDirectory, function () use ($workbookDirectory, $name): WorkbookMeta {
            $meta = $this->readMeta($workbookDirectory) ?? throw new WorkbookNotFoundException();
            $meta = $meta->with(name: self::normalizeName($name), updatedAt: new DateTimeImmutable());
            $this->writeMeta($workbookDirectory, $meta);

            return $this->completeMeta($workbookDirectory, $meta);
        });
    }

    public function delete(int $userId, string $workbookId): void
    {
        $workbookDirectory = $this->workbookDirectory($userId, $workbookId);
        if (!is_file($workbookDirectory . '/' . self::META_FILE)) {
            throw new WorkbookNotFoundException();
        }

        $this->removeDirectory($workbookDirectory);
    }

    public static function normalizeName(string $name): string
    {
        $name = trim((string)preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $name));
        if ($name === '') {
            return 'Workbook';
        }

        return mb_substr($name, 0, self::MAX_NAME_LENGTH);
    }

    private function userDirectory(int $userId): string
    {
        if ($userId < 1) {
            throw new SpreadsheetToolException('Unknown user.', 403);
        }

        return rtrim($this->directory, '/') . '/' . $userId;
    }

    private function workbookDirectory(int $userId, string $workbookId): string
    {
        if (!$this->isId($workbookId)) {
            throw new WorkbookNotFoundException();
        }

        $workbookDirectory = $this->userDirectory($userId) . '/' . $workbookId;
        if (!is_dir($workbookDirectory)) {
            throw new WorkbookNotFoundException();
        }

        return $workbookDirectory;
    }

    private function isId(string $value): bool
    {
        return preg_match(self::ID_PATTERN, $value) === 1;
    }

    private function completeMeta(string $workbookDirectory, WorkbookMeta $meta): WorkbookMeta
    {
        return $meta->with(
            undoSteps: count($this->historyFiles($workbookDirectory)),
            fileSize: (int)@filesize($workbookDirectory . '/' . self::WORKBOOK_FILE),
        );
    }

    private function readMeta(string $workbookDirectory): ?WorkbookMeta
    {
        $content = @file_get_contents($workbookDirectory . '/' . self::META_FILE);
        if ($content === false) {
            return null;
        }

        $data = json_decode($content, true);
        $meta = is_array($data) ? WorkbookMeta::fromArray($data) : null;

        return $meta !== null && $meta->id === basename($workbookDirectory) ? $meta : null;
    }

    private function writeMeta(string $workbookDirectory, WorkbookMeta $meta): void
    {
        $data = $meta->toArray();
        unset($data['undoSteps'], $data['fileSize']);

        $this->replaceFile(
            $workbookDirectory . '/' . self::META_FILE,
            static fn(string $path) => file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)) !== false
        );
    }

    private function writeWorkbook(string $workbookDirectory, Spreadsheet $spreadsheet): void
    {
        $this->replaceFile(
            $workbookDirectory . '/' . self::WORKBOOK_FILE,
            function (string $path) use ($spreadsheet): bool {
                // formulas are calculated when they are shown or exported, not on every save
                $this->io->save($spreadsheet, $path, ESpreadsheetFormat::XLSX, preCalculate: false);

                return true;
            }
        );
    }

    /** @param callable(string): bool $write */
    private function replaceFile(string $path, callable $write): void
    {
        $temporary = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';

        try {
            if (!$write($temporary) || !rename($temporary, $path)) {
                throw new SpreadsheetToolException('The workbook could not be saved.', 500);
            }
        } finally {
            if (is_file($temporary)) {
                @unlink($temporary);
            }
        }
    }

    /** @return list<string> oldest first */
    private function historyFiles(string $workbookDirectory): array
    {
        $files = glob($workbookDirectory . '/' . self::HISTORY_DIRECTORY . '/*.xlsx') ?: [];
        sort($files);

        return $files;
    }

    private function trimHistory(string $workbookDirectory): void
    {
        $files = $this->historyFiles($workbookDirectory);
        foreach (array_slice($files, 0, max(0, count($files) - $this->undoSteps)) as $file) {
            @unlink($file);
        }
    }

    /**
     * @template T
     * @param callable(): T $callback
     * @return T
     */
    private function locked(string $workbookDirectory, callable $callback): mixed
    {
        $handle = fopen($workbookDirectory . '/' . self::LOCK_FILE, 'c');
        if ($handle === false || !flock($handle, LOCK_EX)) {
            throw new SpreadsheetToolException('The workbook is busy, try again.', 503);
        }

        try {
            return $callback();
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }

    private function ensureDirectory(string $directory): void
    {
        if (!is_dir($directory) && !mkdir($directory, 0770, true) && !is_dir($directory)) {
            throw new SpreadsheetToolException('The storage directory could not be created.', 500);
        }
    }

    private function removeDirectory(string $directory): void
    {
        if (!is_dir($directory)) {
            return;
        }

        foreach (scandir($directory) ?: [] as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $path = $directory . '/' . $entry;
            is_dir($path) && !is_link($path) ? $this->removeDirectory($path) : @unlink($path);
        }
        @rmdir($directory);
    }
}
