<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet;

use PhpOffice\PhpSpreadsheet\Spreadsheet;

/** A loaded file together with the CSV options that were detected while reading it. */
final readonly class LoadedSpreadsheet
{
    public function __construct(
        public Spreadsheet $spreadsheet,
        public CsvOptions  $csvOptions,
    ) {
    }
}
