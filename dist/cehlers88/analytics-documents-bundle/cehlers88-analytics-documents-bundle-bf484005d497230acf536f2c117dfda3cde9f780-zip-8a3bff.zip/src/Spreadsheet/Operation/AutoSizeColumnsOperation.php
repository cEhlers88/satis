<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * {"type": "autoSizeColumns", "sheet": 0, "range": "A:F", "width": null}
 *
 * Without a width the columns are sized to their content, with one (in characters)
 * they all get that width.
 */
final class AutoSizeColumnsOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'autoSizeColumns';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        [$firstColumn, , $lastColumn] = $arguments->range($sheet);
        $width = $arguments->has('width') ? $arguments->int('width', null, 1, 255) : null;

        for ($column = $firstColumn; $column <= $lastColumn; ++$column) {
            $dimension = $sheet->getColumnDimension(Coordinate::stringFromColumnIndex($column));
            if ($width === null) {
                $dimension->setAutoSize(true);
            } else {
                $dimension->setAutoSize(false)->setWidth($width);
            }
        }
        if ($width === null) {
            $sheet->calculateColumnWidths();
        }

        return ['columns' => $lastColumn - $firstColumn + 1];
    }
}
