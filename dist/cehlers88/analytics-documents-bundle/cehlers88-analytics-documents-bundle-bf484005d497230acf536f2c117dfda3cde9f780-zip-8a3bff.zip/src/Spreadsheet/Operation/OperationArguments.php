<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\SpreadsheetInspector;
use PhpOffice\PhpSpreadsheet\Cell\AddressRange;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

/**
 * The arguments of an operation as the client sent them, read with a type and
 * checked on the way - an operation never sees an unchecked value.
 */
final readonly class OperationArguments
{
    /** Larger ranges are refused - an operation walks every cell of its range. */
    public const MAX_RANGE_CELLS = 500_000;

    /** @param array<string, mixed> $values */
    public function __construct(private array $values)
    {
    }

    public function has(string $key): bool
    {
        return array_key_exists($key, $this->values) && $this->values[$key] !== null;
    }

    public function sheet(Spreadsheet $spreadsheet, string $key = 'sheet'): Worksheet
    {
        return SpreadsheetInspector::sheet($spreadsheet, $this->int($key, 0, 0));
    }

    public function string(string $key, ?string $default = null, int $maxLength = 32767): string
    {
        $value = $this->values[$key] ?? $default;
        if (is_int($value) || is_float($value)) {
            $value = (string)$value;
        }
        if (!is_string($value)) {
            throw new SpreadsheetToolException(sprintf('"%s" is missing or not a text.', $key));
        }
        if (mb_strlen($value) > $maxLength) {
            throw new SpreadsheetToolException(sprintf('"%s" is longer than %d characters.', $key, $maxLength));
        }

        return $value;
    }

    public function int(string $key, ?int $default = null, int $min = PHP_INT_MIN, int $max = PHP_INT_MAX): int
    {
        $value = $this->values[$key] ?? $default;
        if (is_string($value) && preg_match('/^-?\d+$/D', $value) === 1) {
            $value = (int)$value;
        }
        if (!is_int($value)) {
            throw new SpreadsheetToolException(sprintf('"%s" is missing or not a whole number.', $key));
        }
        if ($value < $min || $value > $max) {
            throw new SpreadsheetToolException(sprintf('"%s" must be between %d and %d.', $key, $min, $max));
        }

        return $value;
    }

    public function bool(string $key, bool $default = false): bool
    {
        $value = $this->values[$key] ?? $default;
        if (!is_bool($value)) {
            throw new SpreadsheetToolException(sprintf('"%s" must be true or false.', $key));
        }

        return $value;
    }

    /**
     * @template T of string
     * @param list<T> $allowed
     * @return T
     */
    public function choice(string $key, array $allowed, ?string $default = null): string
    {
        $value = $this->values[$key] ?? $default;
        if (!in_array($value, $allowed, true)) {
            throw new SpreadsheetToolException(sprintf('"%s" must be one of: %s.', $key, implode(', ', $allowed)));
        }

        return $value;
    }

    /** @return list<mixed> */
    public function list(string $key, int $maxItems): array
    {
        $value = $this->values[$key] ?? [];
        if (!is_array($value) || !array_is_list($value)) {
            throw new SpreadsheetToolException(sprintf('"%s" must be a list.', $key));
        }
        if (count($value) > $maxItems) {
            throw new SpreadsheetToolException(sprintf('"%s" has more than %d entries.', $key, $maxItems));
        }

        return $value;
    }

    /** A column as letter ("C") or index (3), returned as index. */
    public function column(string $key, int|string|null $default = null): int
    {
        return self::columnIndex($this->values[$key] ?? $default, $key);
    }

    public function row(string $key, ?int $default = null): int
    {
        return $this->int($key, $default, 1, AddressRange::MAX_ROW);
    }

    /** A hex colour "RRGGBB" (with or without #), null for none. */
    public function color(string $key): ?string
    {
        $value = $this->values[$key] ?? null;
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_string($value) || preg_match('/^#?([0-9a-fA-F]{6})$/D', $value, $matches) !== 1) {
            throw new SpreadsheetToolException(sprintf('"%s" must be a colour like #1F4E79.', $key));
        }

        return strtoupper($matches[1]);
    }

    /**
     * A cell range: "A1:C5", "B2", whole columns "A:C" or whole rows "2:4" - the
     * latter two limited to the used part of the sheet. Without a value the used
     * range of the sheet is taken.
     *
     * @return array{int, int, int, int} first column, first row, last column, last row
     */
    public function range(Worksheet $sheet, string $key = 'range', bool $required = false): array
    {
        $value = $this->values[$key] ?? null;
        $lastUsedColumn = Coordinate::columnIndexFromString($sheet->getHighestDataColumn());
        $lastUsedRow = $sheet->getHighestDataRow();

        if ($value === null || $value === '') {
            if ($required) {
                throw new SpreadsheetToolException(sprintf('"%s" is missing.', $key));
            }

            return [1, 1, $lastUsedColumn, $lastUsedRow];
        }
        if (!is_string($value)) {
            throw new SpreadsheetToolException(sprintf('"%s" must be a range like A1:C5.', $key));
        }

        $value = strtoupper(str_replace('$', '', trim($value)));
        $parts = explode(':', $value);
        if (count($parts) === 1) {
            $parts[] = $parts[0];
        }
        if (count($parts) !== 2) {
            throw new SpreadsheetToolException(sprintf('"%s" must be a range like A1:C5.', $key));
        }

        if (preg_match('/^[A-Z]{1,3}$/D', $parts[0]) === 1 && preg_match('/^[A-Z]{1,3}$/D', $parts[1]) === 1) {
            $range = [self::columnIndex($parts[0], $key), 1, self::columnIndex($parts[1], $key), max(1, $lastUsedRow)];
        } elseif (preg_match('/^\d+$/D', $parts[0]) === 1 && preg_match('/^\d+$/D', $parts[1]) === 1) {
            $range = [1, (int)$parts[0], max(1, $lastUsedColumn), (int)$parts[1]];
        } elseif (preg_match('/^[A-Z]{1,3}\d+$/D', $parts[0]) === 1 && preg_match('/^[A-Z]{1,3}\d+$/D', $parts[1]) === 1) {
            [$firstColumn, $firstRow] = Coordinate::indexesFromString($parts[0]);
            [$lastColumn, $lastRow] = Coordinate::indexesFromString($parts[1]);
            $range = [$firstColumn, $firstRow, $lastColumn, $lastRow];
        } else {
            throw new SpreadsheetToolException(sprintf('"%s" must be a range like A1:C5.', $key));
        }

        [$firstColumn, $firstRow, $lastColumn, $lastRow] = $range;
        $range = [min($firstColumn, $lastColumn), min($firstRow, $lastRow), max($firstColumn, $lastColumn), max($firstRow, $lastRow)];
        if ($range[0] < 1 || $range[2] > AddressRange::MAX_COLUMN_INT || $range[1] < 1 || $range[3] > AddressRange::MAX_ROW) {
            throw new SpreadsheetToolException(sprintf('"%s" lies outside of a sheet.', $key));
        }
        if (($range[2] - $range[0] + 1) * ($range[3] - $range[1] + 1) > self::MAX_RANGE_CELLS) {
            throw new SpreadsheetToolException(sprintf('"%s" covers more than %s cells.', $key, number_format(self::MAX_RANGE_CELLS)));
        }

        return $range;
    }

    /** @param array{int, int, int, int} $range */
    public static function rangeString(array $range): string
    {
        return Coordinate::stringFromColumnIndex($range[0]) . $range[1] . ':' . Coordinate::stringFromColumnIndex($range[2]) . $range[3];
    }

    public static function columnIndex(mixed $value, string $key = 'column'): int
    {
        if (is_string($value) && preg_match('/^\d+$/D', $value) === 1) {
            $value = (int)$value;
        }
        if (is_string($value) && preg_match('/^[A-Za-z]{1,3}$/D', $value) === 1) {
            $value = Coordinate::columnIndexFromString(strtoupper($value));
        }
        if (!is_int($value) || $value < 1 || $value > AddressRange::MAX_COLUMN_INT) {
            throw new SpreadsheetToolException(sprintf('"%s" must be a column like "C".', $key));
        }

        return $value;
    }
}
