<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * {"type": "mergeCells", "sheet": 0, "range": "A1:D1", "merge": true}
 *
 * Merging keeps the value of the top left cell and empties the others, like Excel does. "merge": false
 * dissolves every merged range that overlaps the range.
 */
final class MergeCellsOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'mergeCells';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $range = $arguments->range($sheet, required: true);

        if (!$arguments->bool('merge', true)) {
            $merges = CellRange::overlappingMerges($sheet, $range);
            foreach ($merges as $merge) {
                $sheet->unmergeCells($merge);
            }

            return ['unmerged' => count($merges)];
        }

        foreach (CellRange::overlappingMerges($sheet, $range) as $merge) {
            $sheet->unmergeCells($merge);
        }
        $sheet->mergeCells(OperationArguments::rangeString($range));

        return ['merged' => OperationArguments::rangeString($range)];
    }
}
