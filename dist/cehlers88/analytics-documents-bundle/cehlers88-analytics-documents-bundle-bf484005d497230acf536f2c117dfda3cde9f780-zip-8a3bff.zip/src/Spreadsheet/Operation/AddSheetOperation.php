<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

/** {"type": "addSheet", "title": "Summary", "index": 1} - without an index the sheet is appended */
final class AddSheetOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'addSheet';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $index = $arguments->has('index') ? $arguments->int('index', null, 0, $spreadsheet->getSheetCount()) : null;
        $title = SheetTitles::unique($spreadsheet, $arguments->string('title', 'Sheet', 100));

        $sheet = new Worksheet($spreadsheet, $title);
        $spreadsheet->addSheet($sheet, $index);

        return ['sheet' => $spreadsheet->getIndex($sheet), 'title' => $title];
    }
}
