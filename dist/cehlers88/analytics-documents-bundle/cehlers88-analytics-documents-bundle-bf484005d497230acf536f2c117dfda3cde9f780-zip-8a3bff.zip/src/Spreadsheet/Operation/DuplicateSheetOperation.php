<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Spreadsheet;

/** {"type": "duplicateSheet", "sheet": 0, "title": "Copy of data"} - the copy is placed right after the sheet */
final class DuplicateSheetOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'duplicateSheet';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $title = SheetTitles::unique($spreadsheet, $arguments->string('title', $sheet->getTitle(), 100));

        $copy = $sheet->copy();
        $copy->setTitle($title, false, false);
        $spreadsheet->addSheet($copy, $spreadsheet->getIndex($sheet) + 1);

        return ['sheet' => $spreadsheet->getIndex($copy), 'title' => $title];
    }
}
