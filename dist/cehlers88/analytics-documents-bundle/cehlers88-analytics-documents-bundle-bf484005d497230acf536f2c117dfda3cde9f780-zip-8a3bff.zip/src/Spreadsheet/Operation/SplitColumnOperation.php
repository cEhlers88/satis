<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\DefaultValueBinder;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * {"type": "splitColumn", "sheet": 0, "column": "B", "delimiter": ";", "headerRow": true, "maxParts": 10}
 *
 * Text to columns: splits the texts of a column at the delimiter into the column
 * and new columns inserted right of it. The header of a new column is the header
 * of the split column with its number, "Address (2)".
 */
final class SplitColumnOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'splitColumn';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $column = $arguments->column('column');
        $delimiter = $arguments->string('delimiter', null, 10);
        if ($delimiter === 'tab' || $delimiter === '\t') {
            $delimiter = "\t";
        }
        if ($delimiter === '') {
            throw new SpreadsheetToolException('The delimiter is empty.');
        }
        $headerRow = $arguments->bool('headerRow', true);
        $maxParts = $arguments->int('maxParts', 50, 2, 200);
        $firstRow = $headerRow ? 2 : 1;
        $lastRow = $sheet->getHighestDataRow(Coordinate::stringFromColumnIndex($column));

        $splits = [];
        $parts = 1;
        for ($row = $firstRow; $row <= $lastRow; ++$row) {
            if (!$sheet->cellExists([$column, $row]) || $sheet->getCell([$column, $row])->getDataType() !== DataType::TYPE_STRING) {
                continue;
            }
            $pieces = explode($delimiter, (string)$sheet->getCell([$column, $row])->getValue(), $maxParts);
            if (count($pieces) > 1) {
                $splits[$row] = $pieces;
                $parts = max($parts, count($pieces));
            }
        }
        if ($parts === 1) {
            return ['columns' => 0, 'rows' => 0];
        }

        $sheet->insertNewColumnBefore(Coordinate::stringFromColumnIndex($column + 1), $parts - 1);

        if ($headerRow && $sheet->cellExists([$column, 1])) {
            $header = trim((string)$sheet->getCell([$column, 1])->getValue());
            for ($part = 2; $part <= $parts; ++$part) {
                $sheet->getCell([$column + $part - 1, 1])->setValueExplicit($header === '' ? '' : sprintf('%s (%d)', $header, $part), DataType::TYPE_STRING);
            }
        }

        foreach ($splits as $row => $pieces) {
            foreach ($pieces as $offset => $piece) {
                $piece = trim($piece);
                $cell = $sheet->getCell([$column + $offset, $row]);
                DefaultValueBinder::dataTypeForValue($piece) === DataType::TYPE_NUMERIC
                    ? $cell->setValueExplicit($piece + 0, DataType::TYPE_NUMERIC)
                    : $cell->setValueExplicit($piece, DataType::TYPE_STRING);
            }
        }

        return ['columns' => $parts - 1, 'rows' => count($splits)];
    }
}
