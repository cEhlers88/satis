<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Font;

/**
 * {"type": "style", "sheet": 0, "range": "A1:F1", "bold": true, "italic": false,
 *  "underline": false, "strike": false, "fontSize": 12, "color": "#FFFFFF", "fill": "#1F4E79",
 *  "numberFormat": "#,##0.00", "align": "center", "verticalAlign": "top", "wrap": true,
 *  "borders": "none|all|outline|bottom"}
 *
 * Only what is given is changed; "fill": "" removes the fill, "color": "" resets the
 * font colour.
 */
final class StyleRangeOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'style';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $range = OperationArguments::rangeString($arguments->range($sheet, required: true));

        $style = [];
        foreach (['bold' => 'bold', 'italic' => 'italic', 'strike' => 'strikethrough'] as $key => $property) {
            if ($arguments->has($key)) {
                $style['font'][$property] = $arguments->bool($key);
            }
        }
        if ($arguments->has('underline')) {
            $style['font']['underline'] = $arguments->bool('underline') ? Font::UNDERLINE_SINGLE : Font::UNDERLINE_NONE;
        }
        if ($arguments->has('fontSize')) {
            $style['font']['size'] = $arguments->int('fontSize', null, 6, 96);
        }
        if ($arguments->has('color')) {
            $style['font']['color'] = ['rgb' => $arguments->color('color') ?? '000000'];
        }
        if ($arguments->has('fill')) {
            $fill = $arguments->color('fill');
            $style['fill'] = $fill === null
                ? ['fillType' => Fill::FILL_NONE]
                : ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => $fill], 'endColor' => ['rgb' => $fill]];
        }
        if ($arguments->has('numberFormat')) {
            $style['numberFormat']['formatCode'] = $arguments->string('numberFormat', null, 200) ?: 'General';
        }
        if ($arguments->has('align')) {
            $style['alignment']['horizontal'] = $arguments->choice('align', ['general', 'left', 'center', 'right', 'justify']);
        }
        if ($arguments->has('verticalAlign')) {
            $style['alignment']['vertical'] = $arguments->choice('verticalAlign', ['top', 'center', 'bottom']);
        }
        if ($arguments->has('wrap')) {
            $style['alignment']['wrapText'] = $arguments->bool('wrap');
        }
        if ($arguments->has('borders')) {
            $borders = $arguments->choice('borders', ['none', 'all', 'outline', 'bottom']);
            $line = ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '000000']];
            $style['borders'] = match ($borders) {
                'none' => ['allBorders' => ['borderStyle' => Border::BORDER_NONE]],
                'all' => ['allBorders' => $line],
                'outline' => ['outline' => $line],
                'bottom' => ['bottom' => $line],
            };
        }

        if ($style === []) {
            throw new SpreadsheetToolException('Nothing to change was given.');
        }
        $sheet->getStyle($range)->applyFromArray($style);

        return ['range' => $range];
    }
}
