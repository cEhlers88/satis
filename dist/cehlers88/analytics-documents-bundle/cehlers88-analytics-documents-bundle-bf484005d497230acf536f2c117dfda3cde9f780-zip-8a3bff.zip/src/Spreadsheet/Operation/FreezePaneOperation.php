<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * {"type": "freezePane", "sheet": 0, "cell": "B2"} - rows above and columns left of
 * B2 stay in place when scrolling; without a cell the pane is released.
 */
final class FreezePaneOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'freezePane';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        if (!$arguments->has('cell') || $arguments->string('cell') === '') {
            $sheet->unfreezePane();

            return ['freezePane' => null];
        }

        $cell = strtoupper($arguments->string('cell', null, 12));
        if (preg_match('/^[A-Z]{1,3}[1-9]\d{0,6}$/D', $cell) !== 1) {
            throw new SpreadsheetToolException('"cell" must be a cell like "B2".');
        }
        if ($cell === 'A1') {
            $sheet->unfreezePane();

            return ['freezePane' => null];
        }
        $sheet->freezePane($cell);

        return ['freezePane' => $cell];
    }
}
