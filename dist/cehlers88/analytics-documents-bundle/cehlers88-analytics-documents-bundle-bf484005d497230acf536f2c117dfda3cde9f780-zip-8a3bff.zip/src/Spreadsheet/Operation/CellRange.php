<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Cell\Cell;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

final class CellRange
{
    /**
     * The cells of a range that exist - walking a range must not create the empty
     * cells in between, a sheet would grow by every lookup.
     *
     * @param array{int, int, int, int} $range
     * @return iterable<Cell>
     */
    public static function existingCells(Worksheet $sheet, array $range): iterable
    {
        [$firstColumn, $firstRow, $lastColumn, $lastRow] = $range;
        for ($row = $firstRow; $row <= $lastRow; ++$row) {
            for ($column = $firstColumn; $column <= $lastColumn; ++$column) {
                if ($sheet->cellExists([$column, $row])) {
                    yield $sheet->getCell([$column, $row]);
                }
            }
        }
    }

    /**
     * @param array{int, int, int, int} $range
     * @return list<string> the merged ranges that overlap the range
     */
    public static function overlappingMerges(Worksheet $sheet, array $range): array
    {
        $overlapping = [];
        foreach ($sheet->getMergeCells() as $merge) {
            [[$firstColumn, $firstRow], [$lastColumn, $lastRow]] = Coordinate::rangeBoundaries($merge);
            if ($firstColumn <= $range[2] && $lastColumn >= $range[0] && $firstRow <= $range[3] && $lastRow >= $range[1]) {
                $overlapping[] = $merge;
            }
        }

        return $overlapping;
    }
}
