<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * {"type": "cleanText", "sheet": 0, "range": null, "trim": true,
 *  "collapseSpaces": true, "removeLineBreaks": false, "case": "none|upper|lower|title"}
 *
 * Tidies the texts of a range - the usual state of an export from another system:
 * spaces around the values, non-breaking spaces, double spaces and line breaks.
 */
final class CleanTextOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'cleanText';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $range = $arguments->range($sheet);
        $trim = $arguments->bool('trim', true);
        $collapse = $arguments->bool('collapseSpaces', true);
        $removeLineBreaks = $arguments->bool('removeLineBreaks');
        $case = $arguments->choice('case', ['none', 'upper', 'lower', 'title'], 'none');

        $changed = 0;
        foreach (CellRange::existingCells($sheet, $range) as $cell) {
            if ($cell->getDataType() !== DataType::TYPE_STRING) {
                continue;
            }
            $original = (string)$cell->getValue();
            $text = str_replace("\u{00A0}", ' ', $original);
            if ($removeLineBreaks) {
                $text = (string)preg_replace('/\R+/u', ' ', $text);
            }
            if ($collapse) {
                $text = (string)preg_replace('/[ \t]{2,}/u', ' ', $text);
            }
            if ($trim) {
                $text = trim($text, " \t\n\r\0\x0B");
            }
            $text = match ($case) {
                'upper' => mb_strtoupper($text),
                'lower' => mb_strtolower($text),
                'title' => mb_convert_case($text, MB_CASE_TITLE),
                default => $text,
            };

            if ($text !== $original) {
                $cell->setValueExplicit($text, DataType::TYPE_STRING);
                ++$changed;
            }
        }

        return ['cells' => $changed];
    }
}
