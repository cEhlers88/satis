<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\ReferenceHelper;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Throwable;

/**
 * The rows of a range, taken out of a sheet and written back in another order or
 * with some of them left out - what sorting and removing duplicates have in common.
 *
 * Rows are moved with their values and cell styles. A formula moved by n rows has
 * its relative references moved by n rows as well, the way copying a row in a
 * spreadsheet program does it, so "=B2*C2" stays in its row.
 */
final class RowBlock
{
    /**
     * @var array<int, array<int, array{mixed, string, int}|null>> original row => column => [value, data type, style index]
     */
    private array $rows = [];

    private function __construct(
        private readonly Worksheet $sheet,
        private readonly int       $firstColumn,
        private readonly int       $firstRow,
        private readonly int       $lastColumn,
        private readonly int       $lastRow,
    ) {
    }

    /** @param array{int, int, int, int} $range */
    public static function read(Worksheet $sheet, array $range): self
    {
        [$firstColumn, $firstRow, $lastColumn, $lastRow] = $range;
        $block = new self($sheet, $firstColumn, $firstRow, $lastColumn, $lastRow);

        for ($row = $firstRow; $row <= $lastRow; ++$row) {
            for ($column = $firstColumn; $column <= $lastColumn; ++$column) {
                if (!$sheet->cellExists([$column, $row])) {
                    $block->rows[$row][$column] = null;
                    continue;
                }
                $cell = $sheet->getCell([$column, $row]);
                $block->rows[$row][$column] = [$cell->getValue(), $cell->getDataType(), $cell->getXfIndex()];
            }
        }

        return $block;
    }

    /** @return list<int> the original row numbers */
    public function rowNumbers(): array
    {
        return array_keys($this->rows);
    }

    /** The value a row shows in a column, formulas calculated - for comparing rows. */
    public function shownValue(int $row, int $column): mixed
    {
        if (!$this->sheet->cellExists([$column, $row])) {
            return null;
        }

        try {
            $value = $this->sheet->getCell([$column, $row])->getCalculatedValue();
        } catch (Throwable) {
            return null;
        }

        return is_object($value) && method_exists($value, 'getPlainText') ? $value->getPlainText() : $value;
    }

    /**
     * Writes the rows in the given order from the first row of the block on; the
     * rows of the block that are left over are emptied.
     *
     * @param list<int> $order original row numbers
     */
    public function write(array $order): void
    {
        $referenceHelper = ReferenceHelper::getInstance();
        $cells = $this->sheet->getCellCollection();
        $target = $this->firstRow;

        foreach ($order as $source) {
            foreach ($this->rows[$source] as $column => $data) {
                $coordinate = Coordinate::stringFromColumnIndex($column) . $target;
                if ($data === null) {
                    if ($cells->has($coordinate)) {
                        $cells->delete($coordinate);
                    }
                    continue;
                }

                [$value, $dataType, $xfIndex] = $data;
                if ($dataType === DataType::TYPE_FORMULA && $target !== $source && is_string($value)) {
                    $value = $referenceHelper->updateFormulaReferences($value, 'A1', 0, $target - $source, $this->sheet->getTitle());
                }
                $this->sheet->getCell($coordinate)->setValueExplicit($value, $dataType)->setXfIndex($xfIndex);
            }
            ++$target;
        }

        for (; $target <= $this->lastRow; ++$target) {
            for ($column = $this->firstColumn; $column <= $this->lastColumn; ++$column) {
                $coordinate = Coordinate::stringFromColumnIndex($column) . $target;
                if ($cells->has($coordinate)) {
                    $cells->delete($coordinate);
                }
            }
        }
    }
}
