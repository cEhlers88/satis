<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * One kind of change the Excel-Manipulator can make to a workbook. Operations are
 * found by the tag analytics_documents.spreadsheet_operation, so a new one is a
 * class in this directory and nothing else.
 */
interface SpreadsheetOperationInterface
{
    /** The "type" a client names the operation by. */
    public function getName(): string;

    /**
     * @return array<string, mixed> what the operation did, e.g. ['cells' => 12]
     */
    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array;
}
