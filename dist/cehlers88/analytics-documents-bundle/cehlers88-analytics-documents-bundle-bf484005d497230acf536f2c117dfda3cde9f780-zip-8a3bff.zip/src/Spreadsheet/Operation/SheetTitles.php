<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

final class SheetTitles
{
    /** Checks a title the way Excel does and makes it unique within the workbook. */
    public static function unique(Spreadsheet $spreadsheet, string $title, ?Worksheet $except = null): string
    {
        $title = trim($title);
        if ($title === '') {
            throw new SpreadsheetToolException('A sheet needs a title.');
        }
        if (preg_match('/[\\\\\/?*:\[\]]/', $title) === 1 || str_starts_with($title, "'") || str_ends_with($title, "'")) {
            throw new SpreadsheetToolException('A sheet title must not contain \ / ? * : [ ] or start or end with an apostrophe.');
        }
        $title = mb_substr($title, 0, Worksheet::SHEET_TITLE_MAXIMUM_LENGTH);

        $candidate = $title;
        $suffix = 2;
        // "Data (2)" taken continues with "Data (3)", not with "Data (2) (2)"
        if (self::taken($spreadsheet, $candidate, $except) && preg_match('/^(.+) \((\d+)\)$/uD', $title, $matches) === 1) {
            [$title, $suffix] = [$matches[1], (int)$matches[2] + 1];
        }
        for (; self::taken($spreadsheet, $candidate, $except); ++$suffix) {
            $ending = ' (' . $suffix . ')';
            $candidate = mb_substr($title, 0, Worksheet::SHEET_TITLE_MAXIMUM_LENGTH - mb_strlen($ending)) . $ending;
        }

        return $candidate;
    }

    private static function taken(Spreadsheet $spreadsheet, string $title, ?Worksheet $except): bool
    {
        $sheet = $spreadsheet->getSheetByName($title);

        return $sheet !== null && $sheet !== $except;
    }
}
