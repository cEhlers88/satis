<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\CellValueParser;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;

/**
 * {"type": "convertText", "sheet": 0, "range": "B2:B900", "numbers": true, "dates": true,
 *  "decimalSeparator": ",", "thousandsSeparator": "."}
 *
 * Turns texts that are numbers or dates into numbers and dates - after a CSV import
 * "1.234,56" and "17.09.2026" are texts, and nothing can be summed or sorted by them.
 * Dates are read as ISO (2026-09-17) or German (17.09.2026) dates.
 */
final class ConvertTextOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'convertText';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $range = $arguments->range($sheet);
        $numbers = $arguments->bool('numbers', true);
        $dates = $arguments->bool('dates', true);
        $decimalSeparator = $arguments->choice('decimalSeparator', ['.', ','], ',');
        $thousandsSeparator = $arguments->choice('thousandsSeparator', ['', '.', ',', ' ', "'"], $decimalSeparator === ',' ? '.' : ',');
        if ($decimalSeparator === $thousandsSeparator) {
            throw new SpreadsheetToolException('Decimal and thousands separator must differ.');
        }

        $convertedNumbers = 0;
        $convertedDates = 0;
        foreach (CellRange::existingCells($sheet, $range) as $cell) {
            if ($cell->getDataType() !== DataType::TYPE_STRING) {
                continue;
            }
            $text = trim((string)$cell->getValue());

            if ($dates) {
                $date = CellValueParser::parseIsoDate($text) ?? CellValueParser::parseGermanDate($text);
                if ($date !== null) {
                    $cell->setValueExplicit($date[0], DataType::TYPE_NUMERIC);
                    if (!Date::isDateTimeFormat($cell->getStyle()->getNumberFormat())) {
                        $cell->getStyle()->getNumberFormat()->setFormatCode($date[1]);
                    }
                    ++$convertedDates;
                    continue;
                }
            }

            if ($numbers) {
                $number = CellValueParser::parseLocalizedNumber($text, $decimalSeparator, $thousandsSeparator);
                if ($number !== null) {
                    $cell->setValueExplicit($number, DataType::TYPE_NUMERIC);
                    if (str_ends_with($text, '%') && $cell->getStyle()->getNumberFormat()->getFormatCode() === NumberFormat::FORMAT_GENERAL) {
                        $cell->getStyle()->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_PERCENTAGE_00);
                    }
                    ++$convertedNumbers;
                }
            }
        }

        return ['numbers' => $convertedNumbers, 'dates' => $convertedDates];
    }
}
