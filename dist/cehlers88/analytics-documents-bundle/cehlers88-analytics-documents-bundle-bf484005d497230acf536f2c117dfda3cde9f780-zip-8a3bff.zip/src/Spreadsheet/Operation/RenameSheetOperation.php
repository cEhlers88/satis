<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Spreadsheet;

/** {"type": "renameSheet", "sheet": 0, "title": "Data"} - formulas referring to the sheet follow */
final class RenameSheetOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'renameSheet';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $title = SheetTitles::unique($spreadsheet, $arguments->string('title', null, 100), $sheet);
        $sheet->setTitle($title);

        return ['title' => $title];
    }
}
