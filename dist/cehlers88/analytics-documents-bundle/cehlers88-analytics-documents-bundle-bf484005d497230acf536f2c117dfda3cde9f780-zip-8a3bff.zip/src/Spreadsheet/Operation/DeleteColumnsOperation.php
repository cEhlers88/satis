<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Cell\AddressRange;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/** {"type": "deleteColumns", "sheet": 0, "column": "C", "count": 1} - columns to the right move left */
final class DeleteColumnsOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'deleteColumns';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $column = $arguments->column('column');
        $count = $arguments->int('count', 1, 1, AddressRange::MAX_COLUMN_INT);
        $sheet->removeColumn(Coordinate::stringFromColumnIndex($column), $count);

        return ['columns' => $count];
    }
}
