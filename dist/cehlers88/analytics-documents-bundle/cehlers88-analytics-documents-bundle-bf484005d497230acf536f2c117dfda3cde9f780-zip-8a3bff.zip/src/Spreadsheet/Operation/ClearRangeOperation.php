<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/** {"type": "clearRange", "sheet": 0, "range": "A2:D9", "what": "contents|formats|all"} */
final class ClearRangeOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'clearRange';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $range = $arguments->range($sheet, required: true);
        $what = $arguments->choice('what', ['contents', 'formats', 'all'], 'contents');
        $cells = $sheet->getCellCollection();
        $count = 0;

        foreach (CellRange::existingCells($sheet, $range) as $cell) {
            ++$count;
            if ($what === 'all') {
                $cells->delete($cell->getCoordinate());
                continue;
            }
            if ($what === 'contents') {
                $cell->setValueExplicit(null, DataType::TYPE_NULL);
            } else {
                $cell->setXfIndex(0);
            }
        }

        return ['cells' => $count];
    }
}
