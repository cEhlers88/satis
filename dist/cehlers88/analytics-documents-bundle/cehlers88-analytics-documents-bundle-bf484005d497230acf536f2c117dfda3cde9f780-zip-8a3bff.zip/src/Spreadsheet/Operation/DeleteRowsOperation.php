<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Cell\AddressRange;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/** {"type": "deleteRows", "sheet": 0, "row": 5, "count": 2} - rows below move up, references follow */
final class DeleteRowsOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'deleteRows';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $row = $arguments->row('row');
        $count = $arguments->int('count', 1, 1, AddressRange::MAX_ROW);
        $sheet->removeRow($row, $count);

        return ['rows' => $count];
    }
}
