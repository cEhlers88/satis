<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * {"type": "sort", "sheet": 0, "range": "A1:F200", "headerRow": true,
 *  "keys": [{"column": "C", "direction": "desc"}, {"column": "A"}]}
 *
 * Sorts the rows of a range (the used range without one) by up to three columns.
 * Like in Excel, numbers come before texts, texts before booleans, and empty cells
 * are always last - in both directions. Texts compare case-insensitively and
 * naturally ("Item 2" before "Item 10").
 */
final class SortRangeOperation implements SpreadsheetOperationInterface
{
    private const MAX_KEYS = 3;

    public function getName(): string
    {
        return 'sort';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $range = $arguments->range($sheet);
        if ($arguments->bool('headerRow', true)) {
            ++$range[1];
        }
        if ($range[1] > $range[3]) {
            return ['rows' => 0];
        }
        if (CellRange::overlappingMerges($sheet, $range) !== []) {
            throw new SpreadsheetToolException('Rows with merged cells cannot be sorted - unmerge them first.');
        }

        $keys = [];
        foreach ($arguments->list('keys', self::MAX_KEYS) as $key) {
            $key = new OperationArguments(is_array($key) ? $key : []);
            $column = $key->column('column');
            if ($column < $range[0] || $column > $range[2]) {
                throw new SpreadsheetToolException(sprintf('Column %s is not part of the range.', Coordinate::stringFromColumnIndex($column)));
            }
            $keys[] = [$column, $key->choice('direction', ['asc', 'desc'], 'asc') === 'desc' ? -1 : 1];
        }
        if ($keys === []) {
            $keys[] = [$range[0], 1];
        }

        $block = RowBlock::read($sheet, $range);
        $values = [];
        foreach ($block->rowNumbers() as $row) {
            foreach ($keys as [$column]) {
                $values[$row][$column] = $block->shownValue($row, $column);
            }
        }

        $order = $block->rowNumbers();
        usort($order, static function (int $left, int $right) use ($keys, $values): int {
            foreach ($keys as [$column, $direction]) {
                $comparison = self::compare($values[$left][$column], $values[$right][$column], $direction);
                if ($comparison !== 0) {
                    return $comparison;
                }
            }

            return $left <=> $right;
        });

        $block->write($order);

        return ['rows' => count($order)];
    }

    public static function compare(mixed $left, mixed $right, int $direction): int
    {
        $leftEmpty = $left === null || $left === '';
        $rightEmpty = $right === null || $right === '';
        if ($leftEmpty || $rightEmpty) {
            return $leftEmpty <=> $rightEmpty;
        }

        $leftRank = self::rank($left);
        $rightRank = self::rank($right);
        if ($leftRank !== $rightRank) {
            return ($leftRank <=> $rightRank) * $direction;
        }

        $comparison = match ($leftRank) {
            0 => $left <=> $right,
            1 => strnatcasecmp((string)$left, (string)$right),
            default => (int)$left <=> (int)$right,
        };

        return $comparison * $direction;
    }

    private static function rank(mixed $value): int
    {
        return match (true) {
            is_int($value), is_float($value) => 0,
            is_bool($value) => 2,
            default => 1,
        };
    }
}
