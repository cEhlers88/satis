<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Spreadsheet;

/** {"type": "moveSheet", "sheet": 3, "index": 0} */
final class MoveSheetOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'moveSheet';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $index = $arguments->int('index', null, 0, $spreadsheet->getSheetCount() - 1);
        $spreadsheet->setIndexByName($sheet->getTitle(), $index);

        return ['sheet' => $index];
    }
}
