<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Cell\Cell;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\RichText\RichText;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * {"type": "findReplace", "sheet": 0, "allSheets": false, "range": null,
 *  "search": "GmbH", "replace": "AG", "matchCase": false, "wholeCell": false,
 *  "regex": false, "inFormulas": false}
 *
 * Replaces in texts and numbers; formulas are only touched when asked for. A text
 * stays a text even if the replacement looks like a number or a formula, a number
 * stays a number as long as the result still is one.
 */
final class FindReplaceOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'findReplace';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $search = $arguments->string('search', null, 1000);
        if ($search === '') {
            throw new SpreadsheetToolException('The search text is empty.');
        }
        $replace = $arguments->string('replace', '', 1000);
        $matchCase = $arguments->bool('matchCase');
        $wholeCell = $arguments->bool('wholeCell');
        $inFormulas = $arguments->bool('inFormulas');

        $flags = 'u' . ($matchCase ? '' : 'i');
        if ($arguments->bool('regex')) {
            // \x01 as delimiter: whatever the user writes can stay as it is
            $pattern = "\x01" . ($wholeCell ? '^(?:' . $search . ')$' : $search) . "\x01" . $flags . ($wholeCell ? 'D' : '');
            if (@preg_match($pattern, '') === false) {
                throw new SpreadsheetToolException('The regular expression is invalid.');
            }
        } else {
            $quoted = preg_quote($search, "\x01");
            $pattern = "\x01" . ($wholeCell ? '^' . $quoted . '$' : $quoted) . "\x01" . $flags . ($wholeCell ? 'D' : '');
            // a literal replacement must not be read as a back reference
            $replace = str_replace(['\\', '$'], ['\\\\', '\\$'], $replace);
        }

        $allSheets = $arguments->bool('allSheets');
        $sheets = $allSheets
            ? iterator_to_array($spreadsheet->getWorksheetIterator(), false)
            : [$arguments->sheet($spreadsheet)];

        $cells = 0;
        $replacements = 0;
        foreach ($sheets as $sheet) {
            $range = $allSheets
                ? [1, 1, Coordinate::columnIndexFromString($sheet->getHighestDataColumn()), $sheet->getHighestDataRow()]
                : $arguments->range($sheet);
            foreach (CellRange::existingCells($sheet, $range) as $cell) {
                $count = $this->replaceInCell($cell, $pattern, $replace, $inFormulas);
                if ($count > 0) {
                    ++$cells;
                    $replacements += $count;
                }
            }
        }

        return ['cells' => $cells, 'replacements' => $replacements];
    }

    private function replaceInCell(Cell $cell, string $pattern, string $replace, bool $inFormulas): int
    {
        $dataType = $cell->getDataType();
        $value = $cell->getValue();

        if ($dataType === DataType::TYPE_FORMULA && !$inFormulas) {
            return 0;
        }
        if ($value instanceof RichText) {
            $value = $value->getPlainText();
        } elseif (is_int($value) || is_float($value)) {
            $value = (string)$value;
        } elseif (!is_string($value)) {
            return 0;
        }

        $count = 0;
        $result = preg_replace($pattern, $replace, $value, -1, $count);
        if ($result === null) {
            throw new SpreadsheetToolException('The regular expression could not be applied.');
        }
        if ($count === 0 || $result === $value) {
            return 0;
        }

        match (true) {
            $dataType === DataType::TYPE_FORMULA => str_starts_with($result, '=')
                ? $cell->setValue($result)
                : $cell->setValueExplicit($result, DataType::TYPE_STRING),
            $dataType === DataType::TYPE_NUMERIC && is_numeric($result) => $cell->setValueExplicit($result + 0, DataType::TYPE_NUMERIC),
            default => $cell->setValueExplicit($result, DataType::TYPE_STRING),
        };

        return $count;
    }
}
