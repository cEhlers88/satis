<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * {"type": "autoFilter", "sheet": 0, "range": null, "remove": false} - puts the filter
 * buttons on the first row of the range (the used range without one).
 */
final class AutoFilterOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'autoFilter';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        if ($arguments->bool('remove')) {
            $sheet->removeAutoFilter();

            return ['autoFilter' => null];
        }

        $range = OperationArguments::rangeString($arguments->range($sheet));
        $sheet->setAutoFilter($range);

        return ['autoFilter' => $range];
    }
}
