<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Spreadsheet;

/** {"type": "insertRows", "sheet": 0, "row": 5, "count": 2} - inserted before row 5, references follow */
final class InsertRowsOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'insertRows';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $row = $arguments->row('row');
        $count = $arguments->int('count', 1, 1, 10000);
        $sheet->insertNewRowBefore($row, $count);

        return ['rows' => $count];
    }
}
