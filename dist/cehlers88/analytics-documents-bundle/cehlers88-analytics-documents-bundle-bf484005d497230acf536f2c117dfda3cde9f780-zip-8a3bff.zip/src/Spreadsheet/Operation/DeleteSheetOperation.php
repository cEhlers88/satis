<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/** {"type": "deleteSheet", "sheet": 2} */
final class DeleteSheetOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'deleteSheet';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        if ($spreadsheet->getSheetCount() < 2) {
            throw new SpreadsheetToolException('A workbook keeps at least one sheet.');
        }

        $spreadsheet->removeSheetByIndex($spreadsheet->getIndex($sheet));
        if ($spreadsheet->getActiveSheetIndex() < 0 || $spreadsheet->getActiveSheetIndex() >= $spreadsheet->getSheetCount()) {
            $spreadsheet->setActiveSheetIndex(0);
        }

        return ['title' => $sheet->getTitle()];
    }
}
