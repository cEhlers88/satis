<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * {"type": "removeDuplicates", "sheet": 0, "range": null, "headerRow": true,
 *  "columns": ["A", "C"], "ignoreCase": false}
 *
 * Keeps the first row of every group of rows that show the same values in the
 * given columns (all columns of the range without) and moves the rest up.
 */
final class RemoveDuplicatesOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'removeDuplicates';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $range = $arguments->range($sheet);
        if ($arguments->bool('headerRow', true)) {
            ++$range[1];
        }
        if ($range[1] > $range[3]) {
            return ['removed' => 0, 'rows' => 0];
        }
        if (CellRange::overlappingMerges($sheet, $range) !== []) {
            throw new SpreadsheetToolException('Rows with merged cells cannot be compared - unmerge them first.');
        }

        $columns = array_map(
            static fn(mixed $column): int => OperationArguments::columnIndex($column),
            $arguments->list('columns', 1000)
        );
        if ($columns === []) {
            $columns = range($range[0], $range[2]);
        }
        foreach ($columns as $column) {
            if ($column < $range[0] || $column > $range[2]) {
                throw new SpreadsheetToolException('Every compared column has to be part of the range.');
            }
        }
        $ignoreCase = $arguments->bool('ignoreCase');

        $block = RowBlock::read($sheet, $range);
        $seen = [];
        $kept = [];
        foreach ($block->rowNumbers() as $row) {
            $key = [];
            foreach ($columns as $column) {
                $value = $block->shownValue($row, $column);
                $key[] = is_string($value) && $ignoreCase ? mb_strtolower($value) : $value;
            }
            $hash = serialize($key);
            if (!isset($seen[$hash])) {
                $seen[$hash] = true;
                $kept[] = $row;
            }
        }

        $removed = count($block->rowNumbers()) - count($kept);
        if ($removed > 0) {
            $block->write($kept);
        }

        return ['removed' => $removed, 'rows' => count($kept)];
    }
}
