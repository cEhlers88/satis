<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/** {"type": "insertColumns", "sheet": 0, "column": "C", "count": 1} - inserted before column C */
final class InsertColumnsOperation implements SpreadsheetOperationInterface
{
    public function getName(): string
    {
        return 'insertColumns';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $column = $arguments->column('column');
        $count = $arguments->int('count', 1, 1, 1000);
        $sheet->insertNewColumnBefore(Coordinate::stringFromColumnIndex($column), $count);

        return ['columns' => $count];
    }
}
