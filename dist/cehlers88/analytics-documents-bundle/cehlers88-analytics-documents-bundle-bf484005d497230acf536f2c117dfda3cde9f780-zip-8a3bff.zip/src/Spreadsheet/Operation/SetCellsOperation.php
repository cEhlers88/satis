<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\CellValueParser;
use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception\SpreadsheetToolException;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * {"type": "setCells", "sheet": 0, "cells": [{"cell": "B2", "value": "=SUM(A1:A9)"}]}
 *
 * Values are read like typed text (see CellValueParser); an empty value clears the
 * cell but keeps its format.
 */
final class SetCellsOperation implements SpreadsheetOperationInterface
{
    public const MAX_CELLS = 20000;

    public function getName(): string
    {
        return 'setCells';
    }

    public function apply(Spreadsheet $spreadsheet, OperationArguments $arguments): array
    {
        $sheet = $arguments->sheet($spreadsheet);
        $count = 0;

        foreach ($arguments->list('cells', self::MAX_CELLS) as $entry) {
            $coordinate = is_array($entry) ? ($entry['cell'] ?? null) : null;
            $value = is_array($entry) ? ($entry['value'] ?? null) : null;
            if (!is_string($coordinate) || preg_match('/^[A-Za-z]{1,3}[1-9]\d{0,6}$/D', $coordinate) !== 1) {
                throw new SpreadsheetToolException('Every cell needs an address like "B2".');
            }
            if (!is_string($value) && !is_int($value) && !is_float($value) && !is_bool($value) && $value !== null) {
                throw new SpreadsheetToolException(sprintf('The value of %s must be a text, number or boolean.', $coordinate));
            }
            if (is_string($value) && mb_strlen($value) > 32767) {
                throw new SpreadsheetToolException(sprintf('The value of %s is longer than a cell can hold.', $coordinate));
            }

            [$column, $row] = Coordinate::indexesFromString(strtoupper($coordinate));
            if ($value === null || $value === '') {
                if (!$sheet->cellExists([$column, $row])) {
                    continue;
                }
            }
            CellValueParser::setCellFromInput($sheet->getCell([$column, $row]), $value);
            ++$count;
        }

        return ['cells' => $count];
    }
}
