<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet;

use Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Operation\SheetTitles;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Throwable;

/**
 * Brings the content of a second file into a workbook: as sheets of their own, or
 * as rows below the data of a sheet - twelve monthly CSV exports into one table.
 */
final class SpreadsheetImporter
{
    /**
     * Moves the sheets of the source into the target - the source is a file that was
     * just read for this and is used up afterwards.
     *
     * @return list<string> the titles of the added sheets
     */
    public function appendSheets(Spreadsheet $target, Spreadsheet $source, string $baseTitle = ''): array
    {
        $titles = [];
        foreach (iterator_to_array($source->getWorksheetIterator(), false) as $sheet) {
            $title = $source->getSheetCount() === 1 && $baseTitle !== '' ? $baseTitle : $sheet->getTitle();
            $title = SheetTitles::unique($target, (string)preg_replace('/[\\\\\/?*:\[\]]/', ' ', $title) ?: 'Sheet');

            $sheet->setTitle($title, false, false);
            // addExternalSheet carries the styles over into the target workbook
            $target->addExternalSheet($sheet);
            $titles[] = $title;
        }

        return $titles;
    }

    /**
     * Appends the rows of the source sheet below the last row of the target sheet.
     * Values and number formats are taken, formulas as their result - they would
     * point at the wrong rows in their new place.
     *
     * @return int the number of appended rows
     */
    public function appendRows(Worksheet $target, Worksheet $source, bool $skipHeaderRow): int
    {
        $targetRow = $target->getHighestDataRow();
        if ($targetRow === 1 && !$this->rowHasData($target, 1)) {
            $targetRow = 0;
        }

        $firstRow = $skipHeaderRow ? 2 : 1;
        $lastRow = $source->getHighestDataRow();
        $lastColumn = Coordinate::columnIndexFromString($source->getHighestDataColumn());
        $appended = 0;

        for ($row = $firstRow; $row <= $lastRow; ++$row) {
            ++$targetRow;
            ++$appended;
            for ($column = 1; $column <= $lastColumn; ++$column) {
                if (!$source->cellExists([$column, $row])) {
                    continue;
                }
                $sourceCell = $source->getCell([$column, $row]);
                $value = $sourceCell->getValue();
                $dataType = $sourceCell->getDataType();
                if ($dataType === DataType::TYPE_FORMULA) {
                    try {
                        $value = $sourceCell->getCalculatedValue();
                    } catch (Throwable) {
                        $value = $sourceCell->getOldCalculatedValue();
                    }
                    $dataType = DataType::TYPE_NUMERIC;
                    if (!is_int($value) && !is_float($value)) {
                        $dataType = is_bool($value) ? DataType::TYPE_BOOL : DataType::TYPE_STRING;
                        $value = is_bool($value) ? $value : (string)$value;
                    }
                }
                if ($value === null || $value === '') {
                    continue;
                }

                $targetCell = $target->getCell([$column, $targetRow]);
                $targetCell->setValueExplicit($value, $dataType === DataType::TYPE_INLINE ? DataType::TYPE_STRING : $dataType);
                $formatCode = $sourceCell->getStyle()->getNumberFormat()->getFormatCode();
                if ($formatCode !== null && $formatCode !== NumberFormat::FORMAT_GENERAL) {
                    $targetCell->getStyle()->getNumberFormat()->setFormatCode($formatCode);
                }
            }
        }

        return $appended;
    }

    private function rowHasData(Worksheet $sheet, int $row): bool
    {
        $lastColumn = Coordinate::columnIndexFromString($sheet->getHighestDataColumn());
        for ($column = 1; $column <= $lastColumn; ++$column) {
            if ($sheet->cellExists([$column, $row]) && $sheet->getCell([$column, $row])->getValue() !== null && $sheet->getCell([$column, $row])->getValue() !== '') {
                return true;
            }
        }

        return false;
    }
}
