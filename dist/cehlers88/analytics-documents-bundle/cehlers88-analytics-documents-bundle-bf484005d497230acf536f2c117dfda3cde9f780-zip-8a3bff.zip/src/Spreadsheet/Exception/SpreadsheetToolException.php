<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception;

use RuntimeException;

/**
 * A request the Excel-Manipulator refuses. The message is meant for the user and
 * therefore never carries paths or other details of the server.
 */
class SpreadsheetToolException extends RuntimeException
{
    public function __construct(string $message, private readonly int $statusCode = 400, ?\Throwable $previous = null)
    {
        parent::__construct($message, 0, $previous);
    }

    public function getStatusCode(): int
    {
        return $this->statusCode;
    }
}
