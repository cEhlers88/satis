<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet\Exception;

final class WorkbookNotFoundException extends SpreadsheetToolException
{
    public function __construct()
    {
        parent::__construct('The workbook does not exist (any more).', 404);
    }
}
