<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Spreadsheet;

use DateTimeImmutable;
use PhpOffice\PhpSpreadsheet\Cell\Cell;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\DefaultValueBinder;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;

/**
 * Turns typed text into cell values - the way a spreadsheet program does it, but
 * predictably: only ISO dates become dates (a "03/04/2026" means different days in
 * different countries), and an apostrophe in front keeps anything as text.
 */
final class CellValueParser
{
    public const DATE_FORMAT = 'yyyy-mm-dd';
    public const DATE_TIME_FORMAT = 'yyyy-mm-dd hh:mm:ss';
    public const TIME_FORMAT = 'hh:mm:ss';

    private const ISO_DATE = '/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?$/D';
    private const TIME = '/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/D';
    private const GERMAN_DATE = '/^(\d{1,2})\.(\d{1,2})\.(\d{2}|\d{4})(?: (\d{1,2}):(\d{2})(?::(\d{2}))?)?$/D';

    public static function looksLikeDate(string $text): bool
    {
        return preg_match(self::ISO_DATE, $text) === 1 || preg_match(self::TIME, $text) === 1;
    }

    /** Writes typed text into a cell. */
    public static function setCellFromInput(Cell $cell, string|int|float|bool|null $input): void
    {
        if ($input === null || $input === '') {
            $cell->setValueExplicit(null, DataType::TYPE_NULL);

            return;
        }
        if (!is_string($input)) {
            $cell->setValue($input);

            return;
        }

        if ($input[0] === "'") {
            $cell->setValueExplicit(substr($input, 1), DataType::TYPE_STRING);

            return;
        }
        if (in_array(strtoupper($input), ['TRUE', 'FALSE'], true)) {
            $cell->setValueExplicit(strtoupper($input) === 'TRUE', DataType::TYPE_BOOL);

            return;
        }

        $date = self::parseIsoDate($input) ?? self::parseTime($input);
        if ($date !== null) {
            $cell->setValueExplicit($date[0], DataType::TYPE_NUMERIC);
            if (!Date::isDateTimeFormat($cell->getStyle()->getNumberFormat())) {
                $cell->getStyle()->getNumberFormat()->setFormatCode($date[1]);
            }

            return;
        }

        if (preg_match('/^([+-]?\d+(?:\.\d+)?)%$/D', $input, $matches) === 1) {
            $cell->setValueExplicit((float)$matches[1] / 100, DataType::TYPE_NUMERIC);
            if ($cell->getStyle()->getNumberFormat()->getFormatCode() === NumberFormat::FORMAT_GENERAL) {
                $cell->getStyle()->getNumberFormat()->setFormatCode(str_contains($matches[1], '.') ? NumberFormat::FORMAT_PERCENTAGE_00 : NumberFormat::FORMAT_PERCENTAGE);
            }

            return;
        }

        $dataType = DefaultValueBinder::dataTypeForValue($input);
        if ($dataType === DataType::TYPE_NUMERIC) {
            $cell->setValueExplicit(self::toNumber($input), DataType::TYPE_NUMERIC);

            return;
        }

        // formulas and everything else go through the binder, which knows formulas
        $cell->setValue($input);
    }

    /** @return array{float, string}|null the Excel serial and a number format that shows it */
    public static function parseIsoDate(string $text): ?array
    {
        if (preg_match(self::ISO_DATE, $text, $matches) !== 1) {
            return null;
        }

        return self::toSerial(
            (int)$matches[1], (int)$matches[2], (int)$matches[3],
            isset($matches[4]) ? (int)$matches[4] : null,
            isset($matches[5]) ? (int)$matches[5] : 0,
            isset($matches[6]) ? (int)$matches[6] : 0,
        );
    }

    /** @return array{float, string}|null dd.mm.yyyy with an optional time, as German programs write it */
    public static function parseGermanDate(string $text): ?array
    {
        if (preg_match(self::GERMAN_DATE, $text, $matches) !== 1) {
            return null;
        }

        $year = (int)$matches[3];
        if (strlen($matches[3]) === 2) {
            $year += $year < 70 ? 2000 : 1900;
        }

        return self::toSerial(
            $year, (int)$matches[2], (int)$matches[1],
            isset($matches[4]) ? (int)$matches[4] : null,
            isset($matches[5]) ? (int)$matches[5] : 0,
            isset($matches[6]) ? (int)$matches[6] : 0,
        );
    }

    /** @return array{float, string}|null */
    public static function parseTime(string $text): ?array
    {
        if (preg_match(self::TIME, $text, $matches) !== 1) {
            return null;
        }

        [$hours, $minutes, $seconds] = [(int)$matches[1], (int)$matches[2], isset($matches[3]) ? (int)$matches[3] : 0];
        if ($hours > 23 || $minutes > 59 || $seconds > 59) {
            return null;
        }

        return [($hours * 3600 + $minutes * 60 + $seconds) / 86400, self::TIME_FORMAT];
    }

    /**
     * A number written with the given separators: "1.234,56" for German,
     * "1,234.56" for English. A currency sign or unit around it is not a number.
     */
    public static function parseLocalizedNumber(string $text, string $decimalSeparator, string $thousandsSeparator): int|float|null
    {
        $text = trim(str_replace("\u{00A0}", ' ', $text));
        if ($text === '' || $decimalSeparator === $thousandsSeparator) {
            return null;
        }

        $percent = str_ends_with($text, '%');
        if ($percent) {
            $text = rtrim(substr($text, 0, -1));
        }

        $pattern = sprintf(
            '/^[+-]?(?:\d{1,3}(?:%1$s\d{3})+|\d+)(?:%2$s\d+)?$/uD',
            $thousandsSeparator === '' ? '(?!)' : preg_quote($thousandsSeparator, '/'),
            preg_quote($decimalSeparator, '/')
        );
        if (preg_match($pattern, $text) !== 1) {
            return null;
        }

        $normalized = str_replace($decimalSeparator, '.', $thousandsSeparator === '' ? $text : str_replace($thousandsSeparator, '', $text));
        $number = self::toNumber($normalized);

        return $percent ? $number / 100 : $number;
    }

    /**
     * A number as Excel shows it in the General format: at most 15 significant
     * digits, so 99.9 stays "99.9" instead of the "99.900000000000006" a double holds.
     */
    public static function numberToText(int|float $value): string
    {
        if (is_int($value)) {
            return (string)$value;
        }

        $text = sprintf('%.15G', $value);
        if (str_contains($text, 'E')) {
            // 1.0E+20 - keep the exponent, drop a mantissa of ".0"
            return (string)preg_replace('/\.?0+E/', 'E', $text);
        }

        return $text === '-0' ? '0' : $text;
    }

    private static function toNumber(string $text): int|float
    {
        $number = $text + 0;

        return is_int($number) || floor($number) !== $number || abs($number) > PHP_INT_MAX ? $number : (int)$number;
    }

    /** @return array{float, string}|null */
    private static function toSerial(int $year, int $month, int $day, ?int $hours, int $minutes, int $seconds): ?array
    {
        if (!checkdate($month, $day, $year) || $hours !== null && ($hours > 23 || $minutes > 59 || $seconds > 59)) {
            return null;
        }

        $dateTime = (new DateTimeImmutable('1970-01-01 00:00:00', new \DateTimeZone('UTC')))
            ->setDate($year, $month, $day)
            ->setTime($hours ?? 0, $minutes, $seconds);
        $serial = Date::dateTimeToExcel($dateTime);

        return [$serial, $hours === null ? self::DATE_FORMAT : self::DATE_TIME_FORMAT];
    }
}
