<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\ENUM;

/**
 * The file formats of the Excel-Manipulator. The reader is always chosen by this
 * format and never guessed from the content: PhpSpreadsheet's identification would
 * also accept HTML, XML and SYLK files, which have no business in this tool.
 */
enum ESpreadsheetFormat: string
{
    case XLSX = 'xlsx';
    case XLS = 'xls';
    case ODS = 'ods';
    case CSV = 'csv';
    case JSON = 'json';

    public static function fromFileName(string $fileName): ?self
    {
        return match (strtolower(pathinfo($fileName, PATHINFO_EXTENSION))) {
            'xlsx', 'xlsm' => self::XLSX,
            'xls' => self::XLS,
            'ods' => self::ODS,
            'csv', 'tsv', 'txt' => self::CSV,
            default => null,
        };
    }

    public function canRead(): bool
    {
        return $this !== self::JSON;
    }

    /** Whether the format keeps a whole workbook, not only the values of one sheet. */
    public function keepsWorkbook(): bool
    {
        return in_array($this, [self::XLSX, self::XLS, self::ODS], true);
    }

    public function mimeType(): string
    {
        return match ($this) {
            self::XLSX => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            self::XLS => 'application/vnd.ms-excel',
            self::ODS => 'application/vnd.oasis.opendocument.spreadsheet',
            self::CSV => 'text/csv',
            self::JSON => 'application/json',
        };
    }

    /** @return list<string> */
    public static function readableExtensions(): array
    {
        return ['xlsx', 'xlsm', 'xls', 'ods', 'csv', 'tsv', 'txt'];
    }
}
