<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Storage;

use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRoot;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRootProvider;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceAccess;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use PHPUnit\Framework\TestCase;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\Security\Core\Role\RoleHierarchy;
use Symfony\Component\Security\Core\User\InMemoryUser;

class WorkspaceAccessTest extends TestCase
{
    public function test_a_workspace_without_roles_is_open(): void
    {
        $workspace = new DocumentRoot('a', 'Offen', '/srv/a');

        $this->assertTrue(WorkspaceAccess::allows($workspace, ['ACCESS_DOCUMENTS'], false));
        $this->assertTrue(WorkspaceAccess::allows($workspace, ['ACCESS_DOCUMENTS'], true));
    }

    public function test_read_roles_limit_who_sees_it_and_without_write_roles_readers_write(): void
    {
        $workspace = new DocumentRoot('a', 'HR', '/srv/a', '', ['ROLE_HR']);

        $this->assertFalse(WorkspaceAccess::allows($workspace, ['ACCESS_DOCUMENTS'], false));
        $this->assertTrue(WorkspaceAccess::allows($workspace, ['ROLE_HR'], false));
        $this->assertTrue(WorkspaceAccess::allows($workspace, ['ROLE_HR'], true));
    }

    public function test_write_roles_limit_writing_and_imply_reading(): void
    {
        $workspace = new DocumentRoot('a', 'Logs', '/srv/a', '', [], ['ROLE_OPS']);

        $this->assertTrue(WorkspaceAccess::allows($workspace, ['ROLE_USER'], false));
        $this->assertFalse(WorkspaceAccess::allows($workspace, ['ROLE_USER'], true));
        $this->assertTrue(WorkspaceAccess::allows($workspace, ['ROLE_OPS'], true));

        $closed = new DocumentRoot('b', 'Geheim', '/srv/b', '', ['ROLE_READER'], ['ROLE_OPS']);
        $this->assertTrue(WorkspaceAccess::allows($closed, ['ROLE_OPS'], false));
        $this->assertTrue(WorkspaceAccess::allows($closed, ['ROLE_READER'], false));
        $this->assertFalse(WorkspaceAccess::allows($closed, ['ROLE_READER'], true));
    }

    public function test_administrators_may_everything(): void
    {
        $workspace = new DocumentRoot('a', 'Geheim', '/srv/a', '', ['ROLE_HR'], ['ROLE_HR']);

        $this->assertTrue(WorkspaceAccess::allows($workspace, ['ROLE_ADMIN'], true));
    }

    public function test_roles_of_the_hierarchy_count_and_hidden_workspaces_are_not_found(): void
    {
        $security = $this->createStub(Security::class);
        $security->method('getUser')->willReturn(new InMemoryUser('lea', null, ['ROLE_HR_LEAD']));
        $access = new WorkspaceAccess($security, new RoleHierarchy(['ROLE_HR_LEAD' => ['ROLE_HR']]));
        $hr = new DocumentRoot('a', 'HR', '/srv/a', '', ['ROLE_HR']);
        $finance = new DocumentRoot('b', 'Finanzen', '/srv/b', '', ['ROLE_FINANCE']);
        $readOnly = new DocumentRoot('c', 'Logs', '/srv/c', '', [], ['ROLE_OPS']);

        $this->assertSame([$hr, $readOnly], $access->readable([$hr, $finance, $readOnly]));
        $this->assertTrue($access->canWrite($hr));

        try {
            $access->assert($finance, false);
            $this->fail('A workspace without read permission was handed out');
        } catch (DocumentUploadException $exception) {
            $this->assertSame(404, $exception->getCode());
        }
        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(403);
        $access->assert($readOnly, true);
    }

    public function test_the_settings_mask_keeps_roles_as_one_line(): void
    {
        $this->assertSame(['ROLE_HR', 'ROLE_OPS'], DocumentRootProvider::roles(' role_hr, ROLE_OPS;ROLE_HR '));
        $this->assertSame([], DocumentRootProvider::roles(''));
        $this->assertSame(['ROLE_A'], DocumentRootProvider::roles(['ROLE_A', '']));
    }
}
