<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Storage;

use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;

/**
 * Everything there is to know about the workspaces, for the administrators of the
 * Workspace-Management page: the configuration as it is stored, where each directory really
 * is, whether it can be read and written, what lies in it, how much room the drive has left
 * and how many documents are registered - those of a workspace that no longer exists included.
 */
class WorkspaceInspector
{
    /** Directories are walked only this far - a huge tree must not hold the page up. */
    public const MAX_ENTRIES = 20000;

    public function __construct(
        private readonly DocumentRootProvider $documentRootProvider,
        private readonly WorkspaceStorage     $workspaceStorage,
        private readonly DocumentRepository   $documentRepository,
    )
    {
    }

    /** @return array<string, mixed> */
    public function inspect(): array
    {
        $documents = $this->documentRepository->countByDocumentRoot();
        $workspaces = [];
        foreach ($this->documentRootProvider->all() as $workspace) {
            $workspaces[] = $this->inspectWorkspace($workspace, $documents[$workspace->id] ?? 0);
            unset($documents[$workspace->id]);
        }

        return [
            'workspaceRoot' => $this->documentRootProvider->workspaceRoot(),
            'workspaceRootAliases' => $this->documentRootProvider->workspaceRootAliases(),
            'incompleteRows' => count($this->documentRootProvider->rows()) - count($workspaces),
            // documents of a workspace id that is not configured (any more), or of none
            'orphanedDocuments' => array_sum($documents),
            'workspaces' => $workspaces,
        ];
    }

    /** @return array<string, mixed> */
    private function inspectWorkspace(DocumentRoot $workspace, int $documents): array
    {
        $info = [
            'id' => $workspace->id,
            'name' => $workspace->name,
            'description' => $workspace->description,
            'path' => $workspace->path,
            'readRoles' => $workspace->readRoles,
            'writeRoles' => $workspace->writeRoles,
            'relative' => !WorkspaceStorage::isAbsolute($workspace->path),
            'absolutePath' => null,
            'resolvedPath' => null,
            'exists' => false,
            'readable' => false,
            'writable' => false,
            'problem' => null,
            'documents' => $documents,
            'files' => null,
            'directories' => null,
            'bytes' => null,
            'truncated' => false,
            'diskFree' => null,
            'diskTotal' => null,
            'modifiedAt' => null,
        ];

        try {
            $info['absolutePath'] = $this->workspaceStorage->configuredPathOf($workspace);
            $root = $this->workspaceStorage->rootOf($workspace);
        } catch (DocumentUploadException) {
            $info['problem'] = $info['absolutePath'] === null
                ? 'Relativer Pfad, aber kein Workspace Root konfiguriert'
                : 'Das Verzeichnis existiert nicht';

            return $info;
        }

        $info['resolvedPath'] = $root;
        $info['exists'] = true;
        $info['readable'] = is_readable($root);
        $info['writable'] = is_writable($root);
        $modified = @filemtime($root);
        $info['modifiedAt'] = $modified === false ? null : date(\DateTimeInterface::ATOM, $modified);
        $free = @disk_free_space($root);
        $total = @disk_total_space($root);
        $info['diskFree'] = $free === false ? null : (int)$free;
        $info['diskTotal'] = $total === false ? null : (int)$total;
        if (!$info['readable']) {
            $info['problem'] = 'Das Verzeichnis ist nicht lesbar';

            return $info;
        }
        if (!$info['writable']) {
            $info['problem'] = 'Das Verzeichnis ist nicht beschreibbar - Hochladen und Ändern schlagen fehl';
        }

        return [...$info, ...self::contents($root)];
    }

    /** @return array{files: int, directories: int, bytes: int, truncated: bool} */
    private static function contents(string $root): array
    {
        $files = 0;
        $directories = 0;
        $bytes = 0;
        $seen = 0;
        try {
            // links are counted, not followed - they may lead out of the workspace
            $items = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::SELF_FIRST,
                \RecursiveIteratorIterator::CATCH_GET_CHILD
            );
            foreach ($items as $item) {
                /** @var \SplFileInfo $item */
                if (++$seen > self::MAX_ENTRIES) {
                    return ['files' => $files, 'directories' => $directories, 'bytes' => $bytes, 'truncated' => true];
                }
                if ($item->isDir() && !$item->isLink()) {
                    $directories++;
                } else {
                    $files++;
                    $bytes += $item->isLink() ? 0 : (int)$item->getSize();
                }
            }
        } catch (\UnexpectedValueException|\RuntimeException) {
            return ['files' => $files, 'directories' => $directories, 'bytes' => $bytes, 'truncated' => true];
        }

        return ['files' => $files, 'directories' => $directories, 'bytes' => $bytes, 'truncated' => false];
    }
}
