<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Storage;

use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\Security\Core\Role\RoleHierarchyInterface;

/**
 * Who may use which workspace. On top of the permission ACCESS_DOCUMENTS, which every
 * documents feature asks for, a workspace can name roles (DocumentRoot):
 *
 * - reading (seeing the workspace, listing, viewing, downloading) needs one of its read
 *   roles - or one of its write roles, writing implies reading;
 * - writing (upload, new folder, rename, move, delete, saving a PDF) needs one of its
 *   write roles - without write roles, everybody who may read may write;
 * - an empty list restricts nothing, so a workspace without roles is open as before;
 * - ROLE_ADMIN may everything.
 *
 * The roles of the user are taken with the role hierarchy, so a role that implies one of
 * the workspace counts.
 */
class WorkspaceAccess
{
    public const ADMIN_ROLE = 'ROLE_ADMIN';

    public function __construct(
        private readonly Security                $security,
        private readonly ?RoleHierarchyInterface $roleHierarchy = null,
    )
    {
    }

    public function canRead(DocumentRoot $workspace): bool
    {
        return self::allows($workspace, $this->roles(), false);
    }

    public function canWrite(DocumentRoot $workspace): bool
    {
        return self::allows($workspace, $this->roles(), true);
    }

    /**
     * @param DocumentRoot[] $workspaces
     * @return list<DocumentRoot> the ones the user may see
     */
    public function readable(array $workspaces): array
    {
        $roles = $this->roles();

        return array_values(array_filter($workspaces, static fn(DocumentRoot $workspace): bool => self::allows($workspace, $roles, false)));
    }

    /**
     * Refuses a workspace the user may not use. One that may not even be read is answered
     * like an unknown one - its name and existence stay hidden.
     */
    public function assert(DocumentRoot $workspace, bool $write): void
    {
        $roles = $this->roles();
        if (!self::allows($workspace, $roles, false)) {
            throw DocumentUploadException::notFound(sprintf('Workspace "%s" not found', $workspace->id));
        }
        if ($write && !self::allows($workspace, $roles, true)) {
            throw DocumentUploadException::forbidden(sprintf('No permission to change workspace "%s"', $workspace->name));
        }
    }

    /** @param list<string> $roles the roles of the user, those of the role hierarchy included */
    public static function allows(DocumentRoot $workspace, array $roles, bool $write): bool
    {
        if (in_array(self::ADMIN_ROLE, $roles, true)) {
            return true;
        }
        $hasOne = static fn(array $required): bool => array_intersect($required, $roles) !== [];
        if ($workspace->writeRoles !== [] && $hasOne($workspace->writeRoles)) {
            return true;
        }
        if ($write && $workspace->writeRoles !== []) {
            return false;
        }

        return $workspace->readRoles === [] || $hasOne($workspace->readRoles);
    }

    /** @return list<string> */
    private function roles(): array
    {
        $roles = $this->security->getUser()?->getRoles() ?? [];
        if ($this->roleHierarchy !== null) {
            $roles = $this->roleHierarchy->getReachableRoleNames($roles);
        }

        return array_values(array_map('strval', $roles));
    }
}
