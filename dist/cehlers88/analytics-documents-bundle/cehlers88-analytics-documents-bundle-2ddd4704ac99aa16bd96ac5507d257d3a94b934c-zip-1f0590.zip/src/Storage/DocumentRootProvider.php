<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Storage;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsDocumentsBundle\Configuration\GeneralConfigurationGroup;

/**
 * The workspaces, as they are configured under "documentRoots" - one row per
 * workspace, identified by its unique id.
 */
class DocumentRootProvider
{
    public function __construct(
        private readonly ConfigurationProvider $configurationProvider,
    )
    {
    }

    /** @return DocumentRoot[] the usable ones - a row without id or path is left out */
    public function all(): array
    {
        $roots = [];
        foreach ($this->rows() as $row) {
            $id = trim((string)($row['id'] ?? ''));
            $path = trim((string)($row['path'] ?? ''));
            if ($id === '' || $path === '') {
                continue;
            }
            $roots[$id] = new DocumentRoot(
                $id,
                trim((string)($row['name'] ?? '')) ?: $id,
                $path,
                trim((string)($row['description'] ?? '')),
                self::roles($row['readRoles'] ?? ''),
                self::roles($row['writeRoles'] ?? '')
            );
        }

        return array_values($roots);
    }

    /**
     * The rows as they are stored, incomplete ones included - what WorkspaceConfiguration
     * writes back, so nothing it does not know about gets lost.
     *
     * @return list<array<string, mixed>>
     */
    public function rows(): array
    {
        return self::decodeRows($this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'documentRoots', -1, []));
    }

    /** @return list<string> the configured "Workspaces Root aliases" */
    public function workspaceRootAliases(): array
    {
        $aliases = [];
        foreach (self::decodeRows($this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'workspaceRootAliases', -1, [])) as $row) {
            $alias = trim((string)($row['alias'] ?? ''));
            if ($alias !== '') {
                $aliases[] = $alias;
            }
        }

        return $aliases;
    }

    public function find(string $id): ?DocumentRoot
    {
        foreach ($this->all() as $root) {
            if ($root->id === $id) {
                return $root;
            }
        }

        return null;
    }

    /** The configured root that relative workspace paths lie below; "" if none. */
    public function workspaceRoot(): string
    {
        return trim((string)$this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'workspaceRoot', -1, ''));
    }

    /**
     * The roles of a workspace row: the settings mask keeps them as one line, separated by
     * commas (or blanks), the API may send a list.
     *
     * @return list<string>
     */
    public static function roles(mixed $value): array
    {
        $parts = is_array($value) ? $value : preg_split('/[\s,;]+/', is_scalar($value) ? (string)$value : '');
        $roles = [];
        foreach ((array)$parts as $part) {
            $role = strtoupper(trim(is_scalar($part) ? (string)$part : ''));
            if ($role !== '' && !in_array($role, $roles, true)) {
                $roles[] = $role;
            }
        }

        return $roles;
    }

    /** @return list<array<string, mixed>> */
    private static function decodeRows(mixed $rows): array
    {
        // newer rows come as arrays, older ones decoded from json text as objects
        $rows = is_string($rows) ? json_decode($rows, true) : json_decode((string)json_encode($rows), true);

        return array_values(array_filter(is_array($rows) ? $rows : [], 'is_array'));
    }
}
