<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Storage;

use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Repository\VariableStoreRepository;
use Cehlers88\AnalyticsDocumentsBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;

/**
 * Creates, changes and removes workspaces - the rows of the configured "documentRoots"
 * (GeneralConfigurationGroup), stored the way the configuration mask of the settings stores
 * them, so both stay interchangeable. Rows are written back with every field they carry, the
 * ones this class does not know included.
 */
class WorkspaceConfiguration
{
    private const MAX_LENGTH = 255;
    /** As the role names of the application (RoleCatalog) */
    private const ROLE_PATTERN = '/^[A-Z][A-Z0-9_]{1,63}$/D';

    public function __construct(
        private readonly DocumentRootProvider    $documentRootProvider,
        private readonly WorkspaceStorage        $workspaceStorage,
        private readonly VariableStoreRepository $variableStoreRepository,
        private readonly DocumentRepository      $documentRepository,
    )
    {
    }

    /**
     * @param string|null $id              null creates a new workspace
     * @param bool        $createDirectory create its directory if it does not exist yet
     * @param list<string>|string|null $readRoles  see WorkspaceAccess; null keeps what the row has
     * @param list<string>|string|null $writeRoles
     */
    public function save(?string $id, string $name, string $description, string $path, bool $createDirectory = false, array|string|null $readRoles = null, array|string|null $writeRoles = null): DocumentRoot
    {
        $name = self::text($name, 'Name');
        $path = self::text($path, 'Pfad');
        $description = trim($description);
        if (preg_match('/[\x00-\x08\x0b-\x1f\x7f]/', $description) === 1) {
            throw DocumentUploadException::badRequest('Die Beschreibung enthält Steuerzeichen');
        }

        $rows = $this->documentRootProvider->rows();
        $index = null;
        if ($id !== null) {
            foreach ($rows as $rowIndex => $row) {
                if (trim((string)($row['id'] ?? '')) === $id) {
                    $index = $rowIndex;
                    break;
                }
            }
            if ($index === null) {
                throw DocumentUploadException::notFound('Diesen Workspace gibt es nicht (mehr)');
            }
        }
        foreach ($rows as $rowIndex => $row) {
            if ($rowIndex !== $index && self::samePath((string)($row['path'] ?? ''), $path)) {
                throw DocumentUploadException::conflict(sprintf(
                    'Der Workspace "%s" verwendet dieses Verzeichnis schon',
                    trim((string)($row['name'] ?? '')) ?: (string)($row['id'] ?? '')
                ));
            }
        }

        $readRoles = self::checkedRoles($readRoles ?? ($index === null ? [] : ($rows[$index]['readRoles'] ?? '')), 'Leserollen');
        $writeRoles = self::checkedRoles($writeRoles ?? ($index === null ? [] : ($rows[$index]['writeRoles'] ?? '')), 'Schreibrollen');
        $workspace = new DocumentRoot($id ?? $this->newId($rows), $name, $path, $description, $readRoles, $writeRoles);
        // checked before anything is written: a relative path needs the workspace root
        try {
            $directory = $this->workspaceStorage->configuredPathOf($workspace);
        } catch (DocumentUploadException) {
            throw DocumentUploadException::badRequest('Ein relativer Pfad braucht einen konfigurierten Workspace Root - oder einen absoluten Pfad');
        }
        if ($createDirectory && !is_dir($directory) && !@mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw DocumentUploadException::storage(sprintf('Das Verzeichnis "%s" konnte nicht angelegt werden', $directory));
        }

        $row = [
            ...($index === null ? [] : $rows[$index]),
            'id' => $workspace->id,
            'name' => $workspace->name,
            'description' => $workspace->description,
            'path' => $workspace->path,
            // one line, as the settings mask keeps them
            'readRoles' => implode(', ', $workspace->readRoles),
            'writeRoles' => implode(', ', $workspace->writeRoles),
        ];
        if ($index === null) {
            $rows[] = $row;
        } else {
            $rows[$index] = $row;
        }
        $this->write($rows);

        return $workspace;
    }

    /**
     * Removes a workspace from the configuration. Its directory and files stay where they
     * are; a workspace that still has registered documents is refused, they would point
     * nowhere.
     */
    public function remove(string $id): void
    {
        $rows = $this->documentRootProvider->rows();
        $remaining = array_values(array_filter($rows, static fn(array $row): bool => trim((string)($row['id'] ?? '')) !== $id));
        if (count($remaining) === count($rows)) {
            throw DocumentUploadException::notFound('Diesen Workspace gibt es nicht (mehr)');
        }
        $documents = $this->documentRepository->count(['documentRootId' => $id]);
        if ($documents > 0) {
            throw DocumentUploadException::conflict(sprintf(
                'Im Workspace sind noch %d Dokument(e) registriert - erst diese löschen oder verschieben',
                $documents
            ));
        }

        $this->write($remaining);
    }

    /** @param list<array<string, mixed>> $rows */
    private function write(array $rows): void
    {
        $this->variableStoreRepository->setVariableValue(
            eMacroVariableContext::SERVER,
            GeneralConfigurationGroup::KEY . '.documentRoots',
            ['array', array_values($rows)]
        );
        $this->variableStoreRepository->flush();
    }

    /**
     * An id as the configuration mask makes them for a UNIQUE_ID field: 13 hex digits,
     * seconds and microseconds.
     *
     * @param list<array<string, mixed>> $rows
     */
    private function newId(array $rows): string
    {
        $taken = array_map(static fn(array $row): string => trim((string)($row['id'] ?? '')), $rows);
        do {
            $id = uniqid();
        } while (in_array($id, $taken, true));

        return $id;
    }

    private static function text(string $value, string $label): string
    {
        $value = trim($value);
        if ($value === '') {
            throw DocumentUploadException::badRequest(sprintf('%s fehlt', $label));
        }
        if (strlen($value) > self::MAX_LENGTH || preg_match('/[\x00-\x1f\x7f]/', $value) === 1) {
            throw DocumentUploadException::badRequest(sprintf('%s ist zu lang oder enthält Steuerzeichen', $label));
        }

        return $value;
    }

    /** @return list<string> */
    private static function checkedRoles(mixed $roles, string $label): array
    {
        $roles = DocumentRootProvider::roles($roles);
        foreach ($roles as $role) {
            if (preg_match(self::ROLE_PATTERN, $role) !== 1) {
                throw DocumentUploadException::badRequest(sprintf('%s: "%s" ist kein Rollenname (A-Z, 0-9, _)', $label, $role));
            }
        }

        return $roles;
    }

    private static function samePath(string $left, string $right): bool
    {
        $normalize = static fn(string $path): string => rtrim(str_replace('\\', '/', trim($path)), '/');

        return $normalize($left) !== '' && $normalize($left) === $normalize($right);
    }
}
