<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Storage;

/**
 * A workspace: an entry of the configured "documentRoots"
 * (GeneralConfigurationGroup). Its path is the root directory of its documents.
 *
 * Who may use it is up to its roles (see WorkspaceAccess): $readRoles to see it and its
 * files, $writeRoles to change something in it. An empty list restricts nothing.
 */
final class DocumentRoot
{
    public function __construct(
        public readonly string $id,
        public readonly string $name,
        public readonly string $path,
        public readonly string $description = '',
        /** @var list<string> */
        public readonly array  $readRoles = [],
        /** @var list<string> */
        public readonly array  $writeRoles = [],
    )
    {
    }
}
