<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 20:37
 */

namespace Cehlers88\AnalyticsDocumentsBundle\Configuration;

use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;

class GeneralConfigurationGroup extends AbstractConfigurationGroup
{
    public const KEY = 'documentsBundle.general';

    public function getItems(): array
    {
        return [
            ConfigurationItemDTO::create('workspaceRoot', 'Workspace Root', eInputType::TEXT_SINGLE_LINE, ''),
            ConfigurationItemDTO::createRepeat('workspaceRootAliases', 'Workspaces Root aliases', [
                ConfigurationItemDTO::create('alias', 'Alias', eInputType::TEXT_SINGLE_LINE, ''),
            ]),
            ConfigurationItemDTO::createRepeat('documentRoots', 'Workspaces', [
                ConfigurationItemDTO::create('id', 'ID', eInputType::UNIQUE_ID),
                ConfigurationItemDTO::create('name', 'Name', eInputType::TEXT_SINGLE_LINE, 'Workspace name'),
                ConfigurationItemDTO::create('description', 'Description', eInputType::TEXT_MULTI_LINE),
                ConfigurationItemDTO::create('path', 'Path', eInputType::TEXT_SINGLE_LINE, '/var/workspace'),
                // roles separated by commas; empty: everybody with ACCESS_DOCUMENTS (see WorkspaceAccess)
                ConfigurationItemDTO::create('readRoles', 'Read roles', eInputType::TEXT_SINGLE_LINE, ''),
                ConfigurationItemDTO::create('writeRoles', 'Write roles', eInputType::TEXT_SINGLE_LINE, ''),
            ], 'Here you can define the workspaces for the documents. Read and write roles (comma separated) limit who may see and change a workspace; empty means everybody with ACCESS_DOCUMENTS, administrators always may.')
        ];
    }

    public function getGroupTitle(): string
    {
        return 'Allgemeine Dokumenteneinstellungen';
    }

    public function getGroupDescription(): string
    {
        return 'Allgemeine Einstellungen für das Dokumentenmodul';
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}