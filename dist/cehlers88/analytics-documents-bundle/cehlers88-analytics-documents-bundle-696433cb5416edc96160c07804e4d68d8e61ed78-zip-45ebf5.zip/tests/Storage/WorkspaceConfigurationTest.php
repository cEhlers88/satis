<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Storage;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Repository\VariableStoreRepository;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRootProvider;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceConfiguration;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceStorage;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use PHPUnit\Framework\TestCase;

class WorkspaceConfigurationTest extends TestCase
{
    private string $directory;
    /** @var list<array<string, mixed>> what the store holds under documentRoots */
    private array $rows = [];
    private string $workspaceRoot = '';
    private int $documents = 0;
    /** @var list<array{0: string, 1: mixed}> name and value of every write */
    private array $written = [];

    protected function setUp(): void
    {
        $this->directory = sys_get_temp_dir() . '/workspace-configuration-' . bin2hex(random_bytes(4));
        mkdir($this->directory, 0775, true);
    }

    protected function tearDown(): void
    {
        exec('rm -rf ' . escapeshellarg($this->directory));
    }

    public function test_a_new_workspace_gets_an_id_and_its_directory(): void
    {
        $this->rows = [['id' => 'a1', 'name' => 'Alt', 'description' => '', 'path' => '/srv/alt', 'extra' => 'kept']];

        $workspace = $this->configuration()->save(null, ' Belege ', 'Quittungen', $this->directory . '/belege', true);

        $this->assertMatchesRegularExpression('/^[0-9a-f]{13}$/', $workspace->id);
        $this->assertDirectoryExists($this->directory . '/belege');
        $this->assertCount(1, $this->written);
        $this->assertSame('documentsBundle.general.documentRoots', $this->written[0][0]);
        [$type, $rows] = $this->written[0][1];
        $this->assertSame('array', $type);
        $this->assertSame('kept', $rows[0]['extra']);
        $this->assertSame(['id' => $workspace->id, 'name' => 'Belege', 'description' => 'Quittungen', 'path' => $this->directory . '/belege'], $rows[1]);
    }

    public function test_changing_a_workspace_keeps_its_other_fields(): void
    {
        $this->rows = [['id' => 'a1', 'name' => 'Alt', 'description' => '', 'path' => '/srv/alt', 'extra' => 'kept']];

        $this->configuration()->save('a1', 'Neu', 'Text', '/srv/neu');

        $this->assertSame([['id' => 'a1', 'name' => 'Neu', 'description' => 'Text', 'path' => '/srv/neu', 'extra' => 'kept']], $this->written[0][1][1]);
    }

    public function test_an_unknown_workspace_can_not_be_changed(): void
    {
        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(404);

        $this->configuration()->save('nope', 'Neu', '', '/srv/neu');
    }

    public function test_two_workspaces_can_not_share_a_directory(): void
    {
        $this->rows = [['id' => 'a1', 'name' => 'Alt', 'path' => '/srv/alt/']];

        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(409);

        $this->configuration()->save(null, 'Zweiter', '', '/srv/alt');
    }

    public function test_a_relative_path_needs_the_workspace_root(): void
    {
        try {
            $this->configuration()->save(null, 'Relativ', '', 'belege');
            $this->fail('A relative path without workspace root was accepted');
        } catch (DocumentUploadException $exception) {
            $this->assertSame(400, $exception->getCode());
            $this->assertSame([], $this->written);
        }

        $this->workspaceRoot = $this->directory;
        $this->configuration()->save(null, 'Relativ', '', 'belege', true);
        $this->assertDirectoryExists($this->directory . '/belege');
    }

    public function test_name_and_path_are_required(): void
    {
        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(400);

        $this->configuration()->save(null, '  ', '', '/srv/x');
    }

    public function test_a_workspace_with_documents_is_not_removed(): void
    {
        $this->rows = [['id' => 'a1', 'name' => 'Alt', 'path' => '/srv/alt'], ['id' => 'b2', 'name' => 'B', 'path' => '/srv/b']];
        $this->documents = 3;

        try {
            $this->configuration()->remove('a1');
            $this->fail('A workspace with documents was removed');
        } catch (DocumentUploadException $exception) {
            $this->assertSame(409, $exception->getCode());
        }

        $this->documents = 0;
        $this->configuration()->remove('a1');
        $this->assertSame([['id' => 'b2', 'name' => 'B', 'path' => '/srv/b']], $this->written[0][1][1]);
    }

    private function configuration(): WorkspaceConfiguration
    {
        $configurationProvider = $this->createStub(ConfigurationProvider::class);
        $configurationProvider->method('getValue')->willReturnCallback(
            fn(string $group, string $item): mixed => match ($item) {
                'documentRoots' => $this->rows,
                'workspaceRoot' => $this->workspaceRoot,
                default => [],
            }
        );
        $provider = new DocumentRootProvider($configurationProvider);

        $store = $this->createStub(VariableStoreRepository::class);
        $store->method('setVariableValue')->willReturnCallback(function (eMacroVariableContext $context, string $name, mixed $value): bool {
            $this->assertSame(eMacroVariableContext::SERVER, $context);
            $this->written[] = [$name, $value];

            return true;
        });
        $store->method('flush')->willReturnSelf();

        $documents = $this->createStub(DocumentRepository::class);
        $documents->method('count')->willReturnCallback(fn(): int => $this->documents);

        return new WorkspaceConfiguration($provider, new WorkspaceStorage($provider), $store, $documents);
    }
}
