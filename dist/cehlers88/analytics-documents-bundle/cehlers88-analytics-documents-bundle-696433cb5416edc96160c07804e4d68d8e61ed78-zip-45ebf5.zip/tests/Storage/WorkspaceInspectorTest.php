<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Storage;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRootProvider;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceInspector;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceStorage;
use PHPUnit\Framework\TestCase;

class WorkspaceInspectorTest extends TestCase
{
    private string $directory;

    protected function setUp(): void
    {
        $this->directory = sys_get_temp_dir() . '/workspace-inspector-' . bin2hex(random_bytes(4));
        mkdir($this->directory . '/root/sub', 0775, true);
        mkdir($this->directory . '/outside');
        file_put_contents($this->directory . '/root/a.txt', '12345');
        file_put_contents($this->directory . '/root/sub/b.txt', '123');
        file_put_contents($this->directory . '/outside/big.bin', str_repeat('x', 1000));
        symlink($this->directory . '/outside', $this->directory . '/root/link');
    }

    protected function tearDown(): void
    {
        exec('rm -rf ' . escapeshellarg($this->directory));
    }

    public function test_tells_everything_about_the_workspaces(): void
    {
        $result = $this->inspector([
            ['id' => 'ok', 'name' => 'Da', 'description' => 'Text', 'path' => 'root'],
            ['id' => 'gone', 'name' => 'Weg', 'path' => '/does/not/exist'],
            ['id' => '', 'name' => 'Halb', 'path' => ''],
        ], ['ok' => 2, 'gone' => 1, 'deleted' => 4])->inspect();

        $this->assertSame($this->directory, $result['workspaceRoot']);
        $this->assertSame(['nas'], $result['workspaceRootAliases']);
        $this->assertSame(1, $result['incompleteRows']);
        $this->assertSame(4, $result['orphanedDocuments']);

        [$present, $missing] = $result['workspaces'];
        $this->assertTrue($present['relative']);
        $this->assertSame($this->directory . '/root', $present['absolutePath']);
        $this->assertTrue($present['exists']);
        $this->assertTrue($present['writable']);
        $this->assertNull($present['problem']);
        $this->assertSame(2, $present['documents']);
        // the link is counted as an entry, what lies behind it is not
        $this->assertSame(['files' => 3, 'directories' => 1, 'bytes' => 8, 'truncated' => false],
            array_intersect_key($present, array_flip(['files', 'directories', 'bytes', 'truncated'])));
        $this->assertGreaterThan(0, $present['diskTotal']);

        $this->assertFalse($missing['exists']);
        $this->assertSame('Das Verzeichnis existiert nicht', $missing['problem']);
        $this->assertSame(1, $missing['documents']);
        $this->assertNull($missing['files']);
    }

    /** @param array<string, int> $documents */
    private function inspector(array $rows, array $documents): WorkspaceInspector
    {
        $configurationProvider = $this->createStub(ConfigurationProvider::class);
        $configurationProvider->method('getValue')->willReturnCallback(
            fn(string $group, string $item): mixed => match ($item) {
                'documentRoots' => $rows,
                'workspaceRoot' => $this->directory,
                'workspaceRootAliases' => [['alias' => 'nas'], ['alias' => ' ']],
                default => [],
            }
        );
        $provider = new DocumentRootProvider($configurationProvider);
        $repository = $this->createStub(DocumentRepository::class);
        $repository->method('countByDocumentRoot')->willReturn($documents);

        return new WorkspaceInspector($provider, new WorkspaceStorage($provider), $repository);
    }
}
