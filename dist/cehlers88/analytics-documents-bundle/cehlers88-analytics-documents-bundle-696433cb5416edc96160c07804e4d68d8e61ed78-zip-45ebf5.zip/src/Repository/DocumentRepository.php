<?php

namespace Cehlers88\AnalyticsDocumentsBundle\Repository;

use Cehlers88\AnalyticsDocumentsBundle\Entity\Document;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Document>
 */
class DocumentRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Document::class);
    }

    /**
     * The documents of an entry of a workspace: the one of the file at $path, or those
     * below the directory at $path.
     *
     * @return list<Document>
     */
    public function findInside(string $documentRootId, string $path): array
    {
        return $this->createQueryBuilder('d')
            ->andWhere('d.documentRootId = :root')
            ->andWhere('d.path = :path OR d.path LIKE :prefix')
            ->setParameter('root', $documentRootId)
            ->setParameter('path', $path)
            ->setParameter('prefix', addcslashes($path, '%_\\') . '/%')
            ->getQuery()
            ->getResult();
    }

    /** @return array<string, int> how many documents each workspace (documentRootId) has */
    public function countByDocumentRoot(): array
    {
        $counts = [];
        $rows = $this->createQueryBuilder('d')
            ->select('d.documentRootId AS root, COUNT(d.id) AS documents')
            ->groupBy('d.documentRootId')
            ->getQuery()
            ->getArrayResult();
        foreach ($rows as $row) {
            $counts[(string)$row['root']] = (int)$row['documents'];
        }

        return $counts;
    }

    //    /**
    //     * @return Document[] Returns an array of Document objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('d')
    //            ->andWhere('d.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('d.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?Document
    //    {
    //        return $this->createQueryBuilder('d')
    //            ->andWhere('d.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }
}
