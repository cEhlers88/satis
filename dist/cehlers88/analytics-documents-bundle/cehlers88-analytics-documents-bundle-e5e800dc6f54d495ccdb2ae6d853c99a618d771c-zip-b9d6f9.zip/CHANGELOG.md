# Changelog

## [0.1.12](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.11...v0.1.12) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([245cce1](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/245cce1be52464b545eb2c3603fc805e701c6bc1))

## [0.1.11](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.10...v0.1.11) (2026-03-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.5.4 ([#21](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/21)) ([c691ae4](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/c691ae447d946b498f72ccb3c503c0373f8ef624))
* **deps:** update dependency cehlers88/analytics-core to v0.5.5 ([#23](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/23)) ([cd72a5f](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/cd72a5f438673122d92e7fac996af9b9abb8abc8))

## [0.1.10](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.9...v0.1.10) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.5 ([#20](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/20)) ([56c7d0b](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/56c7d0bf1d044976bd88e53e4126bcaf2c6e0543))
* **deps:** update dependency cehlers88/analytics-core to v0.4.2 ([#18](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/18)) ([8cb1800](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/8cb180059dc07a0cd75013cc3839198d00ee4970))

## [0.1.9](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.8...v0.1.9) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([ab5c3cf](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/ab5c3cfae0a4cfa9e0b1d263bbed098f047a3a19))

## [0.1.8](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.7...v0.1.8) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([93f6ff1](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/93f6ff16d745cef1ee12bd6da7e1655ba4535bdc))

## [0.1.7](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.6...v0.1.7) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#11](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/11)) ([8e35884](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/8e35884edf6dd36f333a43ac7e54ebe376814442))
* **deps:** update dependency cehlers88/analytics-core to v0.3.1 ([#13](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/13)) ([f18a53c](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/f18a53c2fe3283987d21bc07b8b5c63145b1ab57))

## [0.1.6](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.5...v0.1.6) (2026-03-19)


### Miscellaneous Chores

* bump analytics-core dependency to ^0.3 in composer.json ([bdbe964](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/bdbe96426a53579dc5e39f352235bf0d4f7c95bf))

## [0.1.5](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.4...v0.1.5) (2026-01-22)


### Miscellaneous Chores

* Update dependency versions for analytics-core ([bf25e4b](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/bf25e4b951c43aa218e61e28a94cb79ab958fdd2))

## [0.1.4](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.3...v0.1.4) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.2.0@dev ([#7](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/7)) ([8378af3](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/8378af3a8d7a1a5de117dbd3692c2ffd1b3664e1))
* **deps:** update dependency cehlers88/analytics-core to v0.2.1 ([#6](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/6)) ([226e1d5](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/226e1d5e4a523d2319491eaeceb0ff8b0a78e317))

## [0.1.3](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.2...v0.1.3) (2026-01-21)


### Miscellaneous Chores

* add GitHub workflow to trigger Satis rebuild on release ([2c855c9](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/2c855c99dd5618e07a68b8ecc581b283fc1a9fa0))
* **deps:** update dependency cehlers88/analytics-core to v0.1.5 ([#4](https://github.com/cEhlers88/AnalyticsDocumentsBundle/issues/4)) ([658cacc](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/658cacc4abb705cdd9fca10e68f7d06edcc93433))

## [0.1.2](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([00fc73b](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/00fc73be578d47e100a2ea1a64161dcc99a5ed5e))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([a6093fb](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/a6093fb856758c2212f23770f995781c9a7c3dc1))

## [0.1.1](https://github.com/cEhlers88/AnalyticsDocumentsBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([6b1fc84](https://github.com/cEhlers88/AnalyticsDocumentsBundle/commit/6b1fc846fe3ca819c8167e17b107feb496140b10))
