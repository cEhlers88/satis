<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Entity;

use Cehlers88\AnalyticsDocumentsBundle\Entity\Letterhead;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadDefinition;
use PHPUnit\Framework\TestCase;

class LetterheadTest extends TestCase
{
    public function testKeepsItsDefinition(): void
    {
        $definition = LetterheadDefinition::fromArray(['name' => 'Firma', 'definition' => [
            'headerText' => ['mode' => 'replace', 'value' => 'Kopf'],
            'marginTop' => ['mode' => 'replace', 'value' => 60],
        ]]);

        $letterhead = new Letterhead($definition, null);

        $this->assertEquals($definition, $letterhead->toDefinition());
        $this->assertSame('Firma', $letterhead->getName());
    }

    public function testParentIsPartOfTheDefinition(): void
    {
        $parent = new Letterhead(LetterheadDefinition::fromArray(['name' => 'Konzern']), null);
        (new \ReflectionProperty(Letterhead::class, 'id'))->setValue($parent, 7);

        $child = new Letterhead(LetterheadDefinition::fromArray(['name' => 'Tochter', 'parentId' => 7]), $parent);

        $this->assertSame($parent, $child->getParent());
        $this->assertSame(7, $child->toDefinition()->parentId);
        $this->assertSame(['mode' => 'inherit'], $child->toDefinition()->fields['footerText']);
    }
}
