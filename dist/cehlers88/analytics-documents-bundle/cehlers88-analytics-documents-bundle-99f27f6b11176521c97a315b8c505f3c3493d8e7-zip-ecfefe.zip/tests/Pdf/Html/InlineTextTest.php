<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf\Html;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Html\InlineText;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class InlineTextTest extends TestCase
{
    #[DataProvider('inline')]
    public function testInline(string $text, string $html): void
    {
        $this->assertSame($html, InlineText::inline($text));
    }

    public static function inline(): iterable
    {
        yield 'plain' => ['Hallo', 'Hallo'];
        yield 'escaped html' => ['<b>x</b> & "y"', '&lt;b&gt;x&lt;/b&gt; &amp; &quot;y&quot;'];
        yield 'bold' => ['ein **fettes** Wort', 'ein <strong>fettes</strong> Wort'];
        yield 'italic' => ['ein *kursives* Wort', 'ein <em>kursives</em> Wort'];
        yield 'underline' => ['__unten__', '<u>unten</u>'];
        yield 'nested' => ['**fett und *kursiv***', '<strong>fett und <em>kursiv</em></strong>'];
        yield 'lonely asterisks stay' => ['3 * 4 = 12 und 2*3', '3 * 4 = 12 und 2*3'];
        yield 'escaped asterisk' => ['\*kein\* Stern', '*kein* Stern'];
        yield 'snake_case stays' => ['file_name_here', 'file_name_here'];
        yield 'unclosed stays text' => ['**offen und *auch', '**offen und *auch'];
        yield 'both at once' => ['***beides***', '<strong><em>beides</em></strong>'];
        yield 'crossed markers are nested properly' => ['**a *b** c*', '<strong>a <em>b</em></strong><em> c</em>'];
    }

    public function testBlockMakesListsOfDashLines(): void
    {
        $html = InlineText::block("**Entwickler**, Firma\n- Aufgabe *eins*\n• Aufgabe zwei\nDanach");

        $this->assertSame(
            '<div class="pre"><strong>Entwickler</strong>, Firma</div>'
            . '<ul><li>Aufgabe <em>eins</em></li><li>Aufgabe zwei</li></ul>'
            . '<div class="pre">Danach</div>',
            $html
        );
    }

    public function testBlockKeepsLineBreaksAndIndentation(): void
    {
        $this->assertSame("<div class=\"pre\">a\n  b\n\nc</div>", InlineText::block("a\n  b\r\n\nc"));
    }

    public function testDashWithoutSpaceIsNoListItem(): void
    {
        $this->assertSame('<div class="pre">-5 Grad</div>', InlineText::block('-5 Grad'));
    }
}
