<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf\Content;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\ContentTemplates;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\DocumentContent;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\HeadingColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\ImageColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TableColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TextColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\PdfCreator;
use Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf\Letterhead\LetterheadDataTest;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class DocumentContentTest extends TestCase
{
    public function testReadsRowsOfEveryColumnType(): void
    {
        $content = DocumentContent::fromArray([
            'settings' => ['fontFamily' => 'serif', 'fontSize' => 10, 'lineHeight' => '1.5', 'color' => '#333333', 'accentColor' => '#880726', 'rowSpacing' => 4],
            'rows' => [
                ['columns' => [['type' => 'heading', 'text' => 'Berufserfahrung', 'level' => 2, 'rule' => true]]],
                ['widths' => [1, 3], 'gap' => 4, 'spaceAfter' => 0, 'pageBreakBefore' => true, 'columns' => [
                    ['type' => 'text', 'text' => '2021 – heute', 'style' => ['align' => 'right', 'bold' => true, 'fontSize' => 9, 'color' => '#555555', 'verticalAlign' => 'middle']],
                    ['type' => 'table', 'cells' => [['A', 'B'], ['1']], 'headerRow' => false, 'borders' => false, 'striped' => true, 'columnWidths' => [1, 2]],
                ]],
                ['columns' => [['type' => 'image', 'src' => 'data:image/png;base64,' . base64_encode(LetterheadDataTest::png()), 'width' => 40]]],
            ],
        ]);

        $this->assertSame('DejaVu Serif', $content->settings->font());
        $this->assertSame(1.5, $content->settings->lineHeight);
        $this->assertInstanceOf(HeadingColumn::class, $content->rows[0]->columns[0]);
        $this->assertTrue($content->rows[0]->columns[0]->rule);
        $row = $content->rows[1];
        $this->assertSame([25.0, 75.0], $row->percentages());
        $this->assertSame([4, 0, true], [$row->gap, $row->spaceAfter, $row->pageBreakBefore]);
        $this->assertInstanceOf(TextColumn::class, $row->columns[0]);
        $this->assertSame(['right', true, 9, '#555555', 'middle'], [
            $row->columns[0]->style->align, $row->columns[0]->style->bold, $row->columns[0]->style->fontSize,
            $row->columns[0]->style->color, $row->columns[0]->style->verticalAlign,
        ]);
        $table = $row->columns[1];
        $this->assertInstanceOf(TableColumn::class, $table);
        // ragged rows are filled up
        $this->assertSame([['A', 'B'], ['1', '']], $table->cells);
        $this->assertSame([1, 2], $table->columnWidths);
        $this->assertInstanceOf(ImageColumn::class, $content->rows[2]->columns[0]);
        $this->assertSame(40, $content->rows[2]->columns[0]->width);
        $this->assertSame(mb_strlen('Berufserfahrung2021 – heuteAB1'), $content->textLength());
    }

    public function testMissingWidthsAreEqualShares(): void
    {
        $content = DocumentContent::fromArray(['rows' => [['columns' => [['text' => 'a'], ['text' => 'b'], ['text' => 'c']]]]]);

        $this->assertSame([1, 1, 1], $content->rows[0]->widths);
    }

    #[DataProvider('refused')]
    public function testRefuses(array $data, string $messagePart, int $statusCode = 400): void
    {
        try {
            DocumentContent::fromArray($data);
            $this->fail('The content should have been refused');
        } catch (PdfCreatorException $exception) {
            $this->assertStringContainsString($messagePart, $exception->getMessage());
            $this->assertSame($statusCode, $exception->getStatusCode());
        }
    }

    public static function refused(): iterable
    {
        $text = static fn(string $text = 'x'): array => ['type' => 'text', 'text' => $text];
        yield 'rows no list' => [['rows' => ['a' => 1]], 'Inhalt:'];
        yield 'row without columns' => [['rows' => [['columns' => []]]], 'Zeile 1:'];
        yield 'too many columns' => [['rows' => [['columns' => array_fill(0, 5, $text())]]], 'Zeile 1:'];
        yield 'unknown type' => [['rows' => [['columns' => [['type' => 'video']]]]], 'Typ'];
        yield 'bad alignment names its column' => [['rows' => [['columns' => [$text()]], ['columns' => [$text(), ['type' => 'text', 'style' => ['align' => 'middle']]]]]], 'Zeile 2, Spalte 2:'];
        yield 'bad colour' => [['rows' => [['columns' => [['type' => 'text', 'style' => ['color' => 'red']]]]]], 'Farbe'];
        yield 'bad width' => [['rows' => [['widths' => [0, 1], 'columns' => [$text(), $text()]]]], 'Spaltenbreite'];
        yield 'bad font' => [['settings' => ['fontFamily' => 'comic'], 'rows' => []], 'Schrift'];
        yield 'bad line height' => [['settings' => ['lineHeight' => 5], 'rows' => []], 'Zeilenabstand'];
        yield 'too many table columns' => [['rows' => [['columns' => [['type' => 'table', 'cells' => [array_fill(0, 13, 'x')]]]]]], 'Spalten'];
        yield 'svg image' => [['rows' => [['columns' => [['type' => 'image', 'src' => 'data:image/svg+xml;base64,' . base64_encode('<svg/>')]]]]], 'Bild'];
        yield 'too much text' => [['rows' => [['columns' => [$text(str_repeat('a', PdfCreator::MAX_TEXT_LENGTH + 1))]]]], 'Zeichen', 413];
        yield 'too many rows' => [['rows' => array_fill(0, DocumentContent::MAX_ROWS + 1, ['columns' => [$text()]])], 'Zeilen', 413];
    }

    public function testEmptyContentIsEmpty(): void
    {
        $this->assertTrue(DocumentContent::fromArray(['rows' => [['columns' => [['text' => "  \n"], ['type' => 'image'], ['type' => 'table', 'cells' => [['', '']]]]]]])->isEmpty());
        $this->assertFalse(DocumentContent::fromText('x')->isEmpty());
    }

    public function testEveryTemplateIsValidContent(): void
    {
        foreach (ContentTemplates::all() as $key => $template) {
            $content = DocumentContent::fromArray($template['content']);
            $this->assertNotEmpty($content->rows, $key);
            $this->assertStringStartsWith('%PDF-', (new PdfCreator())->fromContent($content, $template['title']), $key);
        }
    }
}
