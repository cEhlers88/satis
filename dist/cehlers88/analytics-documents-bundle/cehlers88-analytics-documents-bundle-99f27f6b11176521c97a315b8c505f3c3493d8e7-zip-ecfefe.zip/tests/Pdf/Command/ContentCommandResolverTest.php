<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf\Command;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Command\CommandResolver;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Command\ContentCommandResolver;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\DocumentContent;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\HeadingColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TableColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TextColumn;
use PHPUnit\Framework\TestCase;

class ContentCommandResolverTest extends TestCase
{
    public function testCommandColumnsBecomePlainOnes(): void
    {
        $content = DocumentContent::fromArray(['rows' => [
            ['columns' => [['type' => 'heading', 'source' => 'commands', 'commands' => ['title', []], 'level' => 1]]],
            ['columns' => [
                ['type' => 'text', 'text' => 'bleibt'],
                ['type' => 'text', 'source' => 'commands', 'commands' => ['body', []], 'style' => ['bold' => true]],
            ]],
            ['columns' => [['type' => 'table', 'source' => 'commands', 'commands' => ['rows', []], 'headerRow' => false]]],
        ]]);
        $commands = $this->createStub(CommandResolver::class);
        $commands->method('text')->willReturnCallback(static fn(array $definition, string $where): string => $definition[0] . ' @ ' . $where);
        $commands->method('table')->willReturn([['a', 'b'], ['c']]);

        $resolved = (new ContentCommandResolver($commands))->resolve($content);

        $heading = $resolved->rows[0]->columns[0];
        $this->assertInstanceOf(HeadingColumn::class, $heading);
        $this->assertSame('title @ Zeile 1:', $heading->text);
        $this->assertSame(1, $heading->level);
        $this->assertNull($heading->commands());
        $this->assertSame('bleibt', $resolved->rows[1]->columns[0]->text);
        $text = $resolved->rows[1]->columns[1];
        $this->assertInstanceOf(TextColumn::class, $text);
        $this->assertSame('body @ Zeile 2, Spalte 2:', $text->text);
        $this->assertTrue($text->style->bold);
        $table = $resolved->rows[2]->columns[0];
        $this->assertInstanceOf(TableColumn::class, $table);
        $this->assertSame([['a', 'b'], ['c', '']], $table->cells);
        $this->assertFalse($table->headerRow);
    }

    public function testContentWithOnlyCommandsIsNotEmpty(): void
    {
        $this->assertFalse(DocumentContent::fromArray(['rows' => [['columns' => [['source' => 'commands', 'commands' => ['x', []]]]]]])->isEmpty());
    }
}
