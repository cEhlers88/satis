<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf\Command;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Player\CommandPlayer;
use Cehlers88\AnalyticsCore\Provider\VariablesProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Command\CommandResolver;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class CommandResolverTest extends TestCase
{
    /** @param array<string, mixed> $answers command name => what the player answers */
    private function resolver(array $answers, ?array &$ran = null): CommandResolver
    {
        $ran = [];
        $player = $this->createStub(CommandPlayer::class);
        $player->method('run')->willReturnCallback(static function (mixed $definition) use ($answers, &$ran): mixed {
            $ran[] = $definition;
            $name = $definition[0];
            if ($name === 'echo_only') {
                echo 'ausgegeben';

                return null;
            }
            if ($name === 'broken') {
                throw new \RuntimeException('kaputt');
            }

            // like the player: what it does not know comes back as it was
            return array_key_exists($name, $answers) ? $answers[$name] : $definition;
        });
        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('getCommandPlayer')->willReturn($player);
        $environment->method('getVariablesStoreProvider')->willReturn($this->createStub(VariablesProvider::class));
        $applications = $this->createStub(ApplicationRepository::class);
        $applications->method('find')->willReturn($this->createStub(Application::class));

        return new CommandResolver($environment, $applications);
    }

    public function testTextEntriesAndCommandsArePutTogether(): void
    {
        $text = $this->resolver(['get_var' => '27.09.2026'])->text(['Musterstadt, ', ['get_var', ['name' => 'date']]], 'Zeile 1:');

        $this->assertSame('Musterstadt, 27.09.2026', $text);
    }

    public function testASingleCommandAndLineBreaks(): void
    {
        $resolver = $this->resolver(['get_var' => ['Zeile A', 'Zeile B']]);

        $this->assertSame("Zeile A\nZeile B", $resolver->text(['get_var', ['name' => 'lines']], ''));
        $this->assertSame("oben\nunten", $resolver->text(['oben\\nunten'], ''));
    }

    public function testEchoedOutputCountsWhenNothingIsReturned(): void
    {
        $this->assertSame('ausgegeben', $this->resolver([])->text([['echo_only', []]], ''));
    }

    public function testAnUnknownCommandIsReported(): void
    {
        $this->expectException(PdfCreatorException::class);
        $this->expectExceptionMessage('Zeile 2: Den Command „nope“ gibt es nicht');

        $this->resolver([])->text(['nope', ['a' => 1]], 'Zeile 2:');
    }

    public function testAFailingCommandIsReported(): void
    {
        try {
            $this->resolver([])->text([['broken', []]], 'Zeile 3:');
            $this->fail('The failure should have been reported');
        } catch (PdfCreatorException $exception) {
            $this->assertSame(422, $exception->getStatusCode());
            $this->assertStringContainsString('kaputt', $exception->getMessage());
        }
    }

    #[DataProvider('tables')]
    public function testTables(mixed $answer, array $rows): void
    {
        $this->assertSame($rows, $this->resolver(['data' => $answer])->table(['data', []], ''));
    }

    public static function tables(): iterable
    {
        yield 'rows' => [[['a', 1], ['b', 2]], [['a', '1'], ['b', '2']]];
        yield 'records' => [[['Name' => 'Max', 'Alter' => 30], ['Name' => 'Erika', 'Alter' => 31]], [['Name', 'Alter'], ['Max', '30'], ['Erika', '31']]];
        yield 'record' => [['Name' => 'Max', 'Ort' => 'Berlin'], [['Name', 'Max'], ['Ort', 'Berlin']]];
        yield 'json text' => ['[["x","y"]]', [['x', 'y']]];
        yield 'scalar' => ['nur Text', [['nur Text']]];
    }

    public function testCommandTuplesAreToldFromLists(): void
    {
        $this->assertTrue(CommandResolver::isCommand(['get_var', ['name' => 'x']]));
        $this->assertTrue(CommandResolver::isCommand(['now', []]));
        $this->assertFalse(CommandResolver::isCommand(['Text', ['get_var', ['name' => 'x']]]));
        $this->assertFalse(CommandResolver::isCommand(['a', 'b']));
        $this->assertFalse(CommandResolver::isCommand(['nur ein Text']));
    }

    public function testDefinitionsAreChecked(): void
    {
        $this->assertSame(['x', []], CommandResolver::definition(['x', []], ''));
        $this->expectException(PdfCreatorException::class);
        CommandResolver::definition([], 'Zeile 1:');
    }
}
