<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf\Letterhead;

use Cehlers88\AnalyticsDocumentsBundle\Entity\Letterhead;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Command\CommandResolver;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadDefinition;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadResolver;
use Cehlers88\AnalyticsDocumentsBundle\Repository\LetterheadRepository;
use PHPUnit\Framework\TestCase;

class LetterheadResolverTest extends TestCase
{
    /** @var array<int, Letterhead> */
    private array $stored = [];

    private function store(int $id, array $data, ?int $parentId = null): Letterhead
    {
        $letterhead = new Letterhead(LetterheadDefinition::fromArray([...$data, 'parentId' => $parentId]), $parentId === null ? null : $this->stored[$parentId]);
        (new \ReflectionProperty(Letterhead::class, 'id'))->setValue($letterhead, $id);

        return $this->stored[$id] = $letterhead;
    }

    private function resolver(?CommandResolver $commands = null): LetterheadResolver
    {
        $repository = $this->createStub(LetterheadRepository::class);
        $repository->method('find')->willReturnCallback(fn(int $id): ?Letterhead => $this->stored[$id] ?? null);

        return new LetterheadResolver($repository, $commands ?? $this->createStub(CommandResolver::class));
    }

    public function testFieldsAreInheritedReplacedAndExtended(): void
    {
        $this->store(1, ['name' => 'Konzern', 'definition' => [
            'headerText' => ['mode' => 'replace', 'value' => 'Konzern AG'],
            'footerText' => ['mode' => 'replace', 'value' => 'Sitz: Berlin'],
            'marginTop' => ['mode' => 'replace', 'value' => 60],
            'pageNumbers' => ['mode' => 'replace', 'value' => true],
        ]]);
        $this->store(2, ['name' => 'Tochter', 'definition' => [
            'headerText' => ['mode' => 'append', 'value' => 'Tochter GmbH'],
            'footerText' => ['mode' => 'prepend', 'value' => 'Tochter GmbH · HRB 1'],
            'marginTop' => ['mode' => 'inherit'],
        ]], 1);
        $child = LetterheadDefinition::fromArray(['name' => 'Abteilung', 'parentId' => 2, 'definition' => [
            'headerText' => ['mode' => 'append', 'value' => 'Abteilung Einkauf'],
            'footerText' => ['mode' => 'replace', 'value' => 'Nur Einkauf'],
            'marginTop' => ['mode' => 'replace', 'value' => 70],
        ]]);

        $data = $this->resolver()->data($child);

        $this->assertSame('Abteilung', $data->name);
        $this->assertSame("Konzern AG\nTochter GmbH\nAbteilung Einkauf", $data->headerText);
        $this->assertSame('Nur Einkauf', $data->footerText);
        $this->assertSame(70, $data->marginTop);
        $this->assertTrue($data->pageNumbers);
        // never set anywhere: the default
        $this->assertSame(25, $data->marginLeft);
    }

    public function testPrependPutsTheOwnTextFirst(): void
    {
        $this->store(1, ['name' => 'Basis', 'definition' => ['footerText' => ['mode' => 'replace', 'value' => 'Bank']]]);
        $child = LetterheadDefinition::fromArray(['name' => 'Kind', 'parentId' => 1, 'definition' => [
            'footerText' => ['mode' => 'prepend', 'value' => 'Name'],
        ]]);

        $this->assertSame("Name\nBank", $this->resolver()->data($child)->footerText);
    }

    public function testCommandsInTextsAreResolvedOrMarked(): void
    {
        $this->store(1, ['name' => 'Basis', 'definition' => [
            'headerText' => ['mode' => 'replace', 'source' => 'commands', 'commands' => ['get_var', ['name' => 'company']]],
        ]]);
        $child = LetterheadDefinition::fromArray(['name' => 'Kind', 'parentId' => 1, 'definition' => [
            'headerText' => ['mode' => 'append', 'value' => 'Filiale Nord'],
        ]]);
        $commands = $this->createMock(CommandResolver::class);
        $commands->expects($this->once())->method('text')
            ->with(['get_var', ['name' => 'company']], $this->stringContains('Kopfzeile'))
            ->willReturn('Muster AG');

        $this->assertSame("Muster AG\nFiliale Nord", $this->resolver($commands)->data($child)->headerText);
        $this->assertSame("⚙ Command\nFiliale Nord", $this->resolver()->data($child, null, false)->headerText);
    }

    public function testACircleIsRefused(): void
    {
        $this->store(1, ['name' => 'A']);
        $this->store(2, ['name' => 'B'], 1);
        // A would be based on B, which is based on A
        $this->expectException(PdfCreatorException::class);
        $this->expectExceptionMessage('im Kreis');

        $this->resolver()->chain(LetterheadDefinition::fromArray(['name' => 'A', 'parentId' => 2]), 1);
    }

    public function testAMissingBaseIsRefused(): void
    {
        $this->expectException(PdfCreatorException::class);
        $this->expectExceptionCode(0);

        $this->resolver()->chain(LetterheadDefinition::fromArray(['name' => 'Kind', 'parentId' => 99]));
    }
}
