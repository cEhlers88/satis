<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf\Letterhead;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadData;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadDefinition;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class LetterheadDefinitionTest extends TestCase
{
    public function testWithoutBaseEveryFieldStandsOnItsOwn(): void
    {
        $definition = LetterheadDefinition::fromArray(['name' => 'Firma', 'definition' => [
            'headerText' => ['mode' => 'inherit'],
            'footerText' => ['mode' => 'append', 'value' => 'IBAN'],
        ]]);

        $this->assertNull($definition->parentId);
        $this->assertCount(count(LetterheadData::FIELDS), $definition->fields);
        foreach ($definition->fields as $field => $entry) {
            $this->assertSame('replace', $entry['mode'], $field);
        }
        $this->assertSame('', $definition->fields['headerText']['value']);
        $this->assertSame('IBAN', $definition->fields['footerText']['value']);
        $this->assertSame(45, $definition->fields['marginTop']['value']);
    }

    public function testWithBaseMissingFieldsAreInherited(): void
    {
        $definition = LetterheadDefinition::fromArray(['name' => 'Tochter', 'parentId' => '3', 'definition' => [
            'footerText' => ['mode' => 'append', 'source' => 'commands', 'commands' => ['get_var', ['name' => 'x']]],
            'marginTop' => ['mode' => 'replace', 'value' => '50'],
        ]]);

        $this->assertSame(3, $definition->parentId);
        $this->assertSame(['mode' => 'inherit'], $definition->fields['headerText']);
        $this->assertSame(['mode' => 'replace', 'value' => 50], $definition->fields['marginTop']);
        $this->assertSame('commands', $definition->fields['footerText']['source']);
        $this->assertSame(['get_var', ['name' => 'x']], $definition->fields['footerText']['commands']);
    }

    #[DataProvider('refused')]
    public function testRefuses(array $data, string $messagePart): void
    {
        $this->expectException(PdfCreatorException::class);
        $this->expectExceptionMessage($messagePart);

        LetterheadDefinition::fromArray(['name' => 'Firma', 'parentId' => 1, ...$data]);
    }

    public static function refused(): iterable
    {
        yield 'no name' => [['name' => ' '], 'Namen'];
        yield 'bad parent' => [['parentId' => 'x'], 'Grund-Briefpapier'];
        yield 'append for a number' => [['definition' => ['marginTop' => ['mode' => 'append', 'value' => 3]]], 'Rand oben'];
        yield 'unknown mode' => [['definition' => ['headerText' => ['mode' => 'merge']]], 'Kopfzeile'];
        yield 'bad value' => [['definition' => ['fontSize' => ['mode' => 'replace', 'value' => 40]]], 'Schriftgröße'];
        yield 'commands without definition' => [['definition' => ['headerText' => ['mode' => 'replace', 'source' => 'commands']]], 'Commands'];
    }
}
