<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Pdf\Letterhead;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadData;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class LetterheadDataTest extends TestCase
{
    public static function png(int $width = 4, int $height = 2): string
    {
        $image = imagecreatetruecolor($width, $height);
        ob_start();
        imagepng($image);

        return (string)ob_get_clean();
    }

    public function testDefaultsFillWhatIsNotGiven(): void
    {
        $data = LetterheadData::fromArray(['name' => '  Firma  ']);

        $this->assertSame('Firma', $data->name);
        $this->assertNull($data->logo);
        $this->assertFalse($data->pageNumbers);
        foreach (LetterheadData::NUMBERS as $key => [$default]) {
            $this->assertSame($default, $data->{$key}, $key);
        }
    }

    public function testTakesEverythingGiven(): void
    {
        $data = LetterheadData::fromArray([
            'name' => 'Firma',
            'headerText' => "Muster GmbH\r\nStraße 1\n\n",
            'headerAlign' => 'center',
            'logo' => 'data:image/png;base64,' . base64_encode(self::png()),
            'logoPosition' => 'left',
            'logoWidth' => '60',
            'footerText' => 'IBAN',
            'footerAlign' => 'right',
            'pageNumbers' => 'on',
            'marginTop' => 60,
            'marginBottom' => 25,
            'marginLeft' => 20,
            'marginRight' => 15,
            'fontSize' => 12,
        ]);

        $this->assertSame("Muster GmbH\nStraße 1", $data->headerText);
        $this->assertSame('center', $data->headerAlign);
        $this->assertStringStartsWith('data:image/png;base64,', (string)$data->logo);
        $this->assertSame(60, $data->logoWidth);
        $this->assertTrue($data->pageNumbers);
        $this->assertSame([60, 25, 20, 15, 12], [$data->marginTop, $data->marginBottom, $data->marginLeft, $data->marginRight, $data->fontSize]);
    }

    public function testLogoGetsTheTypeItReallyHas(): void
    {
        // a png that claims to be a jpeg
        $data = LetterheadData::fromArray(['name' => 'Firma', 'logo' => 'data:image/jpeg;base64,' . base64_encode(self::png())]);

        $this->assertStringStartsWith('data:image/png;base64,', (string)$data->logo);
    }

    public function testToArrayLeavesTheLogoOutOnRequest(): void
    {
        $data = LetterheadData::fromArray(['name' => 'Firma', 'logo' => 'data:image/png;base64,' . base64_encode(self::png())]);

        $this->assertArrayHasKey('logo', $data->toArray());
        $this->assertArrayNotHasKey('logo', $data->toArray(false));
        $this->assertTrue($data->toArray(false)['hasLogo']);
    }

    #[DataProvider('refused')]
    public function testRefuses(array $data, int $statusCode = 400): void
    {
        try {
            LetterheadData::fromArray(['name' => 'Firma', ...$data]);
            $this->fail('The letterhead should have been refused');
        } catch (PdfCreatorException $exception) {
            $this->assertSame($statusCode, $exception->getStatusCode());
        }
    }

    public static function refused(): iterable
    {
        yield 'no name' => [['name' => '  ']];
        yield 'name too long' => [['name' => str_repeat('a', LetterheadData::MAX_NAME_LENGTH + 1)]];
        yield 'header not text' => [['headerText' => ['a']]];
        yield 'header too long' => [['headerText' => str_repeat('a', LetterheadData::MAX_TEXT_LENGTH + 1)]];
        yield 'unknown alignment' => [['footerAlign' => 'justify']];
        yield 'margin too small' => [['marginTop' => 5]];
        yield 'margin too large' => [['marginLeft' => 51]];
        yield 'margin not whole' => [['marginRight' => '12.5']];
        yield 'logo no data url' => [['logo' => 'https://example.com/logo.png']];
        yield 'logo svg' => [['logo' => 'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg"/>')]];
        yield 'logo not an image' => [['logo' => 'data:image/png;base64,' . base64_encode('no image')]];
        yield 'logo too large' => [['logo' => 'data:image/png;base64,' . base64_encode(str_repeat('a', LetterheadData::MAX_LOGO_BYTES + 1))], 413];
    }
}
