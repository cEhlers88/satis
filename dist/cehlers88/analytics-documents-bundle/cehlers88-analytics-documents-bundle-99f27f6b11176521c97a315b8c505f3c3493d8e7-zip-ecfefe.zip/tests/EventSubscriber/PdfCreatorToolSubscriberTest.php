<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\EventSubscriber;

use Cehlers88\AnalyticsCore\Event\Tool\CollectToolsEvent;
use Cehlers88\AnalyticsDocumentsBundle\EventSubscriber\PdfCreatorToolSubscriber;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class PdfCreatorToolSubscriberTest extends TestCase
{
    public function testAddsTheToolWhenItsRoutesAreImported(): void
    {
        $urlGenerator = $this->createStub(UrlGeneratorInterface::class);
        $urlGenerator->method('generate')->willReturn('/admin_api/documents/pdf/create');
        $event = new CollectToolsEvent();

        (new PdfCreatorToolSubscriber($urlGenerator))->onCollectTools($event);

        $tools = $event->getTools();
        $this->assertCount(1, $tools);
        $this->assertSame('pdfCreator', $tools[0]['name']);
        $this->assertSame('pdfCreator.html.twig', $tools[0]['template']);
        $this->assertSame(['analytics_documents_admin_api_pdf_'], $tools[0]['routes']);
    }

    public function testLeavesTheToolOutWithoutItsRoutes(): void
    {
        $urlGenerator = $this->createStub(UrlGeneratorInterface::class);
        $urlGenerator->method('generate')->willThrowException(new RouteNotFoundException());
        $event = new CollectToolsEvent();

        (new PdfCreatorToolSubscriber($urlGenerator))->onCollectTools($event);

        $this->assertSame([], $event->getTools());
    }
}
