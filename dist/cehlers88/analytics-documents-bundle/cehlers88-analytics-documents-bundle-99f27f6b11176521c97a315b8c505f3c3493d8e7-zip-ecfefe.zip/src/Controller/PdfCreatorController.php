<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Controller;

use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\Security\Doorman;
use Cehlers88\AnalyticsDocumentsBundle\ENUM\EPermission;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Command\ContentCommandResolver;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\DocumentContent;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadDefinition;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadResolver;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\PdfCreator;
use Cehlers88\AnalyticsDocumentsBundle\Repository\LetterheadRepository;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRoot;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRootProvider;
use Cehlers88\AnalyticsDocumentsBundle\Upload\DocumentUploader;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use Cehlers88\AnalyticsDocumentsBundle\Upload\UploadSource;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Routing\Attribute\Route;

/**
 * The PDFs of the PDF-Creator tool (/dashboard/tools): made from the content the tool sends
 * (DocumentContent - rows of text, heading, image and table columns, commands resolved
 * first) on a letterhead or without one, and handed out as download, as preview or into a
 * workspace of the documents as Document. The content itself is not stored here - the
 * letterheads and templates have controllers of their own.
 */
#[Route('/admin_api/documents/pdf', name: 'analytics_documents_admin_api_pdf_')]
final class PdfCreatorController extends AbstractPdfCreatorController
{
    private const PREVIEW_TEXT = "Sehr geehrte Damen und Herren,\n\n"
        . "so sieht ein Brief auf diesem Briefpapier aus. Kopf- und Fußzeile stehen auf jeder Seite, "
        . "der Text hält die eingestellten Ränder ein.\n\n"
        . "Mit freundlichen Grüßen";

    public function __construct(
        private readonly PdfCreator             $pdfCreator,
        private readonly ContentCommandResolver $contentCommandResolver,
        private readonly LetterheadRepository   $letterheads,
        private readonly LetterheadResolver     $letterheadResolver,
        private readonly DocumentRootProvider   $documentRoots,
        private readonly DocumentUploader       $documentUploader,
        private readonly Doorman                $doorman,
    )
    {
    }

    /**
     * The PDF as download. Json: "content" (DocumentContent) - or plain "text" -, and
     * optionally "fileName" and "letterheadId".
     */
    #[Route('/create', name: 'create', methods: ['POST'])]
    public function create(Request $request): Response
    {
        return $this->handle(function () use ($request): Response {
            $this->checkCsrfToken($request);
            $input = $this->readInput($request);
            $fileName = PdfCreator::fileName((string)($input['fileName'] ?? ''));

            return $this->pdfResponse($this->renderPdf($input, substr($fileName, 0, -4)), $fileName, ResponseHeaderBag::DISPOSITION_ATTACHMENT);
        });
    }

    /**
     * The PDF inline - for the preview of the tool. Like create; or "letterhead", a letterhead
     * as it is being edited ({name, parentId, definition, id}), with a sample letter.
     */
    #[Route('/preview', name: 'preview', methods: ['POST'])]
    public function preview(Request $request): Response
    {
        return $this->handle(function () use ($request): Response {
            $this->checkCsrfToken($request);
            $input = $this->readInput($request);
            if (is_array($input['letterhead'] ?? null)) {
                $definition = LetterheadDefinition::fromArray($input['letterhead']);
                $letterhead = $this->letterheadResolver->data($definition, self::optionalId($input['letterhead']['id'] ?? null, 'Das Briefpapier'));
                $text = trim((string)($input['text'] ?? '')) === '' ? self::PREVIEW_TEXT : (string)$input['text'];

                return $this->pdfResponse(
                    $this->pdfCreator->fromText($text, $letterhead->name, $letterhead),
                    PdfCreator::fileName($letterhead->name),
                    ResponseHeaderBag::DISPOSITION_INLINE
                );
            }
            $fileName = PdfCreator::fileName((string)($input['fileName'] ?? ''));

            return $this->pdfResponse($this->renderPdf($input, substr($fileName, 0, -4)), $fileName, ResponseHeaderBag::DISPOSITION_INLINE);
        });
    }

    /** Where a PDF can be saved: the workspaces of the documents - and whether the user may. */
    #[Route('/targets', name: 'targets', methods: ['GET'])]
    public function targets(): Response
    {
        return $this->handle(function (): Response {
            $this->checkAccess();

            return $this->success('Targets', [
                'canSave' => $this->maySaveDocuments(),
                'workspaces' => array_map(
                    static fn(DocumentRoot $root): array => ['id' => $root->id, 'name' => $root->name, 'description' => $root->description],
                    $this->documentRoots->all()
                ),
            ]);
        });
    }

    /**
     * Makes the PDF like create and stores it in a workspace as Document (DocumentUploader).
     * Json: as create, plus "workspaceId", "path" (directory below the workspace) and
     * "overwrite". A file that exists answers 409 unless overwrite is set.
     */
    #[Route('/save', name: 'save', methods: ['POST'])]
    public function save(Request $request): Response
    {
        return $this->handle(function () use ($request): Response {
            $this->checkCsrfToken($request);
            if (!$this->maySaveDocuments()) {
                throw new PdfCreatorException('Zum Speichern in den Dokumenten fehlt die Berechtigung ' . EPermission::ACCESS_DOCUMENTS->value, 403);
            }
            $input = $this->readInput($request);
            $workspace = $this->documentRoots->find(trim((string)($input['workspaceId'] ?? '')))
                ?? throw new PdfCreatorException('Den Arbeitsbereich gibt es nicht (mehr)', 404);
            $fileName = PdfCreator::fileName((string)($input['fileName'] ?? ''));
            $pdf = $this->renderPdf($input, substr($fileName, 0, -4));

            try {
                $result = $this->documentUploader->upload(
                    $workspace,
                    UploadSource::fromBase64(base64_encode($pdf), 'application/pdf', $this->documentUploader->getMaxFileSize()),
                    is_scalar($input['path'] ?? null) ? (string)$input['path'] : '',
                    $fileName,
                    filter_var($input['overwrite'] ?? false, FILTER_VALIDATE_BOOL),
                    ['source' => 'pdfCreator', 'letterheadId' => self::optionalId($input['letterheadId'] ?? null, 'Das Briefpapier')]
                );
            } catch (DocumentUploadException $exception) {
                // the tool speaks German; the uploader's messages are meant for the API
                $message = $exception->getCode() === 409
                    ? sprintf('„%s“ gibt es in diesem Ordner des Arbeitsbereichs „%s“ schon', $fileName, $workspace->name)
                    : $exception->getMessage();
                throw new PdfCreatorException($message, $exception->getCode() ?: 500, $exception);
            }

            return $this->success($result->replaced ? 'Document replaced' : 'Document created', [
                'documentId' => $result->document->getId(),
                'path' => $result->document->getPath(),
                'workspace' => $workspace->name,
                'replaced' => $result->replaced,
            ], $result->replaced ? 200 : 201);
        });
    }

    /** @param array<string, mixed> $input */
    private function renderPdf(array $input, string $title): string
    {
        $letterheadId = self::optionalId($input['letterheadId'] ?? null, 'Das Briefpapier');
        $letterhead = null;
        if ($letterheadId !== null) {
            $entity = $this->letterheads->find($letterheadId) ?? throw new PdfCreatorException('Das Briefpapier gibt es nicht (mehr)', 404);
            $letterhead = $this->letterheadResolver->data($entity->toDefinition(), $letterheadId);
        }
        if (is_array($input['content'] ?? null)) {
            $content = $this->contentCommandResolver->resolve(DocumentContent::fromArray($input['content']));

            return $this->pdfCreator->fromContent($content, $title, $letterhead);
        }

        return $this->pdfCreator->fromText(is_string($input['text'] ?? null) ? $input['text'] : '', $title, $letterhead);
    }

    /** As the upload endpoint of the documents: the permission ACCESS_DOCUMENTS - administrators always have it. */
    private function maySaveDocuments(): bool
    {
        return $this->doorman->checkPermission([RoleDTO::create(EPermission::ACCESS_DOCUMENTS->value)]);
    }

    private function pdfResponse(string $pdf, string $fileName, string $disposition): Response
    {
        $response = new Response($pdf, 200, ['Content-Type' => 'application/pdf']);
        $response->headers->set('Content-Disposition', $response->headers->makeDisposition(
            $disposition,
            $fileName,
            self::asciiFallback($fileName),
        ));

        return $response;
    }

    /** makeDisposition() refuses a fallback with anything but printable ASCII. */
    private static function asciiFallback(string $fileName): string
    {
        $ascii = (string)preg_replace('/[^\x20-\x7E]|%/u', '_', $fileName);

        return $ascii === '' ? PdfCreator::DEFAULT_FILE_NAME : $ascii;
    }
}
