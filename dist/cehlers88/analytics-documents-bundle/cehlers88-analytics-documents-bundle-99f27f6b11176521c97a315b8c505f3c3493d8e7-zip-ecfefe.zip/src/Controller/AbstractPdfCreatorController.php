<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Controller;

use Cehlers88\AnalyticsCore\DTO\ResultDTO;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * What the controllers of the PDF-Creator share: every request needs ROLE_DASHBOARD (or
 * ROLE_ADMIN), every writing one the CSRF token "pdf_creator" in X-CSRF-Token, and a refused
 * request is answered with a ResultDTO whose message is meant for the user.
 *
 * All of their routes are named analytics_documents_admin_api_pdf_*, so the access rules of
 * the tool (ToolAccessListener of the application) cover them.
 */
abstract class AbstractPdfCreatorController extends AbstractController
{
    public const CSRF_TOKEN_ID = 'pdf_creator';
    public const CSRF_HEADER = 'X-CSRF-Token';

    /** @param callable(): Response $action */
    protected function handle(callable $action): Response
    {
        try {
            return $action();
        } catch (PdfCreatorException $exception) {
            return $this->json(ResultDTO::createError($exception->getMessage(), $exception->getStatusCode()), $exception->getStatusCode());
        }
    }

    protected function checkAccess(): void
    {
        if (!$this->isGranted('ROLE_DASHBOARD') && !$this->isGranted('ROLE_ADMIN')) {
            throw $this->createAccessDeniedException();
        }
    }

    protected function checkCsrfToken(Request $request): void
    {
        $this->checkAccess();
        $token = $request->headers->get(self::CSRF_HEADER);
        if (!is_string($token) || $token === '' || !$this->isCsrfTokenValid(self::CSRF_TOKEN_ID, $token)) {
            throw new PdfCreatorException('Ungültiges CSRF-Token - bitte die Seite neu laden', 403);
        }
    }

    /** @return array<string, mixed> */
    protected function readInput(Request $request): array
    {
        if ($request->getContentTypeFormat() !== 'json') {
            return $request->request->all();
        }
        $data = json_decode($request->getContent(), true);
        if (!is_array($data)) {
            throw new PdfCreatorException('Die Anfrage ist kein gültiges JSON');
        }

        return $data;
    }

    protected function success(string $message, mixed $data = [], int $statusCode = 200): Response
    {
        return $this->json(ResultDTO::createSuccess($message, $data, $statusCode), $statusCode);
    }

    /** An id from the input; null when none is given. */
    protected static function optionalId(mixed $value, string $what): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }

        return filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])
            ?: throw new PdfCreatorException(sprintf('%s gibt es nicht (mehr)', $what), 404);
    }
}
