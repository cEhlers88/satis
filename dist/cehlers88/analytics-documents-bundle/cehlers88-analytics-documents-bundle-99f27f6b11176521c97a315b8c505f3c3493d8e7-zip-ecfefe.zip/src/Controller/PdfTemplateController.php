<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Controller;

use Cehlers88\AnalyticsDocumentsBundle\Entity\PdfTemplate;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\ContentTemplates;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\DocumentContent;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\PdfCreator;
use Cehlers88\AnalyticsDocumentsBundle\Repository\LetterheadRepository;
use Cehlers88\AnalyticsDocumentsBundle\Repository\PdfTemplateRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * The templates ("Vorlagen") of the PDF-Creator: those the bundle brings (ContentTemplates,
 * key "builtin-<name>", read only) and the documents users kept as template (PdfTemplate,
 * key = id, shared by everybody who may use the tool).
 */
#[Route('/admin_api/documents/pdf/templates', name: 'analytics_documents_admin_api_pdf_')]
final class PdfTemplateController extends AbstractPdfCreatorController
{
    private const BUILTIN_PREFIX = 'builtin-';
    /** The content of a template as json - images make it large, the database has its limits. */
    private const MAX_CONTENT_BYTES = 8388608;

    public function __construct(
        private readonly PdfTemplateRepository  $templates,
        private readonly LetterheadRepository   $letterheads,
        private readonly EntityManagerInterface $entityManager,
    )
    {
    }

    /** The templates without their content. */
    #[Route('', name: 'templates', methods: ['GET'])]
    public function list(): Response
    {
        return $this->handle(function (): Response {
            $this->checkAccess();
            $list = [];
            foreach (ContentTemplates::all() as $name => $template) {
                $list[] = [
                    'key' => self::BUILTIN_PREFIX . $name,
                    'name' => $template['title'],
                    'description' => $template['description'],
                    'builtin' => true,
                ];
            }
            foreach ($this->templates->findAllByName() as $template) {
                $list[] = [
                    'key' => (string)$template->getId(),
                    'name' => $template->getName(),
                    'description' => $template->getDescription() ?? '',
                    'builtin' => false,
                    'letterheadName' => $template->getLetterhead()?->getName(),
                    'createdBy' => $template->getCreatedBy(),
                    'updatedAt' => $template->getUpdatedAt()->format(\DateTimeInterface::ATOM),
                ];
            }

            return $this->success('Templates', ['templates' => $list]);
        });
    }

    /** One template with its content - what the tool opens. */
    #[Route('/{key}', name: 'template', requirements: ['key' => '[a-z0-9-]+'], methods: ['GET'])]
    public function details(string $key): Response
    {
        return $this->handle(function () use ($key): Response {
            $this->checkAccess();
            if (str_starts_with($key, self::BUILTIN_PREFIX)) {
                $template = ContentTemplates::all()[substr($key, strlen(self::BUILTIN_PREFIX))]
                    ?? throw new PdfCreatorException('Die Vorlage gibt es nicht', 404);

                return $this->success('Template', [
                    'key' => $key,
                    'name' => $template['title'],
                    'content' => $template['content'],
                    'letterheadId' => null,
                    'fileName' => $template['title'],
                ]);
            }
            $template = $this->template($key);

            return $this->success('Template', [
                'key' => $key,
                'name' => $template->getName(),
                'content' => $template->getContent(),
                'letterheadId' => $template->getLetterhead()?->getId(),
                'fileName' => $template->getFileName(),
            ]);
        });
    }

    /**
     * Keeps a document as template. Json: name, description, content, letterheadId, fileName;
     * with "replaceKey" an existing template of the users is replaced.
     */
    #[Route('', name: 'template_save', methods: ['POST'])]
    public function save(Request $request): Response
    {
        return $this->handle(function () use ($request): Response {
            $this->checkCsrfToken($request);
            $input = $this->readInput($request);
            $name = trim(is_string($input['name'] ?? null) ? $input['name'] : '');
            if ($name === '' || mb_strlen($name) > PdfTemplate::MAX_NAME_LENGTH) {
                throw new PdfCreatorException(sprintf('Eine Vorlage braucht einen Namen mit höchstens %d Zeichen', PdfTemplate::MAX_NAME_LENGTH));
            }
            $description = trim(is_string($input['description'] ?? null) ? $input['description'] : '');
            if (mb_strlen($description) > PdfTemplate::MAX_DESCRIPTION_LENGTH) {
                throw new PdfCreatorException(sprintf('Die Beschreibung hat höchstens %d Zeichen', PdfTemplate::MAX_DESCRIPTION_LENGTH));
            }
            $content = is_array($input['content'] ?? null) ? $input['content'] : throw new PdfCreatorException('Die Vorlage hat keinen Inhalt');
            // checked like a document that is made - without running its commands
            DocumentContent::fromArray($content);
            if (strlen((string)json_encode($content)) > self::MAX_CONTENT_BYTES) {
                throw new PdfCreatorException(sprintf('Die Vorlage ist größer als %d MB - weniger oder kleinere Bilder', self::MAX_CONTENT_BYTES / 1048576), 413);
            }
            $letterheadId = self::optionalId($input['letterheadId'] ?? null, 'Das Briefpapier');
            $letterhead = $letterheadId === null ? null : ($this->letterheads->find($letterheadId)
                ?? throw new PdfCreatorException('Das Briefpapier gibt es nicht (mehr)', 404));
            $fileName = trim(is_string($input['fileName'] ?? null) ? $input['fileName'] : '');

            $replaceKey = $input['replaceKey'] ?? null;
            $template = $replaceKey === null || $replaceKey === ''
                ? new PdfTemplate($this->getUser()?->getUserIdentifier())
                : $this->template((string)$replaceKey);
            $template->apply(
                $name,
                $description === '' ? null : $description,
                $content,
                $letterhead,
                $fileName === '' ? null : substr(PdfCreator::fileName($fileName), 0, -4),
            );
            $this->entityManager->persist($template);
            $this->entityManager->flush();

            return $this->success('Template saved', ['key' => (string)$template->getId(), 'name' => $template->getName()], $replaceKey ? 200 : 201);
        });
    }

    #[Route('/{key}', name: 'template_delete', requirements: ['key' => '\d+'], methods: ['DELETE'])]
    public function delete(Request $request, string $key): Response
    {
        return $this->handle(function () use ($request, $key): Response {
            $this->checkCsrfToken($request);
            $template = $this->template($key);
            $this->entityManager->remove($template);
            $this->entityManager->flush();

            return $this->success('Template deleted', ['key' => $key]);
        });
    }

    private function template(string $key): PdfTemplate
    {
        if (str_starts_with($key, self::BUILTIN_PREFIX)) {
            throw new PdfCreatorException('Mitgelieferte Vorlagen lassen sich nicht ändern', 403);
        }
        $id = filter_var($key, FILTER_VALIDATE_INT);

        return ($id === false ? null : $this->templates->find($id))
            ?? throw new PdfCreatorException('Die Vorlage gibt es nicht (mehr)', 404);
    }
}
