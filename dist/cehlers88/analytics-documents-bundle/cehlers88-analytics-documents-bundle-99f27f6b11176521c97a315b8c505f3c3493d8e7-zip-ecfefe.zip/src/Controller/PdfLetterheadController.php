<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Controller;

use Cehlers88\AnalyticsDocumentsBundle\Entity\Letterhead;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadData;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadDefinition;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadResolver;
use Cehlers88\AnalyticsDocumentsBundle\Repository\LetterheadRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * The letterheads ("Briefpapier") of the PDF-Creator - shared by everybody who may use the
 * tool. A letterhead may be based on another one (parentId) and inherit, replace or extend
 * its fields (LetterheadDefinition); the answers carry what it inherits, so the tool can show
 * it next to what the letterhead sets itself.
 */
#[Route('/admin_api/documents/pdf/letterheads', name: 'analytics_documents_admin_api_pdf_')]
final class PdfLetterheadController extends AbstractPdfCreatorController
{
    public function __construct(
        private readonly LetterheadRepository   $letterheads,
        private readonly LetterheadResolver     $resolver,
        private readonly EntityManagerInterface $entityManager,
    )
    {
    }

    /** The letterheads without their logos - enough for the choice and the list. */
    #[Route('', name: 'letterheads', methods: ['GET'])]
    public function list(): Response
    {
        return $this->handle(function (): Response {
            $this->checkAccess();
            $list = [];
            foreach ($this->letterheads->findAllByName() as $letterhead) {
                $effective = $this->resolver->effective($letterhead->toDefinition(), $letterhead->getId());
                $list[] = [
                    'id' => $letterhead->getId(),
                    'name' => $letterhead->getName(),
                    'parentId' => $letterhead->getParent()?->getId(),
                    'parentName' => $letterhead->getParent()?->getName(),
                    'hasLogo' => $effective['logo'] !== null,
                    'pageNumbers' => $effective['pageNumbers'],
                    'updatedAt' => $letterhead->getUpdatedAt()->format(\DateTimeInterface::ATOM),
                ];
            }

            return $this->success('Letterheads', ['letterheads' => $list]);
        });
    }

    /** One letterhead: its definition and what it would inherit from its base letterhead. */
    #[Route('/{id}', name: 'letterhead', requirements: ['id' => '\d+'], methods: ['GET'])]
    public function details(int $id): Response
    {
        return $this->handle(function () use ($id): Response {
            $this->checkAccess();

            return $this->success('Letterhead', $this->describe($this->letterhead($id)));
        });
    }

    /** What a base letterhead hands down - for a letterhead whose base was just picked. */
    #[Route('/{id}/inherited', name: 'letterhead_inherited', requirements: ['id' => '\d+'], methods: ['GET'])]
    public function inherited(int $id): Response
    {
        return $this->handle(function () use ($id): Response {
            $this->checkAccess();
            $letterhead = $this->letterhead($id);

            return $this->success('Inherited', $this->display($letterhead->toDefinition(), $letterhead->getId()));
        });
    }

    #[Route('', name: 'letterhead_create', methods: ['POST'])]
    public function create(Request $request): Response
    {
        return $this->handle(function () use ($request): Response {
            $this->checkCsrfToken($request);
            $definition = LetterheadDefinition::fromArray($this->readInput($request));
            // checks the chain of base letterheads - it has to lead somewhere
            $this->resolver->chain($definition);
            $letterhead = new Letterhead($definition, $this->parent($definition));
            $this->entityManager->persist($letterhead);
            $this->entityManager->flush();

            return $this->success('Letterhead created', $this->describe($letterhead), 201);
        });
    }

    #[Route('/{id}', name: 'letterhead_update', requirements: ['id' => '\d+'], methods: ['PUT'])]
    public function update(Request $request, int $id): Response
    {
        return $this->handle(function () use ($request, $id): Response {
            $this->checkCsrfToken($request);
            $letterhead = $this->letterhead($id);
            $definition = LetterheadDefinition::fromArray($this->readInput($request));
            // refuses a base letterhead that is based on this one
            $this->resolver->chain($definition, $id);
            $letterhead->apply($definition, $this->parent($definition));
            $this->entityManager->flush();

            return $this->success('Letterhead saved', $this->describe($letterhead));
        });
    }

    #[Route('/{id}', name: 'letterhead_delete', requirements: ['id' => '\d+'], methods: ['DELETE'])]
    public function delete(Request $request, int $id): Response
    {
        return $this->handle(function () use ($request, $id): Response {
            $this->checkCsrfToken($request);
            $letterhead = $this->letterhead($id);
            $children = $this->letterheads->findChildren($letterhead);
            if ($children !== []) {
                throw new PdfCreatorException(sprintf(
                    '„%s“ ist die Grundlage von %s - erst diese ändern oder löschen',
                    $letterhead->getName(),
                    implode(', ', array_map(static fn(Letterhead $child): string => '„' . $child->getName() . '“', $children))
                ), 409);
            }
            $this->entityManager->remove($letterhead);
            $this->entityManager->flush();

            return $this->success('Letterhead deleted', ['id' => $id]);
        });
    }

    private function letterhead(int $id): Letterhead
    {
        return $this->letterheads->find($id) ?? throw new PdfCreatorException('Das Briefpapier gibt es nicht (mehr)', 404);
    }

    private function parent(LetterheadDefinition $definition): ?Letterhead
    {
        return $definition->parentId === null ? null : $this->letterhead($definition->parentId);
    }

    /** @return array<string, mixed> */
    private function describe(Letterhead $letterhead): array
    {
        $parent = $letterhead->getParent();

        return [
            'id' => $letterhead->getId(),
            ...$letterhead->toDefinition()->toArray(),
            'inherited' => $parent === null ? null : $this->display($parent->toDefinition(), $parent->getId()),
            'updatedAt' => $letterhead->getUpdatedAt()->format(\DateTimeInterface::ATOM),
        ];
    }

    /**
     * The effective values of a letterhead as the tool shows them - texts as they read,
     * commands in them marked, not run.
     *
     * @return array<string, mixed>
     */
    private function display(LetterheadDefinition $definition, ?int $id): array
    {
        $data = $this->resolver->data($definition, $id, false);
        $values = [];
        foreach (array_keys(LetterheadData::FIELDS) as $field) {
            $values[$field] = $data->{$field};
        }

        return ['name' => $definition->name, 'values' => $values];
    }
}
