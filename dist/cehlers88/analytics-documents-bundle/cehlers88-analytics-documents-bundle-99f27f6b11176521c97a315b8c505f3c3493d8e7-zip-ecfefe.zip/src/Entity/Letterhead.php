<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Entity;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadDefinition;
use Cehlers88\AnalyticsDocumentsBundle\Repository\LetterheadRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * A letterhead ("Briefpapier") of the PDF-Creator - shared by everybody who may use the tool.
 *
 * It may be based on another one (parent) and take over, replace or extend its fields; what
 * it does per field is its definition (LetterheadDefinition), kept as json - the logo, a
 * data url, included. LetterheadResolver makes the effective letterhead of it.
 */
#[ORM\Entity(repositoryClass: LetterheadRepository::class)]
#[ORM\Table(name: 'document_letterhead')]
class Letterhead
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 120)]
    private string $name = '';

    /** Deleting a letterhead others are based on is refused by the controller; the database would only cut the link. */
    #[ORM\ManyToOne(targetEntity: self::class)]
    #[ORM\JoinColumn(name: 'parent_id', nullable: true, onDelete: 'SET NULL')]
    private ?Letterhead $parent = null;

    /** @var array<string, array<string, mixed>> */
    #[ORM\Column(type: Types::JSON)]
    private array $definition = [];

    #[ORM\Column]
    private \DateTimeImmutable $createdAt;

    #[ORM\Column]
    private \DateTimeImmutable $updatedAt;

    public function __construct(LetterheadDefinition $definition, ?Letterhead $parent)
    {
        $this->createdAt = new \DateTimeImmutable();
        $this->apply($definition, $parent);
    }

    public function apply(LetterheadDefinition $definition, ?Letterhead $parent): static
    {
        $this->name = $definition->name;
        $this->parent = $parent;
        $this->definition = $definition->fields;
        $this->updatedAt = new \DateTimeImmutable();

        return $this;
    }

    public function toDefinition(): LetterheadDefinition
    {
        return new LetterheadDefinition($this->name, $this->parent?->getId(), $this->definition);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getParent(): ?Letterhead
    {
        return $this->parent;
    }

    public function getCreatedAt(): \DateTimeImmutable
    {
        return $this->createdAt;
    }

    public function getUpdatedAt(): \DateTimeImmutable
    {
        return $this->updatedAt;
    }
}
