<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Entity;

use Cehlers88\AnalyticsDocumentsBundle\Repository\PdfTemplateRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * A document of the PDF-Creator kept as template ("Vorlage") - the content as the tool sends it
 * (DocumentContent), optionally with the letterhead and the file name it was made with. Shared
 * by everybody who may use the tool, next to the templates the bundle brings (ContentTemplates).
 */
#[ORM\Entity(repositoryClass: PdfTemplateRepository::class)]
#[ORM\Table(name: 'document_pdf_template')]
class PdfTemplate
{
    public const MAX_NAME_LENGTH = 120;
    public const MAX_DESCRIPTION_LENGTH = 500;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: self::MAX_NAME_LENGTH)]
    private string $name = '';

    #[ORM\Column(length: self::MAX_DESCRIPTION_LENGTH, nullable: true)]
    private ?string $description = null;

    /** @var array<string, mixed> */
    #[ORM\Column(type: Types::JSON)]
    private array $content = [];

    #[ORM\ManyToOne(targetEntity: Letterhead::class)]
    #[ORM\JoinColumn(name: 'letterhead_id', nullable: true, onDelete: 'SET NULL')]
    private ?Letterhead $letterhead = null;

    #[ORM\Column(length: 120, nullable: true)]
    private ?string $fileName = null;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $createdBy = null;

    #[ORM\Column]
    private \DateTimeImmutable $createdAt;

    #[ORM\Column]
    private \DateTimeImmutable $updatedAt;

    public function __construct(?string $createdBy)
    {
        $this->createdBy = $createdBy;
        $this->createdAt = new \DateTimeImmutable();
        $this->updatedAt = $this->createdAt;
    }

    /** @param array<string, mixed> $content */
    public function apply(string $name, ?string $description, array $content, ?Letterhead $letterhead, ?string $fileName): static
    {
        $this->name = $name;
        $this->description = $description;
        $this->content = $content;
        $this->letterhead = $letterhead;
        $this->fileName = $fileName;
        $this->updatedAt = new \DateTimeImmutable();

        return $this;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    /** @return array<string, mixed> */
    public function getContent(): array
    {
        return $this->content;
    }

    public function getLetterhead(): ?Letterhead
    {
        return $this->letterhead;
    }

    public function getFileName(): ?string
    {
        return $this->fileName;
    }

    public function getCreatedBy(): ?string
    {
        return $this->createdBy;
    }

    public function getUpdatedAt(): \DateTimeImmutable
    {
        return $this->updatedAt;
    }
}
