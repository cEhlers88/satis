<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Repository;

use Cehlers88\AnalyticsDocumentsBundle\Entity\Letterhead;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Letterhead>
 */
class LetterheadRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Letterhead::class);
    }

    /** @return Letterhead[] */
    public function findAllByName(): array
    {
        return $this->findBy([], ['name' => 'ASC', 'id' => 'ASC']);
    }

    /** @return Letterhead[] the letterheads based directly on this one */
    public function findChildren(Letterhead $letterhead): array
    {
        return $this->findBy(['parent' => $letterhead], ['name' => 'ASC']);
    }
}
