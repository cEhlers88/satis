<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Repository;

use Cehlers88\AnalyticsDocumentsBundle\Entity\PdfTemplate;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<PdfTemplate>
 */
class PdfTemplateRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, PdfTemplate::class);
    }

    /** @return PdfTemplate[] */
    public function findAllByName(): array
    {
        return $this->findBy([], ['name' => 'ASC', 'id' => 'ASC']);
    }
}
