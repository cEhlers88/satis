<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Html;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadData;

/**
 * Header and footer of a letterhead as HTML for dompdf. Both are fixed elements, so they
 * repeat on every page; fixed elements are placed relative to the text area, so they are
 * moved out into the page margins by negative offsets - EDGE_DISTANCE from the edge of
 * the sheet, and never closer than 5 mm to the text.
 */
final class LetterheadHtml
{
    /** Header and footer keep this distance to the edge of the sheet (mm). */
    public const EDGE_DISTANCE = 10;

    /** Where the bottom of the footer area is (mm above the edge of the sheet). */
    public static function footerEdge(LetterheadData $letterhead): int
    {
        return min(self::EDGE_DISTANCE, intdiv($letterhead->marginBottom, 2));
    }

    public static function css(LetterheadData $letterhead): string
    {
        $headerTop = min(self::EDGE_DISTANCE, intdiv($letterhead->marginTop, 2));
        $headerHeight = max(5, $letterhead->marginTop - $headerTop - 5);
        $footerBottom = self::footerEdge($letterhead);
        // page numbers take the line below the footer
        if ($letterhead->pageNumbers) {
            $footerBottom += 5;
        }
        $footerHeight = max(5, $letterhead->marginBottom - $footerBottom - 5);

        return sprintf('.lh-header { position: fixed; left: 0; right: 0; top: -%dmm; height: %dmm; overflow: hidden; font-size: 9pt; line-height: 1.3; }', $letterhead->marginTop - $headerTop, $headerHeight)
            . sprintf('.lh-footer { position: fixed; left: 0; right: 0; bottom: -%dmm; max-height: %dmm; overflow: hidden; font-size: 8pt; line-height: 1.3; color: #333; }', $letterhead->marginBottom - $footerBottom, $footerHeight)
            . '.lh-header table { width: 100%; border-collapse: collapse; }'
            . '.lh-header td { padding: 0; vertical-align: top; }'
            . sprintf('.lh-logo { width: %dmm; }', $letterhead->logoWidth)
            . '.lh-logo-row { margin-bottom: 3mm; }'
            . '.lh-pre { white-space: pre-wrap; }';
    }

    public static function html(LetterheadData $letterhead): string
    {
        $html = '';
        $headerText = $letterhead->headerText === ''
            ? ''
            : sprintf('<div class="lh-pre" style="text-align: %s">%s</div>', $letterhead->headerAlign, self::escape($letterhead->headerText));
        if ($letterhead->logo !== null || $headerText !== '') {
            $html .= '<div class="lh-header">' . self::header($letterhead, $headerText) . '</div>';
        }
        if ($letterhead->footerText !== '') {
            $html .= sprintf(
                '<div class="lh-footer"><div class="lh-pre" style="text-align: %s">%s</div></div>',
                $letterhead->footerAlign,
                self::escape($letterhead->footerText)
            );
        }

        return $html;
    }

    /** Logo and text side by side - or, with the logo in the middle, the logo above the text. */
    private static function header(LetterheadData $letterhead, string $headerText): string
    {
        if ($letterhead->logo === null) {
            return $headerText;
        }
        $logo = sprintf('<img class="lh-logo" src="%s" alt="">', self::escape($letterhead->logo));
        if ($letterhead->logoPosition === 'center') {
            return '<div class="lh-logo-row" style="text-align: center">' . $logo . '</div>' . $headerText;
        }
        $logoCell = sprintf('<td style="width: %dmm; text-align: %s">%s</td>', $letterhead->logoWidth, $letterhead->logoPosition, $logo);
        $gap = '<td style="width: 5mm"></td>';
        $textCell = '<td>' . $headerText . '</td>';

        return '<table><tr>'
            . ($letterhead->logoPosition === 'left' ? $logoCell . $gap . $textCell : $textCell . $gap . $logoCell)
            . '</tr></table>';
    }

    private static function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
