<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Html;

/**
 * The little markup the text of the PDF-Creator knows - enough for a CV or a letter,
 * without anybody having to write HTML:
 *
 *     **fett**   *kursiv*   __unterstrichen__
 *     - ein Punkt einer Aufzählung (also "* " and "• ")
 *
 * A backslash keeps a character as it is ("\*"). Everything else is escaped; line breaks
 * and indentation stay as they were typed.
 */
final class InlineText
{
    private const LIST_ITEM = '/^\s*[-*•]\s+(.*)$/u';

    /** A block: paragraphs and lists. */
    public static function block(string $text): string
    {
        $html = '';
        $paragraph = [];
        $items = [];
        $flushParagraph = static function () use (&$paragraph, &$html): void {
            if ($paragraph !== []) {
                $html .= '<div class="pre">' . implode("\n", array_map(self::inline(...), $paragraph)) . '</div>';
                $paragraph = [];
            }
        };
        $flushItems = static function () use (&$items, &$html): void {
            if ($items !== []) {
                $html .= '<ul>' . implode('', array_map(static fn(string $item): string => '<li>' . self::inline($item) . '</li>', $items)) . '</ul>';
                $items = [];
            }
        };

        foreach (explode("\n", str_replace(["\r\n", "\r"], "\n", $text)) as $line) {
            if (preg_match(self::LIST_ITEM, $line, $match) === 1) {
                $flushParagraph();
                $items[] = $match[1];
            } else {
                $flushItems();
                $paragraph[] = $line;
            }
        }
        $flushParagraph();
        $flushItems();

        return $html;
    }

    /** One line (or a table cell): emphasis, no lists. */
    public static function inline(string $text): string
    {
        // escaped characters are parked, so the markers below do not see them
        $parked = [];
        $text = (string)preg_replace_callback('/\\\\([*_\\\\•-])/u', static function (array $match) use (&$parked): string {
            $parked[] = $match[1];

            return "\u{E000}" . (count($parked) - 1) . "\u{E001}";
        }, $text);

        $html = self::emphasis(htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));

        return (string)preg_replace_callback(
            "/\u{E000}(\\d+)\u{E001}/u",
            static fn(array $match): string => htmlspecialchars($parked[(int)$match[1]] ?? '', ENT_QUOTES, 'UTF-8'),
            $html
        );
    }

    /**
     * The markers as tags, always properly nested: a marker opens before a non-blank and
     * closes after one; "*" and "__" in the middle of a word ("2*3", "file_name") stay
     * text, and so does a marker that is never closed.
     */
    private static function emphasis(string $html): string
    {
        $tags = ['**' => 'strong', '*' => 'em', '__' => 'u'];
        $parts = preg_split('/(\*\*\*|\*\*|\*|__)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY) ?: [];
        $out = [];
        /** @var list<array{string, int}> $open marker and the index of its opening tag in $out */
        $open = [];
        $previous = '';

        foreach ($parts as $index => $part) {
            if (!isset($tags[$part]) && $part !== '***') {
                $out[] = $part;
                $previous = $part;
                continue;
            }
            $next = $parts[$index + 1] ?? '';
            // "***" is both - the order depends on what is open
            $markers = $part === '***'
                ? (end($open) !== false && end($open)[0] === '*' ? ['*', '**'] : ['**', '*'])
                : [$part];

            foreach ($markers as $markerIndex => $marker) {
                // inside "***" the neighbour of each half is the other half
                $before = $markerIndex > 0 ? '*' : mb_substr($previous, -1);
                $after = $markerIndex < count($markers) - 1 ? '*' : mb_substr($next, 0, 1);
                $midWord = $marker !== '**';
                $canClose = $before !== '' && !ctype_space($before) && (!$midWord || !self::isWordChar($after));
                $canOpen = $after !== '' && !ctype_space($after) && (!$midWord || !self::isWordChar($before));
                $position = self::find($open, $marker);

                if ($canClose && $position !== null) {
                    // close what was opened after it, and open it again behind
                    $reopen = array_splice($open, $position + 1);
                    array_pop($open);
                    foreach (array_reverse($reopen) as [$inner]) {
                        $out[] = '</' . $tags[$inner] . '>';
                    }
                    $out[] = '</' . $tags[$marker] . '>';
                    foreach ($reopen as [$inner]) {
                        $out[] = '<' . $tags[$inner] . '>';
                        $open[] = [$inner, count($out) - 1];
                    }
                } elseif ($canOpen) {
                    $out[] = '<' . $tags[$marker] . '>';
                    $open[] = [$marker, count($out) - 1];
                } else {
                    $out[] = $marker;
                }
            }
            $previous = $part;
        }
        // what was never closed is text after all
        foreach ($open as [$marker, $position]) {
            $out[$position] = $marker;
        }

        return implode('', $out);
    }

    /** @param list<array{string, int}> $open */
    private static function find(array $open, string $marker): ?int
    {
        for ($index = count($open) - 1; $index >= 0; $index--) {
            if ($open[$index][0] === $marker) {
                return $index;
            }
        }

        return null;
    }

    private static function isWordChar(string $char): bool
    {
        return $char !== '' && preg_match('/[\p{L}\p{N}_]/u', $char) === 1;
    }
}
