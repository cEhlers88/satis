<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Html;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\Column;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\ContentRow;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\DocumentContent;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\HeadingColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\ImageColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TableColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TextColumn;

/**
 * The content of the PDF-Creator as HTML for dompdf.
 *
 * A row of one column is a plain block and continues on the next page like any text. Columns
 * side by side are the cells of a table - dompdf cannot continue a cell on the next page,
 * so these rows carry data-row, and PdfCreator checks that each of them fits on a page.
 */
final class ContentHtml
{
    public const ROW_ATTRIBUTE = 'data-row';
    /** A table up to this many rows moves to the next page as a whole instead of being split. */
    public const KEEP_TOGETHER_ROWS = 15;

    public static function css(DocumentContent $content): string
    {
        $accent = $content->settings->accentColor;

        return '.pre { white-space: pre-wrap; word-wrap: break-word; }'
            . 'ul { margin: 0; padding-left: 5mm; }'
            . 'li { margin: 0 0 0.5mm 0; }'
            . 'table.columns { width: 100%; border-collapse: collapse; table-layout: fixed; }'
            . 'table.columns > tbody > tr > td, table.columns > tr > td { padding: 0; }'
            . 'table.data { width: 100%; border-collapse: collapse; }'
            . 'table.data th, table.data td { padding: 1mm 1.5mm; vertical-align: top; text-align: inherit; }'
            . 'table.data th { font-weight: bold; }'
            . 'table.data.borders th, table.data.borders td { border: 0.5pt solid #9a9a9a; }'
            . 'table.data.plain th, table.data.plain td { padding: 0 3mm 1mm 0; }'
            . 'table.data.borders th { background: #ececec; }'
            . 'table.data tr.even td { background: #f4f4f4; }'
            . '.heading { font-weight: bold; color: ' . $accent . '; line-height: 1.2; page-break-after: avoid; }'
            . '.heading.rule { border-bottom: 0.75pt solid ' . $accent . '; padding-bottom: 1mm; }'
            . 'img { max-width: 100%; }';
    }

    public static function body(DocumentContent $content): string
    {
        $html = '';
        foreach ($content->rows as $index => $row) {
            $spaceAfter = $row->spaceAfter ?? $content->settings->rowSpacing;
            $style = sprintf('margin-bottom: %dmm;', $spaceAfter) . ($row->pageBreakBefore && $index > 0 ? ' page-break-before: always;' : '');
            // a heading alone in its row stays with the row that follows
            if (count($row->columns) === 1 && $row->columns[0] instanceof HeadingColumn) {
                $style .= ' page-break-after: avoid;';
            }
            $html .= '<div class="row" style="' . $style . '">' . self::row($row, $index) . '</div>';
        }

        return $html;
    }

    private static function row(ContentRow $row, int $index): string
    {
        if (count($row->columns) === 1) {
            return self::column($row->columns[0]);
        }

        // the gap is split between the neighbouring cells, so the outer edges stay flush
        $cells = '';
        $last = count($row->columns) - 1;
        foreach ($row->columns as $position => $column) {
            $padding = sprintf(
                'padding-left: %smm; padding-right: %smm;',
                $position === 0 ? '0' : self::number($row->gap / 2),
                $position === $last ? '0' : self::number($row->gap / 2)
            );
            $cells .= sprintf(
                '<td style="width: %s%%; vertical-align: %s; %s">%s</td>',
                self::number($row->percentages()[$position]),
                $column->style->verticalAlign,
                $padding,
                self::column($column)
            );
        }

        return sprintf('<table class="columns" %s="%d"><tr>%s</tr></table>', self::ROW_ATTRIBUTE, $index, $cells);
    }

    private static function column(Column $column): string
    {
        $style = $column->style->css();

        return match (true) {
            $column instanceof TextColumn => '<div style="' . $style . '">' . InlineText::block($column->text) . '</div>',
            $column instanceof HeadingColumn => self::heading($column, $style),
            $column instanceof ImageColumn => self::image($column, $style),
            $column instanceof TableColumn => self::table($column, $style),
            default => '',
        };
    }

    private static function heading(HeadingColumn $column, string $style): string
    {
        // the column's own size and colour win over those of the level and the accent
        $levelSize = sprintf('font-size: %dpt;', HeadingColumn::SIZES[$column->level]);

        return sprintf(
            '<div class="heading%s" style="%s %s">%s</div>',
            $column->rule ? ' rule' : '',
            $levelSize,
            $style,
            InlineText::inline($column->text)
        );
    }

    private static function image(ImageColumn $column, string $style): string
    {
        if ($column->src === null) {
            return '';
        }

        return sprintf(
            '<div style="%s"><img src="%s" style="width: %d%%;" alt=""></div>',
            $style,
            htmlspecialchars($column->src, ENT_QUOTES, 'UTF-8'),
            $column->width
        );
    }

    private static function table(TableColumn $column, string $style): string
    {
        if ($column->cells === []) {
            return '';
        }
        $rows = $column->cells;
        // the widths go onto the cells of the first row - with table-layout: fixed they hold for all
        $total = array_sum($column->columnWidths);
        $widthOf = static fn(int $index, bool $first): string => $first && $total > 0
            ? sprintf(' style="width: %s%%"', self::number($column->columnWidths[$index] * 100 / $total))
            : '';
        $cellsOf = static function (array $row, string $tag, bool $first) use ($widthOf): string {
            $html = '';
            foreach ($row as $index => $cell) {
                $html .= sprintf('<%1$s class="pre"%2$s>%3$s</%1$s>', $tag, $widthOf($index, $first), InlineText::inline($cell));
            }

            return $html;
        };
        $head = '';
        if ($column->headerRow) {
            $head = '<thead><tr>' . $cellsOf(array_shift($rows), 'th', true) . '</tr></thead>';
        }
        $body = '';
        foreach ($rows as $index => $row) {
            $class = $column->striped && $index % 2 === 1 ? ' class="even"' : '';
            $body .= '<tr' . $class . '>' . $cellsOf($row, 'td', $head === '' && $index === 0) . '</tr>';
        }

        // a short table is not worth splitting - least of all right after its header row
        $keepTogether = count($column->cells) <= self::KEEP_TOGETHER_ROWS ? 'page-break-inside: avoid; ' : '';

        return sprintf(
            '<table class="data%s" style="%s%s%s">%s<tbody>%s</tbody></table>',
            $column->borders ? ' borders' : ' plain',
            $keepTogether,
            $total > 0 ? 'table-layout: fixed; ' : '',
            $style,
            $head,
            $body
        );
    }

    private static function number(float $value): string
    {
        return rtrim(rtrim(number_format($value, 3, '.', ''), '0'), '.');
    }
}
