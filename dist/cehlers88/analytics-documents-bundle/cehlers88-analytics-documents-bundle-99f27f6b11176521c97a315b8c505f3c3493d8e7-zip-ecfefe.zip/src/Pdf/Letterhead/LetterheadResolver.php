<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Command\CommandResolver;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Repository\LetterheadRepository;

/**
 * Makes the effective letterhead of a definition: the letterheads it is based on are applied
 * from the root down, each field as its mode says (LetterheadDefinition), and at last the
 * commands in the texts are resolved.
 *
 * The texts are kept as parts until then - a text that appends to an inherited one is the
 * inherited parts plus its own - and the parts become one text, line by line.
 */
class LetterheadResolver
{
    /** A letterhead may be based on one that is based on one … this many times. */
    public const MAX_DEPTH = 10;

    public function __construct(
        private readonly LetterheadRepository $letterheads,
        private readonly CommandResolver      $commandResolver,
    )
    {
    }

    /**
     * The fields after inheritance: values, and for the texts their parts
     * (`[{source, value, commands}]`).
     *
     * @param int|null $ownId the stored letterhead the definition belongs to - it must not
     *                        turn up among the ones it is based on
     * @return array<string, mixed>
     */
    public function effective(LetterheadDefinition $definition, ?int $ownId = null): array
    {
        $values = [];
        foreach (LetterheadData::FIELDS as $field => $kind) {
            $values[$field] = $kind === 'text' ? [] : LetterheadData::defaultOf($field);
        }
        foreach ($this->chain($definition, $ownId) as $level) {
            foreach ($level->fields as $field => $entry) {
                $values[$field] = self::apply($values[$field], $entry, LetterheadData::FIELDS[$field]);
            }
        }

        return $values;
    }

    /** The letterhead as it is laid out; $runCommands false shows commands as a marker. */
    public function data(LetterheadDefinition $definition, ?int $ownId = null, bool $runCommands = true): LetterheadData
    {
        $values = $this->effective($definition, $ownId);
        foreach (LetterheadData::FIELDS as $field => $kind) {
            if ($kind === 'text') {
                $where = sprintf('Briefpapier „%s“, %s:', $definition->name, LetterheadData::LABELS[$field]);
                $values[$field] = $this->text($values[$field], $where, $runCommands);
            }
        }

        return new LetterheadData($definition->name, ...$values);
    }

    /**
     * The definition and the ones it is based on, root first.
     *
     * @return list<LetterheadDefinition>
     */
    public function chain(LetterheadDefinition $definition, ?int $ownId = null): array
    {
        $chain = [$definition];
        $seen = $ownId === null ? [] : [$ownId => true];
        $parentId = $definition->parentId;
        while ($parentId !== null) {
            if (isset($seen[$parentId])) {
                throw new PdfCreatorException(sprintf('Briefpapier „%s“: die Grundlagen verweisen im Kreis aufeinander', $definition->name));
            }
            if (count($chain) > self::MAX_DEPTH) {
                throw new PdfCreatorException(sprintf('Briefpapier „%s“: mehr als %d Ebenen Vererbung', $definition->name, self::MAX_DEPTH));
            }
            $seen[$parentId] = true;
            $parent = $this->letterheads->find($parentId);
            if ($parent === null) {
                throw new PdfCreatorException(sprintf('Briefpapier „%s“: das Grund-Briefpapier gibt es nicht (mehr)', $definition->name), 404);
            }
            $parentDefinition = $parent->toDefinition();
            $chain[] = $parentDefinition;
            $parentId = $parentDefinition->parentId;
        }

        return array_reverse($chain);
    }

    private static function apply(mixed $current, array $entry, string $kind): mixed
    {
        $mode = $entry['mode'] ?? 'inherit';
        if ($mode === 'inherit') {
            return $current;
        }
        if ($kind !== 'text') {
            return $entry['value'] ?? null;
        }
        $part = ['source' => $entry['source'] ?? 'text', 'value' => $entry['value'] ?? '', 'commands' => $entry['commands'] ?? null];
        // an empty text neither replaces with nothing nor adds an empty line
        $empty = $part['source'] === 'text' && trim((string)$part['value']) === '';

        return match ($mode) {
            'append' => $empty ? $current : [...$current, $part],
            'prepend' => $empty ? $current : [$part, ...$current],
            default => $empty ? [] : [$part],
        };
    }

    /** @param list<array{source: string, value: string, commands: mixed}> $parts */
    private function text(array $parts, string $where, bool $runCommands): string
    {
        $lines = [];
        foreach ($parts as $part) {
            $lines[] = $part['source'] === 'commands'
                ? ($runCommands ? $this->commandResolver->text($part['commands'], $where) : '⚙ Command')
                : $part['value'];
        }

        return rtrim(implode("\n", $lines));
    }
}
