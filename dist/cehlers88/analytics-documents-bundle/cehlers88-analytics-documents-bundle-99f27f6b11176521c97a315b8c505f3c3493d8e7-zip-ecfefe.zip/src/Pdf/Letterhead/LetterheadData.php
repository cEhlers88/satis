<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\ImageDataUrl;

/**
 * A letterhead ("Briefpapier") as it is laid out: a header with an optional logo, a footer,
 * optional page numbers and the page margins the text keeps clear of them. Lengths are
 * millimetres, the font size is points.
 *
 * This is the effective letterhead - what LetterheadResolver makes of a letterhead, the
 * ones it inherits from and the commands in its texts. field() checks a single value and
 * is what LetterheadDefinition uses as well.
 */
final readonly class LetterheadData
{
    public const ALIGNMENTS = ['left', 'center', 'right'];
    public const MAX_NAME_LENGTH = 120;
    public const MAX_TEXT_LENGTH = 2000;
    public const MAX_LOGO_BYTES = 1048576;

    /** Every field and its kind - LetterheadDefinition knows what can be inherited from this. */
    public const FIELDS = [
        'headerText' => 'text',
        'headerAlign' => 'align',
        'logo' => 'image',
        'logoPosition' => 'align',
        'logoWidth' => 'number',
        'footerText' => 'text',
        'footerAlign' => 'align',
        'pageNumbers' => 'bool',
        'marginTop' => 'number',
        'marginBottom' => 'number',
        'marginLeft' => 'number',
        'marginRight' => 'number',
        'fontSize' => 'number',
    ];

    /** How the fields are called in messages. */
    public const LABELS = [
        'headerText' => 'Kopfzeile',
        'headerAlign' => 'Ausrichtung der Kopfzeile',
        'logo' => 'Logo',
        'logoPosition' => 'Position des Logos',
        'logoWidth' => 'Breite des Logos',
        'footerText' => 'Fußzeile',
        'footerAlign' => 'Ausrichtung der Fußzeile',
        'pageNumbers' => 'Seitenzahlen',
        'marginTop' => 'Rand oben',
        'marginBottom' => 'Rand unten',
        'marginLeft' => 'Rand links',
        'marginRight' => 'Rand rechts',
        'fontSize' => 'Schriftgröße',
    ];

    /** name => [default, min, max] - the mask of the tool takes its limits from here too */
    public const NUMBERS = [
        'logoWidth' => [40, 10, 120],
        'marginTop' => [45, 10, 120],
        'marginBottom' => [30, 15, 100],
        'marginLeft' => [25, 10, 50],
        'marginRight' => [20, 10, 50],
        'fontSize' => [11, 8, 16],
    ];

    public function __construct(
        public string  $name,
        public string  $headerText = '',
        public string  $headerAlign = 'left',
        public ?string $logo = null,
        public string  $logoPosition = 'right',
        public int     $logoWidth = 40,
        public string  $footerText = '',
        public string  $footerAlign = 'left',
        public bool    $pageNumbers = false,
        public int     $marginTop = 45,
        public int     $marginBottom = 30,
        public int     $marginLeft = 25,
        public int     $marginRight = 20,
        public int     $fontSize = 11,
    )
    {
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $values = ['name' => self::name($data['name'] ?? '')];
        foreach (self::FIELDS as $field => $kind) {
            $values[$field] = self::field($field, $data[$field] ?? self::defaultOf($field));
        }

        return new self(...$values);
    }

    public static function name(mixed $value): string
    {
        $name = self::text($value, self::MAX_NAME_LENGTH, 'Name', false);
        if ($name === '') {
            throw new PdfCreatorException('Ein Briefpapier braucht einen Namen');
        }

        return $name;
    }

    /** What a field is when nothing sets it. */
    public static function defaultOf(string $field): mixed
    {
        return (new \ReflectionParameter([self::class, '__construct'], $field))->getDefaultValue();
    }

    /** Checks one value of a field and hands it back as the field keeps it. */
    public static function field(string $field, mixed $value): mixed
    {
        $label = self::LABELS[$field] ?? $field;

        return match (self::FIELDS[$field] ?? null) {
            'text' => self::text($value ?? '', self::MAX_TEXT_LENGTH, $label),
            'align' => self::alignment($value, $label),
            'image' => is_string($value) && $value !== '' ? ImageDataUrl::normalize($value, self::MAX_LOGO_BYTES, 'Das Logo') : null,
            'bool' => filter_var($value ?? false, FILTER_VALIDATE_BOOLEAN),
            'number' => self::number($value, self::NUMBERS[$field][1], self::NUMBERS[$field][2], $label),
            default => throw new PdfCreatorException(sprintf('Ein Briefpapier hat kein Feld "%s"', $field)),
        };
    }

    /**
     * @param bool $withLogo false leaves the (possibly large) image out - the list of
     *                       letterheads only needs to know whether there is one
     * @return array<string, mixed>
     */
    public function toArray(bool $withLogo = true): array
    {
        $data = get_object_vars($this);
        if (!$withLogo) {
            unset($data['logo']);
        }
        $data['hasLogo'] = $this->logo !== null;

        return $data;
    }

    private static function text(mixed $value, int $maxLength, string $field, bool $multiLine = true): string
    {
        if (!is_string($value) || !mb_check_encoding($value, 'UTF-8')) {
            throw new PdfCreatorException(sprintf('%s: muss Text sein', $field));
        }
        $value = str_replace(["\r\n", "\r"], "\n", $value);
        $value = $multiLine ? rtrim($value) : trim(str_replace("\n", ' ', $value));
        if (mb_strlen($value) > $maxLength) {
            throw new PdfCreatorException(sprintf('%s: ist länger als %d Zeichen', $field, $maxLength));
        }

        return $value;
    }

    private static function alignment(mixed $value, string $field): string
    {
        if (!in_array($value, self::ALIGNMENTS, true)) {
            throw new PdfCreatorException(sprintf('%s: muss eines von %s sein', $field, implode(', ', self::ALIGNMENTS)));
        }

        return $value;
    }

    private static function number(mixed $value, int $min, int $max, string $field): int
    {
        $number = filter_var($value, FILTER_VALIDATE_INT);
        if ($number === false || $number < $min || $number > $max) {
            throw new PdfCreatorException(sprintf('%s: muss eine ganze Zahl von %d bis %d sein', $field, $min, $max));
        }

        return $number;
    }
}
