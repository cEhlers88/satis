<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Command\CommandResolver;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;

/**
 * A letterhead as it is stored and edited: its name, the letterhead it is based on (if any)
 * and, per field of LetterheadData::FIELDS, what it does with it:
 *
 *     {"headerText": {"mode": "append", "source": "text", "value": "Abteilung Einkauf"},
 *      "footerText": {"mode": "inherit"},
 *      "logo": {"mode": "replace", "value": "data:image/png;base64,…"},
 *      "marginTop": {"mode": "replace", "value": 50}}
 *
 * Modes: "inherit" takes the value of the letterhead it is based on, "replace" sets its own;
 * texts can also be put after ("append") or before ("prepend") the inherited text. A text
 * is plain text or - "source": "commands" - commands resolved when the PDF is made.
 * Without a base letterhead every field is "replace", with its default where nothing is set.
 */
final readonly class LetterheadDefinition
{
    public const MODES = ['inherit', 'replace'];
    public const TEXT_MODES = ['inherit', 'replace', 'append', 'prepend'];

    /** @param array<string, array<string, mixed>> $fields */
    public function __construct(
        public string $name,
        public ?int   $parentId,
        public array  $fields,
    )
    {
    }

    /** @param array<string, mixed> $data {name, parentId, definition} */
    public static function fromArray(array $data): self
    {
        $name = LetterheadData::name($data['name'] ?? '');
        $parentId = $data['parentId'] ?? null;
        if ($parentId !== null && $parentId !== '') {
            $parentId = filter_var($parentId, FILTER_VALIDATE_INT);
            if ($parentId === false || $parentId < 1) {
                throw new PdfCreatorException('Das Grund-Briefpapier gibt es nicht');
            }
        } else {
            $parentId = null;
        }
        $given = $data['definition'] ?? [];
        if (!is_array($given)) {
            throw new PdfCreatorException('Die Definition des Briefpapiers muss ein Objekt sein');
        }

        $fields = [];
        foreach (LetterheadData::FIELDS as $field => $kind) {
            $entry = $given[$field] ?? null;
            $entry = is_array($entry) ? $entry : ['mode' => $parentId === null ? 'replace' : 'inherit'];
            $fields[$field] = self::field($field, $kind, $entry, $parentId !== null);
        }

        return new self($name, $parentId, $fields);
    }

    /** @return array{name: string, parentId: ?int, definition: array<string, array<string, mixed>>} */
    public function toArray(): array
    {
        return ['name' => $this->name, 'parentId' => $this->parentId, 'definition' => $this->fields];
    }

    /**
     * @param array<string, mixed> $entry
     * @return array<string, mixed>
     */
    private static function field(string $field, string $kind, array $entry, bool $hasParent): array
    {
        $label = LetterheadData::LABELS[$field];
        $modes = $kind === 'text' ? self::TEXT_MODES : self::MODES;
        $mode = $entry['mode'] ?? 'replace';
        if (!in_array($mode, $modes, true)) {
            throw new PdfCreatorException(sprintf('%s: den Modus "%s" gibt es nicht', $label, is_scalar($mode) ? $mode : '?'));
        }
        // nothing to inherit from - the field stands on its own
        if (!$hasParent) {
            $mode = 'replace';
        }
        if ($mode === 'inherit') {
            return ['mode' => 'inherit'];
        }
        if ($kind !== 'text') {
            return ['mode' => $mode, 'value' => LetterheadData::field($field, $entry['value'] ?? LetterheadData::defaultOf($field))];
        }

        $commands = ($entry['source'] ?? 'text') === 'commands';

        return [
            'mode' => $mode,
            'source' => $commands ? 'commands' : 'text',
            'value' => LetterheadData::field($field, $entry['value'] ?? ''),
            'commands' => $commands ? CommandResolver::definition($entry['commands'] ?? null, $label . ':') : null,
        ];
    }
}
