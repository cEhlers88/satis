<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Command;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\Column;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\ContentRow;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\DocumentContent;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\HeadingColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TableColumn;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\TextColumn;

/**
 * Turns a DocumentContent whose columns hold commands into one of plain text: every command
 * column is replaced by the same column with what its commands answered. The rows are
 * resolved top to bottom, so a command can use a variable an earlier one set.
 */
class ContentCommandResolver
{
    public function __construct(
        private readonly CommandResolver $commandResolver,
    )
    {
    }

    public function resolve(DocumentContent $content): DocumentContent
    {
        $rows = [];
        foreach ($content->rows as $rowIndex => $row) {
            $columns = [];
            foreach ($row->columns as $columnIndex => $column) {
                $where = count($row->columns) > 1
                    ? sprintf('Zeile %d, Spalte %d:', $rowIndex + 1, $columnIndex + 1)
                    : sprintf('Zeile %d:', $rowIndex + 1);
                $columns[] = $column->commands() === null ? $column : $this->resolveColumn($column, $where);
            }
            $rows[] = new ContentRow($columns, $row->widths, $row->gap, $row->spaceAfter, $row->pageBreakBefore);
        }

        return new DocumentContent($content->settings, $rows);
    }

    private function resolveColumn(Column $column, string $where): Column
    {
        $commands = $column->commands();

        return match (true) {
            $column instanceof TextColumn => new TextColumn($column->style, $this->commandResolver->text($commands, $where)),
            $column instanceof HeadingColumn => new HeadingColumn(
                $column->style,
                trim($this->commandResolver->text($commands, $where)),
                $column->level,
                $column->rule,
            ),
            // read like cells the browser sent, so the limits of a table hold for the answer too
            $column instanceof TableColumn => TableColumn::read([
                'cells' => $this->commandResolver->table($commands, $where),
                'headerRow' => $column->headerRow,
                'borders' => $column->borders,
                'striped' => $column->striped,
            ], $column->style, $where),
            default => $column,
        };
    }
}
