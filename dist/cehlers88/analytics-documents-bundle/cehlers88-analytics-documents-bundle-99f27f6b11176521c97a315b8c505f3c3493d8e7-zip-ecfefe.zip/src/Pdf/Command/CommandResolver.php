<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Command;

use Cehlers88\AnalyticsCore\Macro\ENUM\eMacroVariableContext;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;

/**
 * Resolves the commands a field of the PDF-Creator holds - the text of a column, the data of
 * a table, the header or footer of a letterhead - before the PDF is laid out.
 *
 * A field in command mode holds what <commands-holder> gives: a single command
 * (`["get_var", {"name": "x"}]`), or a list of entries that are text or commands
 * (`["Musterstadt, ", ["get_var", {"name": "date"}]]`). The CommandPlayer only runs lists
 * that are commands through and through, so every entry is run on its own here and the
 * results are put together - as text one after the other ("\n" in a text entry is a line
 * break), as table the rows the commands answer with.
 *
 * Commands run like those of a report (ReportRenderer): for application 1, with the JOB
 * variables cleared once per PDF - so a command in an earlier field can set a variable a
 * later one reads. What they echo is caught and used when they return nothing.
 */
class CommandResolver
{
    /** The application the commands run for - the one reports use as well. */
    public const APPLICATION_ID = 1;
    /** A definition larger than this (as json) is refused. */
    public const MAX_DEFINITION_BYTES = 65536;

    private bool $started = false;

    public function __construct(
        private readonly MacroEnvironment      $macroEnvironment,
        private readonly ApplicationRepository $applicationRepository,
    )
    {
    }

    /**
     * Checks a definition as the browser sent it - without running it.
     *
     * @return array<mixed>|string
     */
    public static function definition(mixed $definition, string $where): array|string
    {
        if (is_string($definition) && trim($definition) !== '') {
            return $definition;
        }
        if (!is_array($definition) || $definition === []) {
            throw new PdfCreatorException(trim($where . ' Es sind noch keine Commands hinterlegt'));
        }
        $json = json_encode($definition);
        if ($json === false || strlen($json) > self::MAX_DEFINITION_BYTES) {
            throw new PdfCreatorException(trim($where . ' Die Commands sind zu umfangreich'), 413);
        }

        return $definition;
    }

    /** The result as text: the entries one after the other. */
    public function text(array|string $definition, string $where): string
    {
        $text = '';
        foreach ($this->runEntries($definition, $where) as $result) {
            $text .= self::stringify($result);
        }

        return $text;
    }

    /**
     * The result as rows of a table: a list of lists is taken as it is, a list of records
     * becomes a header row of their keys and a row per record, a record becomes a row
     * per key.
     *
     * @return list<list<string>>
     */
    public function table(array|string $definition, string $where): array
    {
        $results = $this->runEntries($definition, $where);
        $data = count($results) === 1 ? $results[0] : $results;
        if (is_string($data) && ($decoded = json_decode($data, true)) !== null && is_array($decoded)) {
            $data = $decoded;
        }
        if (!is_array($data)) {
            return [[self::stringify($data)]];
        }
        if ($data === []) {
            return [];
        }
        if (!array_is_list($data)) {
            return array_map(
                static fn(string|int $key, mixed $value): array => [(string)$key, self::stringify($value)],
                array_keys($data),
                array_values($data)
            );
        }
        $first = $data[0];
        if (is_array($first) && !array_is_list($first)) {
            $keys = array_keys($first);
            $rows = [array_map('strval', $keys)];
            foreach ($data as $record) {
                $record = is_array($record) ? $record : [];
                $rows[] = array_map(static fn(string|int $key): string => self::stringify($record[$key] ?? ''), $keys);
            }

            return $rows;
        }

        return array_map(
            static fn(mixed $row): array => is_array($row) ? array_map(self::stringify(...), array_values($row)) : [self::stringify($row)],
            $data
        );
    }

    /** @return list<mixed> the result of every entry */
    private function runEntries(array|string $definition, string $where): array
    {
        if (is_string($definition)) {
            return [self::unescape($definition)];
        }
        $this->start();
        $player = $this->macroEnvironment->getCommandPlayer();
        $results = [];
        ob_start();
        try {
            foreach (self::entries($definition) as $entry) {
                if ($entry === null || is_scalar($entry)) {
                    $results[] = is_string($entry) ? self::unescape($entry) : $entry;
                    continue;
                }
                $result = $player->run($entry);
                // the player hands back what it does not know as a command
                if ($result === $entry && is_array($entry) && self::isCommand($entry)) {
                    throw new PdfCreatorException(trim(sprintf('%s Den Command „%s“ gibt es nicht', $where, $entry[0])), 422);
                }
                $results[] = $result;
            }
        } catch (PdfCreatorException $exception) {
            throw $exception;
        } catch (\Throwable $exception) {
            throw new PdfCreatorException(trim(sprintf('%s Ein Command ist fehlgeschlagen: %s', $where, $exception->getMessage())), 422, $exception);
        } finally {
            $output = (string)ob_get_clean();
        }
        $answered = array_filter($results, static fn(mixed $result): bool => $result !== null && $result !== '' && $result !== []);
        if ($answered === [] && trim($output) !== '') {
            return [$output];
        }

        return $results;
    }

    private function start(): void
    {
        if ($this->started) {
            return;
        }
        $application = $this->applicationRepository->find(self::APPLICATION_ID)
            ?? throw new PdfCreatorException('Für Commands fehlt die Application ' . self::APPLICATION_ID, 500);
        $this->macroEnvironment->setApplication($application);
        $this->macroEnvironment->getVariablesStoreProvider()->clearContext(eMacroVariableContext::JOB);
        $this->started = true;
    }

    /**
     * One command, or a list of entries? A command is always a name and its properties
     * (`["name", {…}]` - <command-element> gives both); the list `["text", ["name", {…}]]`
     * has a command, not properties, in second place, and `["text"]` is a single text.
     */
    public static function isCommand(array $value): bool
    {
        return array_is_list($value)
            && count($value) === 2 && is_string($value[0])
            && is_array($value[1]) && ($value[1] === [] || !array_is_list($value[1]));
    }

    /** @return list<mixed> */
    private static function entries(array $definition): array
    {
        return self::isCommand($definition) ? [$definition] : array_values($definition);
    }

    /** "\n" typed into a text entry is a line break - the entries have one line each. */
    private static function unescape(string $text): string
    {
        return str_replace('\\n', "\n", $text);
    }

    public static function stringify(mixed $value): string
    {
        return match (true) {
            $value === null => '',
            is_bool($value) => $value ? 'true' : 'false',
            is_scalar($value) => (string)$value,
            $value instanceof \Stringable => (string)$value,
            is_array($value) && array_is_list($value) && array_filter($value, static fn(mixed $item): bool => !is_scalar($item) && $item !== null) === []
                => implode("\n", array_map(self::stringify(...), $value)),
            default => (string)json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        };
    }
}
