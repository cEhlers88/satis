<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

/** Text with line breaks, lists ("- ") and **bold**, *italic*, __underlined__ - see InlineText. */
final readonly class TextColumn extends Column
{
    /** @param array<mixed>|string|null $commandDefinition commands that give the text instead */
    public function __construct(TextStyle $style, public string $text, public array|string|null $commandDefinition = null)
    {
        parent::__construct($style);
    }

    public function commands(): array|string|null
    {
        return $this->commandDefinition;
    }

    public function textLength(): int
    {
        return mb_strlen($this->text);
    }
}
