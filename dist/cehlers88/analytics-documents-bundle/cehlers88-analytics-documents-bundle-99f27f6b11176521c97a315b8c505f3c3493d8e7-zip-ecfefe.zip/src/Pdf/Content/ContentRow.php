<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

/**
 * A row of the content: up to MAX_COLUMNS columns side by side. The widths are shares
 * ("1" and "3": a quarter and three quarters). A row of one column continues on the next
 * page like any text; columns side by side have to fit on one page - PdfCreator says so
 * when they do not.
 */
final readonly class ContentRow
{
    public const MAX_COLUMNS = 4;

    /**
     * @param list<Column> $columns
     * @param list<int>    $widths one share per column
     */
    public function __construct(
        public array $columns,
        public array $widths,
        /** between the columns (mm) */
        public int   $gap = 6,
        /** below the row (mm); null: ContentSettings::$rowSpacing */
        public ?int  $spaceAfter = null,
        public bool  $pageBreakBefore = false,
    )
    {
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data, string $where): self
    {
        $columnData = Input::list($data['columns'] ?? null, $where . ' Spalten');
        if ($columnData === [] || count($columnData) > self::MAX_COLUMNS) {
            throw Input::refuse($where, sprintf('braucht 1 bis %d Spalten', self::MAX_COLUMNS));
        }
        $columns = [];
        foreach ($columnData as $index => $column) {
            $columnWhere = count($columnData) > 1 ? sprintf('%s, Spalte %d:', rtrim($where, ':'), $index + 1) : $where;
            $columns[] = Column::fromArray(Input::map($column, $columnWhere), $columnWhere);
        }

        $widths = [];
        $given = Input::list($data['widths'] ?? null, $where . ' Spaltenbreiten');
        foreach ($columns as $index => $column) {
            $widths[] = Input::int($given[$index] ?? null, 1, 100, 1, $where . ' Spaltenbreite');
        }

        return new self(
            $columns,
            $widths,
            Input::int($data['gap'] ?? null, 0, 30, 6, $where . ' Spaltenabstand'),
            Input::optionalInt($data['spaceAfter'] ?? null, 0, 50, $where . ' Abstand danach'),
            Input::bool($data['pageBreakBefore'] ?? false),
        );
    }

    /** The share of every column in percent of the row, gaps not counted. */
    public function percentages(): array
    {
        $total = array_sum($this->widths);

        return array_map(static fn(int $width): float => round($width * 100 / $total, 3), $this->widths);
    }
}
