<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\PdfCreator;

/**
 * What the PDF-Creator lays out: the formatting of the document and its rows, top to
 * bottom. fromArray() takes it as the tool sends it and checks all of it, including the
 * limits of the whole document.
 *
 *     {"settings": {"fontFamily": "serif", "accentColor": "#1f4e79", …},
 *      "rows": [{"widths": [1, 3], "columns": [
 *          {"type": "text", "text": "04/2019 – heute", "style": {"align": "right"}},
 *          {"type": "text", "text": "**Entwickler**, Muster GmbH\n- Aufgabe"}]}]}
 */
final readonly class DocumentContent
{
    public const MAX_ROWS = 300;
    public const MAX_IMAGES = 20;

    /** @param list<ContentRow> $rows */
    public function __construct(
        public ContentSettings $settings,
        public array           $rows,
    )
    {
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $settings = ContentSettings::fromArray(Input::map($data['settings'] ?? null, 'Format:'));
        $rowData = Input::list($data['rows'] ?? null, 'Inhalt:');
        if (count($rowData) > self::MAX_ROWS) {
            throw new PdfCreatorException(sprintf('Ein Dokument hat höchstens %d Zeilen', self::MAX_ROWS), 413);
        }
        $rows = [];
        foreach ($rowData as $index => $row) {
            $where = sprintf('Zeile %d:', $index + 1);
            $rows[] = ContentRow::fromArray(Input::map($row, $where), $where);
        }

        $content = new self($settings, $rows);
        $content->checkLimits();

        return $content;
    }

    /** Plain text as the only content - what the tool sent before it knew rows. */
    public static function fromText(string $text): self
    {
        return new self(new ContentSettings(), [
            new ContentRow([new TextColumn(new TextStyle(), $text)], [1]),
        ]);
    }

    public function textLength(): int
    {
        $length = 0;
        foreach ($this->columns() as $column) {
            $length += $column->textLength();
        }

        return $length;
    }

    public function isEmpty(): bool
    {
        foreach ($this->columns() as $column) {
            if ($column->commands() !== null) {
                return false;
            }
            if ($column instanceof ImageColumn ? $column->src !== null : trim(self::plain($column)) !== '') {
                return false;
            }
        }

        return true;
    }

    /** @return iterable<Column> */
    public function columns(): iterable
    {
        foreach ($this->rows as $row) {
            yield from $row->columns;
        }
    }

    private function checkLimits(): void
    {
        if ($this->textLength() > PdfCreator::MAX_TEXT_LENGTH) {
            throw new PdfCreatorException(sprintf('Der Text ist länger als %d Zeichen', PdfCreator::MAX_TEXT_LENGTH), 413);
        }
        $images = 0;
        foreach ($this->columns() as $column) {
            if ($column instanceof ImageColumn && $column->src !== null) {
                $images++;
            }
        }
        if ($images > self::MAX_IMAGES) {
            throw new PdfCreatorException(sprintf('Ein Dokument hat höchstens %d Bilder', self::MAX_IMAGES), 413);
        }
    }

    private static function plain(Column $column): string
    {
        return match (true) {
            $column instanceof TextColumn, $column instanceof HeadingColumn => $column->text,
            $column instanceof TableColumn => implode('', array_merge(...($column->cells ?: [[]]))),
            default => '',
        };
    }
}
