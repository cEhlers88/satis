<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

/**
 * How the content of a column is set. null means "as the document says".
 */
final readonly class TextStyle
{
    public const ALIGNMENTS = ['left', 'center', 'right', 'justify'];
    public const VERTICAL_ALIGNMENTS = ['top', 'middle', 'bottom'];

    public function __construct(
        public string  $align = 'left',
        public bool    $bold = false,
        public bool    $italic = false,
        public bool    $underline = false,
        public ?int    $fontSize = null,
        public ?string $color = null,
        public string  $verticalAlign = 'top',
    )
    {
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data, string $where): self
    {
        return new self(
            align: Input::choice($data['align'] ?? null, self::ALIGNMENTS, 'left', $where . ' Ausrichtung'),
            bold: Input::bool($data['bold'] ?? false),
            italic: Input::bool($data['italic'] ?? false),
            underline: Input::bool($data['underline'] ?? false),
            fontSize: Input::optionalInt($data['fontSize'] ?? null, 6, 48, $where . ' Schriftgröße'),
            color: Input::color($data['color'] ?? null, $where . ' Farbe'),
            verticalAlign: Input::choice($data['verticalAlign'] ?? null, self::VERTICAL_ALIGNMENTS, 'top', $where . ' vertikale Ausrichtung'),
        );
    }

    /** The declarations for the element that holds the column's content. */
    public function css(): string
    {
        $css = 'text-align: ' . $this->align . ';';
        if ($this->bold) {
            $css .= ' font-weight: bold;';
        }
        if ($this->italic) {
            $css .= ' font-style: italic;';
        }
        if ($this->underline) {
            $css .= ' text-decoration: underline;';
        }
        if ($this->fontSize !== null) {
            $css .= ' font-size: ' . $this->fontSize . 'pt;';
        }
        if ($this->color !== null) {
            $css .= ' color: ' . $this->color . ';';
        }

        return $css;
    }
}
