<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

/**
 * A table of text cells. Long tables continue on the next page - with their header row,
 * if they have one.
 */
final readonly class TableColumn extends Column
{
    public const MAX_COLUMNS = 12;
    public const MAX_CELLS = 10000;
    public const MAX_CELL_LENGTH = 2000;

    /** @param list<list<string>> $cells rows of cells, all of the same length */
    public function __construct(
        TextStyle   $style,
        public array $cells,
        public bool  $headerRow = true,
        public bool  $borders = true,
        public bool  $striped = false,
        /** @var list<int> shares of the table's columns; empty: as wide as their content */
        public array $columnWidths = [],
        /** commands whose result are the rows, instead of the cells */
        public array|string|null $commandDefinition = null,
    )
    {
        parent::__construct($style);
    }

    public function commands(): array|string|null
    {
        return $this->commandDefinition;
    }

    /** @param array<string, mixed> $data */
    public static function read(array $data, TextStyle $style, string $where, array|string|null $commands = null): self
    {
        $rows = Input::list($data['cells'] ?? null, $where . ' Tabelle');
        $cells = [];
        $width = 0;
        foreach ($rows as $index => $row) {
            $row = Input::list($row, sprintf('%s Tabellenzeile %d', $where, $index + 1));
            $cells[] = array_map(
                static fn(mixed $cell): string => Input::text(is_int($cell) || is_float($cell) ? (string)$cell : $cell, $where . ' Tabellenzelle', self::MAX_CELL_LENGTH),
                $row
            );
            $width = max($width, count($row));
        }
        if ($width > self::MAX_COLUMNS) {
            throw Input::refuse($where, sprintf('Eine Tabelle hat höchstens %d Spalten', self::MAX_COLUMNS));
        }
        if ($width * count($cells) > self::MAX_CELLS) {
            throw Input::refuse($where, sprintf('Eine Tabelle hat höchstens %d Zellen', self::MAX_CELLS), 413);
        }
        // ragged rows are filled up, so every row has a cell for every column
        $cells = array_map(static fn(array $row): array => array_pad($row, $width, ''), $cells);

        $columnWidths = [];
        $givenWidths = Input::list($data['columnWidths'] ?? null, $where . ' Tabellen-Spaltenbreiten');
        if ($givenWidths !== [] && $width > 0) {
            for ($index = 0; $index < $width; $index++) {
                $columnWidths[] = Input::int($givenWidths[$index] ?? null, 1, 100, 1, $where . ' Tabellen-Spaltenbreite');
            }
        }

        return new self(
            $style,
            $cells,
            Input::bool($data['headerRow'] ?? true),
            Input::bool($data['borders'] ?? true),
            Input::bool($data['striped'] ?? false),
            $columnWidths,
            $commands,
        );
    }

    public function textLength(): int
    {
        $length = 0;
        foreach ($this->cells as $row) {
            foreach ($row as $cell) {
                $length += mb_strlen($cell);
            }
        }

        return $length;
    }
}
