<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\ImageDataUrl;

/** An image (data url) at a share of the width of its column; without one the column stays empty. */
final readonly class ImageColumn extends Column
{
    public const MAX_BYTES = 2097152;

    public function __construct(TextStyle $style, public ?string $src, public int $width = 100)
    {
        parent::__construct($style);
    }

    /** @param array<string, mixed> $data */
    public static function read(array $data, TextStyle $style, string $where): self
    {
        $src = $data['src'] ?? null;

        return new self(
            $style,
            is_string($src) && $src !== '' ? ImageDataUrl::normalize($src, self::MAX_BYTES, trim($where . ' Das Bild')) : null,
            Input::int($data['width'] ?? null, 5, 100, 100, $where . ' Bildbreite'),
        );
    }
}
