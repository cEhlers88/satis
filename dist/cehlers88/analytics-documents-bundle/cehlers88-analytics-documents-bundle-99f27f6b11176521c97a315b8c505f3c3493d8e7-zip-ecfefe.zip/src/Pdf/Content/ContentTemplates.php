<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

/**
 * Starting points of the PDF-Creator: the content of a document in the form the tool
 * sends it (DocumentContent::fromArray reads every one of them - the tests make sure).
 * The tool gets them through the templateData of its entry on the tools page.
 */
final class ContentTemplates
{
    /** @return array<string, array{title: string, description: string, content: array<string, mixed>}> */
    public static function all(): array
    {
        return [
            'cv' => [
                'title' => 'Tabellarischer Lebenslauf',
                'description' => 'Persönliche Daten mit Foto, Abschnitte mit Zeitraum und Stationen, Ort, Datum und Unterschrift',
                'content' => self::cv(),
            ],
            'letter' => [
                'title' => 'Brief',
                'description' => 'Absender, Anschrift, Datum, Betreff und Text - passend zu einem Briefpapier',
                'content' => self::letter(),
            ],
        ];
    }

    /** @return array<string, mixed> */
    private static function cv(): array
    {
        // every entry: the period on the left, a quarter of the width, the rest on the right -
        // the same shares in every row keep the periods in one line
        $entry = static fn(string $period, string $text): array => [
            'widths' => [1, 3],
            'columns' => [
                ['type' => 'text', 'text' => $period, 'style' => ['color' => '#555555']],
                ['type' => 'text', 'text' => $text],
            ],
        ];
        $section = static fn(string $title): array => [
            'widths' => [1],
            'spaceAfter' => 2,
            'columns' => [['type' => 'heading', 'text' => $title, 'level' => 2, 'rule' => true]],
        ];

        return [
            'settings' => ['fontFamily' => 'sans', 'fontSize' => 10, 'lineHeight' => 1.35, 'accentColor' => '#1f4e79', 'rowSpacing' => 3],
            'rows' => [
                ['widths' => [1], 'spaceAfter' => 6, 'columns' => [['type' => 'heading', 'text' => 'Lebenslauf', 'level' => 1]]],
                $section('Persönliche Daten'),
                [
                    // labels and values in two columns whose lines match - with the same shares
                    // as the entries below (a quarter for the labels), so everything lines up
                    'widths' => [1, 2, 1],
                    'spaceAfter' => 6,
                    'columns' => [
                        ['type' => 'text', 'text' => "Name\nAnschrift\n\nTelefon\nE-Mail\nGeburtsdatum", 'style' => ['color' => '#555555']],
                        ['type' => 'text', 'text' => "**Max Mustermann**\nMusterstraße 1\n12345 Musterstadt\n0123 456789\nmax.mustermann@example.com\n01.01.1990 in Musterstadt"],
                        ['type' => 'image', 'src' => null, 'width' => 100, 'style' => ['align' => 'right']],
                    ],
                ],
                $section('Berufserfahrung'),
                $entry('04/2021 – heute', "**Softwareentwickler**, Muster GmbH, Musterstadt\n- Entwicklung und Betrieb von Webanwendungen\n- Einführung automatisierter Tests"),
                $entry('09/2016 – 03/2021', "**Junior-Entwickler**, Beispiel AG, Beispielstadt\n- Pflege des Kundenportals"),
                ['widths' => [1], 'spaceAfter' => 3, 'columns' => [['type' => 'text', 'text' => '']]],
                $section('Ausbildung'),
                $entry('10/2012 – 08/2016', "**B. Sc. Informatik**, Hochschule Musterstadt\nAbschlussnote: 1,7"),
                $entry('06/2012', '**Abitur**, Gymnasium Musterstadt'),
                ['widths' => [1], 'spaceAfter' => 3, 'columns' => [['type' => 'text', 'text' => '']]],
                $section('Kenntnisse'),
                $entry('Sprachen', 'Deutsch (Muttersprache), Englisch (verhandlungssicher)'),
                $entry('EDV', 'PHP, TypeScript, SQL, Docker'),
                $entry('Interessen', 'Radfahren, Fotografie'),
                [
                    'widths' => [1, 1],
                    'spaceAfter' => 0,
                    'pageBreakBefore' => false,
                    'columns' => [
                        ['type' => 'text', 'text' => "\n\nMusterstadt, " . '01.01.2026', 'style' => ['verticalAlign' => 'bottom']],
                        ['type' => 'image', 'src' => null, 'width' => 60, 'style' => ['align' => 'left', 'verticalAlign' => 'bottom']],
                    ],
                ],
            ],
        ];
    }

    /** @return array<string, mixed> */
    private static function letter(): array
    {
        return [
            'settings' => ['fontFamily' => 'sans', 'lineHeight' => 1.4, 'rowSpacing' => 4],
            'rows' => [
                ['widths' => [1], 'spaceAfter' => 2, 'columns' => [['type' => 'text', 'text' => 'Muster GmbH · Musterstraße 1 · 12345 Musterstadt', 'style' => ['fontSize' => 7, 'underline' => true, 'color' => '#555555']]]],
                ['widths' => [1], 'spaceAfter' => 12, 'columns' => [['type' => 'text', 'text' => "Frau\nErika Beispiel\nBeispielweg 2\n54321 Beispielstadt"]]],
                ['widths' => [1], 'spaceAfter' => 8, 'columns' => [['type' => 'text', 'text' => 'Musterstadt, 01.01.2026', 'style' => ['align' => 'right']]]],
                ['widths' => [1], 'spaceAfter' => 6, 'columns' => [['type' => 'text', 'text' => 'Ihre Anfrage vom 15.12.2025', 'style' => ['bold' => true]]]],
                ['widths' => [1], 'columns' => [['type' => 'text', 'text' => "Sehr geehrte Frau Beispiel,\n\nvielen Dank für Ihre Anfrage. …\n\nMit freundlichen Grüßen\n\n\nMax Mustermann"]]],
            ],
        ];
    }
}
