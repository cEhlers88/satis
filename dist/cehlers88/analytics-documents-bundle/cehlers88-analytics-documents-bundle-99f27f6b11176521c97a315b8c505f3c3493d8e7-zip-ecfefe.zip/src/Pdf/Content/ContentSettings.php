<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

/**
 * The formatting of the whole document; columns set their own on top of it.
 */
final readonly class ContentSettings
{
    /** what the tool offers => the font dompdf brings along for it */
    public const FONTS = [
        'sans' => 'DejaVu Sans',
        'serif' => 'DejaVu Serif',
        'mono' => 'DejaVu Sans Mono',
    ];

    public function __construct(
        public string $fontFamily = 'sans',
        /** null: the letterhead's font size, or 11 pt without one */
        public ?int   $fontSize = null,
        public float  $lineHeight = 1.4,
        public string $color = '#000000',
        /** headings and their lines */
        public string $accentColor = '#1f4e79',
        /** space below every row, unless the row says otherwise (mm) */
        public int    $rowSpacing = 3,
    )
    {
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $where = 'Format:';

        return new self(
            fontFamily: Input::choice($data['fontFamily'] ?? null, array_keys(self::FONTS), 'sans', $where . ' Schrift'),
            fontSize: Input::optionalInt($data['fontSize'] ?? null, 7, 24, $where . ' Schriftgröße'),
            lineHeight: Input::float($data['lineHeight'] ?? null, 1.0, 3.0, 1.4, $where . ' Zeilenabstand'),
            color: Input::color($data['color'] ?? null, $where . ' Textfarbe') ?? '#000000',
            accentColor: Input::color($data['accentColor'] ?? null, $where . ' Akzentfarbe') ?? '#1f4e79',
            rowSpacing: Input::int($data['rowSpacing'] ?? null, 0, 30, 3, $where . ' Abstand zwischen Zeilen'),
        );
    }

    public function font(): string
    {
        return self::FONTS[$this->fontFamily];
    }
}
