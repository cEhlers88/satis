<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;

/**
 * Reading the content of the PDF-Creator as the browser sent it: every value is checked
 * against what it may be, and a refusal names where it was ("Zeile 3, Spalte 2: …").
 *
 * @internal
 */
final class Input
{
    public static function text(mixed $value, string $where, int $maxLength = PHP_INT_MAX): string
    {
        if ($value === null) {
            return '';
        }
        if (!is_string($value) || !mb_check_encoding($value, 'UTF-8')) {
            throw self::refuse($where, 'muss Text sein');
        }
        $value = str_replace(["\r\n", "\r"], "\n", $value);
        if (mb_strlen($value) > $maxLength) {
            throw self::refuse($where, sprintf('ist länger als %d Zeichen', $maxLength));
        }

        return $value;
    }

    public static function int(mixed $value, int $min, int $max, int $default, string $where): int
    {
        if ($value === null || $value === '') {
            return $default;
        }
        $number = filter_var($value, FILTER_VALIDATE_INT);
        if ($number === false || $number < $min || $number > $max) {
            throw self::refuse($where, sprintf('muss eine ganze Zahl von %d bis %d sein', $min, $max));
        }

        return $number;
    }

    /** null (or nothing) stays null - "take what the document says". */
    public static function optionalInt(mixed $value, int $min, int $max, string $where): ?int
    {
        return $value === null || $value === '' ? null : self::int($value, $min, $max, $min, $where);
    }

    public static function float(mixed $value, float $min, float $max, float $default, string $where): float
    {
        if ($value === null || $value === '') {
            return $default;
        }
        $number = filter_var($value, FILTER_VALIDATE_FLOAT);
        if ($number === false || $number < $min || $number > $max) {
            throw self::refuse($where, sprintf('muss eine Zahl von %s bis %s sein', $min, $max));
        }

        return round($number, 2);
    }

    public static function bool(mixed $value): bool
    {
        return filter_var($value ?? false, FILTER_VALIDATE_BOOLEAN);
    }

    /** @param list<string> $allowed */
    public static function choice(mixed $value, array $allowed, string $default, string $where): string
    {
        if ($value === null || $value === '') {
            return $default;
        }
        if (!in_array($value, $allowed, true)) {
            throw self::refuse($where, 'muss eines von ' . implode(', ', $allowed) . ' sein');
        }

        return $value;
    }

    /** A colour as #rrggbb; "" or null is "none". */
    public static function color(mixed $value, string $where): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_string($value) || preg_match('/^#[0-9a-fA-F]{6}$/', $value) !== 1) {
            throw self::refuse($where, 'muss eine Farbe wie #1f4e79 sein');
        }

        return strtolower($value);
    }

    /** @return array<mixed> */
    public static function list(mixed $value, string $where): array
    {
        if ($value === null) {
            return [];
        }
        if (!is_array($value) || !array_is_list($value)) {
            throw self::refuse($where, 'muss eine Liste sein');
        }

        return $value;
    }

    /** @return array<string, mixed> */
    public static function map(mixed $value, string $where): array
    {
        if ($value === null) {
            return [];
        }
        if (!is_array($value) || ($value !== [] && array_is_list($value))) {
            throw self::refuse($where, 'muss ein Objekt sein');
        }

        return $value;
    }

    public static function refuse(string $where, string $problem, int $statusCode = 400): PdfCreatorException
    {
        return new PdfCreatorException(trim($where . ' ' . $problem), $statusCode);
    }
}
