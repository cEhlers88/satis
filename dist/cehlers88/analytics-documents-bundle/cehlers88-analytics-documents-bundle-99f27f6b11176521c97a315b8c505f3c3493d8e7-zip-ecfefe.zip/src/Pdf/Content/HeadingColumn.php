<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf\Content;

/**
 * A heading in the accent colour of the document, optionally with a line below - the
 * sections of a CV, for example. It stays on the page of what follows it.
 */
final readonly class HeadingColumn extends Column
{
    /** pt per level */
    public const SIZES = [1 => 20, 2 => 14, 3 => 12];

    /** @param array<mixed>|string|null $commandDefinition commands that give the text instead */
    public function __construct(
        TextStyle                $style,
        public string            $text,
        public int               $level = 2,
        public bool              $rule = false,
        public array|string|null $commandDefinition = null,
    )
    {
        parent::__construct($style);
    }

    public function commands(): array|string|null
    {
        return $this->commandDefinition;
    }

    public function textLength(): int
    {
        return mb_strlen($this->text);
    }
}
