<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Content\DocumentContent;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Html\ContentHtml;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Html\LetterheadHtml;
use Cehlers88\AnalyticsDocumentsBundle\Pdf\Letterhead\LetterheadData;
use Dompdf\Canvas;
use Dompdf\Dompdf;
use Dompdf\FontMetrics;
use Dompdf\Frame;
use Dompdf\Options;

/**
 * Lays out the content of the PDF-Creator as A4 PDF (dompdf) - optionally on a letterhead,
 * whose header and footer repeat on every page.
 *
 * The fonts are the DejaVu family dompdf brings along: they cover umlauts and most other
 * characters, so no font has to be installed or cached.
 */
final class PdfCreator
{
    /** About 35 pages; dompdf needs several seconds for that already, and more grows with it. */
    public const MAX_TEXT_LENGTH = 100000;
    public const DEFAULT_FILE_NAME = 'dokument.pdf';

    /** The page without letterhead: margins in mm, font size in pt. */
    private const PLAIN_MARGINS = [20, 20, 20, 20];
    private const PLAIN_FONT_SIZE = 11;
    private const PAGE_NUMBER_FONT_SIZE = 8;
    private const MM_TO_PT = 72 / 25.4;
    private const A4_HEIGHT_PT = 841.89;

    /** @return string the PDF itself */
    public function fromText(string $text, string $title = '', ?LetterheadData $letterhead = null): string
    {
        if (!mb_check_encoding($text, 'UTF-8')) {
            throw new PdfCreatorException('Der Text ist kein gültiges UTF-8');
        }

        return $this->fromContent(DocumentContent::fromText(str_replace(["\r\n", "\r"], "\n", $text)), $title, $letterhead);
    }

    /** @return string the PDF itself */
    public function fromContent(DocumentContent $content, string $title = '', ?LetterheadData $letterhead = null): string
    {
        if ($content->isEmpty()) {
            throw new PdfCreatorException('Es gibt noch keinen Inhalt für das PDF');
        }
        if ($content->textLength() > self::MAX_TEXT_LENGTH) {
            throw new PdfCreatorException(sprintf('Der Text ist länger als %d Zeichen', self::MAX_TEXT_LENGTH), 413);
        }

        [$top, $right, $bottom, $left] = $letterhead === null
            ? self::PLAIN_MARGINS
            : [$letterhead->marginTop, $letterhead->marginRight, $letterhead->marginBottom, $letterhead->marginLeft];

        $dompdf = new Dompdf($this->options());
        $tooHigh = $this->watchRowHeights($dompdf, self::A4_HEIGHT_PT - ($top + $bottom) * self::MM_TO_PT);
        $dompdf->loadHtml($this->html($content, $title, $letterhead, [$top, $right, $bottom, $left]), 'UTF-8');
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        if ($tooHigh->rows !== []) {
            throw new PdfCreatorException(sprintf(
                'Zeile %s passt nicht auf eine Seite: Spalten nebeneinander können nicht auf der nächsten Seite weitergehen. '
                . 'Teile den Inhalt auf mehrere Zeilen auf oder setze langen Text in eine Zeile mit nur einer Spalte.',
                implode(', ', array_map(static fn(int $row): int => $row + 1, array_unique($tooHigh->rows)))
            ), 422);
        }
        if ($letterhead !== null && $letterhead->pageNumbers) {
            $this->addPageNumbers($dompdf, $letterhead);
        }
        if ($title !== '') {
            $dompdf->addInfo('Title', $title);
        }

        return (string)$dompdf->output();
    }

    /**
     * A file name that is safe in a Content-Disposition header and on every file system:
     * no directories, no control or reserved characters, always ending in ".pdf".
     */
    public static function fileName(string $wanted): string
    {
        $name = basename(str_replace('\\', '/', trim($wanted)));
        $name = (string)preg_replace('/[\x00-\x1F\x7F<>:"\/\\\\|?*]+/u', '', $name);
        $name = (string)preg_replace('/\.pdf$/i', '', trim($name, " ."));
        $name = mb_substr(trim($name), 0, 120);

        return $name === '' ? self::DEFAULT_FILE_NAME : $name . '.pdf';
    }

    private function options(): Options
    {
        // the content comes from the user: nothing is fetched, nothing is executed - images
        // are data urls and need neither
        return new Options([
            'isRemoteEnabled' => false,
            'isPhpEnabled' => false,
            'isJavascriptEnabled' => false,
            'defaultFont' => 'DejaVu Sans',
            'defaultPaperSize' => 'a4',
        ]);
    }

    /** @param array{int, int, int, int} $margins */
    private function html(DocumentContent $content, string $title, ?LetterheadData $letterhead, array $margins): string
    {
        $settings = $content->settings;
        $fontSize = $settings->fontSize ?? $letterhead?->fontSize ?? self::PLAIN_FONT_SIZE;

        return '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">'
            . '<title>' . htmlspecialchars($title, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</title>'
            . '<style>'
            . sprintf('@page { margin: %dmm %dmm %dmm %dmm; }', ...$margins)
            . sprintf(
                'body { font-family: "%s", sans-serif; font-size: %dpt; line-height: %s; color: %s; }',
                $settings->font(),
                $fontSize,
                $settings->lineHeight,
                $settings->color
            )
            . ContentHtml::css($content)
            . ($letterhead === null ? '' : LetterheadHtml::css($letterhead))
            . '</style></head><body>'
            . ($letterhead === null ? '' : LetterheadHtml::html($letterhead))
            . ContentHtml::body($content)
            . '</body></html>';
    }

    /**
     * Rows of columns side by side are table rows, which dompdf cannot continue on the next
     * page - what does not fit is cut off. Their heights are taken while dompdf lays them
     * out, so such a row is refused instead of silently losing text.
     */
    private function watchRowHeights(Dompdf $dompdf, float $pageContentHeight): object
    {
        $result = new class {
            /** @var list<int> */
            public array $rows = [];
        };
        $dompdf->setCallbacks([[
            'event' => 'end_frame',
            'f' => static function (Frame $frame) use ($result, $pageContentHeight): void {
                $node = $frame->get_node();
                if ($node instanceof \DOMElement && $node->hasAttribute(ContentHtml::ROW_ATTRIBUTE)
                    && $frame->get_border_box()[3] > $pageContentHeight + 1) {
                    $result->rows[] = (int)$node->getAttribute(ContentHtml::ROW_ATTRIBUTE);
                }
            },
        ]]);

        return $result;
    }

    /**
     * "Seite 1 von 3" at the bottom right of every page. dompdf knows the page count only
     * once everything is laid out, so the numbers are written onto the finished pages.
     */
    private function addPageNumbers(Dompdf $dompdf, LetterheadData $letterhead): void
    {
        $canvas = $dompdf->getCanvas();
        $rightEdge = $canvas->get_width() - $letterhead->marginRight * self::MM_TO_PT;
        $y = $canvas->get_height() - LetterheadHtml::footerEdge($letterhead) * self::MM_TO_PT - self::PAGE_NUMBER_FONT_SIZE;

        $canvas->page_script(static function (int $page, int $pages, Canvas $canvas, FontMetrics $fontMetrics) use ($rightEdge, $y): void {
            $font = $fontMetrics->getFont('DejaVu Sans');
            $text = sprintf('Seite %d von %d', $page, $pages);
            $width = $fontMetrics->getTextWidth($text, $font, self::PAGE_NUMBER_FONT_SIZE);
            $canvas->text($rightEdge - $width, $y, $text, $font, self::PAGE_NUMBER_FONT_SIZE, [0.2, 0.2, 0.2]);
        });
    }
}
