<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Pdf;

use Cehlers88\AnalyticsDocumentsBundle\Pdf\Exception\PdfCreatorException;

/**
 * Images of the PDF-Creator - logos of letterheads and images in the content - come as
 * data urls. They are checked to be images of an allowed type by their content, not by
 * what the url claims, and handed back with the type they really have. dompdf embeds
 * them without fetching anything.
 */
final class ImageDataUrl
{
    /** dompdf renders these reliably; SVG is left out on purpose - it is a document of its own. */
    public const TYPES = ['image/png', 'image/jpeg', 'image/gif'];

    /** @param string $what how the message names the image, e.g. "Das Logo" */
    public static function normalize(string $dataUrl, int $maxBytes, string $what): string
    {
        $invalid = sprintf('%s muss ein PNG-, JPEG- oder GIF-Bild sein', $what);
        if (preg_match('#^data:image/[a-z+.-]+;base64,([A-Za-z0-9+/=\s]+)$#', $dataUrl, $match) !== 1) {
            throw new PdfCreatorException($invalid);
        }
        // refused before decoding, so an oversized image never ends up in memory twice
        if (intdiv(strlen($match[1]), 4) * 3 > $maxBytes + 3) {
            throw self::tooLarge($what, $maxBytes);
        }
        $bytes = base64_decode($match[1], true);
        if ($bytes === false || $bytes === '') {
            throw new PdfCreatorException($invalid);
        }
        if (strlen($bytes) > $maxBytes) {
            throw self::tooLarge($what, $maxBytes);
        }
        $info = @getimagesizefromstring($bytes);
        if ($info === false || !in_array($info['mime'], self::TYPES, true)) {
            throw new PdfCreatorException($invalid);
        }

        return 'data:' . $info['mime'] . ';base64,' . base64_encode($bytes);
    }

    private static function tooLarge(string $what, int $maxBytes): PdfCreatorException
    {
        return new PdfCreatorException(sprintf('%s ist größer als %d KB', $what, intdiv($maxBytes, 1024)), 413);
    }
}
