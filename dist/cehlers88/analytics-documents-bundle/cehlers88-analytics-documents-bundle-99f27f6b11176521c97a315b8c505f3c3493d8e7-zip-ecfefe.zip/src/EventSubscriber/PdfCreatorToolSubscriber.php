<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\EventSubscriber;

use Cehlers88\AnalyticsCore\Event\Tool\CollectToolsEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

/**
 * Brings the PDF-Creator to the tools page of the dashboard - through the event of
 * AnalyticsCore, so no class of the application is known here.
 *
 * The tool is only offered once the application imports the bundle's controllers,
 * otherwise its button would have nothing to send the text to.
 */
final class PdfCreatorToolSubscriber implements EventSubscriberInterface
{
    private const ROUTE = 'analytics_documents_admin_api_pdf_create';

    private ?bool $routesImported = null;

    public function __construct(
        private readonly UrlGeneratorInterface $urlGenerator,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            CollectToolsEvent::class => 'onCollectTools',
        ];
    }

    public function onCollectTools(CollectToolsEvent $event): void
    {
        if (!$this->routesImported()) {
            return;
        }
        $event->addTool([
            'name' => 'pdfCreator',
            'title' => 'PDF-Creator',
            'description' => 'Briefe, Lebensläufe und andere Dokumente aus Text, Bildern und Tabellen setzen - mit Briefpapier, als Download oder in die Dokumente',
            'categories' => ['Workspace', 'Data'],
            'teaser' => 'teaser/pdfCreator.html.twig',
            'template' => 'pdfCreator.html.twig',
            'scripts' => ['script/pdfCreator.js.twig'],
            'styles' => ['style/pdfCreator.html.twig'],
            'routes' => ['analytics_documents_admin_api_pdf_'],
        ]);
    }

    private function routesImported(): bool
    {
        if ($this->routesImported === null) {
            try {
                $this->urlGenerator->generate(self::ROUTE);
                $this->routesImported = true;
            } catch (RouteNotFoundException) {
                $this->routesImported = false;
            }
        }

        return $this->routesImported;
    }
}
