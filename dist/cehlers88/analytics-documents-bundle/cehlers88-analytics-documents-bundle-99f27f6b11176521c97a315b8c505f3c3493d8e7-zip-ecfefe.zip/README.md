# AnalyticsDocumentsBundle

A Symfony bundle for document management within the Analytics platform. It provides entities, repositories, macros, and configuration for organizing and accessing documents in workspaces.

## Requirements

- PHP 8.4+
- Symfony 8.x
- `cehlers88/analytics-core` 1.x
- `phpoffice/phpspreadsheet` ^5.10 (Excel-Manipulator)
- `dompdf/dompdf` ^3.1 (PDF-Creator)
- Doctrine ORM

## Installation

Install the bundle via Composer using the custom Satis repository:

```bash
composer require cehlers88/analytics-documents-bundle
```

> **Note:** This package is served from the private Satis repository at `https://cehlers88.github.io/satis`. Ensure your `composer.json` includes this repository:
>
> ```json
> {
>   "repositories": [
>     {
>       "type": "composer",
>       "url": "https://cehlers88.github.io/satis"
>     }
>   ]
> }
> ```

### Registering the Bundle

If your application does not use Symfony Flex auto-discovery, register the bundle manually in `config/bundles.php`:

```php
return [
    // ...
    Cehlers88\AnalyticsDocumentsBundle\AnalyticsDocumentsBundle::class => ['all' => true],
];
```

### Database Migrations

After installation, generate and run the Doctrine migrations to create the required database tables:

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

Or use the schema update command (not recommended for production):

```bash
php bin/console doctrine:schema:update --force
```

## Overview

The bundle integrates with `cehlers88/analytics-core` and registers itself as a bundle plugin (`AbstractBundlePlugin`). It provides:

| Feature | Description |
|---|---|
| **Entities** | `Document`, `Workspace`, `Letterhead` and `PdfTemplate` Doctrine ORM entities |
| **Repositories** | `DocumentRepository` and `WorkspaceRepository` for querying the database |
| **Macros** | Automation macros for retrieving, setting, and merging document data |
| **Configuration** | A configuration group for defining workspace paths and aliases |
| **Permissions** | An `ACCESS_DOCUMENTS` permission to control bundle access |
| **Menu Item** | Registers a "Dokumentverwaltung" (Document Management) entry in the Analytics menu |
| **Excel-Manipulator** | A dashboard tool to open, edit, create and export XLSX, XLS, ODS and CSV files (see below) |
| **PDF-Creator** | A dashboard tool that sets letters, CVs and other documents as PDF - with commands, inheritable letterheads, templates, preview, download and saving into the documents (see below) |

## Entities

### Document

Represents a file registered in the system.

| Property | Type | Description |
|---|---|---|
| `id` | `int` | Auto-generated primary key |
| `name` | `string` | Human-readable name of the document |
| `path` | `string` | Relative file path within the workspace |
| `attributes` | `array` | Arbitrary key-value metadata stored as JSON |
| `registeredAt` | `DateTimeImmutable` | Timestamp when the document was registered |
| `categories` | `Collection<Category>` | Many-to-many relation to Analytics `Category` entities |
| `documentRootId` | `?string` | The workspace: id of an entry of the configured `documentRoots` |
| `workspace` | `Workspace` | Many-to-one relation to a `Workspace` entity - not used by the upload endpoint |

The path never leaves the workspace. `WorkspaceStorage` resolves the full path of the file:

```php
$fullPath = $workspaceStorage->absolutePathOf($document);
```

### Workspace

Represents a container that groups documents under a shared root path.

| Property | Type | Description |
|---|---|---|
| `id` | `int` | Auto-generated primary key |
| `name` | `string` | Human-readable workspace name |
| `path` | `string` | Filesystem root path of this workspace |

The upload endpoint does not use this entity: its workspaces are the configured `documentRoots`
(see [Configuration](#configuration)).
| `documents` | `Collection<Document>` | One-to-many relation to its `Document` entities |

## Repositories

Both repositories extend Symfony's `ServiceEntityRepository` and are auto-wired via Doctrine's `ManagerRegistry`.

### DocumentRepository

```php
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;

// Find a document by ID
$document = $documentRepository->find($id);

// Find all documents
$documents = $documentRepository->findAll();

// Use standard Doctrine criteria
$documents = $documentRepository->findBy(['workspace' => $workspace]);
```

### WorkspaceRepository

```php
use Cehlers88\AnalyticsDocumentsBundle\Repository\WorkspaceRepository;

// Find a workspace by ID
$workspace = $workspaceRepository->find($id);

// Find a workspace by name
$workspace = $workspaceRepository->findOneBy(['name' => 'My Workspace']);
```

## Macros

Macros are automation components tagged with `macro` in the service container. They extend `AbstractDocumentMacro` which sets the macro source to `"DocumentsBundle"`.

### GetDocumentInfosMacro

**Name:** `getDocumentInfos`

Retrieves metadata for a document by its ID.

| Property | Type | Default | Description |
|---|---|---|---|
| `fileId` | `int` | `-1` | ID of the document to retrieve |

**Output:**

| Key | Type | Description |
|---|---|---|
| `name` | `string` | Document name |
| `path` | `string` | Full path (workspace path + document path) |
| `attributes` | `array` | Document attributes |
| `categories` | `Collection` | Associated categories |

### SetDocumentInfosMacro

**Name:** `setDocumentInfos`

Sets or creates document metadata. *(Work in progress)*

| Property | Type | Default | Description |
|---|---|---|---|
| `fileId` | `int` | `-1` | ID of an existing document, or `-1` to create a new one |
| `fullPath` | `string` | `-1` | Full filesystem path of the document |
| `workspaceId` | `int` | `-1` | ID of the target workspace |

### MergeDocumentsMacro

**Name:** `mergeDocuments`

Merges document data. *(Work in progress)*

| Property | Type | Default | Description |
|---|---|---|---|
| `fileId` | `int` | `-1` | ID of the source document |
| `fullPath` | `string` | `-1` | Full filesystem path |
| `workspaceId` | `int` | `-1` | ID of the target workspace |

## Upload endpoint

`POST /api/se/AnalyticsDocumentsBundle.upload` (`DocumentUploadEndpointRunner`) stores a file in a
workspace and answers with the id of the `Document` it created:
`{"hasError": false, "statusCode": 200, "message": "Document created", "data": 42}`.
The caller needs the role `ACCESS_DOCUMENTS` (administrators always pass).

The file comes in one of two ways:

```bash
# as a form sends it (multipart/form-data) - the file keeps its name unless "name" is given
curl -H "Authorization: Bearer $JWT" \
     -F workspaceId=69d5b2a1c4e0f -F path=invoices/2026 -F file=@invoice.pdf \
     https://…/api/se/AnalyticsDocumentsBundle.upload

# base64 encoded (json or form); a data url (data:application/pdf;base64,…) works too
curl -H "Authorization: Bearer $JWT" -H "Content-Type: application/json" \
     -d '{"workspaceId": "69d5b2a1c4e0f", "path": "invoices/2026", "name": "invoice.pdf", "content": "JVBERi0xLjQ…"}' \
     https://…/api/se/AnalyticsDocumentsBundle.upload
```

| Parameter | Required | Description |
|---|---|---|
| `workspaceId` | yes | Id of the workspace - an entry of the configured `documentRoots` |
| `file` | one of both | The file as field of a multipart form |
| `content` | one of both | The file base64 encoded |
| `name` | with `content` | File name incl. extension; defaults to the name of `file` |
| `path` | no | Directory below the workspace, created if missing; `..` and absolute paths are refused |
| `mimeType` | no | Mime type of `content`; detected from the data otherwise |
| `overwrite` | no | `true` replaces an existing file and updates its document instead of answering 409 |
| `attributes` | no | Further attributes of the document (object, or json text in a form) |

The document gets the file name as `name`, the path relative to the workspace (file name included)
as `path`, the workspace id as `documentRootId`, and `attributes.file` with `originalName`,
`mimeType`, `size` and `sha256`.
Refused uploads answer with `hasError: true` and a `statusCode` of 400 (bad input), 404 (unknown
workspace), 409 (file exists), 413 (too large) or 500 (storage problem).

`analytics_documents.upload.max_file_size` limits the size (default 50 MB); PHP (`upload_max_filesize`,
`post_max_size`) and the web server in front have to allow it as well.

## Excel-Manipulator

A tool for `/dashboard/tools` that reads and writes spreadsheets with PhpSpreadsheet.
The bundle brings all of it; the application lists the tool in its tools page and
imports the bundle's templates and controllers:

```yaml
# config/packages/twig.yaml
twig:
  paths:
    'vendor/cehlers88/analytics-documents-bundle/templates': ~

# config/routes/analytics_documents.yaml
analytics_documents_bundle:
  resource: '@AnalyticsDocumentsBundle/Controller/'
  type: attribute
```

| Part | Where |
|---|---|
| Mask and styles | `templates/tool/excelManipulator.html.twig` |
| Script | `templates/tool/script/excelManipulator.js.twig` |
| Tile illustration | `templates/tool/teaser/excelManipulator.html.twig` |
| JSON backend | `Controller/SpreadsheetToolController` under `/admin_api/documents/spreadsheets` (`ROLE_DASHBOARD` or `ROLE_ADMIN`, CSRF token `excel_manipulator` in `X-CSRF-Token`) |
| Working copies and undo | `Spreadsheet/SpreadsheetStorage` - `{directory}/{userId}/{workbookId}/` |
| Reading and writing | `Spreadsheet/SpreadsheetIo` - XLSX, XLSM, XLS, ODS, CSV in; XLSX, XLS, ODS, CSV, JSON out |
| Grid data, column statistics | `Spreadsheet/SpreadsheetInspector` |
| Changes | `Spreadsheet/Operation/*Operation`, applied by `SpreadsheetOperationRunner` |

The mask is a grid: the ribbon over the whole width, below it the list of workbooks on
the left and the workbook on the right - both take the height of the window (`tool-fill`)
and scroll in themselves, so the list stays where it is while one works in the workbook.
Under 900px the list moves above the workbook.

What the tool does - the grid, the panels, undo, import and export - is described in
the application's `docs/dashboard-tools.md`.

### Operations

Every change is an operation `{"type": "…", …arguments}` sent to
`POST /admin_api/documents/spreadsheets/{id}/operations`. A list is applied all or
nothing and is one undo step.

| Type | Arguments |
|---|---|
| `setCells` | `sheet`, `cells: [{cell, value}]` - values read like typed text (`=` formula, `'` text, ISO dates) |
| `clearRange` | `sheet`, `range`, `what: contents\|formats\|all` |
| `insertRows` / `deleteRows` | `sheet`, `row`, `count` |
| `insertColumns` / `deleteColumns` | `sheet`, `column`, `count` |
| `addSheet` / `renameSheet` / `duplicateSheet` / `moveSheet` / `deleteSheet` | `sheet`, `title`, `index` |
| `sort` | `sheet`, `range`, `headerRow`, `keys: [{column, direction}]` (up to 3) |
| `removeDuplicates` | `sheet`, `range`, `headerRow`, `columns`, `ignoreCase` |
| `findReplace` | `sheet`, `allSheets`, `range`, `search`, `replace`, `matchCase`, `wholeCell`, `regex`, `inFormulas` |
| `cleanText` | `sheet`, `range`, `trim`, `collapseSpaces`, `removeLineBreaks`, `case` |
| `convertText` | `sheet`, `range`, `numbers`, `dates`, `decimalSeparator`, `thousandsSeparator` |
| `splitColumn` | `sheet`, `column`, `delimiter`, `headerRow`, `maxParts` |
| `style` | `sheet`, `range`, `bold`, `italic`, `underline`, `strike`, `fontSize`, `color`, `fill`, `numberFormat`, `align`, `verticalAlign`, `wrap`, `borders` |
| `mergeCells` | `sheet`, `range`, `merge` |
| `freezePane` | `sheet`, `cell` (none releases) |
| `autoFilter` | `sheet`, `range`, `remove` |
| `autoSizeColumns` | `sheet`, `range`, `width` (none fits to content) |

A range is `A1:C5`, `B2`, `A:C` or `2:4`; without one the used range of the sheet is
taken. A new operation is a class implementing
`Spreadsheet\Operation\SpreadsheetOperationInterface` - the tag
`analytics_documents.spreadsheet_operation` is set by `services.yaml`.

### Parameters

| Parameter | Default |
|---|---|
| `analytics_documents.spreadsheet.directory` | `%kernel.project_dir%/var/spreadsheets` |
| `analytics_documents.spreadsheet.max_file_size` | `20971520` (20 MB) |
| `analytics_documents.spreadsheet.max_cells` | `1000000`, and never more than `memory_limit` holds (about 1.2 KB per cell) |
| `analytics_documents.spreadsheet.max_workbooks` | `30` per user |
| `analytics_documents.spreadsheet.undo_steps` | `20` per workbook |
| `analytics_documents.spreadsheet.retention_days` | `30` |

### Tests

```bash
vendor/bin/phpunit
```

The tests need the dependencies of the application (Doctrine, HttpFoundation); from a checkout next to
`analytics.c-ehlers.de` they run with its autoloader plus the test namespace of this bundle.

## PDF-Creator

A tool for `/dashboard/tools` that sets documents - letters, CVs, lists - as A4 PDF: rows of
one to four columns, each column text, a heading, an image or a table, fixed or resolved from
commands; on a letterhead (letterheads can build on each other) or without; from templates;
with a live preview, as download or saved into a workspace as `Document`.
`EventSubscriber/PdfCreatorToolSubscriber` adds it to the tools page through
`CollectToolsEvent` of AnalyticsCore as soon as the bundle's controllers are imported (same
`twig.yaml` path and route import as above). What the tool does for its users is described in
the application's `docs/dashboard-tools.md`; it needs from the application `<ribbon-menu>` with
the `ribbon-tab` event, `<tool-modal>` with `statusInfo()` (the `tool-status-info` event),
`<pdf-view>` for the preview and `<commands-holder>` for the commands.

| Part | Where |
|---|---|
| Mask, styles, script, tile | `templates/tool/pdfCreator.html.twig`, `style/`, `script/`, `teaser/pdfCreator.*.twig` - colours only as palette tokens of the application |
| Controllers | `Controller/PdfCreatorController` (create, preview, targets, save), `PdfLetterheadController`, `PdfTemplateController` - all under `/admin_api/documents/pdf`, routes `analytics_documents_admin_api_pdf_*`, sharing `AbstractPdfCreatorController` (`ROLE_DASHBOARD`/`ROLE_ADMIN`, CSRF token `pdf_creator`; saving into the documents also `ACCESS_DOCUMENTS`) |
| Content | `Pdf/Content/DocumentContent` - `ContentSettings`, `ContentRow`, the columns `TextColumn`, `HeadingColumn`, `ImageColumn`, `TableColumn`, each with a `TextStyle`; `fromArray()` checks everything the browser sends, command definitions included |
| Commands | `Pdf/Command/CommandResolver` (runs the entries of a field through the `CommandPlayer`, for application 1), `ContentCommandResolver` (a content with commands → one of plain text) |
| Letterheads | `Entity/Letterhead` (table `document_letterhead`: name, parent, json definition) · `Pdf/Letterhead/LetterheadDefinition` (per field: inherit, replace, append, prepend) · `LetterheadResolver` (chain → effective `LetterheadData`) |
| Templates | `Pdf/Content/ContentTemplates` (built in: tabular CV, letter) and `Entity/PdfTemplate` (table `document_pdf_template`) |
| HTML and rendering | `Pdf/Html/ContentHtml`, `LetterheadHtml`, `InlineText` (`**bold**`, `*italic*`, `__underlined__`, `- ` lists) · `Pdf/PdfCreator` - dompdf, DejaVu fonts, remote resources and PHP switched off; refuses rows of columns side by side that do not fit on a page (422) |
| Images | `Pdf/ImageDataUrl` - PNG, JPEG, GIF as data url, checked by their content |

### Content

```json
{"settings": {"fontFamily": "serif", "fontSize": 10, "lineHeight": 1.35, "color": "#000000", "accentColor": "#1f4e79", "rowSpacing": 3},
 "rows": [
   {"columns": [{"type": "heading", "text": "Berufserfahrung", "level": 2, "rule": true}]},
   {"widths": [1, 3], "gap": 6, "spaceAfter": 3, "pageBreakBefore": false, "columns": [
     {"type": "text", "text": "04/2021 – heute", "style": {"color": "#555555"}},
     {"type": "text", "source": "commands", "commands": ["**Entwickler**, ", ["get_var", {"name": "company"}]]}]},
   {"columns": [{"type": "table", "cells": [["Sprache", "Niveau"], ["Englisch", "C1"]], "headerRow": true, "columnWidths": [1, 2]}]},
   {"columns": [{"type": "image", "src": "data:image/jpeg;base64,…", "width": 40, "style": {"align": "right"}}]}]}
```

`source: "commands"` takes the content from `commands` - what `<commands-holder>` gives: a
command `["name", {…}]` or a list of text entries and commands, resolved one by one and put
together (`\n` in a text entry is a line break); a table takes the rows, records or object
its commands answer with. `style` of a column: `align` (`left`, `center`, `right`,
`justify`), `bold`, `italic`, `underline`, `fontSize` (pt), `color` (`#rrggbb`),
`verticalAlign`. A row of one column continues over the pages; columns side by side have to
fit on one page. Limits: 100 000 characters, 300 rows, 4 columns per row, 20 images of 2 MB,
tables of 12 columns and 10 000 cells, command definitions of 64 KB.

### Letterheads

```json
{"name": "Konzern · Einkauf", "parentId": 1, "definition": {
  "headerText": {"mode": "append", "source": "text", "value": "Abteilung Einkauf"},
  "footerText": {"mode": "replace", "source": "commands", "commands": ["get_var", {"name": "footer"}]},
  "marginTop": {"mode": "inherit"}}}
```

Fields: `headerText`, `headerAlign`, `logo`, `logoPosition`, `logoWidth`, `footerText`,
`footerAlign`, `pageNumbers`, `marginTop`, `marginBottom`, `marginLeft`, `marginRight`,
`fontSize` (`LetterheadData::FIELDS`). Without `parentId` every field is `replace`. The chain
is resolved from the root (at most 10 levels); a circle is refused, as is deleting a letterhead
others are based on (409).

### Endpoints

| Method | Path | |
|---|---|---|
| `POST` | `/create` | `content` (or plain `text`), `fileName`, `letterheadId` - the PDF as attachment |
| `POST` | `/preview` | as create, inline; or `letterhead` (not stored) with a sample letter |
| `GET` | `/targets` | workspaces (`documentRoots`) and `canSave` |
| `POST` | `/save` | as create plus `workspaceId`, `path`, `overwrite` - `DocumentUploader`, 409 if the file exists |
| `GET`, `POST` | `/letterheads` | list, create |
| `GET`, `PUT`, `DELETE` | `/letterheads/{id}` | one letterhead, with `inherited` (what its base hands down) |
| `GET` | `/letterheads/{id}/inherited` | what a letterhead hands down |
| `GET`, `POST` | `/templates` | list (key `builtin-<name>` or id), save (`replaceKey` replaces) |
| `GET`, `DELETE` | `/templates/{key}` | one template with its content, delete a saved one |

Refusals answer with a `ResultDTO` and a German message: 400 (bad input), 403 (token,
permission, built-in template), 404 (letterhead, template, workspace), 409 (file exists,
letterhead is a base), 413 (too large), 422 (a row does not fit on a page, a command failed or
does not exist).

## Configuration

The bundle provides the `GeneralConfigurationGroup` which registers under the key `documentsBundle.general` in the Analytics configuration UI.

| Key | Type | Default | Description |
|---|---|---|---|
| `workspaceRoot` | Text | *(empty)* | Filesystem root path shared by all workspaces |
| `workspaceRootAliases` | Repeatable | *(empty)* | Alternative aliases for the workspace root path |
| `documentRoots` | Repeatable | *(empty)* | The workspaces (see below) - the upload endpoint stores files in them |

Each entry in `documentRoots` supports:

| Key | Type | Default | Description |
|---|---|---|---|
| `id` | Unique ID | *(auto)* | Unique identifier for the workspace definition |
| `name` | Text | `Workspace name` | Display name |
| `description` | Multi-line Text | *(empty)* | Optional description |
| `path` | Text | `/var/workspace` | Root directory of the workspace - absolute, or relative to `workspaceRoot`. It has to exist |

`DocumentRootProvider` reads them, `WorkspaceStorage` resolves their directories.

## Permissions

The bundle defines the following permission via `EPermission`:

| Permission | Value | Description |
|---|---|---|
| `ACCESS_DOCUMENTS` | `ACCESS_DOCUMENTS` | Grants access to the document management module |

Permissions are automatically registered with the Analytics core when the bundle is loaded.

## Services

All bundle services are auto-wired and auto-configured. The `services.yaml` configuration:

- Auto-wires all classes in the bundle namespace
- **Excludes** entity classes from the service container
- Tags all `Macro\*` classes with the `macro` tag
- Tags all `Configuration\*` classes with the `analytics.configuration` tag

## License

MIT License — Copyright (c) 2024 Christoph Ehlers. See [LICENSE](LICENSE) for details.

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a history of releases and changes.
