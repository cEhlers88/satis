<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 20:37
 */

namespace Cehlers88\AnalyticsDocumentsBundle\Configuration;

use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;

class GeneralConfigurationGroup extends AbstractConfigurationGroup
{
    public function getItems(): array
    {
        return [
            ConfigurationItemDTO::create('workspaceRoot', 'Workspace Root', eInputType::TEXT_SINGLE_LINE, ''),
            ConfigurationItemDTO::createRepeat('workspaceRootAliases', 'Workspaces Root aliases', [
                ConfigurationItemDTO::create('alias', 'Alias', eInputType::TEXT_SINGLE_LINE, ''),
            ]),
            ConfigurationItemDTO::createRepeat('documentRoots', 'Workspaces', [
                ConfigurationItemDTO::create('id', 'ID', eInputType::UNIQUE_ID),
                ConfigurationItemDTO::create('name', 'Name', eInputType::TEXT_SINGLE_LINE, 'Workspace name'),
                ConfigurationItemDTO::create('description', 'Description', eInputType::TEXT_MULTI_LINE),
                ConfigurationItemDTO::create('path', 'Path', eInputType::TEXT_SINGLE_LINE, '/var/workspace')
            ], 'Here you can define the workspaces for the documents')
        ];
    }

    public function getGroupTitle(): string
    {
        return 'Allgemeine Dokumenteneinstellungen';
    }

    public function getGroupDescription(): string
    {
        return 'Allgemeine Einstellungen für das Dokumentenmodul';
    }

    public function getKey(): string
    {
        return 'documentsBundle.general';
    }
}