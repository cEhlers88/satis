<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Controller;

use Cehlers88\AnalyticsCore\DTO\ResultDTO;
use Cehlers88\AnalyticsDocumentsBundle\ENUM\EPermission;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRoot;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRootProvider;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceBrowser;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceConfiguration;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceInspector;
use Cehlers88\AnalyticsDocumentsBundle\Upload\DocumentUploader;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use Cehlers88\AnalyticsDocumentsBundle\Upload\UploadSource;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Core\Role\RoleHierarchyInterface;

/**
 * Workspace-Management: a file browser over the configured workspaces ("documentRoots",
 * GeneralConfigurationGroup) - each an independent drive with its own directories and files.
 *
 * The page (/dashboard/documents/workspaces) is what the bundle offers as menu entry
 * (AnalyticsDocumentsBundle::getMenuItems()); everything it shows and changes goes through
 * the JSON routes below /admin_api/documents/workspaces. Both need ROLE_ADMIN or the
 * permission ACCESS_DOCUMENTS, every writing request also the CSRF token "workspace_management"
 * in X-CSRF-Token. Administrators (ROLE_ADMIN) also see everything about the workspaces and
 * create, change and remove them (the "settings" routes).
 */
final class WorkspaceManagementController extends AbstractController
{
    public const PAGE_ROUTE = 'analytics_documents_workspaces';
    public const CSRF_TOKEN_ID = 'workspace_management';
    public const CSRF_HEADER = 'X-CSRF-Token';
    private const WORKSPACE_ID = '[A-Za-z0-9_.-]+';
    /** What a browser may show in place - nothing that could run script on this origin. */
    private const INLINE_TYPES = ['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'application/pdf', 'text/plain'];

    public function __construct(
        private readonly DocumentRootProvider    $documentRootProvider,
        private readonly WorkspaceBrowser        $browser,
        private readonly DocumentUploader        $uploader,
        private readonly WorkspaceInspector      $inspector,
        private readonly WorkspaceConfiguration  $configuration,
        private readonly ?RoleHierarchyInterface $roleHierarchy = null,
    )
    {
    }

    #[Route('/dashboard/documents/workspaces', name: self::PAGE_ROUTE, methods: ['GET'])]
    public function page(): Response
    {
        $this->checkAccess();

        return $this->render('documents/workspaces.html.twig', [
            'workspaces' => $this->describeWorkspaces(),
            'maxFileSize' => $this->uploader->getMaxFileSize(),
            'isAdmin' => $this->isGranted('ROLE_ADMIN'),
        ]);
    }

    /** Everything about the workspaces - WorkspaceInspector. Administrators only. */
    #[Route('/admin_api/documents/workspaces/settings', name: 'analytics_documents_admin_api_workspaces_settings', methods: ['GET'])]
    public function settings(): Response
    {
        return $this->handle(function (): Response {
            $this->denyAccessUnlessGranted('ROLE_ADMIN');

            return $this->success('Workspaces', $this->inspector->inspect());
        });
    }

    /** Creates a workspace (without id) or changes one. Administrators only. */
    #[Route('/admin_api/documents/workspaces/settings', name: 'analytics_documents_admin_api_workspaces_settings_save', methods: ['POST'])]
    public function saveWorkspace(Request $request): Response
    {
        return $this->handle(function () use ($request): Response {
            $this->denyAccessUnlessGranted('ROLE_ADMIN');
            $this->checkCsrfToken($request);
            $input = $this->readInput($request);
            $id = trim((string)($input['id'] ?? ''));
            $workspace = $this->configuration->save(
                $id === '' ? null : $id,
                (string)($input['name'] ?? ''),
                (string)($input['description'] ?? ''),
                (string)($input['path'] ?? ''),
                filter_var($input['createDirectory'] ?? false, FILTER_VALIDATE_BOOL)
            );

            return $this->success($id === '' ? 'Workspace angelegt' : 'Workspace gespeichert', ['id' => $workspace->id], $id === '' ? 201 : 200);
        });
    }

    /** Removes a workspace from the configuration - its files stay. Administrators only. */
    #[Route('/admin_api/documents/workspaces/settings/{workspaceId}/delete', name: 'analytics_documents_admin_api_workspaces_settings_delete', requirements: ['workspaceId' => self::WORKSPACE_ID], methods: ['POST'])]
    public function removeWorkspace(string $workspaceId, Request $request): Response
    {
        return $this->handle(function () use ($workspaceId, $request): Response {
            $this->denyAccessUnlessGranted('ROLE_ADMIN');
            $this->checkCsrfToken($request);
            $this->configuration->remove($workspaceId);

            return $this->success('Workspace entfernt');
        });
    }

    #[Route('/admin_api/documents/workspaces', name: 'analytics_documents_admin_api_workspaces_list', methods: ['GET'])]
    public function workspaces(): Response
    {
        return $this->handle(function (): Response {
            $this->checkAccess();

            return $this->success('Workspaces', ['workspaces' => $this->describeWorkspaces()]);
        });
    }

    #[Route('/admin_api/documents/workspaces/{workspaceId}/entries', name: 'analytics_documents_admin_api_workspaces_entries', requirements: ['workspaceId' => self::WORKSPACE_ID], methods: ['GET'])]
    public function entries(string $workspaceId, Request $request): Response
    {
        return $this->handle(function () use ($workspaceId, $request): Response {
            $this->checkAccess();
            $workspace = $this->findWorkspace($workspaceId);
            $path = (string)$request->query->get('path', '');

            // links that lead out of the workspace only for administrators - they can make a
            // workspace of the target, everybody else could do nothing with them
            $isAdmin = $this->isGranted('ROLE_ADMIN');
            $entries = $this->browser->list($workspace, $path, $isAdmin);
            if ($isAdmin) {
                $others = array_values(array_filter(
                    $this->documentRootProvider->all(),
                    static fn(DocumentRoot $other): bool => $other->id !== $workspace->id
                ));
                foreach ($entries as $index => $entry) {
                    if ($entry['type'] === 'external' && $entry['targetType'] === 'directory') {
                        $match = $this->browser->workspaceContaining($entry['target'], $others);
                        $entries[$index]['targetWorkspace'] = $match === null ? null
                            : ['id' => $match['workspace']->id, 'name' => $match['workspace']->name, 'path' => $match['path']];
                    }
                }
            }

            return $this->success('Entries', [
                'workspace' => $workspace->id,
                'path' => trim(str_replace('\\', '/', $path), '/'),
                'entries' => $entries,
            ]);
        });
    }

    #[Route('/admin_api/documents/workspaces/{workspaceId}/directories', name: 'analytics_documents_admin_api_workspaces_mkdir', requirements: ['workspaceId' => self::WORKSPACE_ID], methods: ['POST'])]
    public function createDirectory(string $workspaceId, Request $request): Response
    {
        return $this->handle(function () use ($workspaceId, $request): Response {
            $this->checkCsrfToken($request);
            $input = $this->readInput($request);
            $path = $this->browser->createDirectory(
                $this->findWorkspace($workspaceId),
                (string)($input['path'] ?? ''),
                (string)($input['name'] ?? '')
            );

            return $this->success('Verzeichnis angelegt', ['path' => $path], 201);
        });
    }

    #[Route('/admin_api/documents/workspaces/{workspaceId}/rename', name: 'analytics_documents_admin_api_workspaces_rename', requirements: ['workspaceId' => self::WORKSPACE_ID], methods: ['POST'])]
    public function rename(string $workspaceId, Request $request): Response
    {
        return $this->handle(function () use ($workspaceId, $request): Response {
            $this->checkCsrfToken($request);
            $input = $this->readInput($request);
            $path = $this->browser->rename(
                $this->findWorkspace($workspaceId),
                (string)($input['path'] ?? ''),
                (string)($input['name'] ?? '')
            );

            return $this->success('Umbenannt', ['path' => $path]);
        });
    }

    #[Route('/admin_api/documents/workspaces/{workspaceId}/move', name: 'analytics_documents_admin_api_workspaces_move', requirements: ['workspaceId' => self::WORKSPACE_ID], methods: ['POST'])]
    public function move(string $workspaceId, Request $request): Response
    {
        return $this->handle(function () use ($workspaceId, $request): Response {
            $this->checkCsrfToken($request);
            $input = $this->readInput($request);
            $path = $this->browser->move(
                $this->findWorkspace($workspaceId),
                (string)($input['path'] ?? ''),
                (string)($input['target'] ?? '')
            );

            return $this->success('Verschoben', ['path' => $path]);
        });
    }

    #[Route('/admin_api/documents/workspaces/{workspaceId}/delete', name: 'analytics_documents_admin_api_workspaces_delete', requirements: ['workspaceId' => self::WORKSPACE_ID], methods: ['POST'])]
    public function delete(string $workspaceId, Request $request): Response
    {
        return $this->handle(function () use ($workspaceId, $request): Response {
            $this->checkCsrfToken($request);
            $input = $this->readInput($request);
            $documents = $this->browser->delete(
                $this->findWorkspace($workspaceId),
                (string)($input['path'] ?? ''),
                filter_var($input['recursive'] ?? false, FILTER_VALIDATE_BOOL)
            );

            return $this->success('Gelöscht', ['removedDocuments' => $documents]);
        });
    }

    /**
     * One or more files of a form (field "files[]" or "file") into a directory of the
     * workspace; each is registered as Document, as with the upload endpoint.
     */
    #[Route('/admin_api/documents/workspaces/{workspaceId}/upload', name: 'analytics_documents_admin_api_workspaces_upload', requirements: ['workspaceId' => self::WORKSPACE_ID], methods: ['POST'])]
    public function upload(string $workspaceId, Request $request): Response
    {
        return $this->handle(function () use ($workspaceId, $request): Response {
            $this->checkCsrfToken($request);
            $workspace = $this->findWorkspace($workspaceId);
            $directory = (string)$request->request->get('path', '');
            $overwrite = filter_var($request->request->get('overwrite', false), FILTER_VALIDATE_BOOL);

            $files = $request->files->all('files');
            if ($request->files->get('file') instanceof UploadedFile) {
                $files[] = $request->files->get('file');
            }
            $files = array_values(array_filter($files, static fn(mixed $file): bool => $file instanceof UploadedFile));
            if ($files === []) {
                throw DocumentUploadException::badRequest('Keine Datei empfangen - vielleicht ist sie größer, als der Server annimmt');
            }

            $stored = [];
            foreach ($files as $file) {
                $result = $this->uploader->upload(
                    $workspace,
                    UploadSource::fromUploadedFile($file, $this->uploader->getMaxFileSize()),
                    $directory,
                    $file->getClientOriginalName(),
                    $overwrite
                );
                $stored[] = [
                    'path' => $result->document->getPath(),
                    'documentId' => $result->document->getId(),
                    'replaced' => $result->replaced,
                ];
            }

            return $this->success(count($stored) === 1 ? 'Datei hochgeladen' : sprintf('%d Dateien hochgeladen', count($stored)), ['files' => $stored], 201);
        });
    }

    #[Route('/admin_api/documents/workspaces/{workspaceId}/download', name: 'analytics_documents_admin_api_workspaces_download', requirements: ['workspaceId' => self::WORKSPACE_ID], methods: ['GET'])]
    public function download(string $workspaceId, Request $request): Response
    {
        return $this->handle(function () use ($workspaceId, $request): Response {
            $this->checkAccess();
            $file = $this->browser->fileOf($this->findWorkspace($workspaceId), (string)$request->query->get('path', ''));

            $response = new BinaryFileResponse($file);
            $inline = $request->query->getBoolean('inline') && in_array($response->getFile()->getMimeType(), self::INLINE_TYPES, true);
            $response->setContentDisposition(
                $inline ? ResponseHeaderBag::DISPOSITION_INLINE : ResponseHeaderBag::DISPOSITION_ATTACHMENT,
                basename($file),
                self::asciiFallback(basename($file))
            );
            $response->headers->set('X-Content-Type-Options', 'nosniff');
            $response->headers->set('Content-Security-Policy', "sandbox; default-src 'none'; img-src 'self'; style-src 'unsafe-inline'");

            return $response;
        });
    }

    /** @return list<array{id: string, name: string, description: string, available: bool}> */
    private function describeWorkspaces(): array
    {
        return array_map(fn(DocumentRoot $workspace): array => [
            'id' => $workspace->id,
            'name' => $workspace->name,
            'description' => $workspace->description,
            'available' => $this->browser->isAvailable($workspace),
        ], $this->documentRootProvider->all());
    }

    private function findWorkspace(string $id): DocumentRoot
    {
        return $this->documentRootProvider->find($id)
            ?? throw DocumentUploadException::notFound('Diesen Workspace gibt es nicht (mehr)');
    }

    /** @param callable(): Response $action */
    private function handle(callable $action): Response
    {
        try {
            return $action();
        } catch (DocumentUploadException $exception) {
            $status = $exception->getCode() >= 400 && $exception->getCode() < 600 ? $exception->getCode() : 500;

            return $this->json(ResultDTO::createError($exception->getMessage(), $status), $status);
        }
    }

    /**
     * ROLE_ADMIN, or the permission of the bundle. That one is no ROLE_*, so no voter knows
     * it - it is looked up in the roles of the user, those of the role hierarchy included.
     */
    private function checkAccess(): void
    {
        if ($this->isGranted('ROLE_ADMIN')) {
            return;
        }
        $user = $this->getUser();
        $roles = $user === null ? [] : $user->getRoles();
        if ($this->roleHierarchy !== null) {
            $roles = $this->roleHierarchy->getReachableRoleNames($roles);
        }
        if (!in_array(EPermission::ACCESS_DOCUMENTS->value, $roles, true)) {
            throw $this->createAccessDeniedException();
        }
    }

    private function checkCsrfToken(Request $request): void
    {
        $this->checkAccess();
        $token = $request->headers->get(self::CSRF_HEADER);
        if (!is_string($token) || $token === '' || !$this->isCsrfTokenValid(self::CSRF_TOKEN_ID, $token)) {
            throw new DocumentUploadException('Ungültiges CSRF-Token - bitte die Seite neu laden', 403);
        }
    }

    /** @return array<string, mixed> */
    private function readInput(Request $request): array
    {
        if ($request->getContentTypeFormat() !== 'json') {
            return $request->request->all();
        }
        $data = json_decode($request->getContent(), true);
        if (!is_array($data)) {
            throw DocumentUploadException::badRequest('Die Anfrage ist kein gültiges JSON');
        }

        return $data;
    }

    private function success(string $message, mixed $data = [], int $statusCode = 200): Response
    {
        return $this->json(ResultDTO::createSuccess($message, $data, $statusCode), $statusCode);
    }

    private static function asciiFallback(string $name): string
    {
        $fallback = preg_replace('/[^\x20-\x7e]|[\/\\\\%"]/', '_', $name) ?? 'download';

        return $fallback === '' ? 'download' : $fallback;
    }
}
