<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Storage;

use Cehlers88\AnalyticsDocumentsBundle\Entity\Document;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use Doctrine\ORM\EntityManagerInterface;

/**
 * The file browser of the Workspace-Management page: what lies in a directory of a
 * workspace, and creating, renaming, moving and deleting directories and files there.
 *
 * Every path is relative to the workspace and goes through the same rules as the upload
 * (WorkspaceStorage): no "..", no absolute path, and an entry a symlink leads out of the
 * workspace is neither listed nor touched. The refusals are DocumentUploadExceptions,
 * whose code is the status to answer with.
 *
 * Files can be registered as Document (an upload does that). Their path is kept in step:
 * a rename or move carries the documents along, a delete removes them.
 */
class WorkspaceBrowser
{
    /** Length of Document::$path - a rename must not produce a path a document can not hold. */
    private const MAX_PATH_LENGTH = 255;

    public function __construct(
        private readonly WorkspaceStorage       $workspaceStorage,
        private readonly DocumentRepository     $documentRepository,
        private readonly EntityManagerInterface $entityManager,
    )
    {
    }

    /**
     * The entries of a directory, directories first, then by name.
     *
     * A symlink that leads out of the workspace (or nowhere) is not part of it and is left
     * out - unless $includeExternal: then it comes as type "external" with where it points
     * ("target", "targetType": directory, file or missing), for the administrators, who may
     * make a workspace of its target. Nothing else of the browser touches such an entry.
     *
     * @return list<array{name: string, path: string, type: string, size: int|null, modifiedAt: string|null, extension: string, documentId: int|null, target?: string, targetType?: string}>
     */
    public function list(DocumentRoot $workspace, string $directory, bool $includeExternal = false): array
    {
        $directory = WorkspaceStorage::normalizeDirectory($directory);
        [$root, $absolute] = $this->resolve($workspace, $directory);
        if (!is_dir($absolute)) {
            throw DocumentUploadException::badRequest(sprintf('"%s" is no directory', $directory));
        }

        $names = scandir($absolute);
        if ($names === false) {
            throw DocumentUploadException::storage(sprintf('The directory "%s" can not be read', $directory));
        }

        $entries = [];
        foreach ($names as $name) {
            if ($name === '.' || $name === '..') {
                continue;
            }
            $path = $directory === '' ? $name : $directory . '/' . $name;
            $entryPath = $absolute . DIRECTORY_SEPARATOR . $name;
            $resolved = realpath($entryPath);
            // a dangling link or one that leads out of the workspace is not part of it
            if ($resolved === false || !self::isInside($resolved, $root)) {
                if ($includeExternal && is_link($entryPath)) {
                    $entries[$path] = self::externalEntry($name, $path, $entryPath, $resolved);
                }
                continue;
            }
            $isDirectory = is_dir($resolved);
            $modified = @filemtime($resolved);
            $entries[$path] = [
                'name' => $name,
                'path' => $path,
                'type' => $isDirectory ? 'directory' : 'file',
                'size' => $isDirectory ? null : (int)@filesize($resolved),
                'modifiedAt' => $modified === false ? null : date(\DateTimeInterface::ATOM, $modified),
                'extension' => $isDirectory ? '' : strtolower(pathinfo($name, PATHINFO_EXTENSION)),
                'documentId' => null,
            ];
        }

        $files = array_column(array_filter($entries, static fn(array $entry): bool => $entry['type'] === 'file'), 'path');
        foreach (array_chunk($files, 500) as $chunk) {
            foreach ($this->documentRepository->findBy(['documentRootId' => $workspace->id, 'path' => $chunk]) as $document) {
                if (isset($entries[(string)$document->getPath()])) {
                    $entries[(string)$document->getPath()]['documentId'] = $document->getId();
                }
            }
        }

        $entries = array_values($entries);
        // directories first - an external link counts as one when it leads to one
        $isFileLike = static fn(array $entry): bool => $entry['type'] === 'file'
            || ($entry['type'] === 'external' && $entry['targetType'] !== 'directory');
        usort($entries, static fn(array $left, array $right): int => [$isFileLike($left), mb_strtolower($left['name'])]
            <=> [$isFileLike($right), mb_strtolower($right['name'])]);

        return $entries;
    }

    /**
     * The configured workspace a directory outside of $current lies in, and where in it:
     * what an external link of the browser can be opened as instead of being made a new
     * workspace.
     *
     * @param list<DocumentRoot> $workspaces
     * @return array{workspace: DocumentRoot, path: string}|null
     */
    public function workspaceContaining(string $target, array $workspaces): ?array
    {
        $best = null;
        foreach ($workspaces as $workspace) {
            try {
                $root = $this->workspaceStorage->rootOf($workspace);
            } catch (DocumentUploadException) {
                continue;
            }
            // the innermost one wins when workspaces lie in each other
            if (self::isInside($target, $root) && ($best === null || strlen($root) > strlen($best[1]))) {
                $best = [$workspace, $root];
            }
        }
        if ($best === null) {
            return null;
        }

        return [
            'workspace' => $best[0],
            'path' => str_replace(DIRECTORY_SEPARATOR, '/', ltrim(substr($target, strlen($best[1])), DIRECTORY_SEPARATOR)),
        ];
    }

    /** @return string the path of the new directory */
    public function createDirectory(DocumentRoot $workspace, string $parent, string $name): string
    {
        $parent = WorkspaceStorage::normalizeDirectory($parent);
        $name = WorkspaceStorage::normalizeFileName($name);
        [, $absoluteParent] = $this->resolve($workspace, $parent);
        if (!is_dir($absoluteParent)) {
            throw DocumentUploadException::notFound(sprintf('The directory "%s" does not exist', $parent));
        }

        $path = self::join($parent, $name);
        self::assertPathLength($path);
        $target = $absoluteParent . DIRECTORY_SEPARATOR . $name;
        if (file_exists($target) || is_link($target)) {
            throw DocumentUploadException::conflict(sprintf('There already is an entry "%s"', $path));
        }
        if (!@mkdir($target, 0775)) {
            throw DocumentUploadException::storage(sprintf('The directory "%s" could not be created', $path));
        }

        return $path;
    }

    /** @return string the new path of the entry */
    public function rename(DocumentRoot $workspace, string $path, string $newName): string
    {
        $path = $this->normalizeEntry($path);
        $newName = WorkspaceStorage::normalizeFileName($newName);
        $parent = self::parentOf($path);

        return $this->relocate($workspace, $path, self::join($parent, $newName));
    }

    /** @return string the new path of the entry */
    public function move(DocumentRoot $workspace, string $path, string $targetDirectory): string
    {
        $path = $this->normalizeEntry($path);
        $targetDirectory = WorkspaceStorage::normalizeDirectory($targetDirectory);
        if ($targetDirectory === $path || str_starts_with($targetDirectory . '/', $path . '/')) {
            throw DocumentUploadException::badRequest('A directory can not be moved into itself');
        }
        [, $absoluteTarget] = $this->resolve($workspace, $targetDirectory);
        if (!is_dir($absoluteTarget)) {
            throw DocumentUploadException::notFound(sprintf('The directory "%s" does not exist', $targetDirectory));
        }

        return $this->relocate($workspace, $path, self::join($targetDirectory, basename($path)));
    }

    /**
     * Deletes a file, or a directory - one that is not empty only with $recursive.
     *
     * @return int how many registered documents went with it
     */
    public function delete(DocumentRoot $workspace, string $path, bool $recursive = false): int
    {
        $path = $this->normalizeEntry($path);
        $absolute = $this->resolveEntry($workspace, $path);

        if (is_dir($absolute) && !is_link($absolute)) {
            $isEmpty = (new \FilesystemIterator($absolute))->valid() === false;
            if (!$isEmpty && !$recursive) {
                throw DocumentUploadException::conflict(sprintf('The directory "%s" is not empty', $path));
            }
            self::removeDirectory($absolute);
        } elseif (!@unlink($absolute)) {
            throw DocumentUploadException::storage(sprintf('"%s" could not be deleted', $path));
        }

        $documents = $this->documentsAt($workspace, $path);
        foreach ($documents as $document) {
            $this->entityManager->remove($document);
        }
        if ($documents !== []) {
            $this->entityManager->flush();
        }

        return count($documents);
    }

    /**
     * The absolute path of a file of the workspace, for its download.
     */
    public function fileOf(DocumentRoot $workspace, string $path): string
    {
        $path = $this->normalizeEntry($path);
        $absolute = $this->resolveEntry($workspace, $path);
        $resolved = (string)realpath($absolute);
        if (!is_file($resolved)) {
            throw DocumentUploadException::badRequest(sprintf('"%s" is no file', $path));
        }

        return $resolved;
    }

    /** Whether the directory of the workspace can be found at all - for the overview. */
    public function isAvailable(DocumentRoot $workspace): bool
    {
        try {
            $this->workspaceStorage->rootOf($workspace);

            return true;
        } catch (DocumentUploadException) {
            return false;
        }
    }

    private function relocate(DocumentRoot $workspace, string $from, string $to): string
    {
        if ($from === $to) {
            return $to;
        }
        self::assertPathLength($to);
        $source = $this->resolveEntry($workspace, $from);
        [, $absoluteParent] = $this->resolve($workspace, self::parentOf($to));
        $target = $absoluteParent . DIRECTORY_SEPARATOR . basename($to);
        // a rename that only changes the case is the same entry on a case-insensitive file system
        if ((file_exists($target) || is_link($target)) && strcasecmp($from, $to) !== 0) {
            throw DocumentUploadException::conflict(sprintf('There already is an entry "%s"', $to));
        }
        if (!@rename($source, $target)) {
            throw DocumentUploadException::storage(sprintf('"%s" could not be moved to "%s"', $from, $to));
        }

        $documents = $this->documentsAt($workspace, $from);
        foreach ($documents as $document) {
            $newPath = $to . substr((string)$document->getPath(), strlen($from));
            if (strlen($newPath) > self::MAX_PATH_LENGTH) {
                // the file moved, the document can not follow - better without it than pointing nowhere
                $this->entityManager->remove($document);
                continue;
            }
            $document->setPath($newPath)->setName(basename($newPath));
        }
        if ($documents !== []) {
            $this->entityManager->flush();
        }

        return $to;
    }

    /** @return list<Document> the one of a file, those below a directory */
    private function documentsAt(DocumentRoot $workspace, string $path): array
    {
        return $this->documentRepository->findInside($workspace->id, $path);
    }

    /** A path that names an entry - the workspace itself is none. */
    private function normalizeEntry(string $path): string
    {
        $path = WorkspaceStorage::normalizeDirectory($path);
        if ($path === '') {
            throw DocumentUploadException::badRequest('The workspace itself can not be changed');
        }

        return $path;
    }

    /**
     * Where an existing entry is, without following a symlink at its end - renaming or
     * deleting a link touches the link, not what it points to.
     */
    private function resolveEntry(DocumentRoot $workspace, string $path): string
    {
        [$root, $absoluteParent] = $this->resolve($workspace, self::parentOf($path));
        $absolute = $absoluteParent . DIRECTORY_SEPARATOR . basename($path);
        if (!file_exists($absolute) && !is_link($absolute)) {
            throw DocumentUploadException::notFound(sprintf('"%s" does not exist', $path));
        }
        $resolved = realpath($absolute);
        if ($resolved !== false && !self::isInside($resolved, $root)) {
            throw DocumentUploadException::badRequest('The path must not leave the workspace');
        }

        return $absolute;
    }

    /**
     * The root of the workspace and the absolute path of a (normalized) path in it, which
     * has to exist and must not lead out of it.
     *
     * @return array{0: string, 1: string}
     */
    private function resolve(DocumentRoot $workspace, string $path): array
    {
        $root = $this->workspaceStorage->rootOf($workspace);
        if ($path === '') {
            return [$root, $root];
        }
        $resolved = realpath($root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $path));
        if ($resolved === false) {
            throw DocumentUploadException::notFound(sprintf('"%s" does not exist', $path));
        }
        if (!self::isInside($resolved, $root)) {
            throw DocumentUploadException::badRequest('The path must not leave the workspace');
        }

        return [$root, $resolved];
    }

    /** @return array<string, mixed> a link that leads out of the workspace, as list() shows it */
    private static function externalEntry(string $name, string $path, string $link, string|false $resolved): array
    {
        $stat = @lstat($link);
        $modified = $stat === false ? false : $stat['mtime'];

        return [
            'name' => $name,
            'path' => $path,
            'type' => 'external',
            'size' => null,
            'modifiedAt' => $modified === false ? null : date(\DateTimeInterface::ATOM, $modified),
            'extension' => '',
            'documentId' => null,
            // a dangling link: where it would point, as it is written
            'target' => $resolved === false ? (string)@readlink($link) : $resolved,
            'targetType' => $resolved === false ? 'missing' : (is_dir($resolved) ? 'directory' : 'file'),
        ];
    }

    private static function removeDirectory(string $directory): void
    {
        $items = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($directory, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($items as $item) {
            /** @var \SplFileInfo $item */
            // a link to a directory is removed as link - what it points to stays untouched
            $removed = $item->isDir() && !$item->isLink() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
            if (!$removed) {
                throw DocumentUploadException::storage(sprintf('"%s" could not be deleted', $item->getFilename()));
            }
        }
        if (!@rmdir($directory)) {
            throw DocumentUploadException::storage('The directory could not be deleted');
        }
    }

    private static function isInside(string $path, string $root): bool
    {
        return $path === $root || str_starts_with($path, rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR);
    }

    private static function parentOf(string $path): string
    {
        $position = strrpos($path, '/');

        return $position === false ? '' : substr($path, 0, $position);
    }

    private static function join(string $directory, string $name): string
    {
        return $directory === '' ? $name : $directory . '/' . $name;
    }

    private static function assertPathLength(string $path): void
    {
        if (strlen($path) > self::MAX_PATH_LENGTH) {
            throw DocumentUploadException::badRequest(sprintf('The path is longer than %d bytes', self::MAX_PATH_LENGTH));
        }
    }
}
