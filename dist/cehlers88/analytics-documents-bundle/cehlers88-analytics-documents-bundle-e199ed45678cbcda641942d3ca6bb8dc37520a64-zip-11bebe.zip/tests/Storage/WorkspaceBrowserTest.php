<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Storage;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsDocumentsBundle\Entity\Document;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRoot;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRootProvider;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceBrowser;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceStorage;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use Doctrine\ORM\EntityManagerInterface;
use PHPUnit\Framework\TestCase;

class WorkspaceBrowserTest extends TestCase
{
    private string $directory;
    private DocumentRoot $workspace;
    /** @var list<Document> what the repository knows */
    private array $documents = [];
    /** @var list<Document> */
    private array $removed = [];

    protected function setUp(): void
    {
        $this->directory = sys_get_temp_dir() . '/workspace-browser-' . bin2hex(random_bytes(4));
        mkdir($this->directory . '/root/invoices/2026', 0775, true);
        mkdir($this->directory . '/outside');
        file_put_contents($this->directory . '/root/invoices/2026/a.pdf', 'pdf');
        file_put_contents($this->directory . '/root/notes.txt', 'hello');
        file_put_contents($this->directory . '/outside/secret.txt', 'secret');
        $this->workspace = new DocumentRoot('ws1', 'Test', $this->directory . '/root');
    }

    protected function tearDown(): void
    {
        exec('rm -rf ' . escapeshellarg($this->directory));
    }

    public function test_lists_directories_first_and_marks_registered_documents(): void
    {
        $this->documents = [$this->document(7, 'notes.txt')];

        $entries = $this->browser()->list($this->workspace, '');

        $this->assertSame(['invoices', 'notes.txt'], array_column($entries, 'name'));
        $this->assertSame('directory', $entries[0]['type']);
        $this->assertNull($entries[0]['size']);
        $this->assertSame(5, $entries[1]['size']);
        $this->assertSame('txt', $entries[1]['extension']);
        $this->assertSame(7, $entries[1]['documentId']);
        $this->assertSame(['a.pdf'], array_column($this->browser()->list($this->workspace, 'invoices/2026'), 'name'));
    }

    public function test_a_symlink_out_of_the_workspace_is_not_listed(): void
    {
        symlink($this->directory . '/outside', $this->directory . '/root/escape');
        symlink($this->directory . '/outside/secret.txt', $this->directory . '/root/secret.txt');

        $this->assertSame(['invoices', 'notes.txt'], array_column($this->browser()->list($this->workspace, ''), 'name'));
    }

    public function test_administrators_see_links_out_of_the_workspace_with_their_target(): void
    {
        symlink($this->directory . '/outside', $this->directory . '/root/escape');
        symlink($this->directory . '/outside/secret.txt', $this->directory . '/root/secret.txt');
        symlink($this->directory . '/nowhere', $this->directory . '/root/dangling');

        $entries = array_column($this->browser()->list($this->workspace, '', true), null, 'name');

        $this->assertSame(['escape', 'invoices', 'dangling', 'notes.txt', 'secret.txt'], array_keys($entries));
        $this->assertSame('external', $entries['escape']['type']);
        $this->assertSame(realpath($this->directory . '/outside'), $entries['escape']['target']);
        $this->assertSame('directory', $entries['escape']['targetType']);
        $this->assertSame('file', $entries['secret.txt']['targetType']);
        $this->assertSame('missing', $entries['dangling']['targetType']);
        $this->assertSame($this->directory . '/nowhere', $entries['dangling']['target']);
        $this->assertSame('directory', $entries['invoices']['type']);
    }

    public function test_finds_the_workspace_a_target_lies_in(): void
    {
        mkdir($this->directory . '/outside/deep/er', 0775, true);
        $outer = new DocumentRoot('ws2', 'Außen', $this->directory . '/outside');
        $inner = new DocumentRoot('ws3', 'Tief', $this->directory . '/outside/deep');
        $missing = new DocumentRoot('ws4', 'Weg', $this->directory . '/gone');
        $browser = $this->browser();

        $match = $browser->workspaceContaining(realpath($this->directory . '/outside/deep/er'), [$outer, $missing, $inner]);
        $this->assertSame('ws3', $match['workspace']->id);
        $this->assertSame('er', $match['path']);

        $this->assertSame('', $browser->workspaceContaining(realpath($this->directory . '/outside'), [$outer])['path']);
        $this->assertNull($browser->workspaceContaining(realpath($this->directory . '/outside'), [$inner]));
    }

    public function test_listing_can_not_leave_the_workspace(): void
    {
        symlink($this->directory . '/outside', $this->directory . '/root/escape');

        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(400);

        $this->browser()->list($this->workspace, 'escape');
    }

    public function test_listing_a_missing_directory_is_not_found(): void
    {
        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(404);

        $this->browser()->list($this->workspace, 'nowhere');
    }

    public function test_creates_a_directory_and_refuses_an_existing_name(): void
    {
        $browser = $this->browser();

        $this->assertSame('invoices/2027', $browser->createDirectory($this->workspace, 'invoices', '2027'));
        $this->assertDirectoryExists($this->directory . '/root/invoices/2027');

        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(409);
        $browser->createDirectory($this->workspace, '', 'notes.txt');
    }

    public function test_renaming_a_directory_carries_its_documents_along(): void
    {
        $inside = $this->document(1, 'invoices/2026/a.pdf');
        $this->documents = [$inside];

        $this->assertSame('bills', $this->browser()->rename($this->workspace, 'invoices', 'bills'));

        $this->assertFileExists($this->directory . '/root/bills/2026/a.pdf');
        $this->assertSame('bills/2026/a.pdf', $inside->getPath());
        $this->assertSame('a.pdf', $inside->getName());
    }

    public function test_renaming_a_file_renames_its_document(): void
    {
        $document = $this->document(1, 'notes.txt');
        $this->documents = [$document];

        $this->browser()->rename($this->workspace, 'notes.txt', 'todo.txt');

        $this->assertFileExists($this->directory . '/root/todo.txt');
        $this->assertSame('todo.txt', $document->getPath());
        $this->assertSame('todo.txt', $document->getName());
    }

    public function test_renaming_onto_an_existing_entry_is_refused(): void
    {
        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(409);

        $this->browser()->rename($this->workspace, 'notes.txt', 'invoices');
    }

    public function test_moves_a_file_into_another_directory(): void
    {
        $document = $this->document(1, 'notes.txt');
        $this->documents = [$document];

        $this->assertSame('invoices/notes.txt', $this->browser()->move($this->workspace, 'notes.txt', 'invoices'));

        $this->assertFileExists($this->directory . '/root/invoices/notes.txt');
        $this->assertSame('invoices/notes.txt', $document->getPath());
    }

    public function test_a_directory_can_not_be_moved_into_itself(): void
    {
        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(400);

        $this->browser()->move($this->workspace, 'invoices', 'invoices/2026');
    }

    public function test_a_directory_that_is_not_empty_is_only_deleted_recursively(): void
    {
        $browser = $this->browser();
        try {
            $browser->delete($this->workspace, 'invoices');
            $this->fail('A directory that is not empty was deleted');
        } catch (DocumentUploadException $exception) {
            $this->assertSame(409, $exception->getCode());
        }

        $this->documents = [$this->document(1, 'invoices/2026/a.pdf')];
        $this->assertSame(1, $browser->delete($this->workspace, 'invoices', true));

        $this->assertDirectoryDoesNotExist($this->directory . '/root/invoices');
        $this->assertCount(1, $this->removed);
    }

    public function test_deleting_a_link_leaves_its_target_alone(): void
    {
        mkdir($this->directory . '/root/archive');
        file_put_contents($this->directory . '/root/archive/keep.txt', 'keep');
        symlink($this->directory . '/root/archive', $this->directory . '/root/shortcut');

        $this->browser()->delete($this->workspace, 'shortcut');

        $this->assertFileDoesNotExist($this->directory . '/root/shortcut');
        $this->assertFileExists($this->directory . '/root/archive/keep.txt');
    }

    public function test_the_workspace_itself_can_not_be_deleted(): void
    {
        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(400);

        $this->browser()->delete($this->workspace, '/', true);
    }

    public function test_a_file_outside_the_workspace_is_not_handed_out(): void
    {
        symlink($this->directory . '/outside/secret.txt', $this->directory . '/root/secret.txt');
        $browser = $this->browser();

        $this->assertSame(realpath($this->directory . '/root/notes.txt'), $browser->fileOf($this->workspace, 'notes.txt'));

        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(400);
        $browser->fileOf($this->workspace, 'secret.txt');
    }

    public function test_an_unreachable_workspace_is_reported_as_unavailable(): void
    {
        $browser = $this->browser();

        $this->assertTrue($browser->isAvailable($this->workspace));
        $this->assertFalse($browser->isAvailable(new DocumentRoot('ws2', 'Gone', $this->directory . '/gone')));
    }

    private function browser(): WorkspaceBrowser
    {
        $configurationProvider = $this->createStub(ConfigurationProvider::class);
        $configurationProvider->method('getValue')->willReturn('');

        $repository = $this->createStub(DocumentRepository::class);
        $repository->method('findBy')->willReturnCallback(fn(array $criteria): array => array_values(array_filter(
            $this->documents,
            static fn(Document $document): bool => in_array($document->getPath(), (array)$criteria['path'], true)
        )));
        $repository->method('findInside')->willReturnCallback(fn(string $root, string $path): array => array_values(array_filter(
            $this->documents,
            static fn(Document $document): bool => $document->getPath() === $path || str_starts_with((string)$document->getPath(), $path . '/')
        )));

        $entityManager = $this->createStub(EntityManagerInterface::class);
        $entityManager->method('remove')->willReturnCallback(function (Document $document): void {
            $this->removed[] = $document;
        });

        return new WorkspaceBrowser(new WorkspaceStorage(new DocumentRootProvider($configurationProvider)), $repository, $entityManager);
    }

    private function document(int $id, string $path): Document
    {
        $document = (new Document())->setDocumentRootId('ws1')->setPath($path)->setName(basename($path));
        (new \ReflectionProperty(Document::class, 'id'))->setValue($document, $id);

        return $document;
    }
}
