<?php

namespace Cehlers88\AnalyticsDocumentsBundle\Macro;

use Analytics\DTO\Macro\MacroPropertyDTO;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;

class SetDocumentInfosMacro extends AbstractDocumentMacro {
    private const PROPERTY_FILE_ID = 'fileId';

    public function __construct(
        private DocumentRepository $documentRepository
    ) {

    }

    private function createDocument(int $workspaceId){

    }

    protected function run(): ?array {
        $fileId = $this->getPropertyValue(self::PROPERTY_FILE_ID);
        if($fileId === -1){

        }


        //$outputValue = $this->getPropertyValue('output');
        /*if(is_array($outputValue) || is_object($outputValue)){
            echo json_encode($outputValue);
        }else{
            echo $outputValue;
        }*/

        return $this->_createRunResult($this->getPropertyValue('output'));
    }

    public function _init(): SetDocumentInfosMacro {
        $this
            ->setProperty(MacroPropertyDTO::create('fileId','int','Specify the fileId', -1))
            ->setProperty(MacroPropertyDTO::create('fullPath','string','Specify the fileId', -1))
            ->setProperty(MacroPropertyDTO::create('workspaceId','int','Specify the workspace id', -1))
        ;
        return $this;
    }

    public function getDescription(): string {
        return '';
    }

    public function getName(): string {
        return 'setDocumentInfos';
    }
}