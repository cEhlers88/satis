<?php

namespace Cehlers88\AnalyticsDocumentsBundle\Macro;

use Analytics\DTO\Macro\MacroPropertyDTO;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;

class MergeDocumentsMacro extends AbstractDocumentMacro {

    public function __construct(
        private DocumentRepository $documentRepository
    ) {

    }

    protected function run(): ?array {
        $outputValue = $this->getPropertyValue('output');


        return $this->_createRunResult($this->getPropertyValue('output'));
    }

    public function _init(): MergeDocumentsMacro {
        $this
            ->setProperty(MacroPropertyDTO::create('fileId','int','Specify the fileId', -1))
            ->setProperty(MacroPropertyDTO::create('fullPath','string','Specify the fileId', -1))
            ->setProperty(MacroPropertyDTO::create('workspaceId','int','Specify the workspace id', -1))
        ;
        return $this;
    }

    public function getDescription(): string {
        return 'Merge documents.';
    }

    public function getName(): string {
        return 'mergeDocuments';
    }
}