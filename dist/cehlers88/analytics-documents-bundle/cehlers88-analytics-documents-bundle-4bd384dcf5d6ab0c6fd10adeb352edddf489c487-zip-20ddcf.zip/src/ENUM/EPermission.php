<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 19:00
 */

namespace Cehlers88\AnalyticsDocumentsBundle\ENUM;

enum EPermission : string {
    case ACCESS_DOCUMENTS = 'ACCESS_DOCUMENTS';

    public static function getPermissions():array {
        return [
            self::ACCESS_DOCUMENTS->value,
        ];
    }
}