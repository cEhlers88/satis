<?php

namespace Cehlers88\AnalyticsDocumentsBundle\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;

class WriteFileMacro extends AbstractDocumentMacro
{
    private const PROPERTY_FILE_ID = 'fileId';

    public function __construct(
        private DocumentRepository $documentRepository
    )
    {

    }

    public function _init(): WriteFileMacro
    {
        $this
            ->setProperty(MacroPropertyDTO::create('filePath', 'string', 'Specify the file name'))
            ->setProperty(MacroPropertyDTO::create('content', 'string', 'Specify the file content'));
        return $this;
    }

    public function getDescription(): string
    {
        return '';
    }

    public function getName(): string
    {
        return 'writeFile';
    }

    protected function run(): ?array
    {
        $fileId = $this->getPropertyValue(self::PROPERTY_FILE_ID);
        if ($fileId === -1) {

        }


        //$outputValue = $this->getPropertyValue('output');
        /*if(is_array($outputValue) || is_object($outputValue)){
            echo json_encode($outputValue);
        }else{
            echo $outputValue;
        }*/

        return $this->_createRunResult($this->getPropertyValue('output'));
    }

    private function createDocument(int $workspaceId)
    {

    }
}