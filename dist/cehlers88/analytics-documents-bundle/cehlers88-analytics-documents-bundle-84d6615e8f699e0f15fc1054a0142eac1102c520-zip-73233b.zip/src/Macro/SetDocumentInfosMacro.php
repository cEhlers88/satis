<?php

namespace Cehlers88\AnalyticsDocumentsBundle\Macro;

use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;

class SetDocumentInfosMacro extends AbstractDocumentMacro
{
    private const PROPERTY_FILE_ID = 'fileId';

    public function __construct(
        private DocumentRepository $documentRepository
    )
    {

    }

    public function _init(): SetDocumentInfosMacro
    {
        $this
            ->setProperty(MacroPropertyDTO::create('fileId', 'int', 'Specify the fileId'))
            ->setProperty(MacroPropertyDTO::create('infos', 'array', 'Specify the file path'));
        return $this;
    }

    public function getDescription(): string
    {
        return '';
    }

    public function getName(): string
    {
        return 'setDocumentInfos';
    }

    protected function run(): ?array
    {
        $fileId = $this->getPropertyValue(self::PROPERTY_FILE_ID);


        //$outputValue = $this->getPropertyValue('output');
        /*if(is_array($outputValue) || is_object($outputValue)){
            echo json_encode($outputValue);
        }else{
            echo $outputValue;
        }*/

        return $this->_createRunResult($this->getPropertyValue('output'));
    }

    private function createDocument(int $workspaceId)
    {

    }
}