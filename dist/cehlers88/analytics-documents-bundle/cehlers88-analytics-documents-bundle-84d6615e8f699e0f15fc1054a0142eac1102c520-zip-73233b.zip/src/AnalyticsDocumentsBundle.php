<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 18:59
 */

namespace Cehlers88\AnalyticsDocumentsBundle;

use Cehlers88\AnalyticsCore\Support\AbstractBundlePlugin;
use Cehlers88\AnalyticsCore\Support\DTO\UI\MenuItemDTO;
use Cehlers88\AnalyticsDocumentsBundle\ENUM\EPermission;

class AnalyticsDocumentsBundle extends AbstractBundlePlugin
{
    public const NAME = 'AnalyticsDocumentsBundle';

    public function getConfigurationGroups(): array
    {
        /*$group = new ConfigurationGroupDTO();
        $group->items = [
            ConfigurationItemDTO::create('default_workspace', 'Standard Arbeitsbereich', eInputType::NUMBER, -1, 'Der Standard Arbeitsbereich für Dokumente'),
        ];

        return [$group];*/

        return [];
    }

    public function getDescription(): string
    {
        return 'Bundle zur Verwaltung von Dokumenten.';
    }

    public function getMenuItems(): array
    {
        return [
            MenuItemDTO::create('Dokumentverwaltung', 'analytics_documents_documents', [], '', [])
        ];
    }

    public function getPermissions(): array
    {
        return EPermission::getPermissions();
    }

    public function getVersion(): string
    {
        return '1.0.0';
    }
}