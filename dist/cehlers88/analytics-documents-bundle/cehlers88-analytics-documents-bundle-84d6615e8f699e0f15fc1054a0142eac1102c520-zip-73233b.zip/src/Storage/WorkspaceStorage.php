<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Storage;

use Cehlers88\AnalyticsDocumentsBundle\Entity\Document;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;

/**
 * Where the files of a workspace live. A workspace (an entry of the configured
 * "documentRoots", DocumentRoot) is the root directory of its documents; the
 * path of a document is relative to it and can never leave it - no "..", no
 * absolute path, no symlink that points outside.
 *
 * The path of a workspace is used as it is when it is absolute; a relative one
 * lies below the configured "Workspace Root" (GeneralConfigurationGroup).
 */
class WorkspaceStorage
{
    public function __construct(
        private readonly DocumentRootProvider $documentRootProvider,
    )
    {
    }

    /** The absolute, existing root directory of the workspace. */
    public function rootOf(DocumentRoot $workspace): string
    {
        $path = $workspace->path;
        if (!self::isAbsolute($path)) {
            $base = $this->documentRootProvider->workspaceRoot();
            if ($base === '') {
                throw DocumentUploadException::storage(sprintf(
                    'Workspace "%s" has the relative path "%s", but no workspace root is configured',
                    $workspace->name,
                    $path
                ));
            }
            $path = rtrim($base, '/\\') . DIRECTORY_SEPARATOR . $path;
        }

        $root = realpath($path);
        if ($root === false || !is_dir($root)) {
            throw DocumentUploadException::storage(sprintf('The directory of workspace "%s" does not exist', $workspace->name));
        }

        return $root;
    }

    /**
     * A directory below the workspace, as it is stored: segments separated by
     * "/", without leading or trailing slash; "" is the workspace itself.
     */
    public static function normalizeDirectory(string $directory): string
    {
        $segments = [];
        foreach (preg_split('#[/\\\\]+#', $directory) ?: [] as $segment) {
            if ($segment === '' || $segment === '.') {
                continue;
            }
            if ($segment === '..') {
                throw DocumentUploadException::badRequest('The path must not leave the workspace ("..")');
            }
            self::assertValidSegment($segment);
            $segments[] = $segment;
        }

        return implode('/', $segments);
    }

    public static function normalizeFileName(string $name): string
    {
        $name = trim($name);
        if ($name === '' || $name === '.' || $name === '..' || preg_match('#[/\\\\]#', $name) === 1) {
            throw DocumentUploadException::badRequest(sprintf('"%s" is no valid file name', $name));
        }
        self::assertValidSegment($name);

        return $name;
    }

    /**
     * The absolute directory for a (normalized) directory of the workspace,
     * created if it does not exist yet.
     */
    public function prepareDirectory(DocumentRoot $workspace, string $directory): string
    {
        $root = $this->rootOf($workspace);
        $target = $directory === '' ? $root : $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $directory);

        if (!is_dir($target) && !@mkdir($target, 0775, true) && !is_dir($target)) {
            throw DocumentUploadException::storage(sprintf('The directory "%s" could not be created', $directory));
        }

        // a symlink inside the workspace may point anywhere - what counts is where it ends up
        $resolved = realpath($target);
        if ($resolved === false || ($resolved !== $root && !str_starts_with($resolved, $root . DIRECTORY_SEPARATOR))) {
            throw DocumentUploadException::badRequest('The path must not leave the workspace');
        }

        return $resolved;
    }

    /** Where the file of a document is. */
    public function absolutePathOf(Document $document): string
    {
        $workspace = $this->documentRootProvider->find((string)$document->getDocumentRootId());
        if ($workspace === null) {
            throw DocumentUploadException::storage(sprintf(
                'The workspace "%s" of document %d is not configured',
                (string)$document->getDocumentRootId(),
                (int)$document->getId()
            ));
        }

        return $this->rootOf($workspace) . DIRECTORY_SEPARATOR
            . str_replace('/', DIRECTORY_SEPARATOR, self::normalizeDirectory((string)$document->getPath()));
    }

    private static function assertValidSegment(string $segment): void
    {
        if (preg_match('/[\x00-\x1f\x7f]/', $segment) === 1) {
            throw DocumentUploadException::badRequest('The path contains control characters');
        }
        if (strlen($segment) > 255) {
            throw DocumentUploadException::badRequest('A path segment is longer than 255 bytes');
        }
    }

    private static function isAbsolute(string $path): bool
    {
        return str_starts_with($path, '/') || str_starts_with($path, '\\') || preg_match('#^[a-zA-Z]:[/\\\\]#', $path) === 1;
    }
}
