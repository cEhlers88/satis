<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Storage;

/**
 * A workspace: an entry of the configured "documentRoots"
 * (GeneralConfigurationGroup). Its path is the root directory of its documents.
 */
final class DocumentRoot
{
    public function __construct(
        public readonly string $id,
        public readonly string $name,
        public readonly string $path,
        public readonly string $description = '',
    )
    {
    }
}
