<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Storage;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsDocumentsBundle\Configuration\GeneralConfigurationGroup;

/**
 * The workspaces, as they are configured under "documentRoots" - one row per
 * workspace, identified by its unique id.
 */
class DocumentRootProvider
{
    public function __construct(
        private readonly ConfigurationProvider $configurationProvider,
    )
    {
    }

    /** @return DocumentRoot[] the usable ones - a row without id or path is left out */
    public function all(): array
    {
        $rows = $this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'documentRoots', -1, []);
        // newer rows come as arrays, older ones decoded from json text as objects
        $rows = is_string($rows) ? json_decode($rows, true) : json_decode((string)json_encode($rows), true);

        $roots = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            if (!is_array($row)) {
                continue;
            }
            $id = trim((string)($row['id'] ?? ''));
            $path = trim((string)($row['path'] ?? ''));
            if ($id === '' || $path === '') {
                continue;
            }
            $roots[$id] = new DocumentRoot(
                $id,
                trim((string)($row['name'] ?? '')) ?: $id,
                $path,
                trim((string)($row['description'] ?? ''))
            );
        }

        return array_values($roots);
    }

    public function find(string $id): ?DocumentRoot
    {
        foreach ($this->all() as $root) {
            if ($root->id === $id) {
                return $root;
            }
        }

        return null;
    }

    /** The configured root that relative workspace paths lie below; "" if none. */
    public function workspaceRoot(): string
    {
        return trim((string)$this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'workspaceRoot', -1, ''));
    }
}
