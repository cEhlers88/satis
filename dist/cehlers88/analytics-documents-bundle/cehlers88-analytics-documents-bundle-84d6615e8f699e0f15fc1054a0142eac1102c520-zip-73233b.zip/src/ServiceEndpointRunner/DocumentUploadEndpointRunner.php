<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\DTO\RoleDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsDocumentsBundle\AnalyticsDocumentsBundle;
use Cehlers88\AnalyticsDocumentsBundle\ENUM\EPermission;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRoot;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRootProvider;
use Cehlers88\AnalyticsDocumentsBundle\Upload\DocumentUploader;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use Cehlers88\AnalyticsDocumentsBundle\Upload\UploadSource;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * POST /api/se/AnalyticsDocumentsBundle.upload - stores a file in a workspace and
 * answers with the id of the Document it created.
 *
 * The file comes either as field "file" of a multipart form, just as a browser
 * sends it, or base64 encoded in "content" (json or form; a data url works too),
 * then with a "name". It lands in the workspace below "path" - see DocumentUploader.
 * The workspace is an entry of the configured "documentRoots", named by its id.
 */
class DocumentUploadEndpointRunner extends AbstractServiceEndpointRunner
{
    public function __construct(
        private readonly DocumentRootProvider $documentRootProvider,
        private readonly DocumentUploader     $documentUploader,
    )
    {
        $this->registerEndpoint($this->buildUploadEndpoint());
    }

    public function getBundleName(): string
    {
        return AnalyticsDocumentsBundle::NAME;
    }

    public function getRequiredRoles(): array
    {
        // a role of the user - administrators have it implicitly
        return [RoleDTO::create(EPermission::ACCESS_DOCUMENTS->value)];
    }

    public function handleUpload(array $values): ServiceEndpointRunnerResultDTO
    {
        try {
            $workspace = $this->findWorkspace($values['workspaceId'] ?? null);
            $source = $this->readSource($values);

            $name = is_scalar($values['name'] ?? null) ? trim((string)$values['name']) : '';
            if ($name === '') {
                $name = $source->originalName
                    ?? throw DocumentUploadException::badRequest('Parameter \'name\' is required for a base64 upload');
            }

            $result = $this->documentUploader->upload(
                $workspace,
                $source,
                is_scalar($values['path'] ?? null) ? (string)$values['path'] : '',
                $name,
                filter_var($values['overwrite'] ?? false, FILTER_VALIDATE_BOOL),
                $this->readAttributes($values['attributes'] ?? [])
            );
        } catch (DocumentUploadException $exception) {
            return ServiceEndpointRunnerResultDTO::createError($exception->getMessage(), $exception->getCode());
        }

        return ServiceEndpointRunnerResultDTO::createSuccess(
            $result->document->getId(),
            $result->replaced ? 'Document replaced' : 'Document created'
        );
    }

    private function findWorkspace(mixed $workspaceId): DocumentRoot
    {
        $workspaceId = is_scalar($workspaceId) ? trim((string)$workspaceId) : '';
        if ($workspaceId === '') {
            throw DocumentUploadException::badRequest('Parameter \'workspaceId\' has to be the id of a workspace');
        }

        return $this->documentRootProvider->find($workspaceId)
            ?? throw DocumentUploadException::notFound(sprintf('Workspace "%s" not found', $workspaceId));
    }

    private function readSource(array $values): UploadSource
    {
        $file = $values['file'] ?? null;
        $content = $values['content'] ?? null;
        $hasContent = is_string($content) && trim($content) !== '';

        if (is_array($file)) {
            throw DocumentUploadException::badRequest('One file per upload - send "file", not a list of files');
        }
        if ($file !== null && !$file instanceof UploadedFile) {
            throw DocumentUploadException::badRequest(
                '"file" has to be a file of a multipart form - send base64 data as "content"'
            );
        }
        if ($file !== null && $hasContent) {
            throw DocumentUploadException::badRequest('Send either "file" or "content", not both');
        }

        $maxFileSize = $this->documentUploader->getMaxFileSize();
        if ($file instanceof UploadedFile) {
            return UploadSource::fromUploadedFile($file, $maxFileSize);
        }
        if ($hasContent) {
            $mimeType = is_string($values['mimeType'] ?? null) && trim($values['mimeType']) !== '' ? trim($values['mimeType']) : null;

            return UploadSource::fromBase64($content, $mimeType, $maxFileSize);
        }

        throw DocumentUploadException::badRequest('Send the file as "file" (multipart form) or base64 encoded as "content"');
    }

    /** Attributes come as array (json) or as json text (form field). */
    private function readAttributes(mixed $attributes): array
    {
        if (is_string($attributes)) {
            $attributes = trim($attributes) === '' ? [] : json_decode($attributes, true);
        }
        if (!is_array($attributes) || (array_is_list($attributes) && $attributes !== [])) {
            throw DocumentUploadException::badRequest('Parameter \'attributes\' has to be an object');
        }

        return $attributes;
    }

    private function buildUploadEndpoint(): EndpointDefinitionDTO
    {
        $describe = static function (PropertyDTO $property, string $description): PropertyDTO {
            $property->description = $description;
            return $property;
        };

        return EndpointDefinitionDTO::create(
            'upload',
            ['POST'],
            [
                $describe(PropertyDTO::create('workspaceId', null, 'string'), 'Id of the workspace (configured "documentRoots") the file is stored in'),
                $describe(PropertyDTO::create('file', null, 'file', true), 'The file, as field of a multipart form - or send "content"'),
                $describe(PropertyDTO::create('content', null, 'string', true), 'The file base64 encoded (a data url works too) - or send "file"'),
                $describe(PropertyDTO::create('name', null, 'string', true), 'File name incl. extension; required with "content", defaults to the name of "file"'),
                $describe(PropertyDTO::create('path', '', 'string', true), 'Directory below the workspace, e.g. "invoices/2026"; created if missing'),
                $describe(PropertyDTO::create('mimeType', null, 'string', true), 'Mime type of "content"; detected from the data if missing'),
                $describe(PropertyDTO::create('overwrite', false, 'bool', true), 'Replace an existing file (and update its document) instead of refusing'),
                $describe(PropertyDTO::create('attributes', [], 'array', true), 'Further attributes of the document, as object or json text'),
            ],
            [],
            'Stores a file in a workspace and answers with the id of the created document.',
            [$this, 'handleUpload']
        )
            ->withSuccessExample(42, 'Document created')
            ->withErrorExample('There already is a file "invoices/2026/invoice.pdf" in workspace "Accounting"', 409);
    }
}
