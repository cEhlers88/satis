<?php

namespace Cehlers88\AnalyticsDocumentsBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsDocumentsBundle\AnalyticsDocumentsBundle;
use Cehlers88\AnalyticsDocumentsBundle\ENUM\EPermission;

class ZipEndpointRunner extends AbstractServiceEndpointRunner
{
    public function __construct()
    {
        $this->registerEndpoint(EndpointDefinitionDTO::create('zip', ['POST'], [
            PropertyDTO::create('action', 'startArchive', 'string')
        ], [], 'Start create a new archive', [$this, 'handleStartArchive'])
            ->withSuccessExample('6ab8b462d349a')
        );

        $this->registerEndpoint(EndpointDefinitionDTO::create('zip', ['POST'], [
            PropertyDTO::create('action', 'appendFile', 'string'),
            PropertyDTO::create('archiveId', null, 'string'),
            PropertyDTO::create('fileId', null, 'int'),
        ]));
    }

    public function getBundleName(): string
    {
        return AnalyticsDocumentsBundle::NAME;
    }

    public function handleStartArchive(array $requestData): ServiceEndpointRunnerResultDTO
    {
        $id = uniqid();
        return ServiceEndpointRunnerResultDTO::createSuccess($id);
    }

    public function getRequiredRoles(): array
    {
        return [
            EPermission::ACCESS_DOCUMENTS->value
        ];
    }
}