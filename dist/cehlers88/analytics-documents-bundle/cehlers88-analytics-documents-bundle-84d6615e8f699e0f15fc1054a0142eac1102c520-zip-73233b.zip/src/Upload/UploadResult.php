<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Upload;

use Cehlers88\AnalyticsDocumentsBundle\Entity\Document;

/** The document an upload created - or, with overwrite, updated. */
final class UploadResult
{
    public function __construct(
        public readonly Document $document,
        public readonly bool     $replaced,
    )
    {
    }
}
