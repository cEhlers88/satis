<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Upload;

use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * The content of an upload - sent base64 encoded, or as a file of a form - and
 * what is known about it. It is checked when it is created, so a source that
 * exists is one that may be stored.
 */
final class UploadSource
{
    private function __construct(
        private readonly ?string       $content,
        private readonly ?UploadedFile $file,
        public readonly int            $size,
        public readonly string         $mimeType,
        public readonly ?string        $originalName,
    )
    {
    }

    /**
     * @param string $encoded plain base64 or a data url (data:<mime>;base64,<data>)
     */
    public static function fromBase64(string $encoded, ?string $mimeType, int $maxBytes): self
    {
        $encoded = trim($encoded);
        if (preg_match('/^data:([\w.+-]+\/[\w.+-]+)?(;[^,]*)?;base64,/i', $encoded, $match) === 1) {
            $mimeType ??= ($match[1] ?? '') !== '' ? $match[1] : null;
            $encoded = substr($encoded, strlen($match[0]));
        }
        // line breaks of chunked base64 and the url-safe alphabet are both fine
        $encoded = strtr(preg_replace('/\s+/', '', $encoded) ?? '', '-_', '+/');

        if ($encoded === '') {
            throw DocumentUploadException::badRequest('The content is empty');
        }
        // refused before decoding, so an oversized upload never ends up in memory twice
        if (intdiv(strlen($encoded), 4) * 3 > $maxBytes + 2) {
            throw DocumentUploadException::tooLarge($maxBytes);
        }

        $content = base64_decode($encoded, true);
        if ($content === false) {
            throw DocumentUploadException::badRequest('The content is no valid base64');
        }
        if (strlen($content) > $maxBytes) {
            throw DocumentUploadException::tooLarge($maxBytes);
        }

        return new self($content, null, strlen($content), $mimeType ?? self::detectMimeType($content), null);
    }

    public static function fromUploadedFile(UploadedFile $file, int $maxBytes): self
    {
        if (!$file->isValid()) {
            if (in_array($file->getError(), [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)) {
                throw DocumentUploadException::tooLarge($maxBytes);
            }
            throw DocumentUploadException::badRequest($file->getErrorMessage());
        }

        $size = (int)$file->getSize();
        if ($size > $maxBytes) {
            throw DocumentUploadException::tooLarge($maxBytes);
        }

        try {
            $mimeType = $file->getMimeType();
        } catch (\LogicException) {
            // no mime type guesser installed - the browser's word is all there is
            $mimeType = null;
        }

        return new self(
            null,
            $file,
            $size,
            $mimeType ?? $file->getClientMimeType(),
            $file->getClientOriginalName() !== '' ? $file->getClientOriginalName() : null
        );
    }

    /** Writes the content to the given path, replacing what is there. */
    public function writeTo(string $targetPath): void
    {
        // written next to the target and renamed, so a failed upload never leaves half a file
        $temporaryPath = dirname($targetPath) . DIRECTORY_SEPARATOR . '.upload-' . bin2hex(random_bytes(6));

        try {
            if ($this->file !== null) {
                $this->file->move(dirname($temporaryPath), basename($temporaryPath));
            } elseif (file_put_contents($temporaryPath, (string)$this->content) === false) {
                throw DocumentUploadException::storage('The file could not be written');
            }

            if (!rename($temporaryPath, $targetPath)) {
                throw DocumentUploadException::storage('The file could not be stored');
            }
        } catch (\Symfony\Component\HttpFoundation\File\Exception\FileException $exception) {
            throw DocumentUploadException::storage('The file could not be stored: ' . $exception->getMessage());
        } finally {
            if (is_file($temporaryPath)) {
                @unlink($temporaryPath);
            }
        }
    }

    private static function detectMimeType(string $content): string
    {
        if (class_exists(\finfo::class)) {
            $detected = new \finfo(FILEINFO_MIME_TYPE)->buffer($content);
            if (is_string($detected) && $detected !== '') {
                return $detected;
            }
        }

        return 'application/octet-stream';
    }
}
