<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Upload;

use Cehlers88\AnalyticsDocumentsBundle\Entity\Document;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRoot;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceStorage;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Stores an uploaded file in a workspace (DocumentRoot) and registers it as
 * Document, which refers to the workspace by its configured id.
 *
 * The document's path is the path of the file relative to the workspace, file
 * name included ("invoices/2026/invoice.pdf"); its name is the file name. What
 * is known about the file lands in the attributes under "file", next to the
 * attributes the caller gave.
 */
class DocumentUploader
{
    /** Length of Document::$path. */
    private const MAX_PATH_LENGTH = 255;

    public function __construct(
        private readonly WorkspaceStorage       $workspaceStorage,
        private readonly DocumentRepository     $documentRepository,
        private readonly EntityManagerInterface $entityManager,
        #[Autowire('%analytics_documents.upload.max_file_size%')]
        private readonly int                    $maxFileSize,
    )
    {
    }

    public function getMaxFileSize(): int
    {
        return $this->maxFileSize;
    }

    /**
     * @param string $directory directory below the workspace, "" for its root
     * @param bool   $overwrite replace a file that exists - and update its document,
     *                          if it has one - instead of refusing the upload
     */
    public function upload(
        DocumentRoot $workspace,
        UploadSource $source,
        string       $directory,
        string       $fileName,
        bool         $overwrite = false,
        array        $attributes = []
    ): UploadResult
    {
        $directory = WorkspaceStorage::normalizeDirectory($directory);
        $fileName = WorkspaceStorage::normalizeFileName($fileName);
        $relativePath = $directory === '' ? $fileName : $directory . '/' . $fileName;
        if (strlen($relativePath) > self::MAX_PATH_LENGTH) {
            throw DocumentUploadException::badRequest(sprintf('The path is longer than %d bytes', self::MAX_PATH_LENGTH));
        }

        $existing = $this->documentRepository->findOneBy(['documentRootId' => $workspace->id, 'path' => $relativePath]);
        $targetPath = $this->workspaceStorage->prepareDirectory($workspace, $directory) . DIRECTORY_SEPARATOR . $fileName;

        if (!$overwrite && ($existing !== null || file_exists($targetPath))) {
            throw DocumentUploadException::conflict(sprintf(
                'There already is a file "%s" in workspace "%s"',
                $relativePath,
                $workspace->name
            ));
        }
        if (is_dir($targetPath)) {
            throw DocumentUploadException::conflict(sprintf('"%s" is a directory', $relativePath));
        }

        $source->writeTo($targetPath);

        $document = $existing ?? new Document();
        $document
            ->setDocumentRootId($workspace->id)
            ->setName($fileName)
            ->setPath($relativePath)
            ->setRegisteredAt(new \DateTimeImmutable())
            ->setAttributes([
                ...($existing?->getAttributes() ?? []),
                ...$attributes,
                'file' => [
                    'originalName' => $source->originalName,
                    'mimeType' => $source->mimeType,
                    'size' => $source->size,
                    'sha256' => hash_file('sha256', $targetPath),
                ],
            ]);

        $this->entityManager->persist($document);
        $this->entityManager->flush();

        return new UploadResult($document, $existing !== null);
    }
}
