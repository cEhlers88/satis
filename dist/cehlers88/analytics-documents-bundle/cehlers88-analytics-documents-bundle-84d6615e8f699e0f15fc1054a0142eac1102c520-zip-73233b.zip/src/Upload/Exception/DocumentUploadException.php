<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Upload\Exception;

/**
 * An upload that was refused. The code is the status the upload endpoint answers
 * with (400 bad input, 404 unknown workspace, 409 file exists, 413 too large,
 * 500 storage problem).
 */
final class DocumentUploadException extends \RuntimeException
{
    public static function badRequest(string $message): self
    {
        return new self($message, 400);
    }

    public static function notFound(string $message): self
    {
        return new self($message, 404);
    }

    public static function conflict(string $message): self
    {
        return new self($message, 409);
    }

    public static function tooLarge(int $maxBytes): self
    {
        return new self(sprintf('The file is larger than the allowed %d bytes', $maxBytes), 413);
    }

    public static function storage(string $message): self
    {
        return new self($message, 500);
    }
}
