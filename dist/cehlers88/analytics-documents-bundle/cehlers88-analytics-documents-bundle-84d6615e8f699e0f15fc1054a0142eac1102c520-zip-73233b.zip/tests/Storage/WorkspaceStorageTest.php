<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Storage;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRoot;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRootProvider;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceStorage;
use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class WorkspaceStorageTest extends TestCase
{
    private string $directory;

    protected function setUp(): void
    {
        $this->directory = sys_get_temp_dir() . '/workspace-storage-' . bin2hex(random_bytes(4));
        mkdir($this->directory . '/root', 0775, true);
    }

    protected function tearDown(): void
    {
        exec('rm -rf ' . escapeshellarg($this->directory));
    }

    public static function directories(): array
    {
        return [
            'root' => ['', ''],
            'slashes' => ['/invoices//2026/', 'invoices/2026'],
            'backslashes' => ['invoices\\2026', 'invoices/2026'],
            'dots' => ['./invoices/./2026', 'invoices/2026'],
        ];
    }

    #[DataProvider('directories')]
    public function test_a_directory_is_stored_relative_and_normalized(string $given, string $expected): void
    {
        $this->assertSame($expected, WorkspaceStorage::normalizeDirectory($given));
    }

    public function test_a_directory_can_not_leave_the_workspace(): void
    {
        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(400);

        WorkspaceStorage::normalizeDirectory('invoices/../../etc');
    }

    public function test_a_file_name_is_a_name_and_no_path(): void
    {
        $this->assertSame('invoice.pdf', WorkspaceStorage::normalizeFileName(' invoice.pdf '));

        $this->expectException(DocumentUploadException::class);
        WorkspaceStorage::normalizeFileName('../invoice.pdf');
    }

    public function test_a_relative_workspace_lies_below_the_configured_root(): void
    {
        $storage = $this->createStorage($this->directory);

        $this->assertSame(realpath($this->directory . '/root'), $storage->rootOf($this->workspace('root')));
    }

    public function test_a_relative_workspace_without_configured_root_is_refused(): void
    {
        $this->expectException(DocumentUploadException::class);

        $this->createStorage('')->rootOf($this->workspace('root'));
    }

    public function test_directories_are_created_inside_the_workspace(): void
    {
        $storage = $this->createStorage('');

        $path = $storage->prepareDirectory($this->workspace($this->directory . '/root'), 'invoices/2026');

        $this->assertDirectoryExists($path);
        $this->assertSame(realpath($this->directory . '/root/invoices/2026'), $path);
    }

    public function test_a_symlink_can_not_lead_out_of_the_workspace(): void
    {
        mkdir($this->directory . '/outside');
        symlink($this->directory . '/outside', $this->directory . '/root/escape');

        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(400);

        $this->createStorage('')->prepareDirectory($this->workspace($this->directory . '/root'), 'escape');
    }

    private function createStorage(string $workspaceRoot): WorkspaceStorage
    {
        $configurationProvider = $this->createStub(ConfigurationProvider::class);
        $configurationProvider->method('getValue')->willReturnCallback(
            static fn(string $group, string $item) => $item === 'workspaceRoot' ? $workspaceRoot : []
        );

        return new WorkspaceStorage(new DocumentRootProvider($configurationProvider));
    }

    private function workspace(string $path): DocumentRoot
    {
        return new DocumentRoot('69d5b2a1c4e0f', 'Test', $path);
    }
}
