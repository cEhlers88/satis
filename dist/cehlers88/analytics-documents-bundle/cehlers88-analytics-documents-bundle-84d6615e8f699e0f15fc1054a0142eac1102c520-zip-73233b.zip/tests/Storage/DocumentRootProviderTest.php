<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Storage;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRootProvider;
use PHPUnit\Framework\TestCase;

class DocumentRootProviderTest extends TestCase
{
    public function test_the_configured_rows_are_the_workspaces(): void
    {
        $provider = $this->createProvider([
            ['id' => '69d5b2a1c4e0f', 'name' => 'Accounting', 'description' => 'Invoices', 'path' => '/srv/accounting'],
            ['id' => '69d5b2a1c4e10', 'name' => '', 'description' => '', 'path' => 'archive'],
        ]);

        $roots = $provider->all();

        $this->assertCount(2, $roots);
        $this->assertSame('Accounting', $roots[0]->name);
        $this->assertSame('/srv/accounting', $provider->find('69d5b2a1c4e0f')->path);
        $this->assertSame('69d5b2a1c4e10', $roots[1]->name, 'a row without name is named by its id');
        $this->assertNull($provider->find('nope'));
    }

    public function test_rows_decoded_as_objects_and_incomplete_rows_are_handled(): void
    {
        $provider = $this->createProvider([
            (object)['id' => 'a1', 'name' => 'A', 'path' => '/a'],
            ['id' => '', 'name' => 'no id', 'path' => '/b'],
            ['id' => 'c1', 'name' => 'no path', 'path' => ''],
        ]);

        $this->assertSame(['a1'], array_map(static fn($root) => $root->id, $provider->all()));
    }

    public function test_nothing_configured_means_no_workspaces(): void
    {
        $this->assertSame([], $this->createProvider(null)->all());
    }

    private function createProvider(mixed $rows): DocumentRootProvider
    {
        $configurationProvider = $this->createStub(ConfigurationProvider::class);
        $configurationProvider->method('getValue')->willReturnCallback(
            static fn(string $group, string $item, int $applicationId = -1, mixed $default = null) => $item === 'documentRoots' ? ($rows ?? $default) : ''
        );

        return new DocumentRootProvider($configurationProvider);
    }
}
