<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\Upload;

use Cehlers88\AnalyticsDocumentsBundle\Upload\Exception\DocumentUploadException;
use Cehlers88\AnalyticsDocumentsBundle\Upload\UploadSource;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class UploadSourceTest extends TestCase
{
    public function test_base64_content_is_decoded(): void
    {
        $source = UploadSource::fromBase64(base64_encode('hello'), 'text/plain', 100);

        $this->assertSame(5, $source->size);
        $this->assertSame('text/plain', $source->mimeType);
        $this->assertNull($source->originalName);
    }

    public function test_a_data_url_brings_its_mime_type(): void
    {
        $source = UploadSource::fromBase64('data:application/pdf;base64,' . base64_encode('%PDF-1.4'), null, 100);

        $this->assertSame('application/pdf', $source->mimeType);
        $this->assertSame(8, $source->size);
    }

    public function test_invalid_base64_is_refused(): void
    {
        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(400);

        UploadSource::fromBase64('not base64!', null, 100);
    }

    public function test_content_larger_than_allowed_is_refused_before_decoding(): void
    {
        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(413);

        UploadSource::fromBase64(base64_encode(str_repeat('x', 200)), null, 100);
    }

    public function test_the_content_is_written_to_the_target(): void
    {
        $target = sys_get_temp_dir() . '/upload-source-' . bin2hex(random_bytes(4));

        UploadSource::fromBase64(base64_encode('hello'), null, 100)->writeTo($target);

        $this->assertSame('hello', file_get_contents($target));
        unlink($target);
    }

    public function test_an_uploaded_file_keeps_its_name(): void
    {
        $path = tempnam(sys_get_temp_dir(), 'upl');
        file_put_contents($path, 'hello');
        $file = new UploadedFile($path, 'hello.txt', 'text/plain', null, true);

        $source = UploadSource::fromUploadedFile($file, 100);
        $target = $path . '.stored';
        $source->writeTo($target);

        $this->assertSame('hello.txt', $source->originalName);
        $this->assertSame(5, $source->size);
        $this->assertSame('hello', file_get_contents($target));
        unlink($target);
    }

    public function test_a_failed_upload_is_refused(): void
    {
        $file = new UploadedFile(__FILE__, 'big.bin', null, UPLOAD_ERR_INI_SIZE, true);

        $this->expectException(DocumentUploadException::class);
        $this->expectExceptionCode(413);

        UploadSource::fromUploadedFile($file, 100);
    }
}
