<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDocumentsBundle\Tests\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\Security\Doorman;
use Cehlers88\AnalyticsDocumentsBundle\Entity\Document;
use Cehlers88\AnalyticsDocumentsBundle\Repository\DocumentRepository;
use Cehlers88\AnalyticsDocumentsBundle\ServiceEndpointRunner\DocumentUploadEndpointRunner;
use Cehlers88\AnalyticsDocumentsBundle\Storage\DocumentRootProvider;
use Cehlers88\AnalyticsDocumentsBundle\Storage\WorkspaceStorage;
use Cehlers88\AnalyticsDocumentsBundle\Upload\DocumentUploader;
use Doctrine\ORM\EntityManagerInterface;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;

class DocumentUploadEndpointRunnerTest extends TestCase
{
    private const ENDPOINT = 'AnalyticsDocumentsBundle.upload';
    private const WORKSPACE_ID = '69d5b2a1c4e0f';

    private string $root;
    /** @var Document[] */
    private array $persisted = [];

    protected function setUp(): void
    {
        $this->root = sys_get_temp_dir() . '/document-upload-' . bin2hex(random_bytes(4));
        mkdir($this->root, 0775, true);
        $this->persisted = [];
    }

    protected function tearDown(): void
    {
        exec('rm -rf ' . escapeshellarg($this->root));
    }

    public function test_a_base64_upload_is_stored_below_the_workspace_and_answers_the_document_id(): void
    {
        $result = $this->createRunner()->runEndpoint(self::ENDPOINT, $this->jsonRequest([
            'workspaceId' => self::WORKSPACE_ID,
            'content' => base64_encode('%PDF-1.4 invoice'),
            'name' => 'invoice.pdf',
            'path' => 'invoices/2026',
            'attributes' => ['customer' => 'ACME'],
        ]));

        $this->assertFalse($result->hasError, $result->message);
        $this->assertSame(1, $result->data);
        $this->assertSame('Document created', $result->message);
        $this->assertSame('%PDF-1.4 invoice', file_get_contents($this->root . '/invoices/2026/invoice.pdf'));

        $document = $this->persisted[0];
        $this->assertSame('invoices/2026/invoice.pdf', $document->getPath());
        $this->assertSame('invoice.pdf', $document->getName());
        $this->assertSame(self::WORKSPACE_ID, $document->getDocumentRootId());
        $this->assertNull($document->getWorkspace());
        $this->assertSame('ACME', $document->getAttributes()['customer']);
        $this->assertSame(16, $document->getAttributes()['file']['size']);
    }

    public function test_a_file_of_a_form_is_stored_under_its_own_name(): void
    {
        $upload = tempnam(sys_get_temp_dir(), 'upl');
        file_put_contents($upload, 'hello');
        $request = Request::create('/api/se/' . self::ENDPOINT, 'POST', ['workspaceId' => self::WORKSPACE_ID], [], [
            'file' => new UploadedFile($upload, 'hello.txt', 'text/plain', null, true),
        ]);

        $result = $this->createRunner()->runEndpoint(self::ENDPOINT, $request);

        $this->assertFalse($result->hasError, $result->message);
        $this->assertSame('hello', file_get_contents($this->root . '/hello.txt'));
        $this->assertSame('hello.txt', $this->persisted[0]->getPath());
    }

    public function test_an_existing_file_is_not_overwritten_unless_asked(): void
    {
        file_put_contents($this->root . '/invoice.pdf', 'old');
        $values = ['workspaceId' => self::WORKSPACE_ID, 'content' => base64_encode('new'), 'name' => 'invoice.pdf'];

        $refused = $this->createRunner()->runEndpoint(self::ENDPOINT, $this->jsonRequest($values));
        $replaced = $this->createRunner()->runEndpoint(self::ENDPOINT, $this->jsonRequest($values + ['overwrite' => true]));

        $this->assertSame(409, $refused->statusCode);
        $this->assertFalse($replaced->hasError, $replaced->message);
        $this->assertSame('new', file_get_contents($this->root . '/invoice.pdf'));
    }

    public function test_the_path_can_not_leave_the_workspace(): void
    {
        $result = $this->createRunner()->runEndpoint(self::ENDPOINT, $this->jsonRequest([
            'workspaceId' => self::WORKSPACE_ID,
            'content' => base64_encode('x'),
            'name' => 'passwd',
            'path' => '../../etc',
        ]));

        $this->assertSame(400, $result->statusCode);
        $this->assertSame([], $this->persisted);
    }

    public function test_an_unknown_workspace_is_answered_with_404(): void
    {
        $result = $this->createRunner()->runEndpoint(self::ENDPOINT, $this->jsonRequest([
            'workspaceId' => 'unknown',
            'content' => base64_encode('x'),
            'name' => 'a.txt',
        ]));

        $this->assertSame(404, $result->statusCode);
        $this->assertSame('Workspace "unknown" not found', $result->message);
    }

    public function test_base64_content_needs_a_name(): void
    {
        $result = $this->createRunner()->runEndpoint(self::ENDPOINT, $this->jsonRequest([
            'workspaceId' => self::WORKSPACE_ID,
            'content' => base64_encode('x'),
        ]));

        $this->assertSame(400, $result->statusCode);
        $this->assertStringContainsString('name', $result->message);
    }

    public function test_an_upload_without_file_or_content_is_refused(): void
    {
        $result = $this->createRunner()->runEndpoint(self::ENDPOINT, $this->jsonRequest(['workspaceId' => self::WORKSPACE_ID]));

        $this->assertSame(400, $result->statusCode);
    }

    public function test_the_workspace_is_required(): void
    {
        $result = $this->createRunner()->runEndpoint(self::ENDPOINT, $this->jsonRequest(['content' => base64_encode('x')]));

        $this->assertTrue($result->hasError);
        $this->assertStringContainsString('workspaceId', $result->message);
    }

    private function createRunner(): DocumentUploadEndpointRunner
    {
        $configurationProvider = $this->createStub(ConfigurationProvider::class);
        $configurationProvider->method('getValue')->willReturnCallback(fn(string $group, string $item) => match ($item) {
            // as an older installation stores it: json text of the rows
            'documentRoots' => json_encode([
                ['id' => self::WORKSPACE_ID, 'name' => 'Accounting', 'description' => '', 'path' => $this->root],
            ]),
            default => '',
        });
        $documentRootProvider = new DocumentRootProvider($configurationProvider);

        $documentRepository = $this->createStub(DocumentRepository::class);
        $documentRepository->method('findOneBy')->willReturnCallback(fn(array $criteria) => array_values(array_filter(
            $this->persisted,
            static fn(Document $document) => $document->getPath() === $criteria['path']
                && $document->getDocumentRootId() === $criteria['documentRootId']
        ))[0] ?? null);

        $entityManager = $this->createStub(EntityManagerInterface::class);
        $entityManager->method('persist')->willReturnCallback(function (Document $document): void {
            if ($document->getId() === null) {
                new \ReflectionProperty(Document::class, 'id')->setValue($document, count($this->persisted) + 1);
                $this->persisted[] = $document;
            }
        });

        $storage = new WorkspaceStorage($documentRootProvider);
        $runner = new DocumentUploadEndpointRunner(
            $documentRootProvider,
            new DocumentUploader($storage, $documentRepository, $entityManager, 1024 * 1024)
        );

        $doorman = $this->createStub(Doorman::class);
        $doorman->method('checkPermission')->willReturn(true);
        $doorman->method('getMessages')->willReturn([]);
        $doorman->method('getReasons')->willReturn([]);
        $runner->setDoorman($doorman);

        return $runner;
    }

    private function jsonRequest(array $values): Request
    {
        return Request::create('/api/se/' . self::ENDPOINT, 'POST', [], [], [], ['CONTENT_TYPE' => 'application/json'], json_encode($values));
    }
}
