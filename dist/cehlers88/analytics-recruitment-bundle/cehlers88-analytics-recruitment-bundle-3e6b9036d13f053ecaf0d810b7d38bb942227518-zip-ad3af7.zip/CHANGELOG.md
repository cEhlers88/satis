# Changelog

## 1.0.0 (2026-09-27)


### Miscellaneous Chores

* Add GitHub Actions workflows for automated releases and Satis rebuild trigger ([46a466e](https://github.com/cEhlers88/AnalyticsRecruitmentBundle/commit/46a466e38e660524ec49825284625ae74ebc6bb5))
* Add RecruitmentBundle for managing references and access links ([ea96865](https://github.com/cEhlers88/AnalyticsRecruitmentBundle/commit/ea96865b7bb384ca28cf24fb5feeed5c235e010b))
