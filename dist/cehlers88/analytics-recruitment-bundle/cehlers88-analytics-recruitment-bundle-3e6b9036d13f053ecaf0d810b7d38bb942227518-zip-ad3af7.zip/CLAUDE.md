# CLAUDE.md

Guidance for AI assistants working in this repository.

## What this repository is

`cehlers88/analytics-recruitment-bundle` is a **Symfony bundle plugin** for the Analytics
platform supporting the job application process. So far: references (portfolio projects with
texts, facts, images), access links (UUID) that show them publicly under `/references/{uuid}`,
and the visits counted through each link. See README.md.

It is a **library, not an application**: no kernel, no `bin/console`. It is loaded by the host
application `analytics.c-ehlers.de` (sibling directory), which registers it in
`config/bundles.php`, imports `src/Resources/config/services.yaml` and the `templates/` path.

| | |
|---|---|
| Package type | `symfony-bundle`, license `proprietary` |
| PSR-4 root | `Cehlers88\AnalyticsRecruitmentBundle\` → `src/` |
| Hard dependency | `cehlers88/analytics-core` (`1.*@dev`) |
| PHP | 8.4+ |
| Distribution | private Satis at `https://cehlers88.github.io/satis` (rebuilt on release) |
| Versioning | release-please, Conventional Commits |

## Conventions

Follow the sibling bundles (`AnalyticsInfrastructureBundle`, `AnalyticsDocumentsBundle`):

- **Permissions are not checked in code** beyond `ROLE_DASHBOARD`/`ROLE_ADMIN`: who may use the
  tool is configured in the tool settings (database), and the application's ToolAccess guards the
  tool's `routes`. No voters. `EPermission` only declares roles so they can be picked there.
- The plugin class extends `Cehlers88\AnalyticsCore\Support\AbstractBundlePlugin`; menu items are
  `MenuItemDTO`s that must point at an existing route.
- Permissions live in `ENUM\EPermission`; enums are otherwise `e`-prefixed.
- Services are autowired/autoconfigured; tags come from `_instanceof` or directory resources in
  `services.yaml`. A directory resource must not be enabled before the directory has a class.
- Entities: `#[ORM\Table(name: 'recruitment_…')]` prefix; the host app needs a migration.
- Controllers: routes `/admin_api/recruitment/...`, names `analytics_recruitment_...`; the host
  app imports `@AnalyticsRecruitmentBundle/Controller/` in `config/routes/`.
- UI texts in German; the host translates them via `translations/messages.{de,en}.yaml`.

## Verifying

```bash
composer install && ./vendor/bin/phpunit
find src tests -name "*.php" -print0 | xargs -0 -n1 php -l
```

Tests that need Doctrine/core classes run best against the host's autoloader:
`./vendor/bin/phpunit --bootstrap ../analytics.c-ehlers.de/vendor/autoload.php`.
