<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Entity;

use Cehlers88\AnalyticsRecruitmentBundle\Repository\ReferenceRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * A station of the portfolio - a web project worked on, with what it was about, the
 * technologies, further facts (client, role, team …), screenshots and content rows.
 *
 * Only published references are shown through an access link.
 */
#[ORM\Entity(repositoryClass: ReferenceRepository::class)]
#[ORM\Table(name: 'recruitment_reference')]
#[ORM\HasLifecycleCallbacks]
class Reference
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 160)]
    private string $title = '';

    /** Role, client or kind of project - the line below the title. */
    #[ORM\Column(length: 160, nullable: true)]
    private ?string $subtitle = null;

    /** Free text, e.g. "03/2021 – 08/2023". */
    #[ORM\Column(length: 80, nullable: true)]
    private ?string $period = null;

    #[ORM\Column(length: 500, nullable: true)]
    private ?string $url = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    /** @var list<string> */
    #[ORM\Column(type: Types::JSON)]
    private array $technologies = [];

    /** @var list<array{label: string, value: string}> */
    #[ORM\Column(type: Types::JSON)]
    private array $facts = [];

    /**
     * Rows below the introduction, each of one to five columns holding a text or an image
     * of this reference, optionally coloured and as a banner over the whole width of the
     * page (ReferenceInput checks the shape):
     *
     *     [{"columns": [{"type": "text", "text": "…"}, {"type": "image", "imageId": 12, "caption": "…"}],
     *       "background": "#1a1a1a" | null, "color": "#ffffff" | null, "banner": false}]
     *
     * @var list<array{columns: list<array<string, mixed>>, background?: ?string, color?: ?string, banner?: bool}>
     */
    #[ORM\Column(type: Types::JSON)]
    private array $contentRows = [];

    #[ORM\Column]
    private int $position = 0;

    #[ORM\Column]
    private bool $published = true;

    #[ORM\Column]
    private \DateTimeImmutable $createdAt;

    #[ORM\Column]
    private \DateTimeImmutable $updatedAt;

    /** @var Collection<int, ReferenceImage> */
    #[ORM\OneToMany(targetEntity: ReferenceImage::class, mappedBy: 'reference', cascade: ['persist', 'remove'], orphanRemoval: true)]
    #[ORM\OrderBy(['position' => 'ASC', 'id' => 'ASC'])]
    private Collection $images;

    public function __construct()
    {
        $this->images = new ArrayCollection();
        $this->createdAt = new \DateTimeImmutable();
        $this->updatedAt = $this->createdAt;
    }

    #[ORM\PreUpdate]
    public function touch(): void
    {
        $this->updatedAt = new \DateTimeImmutable();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function setTitle(string $title): static
    {
        $this->title = $title;

        return $this;
    }

    public function getSubtitle(): ?string
    {
        return $this->subtitle;
    }

    public function setSubtitle(?string $subtitle): static
    {
        $this->subtitle = $subtitle;

        return $this;
    }

    public function getPeriod(): ?string
    {
        return $this->period;
    }

    public function setPeriod(?string $period): static
    {
        $this->period = $period;

        return $this;
    }

    public function getUrl(): ?string
    {
        return $this->url;
    }

    public function setUrl(?string $url): static
    {
        $this->url = $url;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    /** @return list<string> */
    public function getTechnologies(): array
    {
        return $this->technologies;
    }

    /** @param list<string> $technologies */
    public function setTechnologies(array $technologies): static
    {
        $this->technologies = $technologies;

        return $this;
    }

    /** @return list<array{label: string, value: string}> */
    public function getFacts(): array
    {
        return $this->facts;
    }

    /** @param list<array{label: string, value: string}> $facts */
    public function setFacts(array $facts): static
    {
        $this->facts = $facts;

        return $this;
    }

    /** @return list<array{columns: list<array<string, mixed>>}> */
    public function getContentRows(): array
    {
        return $this->contentRows;
    }

    /** @param list<array{columns: list<array<string, mixed>>}> $contentRows */
    public function setContentRows(array $contentRows): static
    {
        $this->contentRows = $contentRows;

        return $this;
    }

    /** @return list<int> the images the content rows show */
    public function getContentImageIds(): array
    {
        $ids = [];
        foreach ($this->contentRows as $row) {
            foreach ($row['columns'] ?? [] as $column) {
                if (($column['type'] ?? null) === 'image' && is_int($column['imageId'] ?? null)) {
                    $ids[] = $column['imageId'];
                }
            }
        }

        return $ids;
    }

    public function getPosition(): int
    {
        return $this->position;
    }

    public function setPosition(int $position): static
    {
        $this->position = $position;

        return $this;
    }

    public function isPublished(): bool
    {
        return $this->published;
    }

    public function setPublished(bool $published): static
    {
        $this->published = $published;

        return $this;
    }

    public function getCreatedAt(): \DateTimeImmutable
    {
        return $this->createdAt;
    }

    public function getUpdatedAt(): \DateTimeImmutable
    {
        return $this->updatedAt;
    }

    /** @return Collection<int, ReferenceImage> */
    public function getImages(): Collection
    {
        return $this->images;
    }

    /**
     * The screenshots in their order - also right after a reordering, when the loaded
     * collection still has the old one.
     *
     * @return list<ReferenceImage>
     */
    public function getGalleryImages(): array
    {
        $images = array_values(array_filter($this->images->toArray(), static fn(ReferenceImage $image): bool => $image->isGalleryImage()));
        usort($images, static fn(ReferenceImage $left, ReferenceImage $right): int => [$left->getPosition(), $left->getId()] <=> [$right->getPosition(), $right->getId()]);

        return $images;
    }

    public function findImage(int $id): ?ReferenceImage
    {
        foreach ($this->images as $image) {
            if ($image->getId() === $id) {
                return $image;
            }
        }

        return null;
    }

    /** What stands for the reference on the overview: the first screenshot, else an image of its rows. */
    public function getCoverImage(): ?ReferenceImage
    {
        $gallery = $this->getGalleryImages();
        if ($gallery !== []) {
            return $gallery[0];
        }
        foreach ($this->getContentImageIds() as $id) {
            if (($image = $this->findImage($id)) !== null) {
                return $image;
            }
        }

        return null;
    }

    public function addImage(ReferenceImage $image): static
    {
        if (!$this->images->contains($image)) {
            $this->images->add($image);
            $image->setReference($this);
        }

        return $this;
    }

    public function removeImage(ReferenceImage $image): static
    {
        $this->images->removeElement($image);

        return $this;
    }
}
