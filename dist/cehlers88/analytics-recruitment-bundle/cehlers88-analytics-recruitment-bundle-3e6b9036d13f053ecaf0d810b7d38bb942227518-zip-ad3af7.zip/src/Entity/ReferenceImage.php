<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Entity;

use Cehlers88\AnalyticsRecruitmentBundle\Repository\ReferenceImageRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * An image of a reference; the file itself is kept by ReferenceImageStorage.
 *
 * Either one of the gallery (screenshots, in their own order) or one shown in a column of a
 * content row (Reference::$contentRows names it by id).
 */
#[ORM\Entity(repositoryClass: ReferenceImageRepository::class)]
#[ORM\Table(name: 'recruitment_reference_image')]
class ReferenceImage
{
    public const CONTEXT_GALLERY = 'gallery';
    public const CONTEXT_CONTENT = 'content';

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'images')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private ?Reference $reference = null;

    /** The id of the stored file, e.g. "3f2a9c0d1b7e4a55.png". */
    #[ORM\Column(length: 40, unique: true)]
    private string $file = '';

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $caption = null;

    #[ORM\Column]
    private int $position = 0;

    #[ORM\Column(length: 20, options: ['default' => self::CONTEXT_GALLERY])]
    private string $context = self::CONTEXT_GALLERY;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getReference(): ?Reference
    {
        return $this->reference;
    }

    public function setReference(?Reference $reference): static
    {
        $this->reference = $reference;

        return $this;
    }

    public function getFile(): string
    {
        return $this->file;
    }

    public function setFile(string $file): static
    {
        $this->file = $file;

        return $this;
    }

    public function getCaption(): ?string
    {
        return $this->caption;
    }

    public function setCaption(?string $caption): static
    {
        $this->caption = $caption;

        return $this;
    }

    public function getPosition(): int
    {
        return $this->position;
    }

    public function setPosition(int $position): static
    {
        $this->position = $position;

        return $this;
    }

    public function getContext(): string
    {
        return $this->context;
    }

    public function setContext(string $context): static
    {
        $this->context = $context === self::CONTEXT_CONTENT ? self::CONTEXT_CONTENT : self::CONTEXT_GALLERY;

        return $this;
    }

    public function isGalleryImage(): bool
    {
        return $this->context === self::CONTEXT_GALLERY;
    }
}
