<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Entity;

use Cehlers88\AnalyticsRecruitmentBundle\ENUM\eDocumentCategory;
use Cehlers88\AnalyticsRecruitmentBundle\Repository\ApplicationDocumentRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * A document of the application - the CV, a reference letter, a certificate - that an
 * access link shows next to the references. The file (PDF or image) is kept by
 * DocumentStorage; replacing it keeps the entry, so the CV can be brought up to date.
 */
#[ORM\Entity(repositoryClass: ApplicationDocumentRepository::class)]
#[ORM\Table(name: 'recruitment_document')]
#[ORM\HasLifecycleCallbacks]
class ApplicationDocument
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 160)]
    private string $title = '';

    #[ORM\Column(length: 30, enumType: eDocumentCategory::class)]
    private eDocumentCategory $category = eDocumentCategory::OTHER;

    /** Who issued it - employer, chamber, vendor of the certificate. */
    #[ORM\Column(length: 160, nullable: true)]
    private ?string $issuer = null;

    /** Free text, e.g. "06/2021". */
    #[ORM\Column(length: 40, nullable: true)]
    private ?string $issuedOn = null;

    /** The id of the stored file, e.g. "3f2a9c0d1b7e4a55.pdf". */
    #[ORM\Column(length: 40, unique: true)]
    private string $file = '';

    #[ORM\Column(length: 255)]
    private string $originalName = '';

    #[ORM\Column]
    private int $size = 0;

    #[ORM\Column]
    private int $position = 0;

    #[ORM\Column]
    private bool $published = true;

    #[ORM\Column]
    private \DateTimeImmutable $updatedAt;

    public function __construct()
    {
        $this->updatedAt = new \DateTimeImmutable();
    }

    #[ORM\PreUpdate]
    public function touch(): void
    {
        $this->updatedAt = new \DateTimeImmutable();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function setTitle(string $title): static
    {
        $this->title = $title;

        return $this;
    }

    public function getCategory(): eDocumentCategory
    {
        return $this->category;
    }

    public function setCategory(eDocumentCategory $category): static
    {
        $this->category = $category;

        return $this;
    }

    public function isCv(): bool
    {
        return $this->category === eDocumentCategory::CV;
    }

    public function getIssuer(): ?string
    {
        return $this->issuer;
    }

    public function setIssuer(?string $issuer): static
    {
        $this->issuer = $issuer;

        return $this;
    }

    public function getIssuedOn(): ?string
    {
        return $this->issuedOn;
    }

    public function setIssuedOn(?string $issuedOn): static
    {
        $this->issuedOn = $issuedOn;

        return $this;
    }

    public function getFile(): string
    {
        return $this->file;
    }

    public function isPdf(): bool
    {
        return str_ends_with($this->file, '.pdf');
    }

    public function getOriginalName(): string
    {
        return $this->originalName;
    }

    public function getSize(): int
    {
        return $this->size;
    }

    /** Takes a newly stored file - the one before is the caller's to remove. */
    public function setStoredFile(string $file, string $originalName, int $size): static
    {
        $this->file = $file;
        $this->originalName = mb_substr($originalName, 0, 255);
        $this->size = $size;

        return $this;
    }

    public function getPosition(): int
    {
        return $this->position;
    }

    public function setPosition(int $position): static
    {
        $this->position = $position;

        return $this;
    }

    public function isPublished(): bool
    {
        return $this->published;
    }

    public function setPublished(bool $published): static
    {
        $this->published = $published;

        return $this;
    }

    public function getUpdatedAt(): \DateTimeImmutable
    {
        return $this->updatedAt;
    }
}
