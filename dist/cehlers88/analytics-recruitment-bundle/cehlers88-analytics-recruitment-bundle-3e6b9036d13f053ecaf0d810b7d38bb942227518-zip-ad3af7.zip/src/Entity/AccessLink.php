<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Entity;

use Cehlers88\AnalyticsRecruitmentBundle\Repository\AccessLinkRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Uid\Uuid;

/**
 * A link that lets somebody who is not signed in look at the published references.
 *
 * The random UUID (v4) is what the link consists of - it cannot be guessed, and every
 * visit through it is counted (AccessLinkVisit), so it shows how the link is used. One
 * link per recipient (the label says whose it is) tells the recipients apart.
 */
#[ORM\Entity(repositoryClass: AccessLinkRepository::class)]
#[ORM\Table(name: 'recruitment_access_link')]
class AccessLink
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 36, unique: true)]
    private string $uuid;

    /** Whom the link was made for, e.g. "Muster GmbH – Frontend-Entwickler". */
    #[ORM\Column(length: 160)]
    private string $label = '';

    #[ORM\Column]
    private bool $active = true;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $expiresAt = null;

    #[ORM\Column]
    private \DateTimeImmutable $createdAt;

    #[ORM\Column]
    private int $visitCount = 0;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $firstVisitedAt = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $lastVisitedAt = null;

    public function __construct()
    {
        $this->uuid = Uuid::v4()->toRfc4122();
        $this->createdAt = new \DateTimeImmutable();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUuid(): string
    {
        return $this->uuid;
    }

    public function getLabel(): string
    {
        return $this->label;
    }

    public function setLabel(string $label): static
    {
        $this->label = $label;

        return $this;
    }

    public function isActive(): bool
    {
        return $this->active;
    }

    public function setActive(bool $active): static
    {
        $this->active = $active;

        return $this;
    }

    public function getExpiresAt(): ?\DateTimeImmutable
    {
        return $this->expiresAt;
    }

    public function setExpiresAt(?\DateTimeImmutable $expiresAt): static
    {
        $this->expiresAt = $expiresAt;

        return $this;
    }

    public function isExpired(?\DateTimeImmutable $now = null): bool
    {
        return $this->expiresAt !== null && $this->expiresAt <= ($now ?? new \DateTimeImmutable());
    }

    /** Whether the link opens the references right now. */
    public function isUsable(?\DateTimeImmutable $now = null): bool
    {
        return $this->active && !$this->isExpired($now);
    }

    public function getCreatedAt(): \DateTimeImmutable
    {
        return $this->createdAt;
    }

    public function getVisitCount(): int
    {
        return $this->visitCount;
    }

    public function getFirstVisitedAt(): ?\DateTimeImmutable
    {
        return $this->firstVisitedAt;
    }

    public function getLastVisitedAt(): ?\DateTimeImmutable
    {
        return $this->lastVisitedAt;
    }

    public function recordVisit(\DateTimeImmutable $at): static
    {
        $this->visitCount++;
        $this->firstVisitedAt ??= $at;
        $this->lastVisitedAt = $at;

        return $this;
    }
}
