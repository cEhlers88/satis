<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Entity;

use Cehlers88\AnalyticsRecruitmentBundle\Repository\AccessLinkVisitRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * One page view through an access link - the overview, a single reference or a document
 * (the CV, a certificate) that was opened or downloaded.
 *
 * The IP address is stored shortened (AccessLinkTracker), the referrer without its query.
 */
#[ORM\Entity(repositoryClass: AccessLinkVisitRepository::class)]
#[ORM\Table(name: 'recruitment_access_link_visit')]
#[ORM\Index(name: 'recruitment_visit_link_time_idx', columns: ['access_link_id', 'visited_at'])]
class AccessLinkVisit
{
    public const PAGE_OVERVIEW = 'overview';
    public const PAGE_REFERENCE = 'reference';
    public const PAGE_DOCUMENT = 'document';

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private AccessLink $accessLink;

    /** The reference that was looked at; null on the overview or when it was deleted since. */
    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?Reference $reference = null;

    /** The document that was opened; null on the other pages or when it was deleted since. */
    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?ApplicationDocument $document = null;

    #[ORM\Column(length: 20)]
    private string $page;

    #[ORM\Column]
    private \DateTimeImmutable $visitedAt;

    #[ORM\Column(length: 45, nullable: true)]
    private ?string $ipAddress = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $userAgent = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $referer = null;

    public function __construct(AccessLink $accessLink, string $page, ?Reference $reference = null, ?\DateTimeImmutable $visitedAt = null)
    {
        $this->accessLink = $accessLink;
        $this->page = $page;
        $this->reference = $reference;
        $this->visitedAt = $visitedAt ?? new \DateTimeImmutable();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getAccessLink(): AccessLink
    {
        return $this->accessLink;
    }

    public function getReference(): ?Reference
    {
        return $this->reference;
    }

    public function getDocument(): ?ApplicationDocument
    {
        return $this->document;
    }

    public function setDocument(?ApplicationDocument $document): static
    {
        $this->document = $document;

        return $this;
    }

    public function getPage(): string
    {
        return $this->page;
    }

    public function getVisitedAt(): \DateTimeImmutable
    {
        return $this->visitedAt;
    }

    public function getIpAddress(): ?string
    {
        return $this->ipAddress;
    }

    public function setIpAddress(?string $ipAddress): static
    {
        $this->ipAddress = $ipAddress;

        return $this;
    }

    public function getUserAgent(): ?string
    {
        return $this->userAgent;
    }

    public function setUserAgent(?string $userAgent): static
    {
        $this->userAgent = $userAgent;

        return $this;
    }

    public function getReferer(): ?string
    {
        return $this->referer;
    }

    public function setReferer(?string $referer): static
    {
        $this->referer = $referer;

        return $this;
    }
}
