<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\ApplicationDocument;
use Cehlers88\AnalyticsRecruitmentBundle\ENUM\eDocumentCategory;

/** Takes what the editor sends for a document: title, category, issuer, issuedOn, published. */
final class DocumentInput
{
    /**
     * @param array<string, mixed> $data
     * @throws \InvalidArgumentException naming what is wrong
     */
    public static function apply(ApplicationDocument $document, array $data): ApplicationDocument
    {
        $title = self::line($data['title'] ?? '', 160, 'Der Titel');
        if ($title === null) {
            throw new \InvalidArgumentException('Ein Dokument braucht einen Titel, z. B. "Lebenslauf" oder "AWS Solutions Architect".');
        }
        $category = eDocumentCategory::tryFrom((string)($data['category'] ?? ''));
        if ($category === null) {
            throw new \InvalidArgumentException('Unbekannte Art des Dokuments.');
        }

        return $document
            ->setTitle($title)
            ->setCategory($category)
            ->setIssuer(self::line($data['issuer'] ?? null, 160, 'Der Aussteller'))
            ->setIssuedOn(self::line($data['issuedOn'] ?? null, 40, 'Das Datum'))
            ->setPublished(array_key_exists('published', $data) ? in_array($data['published'], [true, 'true', '1', 1], true) : $document->isPublished());
    }

    private static function line(mixed $value, int $maxLength, string $name): ?string
    {
        if ($value === null) {
            return null;
        }
        if (!is_string($value)) {
            throw new \InvalidArgumentException(sprintf('%s muss ein Text sein.', $name));
        }
        $value = trim(preg_replace('/\s+/u', ' ', $value) ?? '');
        if (mb_strlen($value) > $maxLength) {
            throw new \InvalidArgumentException(sprintf('%s darf höchstens %d Zeichen lang sein.', $name, $maxLength));
        }

        return $value === '' ? null : $value;
    }
}
