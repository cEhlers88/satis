<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLink;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLinkVisit;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\ApplicationDocument;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\Reference;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\HttpFoundation\Request;

/**
 * Counts a page view through an access link.
 *
 * Kept is what tells how the link is used - when, which page, which browser, where it
 * came from - but not who exactly: the IP address loses its host part, the referrer its
 * query. Whoever is signed in to the installation is not counted - that is the owner
 * previewing their own link, not interest from outside.
 */
final class AccessLinkTracker
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly Security               $security,
    ) {
    }

    public function track(AccessLink $link, Request $request, string $page, ?Reference $reference = null, ?ApplicationDocument $document = null): void
    {
        if ($this->security->getUser() !== null) {
            return;
        }

        $now = new \DateTimeImmutable();
        $visit = new AccessLinkVisit($link, $page, $reference, $now);
        $visit
            ->setDocument($document)
            ->setIpAddress(self::anonymizeIp($request->getClientIp()))
            ->setUserAgent(self::shorten($request->headers->get('User-Agent'), 255))
            ->setReferer(self::shorten(self::stripReferer($request->headers->get('Referer')), 255));
        $link->recordVisit($now);

        $this->entityManager->persist($visit);
        $this->entityManager->flush();
    }

    /** 203.0.113.57 → 203.0.113.0, 2001:db8:85a3:8d3::1 → 2001:db8:85a3:: */
    public static function anonymizeIp(?string $ip): ?string
    {
        if ($ip === null || $ip === '') {
            return null;
        }
        $packed = @inet_pton($ip);
        if ($packed === false) {
            return null;
        }
        $mask = strlen($packed) === 4
            ? "\xff\xff\xff\x00"
            : str_repeat("\xff", 6) . str_repeat("\x00", 10);

        return inet_ntop($packed & $mask) ?: null;
    }

    /** https://example.com/jobs/42?utm=… → https://example.com/jobs/42 */
    public static function stripReferer(?string $referer): ?string
    {
        if ($referer === null || $referer === '') {
            return null;
        }
        $parts = parse_url($referer);
        if (!is_array($parts) || !isset($parts['scheme'], $parts['host'])) {
            return null;
        }

        return $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '') . ($parts['path'] ?? '');
    }

    private static function shorten(?string $value, int $length): ?string
    {
        if ($value === null || trim($value) === '') {
            return null;
        }

        return mb_substr(trim($value), 0, $length);
    }
}
