<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLink;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLinkVisit;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\ApplicationDocument;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\Reference;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\ReferenceImage;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

/** What the editor of the dashboard gets to see of references, documents, access links and visits. */
final class RecruitmentSerializer
{
    public function __construct(private readonly UrlGeneratorInterface $urlGenerator)
    {
    }

    /** @return array<string, mixed> */
    public function reference(Reference $reference): array
    {
        return [
            'id' => $reference->getId(),
            'title' => $reference->getTitle(),
            'subtitle' => $reference->getSubtitle(),
            'period' => $reference->getPeriod(),
            'url' => $reference->getUrl(),
            'description' => $reference->getDescription(),
            'technologies' => $reference->getTechnologies(),
            'facts' => $reference->getFacts(),
            'published' => $reference->isPublished(),
            'position' => $reference->getPosition(),
            'updatedAt' => $reference->getUpdatedAt()->format(DATE_ATOM),
            'images' => array_map($this->image(...), $reference->getGalleryImages()),
            'rows' => $this->contentRows($reference),
        ];
    }

    /** @return list<array<string, mixed>> the rows, an image column with the url of its image */
    private function contentRows(Reference $reference): array
    {
        $rows = [];
        foreach (ContentRows::resolve($reference) as $row) {
            $row['columns'] = array_map(fn(array $column): array => $column['type'] !== 'image' ? $column : [
                'type' => 'image',
                'imageId' => $column['image']->getId(),
                'caption' => $column['caption'],
                'url' => $this->image($column['image'])['url'],
            ], $row['columns']);
            $rows[] = $row;
        }

        return $rows;
    }

    /** @return array<string, mixed> */
    public function image(ReferenceImage $image): array
    {
        return [
            'id' => $image->getId(),
            'file' => $image->getFile(),
            'caption' => $image->getCaption(),
            'url' => $this->urlGenerator->generate('analytics_recruitment_admin_image', ['file' => $image->getFile()]),
        ];
    }

    /** @return array<string, mixed> */
    public function document(ApplicationDocument $document): array
    {
        return [
            'id' => $document->getId(),
            'title' => $document->getTitle(),
            'category' => $document->getCategory()->value,
            'categoryLabel' => $document->getCategory()->label(),
            'issuer' => $document->getIssuer(),
            'issuedOn' => $document->getIssuedOn(),
            'published' => $document->isPublished(),
            'pdf' => $document->isPdf(),
            'originalName' => $document->getOriginalName(),
            'size' => $document->getSize(),
            'updatedAt' => $document->getUpdatedAt()->format(DATE_ATOM),
            'url' => $this->urlGenerator->generate('analytics_recruitment_admin_document_file', ['id' => $document->getId()]),
        ];
    }

    /** @return array<string, mixed> */
    public function accessLink(AccessLink $link): array
    {
        return [
            'id' => $link->getId(),
            'uuid' => $link->getUuid(),
            'label' => $link->getLabel(),
            'active' => $link->isActive(),
            'usable' => $link->isUsable(),
            'expiresAt' => $link->getExpiresAt()?->format('Y-m-d'),
            'createdAt' => $link->getCreatedAt()->format(DATE_ATOM),
            'visitCount' => $link->getVisitCount(),
            'firstVisitedAt' => $link->getFirstVisitedAt()?->format(DATE_ATOM),
            'lastVisitedAt' => $link->getLastVisitedAt()?->format(DATE_ATOM),
            'url' => $this->urlGenerator->generate(
                'analytics_recruitment_public_overview',
                ['uuid' => $link->getUuid()],
                UrlGeneratorInterface::ABSOLUTE_URL
            ),
        ];
    }

    /** @return array<string, mixed> */
    public function visit(AccessLinkVisit $visit): array
    {
        return [
            'id' => $visit->getId(),
            'visitedAt' => $visit->getVisitedAt()->format(DATE_ATOM),
            'page' => $visit->getPage(),
            'reference' => $visit->getReference() === null ? null : [
                'id' => $visit->getReference()->getId(),
                'title' => $visit->getReference()->getTitle(),
            ],
            'document' => $visit->getDocument() === null ? null : [
                'id' => $visit->getDocument()->getId(),
                'title' => $visit->getDocument()->getTitle(),
            ],
            'ipAddress' => $visit->getIpAddress(),
            'userAgent' => $visit->getUserAgent(),
            'referer' => $visit->getReferer(),
        ];
    }
}
