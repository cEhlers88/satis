<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\Reference;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\ReferenceImage;

/** The content rows of a reference with their images looked up - what editor and pages show. */
final class ContentRows
{
    /**
     * An image column whose image is gone (it cannot be, ReferenceInput checks it - but a
     * row must never break a page) is left out.
     *
     * @return list<array{
     *     columns: list<array{type: 'text', text: string}|array{type: 'image', image: ReferenceImage, caption: ?string}>,
     *     background: ?string, color: ?string, banner: bool
     * }>
     */
    public static function resolve(Reference $reference): array
    {
        $rows = [];
        foreach ($reference->getContentRows() as $row) {
            $columns = [];
            foreach ($row['columns'] ?? [] as $column) {
                if (($column['type'] ?? null) === 'text') {
                    $columns[] = ['type' => 'text', 'text' => (string)($column['text'] ?? '')];
                } elseif (($column['type'] ?? null) === 'image' && ($image = $reference->findImage((int)($column['imageId'] ?? 0))) !== null) {
                    $columns[] = ['type' => 'image', 'image' => $image, 'caption' => $column['caption'] ?? null];
                }
            }
            if ($columns !== []) {
                $rows[] = [
                    'columns' => $columns,
                    'background' => $row['background'] ?? null,
                    'color' => $row['color'] ?? null,
                    'banner' => ($row['banner'] ?? false) === true,
                ];
            }
        }

        return $rows;
    }
}
