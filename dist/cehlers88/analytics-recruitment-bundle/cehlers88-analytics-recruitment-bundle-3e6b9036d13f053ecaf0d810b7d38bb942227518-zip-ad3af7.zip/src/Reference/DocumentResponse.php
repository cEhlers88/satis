<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\ApplicationDocument;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

/** A document as the browser gets it - shown in its viewer, or as a download named after its title. */
final class DocumentResponse
{
    public static function create(string $path, ApplicationDocument $document, bool $download): BinaryFileResponse
    {
        $response = new BinaryFileResponse($path, 200, [], false, null, false, true);
        // the type is the one the content was recognised as on upload - never guessed again
        $response->headers->set('Content-Type', DocumentStorage::mimeTypeOf($document->getFile()));
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        if (!$document->isPdf()) {
            $response->headers->set('Content-Security-Policy', "default-src 'none'; img-src 'self'; sandbox");
        }
        $name = self::fileName($document);
        $response->setContentDisposition(
            $download ? ResponseHeaderBag::DISPOSITION_ATTACHMENT : ResponseHeaderBag::DISPOSITION_INLINE,
            $name,
            (string)preg_replace('/[^\x20-\x7E]|[%"\/\\\\]/', '_', $name) ?: 'dokument',
        );

        return $response;
    }

    /** "Lebenslauf Max Mustermann.pdf" - the title, not the name the file had on upload. */
    public static function fileName(ApplicationDocument $document): string
    {
        $title = trim((string)preg_replace(['/[\/\\\\:*?"<>|\x00-\x1F]+/u', '/\s+/u'], ' ', $document->getTitle()));

        return ($title !== '' ? $title : 'Dokument') . '.' . pathinfo($document->getFile(), PATHINFO_EXTENSION);
    }
}
