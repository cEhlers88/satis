<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLink;

/** Takes what the editor sends for an access link: label, active, expiresAt ("YYYY-MM-DD" or empty). */
final class AccessLinkInput
{
    /**
     * @param array<string, mixed> $data
     * @throws \InvalidArgumentException naming what is wrong
     */
    public static function apply(AccessLink $link, array $data): AccessLink
    {
        $label = is_string($data['label'] ?? null) ? trim(preg_replace('/\s+/u', ' ', $data['label']) ?? '') : '';
        if ($label === '') {
            throw new \InvalidArgumentException('Ein Zugriffslink braucht eine Bezeichnung - für wen ist er?');
        }
        if (mb_strlen($label) > 160) {
            throw new \InvalidArgumentException('Die Bezeichnung darf höchstens 160 Zeichen lang sein.');
        }

        $expiresAt = $link->getExpiresAt();
        if (array_key_exists('expiresAt', $data)) {
            $expiresAt = self::endOfDay($data['expiresAt']);
        }

        return $link
            ->setLabel($label)
            ->setActive(array_key_exists('active', $data) ? $data['active'] === true : $link->isActive())
            ->setExpiresAt($expiresAt);
    }

    /** A link valid "until" a day is valid all of that day. */
    private static function endOfDay(mixed $value): ?\DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }
        $date = is_string($value) ? \DateTimeImmutable::createFromFormat('!Y-m-d', $value) : false;
        if ($date === false || $date->format('Y-m-d') !== $value) {
            throw new \InvalidArgumentException('Das Ablaufdatum ist kein gültiges Datum.');
        }

        return $date->setTime(23, 59, 59);
    }
}
