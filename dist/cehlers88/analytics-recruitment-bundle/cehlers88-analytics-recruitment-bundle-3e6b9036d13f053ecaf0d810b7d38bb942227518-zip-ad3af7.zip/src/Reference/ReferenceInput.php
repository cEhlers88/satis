<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\Reference;

/**
 * Takes what the editor sends for a reference - checked field by field, trimmed, and only
 * then written to the entity, so a refused input leaves the reference as it was.
 */
final class ReferenceInput
{
    public const MAX_TECHNOLOGIES = 40;
    public const MAX_FACTS = 30;
    public const MAX_DESCRIPTION = 20000;
    public const MAX_ROWS = 30;
    public const MAX_COLUMNS = 5;
    public const MAX_COLUMN_TEXT = 5000;

    /**
     * @param array<string, mixed> $data title, subtitle, period, url, description,
     *                                   technologies (list of strings), facts (list of
     *                                   {label, value}), published, rows (list of
     *                                   {columns: list of {type: text, text} or
     *                                   {type: image, imageId, caption}, background,
     *                                   color ("#rrggbb" or empty), banner) - an image
     *                                   has to be a content image of this reference
     * @throws \InvalidArgumentException naming what is wrong
     */
    public static function apply(Reference $reference, array $data): Reference
    {
        $title = self::text($data['title'] ?? '', 160, 'Der Titel');
        if ($title === null) {
            throw new \InvalidArgumentException('Eine Referenz braucht einen Titel.');
        }
        $subtitle = self::text($data['subtitle'] ?? null, 160, 'Die Unterzeile');
        $period = self::text($data['period'] ?? null, 80, 'Der Zeitraum');
        $url = self::url($data['url'] ?? null);
        $description = self::text($data['description'] ?? null, self::MAX_DESCRIPTION, 'Die Beschreibung', true);
        $technologies = self::technologies($data['technologies'] ?? []);
        $facts = self::facts($data['facts'] ?? []);
        $rows = array_key_exists('rows', $data) ? self::rows($data['rows'], $reference) : $reference->getContentRows();

        return $reference
            ->setTitle($title)
            ->setSubtitle($subtitle)
            ->setPeriod($period)
            ->setUrl($url)
            ->setDescription($description)
            ->setTechnologies($technologies)
            ->setFacts($facts)
            ->setContentRows($rows)
            ->setPublished(($data['published'] ?? $reference->isPublished()) === true);
    }

    private static function text(mixed $value, int $maxLength, string $name, bool $multiLine = false): ?string
    {
        if ($value === null) {
            return null;
        }
        if (!is_string($value) && !is_int($value) && !is_float($value)) {
            throw new \InvalidArgumentException(sprintf('%s muss ein Text sein.', $name));
        }
        $value = str_replace("\r\n", "\n", (string)$value);
        $value = trim($multiLine ? $value : preg_replace('/\s+/u', ' ', $value) ?? '');
        if (mb_strlen($value) > $maxLength) {
            throw new \InvalidArgumentException(sprintf('%s darf höchstens %d Zeichen lang sein.', $name, $maxLength));
        }

        return $value === '' ? null : $value;
    }

    private static function url(mixed $value): ?string
    {
        $url = self::text($value, 500, 'Die Adresse');
        if ($url === null) {
            return null;
        }
        // "shop.example.com" becomes https://…, "javascript:…" or "ftp://…" is refused
        if (preg_match('~^[a-z][a-z0-9+.-]*:(?!\d)~i', $url) !== 1) {
            $url = 'https://' . $url;
        }
        // only http(s) - the address becomes a link on a public page
        if (filter_var($url, FILTER_VALIDATE_URL) === false || !in_array(strtolower((string)parse_url($url, PHP_URL_SCHEME)), ['http', 'https'], true)) {
            throw new \InvalidArgumentException(sprintf('"%s" ist keine gültige Webadresse.', $url));
        }

        return $url;
    }

    /** @return list<string> */
    private static function technologies(mixed $value): array
    {
        if (is_string($value)) {
            $value = explode(',', $value);
        }
        if (!is_array($value)) {
            throw new \InvalidArgumentException('Die Technologien müssen eine Liste sein.');
        }
        $technologies = [];
        foreach ($value as $technology) {
            $technology = self::text($technology, 40, 'Eine Technologie');
            if ($technology !== null && !in_array(mb_strtolower($technology), array_map('mb_strtolower', $technologies), true)) {
                $technologies[] = $technology;
            }
        }
        if (count($technologies) > self::MAX_TECHNOLOGIES) {
            throw new \InvalidArgumentException(sprintf('Höchstens %d Technologien je Referenz.', self::MAX_TECHNOLOGIES));
        }

        return $technologies;
    }

    /** @return list<array{columns: list<array<string, mixed>>}> */
    private static function rows(mixed $value, Reference $reference): array
    {
        if (!is_array($value)) {
            throw new \InvalidArgumentException('Die Inhaltszeilen müssen eine Liste sein.');
        }
        $contentImages = [];
        foreach ($reference->getImages() as $image) {
            if (!$image->isGalleryImage() && $image->getId() !== null) {
                $contentImages[$image->getId()] = true;
            }
        }

        $rows = [];
        foreach (array_values($value) as $rowIndex => $row) {
            $columns = is_array($row) ? ($row['columns'] ?? null) : null;
            if (!is_array($columns)) {
                throw new \InvalidArgumentException(sprintf('Zeile %d hat keine Spalten.', $rowIndex + 1));
            }
            if (count($columns) === 0) {
                continue;
            }
            if (count($columns) > self::MAX_COLUMNS) {
                throw new \InvalidArgumentException(sprintf('Zeile %d hat mehr als %d Spalten.', $rowIndex + 1, self::MAX_COLUMNS));
            }
            $cleaned = [];
            foreach (array_values($columns) as $columnIndex => $column) {
                $where = sprintf('Zeile %d, Spalte %d', $rowIndex + 1, $columnIndex + 1);
                $type = is_array($column) ? ($column['type'] ?? null) : null;
                if ($type === 'text') {
                    $cleaned[] = ['type' => 'text', 'text' => self::text($column['text'] ?? '', self::MAX_COLUMN_TEXT, $where, true) ?? ''];
                } elseif ($type === 'image') {
                    $imageId = is_numeric($column['imageId'] ?? null) ? (int)$column['imageId'] : null;
                    if ($imageId === null) {
                        throw new \InvalidArgumentException(sprintf('%s: Die Bildspalte hat noch kein Bild.', $where));
                    }
                    if (!isset($contentImages[$imageId])) {
                        throw new \InvalidArgumentException(sprintf('%s: Das Bild gehört nicht zu dieser Referenz.', $where));
                    }
                    $cleaned[] = ['type' => 'image', 'imageId' => $imageId, 'caption' => self::text($column['caption'] ?? null, 255, $where . ': Die Bildunterschrift')];
                } else {
                    throw new \InvalidArgumentException(sprintf('%s enthält weder Text noch Bild.', $where));
                }
            }
            $rows[] = [
                'columns' => $cleaned,
                'background' => self::color($row['background'] ?? null, sprintf('Zeile %d: Die Hintergrundfarbe', $rowIndex + 1)),
                'color' => self::color($row['color'] ?? null, sprintf('Zeile %d: Die Textfarbe', $rowIndex + 1)),
                'banner' => ($row['banner'] ?? false) === true,
            ];
        }
        if (count($rows) > self::MAX_ROWS) {
            throw new \InvalidArgumentException(sprintf('Höchstens %d Inhaltszeilen je Referenz.', self::MAX_ROWS));
        }

        return $rows;
    }

    /** "#rrggbb" in lower case, null for none - it ends up in a style attribute, so nothing else passes. */
    private static function color(mixed $value, string $name): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_string($value) || preg_match('/^#[0-9a-fA-F]{6}$/D', $value) !== 1) {
            throw new \InvalidArgumentException(sprintf('%s muss eine Farbe wie #1a2b3c sein.', $name));
        }

        return strtolower($value);
    }

    /** @return list<array{label: string, value: string}> */
    private static function facts(mixed $value): array
    {
        if (!is_array($value)) {
            throw new \InvalidArgumentException('Die Angaben müssen eine Liste sein.');
        }
        $facts = [];
        foreach ($value as $fact) {
            if (!is_array($fact)) {
                throw new \InvalidArgumentException('Eine Angabe besteht aus Bezeichnung und Wert.');
            }
            $label = self::text($fact['label'] ?? null, 60, 'Die Bezeichnung einer Angabe');
            $text = self::text($fact['value'] ?? null, 300, 'Der Wert einer Angabe');
            if ($label === null && $text === null) {
                continue;
            }
            if ($label === null || $text === null) {
                throw new \InvalidArgumentException('Jede Angabe braucht eine Bezeichnung und einen Wert.');
            }
            $facts[] = ['label' => $label, 'value' => $text];
        }
        if (count($facts) > self::MAX_FACTS) {
            throw new \InvalidArgumentException(sprintf('Höchstens %d Angaben je Referenz.', self::MAX_FACTS));
        }

        return $facts;
    }
}
