<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Reference;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * The files of the application documents: {directory}/{id}, the id being 16 random hex
 * digits and the extension of what the file really is - a PDF (by its signature) or a
 * pixel image. Nothing else is taken: the files are shown to people who are not signed in.
 */
final class DocumentStorage
{
    public const MAX_BYTES = 20 * 1024 * 1024;
    public const TYPES = ['pdf' => 'application/pdf', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'webp' => 'image/webp'];
    public const FILE_ID = '[a-f0-9]{16}\.(?:pdf|png|jpg|webp)';

    public function __construct(
        #[Autowire('%analytics_recruitment.documents.directory%')]
        private readonly string $directory,
    ) {
    }

    /**
     * @return array{file: string, size: int} the id of the stored file and its size
     * @throws \InvalidArgumentException when it is neither a PDF nor an image, or too large
     */
    public function add(string $sourcePath, string $originalName): array
    {
        $size = is_file($sourcePath) ? (int)filesize($sourcePath) : 0;
        if ($size === 0) {
            throw new \InvalidArgumentException('Die Datei ist nicht angekommen.');
        }
        if ($size > self::MAX_BYTES) {
            throw new \InvalidArgumentException(sprintf('Die Datei ist größer als %d MB.', self::MAX_BYTES / 1024 / 1024));
        }
        $extension = self::detectExtension($sourcePath);
        if ($extension === null) {
            throw new \InvalidArgumentException(sprintf('"%s" ist weder ein PDF noch ein PNG-, JPEG- oder WebP-Bild.', $originalName));
        }

        if (!is_dir($this->directory) && !@mkdir($this->directory, 0775, true) && !is_dir($this->directory)) {
            throw new \RuntimeException('The document directory could not be created.');
        }
        do {
            $id = bin2hex(random_bytes(8)) . '.' . $extension;
        } while (file_exists($this->directory . '/' . $id));
        if (!copy($sourcePath, $this->directory . '/' . $id)) {
            throw new \RuntimeException('The document could not be stored.');
        }

        return ['file' => $id, 'size' => $size];
    }

    /** What the file really is, by its content - never by its name. */
    public static function detectExtension(string $path): ?string
    {
        $handle = @fopen($path, 'rb');
        $head = $handle === false ? '' : (string)fread($handle, 1024);
        if ($handle !== false) {
            fclose($handle);
        }
        // a PDF starts with "%PDF-", some writers put a few bytes in front of it
        if (str_contains($head, '%PDF-')) {
            return 'pdf';
        }
        $info = @getimagesize($path);
        $extension = $info === false ? false : array_search($info['mime'] ?? '', self::TYPES, true);

        return $extension === false || $extension === 'pdf' ? null : $extension;
    }

    public function path(string $id): ?string
    {
        if (preg_match('/^' . self::FILE_ID . '$/D', $id) !== 1) {
            return null;
        }
        $file = $this->directory . '/' . $id;

        return is_file($file) ? $file : null;
    }

    public function remove(string $id): void
    {
        $file = $this->path($id);
        if ($file !== null) {
            @unlink($file);
        }
    }

    public static function mimeTypeOf(string $id): string
    {
        return self::TYPES[pathinfo($id, PATHINFO_EXTENSION)] ?? 'application/octet-stream';
    }
}
