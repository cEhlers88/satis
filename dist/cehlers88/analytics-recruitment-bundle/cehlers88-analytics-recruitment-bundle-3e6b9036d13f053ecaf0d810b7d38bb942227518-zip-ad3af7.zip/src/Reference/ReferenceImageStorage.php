<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Reference;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * The image files of the references: {directory}/{id}, the id being 16 random hex digits
 * and the extension of what the file really is. Only pixel images are taken - an SVG
 * could carry script, and the images are shown to people who are not signed in.
 */
final class ReferenceImageStorage
{
    public const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
    public const IMAGE_TYPES = ['png' => 'image/png', 'jpg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp'];
    public const IMAGE_ID = '[a-f0-9]{16}\.(?:png|jpg|gif|webp)';

    public function __construct(
        #[Autowire('%analytics_recruitment.images.directory%')]
        private readonly string $directory,
    ) {
    }

    /**
     * @return string the id of the stored image
     * @throws \InvalidArgumentException when it is no image or too large
     */
    public function add(string $sourcePath, string $originalName): string
    {
        if (!is_file($sourcePath) || filesize($sourcePath) === 0) {
            throw new \InvalidArgumentException('Das Bild ist nicht angekommen.');
        }
        if ((int)filesize($sourcePath) > self::MAX_IMAGE_BYTES) {
            throw new \InvalidArgumentException(sprintf('Das Bild ist größer als %d MB.', self::MAX_IMAGE_BYTES / 1024 / 1024));
        }
        $info = @getimagesize($sourcePath);
        $extension = $info === false ? false : array_search($info['mime'] ?? '', self::IMAGE_TYPES, true);
        if ($extension === false) {
            throw new \InvalidArgumentException(sprintf('"%s" ist kein PNG-, JPEG-, GIF- oder WebP-Bild.', $originalName));
        }

        if (!is_dir($this->directory) && !@mkdir($this->directory, 0775, true) && !is_dir($this->directory)) {
            throw new \RuntimeException('The image directory could not be created.');
        }
        do {
            $id = bin2hex(random_bytes(8)) . '.' . $extension;
        } while (file_exists($this->directory . '/' . $id));
        if (!copy($sourcePath, $this->directory . '/' . $id)) {
            throw new \RuntimeException('The image could not be stored.');
        }

        return $id;
    }

    /** The file of an image, null when there is none by that id. */
    public function path(string $id): ?string
    {
        if (!self::isImageId($id)) {
            return null;
        }
        $file = $this->directory . '/' . $id;

        return is_file($file) ? $file : null;
    }

    public function remove(string $id): void
    {
        $file = $this->path($id);
        if ($file !== null) {
            @unlink($file);
        }
    }

    public static function isImageId(string $id): bool
    {
        return preg_match('/^' . self::IMAGE_ID . '$/D', $id) === 1;
    }

    public static function mimeTypeOf(string $id): string
    {
        return self::IMAGE_TYPES[pathinfo($id, PATHINFO_EXTENSION)] ?? 'application/octet-stream';
    }
}
