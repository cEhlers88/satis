<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\ENUM;

/** What an application document is - the public page groups and labels them by it. */
enum eDocumentCategory: string
{
    case CV = 'cv';
    case REFERENCE_LETTER = 'reference_letter';
    case CERTIFICATE = 'certificate';
    case OTHER = 'other';

    public function label(): string
    {
        return match ($this) {
            self::CV => 'Lebenslauf',
            self::REFERENCE_LETTER => 'Arbeitszeugnis',
            self::CERTIFICATE => 'Zertifikat',
            self::OTHER => 'Sonstiges',
        };
    }

    /** @return array<string, string> value => label, in the order the editor offers them */
    public static function choices(): array
    {
        $choices = [];
        foreach (self::cases() as $case) {
            $choices[$case->value] = $case->label();
        }

        return $choices;
    }
}
