<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.09.2026
 * Time: 20:30
 */

namespace Cehlers88\AnalyticsRecruitmentBundle\ENUM;

enum EPermission: string
{
    /** Edit the references and create the access links to them. */
    case MANAGE_RECRUITMENT = 'MANAGE_RECRUITMENT';

    public static function getPermissions(): array
    {
        return array_map(static fn(self $permission): string => $permission->value, self::cases());
    }
}
