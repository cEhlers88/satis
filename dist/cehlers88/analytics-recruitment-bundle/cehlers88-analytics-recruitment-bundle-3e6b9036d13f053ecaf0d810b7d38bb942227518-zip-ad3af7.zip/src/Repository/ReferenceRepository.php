<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Repository;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\Reference;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Reference>
 */
class ReferenceRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Reference::class);
    }

    /** @return list<Reference> every reference, in the order of the portfolio */
    public function findOrdered(): array
    {
        return $this->findBy([], ['position' => 'ASC', 'id' => 'ASC']);
    }

    /** @return list<Reference> what an access link shows */
    public function findPublished(): array
    {
        return $this->findBy(['published' => true], ['position' => 'ASC', 'id' => 'ASC']);
    }

    public function findPublishedById(int $id): ?Reference
    {
        return $this->findOneBy(['id' => $id, 'published' => true]);
    }

    /** The position behind the last reference - where a new one goes. */
    public function nextPosition(): int
    {
        return 1 + (int)$this->createQueryBuilder('reference')
                ->select('COALESCE(MAX(reference.position), 0)')
                ->getQuery()
                ->getSingleScalarResult();
    }
}
