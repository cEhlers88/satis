<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Repository;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\ReferenceImage;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<ReferenceImage>
 */
class ReferenceImageRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, ReferenceImage::class);
    }

    public function findOneByFile(string $file): ?ReferenceImage
    {
        return $this->findOneBy(['file' => $file]);
    }

    /** An image an access link may show - one of a published reference. */
    public function findPublishedByFile(string $file): ?ReferenceImage
    {
        return $this->createQueryBuilder('image')
            ->innerJoin('image.reference', 'reference')
            ->andWhere('image.file = :file')
            ->andWhere('reference.published = true')
            ->setParameter('file', $file)
            ->getQuery()
            ->getOneOrNullResult();
    }
}
