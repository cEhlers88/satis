<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Repository;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLink;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<AccessLink>
 */
class AccessLinkRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, AccessLink::class);
    }

    public function findOneByUuid(string $uuid): ?AccessLink
    {
        return $this->findOneBy(['uuid' => $uuid]);
    }

    /** @return list<AccessLink> the newest first */
    public function findNewestFirst(): array
    {
        return $this->findBy([], ['createdAt' => 'DESC', 'id' => 'DESC']);
    }
}
