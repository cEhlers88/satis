<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Repository;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\ApplicationDocument;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<ApplicationDocument>
 */
class ApplicationDocumentRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, ApplicationDocument::class);
    }

    /** @return list<ApplicationDocument> */
    public function findOrdered(): array
    {
        return $this->findBy([], ['position' => 'ASC', 'id' => 'ASC']);
    }

    /** @return list<ApplicationDocument> what an access link shows */
    public function findPublished(): array
    {
        return $this->findBy(['published' => true], ['position' => 'ASC', 'id' => 'ASC']);
    }

    public function findPublishedById(int $id): ?ApplicationDocument
    {
        return $this->findOneBy(['id' => $id, 'published' => true]);
    }

    public function nextPosition(): int
    {
        return 1 + (int)$this->createQueryBuilder('document')
                ->select('COALESCE(MAX(document.position), 0)')
                ->getQuery()
                ->getSingleScalarResult();
    }
}
