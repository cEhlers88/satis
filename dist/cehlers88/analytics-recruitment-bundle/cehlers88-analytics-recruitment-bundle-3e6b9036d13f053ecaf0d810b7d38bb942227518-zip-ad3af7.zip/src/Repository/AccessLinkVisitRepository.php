<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Repository;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLink;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLinkVisit;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<AccessLinkVisit>
 */
class AccessLinkVisitRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, AccessLinkVisit::class);
    }

    /** @return list<AccessLinkVisit> the newest first */
    public function findRecent(AccessLink $accessLink, int $limit = 200): array
    {
        return $this->createQueryBuilder('visit')
            ->leftJoin('visit.reference', 'reference')
            ->addSelect('reference')
            ->leftJoin('visit.document', 'document')
            ->addSelect('document')
            ->andWhere('visit.accessLink = :link')
            ->setParameter('link', $accessLink)
            ->orderBy('visit.visitedAt', 'DESC')
            ->addOrderBy('visit.id', 'DESC')
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
    }

    /**
     * How often each reference was opened through the link.
     *
     * @return list<array{referenceId: int, title: string, views: int}> the most viewed first
     */
    public function countViewsPerReference(AccessLink $accessLink): array
    {
        $rows = $this->createQueryBuilder('visit')
            ->select('reference.id AS referenceId', 'reference.title AS title', 'COUNT(visit.id) AS views')
            ->innerJoin('visit.reference', 'reference')
            ->andWhere('visit.accessLink = :link')
            ->setParameter('link', $accessLink)
            ->groupBy('reference.id', 'reference.title')
            ->orderBy('views', 'DESC')
            ->getQuery()
            ->getArrayResult();

        return array_map(static fn(array $row): array => [
            'referenceId' => (int)$row['referenceId'],
            'title' => (string)$row['title'],
            'views' => (int)$row['views'],
        ], $rows);
    }

    /**
     * How often each document was opened or downloaded through the link.
     *
     * @return list<array{documentId: int, title: string, views: int}> the most viewed first
     */
    public function countViewsPerDocument(AccessLink $accessLink): array
    {
        $rows = $this->createQueryBuilder('visit')
            ->select('document.id AS documentId', 'document.title AS title', 'COUNT(visit.id) AS views')
            ->innerJoin('visit.document', 'document')
            ->andWhere('visit.accessLink = :link')
            ->setParameter('link', $accessLink)
            ->groupBy('document.id', 'document.title')
            ->orderBy('views', 'DESC')
            ->getQuery()
            ->getArrayResult();

        return array_map(static fn(array $row): array => [
            'documentId' => (int)$row['documentId'],
            'title' => (string)$row['title'],
            'views' => (int)$row['views'],
        ], $rows);
    }
}
