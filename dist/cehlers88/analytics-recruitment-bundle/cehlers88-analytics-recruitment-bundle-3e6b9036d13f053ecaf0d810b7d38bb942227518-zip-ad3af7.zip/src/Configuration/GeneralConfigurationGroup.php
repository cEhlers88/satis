<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Configuration;

use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;

/** What the public reference pages say about the person the references belong to. */
class GeneralConfigurationGroup extends AbstractConfigurationGroup
{
    public const string KEY = 'recruitmentBundle.general';

    public function getItems(): array
    {
        return [
            ConfigurationItemDTO::create('ownerName', 'Name', eInputType::TEXT_SINGLE_LINE, '', 'Steht als Überschrift über den Referenzen.'),
            ConfigurationItemDTO::create('headline', 'Tätigkeit', eInputType::TEXT_SINGLE_LINE, '', 'z. B. "Full-Stack-Entwickler (PHP / TypeScript)"'),
            ConfigurationItemDTO::create('introduction', 'Einleitung', eInputType::TEXT_MULTI_LINE, '', 'Ein paar Sätze über dich, oberhalb der Referenzen.'),
            ConfigurationItemDTO::create('contactEmail', 'Kontakt-E-Mail', eInputType::EMAIL, '', 'Wird auf den Referenzseiten als Kontakt angezeigt.'),
        ];
    }

    public function getGroupTitle(): string
    {
        return 'Bewerbung: Referenzseiten';
    }

    public function getGroupDescription(): string
    {
        return 'Was die über Zugriffslinks erreichbaren Referenzseiten über dich zeigen.';
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}
