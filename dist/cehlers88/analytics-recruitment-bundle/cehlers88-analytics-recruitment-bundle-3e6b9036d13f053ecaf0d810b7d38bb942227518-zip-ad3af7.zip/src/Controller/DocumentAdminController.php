<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Controller;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\ApplicationDocument;
use Cehlers88\AnalyticsRecruitmentBundle\ENUM\eDocumentCategory;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\DocumentInput;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\DocumentResponse;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\DocumentStorage;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\RecruitmentSerializer;
use Cehlers88\AnalyticsRecruitmentBundle\Repository\ApplicationDocumentRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * The application documents of the references tool: CV, reference letters, certificates.
 * Every change answers the documents as they are now.
 */
#[Route('/admin_api/recruitment/documents', name: 'analytics_recruitment_admin_document')]
final class DocumentAdminController extends AbstractRecruitmentAdminController
{
    public function __construct(
        private readonly ApplicationDocumentRepository $documents,
        private readonly DocumentStorage               $storage,
        private readonly RecruitmentSerializer         $serializer,
        private readonly EntityManagerInterface        $entityManager,
    ) {
    }

    #[Route('', name: 's', methods: ['GET'])]
    public function list(): JsonResponse
    {
        $this->denyUnlessDashboardUser();

        return $this->json($this->all());
    }

    /** Form fields: file, title, category, issuer, issuedOn, published. */
    #[Route('', name: '_create', methods: ['POST'])]
    public function create(Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }

        $document = new ApplicationDocument();
        try {
            DocumentInput::apply($document, $request->request->all());
            $file = $this->uploadedFile($request);
            $stored = $this->storage->add($file->getPathname(), $file->getClientOriginalName());
        } catch (\InvalidArgumentException $exception) {
            return $this->failure($exception->getMessage());
        }
        $document
            ->setStoredFile($stored['file'], $file->getClientOriginalName(), $stored['size'])
            ->setPosition($this->documents->nextPosition());
        $this->entityManager->persist($document);
        $this->entityManager->flush();

        return $this->json(['document' => $this->serializer->document($document)] + $this->all(), 201);
    }

    /** JSON body: {title, category, issuer, issuedOn, published} */
    #[Route('/{id}', name: '_update', requirements: ['id' => '\d+'], methods: ['PUT'])]
    public function update(int $id, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $document = $this->document($id);

        try {
            DocumentInput::apply($document, $this->body($request));
        } catch (\InvalidArgumentException $exception) {
            return $this->failure($exception->getMessage());
        }
        $this->entityManager->flush();

        return $this->json(['document' => $this->serializer->document($document)] + $this->all());
    }

    /** Form field: file - a new version (the current CV, say); title, category and links stay. */
    #[Route('/{id}/file', name: '_replace', requirements: ['id' => '\d+'], methods: ['POST'])]
    public function replaceFile(int $id, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $document = $this->document($id);

        try {
            $file = $this->uploadedFile($request);
            $stored = $this->storage->add($file->getPathname(), $file->getClientOriginalName());
        } catch (\InvalidArgumentException $exception) {
            return $this->failure($exception->getMessage());
        }
        $previous = $document->getFile();
        $document->setStoredFile($stored['file'], $file->getClientOriginalName(), $stored['size']);
        $document->touch();
        $this->entityManager->flush();
        $this->storage->remove($previous);

        return $this->json(['document' => $this->serializer->document($document)] + $this->all());
    }

    #[Route('/{id}', name: '_delete', requirements: ['id' => '\d+'], methods: ['DELETE'])]
    public function delete(int $id, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $document = $this->document($id);
        $file = $document->getFile();
        $this->entityManager->remove($document);
        $this->entityManager->flush();
        $this->storage->remove($file);

        return $this->json($this->all());
    }

    /** JSON body: {ids: [...]} - the documents in their new order. */
    #[Route('/order', name: '_order', methods: ['PUT'])]
    public function order(Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $rank = array_flip($this->idList($this->body($request)['ids'] ?? null));
        $documents = $this->documents->findOrdered();
        usort($documents, static fn(ApplicationDocument $left, ApplicationDocument $right): int => [$rank[$left->getId()] ?? PHP_INT_MAX, $left->getPosition()]
            <=> [$rank[$right->getId()] ?? PHP_INT_MAX, $right->getPosition()]);
        foreach ($documents as $index => $document) {
            $document->setPosition($index + 1);
        }
        $this->entityManager->flush();

        return $this->json($this->all());
    }

    /** The file as the editor opens it; ?download=1 saves it. */
    #[Route('/{id}/file', name: '_file', requirements: ['id' => '\d+'], methods: ['GET'])]
    public function showFile(int $id, Request $request): Response
    {
        $this->denyUnlessDashboardUser();
        $document = $this->document($id);
        $path = $this->storage->path($document->getFile()) ?? throw $this->createNotFoundException();
        $response = DocumentResponse::create($path, $document, $request->query->getBoolean('download'));
        $response->setPrivate();

        return $response;
    }

    /** @return array{documents: list<array<string, mixed>>, categories: array<string, string>, maxSize: int} */
    private function all(): array
    {
        return [
            'documents' => array_map($this->serializer->document(...), $this->documents->findOrdered()),
            'categories' => eDocumentCategory::choices(),
            'maxSize' => DocumentStorage::MAX_BYTES,
        ];
    }

    private function document(int $id): ApplicationDocument
    {
        return $this->documents->find($id) ?? throw $this->createNotFoundException('Dieses Dokument gibt es nicht (mehr).');
    }

    private function uploadedFile(Request $request): UploadedFile
    {
        $file = $request->files->get('file');
        if (!$file instanceof UploadedFile || !$file->isValid()) {
            throw new \InvalidArgumentException('Die Datei ist nicht angekommen - vielleicht ist sie zu groß für den Server.');
        }

        return $file;
    }
}
