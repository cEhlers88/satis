<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * What the backend of the references tool has in common: it is part of the dashboard, every
 * change carries the CSRF token "recruitment" in the X-CSRF-Token header, and a refusal is
 * answered as {message} with a status.
 *
 * Who may use the tool is set in the tool settings (stored in the database); ToolAccess keeps
 * everybody else away from these routes (analytics_recruitment_admin_*) before they get here.
 */
abstract class AbstractRecruitmentAdminController extends AbstractController
{
    public const CSRF_TOKEN_ID = 'recruitment';
    public const CSRF_HEADER = 'X-CSRF-Token';

    protected function denyUnlessDashboardUser(): void
    {
        if (!$this->isGranted('ROLE_DASHBOARD') && !$this->isGranted('ROLE_ADMIN')) {
            throw $this->createAccessDeniedException('The references are kept on the dashboard.');
        }
    }

    /** Null when the request may change something, else the answer that refuses it. */
    protected function refuseWithoutToken(Request $request): ?JsonResponse
    {
        return $this->isCsrfTokenValid(self::CSRF_TOKEN_ID, (string)$request->headers->get(self::CSRF_HEADER, ''))
            ? null
            : $this->failure('Ungültiges CSRF-Token - bitte die Seite neu laden.', 403);
    }

    /** @return array<string, mixed> */
    protected function body(Request $request): array
    {
        try {
            return $request->toArray();
        } catch (\Throwable) {
            return [];
        }
    }

    protected function failure(string $message, int $status = 400): JsonResponse
    {
        return $this->json(['message' => $message], $status);
    }

    /** @return list<int> the ids of a reordering, in their new order */
    protected function idList(mixed $ids): array
    {
        if (!is_array($ids)) {
            return [];
        }

        return array_values(array_unique(array_map('intval', array_filter($ids, 'is_numeric'))));
    }
}
