<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Controller;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\Reference;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\ReferenceImage;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\RecruitmentSerializer;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\ReferenceImageStorage;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\ReferenceInput;
use Cehlers88\AnalyticsRecruitmentBundle\Repository\ReferenceImageRepository;
use Cehlers88\AnalyticsRecruitmentBundle\Repository\ReferenceRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * The backend of the references tool (/dashboard/tools): the stations of the portfolio,
 * their texts, facts and images. Every change answers the reference(s) as they are now.
 */
#[Route('/admin_api/recruitment', name: 'analytics_recruitment_admin_')]
final class ReferenceAdminController extends AbstractRecruitmentAdminController
{
    public function __construct(
        private readonly ReferenceRepository      $references,
        private readonly ReferenceImageRepository $images,
        private readonly ReferenceImageStorage    $imageStorage,
        private readonly RecruitmentSerializer    $serializer,
        private readonly EntityManagerInterface   $entityManager,
    ) {
    }

    #[Route('/references', name: 'references', methods: ['GET'])]
    public function list(): JsonResponse
    {
        $this->denyUnlessDashboardUser();

        return $this->json($this->all());
    }

    #[Route('/references', name: 'reference_create', methods: ['POST'])]
    public function create(Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }

        $reference = new Reference();
        try {
            ReferenceInput::apply($reference, $this->body($request));
        } catch (\InvalidArgumentException $exception) {
            return $this->failure($exception->getMessage());
        }
        $reference->setPosition($this->references->nextPosition());
        $this->entityManager->persist($reference);
        $this->entityManager->flush();

        return $this->json(['reference' => $this->serializer->reference($reference)] + $this->all(), 201);
    }

    #[Route('/references/{id}', name: 'reference_update', requirements: ['id' => '\d+'], methods: ['PUT'])]
    public function update(int $id, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $reference = $this->reference($id);

        try {
            ReferenceInput::apply($reference, $this->body($request));
        } catch (\InvalidArgumentException $exception) {
            return $this->failure($exception->getMessage());
        }
        $unused = $this->dropUnusedContentImages($reference);
        $this->entityManager->flush();
        array_walk($unused, fn(string $file) => $this->imageStorage->remove($file));

        return $this->json(['reference' => $this->serializer->reference($reference)] + $this->all());
    }

    #[Route('/references/{id}', name: 'reference_delete', requirements: ['id' => '\d+'], methods: ['DELETE'])]
    public function delete(int $id, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $reference = $this->reference($id);
        $files = array_map(static fn(ReferenceImage $image): string => $image->getFile(), $reference->getImages()->toArray());

        $this->entityManager->remove($reference);
        $this->entityManager->flush();
        // the files only go once the rows are gone - a failed flush keeps both
        array_walk($files, fn(string $file) => $this->imageStorage->remove($file));

        return $this->json($this->all());
    }

    /** JSON body: {ids: [...]} - the references in their new order. */
    #[Route('/references/order', name: 'reference_order', methods: ['PUT'])]
    public function order(Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $this->applyOrder($this->references->findOrdered(), $this->idList($this->body($request)['ids'] ?? null));
        $this->entityManager->flush();

        return $this->json($this->all());
    }

    /**
     * Form fields: image (the file), caption (optional), context ("gallery", the default, or
     * "content" for a column of a content row - it is kept once a saved row shows it).
     */
    #[Route('/references/{id}/images', name: 'image_upload', requirements: ['id' => '\d+'], methods: ['POST'])]
    public function uploadImage(int $id, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $reference = $this->reference($id);
        $file = $request->files->get('image');
        if (!$file instanceof UploadedFile || !$file->isValid()) {
            return $this->failure('Das Bild ist nicht angekommen - vielleicht ist es zu groß für den Server.');
        }

        try {
            $stored = $this->imageStorage->add($file->getPathname(), $file->getClientOriginalName());
        } catch (\InvalidArgumentException $exception) {
            return $this->failure($exception->getMessage());
        }
        $position = 1 + max([0, ...array_map(static fn(ReferenceImage $image): int => $image->getPosition(), $reference->getImages()->toArray())]);
        $caption = trim((string)$request->request->get('caption', ''));
        $image = new ReferenceImage()
            ->setFile($stored)
            ->setCaption($caption === '' ? null : mb_substr($caption, 0, 255))
            ->setPosition($position)
            ->setContext((string)$request->request->get('context', ReferenceImage::CONTEXT_GALLERY));
        $reference->addImage($image);
        $reference->touch();
        $this->entityManager->flush();

        return $this->json(['reference' => $this->serializer->reference($reference), 'image' => $this->serializer->image($image)], 201);
    }

    /** JSON body: {caption} */
    #[Route('/references/{id}/images/{imageId}', name: 'image_update', requirements: ['id' => '\d+', 'imageId' => '\d+'], methods: ['PUT'])]
    public function updateImage(int $id, int $imageId, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        [$reference, $image] = $this->image($id, $imageId);
        $caption = $this->body($request)['caption'] ?? null;
        $caption = is_string($caption) ? trim(preg_replace('/\s+/u', ' ', $caption) ?? '') : '';
        if (mb_strlen($caption) > 255) {
            return $this->failure('Die Bildunterschrift darf höchstens 255 Zeichen lang sein.');
        }
        $image->setCaption($caption === '' ? null : $caption);
        $reference->touch();
        $this->entityManager->flush();

        return $this->json(['reference' => $this->serializer->reference($reference)]);
    }

    #[Route('/references/{id}/images/{imageId}', name: 'image_delete', requirements: ['id' => '\d+', 'imageId' => '\d+'], methods: ['DELETE'])]
    public function deleteImage(int $id, int $imageId, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        [$reference, $image] = $this->image($id, $imageId);
        $file = $image->getFile();
        $reference->removeImage($image);
        $reference->touch();
        $this->entityManager->flush();
        $this->imageStorage->remove($file);

        return $this->json(['reference' => $this->serializer->reference($reference)]);
    }

    /** JSON body: {ids: [...]} - the images of the reference in their new order. */
    #[Route('/references/{id}/images/order', name: 'image_order', requirements: ['id' => '\d+'], methods: ['PUT'])]
    public function orderImages(int $id, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $reference = $this->reference($id);
        $this->applyOrder($reference->getGalleryImages(), $this->idList($this->body($request)['ids'] ?? null));
        $reference->touch();
        $this->entityManager->flush();

        return $this->json(['reference' => $this->serializer->reference($reference)]);
    }

    /** An image as the editor shows it - the public page has its own route per link. */
    #[Route('/images/{file}', name: 'image', requirements: ['file' => ReferenceImageStorage::IMAGE_ID], methods: ['GET'])]
    public function showImage(string $file): Response
    {
        $this->denyUnlessDashboardUser();
        $path = $this->imageStorage->path($file);
        if ($path === null || $this->images->findOneByFile($file) === null) {
            throw $this->createNotFoundException();
        }
        $response = new BinaryFileResponse($path);
        $response->headers->set('Content-Type', ReferenceImageStorage::mimeTypeOf($file));
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        // the id is new for every upload, so the file behind it never changes
        $response->setPrivate();
        $response->setMaxAge(31536000);

        return $response;
    }

    /**
     * Content images no saved row shows (any more) - uploaded for a column that was then
     * removed or never saved. They go with the save; the files once the rows are gone.
     *
     * @return list<string> the files to remove after the flush
     */
    private function dropUnusedContentImages(Reference $reference): array
    {
        $shown = array_flip($reference->getContentImageIds());
        $files = [];
        foreach ($reference->getImages()->toArray() as $image) {
            if (!$image->isGalleryImage() && !isset($shown[$image->getId()])) {
                $files[] = $image->getFile();
                $reference->removeImage($image);
            }
        }

        return $files;
    }

    /** @return array{references: list<array<string, mixed>>} */
    private function all(): array
    {
        return ['references' => array_map($this->serializer->reference(...), $this->references->findOrdered())];
    }

    private function reference(int $id): Reference
    {
        return $this->references->find($id) ?? throw $this->createNotFoundException('Diese Referenz gibt es nicht (mehr).');
    }

    /** @return array{Reference, ReferenceImage} */
    private function image(int $referenceId, int $imageId): array
    {
        $reference = $this->reference($referenceId);
        foreach ($reference->getImages() as $image) {
            if ($image->getId() === $imageId) {
                return [$reference, $image];
            }
        }
        throw $this->createNotFoundException('Dieses Bild gibt es nicht (mehr).');
    }

    /**
     * Numbers the items in the order of the ids; items the ids do not name keep their
     * relative order behind them.
     *
     * @param list<Reference|ReferenceImage> $items
     * @param list<int>                      $ids
     */
    private function applyOrder(array $items, array $ids): void
    {
        $rank = array_flip($ids);
        usort($items, static fn($left, $right): int => [$rank[$left->getId()] ?? PHP_INT_MAX, $left->getPosition(), $left->getId()]
            <=> [$rank[$right->getId()] ?? PHP_INT_MAX, $right->getPosition(), $right->getId()]);
        foreach ($items as $index => $item) {
            $item->setPosition($index + 1);
        }
    }
}
