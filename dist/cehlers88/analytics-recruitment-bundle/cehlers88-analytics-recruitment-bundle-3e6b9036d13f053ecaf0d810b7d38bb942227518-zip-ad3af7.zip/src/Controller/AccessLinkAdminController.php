<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Controller;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLink;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\AccessLinkInput;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\RecruitmentSerializer;
use Cehlers88\AnalyticsRecruitmentBundle\Repository\AccessLinkRepository;
use Cehlers88\AnalyticsRecruitmentBundle\Repository\AccessLinkVisitRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;

/**
 * The access links of the references tool - made, switched off, deleted - and the visits
 * counted through each of them. The UUID of a link is made once and never changes; a link
 * that should stop working is switched off or deleted.
 */
#[Route('/admin_api/recruitment/access-links', name: 'analytics_recruitment_admin_access_link')]
final class AccessLinkAdminController extends AbstractRecruitmentAdminController
{
    public const VISIT_LIMIT = 300;

    public function __construct(
        private readonly AccessLinkRepository      $accessLinks,
        private readonly AccessLinkVisitRepository $visits,
        private readonly RecruitmentSerializer     $serializer,
        private readonly EntityManagerInterface    $entityManager,
    ) {
    }

    #[Route('', name: 's', methods: ['GET'])]
    public function list(): JsonResponse
    {
        $this->denyUnlessDashboardUser();

        return $this->json($this->all());
    }

    /** JSON body: {label, expiresAt?} */
    #[Route('', name: '_create', methods: ['POST'])]
    public function create(Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }

        $link = new AccessLink();
        try {
            AccessLinkInput::apply($link, $this->body($request));
        } catch (\InvalidArgumentException $exception) {
            return $this->failure($exception->getMessage());
        }
        $this->entityManager->persist($link);
        $this->entityManager->flush();

        return $this->json(['accessLink' => $this->serializer->accessLink($link)] + $this->all(), 201);
    }

    /** JSON body: {label, active, expiresAt} */
    #[Route('/{id}', name: '_update', requirements: ['id' => '\d+'], methods: ['PUT'])]
    public function update(int $id, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $link = $this->link($id);

        try {
            AccessLinkInput::apply($link, $this->body($request));
        } catch (\InvalidArgumentException $exception) {
            return $this->failure($exception->getMessage());
        }
        $this->entityManager->flush();

        return $this->json(['accessLink' => $this->serializer->accessLink($link)] + $this->all());
    }

    /** Deletes the link and the visits counted through it. */
    #[Route('/{id}', name: '_delete', requirements: ['id' => '\d+'], methods: ['DELETE'])]
    public function delete(int $id, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $this->entityManager->remove($this->link($id));
        $this->entityManager->flush();

        return $this->json($this->all());
    }

    /** The latest visits through the link and how often each reference was opened. */
    #[Route('/{id}/visits', name: '_visits', requirements: ['id' => '\d+'], methods: ['GET'])]
    public function visits(int $id): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        $link = $this->link($id);

        return $this->json([
            'accessLink' => $this->serializer->accessLink($link),
            'visits' => array_map($this->serializer->visit(...), $this->visits->findRecent($link, self::VISIT_LIMIT)),
            'limit' => self::VISIT_LIMIT,
            'perReference' => $this->visits->countViewsPerReference($link),
            'perDocument' => $this->visits->countViewsPerDocument($link),
        ]);
    }

    /** @return array{accessLinks: list<array<string, mixed>>} */
    private function all(): array
    {
        return ['accessLinks' => array_map($this->serializer->accessLink(...), $this->accessLinks->findNewestFirst())];
    }

    private function link(int $id): AccessLink
    {
        return $this->accessLinks->find($id) ?? throw $this->createNotFoundException('Diesen Zugriffslink gibt es nicht (mehr).');
    }
}
