<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Controller;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsRecruitmentBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLink;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLinkVisit;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\AccessLinkTracker;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\ContentRows;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\DocumentResponse;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\DocumentStorage;
use Cehlers88\AnalyticsRecruitmentBundle\Repository\ApplicationDocumentRepository;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\ReferenceImageStorage;
use Cehlers88\AnalyticsRecruitmentBundle\Repository\AccessLinkRepository;
use Cehlers88\AnalyticsRecruitmentBundle\Repository\ReferenceImageRepository;
use Cehlers88\AnalyticsRecruitmentBundle\Repository\ReferenceRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * The references - and the CV, reference letters and certificates - for people who are not
 * signed in, reached through an access link only.
 *
 * Access rests on the UUID of the link: random (v4), checked against the pattern before
 * it touches the database, and the link behind it has to be switched on and not expired.
 * A link that does not work (any more) answers like one that never existed. Every page
 * view is counted (AccessLinkTracker), every opened or downloaded document as well; the
 * images are not.
 *
 * The pages ask not to be indexed and send no referrer, so the link does not leak to the
 * sites of the projects they link to.
 */
#[Route('/references', name: 'analytics_recruitment_public_')]
final class PublicReferenceController extends AbstractController
{
    public const UUID = '[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}';

    public function __construct(
        private readonly AccessLinkRepository          $accessLinks,
        private readonly ReferenceRepository           $references,
        private readonly ReferenceImageRepository      $images,
        private readonly ReferenceImageStorage         $imageStorage,
        private readonly AccessLinkTracker             $tracker,
        private readonly ConfigurationProvider         $configurationProvider,
        private readonly ApplicationDocumentRepository $documents,
        private readonly DocumentStorage               $documentStorage,
    ) {
    }

    #[Route('/{uuid}', name: 'overview', requirements: ['uuid' => self::UUID], methods: ['GET'])]
    public function overview(string $uuid, Request $request): Response
    {
        $link = $this->usableLink($uuid);
        $this->tracker->track($link, $request, AccessLinkVisit::PAGE_OVERVIEW);

        return $this->harden($this->render('recruitment/public/overview.html.twig', [
            'uuid' => $uuid,
            'references' => $this->references->findPublished(),
            'documents' => $this->documents->findPublished(),
            'profile' => $this->profile(),
        ]));
    }

    #[Route('/{uuid}/{id}', name: 'reference', requirements: ['uuid' => self::UUID, 'id' => '\d+'], methods: ['GET'])]
    public function reference(string $uuid, int $id, Request $request): Response
    {
        $link = $this->usableLink($uuid);
        $reference = $this->references->findPublishedById($id) ?? throw $this->createNotFoundException();
        $this->tracker->track($link, $request, AccessLinkVisit::PAGE_REFERENCE, $reference);

        $published = $this->references->findPublished();
        $index = array_search($reference, $published, true);
        $index = $index === false ? -1 : $index;

        return $this->harden($this->render('recruitment/public/reference.html.twig', [
            'uuid' => $uuid,
            'reference' => $reference,
            'images' => $reference->getGalleryImages(),
            'rows' => ContentRows::resolve($reference),
            'previous' => $index > 0 ? $published[$index - 1] : null,
            'next' => $index >= 0 ? ($published[$index + 1] ?? null) : null,
            'documents' => $this->documents->findPublished(),
            'profile' => $this->profile(),
        ]));
    }

    #[Route('/{uuid}/images/{file}', name: 'image', requirements: ['uuid' => self::UUID, 'file' => ReferenceImageStorage::IMAGE_ID], methods: ['GET'])]
    public function image(string $uuid, string $file): Response
    {
        $this->usableLink($uuid);
        $path = $this->imageStorage->path($file);
        if ($path === null || $this->images->findPublishedByFile($file) === null) {
            throw $this->createNotFoundException();
        }
        $response = new BinaryFileResponse($path);
        $response->headers->set('Content-Type', ReferenceImageStorage::mimeTypeOf($file));
        $response->headers->set('Content-Security-Policy', "default-src 'none'; sandbox");
        $response->setMaxAge(86400);

        return $this->harden($response);
    }

    /** A document in the browser's viewer; ?download=1 saves it. Both are counted. */
    #[Route('/{uuid}/documents/{id}', name: 'document', requirements: ['uuid' => self::UUID, 'id' => '\d+'], methods: ['GET'])]
    public function document(string $uuid, int $id, Request $request): Response
    {
        $link = $this->usableLink($uuid);
        $document = $this->documents->findPublishedById($id) ?? throw $this->createNotFoundException();
        $path = $this->documentStorage->path($document->getFile()) ?? throw $this->createNotFoundException();
        $this->tracker->track($link, $request, AccessLinkVisit::PAGE_DOCUMENT, null, $document);

        return $this->harden(DocumentResponse::create($path, $document, $request->query->getBoolean('download')));
    }

    private function usableLink(string $uuid): AccessLink
    {
        $link = $this->accessLinks->findOneByUuid($uuid);
        if ($link === null || !$link->isUsable()) {
            throw $this->createNotFoundException('There are no references behind this link.');
        }

        return $link;
    }

    /** @return array{name: string, headline: string, introduction: string, email: string} */
    private function profile(): array
    {
        $value = fn(string $key): string => trim((string)$this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, $key, -1, ''));

        return [
            'name' => $value('ownerName'),
            'headline' => $value('headline'),
            'introduction' => $value('introduction'),
            'email' => $value('contactEmail'),
        ];
    }

    private function harden(Response $response): Response
    {
        $response->headers->set('X-Robots-Tag', 'noindex, nofollow');
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        $response->headers->set('Referrer-Policy', 'no-referrer');
        $response->setPrivate();

        return $response;
    }
}
