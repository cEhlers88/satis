<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.09.2026
 * Time: 20:30
 */

namespace Cehlers88\AnalyticsRecruitmentBundle;

use Cehlers88\AnalyticsCore\Support\AbstractBundlePlugin;
use Cehlers88\AnalyticsRecruitmentBundle\ENUM\EPermission;

class AnalyticsRecruitmentBundle extends AbstractBundlePlugin
{
    public function getDescription(): string
    {
        return 'Bundle zur Unterstützung des Bewerbungsprozesses: Referenzen und Zugriffslinks.';
    }

    public function getPermissions(): array
    {
        return EPermission::getPermissions();
    }

    public function getVersion(): string
    {
        return '1.0.0';
    }
}
