# AnalyticsRecruitmentBundle

A Symfony bundle for the [Analytics](https://github.com/cEhlers88) platform that supports the
**job application process** - keeping track of applications, their stages and the documents
that belong to them.

## Features

- **References** – the stations/projects of a portfolio: title, subtitle, period, web address,
  description, technologies, further facts (label/value), **content rows** (each of up to five
  columns, a column holding a text or an image; a row can have its own background and text colour
  and be a banner over the whole width of the page) and a gallery (PNG, JPEG, GIF, WebP).
  Edited in the tool *Referenzen & Zugriffslinks* on `/dashboard/tools`.
- **Documents** – CV, reference letters, certificates (PDF or image, up to 20 MB), each with
  title, category, issuer and date; a new version replaces the file and keeps the entry.
  The public pages show the CV as a button on every page and all documents in the section
  *Lebenslauf & Zeugnisse* (view in the browser or download).
- **Access links** – `/references/{uuid}` shows the published references to people who are not
  signed in, on
  dark, self-contained pages with the brand colour `#880726` as accent. The UUID (v4) cannot be guessed; a link can expire, be switched off or deleted.
- **Visit tracking** – every page view and every opened or downloaded document through a link is stored (time, page/reference, user agent,
  referrer without query, IP with the host part removed); signed-in users are not counted.
- **Settings** – *Bewerbung: Referenzseiten* (name, headline, introduction, contact e-mail shown on
  the public pages).

Access: like every tool, who may use it is set in the tool settings (database). The bundle declares
the permission `MANAGE_RECRUITMENT` for that purpose; the backend routes
(`analytics_recruitment_admin_*`) are guarded by the application's ToolAccess.

## Requirements

- PHP 8.4+
- Symfony 8
- [`cehlers88/analytics-core`](https://github.com/cEhlers88/AnalyticsCore) `1.*`

## Installation

The package is hosted on the private Satis repository:

```json
{
    "repositories": [
        { "type": "composer", "url": "https://cehlers88.github.io/satis" }
    ]
}
```

```bash
composer require cehlers88/analytics-recruitment-bundle
```

Register the bundle (`config/bundles.php`):

```php
return [
    // ...
    Cehlers88\AnalyticsRecruitmentBundle\AnalyticsRecruitmentBundle::class => ['all' => true],
];
```

Import its services (`config/services.yaml`):

```yaml
imports:
  - { resource: '@AnalyticsRecruitmentBundle/Resources/config/services.yaml' }
```

its routes (`config/routes/analytics_recruitment.yaml`):

```yaml
analytics_recruitment_bundle:
  resource: '@AnalyticsRecruitmentBundle/Controller/'
  type: attribute
```

the public pages (`config/packages/security.yaml`, `access_control`):

```yaml
- { path: ^/references/, roles: PUBLIC_ACCESS }
```

and its templates (`config/packages/twig.yaml`):

```yaml
twig:
  paths:
    'vendor/cehlers88/analytics-recruitment-bundle/templates': ~
```

The tables come with a migration of the host application (`recruitment_*`). Images are stored in
`%kernel.project_dir%/var/recruitment/images` (`RECRUITMENT_IMAGE_DIRECTORY` moves them), documents in
`%kernel.project_dir%/var/recruitment/documents` (`RECRUITMENT_DOCUMENT_DIRECTORY`). Both belong in a
directory the releases share and in the backup.

## Structure

```
src/
├── AnalyticsRecruitmentBundle.php   the plugin (AbstractBundlePlugin)
├── Configuration/                   settings of the public pages
├── Controller/                      admin API (/admin_api/recruitment: references, documents,
│                                    access links) + public pages (/references)
├── ENUM/EPermission.php             MANAGE_RECRUITMENT
├── Entity/, Repository/             Reference, ReferenceImage, ApplicationDocument, AccessLink, AccessLinkVisit
├── EventSubscriber/                 brings the tool to /dashboard/tools (CollectToolsEvent)
├── Reference/                       input checks, image storage, visit tracking, serializer
└── Resources/                       services.yaml, teaser.svg
templates/
├── tool/recruitment/                the tool: template, script, styles, teaser
└── recruitment/public/              the pages behind an access link
tests/                               PHPUnit
```

Extension points follow the other Analytics bundles: a class in `src/Macro/`, `src/Worker/`,
`src/CustomObject/`, `src/Presentation/Frontend/Assembler/` is tagged through `_instanceof`;
`src/Configuration/` and `src/ServiceEndpointRunner/` are tagged by directory (the entries are
prepared, commented out, in `services.yaml`). Entities go to `src/Entity/` - they are mapped by
Doctrine's `auto_mapping` of the host application, which then needs a migration. Controllers go
to `src/Controller/` and need a route import in the host application
(`config/routes/analytics_recruitment.yaml`).

## Development

```bash
composer install
./vendor/bin/phpunit
```
