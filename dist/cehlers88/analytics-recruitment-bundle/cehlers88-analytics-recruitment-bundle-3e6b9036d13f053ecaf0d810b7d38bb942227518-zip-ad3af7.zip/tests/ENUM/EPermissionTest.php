<?php

namespace Cehlers88\AnalyticsRecruitmentBundle\Tests\ENUM;

use Cehlers88\AnalyticsRecruitmentBundle\ENUM\EPermission;
use PHPUnit\Framework\TestCase;

class EPermissionTest extends TestCase
{
    public function testGetPermissionsListsEveryCase(): void
    {
        self::assertSame(['MANAGE_RECRUITMENT'], EPermission::getPermissions());
    }
}
