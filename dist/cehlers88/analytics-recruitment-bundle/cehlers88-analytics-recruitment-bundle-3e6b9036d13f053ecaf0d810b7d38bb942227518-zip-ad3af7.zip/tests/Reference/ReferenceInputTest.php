<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Tests\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\Reference;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\ReferenceInput;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class ReferenceInputTest extends TestCase
{
    public function testTakesAndCleansAllFields(): void
    {
        $reference = ReferenceInput::apply(new Reference(), [
            'title' => "  Relaunch \n Shop ",
            'subtitle' => '',
            'period' => '2021 – 2023',
            'url' => 'shop.example.com/de',
            'description' => "Absatz eins.\r\n\r\nAbsatz zwei.  ",
            'technologies' => ['Symfony', ' symfony ', 'TypeScript', ''],
            'facts' => [['label' => 'Team', 'value' => ' 4 '], ['label' => '', 'value' => '']],
            'published' => false,
        ]);

        self::assertSame('Relaunch Shop', $reference->getTitle());
        self::assertNull($reference->getSubtitle());
        self::assertSame('2021 – 2023', $reference->getPeriod());
        self::assertSame('https://shop.example.com/de', $reference->getUrl());
        self::assertSame("Absatz eins.\n\nAbsatz zwei.", $reference->getDescription());
        self::assertSame(['Symfony', 'TypeScript'], $reference->getTechnologies());
        self::assertSame([['label' => 'Team', 'value' => '4']], $reference->getFacts());
        self::assertFalse($reference->isPublished());
    }

    public function testTechnologiesMayComeAsCommaSeparatedText(): void
    {
        $reference = ReferenceInput::apply(new Reference(), ['title' => 'X', 'technologies' => 'PHP, MySQL ,']);

        self::assertSame(['PHP', 'MySQL'], $reference->getTechnologies());
    }

    public function testKeepsPortsAndHttp(): void
    {
        self::assertSame('https://shop.example.com:8080/x', ReferenceInput::apply(new Reference(), ['title' => 'X', 'url' => 'shop.example.com:8080/x'])->getUrl());
        self::assertSame('http://example.com', ReferenceInput::apply(new Reference(), ['title' => 'X', 'url' => 'http://example.com'])->getUrl());
    }

    /** @return iterable<string, array{array<string, mixed>}> */
    public static function refusedInput(): iterable
    {
        yield 'no title' => [['title' => '  ']];
        yield 'title too long' => [['title' => str_repeat('x', 161)]];
        yield 'javascript url' => [['title' => 'X', 'url' => 'javascript:alert(1)']];
        yield 'ftp url' => [['title' => 'X', 'url' => 'ftp://example.com']];
        yield 'fact without value' => [['title' => 'X', 'facts' => [['label' => 'Team', 'value' => '']]]];
        yield 'facts no list' => [['title' => 'X', 'facts' => 'Team']];
        yield 'title no text' => [['title' => ['X']]];
    }

    #[DataProvider('refusedInput')]
    public function testRefusesInvalidInputAndLeavesTheReferenceAlone(array $data): void
    {
        $reference = new Reference()->setTitle('Before');

        try {
            ReferenceInput::apply($reference, $data);
            self::fail('The input should have been refused.');
        } catch (\InvalidArgumentException) {
            self::assertSame('Before', $reference->getTitle());
        }
    }
}
