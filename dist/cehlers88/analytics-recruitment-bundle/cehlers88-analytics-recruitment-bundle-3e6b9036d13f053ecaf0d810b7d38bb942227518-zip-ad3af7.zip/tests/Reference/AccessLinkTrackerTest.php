<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Tests\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Reference\AccessLinkTracker;
use PHPUnit\Framework\TestCase;

class AccessLinkTrackerTest extends TestCase
{
    public function testShortensIpAddresses(): void
    {
        self::assertSame('203.0.113.0', AccessLinkTracker::anonymizeIp('203.0.113.57'));
        self::assertSame('2001:db8:85a3::', AccessLinkTracker::anonymizeIp('2001:db8:85a3:8d3:1319:8a2e:370:7348'));
        self::assertNull(AccessLinkTracker::anonymizeIp(null));
        self::assertNull(AccessLinkTracker::anonymizeIp('not an ip'));
    }

    public function testKeepsOnlyWhereTheVisitorCameFrom(): void
    {
        self::assertSame('https://mail.example.com/inbox', AccessLinkTracker::stripReferer('https://mail.example.com/inbox?id=secret#top'));
        self::assertSame('http://localhost:8080', AccessLinkTracker::stripReferer('http://localhost:8080'));
        self::assertSame('android-app://com.google/', AccessLinkTracker::stripReferer('android-app://com.google/?q=1'));
        self::assertNull(AccessLinkTracker::stripReferer('not a url'));
        self::assertNull(AccessLinkTracker::stripReferer(''));
    }
}
