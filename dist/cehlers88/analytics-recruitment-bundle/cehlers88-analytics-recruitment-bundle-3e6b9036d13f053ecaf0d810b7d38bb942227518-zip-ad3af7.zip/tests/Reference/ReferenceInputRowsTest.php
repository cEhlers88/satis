<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Tests\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\Reference;
use Cehlers88\AnalyticsRecruitmentBundle\Entity\ReferenceImage;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\ContentRows;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\ReferenceInput;
use PHPUnit\Framework\TestCase;

class ReferenceInputRowsTest extends TestCase
{
    public function testTakesRowsOfTextAndImageColumns(): void
    {
        $reference = $this->referenceWithImages();

        ReferenceInput::apply($reference, ['title' => 'X', 'rows' => [
            ['columns' => [['type' => 'text', 'text' => " Links \r\n\r\nzweiter Absatz "], ['type' => 'image', 'imageId' => '12', 'caption' => ' Startseite ']],
                'background' => '#1A2B3C', 'color' => '', 'banner' => true],
            ['columns' => []],
        ]]);

        self::assertSame([[
            'columns' => [
                ['type' => 'text', 'text' => "Links \n\nzweiter Absatz"],
                ['type' => 'image', 'imageId' => 12, 'caption' => 'Startseite'],
            ],
            'background' => '#1a2b3c',
            'color' => null,
            'banner' => true,
        ]], $reference->getContentRows());
        self::assertSame([12], $reference->getContentImageIds());
    }

    public function testRowsThatAreNotSentStayAsTheyAre(): void
    {
        $reference = new Reference()->setContentRows([['columns' => [['type' => 'text', 'text' => 'bleibt']]]]);

        ReferenceInput::apply($reference, ['title' => 'X']);

        self::assertSame('bleibt', $reference->getContentRows()[0]['columns'][0]['text']);
    }

    public function testRefusesSixColumnsForeignImagesGalleryImagesAndOddColours(): void
    {
        $cases = [
            'six columns' => array_fill(0, 6, ['type' => 'text', 'text' => 'x']),
            'image of another reference' => [['type' => 'image', 'imageId' => 99]],
            'gallery image' => [['type' => 'image', 'imageId' => 13]],
            'image column without image' => [['type' => 'image', 'imageId' => null]],
            'unknown type' => [['type' => 'video']],
        ];
        foreach ($cases as $case => $columns) {
            try {
                ReferenceInput::apply($this->referenceWithImages(), ['title' => 'X', 'rows' => [['columns' => $columns]]]);
                self::fail('Refused: ' . $case);
            } catch (\InvalidArgumentException) {
                self::addToAssertionCount(1);
            }
        }
        // a colour ends up in a style attribute - nothing but #rrggbb
        foreach (['red', '#fff', '#12345g', 'red;background:url(x)', '#123456;'] as $color) {
            try {
                ReferenceInput::apply($this->referenceWithImages(), ['title' => 'X', 'rows' => [['columns' => [['type' => 'text', 'text' => 'x']], 'background' => $color]]]);
                self::fail('Refused colour: ' . $color);
            } catch (\InvalidArgumentException) {
                self::addToAssertionCount(1);
            }
        }
    }

    public function testResolvesTheImagesAndSkipsOnesThatAreGone(): void
    {
        $reference = $this->referenceWithImages()->setContentRows([
            ['columns' => [['type' => 'image', 'imageId' => 12, 'caption' => null], ['type' => 'image', 'imageId' => 404, 'caption' => null]]],
            ['columns' => [['type' => 'image', 'imageId' => 404, 'caption' => null]]],
        ]);

        $rows = ContentRows::resolve($reference);

        self::assertCount(1, $rows);
        self::assertCount(1, $rows[0]['columns']);
        self::assertSame('a.png', $rows[0]['columns'][0]['image']->getFile());
        self::assertFalse($rows[0]['banner']);
        self::assertNull($rows[0]['background']);
        self::assertSame('b.png', $reference->getCoverImage()?->getFile(), 'a screenshot stands for the reference');
        $reference->removeImage($reference->findImage(13));
        self::assertSame('a.png', $reference->getCoverImage()?->getFile(), 'without screenshots a column image does');
    }

    /** A reference with the content image 12 and the gallery image 13. */
    private function referenceWithImages(): Reference
    {
        $reference = new Reference();
        $reference->addImage($this->image(12, 'a.png', ReferenceImage::CONTEXT_CONTENT));
        $reference->addImage($this->image(13, 'b.png', ReferenceImage::CONTEXT_GALLERY));

        return $reference;
    }

    private function image(int $id, string $file, string $context): ReferenceImage
    {
        $image = new ReferenceImage()->setFile($file)->setContext($context);
        new \ReflectionProperty(ReferenceImage::class, 'id')->setValue($image, $id);

        return $image;
    }
}
