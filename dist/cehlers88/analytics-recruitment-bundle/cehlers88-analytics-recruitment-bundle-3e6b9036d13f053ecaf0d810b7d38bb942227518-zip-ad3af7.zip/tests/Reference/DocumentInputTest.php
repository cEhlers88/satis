<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Tests\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\ApplicationDocument;
use Cehlers88\AnalyticsRecruitmentBundle\ENUM\eDocumentCategory;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\DocumentInput;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\DocumentResponse;
use PHPUnit\Framework\TestCase;

class DocumentInputTest extends TestCase
{
    public function testTakesTheFormFields(): void
    {
        $document = DocumentInput::apply(new ApplicationDocument(), [
            'title' => '  AWS  Solutions Architect ', 'category' => 'certificate', 'issuer' => 'Amazon', 'issuedOn' => '', 'published' => '0',
        ]);

        self::assertSame('AWS Solutions Architect', $document->getTitle());
        self::assertSame(eDocumentCategory::CERTIFICATE, $document->getCategory());
        self::assertSame('Amazon', $document->getIssuer());
        self::assertNull($document->getIssuedOn());
        self::assertFalse($document->isPublished());
        self::assertFalse($document->isCv());
    }

    public function testRefusesMissingTitleAndUnknownCategory(): void
    {
        foreach ([['title' => '', 'category' => 'cv'], ['title' => 'X', 'category' => 'diploma']] as $data) {
            try {
                DocumentInput::apply(new ApplicationDocument(), $data);
                self::fail('Refused: ' . json_encode($data));
            } catch (\InvalidArgumentException) {
                self::addToAssertionCount(1);
            }
        }
    }

    public function testADownloadIsNamedAfterTheTitle(): void
    {
        $document = new ApplicationDocument()->setTitle('Lebenslauf / Max: Mustermann')->setStoredFile('0123456789abcdef.pdf', 'scan_final_v3.pdf', 10);

        self::assertSame('Lebenslauf Max Mustermann.pdf', DocumentResponse::fileName($document));
    }
}
