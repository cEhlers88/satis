<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Tests\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Reference\DocumentStorage;
use PHPUnit\Framework\TestCase;

class DocumentStorageTest extends TestCase
{
    private string $directory;

    protected function setUp(): void
    {
        $this->directory = sys_get_temp_dir() . '/recruitment-documents-' . bin2hex(random_bytes(4));
    }

    protected function tearDown(): void
    {
        array_map('unlink', glob($this->directory . '/*') ?: []);
        @rmdir($this->directory);
    }

    public function testRecognisesTheFileByItsContentNotItsName(): void
    {
        self::assertSame('pdf', DocumentStorage::detectExtension($this->file("%PDF-1.7\n%âãÏÓ\n1 0 obj")));
        self::assertSame('png', DocumentStorage::detectExtension($this->png()));
        self::assertNull(DocumentStorage::detectExtension($this->file('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>')));
        self::assertNull(DocumentStorage::detectExtension($this->file("MZ\x90\x00 not a pdf")));
    }

    public function testStoresUnderARandomIdAndRemoves(): void
    {
        $storage = new DocumentStorage($this->directory);

        $stored = $storage->add($this->file('%PDF-1.4 cv'), 'Lebenslauf.exe');

        self::assertMatchesRegularExpression('/^[a-f0-9]{16}\.pdf$/', $stored['file']);
        self::assertSame(11, $stored['size']);
        self::assertNotNull($storage->path($stored['file']));
        self::assertNull($storage->path('../../etc/passwd'));
        $storage->remove($stored['file']);
        self::assertNull($storage->path($stored['file']));
    }

    public function testRefusesWhatIsNeitherPdfNorImage(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        new DocumentStorage($this->directory)->add($this->file('<html>hello</html>'), 'cv.pdf');
    }

    private function file(string $content): string
    {
        $path = tempnam(sys_get_temp_dir(), 'doc');
        file_put_contents($path, $content);

        return $path;
    }

    private function png(): string
    {
        $path = tempnam(sys_get_temp_dir(), 'png');
        $image = imagecreatetruecolor(4, 4);
        imagepng($image, $path);

        return $path;
    }
}
