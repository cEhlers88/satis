<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Tests\Reference;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLink;
use Cehlers88\AnalyticsRecruitmentBundle\Reference\AccessLinkInput;
use PHPUnit\Framework\TestCase;

class AccessLinkInputTest extends TestCase
{
    public function testALinkIsValidAllOfItsLastDay(): void
    {
        $link = AccessLinkInput::apply(new AccessLink(), ['label' => ' Muster  GmbH ', 'expiresAt' => '2030-05-17']);

        self::assertSame('Muster GmbH', $link->getLabel());
        self::assertSame('2030-05-17 23:59:59', $link->getExpiresAt()?->format('Y-m-d H:i:s'));
        self::assertTrue($link->isUsable(new \DateTimeImmutable('2030-05-17 22:00')));
        self::assertFalse($link->isUsable(new \DateTimeImmutable('2030-05-18 00:00')));
    }

    public function testKeepsWhatIsNotSent(): void
    {
        $link = new AccessLink()->setActive(false)->setExpiresAt(new \DateTimeImmutable('2030-01-01'));

        AccessLinkInput::apply($link, ['label' => 'Neu']);

        self::assertFalse($link->isActive());
        self::assertSame('2030-01-01', $link->getExpiresAt()?->format('Y-m-d'));
    }

    public function testAnEmptyDateRemovesTheExpiry(): void
    {
        $link = AccessLinkInput::apply(new AccessLink()->setExpiresAt(new \DateTimeImmutable()), ['label' => 'X', 'expiresAt' => '', 'active' => true]);

        self::assertNull($link->getExpiresAt());
        self::assertTrue($link->isUsable());
    }

    public function testRefusesAMissingLabelAndAnInvalidDate(): void
    {
        foreach ([['label' => ''], ['label' => 'X', 'expiresAt' => '2030-02-30'], ['label' => 'X', 'expiresAt' => '17.05.2030']] as $data) {
            try {
                AccessLinkInput::apply(new AccessLink(), $data);
                self::fail('Refused: ' . json_encode($data));
            } catch (\InvalidArgumentException) {
                self::addToAssertionCount(1);
            }
        }
    }
}
