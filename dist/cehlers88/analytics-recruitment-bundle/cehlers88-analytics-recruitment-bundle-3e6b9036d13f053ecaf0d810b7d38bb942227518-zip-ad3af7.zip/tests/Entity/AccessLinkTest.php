<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\Tests\Entity;

use Cehlers88\AnalyticsRecruitmentBundle\Entity\AccessLink;
use PHPUnit\Framework\TestCase;

class AccessLinkTest extends TestCase
{
    public function testEveryLinkGetsItsOwnRandomUuid(): void
    {
        $first = new AccessLink();
        $second = new AccessLink();

        self::assertMatchesRegularExpression('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/', $first->getUuid());
        self::assertNotSame($first->getUuid(), $second->getUuid());
    }

    public function testCountsVisits(): void
    {
        $link = new AccessLink();
        $link->recordVisit(new \DateTimeImmutable('2030-01-01 10:00'));
        $link->recordVisit(new \DateTimeImmutable('2030-01-02 12:00'));

        self::assertSame(2, $link->getVisitCount());
        self::assertSame('2030-01-01 10:00', $link->getFirstVisitedAt()?->format('Y-m-d H:i'));
        self::assertSame('2030-01-02 12:00', $link->getLastVisitedAt()?->format('Y-m-d H:i'));
    }

    public function testASwitchedOffLinkIsNotUsable(): void
    {
        self::assertFalse(new AccessLink()->setActive(false)->isUsable());
    }
}
