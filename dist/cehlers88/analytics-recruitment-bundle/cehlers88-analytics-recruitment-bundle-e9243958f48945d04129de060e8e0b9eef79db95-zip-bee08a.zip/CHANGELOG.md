# Changelog

## [1.0.1](https://github.com/cEhlers88/AnalyticsRecruitmentBundle/compare/v1.0.0...v1.0.1) (2026-09-29)


### Bug Fixes

* Use the English category id `Career` for the references tool ([f4831a1](https://github.com/cEhlers88/AnalyticsRecruitmentBundle/commit/f4831a1861035679db52ed6c2b412450ba152297))
* Use the English category id `Career` for the references tool ([#2](https://github.com/cEhlers88/AnalyticsRecruitmentBundle/issues/2)) ([3e6b903](https://github.com/cEhlers88/AnalyticsRecruitmentBundle/commit/3e6b9036d13f053ecaf0d810b7d38bb942227518))

## 1.0.0 (2026-09-27)


### Miscellaneous Chores

* Add GitHub Actions workflows for automated releases and Satis rebuild trigger ([46a466e](https://github.com/cEhlers88/AnalyticsRecruitmentBundle/commit/46a466e38e660524ec49825284625ae74ebc6bb5))
* Add RecruitmentBundle for managing references and access links ([ea96865](https://github.com/cEhlers88/AnalyticsRecruitmentBundle/commit/ea96865b7bb384ca28cf24fb5feeed5c235e010b))
