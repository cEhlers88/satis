<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsRecruitmentBundle\EventSubscriber;

use Cehlers88\AnalyticsCore\Event\Tool\CollectToolsEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

/**
 * Brings the references editor to the tools page of the application (CollectToolsEvent).
 * Who may use it is set in the tool settings like for every other tool - the permission
 * MANAGE_RECRUITMENT the bundle declares is meant for that; ToolAccess then also keeps
 * everybody else away from the backend routes (analytics_recruitment_admin_*).
 */
final class RecruitmentToolSubscriber implements EventSubscriberInterface
{
    /** A route of ReferenceAdminController - it exists only when the application imports the bundle's routes. */
    private const ROUTE = 'analytics_recruitment_admin_references';

    public function __construct(private readonly UrlGeneratorInterface $urlGenerator)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [CollectToolsEvent::class => 'onCollectTools'];
    }

    public function onCollectTools(CollectToolsEvent $event): void
    {
        // without its routes the tool could not render (path()) and would break the whole tools page
        try {
            $this->urlGenerator->generate(self::ROUTE);
        } catch (RouteNotFoundException) {
            return;
        }

        $event->addTool([
            'name' => 'recruitmentReferences',
            'title' => 'Referenzen & Zugriffslinks',
            'description' => 'Die Projekte des Portfolios mit Texten, Bildern und Angaben pflegen und per Zugriffslink ohne Anmeldung zeigen - samt Aufrufstatistik',
            'categories' => ['Bewerbung', 'Workspace'],
            'teaser' => 'recruitment/teaser/references.html.twig',
            'template' => 'recruitment/references.html.twig',
            'scripts' => ['recruitment/script/references.js.twig'],
            'styles' => ['recruitment/style/references.html.twig'],
            'routes' => ['analytics_recruitment_admin_'],
        ]);
    }
}
