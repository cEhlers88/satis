<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 24.05.2024
 * Time: 16:14
 */

namespace Cehlers88\AnalyticsFiBuBundle\Configuration;

use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;
use Cehlers88\AnalyticsFiBuBundle\Repository\PaymentMethodRepository;

class GeneralConfigurationGroup extends AbstractConfigurationGroup
{
    public function __construct(
        private PaymentMethodRepository $paymentMethodRepository
    )
    {
    }

    public function getItems(): array
    {
        return [
            ConfigurationItemDTO::createSelect(
                'defaultPaymentMethod',
                $this->getPaymentMethodOptions(),
                'Default payment method',
                null,
                ''
            )
        ];
    }

    private function getPaymentMethodOptions(): array
    {
        $options = [
            ['value' => '', 'label' => 'None']
        ];
        array_map(function ($paymentMethod) use (&$options) {
            $options[] = ['value' => $paymentMethod->getId(), 'label' => $paymentMethod->getName()];
        }, $this->paymentMethodRepository->findAll());
        return $options;
    }

    public function getGroupTitle(): string
    {
        return 'Allgemeine Finanzbuchhaltungseinstellungen';
    }

    public function getGroupDescription(): string
    {
        return 'Allgemeine Einstellungen für das Finanzbuchhaltungsmodul';
    }

    public function getKey(): string
    {
        return 'fibuBundle.general';
    }
}