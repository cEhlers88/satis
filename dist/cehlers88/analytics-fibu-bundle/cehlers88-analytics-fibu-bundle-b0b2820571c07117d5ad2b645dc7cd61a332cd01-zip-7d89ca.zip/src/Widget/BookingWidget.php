<?php

namespace Cehlers88\AnalyticsFiBuBundle\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Analytics\Widget\AbstractWidget;
use Cehlers88\AnalyticsFiBuBundle\Repository\PaymentMethodRepository;

class BookingWidget extends AbstractWidget
{
    public function __construct(
        private PaymentMethodRepository $paymentMethodRepository
    ){

    }

    public function getName(): string
    {
        return 'booking';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height'=>'50px','boxes'=>[1]],
            ['height'=>'50px','boxes'=>[1]],
            ['height'=>'50px','boxes'=>[1]],
            ['height'=>'120px','boxes'=>[1]],
            ['height'=>'50px','boxes'=>[.4,.6]],
        ];
    }

    public function enrichProperties(array $properties) : array
    {
        return  [
            ...$properties,
            'paymentMethods' => $this->paymentMethodRepository->findAll()
        ];
    }

    public function getRequiredRoles(): array
    {
        return [
            'ROLE_USER',
            'FIBU_USER'
        ];
    }

    public function submit(array $data): WidgetSubmitResultDTO
    {
        return WidgetSubmitResultDTO::createSuccess('Success', [], 200);
    }
}