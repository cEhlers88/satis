<?php

namespace Cehlers88\AnalyticsFiBuBundle\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsFiBuBundle\AnalyticsFiBuBundle;
use Cehlers88\AnalyticsFiBuBundle\Schedule\Recurrence;
use Cehlers88\AnalyticsFiBuBundle\Schedule\ScheduledBookingService;

/**
 * The planned bookings and standing orders (Daueraufträge): lists the pending
 * ones and lets them be changed, ended or added.
 */
class ScheduledBookingsWidget extends AbstractFiBuWidget
{
    private const ACTION_LIST = 'list';
    private const ACTION_CREATE = 'create';
    private const ACTION_UPDATE = 'update';
    private const ACTION_CANCEL = 'cancel';
    private const ACTION_CREATE_PAYMENT_METHOD = 'createPaymentMethod';

    public function __construct(
        private ScheduledBookingService $scheduledBookingService,
        ConfigurationProvider           $configurationProvider,
        CustomObjectProvider            $customObjectProvider,
        ApplicationRepository           $applicationRepository,
    )
    {
        parent::__construct($configurationProvider, $customObjectProvider, $applicationRepository);
    }

    public function getName(): string
    {
        return AnalyticsFiBuBundle::getBundleName() . '.scheduledBookings';
    }

    public function getTemplateName(): string
    {
        return 'scheduledBookings';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '28px', 'boxes' => [.6, .3]],
            ['height' => '44px', 'boxes' => [1]],
            ['height' => '44px', 'boxes' => [1]],
            ['height' => '44px', 'boxes' => [1]],
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $paymentMethods = $this->getPaymentMethods();

        return [
            ...$properties,
            'now' => new \DateTime(),
            'paymentMethods' => $paymentMethods,
            'defaultFromPaymentMethod' => $this->getDefaultFromPaymentMethod(),
            'intervals' => Recurrence::INTERVALS,
            'schedules' => $this->getScheduleViews(),
        ];
    }

    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        return match ($data['action'] ?? self::ACTION_LIST) {
            self::ACTION_CREATE => $this->create($data, $user),
            self::ACTION_UPDATE => $this->update($data, $user),
            self::ACTION_CANCEL => $this->cancel($data),
            self::ACTION_CREATE_PAYMENT_METHOD => $this->createPaymentMethod($data),
            default => WidgetSubmitResultDTO::createSuccess('', ['schedules' => $this->getScheduleViews()], 200),
        };
    }

    private function create(array $data, ?User $user): WidgetSubmitResultDTO
    {
        $values = $this->readValues($data);
        if ($values instanceof WidgetSubmitResultDTO) {
            return $values;
        }
        $applicationId = $this->resolveApplicationId($data);
        if (!is_null($applicationError = $this->validateApplication($applicationId))) {
            return $applicationError;
        }

        try {
            $this->scheduledBookingService->create(
                $applicationId,
                $values['transaction'],
                $values['nextExecution'],
                $values['interval'],
                $data,
                $values['autoApprove'],
                $user ? (int)$user->getId() : -1
            );
        } catch (\InvalidArgumentException $exception) {
            return WidgetSubmitResultDTO::createError(400, $exception->getMessage());
        }

        return WidgetSubmitResultDTO::createSuccess(
            $values['interval'] === '' ? 'Buchung geplant.' : 'Dauerauftrag angelegt.',
            ['schedules' => $this->getScheduleViews()],
            200
        );
    }

    private function update(array $data, ?User $user): WidgetSubmitResultDTO
    {
        $trackingBuffer = $this->scheduledBookingService->findPending((int)($data['id'] ?? 0));
        if (is_null($trackingBuffer)) {
            return WidgetSubmitResultDTO::createError(404, 'Dauerauftrag nicht gefunden - vielleicht wurde er inzwischen ausgeführt.');
        }

        $values = $this->readValues(
            $data,
            (string)($trackingBuffer->getData()['data']['repeatOptions']['interval'] ?? '')
        );
        if ($values instanceof WidgetSubmitResultDTO) {
            return $values;
        }

        try {
            $this->scheduledBookingService->update(
                $trackingBuffer,
                $values['transaction'],
                $values['nextExecution'],
                $values['interval'],
                $data,
                $values['autoApprove'],
                $user ? (int)$user->getId() : -1
            );
        } catch (\InvalidArgumentException $exception) {
            return WidgetSubmitResultDTO::createError(400, $exception->getMessage());
        }

        return WidgetSubmitResultDTO::createSuccess('Änderungen gespeichert.', [
            'schedules' => $this->getScheduleViews(),
        ], 200);
    }

    private function cancel(array $data): WidgetSubmitResultDTO
    {
        $trackingBuffer = $this->scheduledBookingService->findPending((int)($data['id'] ?? 0));
        if (is_null($trackingBuffer)) {
            return WidgetSubmitResultDTO::createError(404, 'Dauerauftrag nicht gefunden.');
        }

        $this->scheduledBookingService->cancel($trackingBuffer);

        return WidgetSubmitResultDTO::createSuccess('Dauerauftrag beendet.', [
            'schedules' => $this->getScheduleViews(),
        ], 200);
    }

    /**
     * What create and update both take, validated. $keptInterval is the one
     * a schedule being changed already has, accepted even if not offered.
     *
     * @return array{transaction: \Cehlers88\AnalyticsFiBuBundle\DTO\TransactionDTO, nextExecution: \DateTimeImmutable, interval: string, autoApprove: bool}|WidgetSubmitResultDTO
     */
    private function readValues(array $data, string $keptInterval = ''): array|WidgetSubmitResultDTO
    {
        $amount = $this->parseAmount($data['amount'] ?? '');
        $from = (int)($data['from'] ?? 0);
        $to = (int)($data['to'] ?? 0);
        $interval = (string)($data['interval'] ?? '');

        if ($amount === null || $amount <= 0) {
            return WidgetSubmitResultDTO::createError(400, 'Bitte einen Betrag größer 0 eingeben.');
        }
        if (!is_null($accountError = $this->validateAccounts($from, $to))) {
            return $accountError;
        }
        if ($interval !== '' && $interval !== $keptInterval && !Recurrence::isKnownInterval($interval)) {
            return WidgetSubmitResultDTO::createError(400, 'Unbekannte Wiederholung.');
        }
        $nextExecution = ScheduledBookingService::parseDate((string)($data['executionDate'] ?? ''));
        if (is_null($nextExecution)) {
            return WidgetSubmitResultDTO::createError(400, 'Ungültiges Ausführungsdatum.');
        }
        // Today is fine - the worker books it on its next pass - but a date
        // already past would be booked late without anyone noticing.
        if ($nextExecution < new \DateTimeImmutable('today')) {
            return WidgetSubmitResultDTO::createError(400, 'Die nächste Ausführung darf nicht in der Vergangenheit liegen.');
        }

        return [
            'transaction' => $this->createTransaction($amount, $from, $to, trim((string)($data['description'] ?? ''))),
            'nextExecution' => $nextExecution,
            'interval' => $interval,
            // A planned one-off booking was approved by entering it; the
            // executions of a standing order only when that was asked for.
            'autoApprove' => $interval === '' || filter_var($data['autoApprove'] ?? false, FILTER_VALIDATE_BOOLEAN),
        ];
    }

    private function getScheduleViews(): array
    {
        return $this->scheduledBookingService->getViews($this->getPaymentMethodNames(), $this->getOwnPaymentMethodIds());
    }
}
