<?php

namespace Cehlers88\AnalyticsFiBuBundle\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Widget\AbstractWidget;
use Cehlers88\AnalyticsFiBuBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\PaymentMethod;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionDTO;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionPostingDTO;
use Cehlers88\AnalyticsFiBuBundle\ENUM\EPermission;

/**
 * What the booking widget and the standing-order widget both need to turn
 * submitted values into a valid transaction.
 */
abstract class AbstractFiBuWidget extends AbstractWidget
{
    public function __construct(
        protected ConfigurationProvider $configurationProvider,
        protected CustomObjectProvider  $customObjectProvider,
        protected ApplicationRepository $applicationRepository,
    )
    {
    }

    public function getRequiredRoles(): array
    {
        return [
            'ROLE_USER',
            EPermission::ACCESS_FIBU->value
        ];
    }

    /**
     * Money leaves the "from" account (credit) and arrives on the "to" account
     * (debit), see ExecuteBookingJob.
     */
    protected function createTransaction(float $amount, int $from, int $to, string $description, string $bookingDate = ''): TransactionDTO
    {
        return TransactionDTO::createFromArray([
            'description' => $description,
            'bookingDate' => $bookingDate,
            'postings' => [
                TransactionPostingDTO::createFromArray([
                    'amount' => $amount,
                    'paymentMethod' => $to,
                    'type' => 'debit',
                ]),
                TransactionPostingDTO::createFromArray([
                    'amount' => $amount,
                    'paymentMethod' => $from,
                    'type' => 'credit',
                ])
            ],
        ]);
    }

    /**
     * The quick creation of an account typed into the widget that does not
     * exist yet. Asking twice for the same name (case-insensitive) answers with
     * the existing account instead of creating a second one.
     */
    protected function createPaymentMethod(array $data): WidgetSubmitResultDTO
    {
        $name = trim((string)($data['name'] ?? ''));
        if ($name === '') {
            return WidgetSubmitResultDTO::createError(400, 'Bitte einen Namen für den Zahlungsweg angeben.');
        }
        if (mb_strlen($name) > 255) {
            return WidgetSubmitResultDTO::createError(400, 'Der Name ist zu lang (höchstens 255 Zeichen).');
        }

        $startAmount = 0.0;
        if (trim((string)($data['startAmount'] ?? '')) !== '') {
            $startAmount = $this->parseAmount($data['startAmount']);
            if (is_null($startAmount)) {
                return WidgetSubmitResultDTO::createError(400, 'Ungültiger Startbetrag.');
            }
        }

        foreach ($this->getPaymentMethods() as $paymentMethod) {
            if (mb_strtolower($paymentMethod->getName()) === mb_strtolower($name)) {
                return WidgetSubmitResultDTO::createSuccess('Zahlungsweg existiert bereits.', [
                    'paymentMethod' => $this->createPaymentMethodOption($paymentMethod),
                ], 200);
            }
        }

        /** @var PaymentMethod $paymentMethod */
        $paymentMethod = $this->customObjectProvider->createNewCustomEntity(PaymentMethod::class);
        $paymentMethod->setName($name);
        $paymentMethod
            ->setDescription(trim((string)($data['description'] ?? '')))
            ->setStartAmount($startAmount)
            // A new account has seen no booking yet, so it holds what it started with.
            ->setCurrentAmount($startAmount)
            // Created on the fly, it may be needed on either side of a booking.
            ->setIsDebitor(true)
            ->setIsCreditor(true);

        $this->customObjectProvider->save($paymentMethod);

        // Read back like saveTemplate does: the id is only known once stored.
        $saved = $this->customObjectProvider->getCustomEntityByClassNameAndName(PaymentMethod::class, $name);
        if (!$saved instanceof PaymentMethod || (int)$saved->getId() <= 0) {
            return WidgetSubmitResultDTO::createError(500, 'Der Zahlungsweg konnte nicht angelegt werden.');
        }

        return WidgetSubmitResultDTO::createSuccess('Zahlungsweg „' . $name . '“ angelegt.', [
            'paymentMethod' => $this->createPaymentMethodOption($saved),
        ], 200);
    }

    /**
     * An entry of the account suggestions.
     *
     * @return array{value: string, label: string}
     */
    protected function createPaymentMethodOption(PaymentMethod $paymentMethod): array
    {
        return ['value' => (string)$paymentMethod->getId(), 'label' => $paymentMethod->getName()];
    }

    /**
     * @return PaymentMethod[]
     */
    protected function getPaymentMethods(): array
    {
        $paymentMethods = $this->customObjectProvider->getCustomEntitiesByClassName(PaymentMethod::class);
        usort($paymentMethods, fn(PaymentMethod $a, PaymentMethod $b) => strcasecmp($a->getName(), $b->getName()));

        return $paymentMethods;
    }

    /**
     * @return array<int, string> id => name
     */
    protected function getPaymentMethodNames(): array
    {
        $names = [];
        foreach ($this->getPaymentMethods() as $paymentMethod) {
            $names[$paymentMethod->getId()] = $paymentMethod->getName();
        }

        return $names;
    }

    /**
     * The accounts set up as one's own in the FiBu settings - what tells an
     * incoming payment from an outgoing one, as in ExecuteBookingJob.
     *
     * @return int[]
     */
    protected function getOwnPaymentMethodIds(): array
    {
        $entries = $this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'ownPaymentMethods');

        $ids = [];
        foreach (is_iterable($entries) ? $entries : [] as $entry) {
            $id = (int)(is_array($entry) ? ($entry['paymentMethod'] ?? 0) : 0);
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return $ids;
    }

    protected function getDefaultFromPaymentMethod(): mixed
    {
        return $this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'defaultPaymentMethod');
    }

    protected function resolveApplicationId(array $data): int
    {
        $applicationId = (int)($data['applicationId'] ?? -1);

        if ($applicationId <= 0) {
            $applicationId = (int)$this->configurationProvider->getValue(
                GeneralConfigurationGroup::KEY,
                'defaultApplication'
            );
        }

        return $applicationId;
    }

    /**
     * The application the tracking buffer entries go to. Without one they can
     * not be created at all - better say so than fail with a server error.
     */
    protected function validateApplication(int $applicationId): ?WidgetSubmitResultDTO
    {
        if ($applicationId <= 0) {
            return WidgetSubmitResultDTO::createError(400, 'Keine Anwendung für Buchungen eingestellt (FiBu-Einstellungen: Default application).');
        }
        if (is_null($this->applicationRepository->find($applicationId))) {
            return WidgetSubmitResultDTO::createError(400, 'Unbekannte Anwendung: ' . $applicationId);
        }

        return null;
    }

    /**
     * Both accounts must be payment methods: ExecuteBookingJob skips one it can
     * not find and would book only the other half of the transaction.
     */
    protected function validateAccounts(int $from, int $to): ?WidgetSubmitResultDTO
    {
        if ($from <= 0 || $to <= 0) {
            return WidgetSubmitResultDTO::createError(400, 'Bitte Ursprungs- und Zielkonto wählen.');
        }
        if ($from === $to) {
            return WidgetSubmitResultDTO::createError(400, 'Ursprungs- und Zielkonto müssen sich unterscheiden.');
        }

        $paymentMethodIds = array_map(fn(PaymentMethod $paymentMethod) => $paymentMethod->getId(), $this->getPaymentMethods());
        if (!in_array($from, $paymentMethodIds, true) || !in_array($to, $paymentMethodIds, true)) {
            return WidgetSubmitResultDTO::createError(400, 'Unbekanntes Konto.');
        }

        return null;
    }

    /**
     * Accepts "1234.5", "1234,50" and "1.234,50" alike.
     */
    protected function parseAmount(mixed $value): ?float
    {
        $value = str_replace([' ', '€'], '', trim((string)$value));
        if (str_contains($value, ',')) {
            $value = str_replace(['.', ','], ['', '.'], $value);
        }

        if (!is_numeric($value) || !is_finite((float)$value)) {
            return null;
        }

        return round((float)$value, 2);
    }
}
