<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsFiBuBundle\Overview;

use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionDTO;
use Cehlers88\AnalyticsFiBuBundle\Schedule\ScheduledBookingService;

/**
 * The bookings of a period as seen from a chosen set of payment methods: what
 * came in, what went out, per payment method and over time.
 *
 * Seen from the set, money arriving on one of its payment methods from outside
 * is incoming, money leaving it for outside outgoing, and money moved between
 * two of them a transfer - which changes the payment methods involved but not
 * the totals. Bookings that touch none of them are left out.
 */
final class BookingOverview
{
    /**
     * @param iterable<array{id: int|null, date: \DateTimeInterface, transaction: mixed}> $entries
     *        the executed bookings, dated by their booking date; those outside
     *        the period are skipped
     * @param int[] $paymentMethodIds the payment methods the overview is about
     * @param array<int, string> $paymentMethodNames id => name of every payment method
     * @param array<int, float> $currentAmounts id => current balance
     * @param int|null $maxBookings how many bookings to list, newest first;
     *        the totals and the chart still count every one
     *
     * @return array{
     *     bookings: list<array<string, mixed>>,
     *     totals: array{incoming: float, outgoing: float, balance: float, transfers: float, count: int},
     *     paymentMethods: list<array{id: int, name: string, incoming: float, outgoing: float, balance: float, currentAmount: float|null}>,
     *     chart: array{bucket: string, labels: list<string>, incoming: list<float>, outgoing: list<float>}
     * }
     */
    public static function build(
        iterable      $entries,
        array         $paymentMethodIds,
        array         $paymentMethodNames,
        BookingPeriod $period,
        array         $currentAmounts = [],
        ?int          $maxBookings = null,
    ): array
    {
        $selected = array_fill_keys(array_map('intval', $paymentMethodIds), true);

        $bookings = [];
        $totals = ['incoming' => 0.0, 'outgoing' => 0.0, 'balance' => 0.0, 'transfers' => 0.0, 'count' => 0];
        $perPaymentMethod = [];
        foreach (array_keys($selected) as $id) {
            $perPaymentMethod[$id] = [
                'id' => $id,
                'name' => $paymentMethodNames[$id] ?? ('#' . $id),
                'incoming' => 0.0,
                'outgoing' => 0.0,
                'balance' => 0.0,
                'currentAmount' => array_key_exists($id, $currentAmounts) ? (float)$currentAmounts[$id] : null,
            ];
        }
        $buckets = self::createBuckets($period);
        $chartIncoming = array_fill_keys(array_keys($buckets), 0.0);
        $chartOutgoing = $chartIncoming;

        foreach ($entries as $entry) {
            [$from, $to, $amount, $description] = self::readTransaction($entry['transaction'] ?? null);
            $fromSelected = !is_null($from) && isset($selected[$from]);
            $toSelected = !is_null($to) && isset($selected[$to]);
            if ((!$fromSelected && !$toSelected) || $amount == 0) {
                continue;
            }

            $direction = ScheduledBookingService::resolveDirection($from, $to, array_keys($selected));
            $date = \DateTimeImmutable::createFromInterface($entry['date']);
            if ($date < $period->start || $date >= $period->getEndExclusive()) {
                continue;
            }
            $bucket = self::bucketKey($date, $period->getBucket());

            if ($fromSelected) {
                $perPaymentMethod[$from]['outgoing'] += $amount;
                $perPaymentMethod[$from]['balance'] -= $amount;
            }
            if ($toSelected) {
                $perPaymentMethod[$to]['incoming'] += $amount;
                $perPaymentMethod[$to]['balance'] += $amount;
            }

            match ($direction) {
                'incoming' => $totals['incoming'] += $amount,
                'outgoing' => $totals['outgoing'] += $amount,
                default => $totals['transfers'] += $amount,
            };
            if ($direction === 'incoming' && isset($chartIncoming[$bucket])) {
                $chartIncoming[$bucket] += $amount;
            }
            if ($direction === 'outgoing' && isset($chartOutgoing[$bucket])) {
                $chartOutgoing[$bucket] += $amount;
            }
            $totals['count']++;

            $bookings[] = [
                'id' => $entry['id'] ?? null,
                'date' => $date->format('Y-m-d'),
                'description' => $description,
                'amount' => round($amount, 2),
                'direction' => $direction,
                'fromId' => $from,
                'toId' => $to,
                'from' => $paymentMethodNames[$from] ?? '?',
                'to' => $paymentMethodNames[$to] ?? '?',
            ];
        }

        // Newest first, whatever order the entries came in.
        // Newest first by booking date, the later entered first within a day.
        usort($bookings, fn(array $a, array $b) => strcmp($b['date'], $a['date']) ?: (int)$b['id'] <=> (int)$a['id']);
        if (!is_null($maxBookings)) {
            $bookings = array_slice($bookings, 0, $maxBookings);
        }

        $totals['balance'] = $totals['incoming'] - $totals['outgoing'];
        foreach (['incoming', 'outgoing', 'balance', 'transfers'] as $key) {
            $totals[$key] = round($totals[$key], 2);
        }

        $paymentMethods = array_values(array_map(static function (array $row): array {
            foreach (['incoming', 'outgoing', 'balance'] as $key) {
                $row[$key] = round($row[$key], 2);
            }
            return $row;
        }, $perPaymentMethod));
        usort($paymentMethods, fn(array $a, array $b) => strcasecmp($a['name'], $b['name']));

        return [
            'bookings' => $bookings,
            'totals' => $totals,
            'paymentMethods' => $paymentMethods,
            'chart' => [
                'bucket' => $period->getBucket(),
                'labels' => array_values($buckets),
                'incoming' => array_values(array_map(fn(float $value) => round($value, 2), $chartIncoming)),
                'outgoing' => array_values(array_map(fn(float $value) => round($value, 2), $chartOutgoing)),
            ],
        ];
    }

    /**
     * The paying account (credit), the receiving one (debit), the amount and
     * the description of a booking. A negative amount - the former booking
     * widget allowed one - is the same booking the other way round.
     *
     * @return array{0: int|null, 1: int|null, 2: float, 3: string}
     */
    private static function readTransaction(mixed $transaction): array
    {
        if (!$transaction instanceof TransactionDTO) {
            $transaction = TransactionDTO::createFromArray(is_array($transaction) ? $transaction : []);
        }

        $from = null;
        $to = null;
        $amount = 0.0;
        foreach ($transaction->postings as $posting) {
            $amount = (float)$posting->amount;
            if ($posting->type === 'credit') {
                $from = (int)$posting->paymentMethod;
            } else {
                $to = (int)$posting->paymentMethod;
            }
        }

        if ($amount < 0) {
            [$from, $to, $amount] = [$to, $from, -$amount];
        }

        return [$from, $to, $amount, $transaction->description];
    }

    /**
     * Every step of the period, so a day without bookings is a zero on the
     * diagram instead of a gap that pulls its neighbours together.
     *
     * @return array<string, string> bucket key => label
     */
    private static function createBuckets(BookingPeriod $period): array
    {
        $bucket = $period->getBucket();
        [$step, $labelFormat] = match ($bucket) {
            BookingPeriod::BUCKET_DAY => ['+1 day', 'd.m.'],
            BookingPeriod::BUCKET_MONTH => ['+1 month', 'm/Y'],
            default => ['+1 year', 'Y'],
        };

        $buckets = [];
        $cursor = match ($bucket) {
            BookingPeriod::BUCKET_DAY => $period->start,
            BookingPeriod::BUCKET_MONTH => $period->start->modify('first day of this month'),
            default => $period->start->modify('first day of january this year'),
        };
        while ($cursor <= $period->end) {
            $buckets[self::bucketKey($cursor, $bucket)] = $cursor->format($labelFormat);
            $cursor = $cursor->modify($step);
        }

        return $buckets;
    }

    private static function bucketKey(\DateTimeImmutable $date, string $bucket): string
    {
        return $date->format(match ($bucket) {
            BookingPeriod::BUCKET_DAY => 'Y-m-d',
            BookingPeriod::BUCKET_MONTH => 'Y-m',
            default => 'Y',
        });
    }
}
