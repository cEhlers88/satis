<?php

namespace Cehlers88\AnalyticsFiBuBundle\DTO;

use Cehlers88\AnalyticsCore\Support\DTO\DTO;

class TransactionDTO extends DTO
{
    public string $description = '';

    /**
     * The day the booking belongs to (Y-m-d), which is not necessarily the day
     * it was processed: a standing order set up retroactively books each past
     * execution at once, but on the date it was due. Empty for bookings from
     * before the field existed - see BookingDate::of().
     */
    public string $bookingDate = '';

    /** @var int[] */
    public array $categories = [];

    /** @var TransactionPostingDTO[] */
    public array $postings = [];

    public static function createFromArray(array $arr): self
    {
        $dto = new self();
        $dto->description = $arr['description'] ?? '';
        $dto->bookingDate = (string)($arr['bookingDate'] ?? '');
        $dto->categories = $arr['categories'] ?? [];
        $dto->postings = [];

        foreach ($arr['postings'] ?? [] as $posting) {
            if ($posting instanceof TransactionPostingDTO) {
                $dto->postings[] = $posting;
                continue;
            }

            $dto->postings[] = TransactionPostingDTO::createFromArray($posting);
        }

        return $dto;
    }
}