<?php

namespace Cehlers88\AnalyticsFiBuBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Cehlers88\AnalyticsFiBuBundle\Repository\PaymentMethodRepository;

#[ORM\Entity(repositoryClass: PaymentMethodRepository::class)]
#[ORM\Table(name: 'fibu_payment_method')]
class PaymentMethod
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $description = null;

    #[ORM\Column]
    private bool $isCreditor = false;
    #[ORM\Column]
    private bool $isDebitor = false;

    #[ORM\Column]
    private float $startAmount = 0;
    #[ORM\Column]
    private float $currentAmount = 0;
    #[ORM\Column(nullable: true)]
    private ?float $overdraftLimit = null;

    #[ORM\ManyToOne]
    private ?BankAccount $bankAccount = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getBankAccount(): ?BankAccount
    {
        return $this->bankAccount;
    }

    public function setBankAccount(?BankAccount $bankAccount): static
    {
        $this->bankAccount = $bankAccount;

        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function isCreditor(): bool
    {
        return $this->isCreditor;
    }

    public function setIsCreditor(bool $isCreditor): static
    {
        $this->isCreditor = $isCreditor;
        return $this;
    }

    public function isDebitor(): bool
    {
        return $this->isDebitor;
    }

    public function setIsDebitor(bool $isDebitor): static
    {
        $this->isDebitor = $isDebitor;
        return $this;
    }

    public function getStartAmount(): float
    {
        return $this->startAmount;
    }

    public function setStartAmount(float $startAmount): static
    {
        $this->startAmount = $startAmount;
        return $this;
    }

    public function getCurrentAmount(): float
    {
        return round($this->currentAmount,2);
    }

    public function setCurrentAmount(float $currentAmount): static
    {
        $this->currentAmount = $currentAmount;
        return $this;
    }

    public function getOverdraftLimit(): ?float
    {
        return $this->overdraftLimit;
    }

    public function setOverdraftLimit(?float $overdraftLimit): static
    {
        $this->overdraftLimit = $overdraftLimit;
        return $this;
    }
}
