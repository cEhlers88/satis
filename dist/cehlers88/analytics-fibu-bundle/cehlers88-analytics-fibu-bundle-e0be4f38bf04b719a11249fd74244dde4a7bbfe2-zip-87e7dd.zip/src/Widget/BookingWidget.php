<?php

namespace Cehlers88\AnalyticsFiBuBundle\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Recorder\TrackingRecorder;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Widget\AbstractWidget;
use Cehlers88\AnalyticsFiBuBundle\AnalyticsFiBuBundle;
use Cehlers88\AnalyticsFiBuBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\BookingTemplate;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\PaymentMethod;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionDTO;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionPostingDTO;
use Cehlers88\AnalyticsFiBuBundle\ENUM\EPermission;
use Cehlers88\AnalyticsFiBuBundle\Schedule\Recurrence;
use Cehlers88\AnalyticsFiBuBundle\Worker\Job\ExecuteBookingJob;
use Cehlers88\AnalyticsFiBuBundle\Worker\Job\HandleScheduledBookingsJob;

class BookingWidget extends AbstractWidget
{
    private const ACTION_BOOK = 'book';
    private const ACTION_SAVE_TEMPLATE = 'saveTemplate';
    private const ACTION_CANCEL_SCHEDULE = 'cancelSchedule';

    private const END_NEVER = 'never';
    private const END_DATE = 'date';
    private const END_COUNT = 'count';

    public function __construct(
        private TrackingRecorder         $trackingRecorder,
        private ConfigurationProvider    $configurationProvider,
        private CustomObjectProvider     $customObjectProvider,
        private TrackingBufferRepository $trackingBufferRepository,
        private ApplicationRepository    $applicationRepository,
    )
    {

    }

    public function getName(): string
    {
        return AnalyticsFiBuBundle::getBundleName() . '.booking';
    }

    public function getTemplateName(): string
    {
        return 'booking';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '28px', 'boxes' => [.3, .3, .3]],
            ['height' => '48px', 'boxes' => [1]],
            ['height' => '40px', 'boxes' => [.45, .1, .45]],
            ['height' => '40px', 'boxes' => [1]],
            ['height' => '40px', 'boxes' => [.5, .5]],
            ['height' => '36px', 'boxes' => [.6, .4]],
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $paymentMethods = $this->getPaymentMethods();

        return [
            ...$properties,
            'now' => new \DateTime(),
            'paymentMethods' => $paymentMethods,
            'defaultFromPaymentMethod' => $this->configurationProvider->getValue(
                GeneralConfigurationGroup::KEY,
                'defaultPaymentMethod'
            ),
            'intervals' => Recurrence::INTERVALS,
            'bookingTemplates' => array_map(
                fn(BookingTemplate $template) => $this->createTemplateView($template),
                $this->getBookingTemplates()
            ),
            'schedules' => $this->getScheduleViews(),
        ];
    }

    public function getRequiredRoles(): array
    {
        return [
            'ROLE_USER',
            EPermission::ACCESS_FIBU->value
        ];
    }

    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        return match ($data['action'] ?? self::ACTION_BOOK) {
            self::ACTION_SAVE_TEMPLATE => $this->saveTemplate($data),
            self::ACTION_CANCEL_SCHEDULE => $this->cancelSchedule($data),
            default => $this->book($data, $user),
        };
    }

    private function book(array $data, ?User $user): WidgetSubmitResultDTO
    {
        // Callers of the former widget send "creditor" (the paying account) and
        // "debitor" (the receiving one) and expect the booking to be made at once,
        // whatever executionDate they pass - they keep getting exactly that.
        $isLegacyRequest = !isset($data['from'], $data['to']) && (isset($data['creditor']) || isset($data['debitor']));

        $amount = $this->parseAmount($data['amount'] ?? '');
        $from = (int)($data[$isLegacyRequest ? 'creditor' : 'from'] ?? 0);
        $to = (int)($data[$isLegacyRequest ? 'debitor' : 'to'] ?? 0);
        $description = trim((string)($data['description'] ?? ''));
        $interval = $isLegacyRequest ? '' : (string)($data['interval'] ?? '');

        // The former widget allowed negative amounts (a booking the other way round).
        if ($amount === null || ($isLegacyRequest ? $amount == 0 : $amount <= 0)) {
            return WidgetSubmitResultDTO::createError(400, 'Bitte einen Betrag größer 0 eingeben.');
        }
        if (!is_null($accountError = $this->validateAccounts($from, $to))) {
            return $accountError;
        }
        if ($interval !== '' && !Recurrence::isKnownInterval($interval)) {
            return WidgetSubmitResultDTO::createError(400, 'Unbekannte Wiederholung.');
        }

        $executionDate = ($isLegacyRequest || empty($data['executionDate']))
            ? new \DateTimeImmutable('today')
            : $this->parseDate((string)$data['executionDate']);
        if (is_null($executionDate)) {
            return WidgetSubmitResultDTO::createError(400, 'Ungültiges Ausführungsdatum.');
        }

        $applicationId = $this->resolveApplicationId($data);
        // Without an application the tracking buffer entry can not be created
        // at all - better say so than fail with a server error.
        if ($applicationId <= 0) {
            return WidgetSubmitResultDTO::createError(400, 'Keine Anwendung für Buchungen eingestellt (FiBu-Einstellungen: Default application).');
        }
        if (is_null($this->applicationRepository->find($applicationId))) {
            return WidgetSubmitResultDTO::createError(400, 'Unbekannte Anwendung: ' . $applicationId);
        }
        $approvedBy = $user ? $user->getId() : -1;
        $transaction = TransactionDTO::createFromArray([
            'description' => $description,
            'postings' => [
                // Money leaves the "from" account (credit) and arrives on the
                // "to" account (debit), see ExecuteBookingJob.
                TransactionPostingDTO::createFromArray([
                    'amount' => $amount,
                    'paymentMethod' => $to,
                    'type' => 'debit',
                ]),
                TransactionPostingDTO::createFromArray([
                    'amount' => $amount,
                    'paymentMethod' => $from,
                    'type' => 'credit',
                ])
            ],
        ]);

        $today = new \DateTimeImmutable('today');
        if ($isLegacyRequest || ($interval === '' && $executionDate <= $today)) {
            $this->trackingRecorder->track(
                $applicationId,
                [
                    'key' => ExecuteBookingJob::$KEY,
                    'data' => ['transaction' => $transaction],
                ],
                true,
                ['approvedBy' => $approvedBy]
            );

            return WidgetSubmitResultDTO::createSuccess('Buchung erfasst.', [
                'applicationId' => $applicationId,
                // What the former widget answered with, for callers relying on it.
                'data' => $data,
                'isToday' => $executionDate->format('Y-m-d') === $today->format('Y-m-d'),
                'scheduled' => false,
            ], 200);
        }

        $scheduleData = [
            'transaction' => $transaction,
            'waitUntil' => $executionDate->format('Y-m-d'),
        ];

        // A planned booking was approved by submitting it; the executions of a
        // standing order only when its creator asked for that.
        $autoApprove = $interval === '' || filter_var($data['autoApprove'] ?? false, FILTER_VALIDATE_BOOLEAN);
        if ($autoApprove && $approvedBy > 0) {
            $scheduleData['autoApprovedBy'] = $approvedBy;
        }

        // The start date marks the schedule as one of this widget, see
        // HandleScheduledBookingsJob - a planned one-off booking carries it too.
        $repeatOptions = [
            'startDate' => $executionDate->format('Y-m-d'),
            'occurrence' => 0,
        ];

        if ($interval !== '') {
            $repeatOptions['interval'] = $interval;

            switch ($data['endType'] ?? self::END_NEVER) {
                case self::END_NEVER:
                    break;
                case self::END_DATE:
                    if (empty($data['endDate'])) {
                        return WidgetSubmitResultDTO::createError(400, 'Bitte ein Enddatum angeben.');
                    }
                    $lastExecution = $this->parseDate((string)$data['endDate']);
                    if (is_null($lastExecution)) {
                        return WidgetSubmitResultDTO::createError(400, 'Ungültiges Enddatum.');
                    }
                    if ($lastExecution < $executionDate) {
                        return WidgetSubmitResultDTO::createError(400, 'Das Enddatum liegt vor der ersten Ausführung.');
                    }
                    $repeatOptions['lastExecution'] = $lastExecution->format('Y-m-d');
                    break;
                case self::END_COUNT:
                    $count = (int)($data['endCount'] ?? 0);
                    if ($count < 1) {
                        return WidgetSubmitResultDTO::createError(400, 'Bitte mindestens eine Ausführung angeben.');
                    }
                    $repeatOptions['lastExecution'] = Recurrence::lastOccurrence($executionDate, $interval, $count)->format('Y-m-d');
                    break;
                default:
                    // Rather no standing order than an endless one by mistake.
                    return WidgetSubmitResultDTO::createError(400, 'Unbekanntes Ende des Dauerauftrags.');
            }
        }

        $scheduleData['repeatOptions'] = $repeatOptions;

        $this->trackingRecorder->track(
            $applicationId,
            [
                'key' => HandleScheduledBookingsJob::$KEY,
                'data' => $scheduleData,
            ],
            true,
            ['approvedBy' => $approvedBy]
        );

        return WidgetSubmitResultDTO::createSuccess(
            $interval === '' ? 'Buchung geplant.' : 'Dauerauftrag angelegt.',
            [
                'applicationId' => $applicationId,
                'scheduled' => true,
                'schedules' => $this->getScheduleViews(),
            ],
            200
        );
    }

    private function saveTemplate(array $data): WidgetSubmitResultDTO
    {
        $name = trim((string)($data['name'] ?? ''));
        if ($name === '') {
            return WidgetSubmitResultDTO::createError(400, 'Bitte einen Namen für die Vorlage angeben.');
        }
        if (!is_null($accountError = $this->validateAccounts((int)($data['from'] ?? 0), (int)($data['to'] ?? 0)))) {
            return $accountError;
        }

        // Saving under an existing name updates that template, which is how a
        // template is corrected from the widget.
        $template = $this->customObjectProvider->getCustomEntityByClassNameAndName(BookingTemplate::class, $name);
        if (!$template instanceof BookingTemplate) {
            /** @var BookingTemplate $template */
            $template = $this->customObjectProvider->createNewCustomEntity(BookingTemplate::class);
            $template->setName($name);
        }

        $template
            ->setFromPaymentMethodId((int)($data['from'] ?? -1))
            ->setToPaymentMethodId((int)($data['to'] ?? -1))
            ->setDescription(trim((string)($data['description'] ?? '')))
            ->setAmount(max(0, $this->parseAmount($data['amount'] ?? '') ?? 0));

        $this->customObjectProvider->save($template);

        $saved = $this->customObjectProvider->getCustomEntityByClassNameAndName(BookingTemplate::class, $name);

        return WidgetSubmitResultDTO::createSuccess('Vorlage gespeichert.', [
            'template' => $saved instanceof BookingTemplate ? $this->createTemplateView($saved) : null,
        ], 200);
    }

    private function cancelSchedule(array $data): WidgetSubmitResultDTO
    {
        $trackingBuffer = $this->trackingBufferRepository->find((int)($data['id'] ?? 0));

        if (
            !$trackingBuffer instanceof TrackingBuffer
            || $trackingBuffer->getKeyValue() !== HandleScheduledBookingsJob::$KEY
            || $trackingBuffer->getState() !== eTrackingBufferState::NEW
        ) {
            return WidgetSubmitResultDTO::createError(404, 'Dauerauftrag nicht gefunden.');
        }

        // The pending entry is the only link to the executions still to come;
        // once it is ignored, the worker never creates them.
        $trackingBuffer
            ->setHandledAt(new \DateTime())
            ->setState(eTrackingBufferState::IGNORED);
        $this->trackingBufferRepository->save($trackingBuffer, true);

        return WidgetSubmitResultDTO::createSuccess('Dauerauftrag beendet.', [], 200);
    }

    /**
     * @return PaymentMethod[]
     */
    private function getPaymentMethods(): array
    {
        $paymentMethods = $this->customObjectProvider->getCustomEntitiesByClassName(PaymentMethod::class);
        usort($paymentMethods, fn(PaymentMethod $a, PaymentMethod $b) => strcasecmp($a->getName(), $b->getName()));

        return $paymentMethods;
    }

    /**
     * @return BookingTemplate[]
     */
    private function getBookingTemplates(): array
    {
        $templates = $this->customObjectProvider->getCustomEntitiesByClassName(BookingTemplate::class);
        usort($templates, fn(BookingTemplate $a, BookingTemplate $b) => strcasecmp($a->getName(), $b->getName()));

        return $templates;
    }

    private function createTemplateView(BookingTemplate $template): array
    {
        return [
            'id' => $template->getId(),
            'name' => $template->getName(),
            'from' => $template->getFromPaymentMethodId(),
            'to' => $template->getToPaymentMethodId(),
            'description' => $template->getDescription(),
            'amount' => $template->getAmount(),
        ];
    }

    /**
     * The planned bookings and standing orders that have not run out yet, each
     * represented by its next pending execution.
     */
    private function getScheduleViews(): array
    {
        $paymentMethodNames = [];
        foreach ($this->getPaymentMethods() as $paymentMethod) {
            $paymentMethodNames[$paymentMethod->getId()] = $paymentMethod->getName();
        }

        $views = [];

        foreach ($this->trackingBufferRepository->findByAnyDataKeyValue([HandleScheduledBookingsJob::$KEY]) as $trackingBuffer) {
            $data = $trackingBuffer->getData()['data'] ?? [];
            $transaction = $data['transaction'] ?? [];
            $repeatOptions = $data['repeatOptions'] ?? [];
            $from = null;
            $to = null;
            $amount = 0;

            foreach ($transaction['postings'] ?? [] as $posting) {
                $amount = (float)($posting['amount'] ?? 0);
                if (($posting['type'] ?? '') === 'credit') {
                    $from = (int)($posting['paymentMethod'] ?? 0);
                } else {
                    $to = (int)($posting['paymentMethod'] ?? 0);
                }
            }

            $interval = (string)($repeatOptions['interval'] ?? '');

            $views[] = [
                'id' => $trackingBuffer->getId(),
                'description' => (string)($transaction['description'] ?? ''),
                'amount' => $amount,
                'from' => $paymentMethodNames[$from] ?? '?',
                'to' => $paymentMethodNames[$to] ?? '?',
                'interval' => $interval === '' ? '' : Recurrence::getLabel($interval),
                'nextExecution' => (string)($data['waitUntil'] ?? ''),
                'lastExecution' => (string)($repeatOptions['lastExecution'] ?? ''),
                'autoApprove' => (int)($data['autoApprovedBy'] ?? -1) > 0,
            ];
        }

        usort($views, fn(array $a, array $b) => strcmp($a['nextExecution'], $b['nextExecution']));

        return $views;
    }

    private function resolveApplicationId(array $data): int
    {
        $applicationId = (int)($data['applicationId'] ?? -1);

        if ($applicationId <= 0) {
            $applicationId = (int)$this->configurationProvider->getValue(
                GeneralConfigurationGroup::KEY,
                'defaultApplication'
            );
        }

        return $applicationId;
    }

    /**
     * Both accounts must be payment methods: ExecuteBookingJob skips one it can
     * not find and would book only the other half of the transaction.
     */
    private function validateAccounts(int $from, int $to): ?WidgetSubmitResultDTO
    {
        if ($from <= 0 || $to <= 0) {
            return WidgetSubmitResultDTO::createError(400, 'Bitte Ursprungs- und Zielkonto wählen.');
        }
        if ($from === $to) {
            return WidgetSubmitResultDTO::createError(400, 'Ursprungs- und Zielkonto müssen sich unterscheiden.');
        }

        $paymentMethodIds = array_map(fn(PaymentMethod $paymentMethod) => $paymentMethod->getId(), $this->getPaymentMethods());
        if (!in_array($from, $paymentMethodIds, true) || !in_array($to, $paymentMethodIds, true)) {
            return WidgetSubmitResultDTO::createError(400, 'Unbekanntes Konto.');
        }

        return null;
    }

    /**
     * Only real Y-m-d dates - no "tomorrow", and no 31st of February that
     * quietly becomes the 3rd of March.
     */
    private function parseDate(string $value): ?\DateTimeImmutable
    {
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value);

        return $date !== false && $date->format('Y-m-d') === $value ? $date : null;
    }

    /**
     * Accepts "1234.5", "1234,50" and "1.234,50" alike.
     */
    private function parseAmount(mixed $value): ?float
    {
        $value = str_replace([' ', '€'], '', trim((string)$value));
        if (str_contains($value, ',')) {
            $value = str_replace(['.', ','], ['', '.'], $value);
        }

        if (!is_numeric($value) || !is_finite((float)$value)) {
            return null;
        }

        return round((float)$value, 2);
    }
}
