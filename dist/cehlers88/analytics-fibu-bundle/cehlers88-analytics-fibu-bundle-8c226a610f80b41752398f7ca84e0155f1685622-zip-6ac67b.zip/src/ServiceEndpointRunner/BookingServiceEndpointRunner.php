<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 01.11.2025
 * Time: 11:14
 */

namespace Cehlers88\AnalyticsFiBuBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Symfony\Component\HttpFoundation\Request;

class BookingServiceEndpointRunner extends AbstractServiceEndpointRunner
{
    public function handleRequest(string $endpointName, Request $request): ServiceEndpointRunnerResultDTO
    {
        if ($this->getUser() === null) {
            return ServiceEndpointRunnerResultDTO::createError('user not logged in');
        }

        return ServiceEndpointRunnerResultDTO::createSuccess([
            'user' => $this->getUser()->getId(),
        ], 'executed booking');
    }

    public function getEndpoints(): mixed
    {
        return [
            EndpointDefinitionDTO::create('book', ['POST']),
        ];
    }

    public function getBundleName(): string
    {
        return 'AnalyticsFiBuBundle';
    }

    public function getRequiredRoles(): array
    {
        return ['FIBU_USER'];
    }
}