<?php

namespace Cehlers88\AnalyticsFiBuBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

/**
 * A booking that recurs by hand: picked in the booking widget, it fills in the
 * accounts and the description (and the amount, when it has one), so only what
 * differs from last time is left to type.
 */
class BookingTemplate extends AbstractCustomObject
{
    public function getFromPaymentMethodId(): int
    {
        return (int)$this->getAttribute('from_payment_method_id', -1);
    }

    public function setFromPaymentMethodId(int $paymentMethodId): static
    {
        return $this->setAttribute('from_payment_method_id', $paymentMethodId);
    }

    public function getToPaymentMethodId(): int
    {
        return (int)$this->getAttribute('to_payment_method_id', -1);
    }

    public function setToPaymentMethodId(int $paymentMethodId): static
    {
        return $this->setAttribute('to_payment_method_id', $paymentMethodId);
    }

    public function getDescription(): string
    {
        return (string)$this->getAttribute('description', '');
    }

    public function setDescription(string $description): static
    {
        return $this->setAttribute('description', $description);
    }

    /** 0 when the amount differs every time and is left for the booking. */
    public function getAmount(): float
    {
        return (float)$this->getAttribute('amount', 0);
    }

    public function setAmount(float $amount): static
    {
        return $this->setAttribute('amount', $amount);
    }
}
