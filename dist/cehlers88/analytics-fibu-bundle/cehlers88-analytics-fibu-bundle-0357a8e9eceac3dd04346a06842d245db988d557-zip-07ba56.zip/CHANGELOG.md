# Changelog

## [0.1.1](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([fd355ff](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fd355ffd721a572da177c803d2d5953464d71f55))
