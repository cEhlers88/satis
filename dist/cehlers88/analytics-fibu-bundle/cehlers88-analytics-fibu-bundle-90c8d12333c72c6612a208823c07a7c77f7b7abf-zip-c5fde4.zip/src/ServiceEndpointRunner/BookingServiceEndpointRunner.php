<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 01.11.2025
 * Time: 11:14
 */

namespace Cehlers88\AnalyticsFiBuBundle\ServiceEndpointRunner;

use Analytics\DTO\ServiceEndpointRunnerResultDTO;
use Analytics\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Symfony\Component\HttpFoundation\Request;

class BookingServiceEndpointRunner extends AbstractServiceEndpointRunner {
    public function handleRequest(Request $request): mixed {
        if($this->getUser() === null){
            return ServiceEndpointRunnerResultDTO::createError('user not logged in');
        }

        return ServiceEndpointRunnerResultDTO::createSuccess([
            'user'=>$this->getUser()->getId(),
            'count' => $this->trackingBufferRepository->count()
        ],'executed booking');
    }

    public function getEndpoint(): string {
        return "fibu_booking";
    }

    public function getBundleName(): string {
        // TODO: Implement getBundleName() method.
        return 'AnalyticsFiBuBundle';
    }
}