# Changelog

## [1.10.14](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.13...v1.10.14) (2026-09-11)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.41.1 ([#80](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/80)) ([c9d13e9](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/c9d13e9b789c7c2f4ad86f4544705afa75cb5994))

## [1.10.13](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.12...v1.10.13) (2026-09-11)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.41.1 ([#78](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/78)) ([c47d2fe](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/c47d2fee18e06dd4ef7a8b6a0a36dcd3e38fe74a))

## [1.10.12](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.11...v1.10.12) (2026-08-27)


### Miscellaneous Chores

* adjust booking widget layout to improve button alignment and spacing ([d7f7f12](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/d7f7f12c25c0212695a16df1b6dea68314199cd6))
* **deps:** update dependency cehlers88/analytics-core to v1.40.0 ([#77](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/77)) ([eb30b00](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/eb30b00940fb3963fc09b890d2accbfa2ce799ae))
* fix attribute name typo in BankAccount tile template ([e5c9a8d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/e5c9a8db944a95d90f4a17d4204aa4bf93253d09))
* fix import for AbstractWidget in BookingWidget ([b6ec0cc](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/b6ec0cc8005734649e13b15216c319929b131768))
* update widget service definitions and clean up legacy configuration in services.yaml ([2bc62c7](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/2bc62c7226e7027a4ef39dd2d015a2ac75cd0775))

## [1.10.11](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.10...v1.10.11) (2026-08-23)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.13 ([#74](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/74)) ([4cfdc36](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4cfdc364775e73b4dd70af25cf7458233dd225ef))

## [1.10.10](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.9...v1.10.10) (2026-08-14)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.11 ([#73](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/73)) ([dd65e77](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/dd65e77214c9a8e2c7d0e2f22e47c3cc9a5be28e))
* update service tags for `ServiceEndpointRunnerInterface` and remove legacy `ServiceEndpointRunner` definitions ([3d262d5](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/3d262d5ab34089fa90cb7b2d233862be12a6f36f))

## [1.10.9](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.8...v1.10.9) (2026-07-20)


### Miscellaneous Chores

* add debug log to fibu_bundle.ts ([319cc32](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/319cc32274a00448fcb1e7c3add20b0a53f3f8e9))
* **deps:** update dependency cehlers88/analytics-core to v1.39.8 ([#71](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/71)) ([a9d5b31](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a9d5b310524e0935d8051278492d7070b97acc06))

## [1.10.8](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.7...v1.10.8) (2026-07-18)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.7 ([#68](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/68)) ([fcb700d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fcb700de40f26c2ccf1065c0a16f4de4fe0b76dc))

## [1.10.7](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.6...v1.10.7) (2026-07-12)


### Miscellaneous Chores

* add tile template for BankAccount object and update getter in entity ([3f5472a](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/3f5472a02c5dd93a5cf51c3c7222fc12e1432de7))
* calculate and display total amount in BankAccount tile, update BIC fallback logic ([81887c6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/81887c6f8d31c255ada9417e70a458e323b2f4cf))
* **deps:** update dependency cehlers88/analytics-core to v1.39.3 ([#65](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/65)) ([9119cf6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/9119cf6dd434d9cafa5634bef11b6db8af0c8118))
* **deps:** update dependency cehlers88/analytics-core to v1.39.5 ([#67](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/67)) ([f71dfff](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/f71dfff4d11f0f0c677e095afc5ae2e1ad76ba81))
* fix typo in BankAccount tile label and replace dropdowns with suggest-inputs in booking widget ([f6992a1](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/f6992a1d7bcd420d3dcbeb341bf75d624e37b6ac))
* update `handleRequest` signature and clean up unused endpoint definitions ([960651e](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/960651ee94e72d1414093f12b704bd1e031c609c))

## [1.10.6](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.5...v1.10.6) (2026-06-21)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.1 ([#63](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/63)) ([ee396d6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/ee396d654708fd4c124c4c7792dd3e791fb6c472))
* Refactor imports to use AbstractMacro from AnalyticsCore ([01381f6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/01381f6f3ca14465c981beb4f301a991c951eff8))
* Replaced imports of `MenuItemDTO` with the correct path `Cehlers88\AnalyticsCore\Support\DTO\UI\MenuItemDTO` in multiple bundles. This ensures consistency and resolves potential namespace issues. ([7ca2815](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/7ca281544ddf2884e744306cc43337c3b1ae8892))
* update namespace references for DTO imports to `AnalyticsCore\Support\DTO\DTO` ([db8085a](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/db8085a9b76c697c24c9e6d3fbbdc732b98864b8))
* update service tags for MacroInterface and remove legacy macro definitions ([00952c3](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/00952c3c41205fa33004d9ea5777d5b7cfddea67))

## [1.10.5](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.4...v1.10.5) (2026-06-14)


### Miscellaneous Chores

* bump `cehlers88/analytics-core` to v1.38.8 in composer.lock ([2b84ee6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/2b84ee679adffcd702b930a04928685944f213af))

## [1.10.4](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.3...v1.10.4) (2026-06-14)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.38.7 ([#60](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/60)) ([5b3a533](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/5b3a53366d5d9012c88c0b384ef0e5eabcee50f0))

## [1.10.3](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.2...v1.10.3) (2026-05-24)


### Miscellaneous Chores

* update namespace reference for `BankAccountRepository` in `BankAccount` entity ([453c8a5](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/453c8a55a3634fedd21bbf98f3de527daca0d6ec))

## [1.10.2](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.1...v1.10.2) (2026-05-24)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.38.2 ([#57](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/57)) ([6e3d60e](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/6e3d60e8b718e0e70dc7411a2763cb32cd2a2017))

## [1.10.1](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.10.0...v1.10.1) (2026-05-17)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.38.1 ([#56](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/56)) ([c0972a1](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/c0972a177a2ce313192b0cb05620bb180dcad4d9))
* use `getCustomObjectById` instead of `getCustomEntityById` in `ExecuteBookingJob` ([e409d77](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/e409d7731d12de1c2bac362a03e850859f57eff6))

## [1.10.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.9.1...v1.10.0) (2026-05-17)


### Features

* add `CreateClosingEntryWorker` for generating periodic closing reports ([4f469bc](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4f469bc50dd6d1c5fde96d7d754298f9a40be58d))


### Miscellaneous Chores

* bump `cehlers88/analytics-core` to v1.38.0 in composer.lock ([a4d1aff](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a4d1affdacfa2b98d839905eacdd40fd12870b0a))
* refactor: update `CreateClosingEntryWorker` and `BookMacro` with improved method formatting and type hints ([2f2fced](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/2f2fceda1a739409e27d364f647cf046694d4211))

## [1.9.1](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.9.0...v1.9.1) (2026-05-16)


### Miscellaneous Chores

* bump `cehlers88/analytics-core` to v1.37.0 in composer.lock ([a24bb03](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a24bb031429b2fcd8a14a37dc8e0e36cb2c095f2))
* remove `PaymentMethod` entity and associated repository ([29e230c](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/29e230c7d314acdc70443eca8e968a5cf96235cd))

## [1.9.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.8.0...v1.9.0) (2026-05-16)


### Features

* add `BankAccount` and `PaymentMethod` custom objects to enhance financial data management ([2bf4cdd](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/2bf4cdd6683383ad9acc5e10550d2b0d7d39b9f8))
* enhance `PaymentMethod` object and refactor booking widget ([5a88036](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/5a88036678f6d41b3be0b2c3e9a97f67b0743542))


### Miscellaneous Chores

* bump `cehlers88/analytics-core` to v1.35.0 in composer.lock ([f5d7e8f](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/f5d7e8f8afed57adf1efbc7258b93db428dea78b))
* replace `PaymentMethodRepository` with `CustomObjectProvider` in booking job and widget ([8c250db](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/8c250dbaaa274a45052871ca3a527e769c0f5949))

## [1.8.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.7.0...v1.8.0) (2026-05-16)


### Features

* improve booking widget functionality and enhance transaction handling ([31e51d0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/31e51d0c1317302de7933c012dd0f277e9e1176b))
* refactor booking widget and enhance configuration handling ([d6c3d45](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/d6c3d45fcf5c80ddf72fa58327dea24721bb099d))


### Miscellaneous Chores

* Bump `cehlers88/analytics-core` to v1.34.0 in composer.lock ([3304fca](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/3304fca0b64b9a069bfecfd57f6984381e1d8313))

## [1.7.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.6.0...v1.7.0) (2026-05-15)


### Features

* enhance booking widget layout and improve validation logic ([02aaf41](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/02aaf41687170bc48b51b641e3bdb6ee157e8d8f))

## [1.6.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.5.0...v1.6.0) (2026-05-14)


### Features

* add state parameter to tracking buffer creation and upgrade analytics-core to v1.33.0 ([1318747](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/131874761e6fd29c77b58229f3153b6a06f9a70d))

## [1.5.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.4.1...v1.5.0) (2026-05-14)


### Features

* improve tracking buffer handling and booking validation ([4cdff4d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4cdff4d6283f8d46214acce39848a3ec2e3d4574))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.30.0 ([#46](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/46)) ([994cc06](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/994cc065bb771a14ae176898e293e59b86c8257e))

## [1.4.1](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.4.0...v1.4.1) (2026-05-14)


### Miscellaneous Chores

* refactor: extract tracking buffer creation logic and upgrade analytics-core to v1.31.0 ([94d9c6f](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/94d9c6fb2426fbe8e2d654ebac80bd6fff0fc7cc))

## [1.4.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.3.0...v1.4.0) (2026-05-10)


### Features

* enhance scheduled bookings processing and payment method handling ([17b51b7](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/17b51b72eed56c6501a9c9c7f13491fedbf31683))

## [1.3.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.2.9...v1.3.0) (2026-05-10)


### Features

* add support for custom payment methods in GeneralConfigurationGroup ([fdf6098](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fdf6098b38e78fb8eef0c39f6064b23b75d7c480))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.29.0 ([#43](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/43)) ([d3eba20](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/d3eba20bbd040013ff44cf6484d76d3e97ba32b6))

## [1.2.9](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.2.8...v1.2.9) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.2 ([#41](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/41)) ([dd31575](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/dd3157583ba0a03230b47687da1bc23ca3c2cfbc))

## [1.2.8](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.2.7...v1.2.8) (2026-05-03)


### Miscellaneous Chores

* Update branch alias format in composer.json files ([0eb0eb9](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0eb0eb9c0ec3361e0ca5900895dce6c3423993b2))

## [1.2.7](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.2.6...v1.2.7) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.1 ([#38](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/38)) ([de92031](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/de92031d6e6b1d1d535ff55ad2f2b210502def49))

## [1.2.6](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.2.5...v1.2.6) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.24.0 ([#36](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/36)) ([3610461](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/3610461bfc1e2297528370f9e57427c5712b233e))
* **deps:** update dependency cehlers88/analytics-core to v1.25.1 ([#37](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/37)) ([4877b0d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4877b0d739763f8a6fa975f8e3cf1019c007d955))
* update parent class in BookingServiceEndpointRunner to AbstractServiceEndpointRunner ([3006bf8](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/3006bf8154f42222374b8fedb85c01169eddbbc4))

## [1.2.5](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.2.4...v1.2.5) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.23.1 ([#34](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/34)) ([0ba0e36](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0ba0e362612dee93504b9c24d21420ce9da0ca13))
* update BookingServiceEndpointRunner to use AnalyticsCore interfaces and DTOs ([1982a77](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/1982a77cbcb225b01d6251b30fa85b9229f4b5d9))
* update composer.json to refine branch-alias and require analytics-core 1.*[@dev](https://github.com/dev) ([12417ca](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/12417ca66beb6df8ea0b77d46d5ef74e0b314547))

## [1.2.4](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.2.3...v1.2.4) (2026-05-02)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.21.0 ([#28](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/28)) ([d9fb165](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/d9fb165872fc3f172473502d7f8d7969db28ca14))
* **deps:** update dependency cehlers88/analytics-core to v1.22.1 ([#32](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/32)) ([71539c8](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/71539c8333b076f46e0a74f29881cd38a627420f))
* **deps:** update googleapis/release-please-action action to v5 ([#29](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/29)) ([a53ae0f](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a53ae0f6b26894d61f9621b36a92b186c606ff19))

## [1.2.3](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.2.2...v1.2.3) (2026-04-26)


### Miscellaneous Chores

* upgrade analytics-core to v1.20.0, update composer files, and fix EPermission namespace in BookingWidget ([4593c2e](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4593c2e79ca720a611af840fbe5b765e13c3b9a7))

## [1.2.2](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.2.1...v1.2.2) (2026-04-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.16.1 ([#25](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/25)) ([c6e8581](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/c6e858162abbf881495fea10774f27c711ed056f))
* **deps:** update dependency cehlers88/analytics-core to v1.17.0 ([#27](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/27)) ([de949e2](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/de949e22700060e11f7dea96a1f6db7363bace42))

## [1.2.1](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.2.0...v1.2.1) (2026-04-14)


### Bug Fixes

* update required roles in BookingWidget to use EPermission enum ([52e7fa3](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/52e7fa328df348a1e2856e45b7bae2e36840a2eb))

## [1.2.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.1.0...v1.2.0) (2026-04-13)


### Features

* enhance PaymentMethod with overdraft limit, fix formatting, and cleanup unused code ([e5c1f8d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/e5c1f8d5055bdea7dcc589b54e42428d96fd925c))


### Miscellaneous Chores

* upgrade analytics-core to v1.16.0 and update composer.lock ([e8ba35b](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/e8ba35b3e2403687d5f8d60e54824f93d578e61d))

## [1.1.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.0.0...v1.1.0) (2026-04-12)


### Features

* add booking processing jobs and extend PaymentMethod entity ([e8b8be0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/e8b8be0f5d5c6a5f5b8bda0d2d258289f21fbafd))


### Miscellaneous Chores

* upgrade analytics-core to v1.15.0 and update composer.lock ([dd41ea6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/dd41ea6d91d19e3fff27ddb1a5e1f6ccdb6f93d0))

## [1.0.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.13...v1.0.0) (2026-04-06)


### ⚠ BREAKING CHANGES

* removed unused endpoint from BookingServiceEndpointRunner

### Features

* removed unused endpoint from BookingServiceEndpointRunner ([913caf2](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/913caf296ffb93853a20aedfd56ce1e9b6237633))


### Miscellaneous Chores

* bump analytics-core dependency to v1.10.1 and update composer.lock ([257a50d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/257a50d8a9bba3b5ce35da5afc1e17e263f4c026))
* update BookingServiceEndpointRunner and adjust analytics-core dependency to 1.*[@dev](https://github.com/dev) ([30982d8](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/30982d86161f570f615319fdcffc3cfe2d4cdc68))

## [0.1.13](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.12...v0.1.13) (2026-03-24)


### Miscellaneous Chores

* update dependencies ([a495de0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a495de041c3ee43fc4c080a32faf4596bf3dc64b))
* Upgraded the analytics-core package to v1.3.7 to include the latest changes and improvements. Updated the associated reference, distribution URL, and checksum to match the new version. ([96eb7ac](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/96eb7acc7691ca4f05b35e2fc282659658234801))

## [0.1.12](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.11...v0.1.12) (2026-03-22)


### Miscellaneous Chores

* add GitHub Actions workflow to trigger Satis rebuild on release ([fc3a463](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fc3a463b9d9d3b65c4d354b01b74571c1909c83f))
* **deps:** update dependency cehlers88/analytics-core to ^0.2.0@dev ([#7](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/7)) ([4c5c201](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4c5c2014b8f77d1ca0c8f51a3fc562bb63476d1c))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([4dd5771](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4dd5771ab5558e7f40a758b64f3bec5f9264796f))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([c4a2680](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/c4a26806e08e0c32364720948c77d05572420809))
* **deps:** update dependency cehlers88/analytics-core to v0.1.5 ([#4](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/4)) ([a2a6e28](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a2a6e28bf45edcdfcee62cae12188f670b92d67f))
* **deps:** update dependency cehlers88/analytics-core to v0.2.1 ([#6](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/6)) ([672fe02](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/672fe02b91b732e35f8b64e53c675feff64ba8ec))
* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#11](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/11)) ([7197f0d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/7197f0dcd45469850118fe060e6be319d9d2f9ef))
* implement release-please ([fd355ff](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fd355ffd721a572da177c803d2d5953464d71f55))
* **main:** release 0.1.1 ([0357a8e](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0357a8e9eceac3dd04346a06842d245db988d557))
* **main:** release 0.1.1 ([48c9991](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/48c999120db52c304266e40db126e6c4e9cf99c2))
* **main:** release 0.1.10 ([#17](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/17)) ([9aa43a1](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/9aa43a173de84fc23adf6e8b883a172315bb2df1))
* **main:** release 0.1.11 ([#18](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/18)) ([69dfecf](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/69dfecfb51d62c16560b43c1b31e36fa7e8d9112))
* **main:** release 0.1.2 ([715c247](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/715c247dc2729738b2742f8b5367929c8cd6a098))
* **main:** release 0.1.2 ([a21cfb0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a21cfb02839f8e6834f046f6c9626a9d0a1c249c))
* **main:** release 0.1.3 ([#5](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/5)) ([85c89d6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/85c89d679528ebc3a5b34ca1f2b99496ffa5965f))
* **main:** release 0.1.4 ([#8](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/8)) ([5b5adb5](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/5b5adb55d48f8aac18455a662901d4d46043e2b3))
* **main:** release 0.1.5 ([#9](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/9)) ([90c8d12](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/90c8d12333c72c6612a208823c07a7c77f7b7abf))
* **main:** release 0.1.6 ([#10](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/10)) ([b0b2820](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/b0b2820571c07117d5ad2b645dc7cd61a332cd01))
* **main:** release 0.1.7 ([#12](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/12)) ([0437389](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/04373896b91733d80fcfba3fd48fc38b2523e34a))
* **main:** release 0.1.8 ([#15](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/15)) ([dc2e5a8](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/dc2e5a800ac153d63f7f092ee383911977f6117b))
* **main:** release 0.1.9 ([#16](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/16)) ([f04c10b](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/f04c10b256f7d60b7851f8eb1dfd8b33adf936f8))
* Update analytics-core dependency to ^0.4 in composer.json ([9de44d8](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/9de44d895ce369b31273c6a250955991c7a87258))
* Update analytics-core dependency to ^0.5 in composer.json ([0c56336](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0c5633693897377b0302b2f648f0823340943d05))
* Update analytics-core dependency to ^1.0 in composer.json and lock file ([615e7d1](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/615e7d1c520f8fe3fb7244164b906b16e829bba0))
* update analytics-core dependency to dev-main ([4c1bac0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4c1bac060d82b209063c7bfb7059cd490aa8c26a))
* update branch alias and analytics-core dependency version ([0e4446a](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0e4446a464587ff812bb763383ab524dde66f8b7))
* Update dependency versions for analytics-core ([874c5d6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/874c5d6eef4f1d72192dda8867b46ef87d490528))

## [0.1.11](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.10...v0.1.11) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([615e7d1](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/615e7d1c520f8fe3fb7244164b906b16e829bba0))

## [0.1.10](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.9...v0.1.10) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.5 in composer.json ([0c56336](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0c5633693897377b0302b2f648f0823340943d05))

## [0.1.9](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.8...v0.1.9) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([9de44d8](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/9de44d895ce369b31273c6a250955991c7a87258))

## [0.1.8](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.7...v0.1.8) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([4c1bac0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4c1bac060d82b209063c7bfb7059cd490aa8c26a))

## [0.1.7](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.6...v0.1.7) (2026-03-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#11](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/11)) ([7197f0d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/7197f0dcd45469850118fe060e6be319d9d2f9ef))
* update branch alias and analytics-core dependency version ([0e4446a](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0e4446a464587ff812bb763383ab524dde66f8b7))

## [0.1.6](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.5...v0.1.6) (2026-01-22)


### Miscellaneous Chores

* Update dependency versions for analytics-core ([874c5d6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/874c5d6eef4f1d72192dda8867b46ef87d490528))

## [0.1.5](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.4...v0.1.5) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.2.1 ([#6](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/6)) ([672fe02](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/672fe02b91b732e35f8b64e53c675feff64ba8ec))

## [0.1.4](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.3...v0.1.4) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.2.0@dev ([#7](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/7)) ([4c5c201](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4c5c2014b8f77d1ca0c8f51a3fc562bb63476d1c))

## [0.1.3](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.2...v0.1.3) (2026-01-21)


### Miscellaneous Chores

* add GitHub Actions workflow to trigger Satis rebuild on release ([fc3a463](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fc3a463b9d9d3b65c4d354b01b74571c1909c83f))
* **deps:** update dependency cehlers88/analytics-core to v0.1.5 ([#4](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/4)) ([a2a6e28](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a2a6e28bf45edcdfcee62cae12188f670b92d67f))

## [0.1.2](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([4dd5771](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4dd5771ab5558e7f40a758b64f3bec5f9264796f))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([c4a2680](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/c4a26806e08e0c32364720948c77d05572420809))

## [0.1.1](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([fd355ff](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fd355ffd721a572da177c803d2d5953464d71f55))
