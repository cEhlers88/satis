<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 06.05.2024
 * Time: 16:12
 */

namespace Cehlers88\AnalyticsFiBuBundle\DependencyInjection;

use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Extension\Extension;

class FiBuBundleExtension extends Extension {
        public function load(array $configs, ContainerBuilder $container){

        }
}