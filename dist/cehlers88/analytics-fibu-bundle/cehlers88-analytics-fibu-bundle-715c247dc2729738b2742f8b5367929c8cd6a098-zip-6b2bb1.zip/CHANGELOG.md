# Changelog

## [0.1.2](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([4dd5771](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4dd5771ab5558e7f40a758b64f3bec5f9264796f))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([c4a2680](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/c4a26806e08e0c32364720948c77d05572420809))

## [0.1.1](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([fd355ff](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fd355ffd721a572da177c803d2d5953464d71f55))
