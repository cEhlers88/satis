# Changelog

## [1.1.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v1.0.0...v1.1.0) (2026-04-12)


### Features

* add booking processing jobs and extend PaymentMethod entity ([e8b8be0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/e8b8be0f5d5c6a5f5b8bda0d2d258289f21fbafd))


### Miscellaneous Chores

* upgrade analytics-core to v1.15.0 and update composer.lock ([dd41ea6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/dd41ea6d91d19e3fff27ddb1a5e1f6ccdb6f93d0))

## [1.0.0](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.13...v1.0.0) (2026-04-06)


### ⚠ BREAKING CHANGES

* removed unused endpoint from BookingServiceEndpointRunner

### Features

* removed unused endpoint from BookingServiceEndpointRunner ([913caf2](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/913caf296ffb93853a20aedfd56ce1e9b6237633))


### Miscellaneous Chores

* bump analytics-core dependency to v1.10.1 and update composer.lock ([257a50d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/257a50d8a9bba3b5ce35da5afc1e17e263f4c026))
* update BookingServiceEndpointRunner and adjust analytics-core dependency to 1.*[@dev](https://github.com/dev) ([30982d8](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/30982d86161f570f615319fdcffc3cfe2d4cdc68))

## [0.1.13](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.12...v0.1.13) (2026-03-24)


### Miscellaneous Chores

* update dependencies ([a495de0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a495de041c3ee43fc4c080a32faf4596bf3dc64b))
* Upgraded the analytics-core package to v1.3.7 to include the latest changes and improvements. Updated the associated reference, distribution URL, and checksum to match the new version. ([96eb7ac](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/96eb7acc7691ca4f05b35e2fc282659658234801))

## [0.1.12](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.11...v0.1.12) (2026-03-22)


### Miscellaneous Chores

* add GitHub Actions workflow to trigger Satis rebuild on release ([fc3a463](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fc3a463b9d9d3b65c4d354b01b74571c1909c83f))
* **deps:** update dependency cehlers88/analytics-core to ^0.2.0@dev ([#7](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/7)) ([4c5c201](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4c5c2014b8f77d1ca0c8f51a3fc562bb63476d1c))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([4dd5771](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4dd5771ab5558e7f40a758b64f3bec5f9264796f))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([c4a2680](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/c4a26806e08e0c32364720948c77d05572420809))
* **deps:** update dependency cehlers88/analytics-core to v0.1.5 ([#4](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/4)) ([a2a6e28](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a2a6e28bf45edcdfcee62cae12188f670b92d67f))
* **deps:** update dependency cehlers88/analytics-core to v0.2.1 ([#6](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/6)) ([672fe02](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/672fe02b91b732e35f8b64e53c675feff64ba8ec))
* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#11](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/11)) ([7197f0d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/7197f0dcd45469850118fe060e6be319d9d2f9ef))
* implement release-please ([fd355ff](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fd355ffd721a572da177c803d2d5953464d71f55))
* **main:** release 0.1.1 ([0357a8e](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0357a8e9eceac3dd04346a06842d245db988d557))
* **main:** release 0.1.1 ([48c9991](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/48c999120db52c304266e40db126e6c4e9cf99c2))
* **main:** release 0.1.10 ([#17](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/17)) ([9aa43a1](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/9aa43a173de84fc23adf6e8b883a172315bb2df1))
* **main:** release 0.1.11 ([#18](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/18)) ([69dfecf](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/69dfecfb51d62c16560b43c1b31e36fa7e8d9112))
* **main:** release 0.1.2 ([715c247](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/715c247dc2729738b2742f8b5367929c8cd6a098))
* **main:** release 0.1.2 ([a21cfb0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a21cfb02839f8e6834f046f6c9626a9d0a1c249c))
* **main:** release 0.1.3 ([#5](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/5)) ([85c89d6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/85c89d679528ebc3a5b34ca1f2b99496ffa5965f))
* **main:** release 0.1.4 ([#8](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/8)) ([5b5adb5](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/5b5adb55d48f8aac18455a662901d4d46043e2b3))
* **main:** release 0.1.5 ([#9](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/9)) ([90c8d12](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/90c8d12333c72c6612a208823c07a7c77f7b7abf))
* **main:** release 0.1.6 ([#10](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/10)) ([b0b2820](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/b0b2820571c07117d5ad2b645dc7cd61a332cd01))
* **main:** release 0.1.7 ([#12](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/12)) ([0437389](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/04373896b91733d80fcfba3fd48fc38b2523e34a))
* **main:** release 0.1.8 ([#15](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/15)) ([dc2e5a8](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/dc2e5a800ac153d63f7f092ee383911977f6117b))
* **main:** release 0.1.9 ([#16](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/16)) ([f04c10b](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/f04c10b256f7d60b7851f8eb1dfd8b33adf936f8))
* Update analytics-core dependency to ^0.4 in composer.json ([9de44d8](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/9de44d895ce369b31273c6a250955991c7a87258))
* Update analytics-core dependency to ^0.5 in composer.json ([0c56336](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0c5633693897377b0302b2f648f0823340943d05))
* Update analytics-core dependency to ^1.0 in composer.json and lock file ([615e7d1](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/615e7d1c520f8fe3fb7244164b906b16e829bba0))
* update analytics-core dependency to dev-main ([4c1bac0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4c1bac060d82b209063c7bfb7059cd490aa8c26a))
* update branch alias and analytics-core dependency version ([0e4446a](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0e4446a464587ff812bb763383ab524dde66f8b7))
* Update dependency versions for analytics-core ([874c5d6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/874c5d6eef4f1d72192dda8867b46ef87d490528))

## [0.1.11](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.10...v0.1.11) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([615e7d1](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/615e7d1c520f8fe3fb7244164b906b16e829bba0))

## [0.1.10](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.9...v0.1.10) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.5 in composer.json ([0c56336](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0c5633693897377b0302b2f648f0823340943d05))

## [0.1.9](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.8...v0.1.9) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([9de44d8](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/9de44d895ce369b31273c6a250955991c7a87258))

## [0.1.8](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.7...v0.1.8) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([4c1bac0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4c1bac060d82b209063c7bfb7059cd490aa8c26a))

## [0.1.7](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.6...v0.1.7) (2026-03-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#11](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/11)) ([7197f0d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/7197f0dcd45469850118fe060e6be319d9d2f9ef))
* update branch alias and analytics-core dependency version ([0e4446a](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0e4446a464587ff812bb763383ab524dde66f8b7))

## [0.1.6](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.5...v0.1.6) (2026-01-22)


### Miscellaneous Chores

* Update dependency versions for analytics-core ([874c5d6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/874c5d6eef4f1d72192dda8867b46ef87d490528))

## [0.1.5](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.4...v0.1.5) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.2.1 ([#6](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/6)) ([672fe02](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/672fe02b91b732e35f8b64e53c675feff64ba8ec))

## [0.1.4](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.3...v0.1.4) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.2.0@dev ([#7](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/7)) ([4c5c201](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4c5c2014b8f77d1ca0c8f51a3fc562bb63476d1c))

## [0.1.3](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.2...v0.1.3) (2026-01-21)


### Miscellaneous Chores

* add GitHub Actions workflow to trigger Satis rebuild on release ([fc3a463](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fc3a463b9d9d3b65c4d354b01b74571c1909c83f))
* **deps:** update dependency cehlers88/analytics-core to v0.1.5 ([#4](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/4)) ([a2a6e28](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a2a6e28bf45edcdfcee62cae12188f670b92d67f))

## [0.1.2](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([4dd5771](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4dd5771ab5558e7f40a758b64f3bec5f9264796f))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([c4a2680](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/c4a26806e08e0c32364720948c77d05572420809))

## [0.1.1](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([fd355ff](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fd355ffd721a572da177c803d2d5953464d71f55))
