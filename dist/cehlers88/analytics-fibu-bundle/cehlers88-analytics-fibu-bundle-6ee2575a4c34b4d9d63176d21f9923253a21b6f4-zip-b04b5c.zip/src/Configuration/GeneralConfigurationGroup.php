<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 24.05.2024
 * Time: 16:14
 */

namespace Cehlers88\AnalyticsFiBuBundle\Configuration;

use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsFiBuBundle\Repository\PaymentMethodRepository;
use Lcobucci\JWT\Signer\Key;

class GeneralConfigurationGroup extends AbstractConfigurationGroup
{
    public const KEY = 'fibuBundle.general';

    public function __construct(
        private ApplicationRepository   $applicationRepository,
        private PaymentMethodRepository $paymentMethodRepository,
    )
    {
    }

    public function getItems(): array
    {
        return [
            ConfigurationItemDTO::createSelect('defaultApplication', $this->getApplicationOptions(), 'Default application', null, ''),
            ConfigurationItemDTO::createSelect('defaultPaymentMethod', $this->getPaymentMethodOptions(), 'Default payment method', null, ''),
            ConfigurationItemDTO::createRepeat('ownPaymentMethods', 'Eigene Zahlungswege', [
                ConfigurationItemDTO::createSelect('paymentMethod', $this->getPaymentMethodOptions(), 'Zahlungsweg'),
            ], '')
        ];
    }

    private function getApplicationOptions(): array
    {
        $options = [
            ['value' => '', 'label' => 'None']
        ];
        array_map(function ($application) use (&$options) {
            $options[] = ['value' => $application->getId(), 'label' => $application->getName()];
        }, $this->applicationRepository->findAll());
        return $options;
    }

    private function getPaymentMethodOptions(): array
    {
        $options = [
            ['value' => '', 'label' => 'None']
        ];
        array_map(function ($paymentMethod) use (&$options) {
            $options[] = ['value' => $paymentMethod->getId(), 'label' => $paymentMethod->getName()];
        }, $this->paymentMethodRepository->findAll());
        return $options;
    }

    public function getGroupTitle(): string
    {
        return 'Allgemeine Finanzbuchhaltungseinstellungen';
    }

    public function getGroupDescription(): string
    {
        return 'Allgemeine Einstellungen für das Finanzbuchhaltungsmodul';
    }

    public function getKey(): string
    {
        return self::KEY;
    }
}