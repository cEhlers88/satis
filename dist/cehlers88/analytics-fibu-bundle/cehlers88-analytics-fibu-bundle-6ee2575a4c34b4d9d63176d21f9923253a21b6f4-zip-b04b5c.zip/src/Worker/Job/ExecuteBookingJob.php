<?php

namespace Cehlers88\AnalyticsFiBuBundle\Worker\Job;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Cehlers88\AnalyticsFiBuBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionDTO;
use Cehlers88\AnalyticsFiBuBundle\Repository\PaymentMethodRepository;

class ExecuteBookingJob extends AbstractWorkerJob
{
    public static string $KEY = 'FIBU.booking';

    private array $ownPaymentMethodIds = [];

    public function __construct(
        private PaymentMethodRepository $paymentMethodRepository,
        private ConfigurationProvider   $configurationProvider
    )
    {
        $this->setType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION);
    }

    /**
     * @param TrackingBuffer $object
     * @return AbstractWorkerJob
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $data = $object->getData()['data'];

        $transaction = TransactionDTO::createFromArray($data['transaction']);

        foreach ($this->configurationProvider->getValue(
            GeneralConfigurationGroup::KEY,
            'ownPaymentMethods'
        ) as $entry) {
            $this->ownPaymentMethodIds[] = $entry['paymentMethod'];
        }

        $direction = 'undefined'; // incoming / outgoing
        $handlerDataDetails = [];

        foreach ($transaction->postings as $posting) {
            $paymentMethod = $this->paymentMethodRepository->find($posting->paymentMethod);
            if (empty($paymentMethod)) {
                $this->logWarning('payment method not found: ' . $posting->paymentMethod);
                continue;
            }
            if (in_array($posting->paymentMethod, $this->ownPaymentMethodIds)) { // is own payment method
                $direction = $posting->type === 'debit' ? 'incoming' : 'outgoing';
            }
            $updatedAmount = $posting->type === 'debit' ? $posting->amount : -$posting->amount;
            $paymentMethod->setCurrentAmount($paymentMethod->getCurrentAmount() + $updatedAmount);

            $this->paymentMethodRepository->save($paymentMethod, true);
            $handlerDataDetails['pm_' . $paymentMethod->getId()] = [
                'name' => $paymentMethod->getName(),
                'newAmount' => $paymentMethod->getCurrentAmount(),
            ];
        }

        $object
            ->setHandledAt(new \DateTime())
            ->setState(eTrackingBufferState::PROCESSED_FINISHED)
            ->setHandlerData([
                'direction' => $direction,
                'details' => $handlerDataDetails
            ]);

        return parent::workOnObject($object);
    }

    /**
     * @param TrackingBuffer $workingObject
     * @return bool
     */
    public function willHandle(object $workingObject): bool
    {
        if ($workingObject->getKeyValue() !== self::$KEY) {
            return false;
        }

        $handlerData = $workingObject->getHandlerData();
        if (!isset($handlerData['approvedBy']) || $handlerData['approvedBy'] <= 0) {
            return false;
        }

        return true;
    }
}