<?php

namespace Cehlers88\AnalyticsFiBuBundle\Worker;

use Cehlers88\AnalyticsCore\Worker\AbstractWorker;

class BookingWorker extends AbstractWorker
{
    public function getWorkingObjects(): array
    {
        return [];
    }

    public function getName(): string
    {
        return 'BookingWorker';
    }
}