<?php

namespace Cehlers88\AnalyticsFiBuBundle\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Analytics\Widget\AbstractWidget;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Recorder\TrackingRecorder;
use Cehlers88\AnalyticsFiBuBundle\AnalyticsFiBuBundle;
use Cehlers88\AnalyticsFiBuBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\PaymentMethod;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionDTO;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionPostingDTO;
use Cehlers88\AnalyticsFiBuBundle\ENUM\EPermission;

class BookingWidget extends AbstractWidget
{
    public function __construct(
        private TrackingRecorder      $trackingRecorder,
        private ConfigurationProvider $configurationProvider,
        private CustomObjectProvider  $customObjectProvider
    )
    {

    }

    public function getName(): string
    {
        return AnalyticsFiBuBundle::getBundleName() . '.booking';
    }

    public function getTemplateName(): string
    {
        return 'booking';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '40px', 'boxes' => [1]],
            ['height' => '40px', 'boxes' => [1]],
            ['height' => '40px', 'boxes' => [1]],
            ['height' => '120px', 'boxes' => [1]],
            ['height' => '40px', 'boxes' => [.4, .6]],
        ];
    }

    public function enrichProperties(array $properties): array
    {
        return [
            ...$properties,
            'now' => new \DateTime(),
            'paymentMethods' => $this->customObjectProvider->getCustomEntitiesByClassName(PaymentMethod::class),
            //'paymentMethods' => $this->paymentMethodRepository->findAll()
        ];
    }

    public function getRequiredRoles(): array
    {
        return [
            'ROLE_USER',
            EPermission::ACCESS_FIBU->value
        ];
    }

    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        $executionDate = new \DateTime($data['executionDate']);
        $isToday = $executionDate->format('Y-m-d') === new \DateTime()->format('Y-m-d');
        $applicationId = $data['applicationId'] ?? -1;

        if ($applicationId === -1) {
            $applicationId = $this->configurationProvider->getValue(
                GeneralConfigurationGroup::KEY,
                'defaultApplication'
            );
        }

        $this->trackingRecorder->track(
            $applicationId,
            [
                'key' => 'FIBU.booking',
                'data' => [
                    'transaction' => TransactionDTO::createFromArray([
                        'description' => $data['description'],
                        'postings' => [
                            TransactionPostingDTO::createFromArray([
                                'amount' => $data['amount'],
                                'paymentMethod' => $data['debitor'],
                                'type' => 'debit',
                            ]),
                            TransactionPostingDTO::createFromArray([
                                'amount' => $data['amount'],
                                'paymentMethod' => $data['creditor'],
                                'type' => 'credit',
                            ])
                        ],
                    ])
                ],
            ],
            true,
            ['approvedBy' => $user ? $user->getId() : -1]
        );

        return WidgetSubmitResultDTO::createSuccess('Success', [
            'applicationId' => $applicationId,
            'data' => $data,
            'isToday' => $isToday
        ], 200);
    }
}