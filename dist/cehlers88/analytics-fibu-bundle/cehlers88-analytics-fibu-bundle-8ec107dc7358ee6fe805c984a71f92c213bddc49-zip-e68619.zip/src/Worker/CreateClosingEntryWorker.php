<?php

namespace Cehlers88\AnalyticsFiBuBundle\Worker;

use Cehlers88\AnalyticsCore\Worker\AbstractWorker;

/** Zur erstellung von Abschlussberichten Täglich/Monatlich/Jährlich */
class CreateClosingEntryWorker extends AbstractWorker
{
    public function configure(array $properties): static
    {
        //$this->addProperty(PropertyDTO::create());
        return parent::configure($properties);
    }

    public function getWorkingObjects(): array
    {
        return [];
    }
}