<?php

namespace Cehlers88\AnalyticsFiBuBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

class BankAccount extends AbstractCustomObject
{
    public function getIban(): string
    {
        return $this->getAttribute('iban', '');
    }

    public function setIban(string $iban): static
    {
        return $this->setAttribute('iban', $iban);
    }

    public function getHolderName(): string
    {
        return $this->getAttribute('holder_name', '');
    }

    public function setHolderName(string $holderName): static
    {
        return $this->setAttribute('holder_name', $holderName);
    }
}