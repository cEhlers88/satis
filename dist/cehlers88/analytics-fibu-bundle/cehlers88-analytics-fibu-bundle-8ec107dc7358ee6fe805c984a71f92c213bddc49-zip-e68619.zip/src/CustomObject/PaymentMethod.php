<?php

namespace Cehlers88\AnalyticsFiBuBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

class PaymentMethod extends AbstractCustomObject
{
    public function getBankAccountId(): int
    {
        return $this->getAttribute('bank_account_id', -1);
    }

    public function setBankAccountId(int $bankAccountId): static
    {
        return $this->setAttribute('bank_account_id', $bankAccountId);
    }

    public function getDescription(): string
    {
        return $this->getAttribute('description', '');
    }

    public function setDescription(string $description): static
    {
        return $this->setAttribute('description', $description);
    }

    public function getStartAmount(): float
    {
        return $this->getAttribute('start_amount', 0);
    }

    public function setStartAmount(float $startAmount): static
    {
        return $this->setAttribute('start_amount', $startAmount);
    }

    public function getCurrentAmount(): float
    {
        return $this->getAttribute('current_amount', 0);
    }

    public function setCurrentAmount(float $currentAmount): static
    {
        return $this->setAttribute('current_amount', $currentAmount);
    }

    public function getOverdraftLimit(): float
    {
        return $this->getAttribute('overdraft_limit', 0);
    }

    public function setOverdraftLimit(float $overdraftLimit): static
    {
        return $this->setAttribute('overdraft_limit', $overdraftLimit);
    }

    public function isDebitor(): bool
    {
        return $this->getAttribute('is_debitor', true);
    }

    public function setIsDebitor(bool $isDebitor): static
    {
        return $this->setAttribute('is_debitor', $isDebitor);
    }

    public function isCreditor(): bool
    {
        return $this->getAttribute('is_creditor', true);
    }

    public function setIsCreditor(bool $isCreditor): static
    {
        return $this->setAttribute('is_creditor', $isCreditor);
    }
}