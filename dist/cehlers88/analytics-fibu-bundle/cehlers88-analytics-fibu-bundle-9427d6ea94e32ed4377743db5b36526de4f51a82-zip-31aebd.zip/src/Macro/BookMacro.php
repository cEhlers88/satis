<?php

namespace Cehlers88\AnalyticsFiBuBundle\Macro;

use Analytics\DTO\Macro\MacroPropertyDTO;
use Analytics\Macro\AbstractMacro;

class BookMacro extends AbstractMacro {
    private const PROPERTY_PAYMENT_METHOD = 'paymentMethod';
    private const PROPERTY_VALUE = 'value';
    private const PROPERTY_DESCRIPTION = 'description';
    private const PROPERTY_COUNTER_PAYMENT_METHOD = 'counterPaymentMethod';
    private const PROPERTY_DATA = 'data';

    protected function run(): ?array {

        return $this->_createRunResult('ausgeführt');
    }
    public function init(): BookMacro {
        $this->_source = "FiBuBundle";

        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_PAYMENT_METHOD, MacroPropertyDTO::TYPE_INT, 'Specify the id of the payment method'))
            //->setProperty
        ;

        return $this;
    }

    public function getDescription(): string {
        return 'Use this macro to book a value.';
    }

    public function getName(): string {
        return 'book';
    }
}