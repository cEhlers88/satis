<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 05.05.2024
 * Time: 21:58
 */
namespace Cehlers88\AnalyticsFiBuBundle;

use Analytics\AbstractBundlePlugin;
use Analytics\DTO\UI\MenuItemDTO;
use Cehlers88\AnalyticsFiBuBundle\ENUM\EPermission;

class AnalyticsFiBuBundle extends AbstractBundlePlugin {
    public function getDescription():string {
        return 'Bundle zur Verwaltung von Finanzen.';
    }
    public function getMenuItems():array {
        return [
            MenuItemDTO::create('Finanzbuchhaltung', '', [], '', [
                MenuItemDTO::create('Zahlungswege', 'analytics_fibu_payment_methods', [], '', [], [EPermission::READ_FIBU_PAYMENT_METHODS->value])
            ], [EPermission::ACCESS_FIBU->value])
        ];
    }
    public function getPermissions():array {
        return EPermission::getPermissions();
    }

    public function getVersion():string {
        return '1.0.0';
    }
}