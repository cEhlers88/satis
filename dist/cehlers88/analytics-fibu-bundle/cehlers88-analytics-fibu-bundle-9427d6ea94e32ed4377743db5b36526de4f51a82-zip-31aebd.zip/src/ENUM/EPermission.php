<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 07.05.2024
 * Time: 21:57
 */

namespace Cehlers88\AnalyticsFiBuBundle\ENUM;

enum EPermission : string {
    case ACCESS_FIBU = 'ACCESS_FIBU';
    case READ_FIBU_PAYMENT_METHODS = 'READ_FIBU_PAYMENT_METHODS';

    public static function getPermissions():array {
        return [
            self::ACCESS_FIBU,
            self::READ_FIBU_PAYMENT_METHODS
        ];
    }
}