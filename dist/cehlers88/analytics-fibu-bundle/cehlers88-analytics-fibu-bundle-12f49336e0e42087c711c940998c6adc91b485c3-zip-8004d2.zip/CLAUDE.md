# CLAUDE.md

Guidance for AI assistants working in this repository.

## What this is

`cehlers88/analytics-fibu-bundle` — a **Symfony bundle** (not a standalone app) that adds
financial accounting (*Finanzbuchhaltung* / FiBu) features to the closed-source **Analytics**
platform. It is a plugin: it ships extension points (widget, macro, workers, jobs, service
endpoint, configuration group, custom objects) that the host application discovers via DI tags.

- Namespace: `Cehlers88\AnalyticsFiBuBundle\` → `src/` (PSR-4)
- Distribution: private Satis repo at `https://cehlers88.github.io/satis` (not Packagist)
- License: proprietary
- UI language: **German** (labels, menu entries, descriptions). Code, class names and commit
  messages are English. Newer template strings go through Twig `|trans`; older ones are hardcoded
  German — prefer `|trans` for new strings.

## Requirements

- **PHP >= 8.4.** `composer.json` declares no `php` constraint, but `cehlers88/analytics-core`
  requires `>=8.4` and the code uses PHP 8.4 syntax (`new Foo()->bar()` without parentheses in
  `src/AnalyticsFiBuBundle.php:19` and `src/Widget/BookingWidget.php:71`). Do not "fix" that
  syntax — it is intentional.
- `cehlers88/analytics-core` `1.*@dev` (locked at v1.40.0). Bumped automatically by Renovate.

## Repository layout

```
src/
  AnalyticsFiBuBundle.php          Bundle entry: menu items, permissions, description
  Configuration/                   AbstractConfigurationGroup — admin settings (tag: analytics.configuration)
  CustomObject/                    AbstractCustomObject — attribute-bag domain objects (tag: custom_object)
  DTO/                             Transaction / TransactionPosting value objects
  ENUM/EPermission.php             Permission constants exposed to the platform
  Entity/                          Doctrine ORM entities (excluded from autowiring)
  Macro/                           AbstractMacro — scriptable actions (tag: analytics.macro)
  Repository/                      Doctrine repositories
  ServiceEndpointRunner/           HTTP endpoints (tag: analytics.service_endpoint_runner)
  Widget/                          AbstractWidget — dashboard widgets (tag: widget)
  Worker/                          AbstractWorker — background processors (tag: analytics.worker)
  Worker/Job/                      AbstractWorkerJob — units of work (tag: worker_job)
  Resources/config/services.yaml   DI wiring
templates/
  widget/booking.html.twig         BookingWidget template (name = getTemplateName())
  customObject/tile/bankAccount.html.twig   Tile renderer for the BankAccount custom object
assets/fibu_bundle.ts              Front-end entry point (currently a stub)
.github/workflows/                 release-please + Satis rebuild dispatch
```

There is **no test suite, no PHPUnit, no linter, no static analysis, and no CI build job.**
`vendor/` is not committed and `composer install` will fail without credentials for the private
Satis repository. Verify changes by reading code and, at most, `php -l` for syntax.

## Two domain-model styles — know which one you are touching

This is the single most important thing to get right in this codebase.

1. **Custom objects** (`src/CustomObject/`) — the *current* model. They extend
   `AbstractCustomObject` and store everything in a generic attribute bag via
   `getAttribute()` / `setAttribute()` with **snake_case keys** (`bank_account_id`,
   `current_amount`, `is_debitor`). They are loaded and persisted through
   `CustomObjectProvider` (`getCustomEntitiesByClassName()`, `getCustomObjectById()`,
   `save()`), never through Doctrine. `PaymentMethod` lives here.
2. **Doctrine entities** (`src/Entity/`) — legacy. Only `BankAccount` remains, mapped to table
   `fibu_bank_account`. It is *excluded* from the autowiring resource in `services.yaml`.

`BankAccount` exists in **both** styles (`src/Entity/BankAccount.php` and
`src/CustomObject/BankAccount.php`). Active code paths use the custom object; the entity and
`BankAccountRepository` are effectively dormant. Prefer the custom-object style for new work.

## Booking flow (the core feature)

```
BookingWidget::submit()            builds a TransactionDTO (two postings: debit + credit)
  → TrackingRecorder::track()      writes a TrackingBuffer keyed 'FIBU.booking',
                                   handlerData['approvedBy'] = user id
  → BookingWorker::getWorkingObjects()
                                   picks up buffers keyed 'FIBU.booking' or
                                   'FIBU.scheduled_booking'
  → HandleScheduledBookingsJob     ('FIBU.scheduled_booking') waits for data.waitUntil,
                                   then spawns a follow-up scheduled buffer + an
                                   'FIBU.booking' buffer in state INTERACTION_REQUIRED
  → ExecuteBookingJob              ('FIBU.booking', only when approvedBy > 0) applies each
                                   posting to the PaymentMethod's current_amount
                                   (debit = +amount, credit = -amount), derives
                                   direction incoming/outgoing from the configured
                                   "own payment methods", marks the buffer PROCESSED_FINISHED
```

Key invariants:

- Job key constants are **public static properties**, not consts: `ExecuteBookingJob::$KEY`,
  `HandleScheduledBookingsJob::$KEY`. Match a buffer with `getKeyValue()`.
- Every job implements `willHandle(object $workingObject): bool` as its guard and does the work
  in `workOnObject(object $object)`; both take `object` and document the real type in a
  `@param` docblock.
- Jobs set their type in the constructor: `$this->setType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION)`.
- A transaction is balanced by construction in the widget (same amount, one `debit`, one
  `credit` posting). Preserve that when changing `TransactionDTO` handling.

## Extension points and how they register

`src/Resources/config/services.yaml` uses `_instanceof` to tag by base class/interface, so
**dropping a class into the right directory extending the right base is all the wiring you need**:

| Base class / interface                    | Tag                                 |
|-------------------------------------------|-------------------------------------|
| `AnalyticsCore\Macro\MacroInterface`      | `analytics.macro`                   |
| `AnalyticsCore\Worker\WorkerInterface`    | `analytics.worker`                  |
| `AnalyticsCore\Worker\Job\JobInterface`   | `worker_job`                        |
| `...\ServiceEndpointRunnerInterface`      | `analytics.service_endpoint_runner` |
| `AnalyticsCore\Widget\AbstractWidget`     | `widget`                            |
| anything in `Configuration/`              | `analytics.configuration` (public)  |
| anything in `CustomObject/`               | `custom_object` (public)            |

Everything under `src/` is autowired except `src/Entity/`.

Current registrations:

- **Widget** `AnalyticsFiBuBundle.booking` (`getName()` = bundle name + `.booking`), template
  `booking`, roles `ROLE_USER` + `ACCESS_FIBU`. The Twig template must submit with that exact
  name: `_widgetHelper.submitWidget('AnalyticsFiBuBundle.booking', formData)`.
- **Macro** `book` (source `FiBuBundle`) — declared but `run()` is still a stub.
- **Service endpoint** `book` (POST), bundle name `AnalyticsFiBuBundle`, role `FIBU_USER`.
- **Configuration group** `fibuBundle.general` — keys `defaultApplication`,
  `defaultPaymentMethod`, and the repeat field `ownPaymentMethods`. Read via
  `ConfigurationProvider::getValue(GeneralConfigurationGroup::KEY, '<key>')`. `ownPaymentMethods`
  drives the incoming/outgoing direction in `ExecuteBookingJob`.
- **Permissions** `ACCESS_FIBU`, `READ_FIBU_PAYMENT_METHODS` (`EPermission` enum). When adding
  one, add the case *and* list it in `EPermission::getPermissions()` — that method is a manual
  list, not `self::cases()`.
- **Menu** built in `AnalyticsFiBuBundle::getMenuItems()` from `MenuItemDTO::create(label, route,
  params, icon, children, permissions)`.

## Conventions

- Setters on entities, custom objects and DTO-ish classes return `static` for chaining.
- DTOs extend `AnalyticsCore\Support\DTO\DTO`, use public typed properties with defaults, and a
  static `createFromArray(array $arr): self` that null-coalesces every key. Nested DTO arrays are
  hydrated defensively (accept either an already-built DTO or a raw array — see `TransactionDTO`).
- Custom-object accessors always supply a default to `getAttribute()`.
- Widgets declare `getPreloadPlaceholders()` (skeleton layout) and enrich Twig variables in
  `enrichProperties(array $properties): array` by spreading `...$properties` first.
- Several older files carry a `Created by PhpStorm` docblock header. Keep existing ones; new files
  do not need it.
- `.idea/` is committed on purpose — leave it alone.

## Known quirks — read before "fixing" them

- **`Analytics\...` imports are host-application classes, not this bundle's dependency.**
  `Analytics\DTO\WidgetSubmitResultDTO`, `Analytics\ENUM\eWorkerJobType`, and
  `Analytics\Entity\BankAccount` resolve only inside the Analytics app; `analytics-core` only
  ships `Cehlers88\AnalyticsCore\`. Static analysis run from this repo alone will report them as
  undefined. Most equivalents have migrated to `Cehlers88\AnalyticsCore\...` — before changing an
  import, confirm against the installed core version rather than guessing.
- `BankAccountRepository` imports `Analytics\Entity\BankAccount` while the entity here is
  `Cehlers88\AnalyticsFiBuBundle\Entity\BankAccount` — a genuine leftover, harmless only because
  the repository is unused.
- `FiBuBundleExtension::load()` is empty and its class name does not follow Symfony's
  `AnalyticsFiBuExtension` convention, so it does not load `services.yaml`. That file is picked up
  by the host application / `AbstractBundlePlugin`. Do not assume the extension runs.
- `AnalyticsFiBuBundle::getVersion()` hardcodes `'1.0.0'` and is unrelated to the released version
  (1.10.x). Releases are tagged by release-please, not by this method.
- `templates/widget/booking.html.twig` gives **both** suggest-inputs the id `creditor-{{ id }}`,
  so `document.getElementById('debitor-…')` returns `null` and the two "Summe" inputs are inert
  leftovers. Real bug; fix it deliberately, not incidentally.
- `HandleScheduledBookingsJob::endOfRepeatingReached()` computes `$paymentMethodIdToCheck` /
  `$amount` and never uses them — an unfinished feature, not dead code to delete silently.
- `CreateClosingEntryWorker` and `BookMacro::run()` are scaffolds for daily/monthly/yearly closing
  reports and macro-driven booking.
- `README.md` has drifted from the code: it documents PHP 8.1+, `analytics-core ^0.3`,
  `PaymentMethod` as a Doctrine entity/`fibu_payment_method` table, endpoint `fibu_booking`, and
  widget role `FIBU_USER`. The code is the source of truth. If you change behaviour the README
  documents, update the README in the same commit.

## Workflow

- **Branch**: never commit to `main` directly. Work on the branch you were assigned.
- **Commits**: Conventional Commits — release-please parses them. History is almost entirely
  `chore:` / `chore(deps):`; use `feat:` and `fix:` when the change actually is one, since those
  drive the version bump. Scope is optional. No model or assistant identifiers in commit
  messages, PR text, or code comments.
- **Releases**: pushing to `main` runs `.github/workflows/release-please.yml` (release-type `php`),
  which maintains `CHANGELOG.md` and opens a release PR. Publishing that release fires
  `.github/workflows/trigger-satis.yml`, which dispatches a rebuild of the Satis index so the new
  version becomes installable. Never hand-edit `CHANGELOG.md` or version numbers.
- **Dependencies**: `cehlers88/analytics-core` bumps arrive as automated PRs. Don't edit
  `composer.lock` by hand.
