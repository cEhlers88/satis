# AnalyticsFiBuBundle

A Symfony bundle that provides financial accounting (Finanzbuchhaltung/FiBu) functionality for the Analytics platform. It enables management of bank accounts and payment methods, creation of financial bookings, and tracking of payment flows between creditors and debtors.

## Table of Contents

- [Requirements](#requirements)
- [Installation](#installation)
- [Bundle Registration](#bundle-registration)
- [Database Setup](#database-setup)
- [Permissions](#permissions)
- [Entities](#entities)
  - [BankAccount](#bankaccount)
  - [PaymentMethod](#paymentmethod)
- [Widgets](#widgets)
  - [BookingWidget](#bookingwidget)
- [Macros](#macros)
  - [BookMacro](#bookmacro)
- [Service Endpoints](#service-endpoints)
  - [BookingServiceEndpointRunner](#bookingserviceendpointrunner)
- [Workers](#workers)
  - [BookingWorker](#bookingworker)
- [Configuration](#configuration)
- [Menu Structure](#menu-structure)
- [Changelog](#changelog)

---

## Requirements

- PHP 8.1+
- Symfony (compatible framework version)
- Doctrine ORM
- [`cehlers88/analytics-core`](https://github.com/cEhlers88/AnalyticsCoreBundle) `^0.3`

---

## Installation

This package is distributed via a private [Satis](https://composer.github.io/satis/) repository. Add the repository to your `composer.json` before requiring the package:

```json
{
    "repositories": [
        {
            "type": "composer",
            "url": "https://cehlers88.github.io/satis"
        }
    ]
}
```

Then install the bundle via Composer:

```bash
composer require cehlers88/analytics-fibu-bundle
```

---

## Bundle Registration

Register the bundle in your Symfony application's `config/bundles.php`:

```php
return [
    // ...
    Cehlers88\AnalyticsFiBuBundle\AnalyticsFiBuBundle::class => ['all' => true],
];
```

---

## Database Setup

The bundle adds two database tables. After installation, run the Doctrine migrations or schema update:

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

Or, for development environments:

```bash
php bin/console doctrine:schema:update --force
```

The following tables will be created:

| Table | Description |
|-------|-------------|
| `fibu_bank_account` | Stores bank account details (IBAN, holder name) |
| `fibu_payment_method` | Stores payment methods with creditor/debitor flags and optional bank account link |

---

## Permissions

The bundle defines the following permissions via the `EPermission` enum:

| Permission | Value | Description |
|---|---|---|
| `ACCESS_FIBU` | `ACCESS_FIBU` | Grants access to the Finanzbuchhaltung (FiBu) menu section |
| `READ_FIBU_PAYMENT_METHODS` | `READ_FIBU_PAYMENT_METHODS` | Grants access to the payment methods list view |

These permissions are registered automatically with the Analytics platform when the bundle is loaded.

---

## Entities

### BankAccount

**Table:** `fibu_bank_account`

Represents a bank account that can be associated with a payment method.

| Field | Type | Description |
|-------|------|-------------|
| `id` | `int` | Auto-generated primary key |
| `iban` | `string(24)` | The International Bank Account Number |
| `holderName` | `string(255)` | Name of the account holder |

**Example usage:**

```php
use Cehlers88\AnalyticsFiBuBundle\Entity\BankAccount;

$account = new BankAccount();
$account->setIban('DE89370400440532013000');
$account->setHolderName('Max Mustermann');

$entityManager->persist($account);
$entityManager->flush();
```

---

### PaymentMethod

**Table:** `fibu_payment_method`

Represents a payment method that can act as a creditor, a debitor, or both. An optional bank account can be linked.

| Field | Type | Description |
|-------|------|-------------|
| `id` | `int` | Auto-generated primary key |
| `name` | `string(255)` | Display name of the payment method |
| `description` | `string(255)\|null` | Optional description |
| `isCreditor` | `bool` | Whether this method can act as a creditor (receiving party) |
| `isDebitor` | `bool` | Whether this method can act as a debitor (paying party) |
| `bankAccount` | `BankAccount\|null` | Optionally linked bank account |

**Example usage:**

```php
use Cehlers88\AnalyticsFiBuBundle\Entity\PaymentMethod;

$method = new PaymentMethod();
$method->setName('Corporate Checking Account');
$method->setDescription('Main business account');
$method->setIsDebitor(true);
$method->setIsCreditor(false);
$method->setBankAccount($bankAccount); // optional

$entityManager->persist($method);
$entityManager->flush();
```

---

## Widgets

### BookingWidget

**Widget name:** `booking`  
**Required roles:** `ROLE_USER`, `FIBU_USER`  
**Template:** `templates/widget/booking.html.twig`

The `BookingWidget` renders a form that allows users to create financial bookings. It loads all available payment methods from the database and passes them to the Twig template.

**Template variables provided:**

| Variable | Type | Description |
|----------|------|-------------|
| `paymentMethods` | `PaymentMethod[]` | All payment methods; filtered in the template by `isDebitor`/`isCreditor` flags |

**Form fields rendered:**

| Field | Description |
|-------|-------------|
| Debitor (Eigene Zahlungsart) | Dropdown of payment methods where `isDebitor = true` |
| Creditor (Kreditor Zahlungsweg) | Dropdown of payment methods where `isCreditor = true` |
| Description (Posten beschreibung) | Text input for the line-item description |
| Amount (Betrag) | Text input for the monetary amount |
| Transaction description (Transaktionsbeschreibung) | Text input for the overall transaction description |

**Client-side validation:**

- Creditor must be selected
- Debitor must be selected
- Creditor and Debitor must not be the same payment method

On successful validation, the widget submits a `POST` request to `submitWidget/booking` via the Analytics widget helper.

---

## Macros

### BookMacro

**Macro name:** `book`  
**Source:** `FiBuBundle`

The `BookMacro` is used to programmatically book a financial transaction. It can be configured with the following properties:

| Property | Type | Description |
|----------|------|-------------|
| `paymentMethod` | `int` | ID of the payment method to use for the booking |
| `counterPaymentMethod` | `int` | ID of the counter-party payment method |
| `value` | — | The monetary value to book |
| `description` | — | Description for the booking entry |
| `data` | — | Additional data for the booking |

**Example configuration (within Analytics macro pipeline):**

```json
{
    "macro": "book",
    "properties": {
        "paymentMethod": 1
    }
}
```

---

## Service Endpoints

### BookingServiceEndpointRunner

**Endpoint:** `fibu_booking`  
**Bundle:** `AnalyticsFiBuBundle`

This endpoint handles incoming booking requests from the Analytics platform. It requires an authenticated user session.

**Request:** Any HTTP request to the `fibu_booking` endpoint.

**Responses:**

| Scenario | Response |
|----------|----------|
| User not authenticated | Error: `"user not logged in"` |
| User authenticated | Success with user ID and current tracking buffer count |

**Success response payload:**

```json
{
    "user": 42,
    "count": 5
}
```

---

## Workers

### BookingWorker

**Worker name:** `BookingWorker`

The `BookingWorker` is a background task processor registered with the Analytics platform. It currently serves as a scaffold for future background booking processing logic.

---

## Configuration

The bundle provides a configuration group (`fibuBundle.general`) accessible in the Analytics administration interface under **Allgemeine Finanzbuchhaltungseinstellungen**.

| Key | Type | Description |
|-----|------|-------------|
| `defaultPaymentMethod` | `select` | The default payment method pre-selected in booking forms; options are populated from all available `PaymentMethod` entities |

---

## Menu Structure

When a user has the required permissions, the following navigation items are added to the Analytics menu:

```
Finanzbuchhaltung                          [requires: ACCESS_FIBU]
└── Zahlungswege                           [requires: READ_FIBU_PAYMENT_METHODS]
    (route: analytics_fibu_payment_methods)
```

---

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a full history of changes.

---

## License

This bundle is proprietary software. See [LICENSE](LICENSE) for details.

© 2024 Christoph Ehlers
