<?php

namespace Cehlers88\AnalyticsFiBuBundle\Repository;

use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Cehlers88\AnalyticsFiBuBundle\Entity\PaymentMethod;

/**
 * @extends ServiceEntityRepository<PaymentMethod>
 */
class PaymentMethodRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, PaymentMethod::class);
    }

    public function save(PaymentMethod $paymentMethod, bool $flush = false): void
    {
        $this->getEntityManager()->persist($paymentMethod);

        if (!$flush) {
            return;
        }

        $this->getEntityManager()->flush();
    }
}
