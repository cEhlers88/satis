<?php

namespace Cehlers88\AnalyticsFiBuBundle\Worker;

use Cehlers88\AnalyticsCore\Worker\AbstractWorker;
use Cehlers88\AnalyticsFiBuBundle\Worker\Job\ExecuteBookingJob;
use Cehlers88\AnalyticsFiBuBundle\Worker\Job\HandleScheduledBookingsJob;

class BookingWorker extends AbstractWorker
{
    public function __construct()
    {
        //$this->addProperty(PropertyDTO::create('keys', null, 'array'));
    }

    public function getWorkingObjects(): array
    {
        $processableBuffers = [];
        $handleScheduledJob = $this->getJobByClassName(HandleScheduledBookingsJob::class);

        foreach ($this->trackingBufferRepository->findByAnyDataKeyValue([
            ExecuteBookingJob::$KEY,
            HandleScheduledBookingsJob::$KEY
        ]) as $availableBookingBuffer) {
            if ($availableBookingBuffer->getKeyValue() === HandleScheduledBookingsJob::$KEY) {
                if (!$handleScheduledJob->willHandle($availableBookingBuffer)) {
                    continue;
                }
            }
            $processableBuffers[] = $availableBookingBuffer;
        }

        return $processableBuffers;
    }

    public function getRequiredJobs(): array
    {
        return [
            HandleScheduledBookingsJob::class,
            ExecuteBookingJob::class
        ];
    }

    protected function onJobsComplete(): void
    {
        $this->addResultMessage('Buchungen wurden verarbeitet');
    }
}