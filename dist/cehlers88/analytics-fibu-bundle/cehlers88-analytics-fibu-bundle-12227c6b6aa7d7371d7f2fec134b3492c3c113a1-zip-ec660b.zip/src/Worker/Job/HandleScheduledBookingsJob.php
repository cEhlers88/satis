<?php

namespace Cehlers88\AnalyticsFiBuBundle\Worker\Job;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;

class HandleScheduledBookingsJob extends AbstractWorkerJob
{
    public static string $KEY = 'FIBU.scheduled_booking';

    public function __construct(
        private TrackingBufferRepository $trackingBufferRepository,
    )
    {
        $this->setType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION);
    }

    /**
     * @param TrackingBuffer $workingObject
     */
    public function willHandle(object $workingObject): bool
    {
        if ($workingObject->getKeyValue() !== self::$KEY) {
            return false;
        }

        $data = $workingObject->getData()['data'];
        $waitUntil = $data['waitUntil'] ?? null;
        if (is_null($waitUntil)) {
            return true;
        }
        return strtotime($waitUntil) < time();
    }

    /**
     * @param TrackingBuffer $object
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $data = $object->getData()['data'];
        $repeatOptions = $data['repeatOptions'] ?? [];
        $lastExecution = $repeatOptions['lastExecution'] ?? null;

        if (is_null($lastExecution) || strtotime($lastExecution) < time()) {
            return $this;
        }

        $this->createFollowTrackingBuffer($object);
        $this->createExecutionTrackingBuffer($object);

        $object
            ->setHandledAt(new \DateTime())
            ->setState(eTrackingBufferState::PROCESSED_FINISHED);

        return $this;
    }

    private function createFollowTrackingBuffer(TrackingBuffer $trackingBuffer): void
    {
        $data = $trackingBuffer->getData();
        $repeatOptions = $data['data']['repeatOptions'];
        $oldWaitUntil = strtotime($data['data']['waitUntil']);
        $newWaitUntil = strtotime($repeatOptions['interval'], $oldWaitUntil);

        $data['data']['waitUntil'] = date('Y-m-d', $newWaitUntil);

        $newTrackingBuffer = new TrackingBuffer();
        $newTrackingBuffer
            ->setData($data)
            ->setApplication($trackingBuffer->getApplication())
            ->setNote($trackingBuffer->getNote())
            ->setState(eTrackingBufferState::NEW);

        $this->trackingBufferRepository->save($newTrackingBuffer);
    }

    private function createExecutionTrackingBuffer(TrackingBuffer $trackingBuffer): void
    {
        $data = [
            'key' => ExecuteBookingJob::$KEY,
            'data' => [
                'transaction' => $trackingBuffer->getData()['data']['transaction']
            ]
        ];

        $newTrackingBuffer = new TrackingBuffer();
        $newTrackingBuffer
            ->setData($data)
            ->setApplication($trackingBuffer->getApplication())
            ->setNote('')
            ->setState(eTrackingBufferState::NEW);

        $this->trackingBufferRepository->save($newTrackingBuffer);
    }
}