<?php

namespace Cehlers88\AnalyticsFiBuBundle\Worker\Job;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionDTO;
use Cehlers88\AnalyticsFiBuBundle\Repository\PaymentMethodRepository;

class ExecuteBookingJob extends AbstractWorkerJob
{
    public static string $KEY = 'FIBU.booking';

    public function __construct(
        private PaymentMethodRepository $paymentMethodRepository,
    )
    {
        $this->setType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION);
    }

    /**
     * @param TrackingBuffer $object
     * @return AbstractWorkerJob
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $data = $object->getData()['data'];

        $transaction = TransactionDTO::createFromArray($data['transaction']);

        foreach ($transaction->postings as $posting) {
            $paymentMethod = $this->paymentMethodRepository->find($posting->paymentMethod);
            if (empty($paymentMethod)) {
                $this->logWarning('payment method not found: ' . $posting->paymentMethod);
                continue;
            }

            $updatedAmount = $posting->type === 'debit' ? $posting->amount : -$posting->amount;
            $paymentMethod->setCurrentAmount($paymentMethod->getCurrentAmount() + $updatedAmount);

            $this->paymentMethodRepository->save($paymentMethod, true);
        }
        $object
            ->setHandledAt(new \DateTime())
            ->setState(eTrackingBufferState::PROCESSED_FINISHED);

        return parent::workOnObject($object);
    }

    public function willHandle(object $workingObject): bool
    {
        if ($workingObject->getKeyValue() !== self::$KEY) {
            return false;
        }

        return true;
    }
}