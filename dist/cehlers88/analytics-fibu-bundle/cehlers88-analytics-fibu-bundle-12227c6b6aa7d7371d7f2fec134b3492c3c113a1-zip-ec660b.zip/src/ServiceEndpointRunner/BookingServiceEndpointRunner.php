<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 01.11.2025
 * Time: 11:14
 */

namespace Cehlers88\AnalyticsFiBuBundle\ServiceEndpointRunner;

use Analytics\DTO\ServiceEndpointRunnerResultDTO;
use Analytics\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Analytics\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Symfony\Component\HttpFoundation\Request;

class BookingServiceEndpointRunner extends AbstractServiceEndpointRunner
{
    public function handleRequest(Request $request): mixed
    {
        if ($this->getUser() === null) {
            return ServiceEndpointRunnerResultDTO::createError('user not logged in');
        }

        return ServiceEndpointRunnerResultDTO::createSuccess([
            'user' => $this->getUser()->getId(),
        ], 'executed booking');
    }

    public function getEndpoints(): mixed
    {
        return [
            EndpointDefinitionDTO::create('book', ['POST']),
            /*EndpointDefinitionDTO::create('startTransaction', ['POST']),
            EndpointDefinitionDTO::create('submitTransaction', ['POST']),
            EndpointDefinitionDTO::create('paymentMethods', ['GET'])*/
        ];
    }

    public function getBundleName(): string
    {
        return 'AnalyticsFiBuBundle';
    }

    public function getRequiredRoles(): array
    {
        return ['FIBU_USER'];
    }
}