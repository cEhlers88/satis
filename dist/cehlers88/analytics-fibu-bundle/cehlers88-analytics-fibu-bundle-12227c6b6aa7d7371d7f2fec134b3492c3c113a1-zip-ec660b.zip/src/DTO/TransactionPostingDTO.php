<?php

namespace Cehlers88\AnalyticsFiBuBundle\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;

class TransactionPostingDTO extends DTO
{
    public int $paymentMethod = -1;

    public string $type = '';

    public float $amount = 0;

    public static function createFromArray(array $arr): self
    {
        $dto = new self();
        $dto->paymentMethod = $arr['paymentMethod'] ?? -1;
        $dto->type = $arr['type'] ?? 'debit';
        $dto->amount = $arr['amount'] ?? 0;
        return $dto;
    }
}