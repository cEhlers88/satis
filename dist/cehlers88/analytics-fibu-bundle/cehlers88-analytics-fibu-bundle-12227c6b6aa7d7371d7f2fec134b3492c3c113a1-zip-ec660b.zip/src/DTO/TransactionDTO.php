<?php

namespace Cehlers88\AnalyticsFiBuBundle\DTO;

use Cehlers88\AnalyticsCore\DTO\DTO;

class TransactionDTO extends DTO
{
    public string $description = '';

    /** @var int[] */
    public array $categories = [];

    /** @var TransactionPostingDTO[] */
    public array $postings = [];

    public static function createFromArray(array $arr): self
    {
        $dto = new self();
        $dto->description = $arr['description'] ?? '';
        $dto->categories = $arr['categories'] ?? [];
        $dto->postings = [];

        foreach ($arr['postings'] ?? [] as $posting) {
            $dto->postings[] = TransactionPostingDTO::createFromArray($posting);
        }

        return $dto;
    }
}