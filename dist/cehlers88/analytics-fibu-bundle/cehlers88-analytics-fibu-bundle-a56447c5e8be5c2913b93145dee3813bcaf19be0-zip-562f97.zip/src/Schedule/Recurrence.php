<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsFiBuBundle\Schedule;

/**
 * The repeat intervals a standing order can be set up with, and the dates they
 * fall on.
 *
 * Dates are counted from the first execution rather than from the previous
 * one: a standing order on the 31st then runs on the last day of shorter
 * months and returns to the 31st afterwards, instead of drifting to the 28th
 * for good - and executing one early ("jetzt ausführen") does not shift the
 * ones after it.
 */
final class Recurrence
{
    /** strtotime-compatible interval => label */
    public const INTERVALS = [
        '+1 week' => 'Wöchentlich',
        '+2 weeks' => 'Alle 2 Wochen',
        '+1 month' => 'Monatlich',
        '+3 months' => 'Vierteljährlich',
        '+6 months' => 'Halbjährlich',
        '+1 year' => 'Jährlich',
    ];

    public static function isKnownInterval(string $interval): bool
    {
        return array_key_exists($interval, self::INTERVALS);
    }

    public static function getLabel(string $interval): string
    {
        return self::INTERVALS[$interval] ?? $interval;
    }

    /**
     * The date of the n-th execution, the first one being n = 0.
     */
    public static function occurrence(\DateTimeImmutable $start, string $interval, int $n): \DateTimeImmutable
    {
        if ($n <= 0) {
            return $start;
        }

        if (!preg_match('/^\+?\s*(\d+)\s*(day|week|month|year)s?$/i', trim($interval), $match)) {
            // Anything else strtotime understands still works, just without
            // the month-end correction.
            $date = $start;
            for ($i = 0; $i < $n; $i++) {
                $date = $date->modify($interval);
            }
            return $date;
        }

        $step = (int)$match[1] * $n;

        switch (strtolower($match[2])) {
            case 'day':
                return $start->modify('+' . $step . ' days');
            case 'week':
                return $start->modify('+' . ($step * 7) . ' days');
            case 'year':
                $step *= 12;
            // no break - a year is twelve months
            case 'month':
            default:
                $monthIndex = (int)$start->format('Y') * 12 + (int)$start->format('n') - 1 + $step;
                $year = intdiv($monthIndex, 12);
                $month = $monthIndex % 12 + 1;
                $daysInMonth = (int)$start->setDate($year, $month, 1)->format('t');

                return $start->setDate($year, $month, min((int)$start->format('j'), $daysInMonth));
        }
    }

    /**
     * The date of the last execution when a standing order runs $count times.
     */
    public static function lastOccurrence(\DateTimeImmutable $start, string $interval, int $count): \DateTimeImmutable
    {
        return self::occurrence($start, $interval, max(1, $count) - 1);
    }
}
