<?php

namespace Cehlers88\AnalyticsFiBuBundle\Worker\Job;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Cehlers88\AnalyticsFiBuBundle\Schedule\Recurrence;

class HandleScheduledBookingsJob extends AbstractWorkerJob
{
    public static string $KEY = 'FIBU.scheduled_booking';

    public function __construct(
        private TrackingBufferRepository $trackingBufferRepository,
    )
    {
        $this->setType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION);
    }

    /**
     * @param TrackingBuffer $workingObject
     */
    public function willHandle(object $workingObject): bool
    {
        if ($workingObject->getKeyValue() !== self::$KEY) {
            return false;
        }

        $data = $workingObject->getData()['data'];
        $waitUntil = $data['waitUntil'] ?? null;
        if (is_null($waitUntil)) {
            return true;
        }
        return strtotime($waitUntil) < time();
    }

    /**
     * @param TrackingBuffer $object
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $data = $object->getData()['data'];
        $repeatOptions = $data['repeatOptions'] ?? [];

        // Only schedules that record their start date (as the booking widget
        // creates them) follow the calendar rules below; every other scheduled
        // booking - from the tracking API, commands or older data - is handled
        // exactly as before.
        if (empty($repeatOptions['startDate'])) {
            return $this->workOnLegacySchedule($object);
        }

        // The due execution is booked even when it is the last one; the end of
        // the schedule only stops the follow-ups.
        if ($this->isWithinSchedule($data['waitUntil'] ?? null, $repeatOptions)) {
            $this->createExecutionTrackingBuffer($object);
        }

        $nextExecution = $this->getNextExecution($repeatOptions);
        if (!is_null($nextExecution)) {
            $this->createFollowTrackingBuffer($object, $nextExecution);
        }

        $this->_worker->setWantToReRun(true);

        $object
            ->setHandledAt(new \DateTime())
            ->setState(eTrackingBufferState::PROCESSED_FINISHED);

        return $this;
    }

    private function workOnLegacySchedule(TrackingBuffer $object): AbstractWorkerJob
    {
        $data = $object->getData()['data'];
        $repeatOptions = $data['repeatOptions'] ?? [];

        if (!$this->endOfRepeatingReached($repeatOptions)) {
            $this->createLegacyFollowTrackingBuffer($object);
            $this->createExecutionTrackingBuffer($object);
            $this->_worker->setWantToReRun(true);
        }

        $object
            ->setHandledAt(new \DateTime())
            ->setState(eTrackingBufferState::PROCESSED_FINISHED);

        return $this;
    }

    private function endOfRepeatingReached(array $repeatOptions): bool
    {
        $amountReached = $repeatOptions['amountReached'] ?? null;
        if (!is_null($amountReached)) {
            $paymentMethodIdToCheck = $amountReached['paymentMethod'] ?? -1;
            $amount = $amountReached['amount'];
        }

        $lastExecution = $repeatOptions['lastExecution'] ?? null;
        if (is_null($lastExecution) || strtotime($lastExecution) < time()) {
            return true;
        }

        return false;
    }

    private function createLegacyFollowTrackingBuffer(TrackingBuffer $trackingBuffer): void
    {
        $data = $trackingBuffer->getData();
        $data['data']['parentId'] = $trackingBuffer->getId();

        $repeatOptions = $data['data']['repeatOptions'];
        $oldWaitUntil = strtotime($data['data']['waitUntil']);
        $newWaitUntil = strtotime($repeatOptions['interval'], $oldWaitUntil);

        $data['data']['waitUntil'] = date('Y-m-d', $newWaitUntil);

        $this->createNewTrackingBuffer($data, $trackingBuffer);
    }

    private function isWithinSchedule(?string $executionDate, array $repeatOptions): bool
    {
        $lastExecution = $repeatOptions['lastExecution'] ?? null;
        if (empty($lastExecution) || empty($executionDate)) {
            return true;
        }

        return date('Y-m-d', strtotime($executionDate)) <= date('Y-m-d', strtotime($lastExecution));
    }

    private function getNextExecution(array $repeatOptions): ?\DateTimeImmutable
    {
        $interval = $repeatOptions['interval'] ?? null;
        if (empty($interval)) {
            return null;
        }

        $nextExecution = Recurrence::occurrence(
            new \DateTimeImmutable($repeatOptions['startDate']),
            $interval,
            (int)($repeatOptions['occurrence'] ?? 0) + 1
        );

        $lastExecution = $repeatOptions['lastExecution'] ?? null;
        if (!empty($lastExecution) && $nextExecution->format('Y-m-d') > date('Y-m-d', strtotime($lastExecution))) {
            return null;
        }

        return $nextExecution;
    }

    private function createFollowTrackingBuffer(TrackingBuffer $trackingBuffer, \DateTimeImmutable $nextExecution): void
    {
        $data = $trackingBuffer->getData();
        $data['data']['parentId'] = $trackingBuffer->getId();
        $data['data']['waitUntil'] = $nextExecution->format('Y-m-d');
        $data['data']['repeatOptions']['occurrence'] = (int)($data['data']['repeatOptions']['occurrence'] ?? 0) + 1;

        $this->createNewTrackingBuffer($data, $trackingBuffer, $trackingBuffer->getHandlerData());
    }

    private function createNewTrackingBuffer(
        array                $data,
        TrackingBuffer       $parentTrackingBuffer,
        ?array               $handlerData = null,
        eTrackingBufferState $state = eTrackingBufferState::NEW
    ): void
    {
        $newTrackingBuffer = new TrackingBuffer();
        $newTrackingBuffer
            ->setData($data)
            ->setHandlerData($handlerData)
            ->setApplication($parentTrackingBuffer->getApplication())
            ->setNote($parentTrackingBuffer->getNote())
            ->setFilters($parentTrackingBuffer->getFilters())
            ->setState($state);

        $this->trackingBufferRepository->save($newTrackingBuffer);
    }

    private function createExecutionTrackingBuffer(TrackingBuffer $trackingBuffer): void
    {
        $data = [
            'key' => ExecuteBookingJob::$KEY,
            'data' => [
                'scheduledBy' => $trackingBuffer->getId(),
                'transaction' => $trackingBuffer->getData()['data']['transaction']
            ]
        ];

        // Whoever set the schedule up may have approved all its executions in
        // advance; otherwise each one waits for someone to approve it.
        $approvedBy = (int)($trackingBuffer->getData()['data']['autoApprovedBy'] ?? -1);

        $this->createNewTrackingBuffer($data, $trackingBuffer, [
            'approvedBy' => $approvedBy
        ], $approvedBy > 0 ? eTrackingBufferState::NEW : eTrackingBufferState::INTERACTION_REQUIRED);
    }
}