<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsFiBuBundle\Overview;

use Cehlers88\AnalyticsFiBuBundle\Schedule\ScheduledBookingService;

/**
 * The days a booking overview covers: a period that moves along with the
 * calendar ("Dieser Monat") or a fixed one between two dates.
 */
final class BookingPeriod
{
    public const THIS_WEEK = 'thisWeek';
    public const THIS_MONTH = 'thisMonth';
    public const THIS_YEAR = 'thisYear';
    public const LAST_WEEK = 'lastWeek';
    public const LAST_MONTH = 'lastMonth';
    public const LAST_YEAR = 'lastYear';
    public const CUSTOM = 'custom';

    /** key => label, in the order the settings offer them */
    public const OPTIONS = [
        self::THIS_WEEK => 'Diese Woche',
        self::THIS_MONTH => 'Dieser Monat',
        self::THIS_YEAR => 'Dieses Jahr',
        self::LAST_WEEK => 'Letzte Woche',
        self::LAST_MONTH => 'Letzter Monat',
        self::LAST_YEAR => 'Letztes Jahr',
        self::CUSTOM => 'Fester Zeitraum',
    ];

    public const BUCKET_DAY = 'day';
    public const BUCKET_MONTH = 'month';
    public const BUCKET_YEAR = 'year';

    /**
     * @param string|null $error why the period asked for could not be used and
     *                           this one is shown instead - meant for the user
     */
    private function __construct(
        public readonly string             $key,
        public readonly \DateTimeImmutable $start,
        public readonly \DateTimeImmutable $end,
        public readonly ?string            $error = null,
    )
    {
    }

    /**
     * $from and $to only count for a fixed period, as Y-m-d. One given the
     * wrong way round is turned around; without a valid start the overview
     * falls back to the current month and says so.
     */
    public static function resolve(string $key, ?string $from, ?string $to, \DateTimeImmutable $today): self
    {
        $today = $today->setTime(0, 0);
        $monday = $today->modify('-' . ((int)$today->format('N') - 1) . ' days');

        return match ($key) {
            self::THIS_WEEK => new self($key, $monday, $monday->modify('+6 days')),
            self::LAST_WEEK => new self($key, $monday->modify('-7 days'), $monday->modify('-1 day')),
            self::THIS_YEAR => new self($key, $today->modify('first day of january this year'), $today->modify('last day of december this year')),
            self::LAST_YEAR => new self($key, $today->modify('first day of january last year'), $today->modify('last day of december last year')),
            self::LAST_MONTH => new self($key, $today->modify('first day of last month'), $today->modify('last day of last month')),
            self::CUSTOM => self::resolveCustom($from, $to, $today),
            default => self::thisMonth($today),
        };
    }

    private static function resolveCustom(?string $from, ?string $to, \DateTimeImmutable $today): self
    {
        $start = ScheduledBookingService::parseDate(trim((string)$from));
        if (is_null($start)) {
            return self::thisMonth($today, 'Kein gültiger Beginn des Zeitraums eingestellt - gezeigt wird der aktuelle Monat.');
        }

        // An open end is today: "since the 1st of March".
        $end = ScheduledBookingService::parseDate(trim((string)$to)) ?? $today;
        if ($end < $start) {
            [$start, $end] = [$end, $start];
        }

        return new self(self::CUSTOM, $start, $end);
    }

    private static function thisMonth(\DateTimeImmutable $today, ?string $error = null): self
    {
        return new self(self::THIS_MONTH, $today->modify('first day of this month'), $today->modify('last day of this month'), $error);
    }

    /** The first moment after the period, for a query that ends before it. */
    public function getEndExclusive(): \DateTimeImmutable
    {
        return $this->end->modify('+1 day');
    }

    public function getDayCount(): int
    {
        return (int)$this->start->diff($this->end)->days + 1;
    }

    /**
     * How finely the diagram groups the bookings: by day for up to two months,
     * by month for up to three years, by year beyond that.
     */
    public function getBucket(): string
    {
        $days = $this->getDayCount();

        return match (true) {
            $days <= 62 => self::BUCKET_DAY,
            $days <= 3 * 366 => self::BUCKET_MONTH,
            default => self::BUCKET_YEAR,
        };
    }

    public function getLabel(): string
    {
        return self::OPTIONS[$this->key] ?? $this->key;
    }
}
