<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsFiBuBundle\Booking;

use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsFiBuBundle\Schedule\ScheduledBookingService;

/**
 * The date a FIBU.booking entry belongs to, for whatever lists, filters or
 * sums bookings by day.
 */
final class BookingDate
{
    /**
     * The booking date the transaction was entered with, else the one
     * ExecuteBookingJob recorded when booking it, else - for bookings from
     * before the field existed - the day the entry was tracked.
     */
    public static function of(TrackingBuffer $trackingBuffer): ?\DateTimeImmutable
    {
        $data = $trackingBuffer->getData()['data'] ?? [];
        $transaction = $data['transaction'] ?? [];
        $candidates = [
            is_array($transaction) ? ($transaction['bookingDate'] ?? '') : ($transaction->bookingDate ?? ''),
            $trackingBuffer->getHandlerData()['bookingDate'] ?? '',
        ];

        foreach ($candidates as $candidate) {
            $date = ScheduledBookingService::parseDate((string)$candidate);
            if (!is_null($date)) {
                return $date;
            }
        }

        $timestamp = $trackingBuffer->getTimestamp();

        return is_null($timestamp)
            ? null
            : \DateTimeImmutable::createFromInterface($timestamp)->setTime(0, 0);
    }
}
