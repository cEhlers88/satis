<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsFiBuBundle\Booking;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsFiBuBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\PaymentMethod;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionDTO;

/**
 * Moves the money of a FIBU.booking entry between its payment methods - and
 * back again when the booking is cancelled. The one place the balances
 * (current_amount) of the payment methods are changed by a booking.
 *
 * A "debit" posting adds its amount to the payment method, a "credit" posting
 * takes it away; cancelling does the opposite of both.
 */
final class BookingExecutor
{
    public function __construct(
        private readonly ConfigurationProvider $configurationProvider,
        private readonly CustomObjectProvider  $customObjectProvider,
    )
    {
    }

    /**
     * Books the entry and closes it, as ExecuteBookingJob always did: the
     * handler data then holds the direction, the booking date and the new
     * balances of the payment methods.
     *
     * @return int[] the payment methods that were not found - their half of
     *         the transaction is skipped
     */
    public function execute(TrackingBuffer $booking): array
    {
        $transaction = self::readTransaction($booking);
        [$details, $missing, $direction] = $this->applyPostings($transaction, 1);

        $handledAt = new \DateTime();
        $booking
            ->setHandledAt($handledAt)
            ->setState(eTrackingBufferState::PROCESSED_FINISHED)
            ->setHandlerData([
                'direction' => $direction,
                // A booking that brings no date of its own (tracking API,
                // older callers) belongs to the day it is booked.
                'bookingDate' => $transaction->bookingDate !== '' ? $transaction->bookingDate : $handledAt->format('Y-m-d'),
                'details' => $details,
            ]);

        return $missing;
    }

    /**
     * Gives the money of an executed booking back: every payment method ends
     * up where it would be without the booking. Leaves the entry itself as it
     * is - marking it cancelled is BookingCancellationService's part.
     *
     * @return array<string, array{name: string, newAmount: float}> the new
     *         balances, keyed like the details of an executed booking
     */
    public function reverse(TrackingBuffer $booking): array
    {
        return $this->applyPostings(self::readTransaction($booking), -1)[0];
    }

    public static function readTransaction(TrackingBuffer $booking): TransactionDTO
    {
        $transaction = $booking->getData()['data']['transaction'] ?? [];

        return $transaction instanceof TransactionDTO
            ? $transaction
            : TransactionDTO::createFromArray(is_array($transaction) ? $transaction : []);
    }

    /**
     * @param int $sign 1 to book, -1 to cancel
     * @return array{0: array<string, array{name: string, newAmount: float}>, 1: int[], 2: string}
     *         the new balances, the payment methods not found and the direction
     *         (incoming / outgoing as seen from one's own payment methods,
     *         "undefined" when none of them is involved)
     */
    private function applyPostings(TransactionDTO $transaction, int $sign): array
    {
        $ownPaymentMethodIds = $this->getOwnPaymentMethodIds();
        $direction = 'undefined';
        $details = [];
        $missing = [];

        foreach ($transaction->postings as $posting) {
            $paymentMethod = $this->customObjectProvider->getCustomEntitiesBy(['id' => $posting->paymentMethod])[0] ?? null;
            if (!$paymentMethod instanceof PaymentMethod) {
                $missing[] = $posting->paymentMethod;
                continue;
            }
            if (in_array($posting->paymentMethod, $ownPaymentMethodIds)) {
                $direction = $posting->type === 'debit' ? 'incoming' : 'outgoing';
            }

            $change = $posting->type === 'debit' ? $posting->amount : -$posting->amount;
            $paymentMethod->setCurrentAmount($paymentMethod->getCurrentAmount() + $sign * $change);
            $this->customObjectProvider->save($paymentMethod);

            $details['pm_' . $paymentMethod->getId()] = [
                'name' => $paymentMethod->getName(),
                'newAmount' => $paymentMethod->getCurrentAmount(),
            ];
        }

        return [$details, $missing, $direction];
    }

    /** @return int[] */
    private function getOwnPaymentMethodIds(): array
    {
        $ids = [];
        $entries = $this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'ownPaymentMethods');
        foreach (is_iterable($entries) ? $entries : [] as $entry) {
            if (is_array($entry) && isset($entry['paymentMethod'])) {
                $ids[] = $entry['paymentMethod'];
            }
        }

        return $ids;
    }
}
