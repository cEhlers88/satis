<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsFiBuBundle\Booking;

/**
 * Amounts as people type them into a form.
 */
final class Amount
{
    /**
     * Accepts "1234.5", "1234,50" and "1.234,50" alike, rounded to cents; null
     * for anything that is not a finite number.
     */
    public static function parse(mixed $value): ?float
    {
        $value = str_replace([' ', '€'], '', trim(is_scalar($value) ? (string)$value : ''));
        if (str_contains($value, ',')) {
            $value = str_replace(['.', ','], ['', '.'], $value);
        }

        if (!is_numeric($value) || !is_finite((float)$value)) {
            return null;
        }

        return round((float)$value, 2);
    }
}
