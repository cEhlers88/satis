<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsFiBuBundle\Booking;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\Category;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\PaymentMethod;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionDTO;
use Cehlers88\AnalyticsFiBuBundle\Schedule\ScheduledBookingService;
use Cehlers88\AnalyticsFiBuBundle\Worker\Job\ExecuteBookingJob;

/**
 * Cancelling (Stornieren) and correcting FIBU.booking entries.
 *
 * A cancelled booking is not deleted: it keeps what was booked, and its handler
 * data gets a "cancellation" entry - when, by whom, why, and the balances the
 * payment methods have after the money was given back. Overviews leave it out
 * from then on (see isCancelled()).
 *
 * Cancelling happens either
 * - synchronously: the money goes back to the payment methods right away and
 *   no further entry is created, or
 * - asynchronously: a cancellation order (FIBU.cancel_booking, nested below the
 *   booking) is tracked, and the BookingWorker carries it out on its next run
 *   (ExecuteBookingCancellationJob). Until then the booking is marked as
 *   pending, so it is not cancelled twice.
 *
 * A booking still waiting for its approval (INTERACTION_REQUIRED) has not moved
 * any money; cancelling it only takes it out of the way (IGNORED), whichever
 * way was asked for. One the worker may be booking at this moment (NEW) is
 * refused - the cancellation could come before the booking.
 *
 * A correction cancels the booking the same way and books the corrected values
 * as a new FIBU.booking, nested below the original and pointing back to it
 * ("corrects"). Synchronously that booking is executed at once, asynchronously
 * it waits for the worker like any other.
 */
final class BookingCancellationService
{
    public const KEY = 'FIBU.cancel_booking';

    public const MODE_SYNC = 'sync';
    public const MODE_ASYNC = 'async';

    public const MAX_REASON_LENGTH = 1000;

    public function __construct(
        private readonly BookingExecutor          $bookingExecutor,
        private readonly TrackingBufferRepository $trackingBufferRepository,
        private readonly CustomObjectProvider     $customObjectProvider,
    )
    {
    }

    /**
     * Whether the booking these handler data belong to was cancelled - an
     * ordered cancellation that has not been carried out yet does not count.
     */
    public static function isCancelled(?array $handlerData): bool
    {
        return is_array($handlerData['cancellation'] ?? null) && !empty($handlerData['cancellation']['cancelledAt']);
    }

    public static function isCancellationPending(?array $handlerData): bool
    {
        return is_array($handlerData['cancellation'] ?? null)
            && empty($handlerData['cancellation']['cancelledAt'])
            && !empty($handlerData['cancellation']['orderId']);
    }

    /**
     * @return TrackingBuffer|null the cancellation order when cancelled
     *         asynchronously, null when it is done already
     * @throws \InvalidArgumentException with a message meant for the user
     */
    public function cancel(TrackingBuffer $booking, string $mode, string $reason, int $userId): ?TrackingBuffer
    {
        $mode = self::normalizeMode($mode);
        $reason = self::normalizeReason($reason);
        $this->assertCancellable($booking);

        if ($booking->getState() === eTrackingBufferState::INTERACTION_REQUIRED) {
            $this->discard($booking, $mode, $reason, $userId);
            $this->trackingBufferRepository->flush();

            return null;
        }

        if ($mode === self::MODE_SYNC) {
            $this->cancelNow($booking, $mode, $reason, $userId);
            $this->trackingBufferRepository->flush();

            return null;
        }

        self::assertCanOrder($userId);

        return $this->createOrder($booking, $reason, $userId);
    }

    /**
     * Cancels the booking and books the corrected transaction in its place.
     * An empty description or booking date of the correction is taken from
     * the booking; so are the categories when none are given.
     *
     * @param iterable<Category>|null $categories null keeps those of the booking
     * @return TrackingBuffer the correction booking
     * @throws \InvalidArgumentException with a message meant for the user
     */
    public function correct(
        TrackingBuffer $booking,
        TransactionDTO $corrected,
        string         $mode,
        string         $reason,
        int            $userId,
        ?iterable      $categories = null,
    ): TrackingBuffer
    {
        $mode = self::normalizeMode($mode);
        $reason = self::normalizeReason($reason);
        $this->assertCancellable($booking);
        $this->assertBookable($corrected);
        if ($mode === self::MODE_ASYNC) {
            self::assertCanOrder($userId);
        }

        $original = BookingExecutor::readTransaction($booking);
        if (trim($corrected->description) === '') {
            $corrected->description = $original->description;
        }
        if ($corrected->bookingDate === '') {
            $corrected->bookingDate = BookingDate::of($booking)?->format('Y-m-d') ?? '';
        } elseif (is_null(ScheduledBookingService::parseDate($corrected->bookingDate))) {
            throw new \InvalidArgumentException('Ungültiges Buchungsdatum.');
        }

        $correction = new TrackingBuffer();
        $correction
            ->setState(eTrackingBufferState::NEW)
            ->setApplication($booking->getApplication())
            ->setParent($booking)
            ->setData([
                'key' => ExecuteBookingJob::$KEY,
                'data' => [
                    // Stored as plain arrays like every entry read back from the database.
                    'transaction' => json_decode(json_encode($corrected, JSON_THROW_ON_ERROR), true, 512, JSON_THROW_ON_ERROR),
                    'corrects' => $booking->getId(),
                    'correctionReason' => $reason,
                ],
            ])
            // Asked for by whoever corrects it, so it needs no further approval.
            ->setHandlerData(['approvedBy' => $userId])
            ->setCategories($categories ?? $booking->getCategories());
        $this->trackingBufferRepository->save($correction, true);

        if ($booking->getState() === eTrackingBufferState::INTERACTION_REQUIRED) {
            $this->discard($booking, $mode, $reason, $userId, $correction->getId());
        } elseif ($mode === self::MODE_SYNC) {
            $this->cancelNow($booking, $mode, $reason, $userId, ['correctedBy' => $correction->getId()]);
        } else {
            $this->createOrder($booking, $reason, $userId, $correction->getId());
        }

        if ($mode === self::MODE_SYNC) {
            $this->bookingExecutor->execute($correction);
        }
        $this->trackingBufferRepository->flush();

        return $correction;
    }

    /**
     * Carries out a cancellation order (FIBU.cancel_booking). An order whose
     * booking is gone, or cancelled meanwhile, ends in ERROR with the reason in
     * its handler data and moves no money.
     *
     * @return bool whether the booking was cancelled
     */
    public function executeOrder(TrackingBuffer $order): bool
    {
        $orderData = $order->getData()['data'] ?? [];
        $handlerData = $order->getHandlerData() ?? [];
        $bookingId = (int)($orderData['bookingId'] ?? 0);
        $booking = $bookingId > 0 ? $this->trackingBufferRepository->find($bookingId) : null;

        $error = match (true) {
            !$booking instanceof TrackingBuffer, !self::isBooking($booking) => 'Buchung nicht gefunden.',
            self::isCancelled($booking->getHandlerData()) => 'Die Buchung wurde bereits storniert.',
            $booking->getState() !== eTrackingBufferState::PROCESSED_FINISHED => 'Die Buchung ist nicht ausgeführt.',
            default => null,
        };

        $order->setHandledAt(new \DateTime());
        if (!is_null($error)) {
            // Lets go of the booking, so it can be cancelled again.
            if ($booking instanceof TrackingBuffer && !self::isCancelled($booking->getHandlerData())
                && (int)($booking->getHandlerData()['cancellation']['orderId'] ?? 0) === (int)$order->getId()) {
                $bookingHandlerData = $booking->getHandlerData();
                unset($bookingHandlerData['cancellation']);
                $booking->setHandlerData($bookingHandlerData);
            }
            $order
                ->setState(eTrackingBufferState::ERROR)
                ->setHandlerData([...$handlerData, 'error' => $error]);
            $this->trackingBufferRepository->flush();

            return false;
        }

        $details = $this->cancelNow(
            $booking,
            self::MODE_ASYNC,
            self::normalizeReason((string)($orderData['reason'] ?? '')),
            (int)($handlerData['approvedBy'] ?? -1)
        );
        $order
            ->setState(eTrackingBufferState::PROCESSED_FINISHED)
            ->setHandlerData([...$handlerData, 'details' => $details]);
        $this->trackingBufferRepository->flush();

        return true;
    }

    /**
     * @throws \InvalidArgumentException with a message meant for the user
     */
    public function assertCancellable(TrackingBuffer $booking): void
    {
        $handlerData = $booking->getHandlerData();

        if (!self::isBooking($booking)) {
            throw new \InvalidArgumentException('Dieser Eintrag ist keine Buchung.');
        }
        if (self::isCancelled($handlerData)) {
            throw new \InvalidArgumentException('Diese Buchung wurde bereits storniert.');
        }
        if (self::isCancellationPending($handlerData)) {
            throw new \InvalidArgumentException('Für diese Buchung ist bereits eine Stornierung beauftragt.');
        }

        match ($booking->getState()) {
            eTrackingBufferState::PROCESSED_FINISHED, eTrackingBufferState::INTERACTION_REQUIRED => null,
            eTrackingBufferState::NEW, eTrackingBufferState::IN_PROGRESS
                => throw new \InvalidArgumentException('Diese Buchung wird gerade ausgeführt - bitte danach stornieren.'),
            default => throw new \InvalidArgumentException('Nur ausgeführte oder auf Freigabe wartende Buchungen können storniert werden.'),
        };
    }

    /**
     * By its data rather than by the key column alone, which the database
     * fills in only once the entry is stored.
     */
    public static function isBooking(TrackingBuffer $trackingBuffer): bool
    {
        return ($trackingBuffer->getData()['key'] ?? $trackingBuffer->getKeyValue()) === ExecuteBookingJob::$KEY;
    }

    public static function normalizeMode(string $mode): string
    {
        return match ($mode) {
            self::MODE_SYNC, self::MODE_ASYNC => $mode,
            default => throw new \InvalidArgumentException('Unbekannte Art der Stornierung: ' . $mode),
        };
    }

    public static function normalizeReason(string $reason): string
    {
        $reason = trim($reason);
        if (mb_strlen($reason) > self::MAX_REASON_LENGTH) {
            throw new \InvalidArgumentException(sprintf('Der Stornierungsgrund ist zu lang (höchstens %d Zeichen).', self::MAX_REASON_LENGTH));
        }

        return $reason;
    }

    /**
     * The worker carries out only what someone approved (approvedBy), see
     * ExecuteBookingJob::willHandle().
     */
    private static function assertCanOrder(int $userId): void
    {
        if ($userId <= 0) {
            throw new \InvalidArgumentException('Ohne angemeldeten Benutzer kann kein Buchungsauftrag angelegt werden.');
        }
    }

    /**
     * Both accounts must be payment methods: BookingExecutor skips one it can
     * not find and would book only the other half of the transaction.
     *
     * @throws \InvalidArgumentException with a message meant for the user
     */
    private function assertBookable(TransactionDTO $transaction): void
    {
        $from = null;
        $to = null;
        foreach ($transaction->postings as $posting) {
            if ($posting->amount <= 0) {
                throw new \InvalidArgumentException('Bitte einen Betrag größer 0 eingeben.');
            }
            if ($posting->type === 'credit') {
                $from = $posting->paymentMethod;
            } else {
                $to = $posting->paymentMethod;
            }
        }

        if (count($transaction->postings) !== 2 || is_null($from) || is_null($to) || $from <= 0 || $to <= 0) {
            throw new \InvalidArgumentException('Bitte Ursprungs- und Zielkonto wählen.');
        }
        if ($from === $to) {
            throw new \InvalidArgumentException('Ursprungs- und Zielkonto müssen sich unterscheiden.');
        }
        foreach ([$from, $to] as $id) {
            if (!($this->customObjectProvider->getCustomEntitiesBy(['id' => $id])[0] ?? null) instanceof PaymentMethod) {
                throw new \InvalidArgumentException('Unbekanntes Konto.');
            }
        }
    }

    /**
     * Gives the money back and marks the booking cancelled.
     *
     * @param array<string, mixed> $extra further entries of the cancellation mark
     * @return array<string, array{name: string, newAmount: float}> the new balances
     */
    private function cancelNow(TrackingBuffer $booking, string $mode, string $reason, int $userId, array $extra = []): array
    {
        $details = $this->bookingExecutor->reverse($booking);

        $this->markCancelled($booking, [
            ...$extra,
            'cancelledAt' => (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM),
            'cancelledBy' => $userId,
            'reason' => $reason,
            'mode' => $mode,
            'details' => $details,
        ]);

        return $details;
    }

    /** A booking that never moved money is only taken out of the worker's way. */
    private function discard(TrackingBuffer $booking, string $mode, string $reason, int $userId, ?int $correctedBy = null): void
    {
        $this->markCancelled($booking, array_filter([
            'cancelledAt' => (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM),
            'cancelledBy' => $userId,
            'reason' => $reason,
            'mode' => $mode,
            'details' => [],
            'correctedBy' => $correctedBy,
        ], fn(mixed $value) => !is_null($value)));
        $booking
            ->setHandledAt(new \DateTime())
            ->setState(eTrackingBufferState::IGNORED);
    }

    private function createOrder(TrackingBuffer $booking, string $reason, int $userId, ?int $correctedBy = null): TrackingBuffer
    {
        $order = new TrackingBuffer();
        $order
            ->setState(eTrackingBufferState::NEW)
            ->setApplication($booking->getApplication())
            ->setParent($booking)
            ->setData([
                'key' => self::KEY,
                'data' => [
                    'bookingId' => $booking->getId(),
                    'reason' => $reason,
                ],
            ])
            // Ordered by the one cancelling, so the worker may carry it out.
            ->setHandlerData(['approvedBy' => $userId]);
        $this->trackingBufferRepository->save($order, true);

        $this->markCancelled($booking, array_filter([
            'requestedAt' => (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM),
            'requestedBy' => $userId,
            'reason' => $reason,
            'mode' => self::MODE_ASYNC,
            'orderId' => $order->getId(),
            'correctedBy' => $correctedBy,
        ], fn(mixed $value) => !is_null($value)));
        $this->trackingBufferRepository->flush();

        return $order;
    }

    /**
     * Adds to the cancellation mark the booking may have already - the order
     * of an asynchronous cancellation is kept when it is carried out.
     *
     * @param array<string, mixed> $cancellation
     */
    private function markCancelled(TrackingBuffer $booking, array $cancellation): void
    {
        $handlerData = $booking->getHandlerData() ?? [];
        $handlerData['cancellation'] = [
            ...(is_array($handlerData['cancellation'] ?? null) ? $handlerData['cancellation'] : []),
            ...$cancellation,
        ];
        $booking->setHandlerData($handlerData);
    }
}
