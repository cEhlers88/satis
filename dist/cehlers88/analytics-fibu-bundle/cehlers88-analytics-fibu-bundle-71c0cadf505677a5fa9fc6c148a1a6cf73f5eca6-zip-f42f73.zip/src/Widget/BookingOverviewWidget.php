<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsFiBuBundle\Widget;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\ENUM\eConditionType;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\CategoryRepository;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsFiBuBundle\AnalyticsFiBuBundle;
use Cehlers88\AnalyticsFiBuBundle\Booking\BookingCancellationService;
use Cehlers88\AnalyticsFiBuBundle\Booking\BookingDate;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\PaymentMethod;
use Cehlers88\AnalyticsFiBuBundle\Overview\BookingOverview;
use Cehlers88\AnalyticsFiBuBundle\Overview\BookingPeriod;
use Cehlers88\AnalyticsFiBuBundle\Worker\Job\ExecuteBookingJob;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\AbstractQuery;
use Doctrine\ORM\QueryBuilder;

/**
 * Buchungsübersicht: the executed bookings of a period for the payment methods
 * picked in the tile settings, as a list and/or a diagram.
 */
class BookingOverviewWidget extends AbstractFiBuWidget
{
    /** The list stops here; the totals and the diagram still count every booking. */
    private const MAX_LISTED_BOOKINGS = 100;

    public function __construct(
        private readonly TrackingBufferRepository $trackingBufferRepository,
        ConfigurationProvider                     $configurationProvider,
        CustomObjectProvider                      $customObjectProvider,
        ApplicationRepository                     $applicationRepository,
        CategoryRepository                        $categoryRepository,
    )
    {
        parent::__construct($configurationProvider, $customObjectProvider, $applicationRepository, $categoryRepository);
    }

    public function getName(): string
    {
        return AnalyticsFiBuBundle::getBundleName() . '.bookingOverview';
    }

    public function getTemplateName(): string
    {
        return 'bookingOverview';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '28px', 'boxes' => [.3, .3, .3]],
            ['height' => '120px', 'boxes' => [1]],
            ['height' => '36px', 'boxes' => [1]],
            ['height' => '36px', 'boxes' => [1]],
            ['height' => '36px', 'boxes' => [1]],
        ];
    }

    public function getSettingDefinitions(): array
    {
        $paymentMethodNames = $this->getPaymentMethodNames();
        $ownPaymentMethodIds = array_values(array_filter(
            $this->getOwnPaymentMethodIds(),
            fn(int $id) => isset($paymentMethodNames[$id])
        ));
        $isFixedPeriod = PropertyConditionDTO::when('period', BookingPeriod::CUSTOM)->thenRequired();
        $isMovingPeriod = PropertyConditionDTO::when('period', BookingPeriod::CUSTOM, eConditionType::NOT_EQUALS)->thenHidden();

        return [
            PropertyDTO::create(
                name: 'period',
                value: BookingPeriod::THIS_MONTH,
                type: 'string',
                isOptional: true,
                label: 'Zeitraum',
                ui: ['options' => BookingPeriod::OPTIONS]
            ),
            PropertyDTO::create(
                name: 'dateFrom',
                value: null,
                type: 'date',
                isOptional: true,
                label: 'Von',
                conditions: [$isMovingPeriod, $isFixedPeriod]
            ),
            PropertyDTO::create(
                name: 'dateTo',
                value: null,
                type: 'date',
                isOptional: true,
                label: 'Bis',
                description: 'Leer bedeutet: bis heute.',
                conditions: [$isMovingPeriod]
            ),
            PropertyDTO::create(
                name: 'showList',
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Als Liste anzeigen'
            ),
            PropertyDTO::create(
                name: 'showChart',
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Als Diagramm anzeigen'
            ),
            PropertyDTO::create(
                name: 'groupBy',
                value: BookingOverview::GROUP_BY_PAYMENT_METHOD,
                type: 'string',
                isOptional: true,
                label: 'Gruppieren nach',
                description: 'Eine Buchung mit mehreren Kategorien zählt in jeder davon.',
                ui: ['options' => BookingOverview::GROUP_BY_OPTIONS]
            ),
            PropertyDTO::create(
                name: 'paymentMethods',
                value: null,
                type: 'string',
                isOptional: true,
                label: 'Zahlungswege',
                description: 'Ohne Auswahl zählen die eigenen Zahlungswege aus den FiBu-Einstellungen.',
                ui: [
                    'input' => 'suggest',
                    'multiple' => true,
                    'suggestions' => $paymentMethodNames,
                    'presets' => count($ownPaymentMethodIds) > 0
                        ? [['label' => 'Alle eigenen Zahlungswege', 'values' => $ownPaymentMethodIds]]
                        : [],
                ]
            ),
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $paymentMethods = $this->getPaymentMethods();
        $paymentMethodNames = [];
        $currentAmounts = [];
        foreach ($paymentMethods as $paymentMethod) {
            $paymentMethodNames[$paymentMethod->getId()] = $paymentMethod->getName();
            $currentAmounts[$paymentMethod->getId()] = $paymentMethod->getTileDetails()['currentAmount'];
        }

        $period = BookingPeriod::resolve(
            (string)($properties['period'] ?? BookingPeriod::THIS_MONTH),
            isset($properties['dateFrom']) ? (string)$properties['dateFrom'] : null,
            isset($properties['dateTo']) ? (string)$properties['dateTo'] : null,
            new \DateTimeImmutable('today')
        );
        [$selectedIds, $selection] = $this->resolveSelection($properties['paymentMethods'] ?? null, $paymentMethodNames);
        $categoryNames = [];
        foreach ($this->getCategoryOptions() as $option) {
            $categoryNames[(int)$option['value']] = $option['label'];
        }
        $groupBy = (string)($properties['groupBy'] ?? '');

        $overview = BookingOverview::build(
            $this->findBookings($period),
            $selectedIds,
            $paymentMethodNames,
            $period,
            $currentAmounts,
            self::MAX_LISTED_BOOKINGS,
            $categoryNames
        );

        return [
            ...$properties,
            'overview' => [
                ...$overview,
                'hiddenBookings' => max(0, $overview['totals']['count'] - count($overview['bookings'])),
            ],
            // Under a name of its own: "period" is the setting it was made from.
            'periodView' => [
                'key' => $period->key,
                'label' => $period->getLabel(),
                'start' => $period->start->format('Y-m-d'),
                'end' => $period->end->format('Y-m-d'),
                'error' => $period->error,
            ],
            'selection' => $selection,
            'groupBy' => isset(BookingOverview::GROUP_BY_OPTIONS[$groupBy]) ? $groupBy : BookingOverview::GROUP_BY_PAYMENT_METHOD,
            // An unchecked box is stored as false; a tile set up before the
            // setting existed shows both.
            'showList' => filter_var($properties['showList'] ?? true, FILTER_VALIDATE_BOOLEAN),
            'showChart' => filter_var($properties['showChart'] ?? true, FILTER_VALIDATE_BOOLEAN),
        ];
    }

    /**
     * The payment methods the overview is about: the ones picked in the
     * settings, or - with none picked - one's own from the FiBu settings, or
     * every payment method when there are none of those either. Picked ones
     * that were deleted since are skipped.
     *
     * @param array<int, string> $paymentMethodNames
     * @return array{0: int[], 1: string} the ids and where they came from
     *         ("settings", "own" or "all")
     */
    private function resolveSelection(mixed $setting, array $paymentMethodNames): array
    {
        $picked = is_array($setting) ? $setting : explode(',', is_scalar($setting) ? (string)$setting : '');
        $picked = array_values(array_unique(array_filter(
            array_map(fn(mixed $id) => is_scalar($id) ? (int)trim((string)$id) : 0, $picked),
            fn(int $id) => isset($paymentMethodNames[$id])
        )));
        if (count($picked) > 0) {
            return [$picked, 'settings'];
        }

        $own = array_values(array_filter($this->getOwnPaymentMethodIds(), fn(int $id) => isset($paymentMethodNames[$id])));
        if (count($own) > 0) {
            return [$own, 'own'];
        }

        return [array_keys($paymentMethodNames), 'all'];
    }

    /**
     * The bookings ExecuteBookingJob carried out that may belong to the
     * period - those waiting for approval have not moved any money yet, and
     * cancelled ones gave theirs back.
     *
     * The period is about the booking date (BookingDate), which the database
     * can not filter on. A booking is never tracked before its booking date, so
     * the query only bounds the start; a backdated booking processed after the
     * period still comes along, and BookingOverview drops what lies outside.
     *
     * Read as plain rows one by one rather than as managed entities, so a long
     * period costs a row each. Their categories come beforehand as pairs of
     * ids, which are few next to the bookings.
     *
     * @return iterable<array{id: int|null, date: \DateTimeInterface, transaction: mixed, categories: int[]}>
     */
    private function findBookings(BookingPeriod $period): iterable
    {
        $categoryIds = [];
        $pairs = $this->createBookingQuery($period)
            ->select('t.id AS bookingId', 'c.id AS categoryId')
            ->innerJoin('t.categories', 'c')
            ->getQuery()
            ->getScalarResult();
        foreach ($pairs as $pair) {
            $categoryIds[(int)$pair['bookingId']][] = (int)$pair['categoryId'];
        }

        $rows = $this->createBookingQuery($period)
            ->select('t.id', 't.timestamp', 't.data', 't.handlerData')
            ->getQuery()
            ->toIterable([], AbstractQuery::HYDRATE_ARRAY);

        foreach ($rows as $row) {
            // A detached entry, so the booking date is read by the one rule
            // BookingDate keeps for it.
            $trackingBuffer = (new TrackingBuffer())
                ->setData(is_array($row['data'] ?? null) ? $row['data'] : [])
                ->setHandlerData(is_array($row['handlerData'] ?? null) ? $row['handlerData'] : null);
            if ($row['timestamp'] instanceof \DateTimeInterface) {
                $trackingBuffer->setTimestamp($row['timestamp']);
            }

            // A cancelled booking gave its money back - as if it never happened.
            if (BookingCancellationService::isCancelled($trackingBuffer->getHandlerData())) {
                continue;
            }

            $date = BookingDate::of($trackingBuffer);
            if (is_null($date)) {
                continue;
            }

            $id = isset($row['id']) ? (int)$row['id'] : null;
            yield [
                'id' => $id,
                'date' => $date,
                'transaction' => $row['data']['data']['transaction'] ?? null,
                'categories' => is_null($id) ? [] : ($categoryIds[$id] ?? []),
            ];
        }
    }

    private function createBookingQuery(BookingPeriod $period): QueryBuilder
    {
        return $this->trackingBufferRepository->createQueryBuilder('t')
            ->where('t.keyValue = :key')
            ->andWhere('t.state = :state')
            ->andWhere('t.timestamp >= :start')
            ->setParameter('key', ExecuteBookingJob::$KEY)
            ->setParameter('state', eTrackingBufferState::PROCESSED_FINISHED->value)
            ->setParameter('start', $period->start, Types::DATETIME_IMMUTABLE);
    }
}
