<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsFiBuBundle\Schedule;

use Cehlers88\AnalyticsCore\Entity\Category;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Recorder\TrackingRecorder;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionDTO;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionPostingDTO;
use Cehlers88\AnalyticsFiBuBundle\Worker\Job\HandleScheduledBookingsJob;

/**
 * Planned bookings and standing orders.
 *
 * A schedule has no row of its own: it is the pending FIBU.scheduled_booking
 * entry of its next execution, which HandleScheduledBookingsJob replaces by the
 * one after it. Creating a schedule tracks that entry, changing one rewrites
 * it, and ending one ignores it - the worker then never creates the rest.
 *
 * The categories of a schedule are those of its pending entry; the worker
 * hands them on to every execution and to the entry after it.
 */
final class ScheduledBookingService
{
    public const END_NEVER = 'never';
    public const END_DATE = 'date';
    public const END_COUNT = 'count';

    public function __construct(
        private readonly TrackingRecorder         $trackingRecorder,
        private readonly TrackingBufferRepository $trackingBufferRepository,
    )
    {
    }

    /**
     * @param array{endType?: mixed, endDate?: mixed, endCount?: mixed} $end
     * @param iterable<Category> $categories
     * @throws \InvalidArgumentException with a message meant for the user
     */
    public function create(
        int                $applicationId,
        TransactionDTO     $transaction,
        \DateTimeImmutable $firstExecution,
        string             $interval,
        array              $end,
        bool               $autoApprove,
        int                $approvedBy,
        iterable           $categories = [],
    ): void
    {
        $scheduleData = [
            'transaction' => $transaction,
            'waitUntil' => $firstExecution->format('Y-m-d'),
        ];
        if ($autoApprove && $approvedBy > 0) {
            $scheduleData['autoApprovedBy'] = $approvedBy;
        }
        $scheduleData['repeatOptions'] = self::buildRepeatOptions($firstExecution, $interval, $end);

        $this->trackingRecorder->track(
            $applicationId,
            [
                'key' => HandleScheduledBookingsJob::$KEY,
                'data' => $scheduleData,
            ],
            true,
            ['approvedBy' => $approvedBy],
            $categories
        );
    }

    /**
     * Rewrites a pending schedule with what was entered for it.
     *
     * Its calendar is kept while neither the next execution nor the interval
     * changes, so a standing order on the 31st keeps returning to the 31st;
     * otherwise the schedule starts over from the new next execution. A
     * schedule from before the widget recorded start dates gets one here, and
     * an interval set up outside the widget may stay what it is.
     *
     * An execution that is already due is refused: the worker may be booking
     * it at this very moment, from the data as it was, and the change would be
     * lost on an entry that is already processed.
     *
     * @param array{endType?: mixed, endDate?: mixed, endCount?: mixed} $end
     * @param iterable<Category>|null $categories null keeps the ones it has
     * @throws \InvalidArgumentException with a message meant for the user
     */
    public function update(
        TrackingBuffer     $trackingBuffer,
        TransactionDTO     $transaction,
        \DateTimeImmutable $nextExecution,
        string             $interval,
        array              $end,
        bool               $autoApprove,
        int                $userId,
        ?iterable          $categories = null,
    ): void
    {
        $data = $trackingBuffer->getData();
        $schedule = $data['data'] ?? [];
        $current = $schedule['repeatOptions'] ?? [];
        $currentInterval = (string)($current['interval'] ?? '');

        if (self::isDue($trackingBuffer)) {
            throw new \InvalidArgumentException('Diese Ausführung ist bereits fällig und wird gerade gebucht - bitte danach ändern.');
        }

        $keepsCalendar = !empty($current['startDate'])
            && $interval !== ''
            && $currentInterval === $interval
            && (string)($schedule['waitUntil'] ?? '') === $nextExecution->format('Y-m-d');

        $schedule['repeatOptions'] = $keepsCalendar
            ? self::buildRepeatOptions(
                new \DateTimeImmutable((string)$current['startDate']),
                $interval,
                $end,
                (int)($current['occurrence'] ?? 0),
                $currentInterval
            )
            : self::buildRepeatOptions($nextExecution, $interval, $end, 0, $currentInterval);

        // Stored as plain arrays like every entry read back from the database.
        $schedule['transaction'] = json_decode(json_encode($transaction, JSON_THROW_ON_ERROR), true, 512, JSON_THROW_ON_ERROR);
        $schedule['waitUntil'] = $nextExecution->format('Y-m-d');

        // An advance approval stays with whoever gave it; switched on now, it
        // is the approval of the one changing the schedule.
        if (!$autoApprove) {
            unset($schedule['autoApprovedBy']);
        } elseif ((int)($schedule['autoApprovedBy'] ?? -1) <= 0 && $userId > 0) {
            $schedule['autoApprovedBy'] = $userId;
        }

        $data['data'] = $schedule;
        $trackingBuffer->setData($data);
        if (!is_null($categories)) {
            $trackingBuffer->setCategories($categories);
        }
        $this->trackingBufferRepository->save($trackingBuffer, true);
    }

    /**
     * The pending entry of a schedule, null for anything else - an execution,
     * or a schedule that already ran out or was ended.
     */
    public function findPending(int $id): ?TrackingBuffer
    {
        $trackingBuffer = $id > 0 ? $this->trackingBufferRepository->find($id) : null;

        if (
            !$trackingBuffer instanceof TrackingBuffer
            || $trackingBuffer->getKeyValue() !== HandleScheduledBookingsJob::$KEY
            || $trackingBuffer->getState() !== eTrackingBufferState::NEW
        ) {
            return null;
        }

        return $trackingBuffer;
    }

    /**
     * Whether the worker already takes the entry up, by the same rule as
     * HandleScheduledBookingsJob::willHandle().
     */
    public static function isDue(TrackingBuffer $trackingBuffer): bool
    {
        $waitUntil = $trackingBuffer->getData()['data']['waitUntil'] ?? null;

        return empty($waitUntil) || strtotime((string)$waitUntil) < time();
    }

    public function cancel(TrackingBuffer $trackingBuffer): void
    {
        $trackingBuffer
            ->setHandledAt(new \DateTime())
            ->setState(eTrackingBufferState::IGNORED);
        $this->trackingBufferRepository->save($trackingBuffer, true);
    }

    /**
     * The pending schedules, earliest next execution first.
     *
     * @param array<int, string> $paymentMethodNames id => name
     * @param int[] $ownPaymentMethodIds the accounts set up as one's own (FiBu settings)
     * @return list<array<string, mixed>>
     */
    public function getViews(array $paymentMethodNames, array $ownPaymentMethodIds = []): array
    {
        $views = array_map(
            fn(TrackingBuffer $trackingBuffer) => self::createView($trackingBuffer, $paymentMethodNames, $ownPaymentMethodIds),
            $this->trackingBufferRepository->findByAnyDataKeyValue([HandleScheduledBookingsJob::$KEY])
        );

        usort($views, fn(array $a, array $b) => strcmp($a['nextExecution'], $b['nextExecution']));

        return $views;
    }

    /**
     * @param array<int, string> $paymentMethodNames id => name
     * @param int[] $ownPaymentMethodIds the accounts set up as one's own (FiBu settings)
     * @return array<string, mixed>
     */
    public static function createView(TrackingBuffer $trackingBuffer, array $paymentMethodNames, array $ownPaymentMethodIds = []): array
    {
        $data = $trackingBuffer->getData()['data'] ?? [];
        // Stored entries come back from the database as arrays; one tracked in
        // this very request is still the DTO it was tracked with.
        $transaction = $data['transaction'] ?? [];
        if (!$transaction instanceof TransactionDTO) {
            $transaction = TransactionDTO::createFromArray(is_array($transaction) ? $transaction : []);
        }
        $repeatOptions = $data['repeatOptions'] ?? [];
        $from = null;
        $to = null;
        $amount = 0.0;

        /** @var TransactionPostingDTO $posting */
        foreach ($transaction->postings as $posting) {
            $amount = (float)$posting->amount;
            if ($posting->type === 'credit') {
                $from = (int)$posting->paymentMethod;
            } else {
                $to = (int)$posting->paymentMethod;
            }
        }

        $interval = (string)($repeatOptions['interval'] ?? '');
        $categories = $trackingBuffer->getCategories()->toArray();
        usort($categories, fn(Category $a, Category $b) => strcasecmp((string)$a->getName(), (string)$b->getName()));

        return [
            'id' => $trackingBuffer->getId(),
            'description' => $transaction->description,
            'amount' => $amount,
            'fromId' => $from,
            'toId' => $to,
            'from' => $paymentMethodNames[$from] ?? '?',
            'to' => $paymentMethodNames[$to] ?? '?',
            'intervalKey' => $interval,
            'interval' => $interval === '' ? '' : Recurrence::getLabel($interval),
            'monthlyFactor' => $interval === '' ? null : Recurrence::monthlyFactor($interval),
            'direction' => self::resolveDirection($from, $to, $ownPaymentMethodIds),
            'nextExecution' => (string)($data['waitUntil'] ?? ''),
            'lastExecution' => (string)($repeatOptions['lastExecution'] ?? ''),
            'autoApprove' => (int)($data['autoApprovedBy'] ?? -1) > 0,
            'categoryIds' => array_map(fn(Category $category) => (string)$category->getId(), $categories),
            'categories' => array_map(fn(Category $category) => (string)$category->getName(), $categories),
            // Being booked now, so it can not be changed - see update().
            'due' => self::isDue($trackingBuffer),
        ];
    }

    /**
     * Seen from one's own accounts: money that arrives on one of them from
     * elsewhere is incoming, money that leaves for elsewhere outgoing, between
     * two of them a transfer - and "unknown" when neither side is one's own.
     *
     * @param int[] $ownPaymentMethodIds
     */
    public static function resolveDirection(?int $from, ?int $to, array $ownPaymentMethodIds): string
    {
        $fromIsOwn = !is_null($from) && in_array($from, $ownPaymentMethodIds, true);
        $toIsOwn = !is_null($to) && in_array($to, $ownPaymentMethodIds, true);

        return match (true) {
            $fromIsOwn && $toIsOwn => 'transfer',
            $toIsOwn => 'incoming',
            $fromIsOwn => 'outgoing',
            default => 'unknown',
        };
    }

    /**
     * The repeat options of a schedule counted from $start, whose next
     * execution is its $occurrence-th one.
     *
     * The start date is what marks a schedule as following the calendar rules
     * of HandleScheduledBookingsJob - a planned one-off booking carries it too.
     *
     * $keptInterval is the interval the schedule already has: kept, it is
     * accepted even when the widget does not offer it.
     *
     * @param array{endType?: mixed, endDate?: mixed, endCount?: mixed} $end
     * @throws \InvalidArgumentException with a message meant for the user
     */
    public static function buildRepeatOptions(
        \DateTimeImmutable $start,
        string             $interval,
        array              $end,
        int                $occurrence = 0,
        string             $keptInterval = '',
    ): array
    {
        $repeatOptions = [
            'startDate' => $start->format('Y-m-d'),
            'occurrence' => $occurrence,
        ];

        if ($interval === '') {
            return $repeatOptions;
        }
        if ($interval !== $keptInterval && !Recurrence::isKnownInterval($interval)) {
            throw new \InvalidArgumentException('Unbekannte Wiederholung.');
        }

        $repeatOptions['interval'] = $interval;
        $nextExecution = Recurrence::occurrence($start, $interval, $occurrence);

        switch ((string)($end['endType'] ?? self::END_NEVER)) {
            case self::END_NEVER:
                break;
            case self::END_DATE:
                if (empty($end['endDate'])) {
                    throw new \InvalidArgumentException('Bitte ein Enddatum angeben.');
                }
                $lastExecution = self::parseDate((string)$end['endDate']);
                if (is_null($lastExecution)) {
                    throw new \InvalidArgumentException('Ungültiges Enddatum.');
                }
                if ($lastExecution < $nextExecution) {
                    throw new \InvalidArgumentException('Das Enddatum liegt vor der ersten Ausführung.');
                }
                $repeatOptions['lastExecution'] = $lastExecution->format('Y-m-d');
                break;
            case self::END_COUNT:
                $count = (int)($end['endCount'] ?? 0);
                if ($count < 1) {
                    throw new \InvalidArgumentException('Bitte mindestens eine Ausführung angeben.');
                }
                $repeatOptions['lastExecution'] = Recurrence::occurrence($start, $interval, $occurrence + $count - 1)->format('Y-m-d');
                break;
            default:
                // Rather no standing order than an endless one by mistake.
                throw new \InvalidArgumentException('Unbekanntes Ende des Dauerauftrags.');
        }

        return $repeatOptions;
    }

    /**
     * Only real Y-m-d dates - no "tomorrow", and no 31st of February that
     * quietly becomes the 3rd of March.
     */
    public static function parseDate(string $value): ?\DateTimeImmutable
    {
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value);

        return $date !== false && $date->format('Y-m-d') === $value ? $date : null;
    }
}
