<?php

namespace Cehlers88\AnalyticsFiBuBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

class PaymentMethod extends AbstractCustomObject
{
    public function getBankAccountId(): int
    {
        return $this->getAttribute('bank_account_id', -1);
    }

    public function setBankAccountId(int $bankAccountId): static
    {
        return $this->setAttribute('bank_account_id', $bankAccountId);
    }

    public function getDescription(): string
    {
        return $this->getAttribute('description', '');
    }

    public function setDescription(string $description): static
    {
        return $this->setAttribute('description', $description);
    }

    public function getStartAmount(): float
    {
        return $this->getAttribute('start_amount', 0);
    }

    public function setStartAmount(float $startAmount): static
    {
        return $this->setAttribute('start_amount', $startAmount);
    }

    public function getCurrentAmount(): float
    {
        return $this->getAttribute('current_amount', 0);
    }

    public function setCurrentAmount(float $currentAmount): static
    {
        return $this->setAttribute('current_amount', $currentAmount);
    }

    public function getOverdraftLimit(): float
    {
        return $this->getAttribute('overdraft_limit', 0);
    }

    public function setOverdraftLimit(float $overdraftLimit): static
    {
        return $this->setAttribute('overdraft_limit', $overdraftLimit);
    }

    public function isDebitor(): bool
    {
        return $this->getAttribute('is_debitor', true);
    }

    public function setIsDebitor(bool $isDebitor): static
    {
        return $this->setAttribute('is_debitor', $isDebitor);
    }

    public function isCreditor(): bool
    {
        return $this->getAttribute('is_creditor', true);
    }

    public function setIsCreditor(bool $isCreditor): static
    {
        return $this->setAttribute('is_creditor', $isCreditor);
    }

    public function getTileTemplate(): ?string
    {
        return 'customObject/tile/paymentMethod.html.twig';
    }

    /**
     * The figures of the tile. They are read leniently, since the attributes can
     * be edited as free text on /dashboard/customObjects and the typed getters
     * would fail on anything that is not a number.
     */
    public function getTileDetails(): array
    {
        $currentAmount = $this->getNumericAttribute('current_amount');
        // Some enter the limit as the lowest balance allowed (-500), others as its size (500).
        $overdraftLimit = abs($this->getNumericAttribute('overdraft_limit'));

        return [
            'currentAmount' => $currentAmount,
            'startAmount' => $this->getNumericAttribute('start_amount'),
            'overdraftLimit' => $overdraftLimit,
            'available' => $currentAmount + $overdraftLimit,
            'isDebitor' => $this->getFlagAttribute('is_debitor'),
            'isCreditor' => $this->getFlagAttribute('is_creditor'),
        ];
    }

    private function getNumericAttribute(string $name): float
    {
        $value = $this->getAttribute($name, 0);

        return is_numeric($value) ? (float)$value : 0.0;
    }

    /** A missing flag counts as set, as in isDebitor(); a stored false is an empty string. */
    private function getFlagAttribute(string $name): bool
    {
        return filter_var($this->getAttribute($name, true), FILTER_VALIDATE_BOOLEAN);
    }
}