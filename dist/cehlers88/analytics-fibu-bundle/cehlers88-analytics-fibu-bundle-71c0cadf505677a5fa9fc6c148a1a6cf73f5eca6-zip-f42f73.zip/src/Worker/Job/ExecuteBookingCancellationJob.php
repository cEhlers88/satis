<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsFiBuBundle\Worker\Job;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Cehlers88\AnalyticsFiBuBundle\Booking\BookingCancellationService;

/**
 * Carries out the cancellation orders (FIBU.cancel_booking) of asynchronous
 * cancellations, see BookingCancellationService.
 */
class ExecuteBookingCancellationJob extends AbstractWorkerJob
{
    public function __construct(
        private readonly BookingCancellationService $bookingCancellationService,
    )
    {
        $this->setType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION);
    }

    /**
     * @param TrackingBuffer $object
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        if (!$this->bookingCancellationService->executeOrder($object)) {
            $this->logWarning('booking cancellation #' . $object->getId() . ' failed: ' . ($object->getHandlerData()['error'] ?? ''));
        }

        return parent::workOnObject($object);
    }

    /**
     * @param TrackingBuffer $workingObject
     */
    public function willHandle(object $workingObject): bool
    {
        if ($workingObject->getKeyValue() !== BookingCancellationService::KEY) {
            return false;
        }

        return (int)($workingObject->getHandlerData()['approvedBy'] ?? 0) > 0;
    }
}
