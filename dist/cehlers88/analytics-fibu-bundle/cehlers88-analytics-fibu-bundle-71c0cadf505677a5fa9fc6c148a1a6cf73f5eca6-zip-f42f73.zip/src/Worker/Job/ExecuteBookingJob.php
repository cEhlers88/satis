<?php

namespace Cehlers88\AnalyticsFiBuBundle\Worker\Job;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Cehlers88\AnalyticsFiBuBundle\Booking\BookingExecutor;

class ExecuteBookingJob extends AbstractWorkerJob
{
    public static string $KEY = 'FIBU.booking';

    public function __construct(
        private BookingExecutor $bookingExecutor,
    )
    {
        $this->setType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION);
    }

    /**
     * @param TrackingBuffer $object
     * @return AbstractWorkerJob
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        foreach ($this->bookingExecutor->execute($object) as $paymentMethodId) {
            $this->logWarning('payment method not found: ' . $paymentMethodId);
        }

        return parent::workOnObject($object);
    }

    /**
     * @param TrackingBuffer $workingObject
     * @return bool
     */
    public function willHandle(object $workingObject): bool
    {
        if ($workingObject->getKeyValue() !== self::$KEY) {
            return false;
        }

        $handlerData = $workingObject->getHandlerData();
        if (!isset($handlerData['approvedBy']) || $handlerData['approvedBy'] <= 0) {
            return false;
        }

        return true;
    }
}
