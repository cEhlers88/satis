<?php

namespace Cehlers88\AnalyticsFiBuBundle\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\CustomEntity;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\CustomObjectAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\BookingTemplate;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\PaymentMethod;

/**
 * A template only stores the ids of its payment methods. Its tile names them,
 * so both go along as child objects, reachable through the child map as
 * "from_payment_method" and "to_payment_method".
 */
class BookingTemplateAssembler extends CustomObjectAssembler
{
    private const PAYMENT_METHOD_ATTRIBUTES = [
        'from_payment_method_id' => 'from_payment_method',
        'to_payment_method_id' => 'to_payment_method',
    ];

    protected function enrichView(EntityInterface|AbstractCustomObject $entity, CustomObjectView $view): CustomObjectView
    {
        $paymentMethodAssembler = $this->assemblerProvider->getAssemblerForClass(CustomEntity::class);

        foreach (self::PAYMENT_METHOD_ATTRIBUTES as $attributeName => $childName) {
            $paymentMethodId = (int)($view->attribute->{$attributeName} ?? 0);
            if ($paymentMethodId <= 0) {
                continue;
            }

            // A payment method deleted since the template was saved simply stays unnamed.
            $paymentMethod = $this->customObjectProvider->getCustomObjectById($paymentMethodId);
            if (!$paymentMethod instanceof PaymentMethod) {
                continue;
            }

            $view->childMap->{$childName} = count($view->childObjects);
            $view->childObjects[] = $paymentMethodAssembler->one($paymentMethod);
        }

        return $view;
    }

    public function canHandle(string $className): bool
    {
        return $className === BookingTemplate::class;
    }
}
