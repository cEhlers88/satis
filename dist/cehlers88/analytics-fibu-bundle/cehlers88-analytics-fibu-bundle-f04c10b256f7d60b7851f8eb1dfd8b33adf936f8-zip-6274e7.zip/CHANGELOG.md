# Changelog

## [0.1.9](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.8...v0.1.9) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([9de44d8](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/9de44d895ce369b31273c6a250955991c7a87258))

## [0.1.8](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.7...v0.1.8) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([4c1bac0](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4c1bac060d82b209063c7bfb7059cd490aa8c26a))

## [0.1.7](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.6...v0.1.7) (2026-03-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#11](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/11)) ([7197f0d](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/7197f0dcd45469850118fe060e6be319d9d2f9ef))
* update branch alias and analytics-core dependency version ([0e4446a](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/0e4446a464587ff812bb763383ab524dde66f8b7))

## [0.1.6](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.5...v0.1.6) (2026-01-22)


### Miscellaneous Chores

* Update dependency versions for analytics-core ([874c5d6](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/874c5d6eef4f1d72192dda8867b46ef87d490528))

## [0.1.5](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.4...v0.1.5) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.2.1 ([#6](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/6)) ([672fe02](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/672fe02b91b732e35f8b64e53c675feff64ba8ec))

## [0.1.4](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.3...v0.1.4) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.2.0@dev ([#7](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/7)) ([4c5c201](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4c5c2014b8f77d1ca0c8f51a3fc562bb63476d1c))

## [0.1.3](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.2...v0.1.3) (2026-01-21)


### Miscellaneous Chores

* add GitHub Actions workflow to trigger Satis rebuild on release ([fc3a463](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fc3a463b9d9d3b65c4d354b01b74571c1909c83f))
* **deps:** update dependency cehlers88/analytics-core to v0.1.5 ([#4](https://github.com/cEhlers88/AnalyticsFiBuBundle/issues/4)) ([a2a6e28](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/a2a6e28bf45edcdfcee62cae12188f670b92d67f))

## [0.1.2](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([4dd5771](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/4dd5771ab5558e7f40a758b64f3bec5f9264796f))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([c4a2680](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/c4a26806e08e0c32364720948c77d05572420809))

## [0.1.1](https://github.com/cEhlers88/AnalyticsFiBuBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([fd355ff](https://github.com/cEhlers88/AnalyticsFiBuBundle/commit/fd355ffd721a572da177c803d2d5953464d71f55))
