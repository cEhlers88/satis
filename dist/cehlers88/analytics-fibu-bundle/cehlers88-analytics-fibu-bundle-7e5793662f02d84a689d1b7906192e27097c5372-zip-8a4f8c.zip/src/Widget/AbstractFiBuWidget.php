<?php

namespace Cehlers88\AnalyticsFiBuBundle\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Widget\AbstractWidget;
use Cehlers88\AnalyticsFiBuBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\PaymentMethod;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionDTO;
use Cehlers88\AnalyticsFiBuBundle\DTO\TransactionPostingDTO;
use Cehlers88\AnalyticsFiBuBundle\ENUM\EPermission;

/**
 * What the booking widget and the standing-order widget both need to turn
 * submitted values into a valid transaction.
 */
abstract class AbstractFiBuWidget extends AbstractWidget
{
    public function __construct(
        protected ConfigurationProvider $configurationProvider,
        protected CustomObjectProvider  $customObjectProvider,
        protected ApplicationRepository $applicationRepository,
    )
    {
    }

    public function getRequiredRoles(): array
    {
        return [
            'ROLE_USER',
            EPermission::ACCESS_FIBU->value
        ];
    }

    /**
     * Money leaves the "from" account (credit) and arrives on the "to" account
     * (debit), see ExecuteBookingJob.
     */
    protected function createTransaction(float $amount, int $from, int $to, string $description): TransactionDTO
    {
        return TransactionDTO::createFromArray([
            'description' => $description,
            'postings' => [
                TransactionPostingDTO::createFromArray([
                    'amount' => $amount,
                    'paymentMethod' => $to,
                    'type' => 'debit',
                ]),
                TransactionPostingDTO::createFromArray([
                    'amount' => $amount,
                    'paymentMethod' => $from,
                    'type' => 'credit',
                ])
            ],
        ]);
    }

    /**
     * An entry of the account suggestions.
     *
     * @return array{value: string, label: string}
     */
    protected function createPaymentMethodOption(PaymentMethod $paymentMethod): array
    {
        return ['value' => (string)$paymentMethod->getId(), 'label' => $paymentMethod->getName()];
    }

    /**
     * @return PaymentMethod[]
     */
    protected function getPaymentMethods(): array
    {
        $paymentMethods = $this->customObjectProvider->getCustomEntitiesByClassName(PaymentMethod::class);
        usort($paymentMethods, fn(PaymentMethod $a, PaymentMethod $b) => strcasecmp($a->getName(), $b->getName()));

        return $paymentMethods;
    }

    /**
     * @return array<int, string> id => name
     */
    protected function getPaymentMethodNames(): array
    {
        $names = [];
        foreach ($this->getPaymentMethods() as $paymentMethod) {
            $names[$paymentMethod->getId()] = $paymentMethod->getName();
        }

        return $names;
    }

    protected function getDefaultFromPaymentMethod(): mixed
    {
        return $this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, 'defaultPaymentMethod');
    }

    protected function resolveApplicationId(array $data): int
    {
        $applicationId = (int)($data['applicationId'] ?? -1);

        if ($applicationId <= 0) {
            $applicationId = (int)$this->configurationProvider->getValue(
                GeneralConfigurationGroup::KEY,
                'defaultApplication'
            );
        }

        return $applicationId;
    }

    /**
     * The application the tracking buffer entries go to. Without one they can
     * not be created at all - better say so than fail with a server error.
     */
    protected function validateApplication(int $applicationId): ?WidgetSubmitResultDTO
    {
        if ($applicationId <= 0) {
            return WidgetSubmitResultDTO::createError(400, 'Keine Anwendung für Buchungen eingestellt (FiBu-Einstellungen: Default application).');
        }
        if (is_null($this->applicationRepository->find($applicationId))) {
            return WidgetSubmitResultDTO::createError(400, 'Unbekannte Anwendung: ' . $applicationId);
        }

        return null;
    }

    /**
     * Both accounts must be payment methods: ExecuteBookingJob skips one it can
     * not find and would book only the other half of the transaction.
     */
    protected function validateAccounts(int $from, int $to): ?WidgetSubmitResultDTO
    {
        if ($from <= 0 || $to <= 0) {
            return WidgetSubmitResultDTO::createError(400, 'Bitte Ursprungs- und Zielkonto wählen.');
        }
        if ($from === $to) {
            return WidgetSubmitResultDTO::createError(400, 'Ursprungs- und Zielkonto müssen sich unterscheiden.');
        }

        $paymentMethodIds = array_map(fn(PaymentMethod $paymentMethod) => $paymentMethod->getId(), $this->getPaymentMethods());
        if (!in_array($from, $paymentMethodIds, true) || !in_array($to, $paymentMethodIds, true)) {
            return WidgetSubmitResultDTO::createError(400, 'Unbekanntes Konto.');
        }

        return null;
    }

    /**
     * Accepts "1234.5", "1234,50" and "1.234,50" alike.
     */
    protected function parseAmount(mixed $value): ?float
    {
        $value = str_replace([' ', '€'], '', trim((string)$value));
        if (str_contains($value, ',')) {
            $value = str_replace(['.', ','], ['', '.'], $value);
        }

        if (!is_numeric($value) || !is_finite((float)$value)) {
            return null;
        }

        return round((float)$value, 2);
    }
}
