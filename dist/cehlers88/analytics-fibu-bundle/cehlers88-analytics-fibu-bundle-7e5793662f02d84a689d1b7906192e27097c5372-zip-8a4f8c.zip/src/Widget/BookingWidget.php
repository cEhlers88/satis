<?php

namespace Cehlers88\AnalyticsFiBuBundle\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Recorder\TrackingRecorder;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsFiBuBundle\AnalyticsFiBuBundle;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\BookingTemplate;
use Cehlers88\AnalyticsFiBuBundle\CustomObject\PaymentMethod;
use Cehlers88\AnalyticsFiBuBundle\Schedule\Recurrence;
use Cehlers88\AnalyticsFiBuBundle\Schedule\ScheduledBookingService;
use Cehlers88\AnalyticsFiBuBundle\Worker\Job\ExecuteBookingJob;

/**
 * Books right away, or sets up a planned booking or standing order. Those are
 * listed, changed and ended in the ScheduledBookingsWidget.
 */
class BookingWidget extends AbstractFiBuWidget
{
    private const ACTION_BOOK = 'book';
    private const ACTION_SAVE_TEMPLATE = 'saveTemplate';
    private const ACTION_CREATE_PAYMENT_METHOD = 'createPaymentMethod';

    public function __construct(
        private TrackingRecorder        $trackingRecorder,
        private ScheduledBookingService $scheduledBookingService,
        ConfigurationProvider           $configurationProvider,
        CustomObjectProvider            $customObjectProvider,
        ApplicationRepository           $applicationRepository,
    )
    {
        parent::__construct($configurationProvider, $customObjectProvider, $applicationRepository);
    }

    public function getName(): string
    {
        return AnalyticsFiBuBundle::getBundleName() . '.booking';
    }

    public function getTemplateName(): string
    {
        return 'booking';
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '28px', 'boxes' => [.3, .3, .3]],
            ['height' => '48px', 'boxes' => [1]],
            ['height' => '40px', 'boxes' => [.45, .1, .45]],
            ['height' => '40px', 'boxes' => [1]],
            ['height' => '40px', 'boxes' => [.5, .5]],
            ['height' => '36px', 'boxes' => [.6, .4]],
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $paymentMethods = $this->getPaymentMethods();

        return [
            ...$properties,
            'now' => new \DateTime(),
            'paymentMethods' => $paymentMethods,
            'defaultFromPaymentMethod' => $this->getDefaultFromPaymentMethod(),
            'intervals' => Recurrence::INTERVALS,
            'bookingTemplates' => array_map(
                fn(BookingTemplate $template) => $this->createTemplateView($template),
                $this->getBookingTemplates()
            ),
        ];
    }

    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        return match ($data['action'] ?? self::ACTION_BOOK) {
            self::ACTION_SAVE_TEMPLATE => $this->saveTemplate($data),
            self::ACTION_CREATE_PAYMENT_METHOD => $this->createPaymentMethod($data),
            default => $this->book($data, $user),
        };
    }

    private function book(array $data, ?User $user): WidgetSubmitResultDTO
    {
        // Callers of the former widget send "creditor" (the paying account) and
        // "debitor" (the receiving one) and expect the booking to be made at once,
        // whatever executionDate they pass - they keep getting exactly that.
        $isLegacyRequest = !isset($data['from'], $data['to']) && (isset($data['creditor']) || isset($data['debitor']));

        $amount = $this->parseAmount($data['amount'] ?? '');
        $from = (int)($data[$isLegacyRequest ? 'creditor' : 'from'] ?? 0);
        $to = (int)($data[$isLegacyRequest ? 'debitor' : 'to'] ?? 0);
        $description = trim((string)($data['description'] ?? ''));
        $interval = $isLegacyRequest ? '' : (string)($data['interval'] ?? '');

        // The former widget allowed negative amounts (a booking the other way round).
        if ($amount === null || ($isLegacyRequest ? $amount == 0 : $amount <= 0)) {
            return WidgetSubmitResultDTO::createError(400, 'Bitte einen Betrag größer 0 eingeben.');
        }
        if (!is_null($accountError = $this->validateAccounts($from, $to))) {
            return $accountError;
        }
        if ($interval !== '' && !Recurrence::isKnownInterval($interval)) {
            return WidgetSubmitResultDTO::createError(400, 'Unbekannte Wiederholung.');
        }

        $executionDate = ($isLegacyRequest || empty($data['executionDate']))
            ? new \DateTimeImmutable('today')
            : ScheduledBookingService::parseDate((string)$data['executionDate']);
        if (is_null($executionDate)) {
            return WidgetSubmitResultDTO::createError(400, 'Ungültiges Ausführungsdatum.');
        }

        $applicationId = $this->resolveApplicationId($data);
        if (!is_null($applicationError = $this->validateApplication($applicationId))) {
            return $applicationError;
        }
        $approvedBy = $user ? $user->getId() : -1;
        $transaction = $this->createTransaction($amount, $from, $to, $description);

        $today = new \DateTimeImmutable('today');
        if ($isLegacyRequest || ($interval === '' && $executionDate <= $today)) {
            $this->trackingRecorder->track(
                $applicationId,
                [
                    'key' => ExecuteBookingJob::$KEY,
                    'data' => ['transaction' => $transaction],
                ],
                true,
                ['approvedBy' => $approvedBy]
            );

            return WidgetSubmitResultDTO::createSuccess('Buchung erfasst.', [
                'applicationId' => $applicationId,
                // What the former widget answered with, for callers relying on it.
                'data' => $data,
                'isToday' => $executionDate->format('Y-m-d') === $today->format('Y-m-d'),
                'scheduled' => false,
            ], 200);
        }

        try {
            // A planned booking was approved by submitting it; the executions of
            // a standing order only when its creator asked for that.
            $this->scheduledBookingService->create(
                $applicationId,
                $transaction,
                $executionDate,
                $interval,
                $data,
                $interval === '' || filter_var($data['autoApprove'] ?? false, FILTER_VALIDATE_BOOLEAN),
                $approvedBy
            );
        } catch (\InvalidArgumentException $exception) {
            return WidgetSubmitResultDTO::createError(400, $exception->getMessage());
        }

        return WidgetSubmitResultDTO::createSuccess(
            $interval === '' ? 'Buchung geplant.' : 'Dauerauftrag angelegt.',
            [
                'applicationId' => $applicationId,
                'scheduled' => true,
            ],
            200
        );
    }

    private function saveTemplate(array $data): WidgetSubmitResultDTO
    {
        $name = trim((string)($data['name'] ?? ''));
        if ($name === '') {
            return WidgetSubmitResultDTO::createError(400, 'Bitte einen Namen für die Vorlage angeben.');
        }
        if (!is_null($accountError = $this->validateAccounts((int)($data['from'] ?? 0), (int)($data['to'] ?? 0)))) {
            return $accountError;
        }

        // Saving under an existing name updates that template, which is how a
        // template is corrected from the widget.
        $template = $this->customObjectProvider->getCustomEntityByClassNameAndName(BookingTemplate::class, $name);
        if (!$template instanceof BookingTemplate) {
            /** @var BookingTemplate $template */
            $template = $this->customObjectProvider->createNewCustomEntity(BookingTemplate::class);
            $template->setName($name);
        }

        $template
            ->setFromPaymentMethodId((int)($data['from'] ?? -1))
            ->setToPaymentMethodId((int)($data['to'] ?? -1))
            ->setDescription(trim((string)($data['description'] ?? '')))
            ->setAmount(max(0, $this->parseAmount($data['amount'] ?? '') ?? 0));

        $this->customObjectProvider->save($template);

        $saved = $this->customObjectProvider->getCustomEntityByClassNameAndName(BookingTemplate::class, $name);

        return WidgetSubmitResultDTO::createSuccess('Vorlage gespeichert.', [
            'template' => $saved instanceof BookingTemplate ? $this->createTemplateView($saved) : null,
        ], 200);
    }

    /**
     * The quick creation of an account typed into the widget that does not
     * exist yet. Asking twice for the same name (case-insensitive) answers with
     * the existing account instead of creating a second one.
     */
    private function createPaymentMethod(array $data): WidgetSubmitResultDTO
    {
        $name = trim((string)($data['name'] ?? ''));
        if ($name === '') {
            return WidgetSubmitResultDTO::createError(400, 'Bitte einen Namen für den Zahlungsweg angeben.');
        }
        if (mb_strlen($name) > 255) {
            return WidgetSubmitResultDTO::createError(400, 'Der Name ist zu lang (höchstens 255 Zeichen).');
        }

        $startAmount = 0.0;
        if (trim((string)($data['startAmount'] ?? '')) !== '') {
            $startAmount = $this->parseAmount($data['startAmount']);
            if (is_null($startAmount)) {
                return WidgetSubmitResultDTO::createError(400, 'Ungültiger Startbetrag.');
            }
        }

        foreach ($this->getPaymentMethods() as $paymentMethod) {
            if (mb_strtolower($paymentMethod->getName()) === mb_strtolower($name)) {
                return WidgetSubmitResultDTO::createSuccess('Zahlungsweg existiert bereits.', [
                    'paymentMethod' => $this->createPaymentMethodOption($paymentMethod),
                ], 200);
            }
        }

        /** @var PaymentMethod $paymentMethod */
        $paymentMethod = $this->customObjectProvider->createNewCustomEntity(PaymentMethod::class);
        $paymentMethod->setName($name);
        $paymentMethod
            ->setDescription(trim((string)($data['description'] ?? '')))
            ->setStartAmount($startAmount)
            // A new account has seen no booking yet, so it holds what it started with.
            ->setCurrentAmount($startAmount)
            // Created on the fly, it may be needed on either side of a booking.
            ->setIsDebitor(true)
            ->setIsCreditor(true);

        $this->customObjectProvider->save($paymentMethod);

        // Read back like saveTemplate does: the id is only known once stored.
        $saved = $this->customObjectProvider->getCustomEntityByClassNameAndName(PaymentMethod::class, $name);
        if (!$saved instanceof PaymentMethod || (int)$saved->getId() <= 0) {
            return WidgetSubmitResultDTO::createError(500, 'Der Zahlungsweg konnte nicht angelegt werden.');
        }

        return WidgetSubmitResultDTO::createSuccess('Zahlungsweg „' . $name . '“ angelegt.', [
            'paymentMethod' => $this->createPaymentMethodOption($saved),
        ], 200);
    }

    /**
     * @return BookingTemplate[]
     */
    private function getBookingTemplates(): array
    {
        $templates = $this->customObjectProvider->getCustomEntitiesByClassName(BookingTemplate::class);
        usort($templates, fn(BookingTemplate $a, BookingTemplate $b) => strcasecmp($a->getName(), $b->getName()));

        return $templates;
    }

    private function createTemplateView(BookingTemplate $template): array
    {
        return [
            'id' => $template->getId(),
            'name' => $template->getName(),
            'from' => $template->getFromPaymentMethodId(),
            'to' => $template->getToPaymentMethodId(),
            'description' => $template->getDescription(),
            'amount' => $template->getAmount(),
        ];
    }
}
