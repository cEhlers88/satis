# AnalyticsFiBuBundle

A Symfony bundle that provides financial accounting (Finanzbuchhaltung/FiBu) functionality for the Analytics platform. It enables management of bank accounts and payment methods, creation of financial bookings, and tracking of payment flows between creditors and debtors.

## Table of Contents

- [Requirements](#requirements)
- [Installation](#installation)
- [Bundle Registration](#bundle-registration)
- [Database Setup](#database-setup)
- [Permissions](#permissions)
- [Entities](#entities)
  - [BankAccount](#bankaccount)
  - [PaymentMethod](#paymentmethod)
- [Widgets](#widgets)
  - [BookingWidget](#bookingwidget)
  - [ScheduledBookingsWidget](#scheduledbookingswidget)
  - [BookingTemplate](#bookingtemplate)
- [Macros](#macros)
  - [BookMacro](#bookmacro)
- [Service Endpoints](#service-endpoints)
  - [BookingServiceEndpointRunner](#bookingserviceendpointrunner)
- [Workers](#workers)
  - [BookingWorker](#bookingworker)
- [Configuration](#configuration)
- [Menu Structure](#menu-structure)
- [Changelog](#changelog)

---

## Requirements

- PHP 8.1+
- Symfony (compatible framework version)
- Doctrine ORM
- [`cehlers88/analytics-core`](https://github.com/cEhlers88/AnalyticsCoreBundle) `^0.3`

---

## Installation

This package is distributed via a private [Satis](https://composer.github.io/satis/) repository. Add the repository to your `composer.json` before requiring the package:

```json
{
    "repositories": [
        {
            "type": "composer",
            "url": "https://cehlers88.github.io/satis"
        }
    ]
}
```

Then install the bundle via Composer:

```bash
composer require cehlers88/analytics-fibu-bundle
```

---

## Bundle Registration

Register the bundle in your Symfony application's `config/bundles.php`:

```php
return [
    // ...
    Cehlers88\AnalyticsFiBuBundle\AnalyticsFiBuBundle::class => ['all' => true],
];
```

---

## Database Setup

The bundle adds two database tables. After installation, run the Doctrine migrations or schema update:

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

Or, for development environments:

```bash
php bin/console doctrine:schema:update --force
```

The following tables will be created:

| Table | Description |
|-------|-------------|
| `fibu_bank_account` | Stores bank account details (IBAN, holder name) |
| `fibu_payment_method` | Stores payment methods with creditor/debitor flags and optional bank account link |

---

## Permissions

The bundle defines the following permissions via the `EPermission` enum:

| Permission | Value | Description |
|---|---|---|
| `ACCESS_FIBU` | `ACCESS_FIBU` | Grants access to the Finanzbuchhaltung (FiBu) menu section |
| `READ_FIBU_PAYMENT_METHODS` | `READ_FIBU_PAYMENT_METHODS` | Grants access to the payment methods list view |

These permissions are registered automatically with the Analytics platform when the bundle is loaded.

---

## Entities

### BankAccount

**Table:** `fibu_bank_account`

Represents a bank account that can be associated with a payment method.

| Field | Type | Description |
|-------|------|-------------|
| `id` | `int` | Auto-generated primary key |
| `iban` | `string(24)` | The International Bank Account Number |
| `holderName` | `string(255)` | Name of the account holder |

**Example usage:**

```php
use Cehlers88\AnalyticsFiBuBundle\Entity\BankAccount;

$account = new BankAccount();
$account->setIban('DE89370400440532013000');
$account->setHolderName('Max Mustermann');

$entityManager->persist($account);
$entityManager->flush();
```

---

### PaymentMethod

**Table:** `fibu_payment_method`

Represents a payment method that can act as a creditor, a debitor, or both. An optional bank account can be linked.

| Field | Type | Description |
|-------|------|-------------|
| `id` | `int` | Auto-generated primary key |
| `name` | `string(255)` | Display name of the payment method |
| `description` | `string(255)\|null` | Optional description |
| `isCreditor` | `bool` | Whether this method can act as a creditor (receiving party) |
| `isDebitor` | `bool` | Whether this method can act as a debitor (paying party) |
| `bankAccount` | `BankAccount\|null` | Optionally linked bank account |

**Example usage:**

```php
use Cehlers88\AnalyticsFiBuBundle\Entity\PaymentMethod;

$method = new PaymentMethod();
$method->setName('Corporate Checking Account');
$method->setDescription('Main business account');
$method->setIsDebitor(true);
$method->setIsCreditor(false);
$method->setBankAccount($bankAccount); // optional

$entityManager->persist($method);
$entityManager->flush();
```

---

## Widgets

### BookingWidget

**Widget name:** `AnalyticsFiBuBundle.booking`  
**Required roles:** `ROLE_USER`, `ACCESS_FIBU`  
**Template:** `templates/widget/booking.html.twig`

Books an amount from one payment method to another - right away, on a later date, or
repeatedly as a standing order (Dauerauftrag).

- **Templates** (`BookingTemplate`, see below) appear as chips at the top. Picking one fills
  in the accounts, the description and, if the template has one, the amount; the cursor
  then lands in the amount field. *Als Vorlage speichern* saves the current entries as a
  template (saving under an existing name updates that template).
- **Amount** accepts `12.5`, `12,50` and `1.234,50`.
- **Accounts** are picked with `<suggest-input>`. A typed name that matches an account
  (ignoring case) selects it; any other name opens a dialog to create that payment method
  on the spot (name, optional start amount and description; it can be used on both sides
  of a booking). Cancelled, the dialog is asked again only when booking.
- **Ausführung am / Wiederholung**: a booking for today (or earlier) is booked at once
  (`FIBU.booking`); a later date or a repeat interval creates a `FIBU.scheduled_booking`.
  Intervals: weekly, every 2 weeks, monthly, quarterly, half-yearly, yearly
  (`Schedule\Recurrence::INTERVALS`). A standing order ends never, on a date, or after a
  number of executions. With *Automatisch buchen* its executions are booked without
  approval; otherwise each one waits in the tracking buffer for approval.
- A summary line says what is going to happen before anything is submitted.
- What it plans is listed, changed and ended in the
  [ScheduledBookingsWidget](#scheduledbookingswidget); when both are on one dashboard, the
  booking widget tells the other one (`fibu:schedules-changed` on `document`) to reload.
- Questions use the application's own dialogs (`window.application.confirm()`, the
  `app-dialog` of the host app), never the browser's `alert`/`confirm`/`prompt`.

Everything is validated again on the server. `submit()` takes an `action`:

| Action | Fields |
|--------|--------|
| `book` (default) | `amount`, `from`, `to`, `description`, `executionDate`, `interval`, `endType` (`never`/`date`/`count`), `endDate`, `endCount`, `autoApprove` |
| `saveTemplate` | `name`, `from`, `to`, `description`, `amount` |
| `createPaymentMethod` | `name`, `startAmount`, `description`; answers with `paymentMethod: {value, label}` (an existing one of the same name instead of a duplicate) |

Requests in the former format (`creditor` = paying account, `debitor` = receiving
account, no `from`/`to`) are still accepted and booked at once, as before.

### ScheduledBookingsWidget

**Widget name:** `AnalyticsFiBuBundle.scheduledBookings`  
**Required roles:** `ROLE_USER`, `ACCESS_FIBU`  
**Template:** `templates/widget/scheduledBookings.html.twig`

The planned bookings and standing orders (*Geplant & Daueraufträge*): every pending
`FIBU.scheduled_booking` with its accounts, amount, interval, next and last execution.

- *Bearbeiten* opens the entry in a form: amount, accounts, description, next execution,
  interval, end (never / on a date / after a number of executions counted from the next
  one) and *Automatisch buchen*. Saving rewrites the pending entry; its calendar is kept
  while the next execution and the interval stay the same, so a standing order on the 31st
  keeps returning to the 31st.
- *Neuer Dauerauftrag* adds one with the same form (a one-off date makes it a planned
  booking).
- *Beenden* stops one after a confirmation (the pending entry is set to `IGNORED`).

The logic lives in `Schedule\ScheduledBookingService`, which the booking widget uses to
create schedules as well. `submit()` takes an `action`:

| Action | Fields |
|--------|--------|
| `list` (default) | – ; answers with `schedules` |
| `create` | `amount`, `from`, `to`, `description`, `executionDate`, `interval`, `endType`, `endDate`, `endCount`, `autoApprove` |
| `update` | `id` of the pending `FIBU.scheduled_booking` and the fields of `create` |
| `cancel` | `id` of the pending `FIBU.scheduled_booking` |

`create`, `update` and `cancel` answer with the new `schedules` list.

### BookingTemplate

A custom object (`CustomObject\BookingTemplate`) with the attributes
`from_payment_method_id`, `to_payment_method_id`, `description` and `amount` (0 = enter
the amount each time). Created from the widget or the custom-object management.

---

## Macros

### BookMacro

**Macro name:** `book`  
**Source:** `FiBuBundle`

The `BookMacro` is used to programmatically book a financial transaction. It can be configured with the following properties:

| Property | Type | Description |
|----------|------|-------------|
| `paymentMethod` | `int` | ID of the payment method to use for the booking |
| `counterPaymentMethod` | `int` | ID of the counter-party payment method |
| `value` | — | The monetary value to book |
| `description` | — | Description for the booking entry |
| `data` | — | Additional data for the booking |

**Example configuration (within Analytics macro pipeline):**

```json
{
    "macro": "book",
    "properties": {
        "paymentMethod": 1
    }
}
```

---

## Service Endpoints

### BookingServiceEndpointRunner

**Endpoint:** `fibu_booking`  
**Bundle:** `AnalyticsFiBuBundle`

This endpoint handles incoming booking requests from the Analytics platform. It requires an authenticated user session.

**Request:** Any HTTP request to the `fibu_booking` endpoint.

**Responses:**

| Scenario | Response |
|----------|----------|
| User not authenticated | Error: `"user not logged in"` |
| User authenticated | Success with user ID and current tracking buffer count |

**Success response payload:**

```json
{
    "user": 42,
    "count": 5
}
```

---

## Workers

### BookingWorker

Processes the booking entries of the tracking buffer with two jobs:

- `HandleScheduledBookingsJob` picks up a due `FIBU.scheduled_booking`.
  - Schedules with `repeatOptions.startDate` (created by the booking widget): the due
    execution becomes a `FIBU.booking` (approved in advance when the schedule carries
    `autoApprovedBy`, otherwise waiting for approval), and a standing order gets the
    pending entry of its next execution until `lastExecution`. Dates are counted from
    `startDate`, so a standing order on the 31st runs on the last day of shorter months,
    and executing one early does not shift the others.
  - All other scheduled bookings (tracking API, commands, existing data) are handled as
    they always were: while `lastExecution` lies in the future, an execution waiting for
    approval and the next entry (`waitUntil` + `interval`) are created.
- `ExecuteBookingJob` books an approved `FIBU.booking` onto the payment methods.

---

## Configuration

The bundle provides a configuration group (`fibuBundle.general`) accessible in the Analytics administration interface under **Allgemeine Finanzbuchhaltungseinstellungen**.

| Key | Type | Description |
|-----|------|-------------|
| `defaultPaymentMethod` | `select` | The default payment method pre-selected in booking forms; options are populated from all available `PaymentMethod` entities |

---

## Menu Structure

When a user has the required permissions, the following navigation items are added to the Analytics menu:

```
Finanzbuchhaltung                          [requires: ACCESS_FIBU]
└── Zahlungswege                           [requires: READ_FIBU_PAYMENT_METHODS]
    (route: analytics_fibu_payment_methods)
```

---

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a full history of changes.

---

## License

This bundle is proprietary software. See [LICENSE](LICENSE) for details.

© 2024 Christoph Ehlers
