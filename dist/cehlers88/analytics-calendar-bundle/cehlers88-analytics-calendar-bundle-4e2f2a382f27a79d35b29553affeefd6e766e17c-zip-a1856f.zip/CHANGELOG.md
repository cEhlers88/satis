# Changelog

## [1.1.0](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.13...v1.1.0) (2026-04-26)


### Features

* expose JS assets with webpack-encore integration guide ([#40](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/40)) ([72e8017](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/72e80177fd373635784e6f8e4da3fe0d4e8c9c7f))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.20.0 ([#38](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/38)) ([e8471b2](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/e8471b2654d68c732f1603981eccd4a3bf6a8636))
* **deps:** update googleapis/release-please-action action to v5 ([#42](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/42)) ([af7f129](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/af7f129846dddff7ac871c0b3128b1cb3de98bff))

## [1.0.13](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.12...v1.0.13) (2026-04-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.16.1 ([#35](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/35)) ([ee267ba](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/ee267ba2820d5e3ea15df44070efb31c0f1c6dcc))
* **deps:** update dependency cehlers88/analytics-core to v1.17.0 ([#37](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/37)) ([e4fb320](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/e4fb320e42714db3770d0cd4ea40e1ada0a4e568))
* Refactor AnalyticsCalendarBundle to follow PSR-12 coding standards and update AbstractBundlePlugin reference ([7c02561](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/7c025616e728318da1c380710fba29f7beade9a4))

## [1.0.12](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.11...v1.0.12) (2026-04-13)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.15.0 ([#32](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/32)) ([c0d69aa](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/c0d69aadafe512227d440005d0c24c910437e8e4))
* **deps:** update dependency cehlers88/analytics-core to v1.16.0 ([#34](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/34)) ([7320775](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/73207759e968fa0ef9a44b8f63eb95257fd1aaed))

## [1.0.11](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.10...v1.0.11) (2026-03-29)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.3.13 ([#28](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/28)) ([dc56450](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/dc564507d16e81516deb961b2c3e878312d9f309))
* **deps:** update dependency cehlers88/analytics-core to v1.4.1 ([#30](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/30)) ([d07556a](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/d07556ad3b56118f513e711df4523c016aaabc32))
* **deps:** update dependency cehlers88/analytics-core to v1.6.0 ([#31](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/31)) ([639fe54](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/639fe54f3a85acb9457cadc30fe7a96304fbaa15))

## [1.0.10](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.9...v1.0.10) (2026-03-24)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.3.6 ([#26](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/26)) ([b56fc6f](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/b56fc6f5df453b7b79306194cfd83b791efd2967))
* Upgraded the analytics-core package to v1.3.7 to include the latest changes and improvements. Updated the associated reference, distribution URL, and checksum to match the new version. ([56f3bf6](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/56f3bf690ca45d216705a576df8a1ececc0fcce7))

## [1.0.9](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.8...v1.0.9) (2026-03-23)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.1.3 ([#23](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/23)) ([e129075](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/e129075318b37559a7c8cc81bc9b3193775fbee8))
* **deps:** update dependency cehlers88/analytics-core to v1.3.5 ([#25](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/25)) ([a9f83e7](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/a9f83e7af6478e76afe0f21c4d28cf3aaf5b1338))

## [1.0.8](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.7...v1.0.8) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([838e7bb](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/838e7bbe8ebbc3177beddf524e5dfc753b1cc35f))

## [1.0.7](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.6...v1.0.7) (2026-03-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.5.4 ([#18](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/18)) ([ccf6e1c](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/ccf6e1c154890c0e8e30a1c928474aee77cdfd91))
* **deps:** update dependency cehlers88/analytics-core to v0.5.5 ([#20](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/20)) ([874cfa2](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/874cfa2d181a4b3099c9f9e0aa483ebf99454555))

## [1.0.6](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.5...v1.0.6) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.5 ([#17](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/17)) ([c882fcd](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/c882fcde8a9ecc411480e29fe58b51acc30ae6d6))
* **deps:** update dependency cehlers88/analytics-core to v0.4.2 ([#15](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/15)) ([cb7106d](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/cb7106db3bb54180b6de995c1eac7d8ab55d2c1b))

## [1.0.5](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.4...v1.0.5) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.4.1 ([#13](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/13)) ([11a20be](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/11a20beb2094bf40dc831eeafbf62caf78c280d8))

## [1.0.4](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.3...v1.0.4) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([3c3a4d8](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/3c3a4d8d17e5798e10d06455143de0de0b7872ad))

## [1.0.3](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.2...v1.0.3) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.1 ([#10](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/10)) ([adb7f91](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/adb7f9188042d5338c1d1ae732ab15a5f398b7dd))
* Update analytics-core dependency to use dev-main ([3c31914](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/3c319142447a589a3c11efae1560807c2a16e2e2))

## [1.0.2](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.1...v1.0.2) (2026-03-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.3 ([#7](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/7)) ([eac0b9a](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/eac0b9ae85fd05670c829996e77c2c4a3352dd47))
* **deps:** update dependency cehlers88/analytics-core to v0.2.1 ([#3](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/3)) ([6909f00](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/6909f0045d042b159b899a428e43796039009bc9))
* Update composer.json to align branch alias and dependency versioning ([e29b46b](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/e29b46b2895865727b1925a29f1e25481e4cc26b))

## [1.0.1](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.0...v1.0.1) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.2.0@dev ([#4](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/4)) ([a6426ca](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/a6426ca8c32cc3c2070f0ec2fcc66899313ce00b))

## 1.0.0 (2026-01-21)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.7 ([#1](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/1)) ([3d226cf](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/3d226cfcbdd9df91e0f09d1ec7e15050bfafae57))
* Introduce AnalyticsCalendarBundle with core features and configuration. ([98a0247](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/98a0247560e3ad85204ebc803f6fc1d2327e8073))
