<?php

namespace Cehlers88\AnalyticsCalendarBundle\Calendar;

use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCore\Entity\Category;
use Cehlers88\AnalyticsCore\Entity\User;

/**
 * Builds the view model the calendar widget is rendered from.
 *
 * The factory answers three questions for a period: which days it is made of,
 * what happens on each of them, and where the navigation goes from here. A
 * repeating appointment is expanded into the occurrences that actually fall
 * into the period, so a template never has to know a recurrence rule.
 */
class CalendarViewFactory
{
    /**
     * Colours an appointment can get. They are picked from the title so the
     * same appointment keeps its colour without the entity having to store one.
     */
    private const COLORS = [
        '#4f83cc',
        '#5aa469',
        '#c2803a',
        '#8e6fbd',
        '#3f9c9c',
        '#c2557a',
        '#8b9a3f',
        '#5f8fa8',
    ];

    public function __construct(
        private AppointmentRepository $appointmentRepository,
        private OccurrenceResolver    $occurrenceResolver,
        private WorkWeek              $workWeek = new WorkWeek(),
        private VacationCategories    $vacationCategories = new VacationCategories()
    ) {
    }

    /**
     * @param string $view          CalendarGrid::VIEW_MONTH or ::VIEW_WEEK
     * @param int    $firstDayOfWeek 1 = Monday … 7 = Sunday
     * @param ?User  $user           Whose appointments are shown - nobody's without one
     * @param ?\DateTimeImmutable $now What counts as running or over - the current time without one
     *
     * @return array The properties the calendar template renders
     */
    public function create(
        \DateTimeImmutable $anchor,
        string             $view,
        int                $firstDayOfWeek,
        string             $timeFormat = 'H:i',
        string             $dateFormat = 'd.m.Y',
        ?User              $user = null,
        ?\DateTimeImmutable $now = null
    ): array {
        $now ??= new \DateTimeImmutable();
        $anchor = $anchor->setTime(0, 0);
        $view = $view === CalendarGrid::VIEW_WEEK ? CalendarGrid::VIEW_WEEK : CalendarGrid::VIEW_MONTH;
        $firstDayOfWeek = min(7, max(1, $firstDayOfWeek));
        $today = $now->setTime(0, 0);

        [$rangeStart, $rangeEnd] = $this->resolveRange($anchor, $view, $firstDayOfWeek);

        $occurrencesByDay = $user === null
            ? []
            : $this->collectOccurrences($rangeStart, $rangeEnd, $timeFormat, $user, $now);

        $weeks = [];
        $day = $rangeStart;
        $appointmentCount = 0;

        while ($day <= $rangeEnd) {
            $week = [
                'number' => (int)$day->format('W'),
                'days' => [],
            ];

            for ($i = 0; $i < 7; $i++) {
                $key = $day->format('Y-m-d');
                $appointments = $occurrencesByDay[$key] ?? [];
                $appointmentCount += count($appointments);

                $week['days'][] = [
                    'date' => $key,
                    'day' => (int)$day->format('j'),
                    'label' => $day->format($dateFormat),
                    'weekdayName' => CalendarGrid::weekdayName((int)$day->format('N')),
                    'isToday' => $day == $today,
                    'isWeekend' => $this->workWeek->isWeekend((int)$day->format('N')),
                    'isCurrentMonth' => $view === CalendarGrid::VIEW_WEEK
                        || $day->format('Y-m') === $anchor->format('Y-m'),
                    'isPast' => $day < $today,
                    'appointments' => $appointments,
                ];

                $day = $day->modify('+1 day');
            }

            $weeks[] = $week;
        }

        $todayKey = $today->format('Y-m-d');
        if ($user !== null && !($today >= $rangeStart && $today <= $rangeEnd)) {
            // navigated away from today - the badge of the tile still counts today
            $occurrencesByDay = $this->collectOccurrences($today, $today, $timeFormat, $user, $now);
        }

        return [
            'view' => $view,
            'date' => $anchor->format('Y-m-d'),
            'today' => $today->format('Y-m-d'),
            'isCurrentPeriod' => $today >= $rangeStart && $today <= $rangeEnd,
            'firstDayOfWeek' => $firstDayOfWeek,
            'weekdays' => $this->buildWeekdays($firstDayOfWeek),
            'weeks' => $weeks,
            'periodTitle' => $this->buildPeriodTitle($anchor, $view, $rangeStart, $rangeEnd),
            'periodSubTitle' => $view === CalendarGrid::VIEW_WEEK
                ? 'KW ' . $rangeStart->format('W')
                : $rangeStart->format('d.m.') . ' – ' . $rangeEnd->format('d.m.Y'),
            'appointmentCount' => $appointmentCount,
            'todayOpenUntil' => self::openUntil($occurrencesByDay[$todayKey] ?? []),
            'previousDate' => $this->shift($anchor, $view, -1)->format('Y-m-d'),
            'nextDate' => $this->shift($anchor, $view, 1)->format('Y-m-d'),
            'rangeStart' => $rangeStart->format('Y-m-d'),
            'rangeEnd' => $rangeEnd->format('Y-m-d'),
            'timeFormat' => $timeFormat,
            'dateFormat' => $dateFormat,
        ];
    }

    /**
     * @return array{0: \DateTimeImmutable, 1: \DateTimeImmutable}
     */
    private function resolveRange(
        \DateTimeImmutable $anchor,
        string             $view,
        int                $firstDayOfWeek
    ): array {
        if ($view === CalendarGrid::VIEW_WEEK) {
            $start = CalendarGrid::startOfWeek($anchor, $firstDayOfWeek);

            return [$start, $start->modify('+6 days')];
        }

        $start = CalendarGrid::startOfWeek($anchor->modify('first day of this month'), $firstDayOfWeek);
        $end = CalendarGrid::startOfWeek($anchor->modify('last day of this month'), $firstDayOfWeek)
            ->modify('+6 days');

        return [$start, $end];
    }

    private function shift(\DateTimeImmutable $anchor, string $view, int $steps): \DateTimeImmutable
    {
        if ($view === CalendarGrid::VIEW_WEEK) {
            return $anchor->modify(($steps * 7) . ' days');
        }

        // Stepping from the first of the month keeps a 31st from skipping the
        // short month that follows it.
        return $anchor->modify('first day of this month')->modify($steps . ' month');
    }

    private function buildPeriodTitle(
        \DateTimeImmutable $anchor,
        string             $view,
        \DateTimeImmutable $rangeStart,
        \DateTimeImmutable $rangeEnd
    ): string {
        if ($view === CalendarGrid::VIEW_MONTH) {
            return CalendarGrid::monthName((int)$anchor->format('n')) . ' ' . $anchor->format('Y');
        }

        if ($rangeStart->format('n') === $rangeEnd->format('n')) {
            return CalendarGrid::monthName((int)$rangeStart->format('n')) . ' ' . $rangeStart->format('Y');
        }

        return CalendarGrid::monthName((int)$rangeStart->format('n'))
            . ' / ' . CalendarGrid::monthName((int)$rangeEnd->format('n'))
            . ' ' . $rangeEnd->format('Y');
    }

    /**
     * @return array<int, array{iso: int, name: string, short: string, isWeekend: bool}>
     */
    private function buildWeekdays(int $firstDayOfWeek): array
    {
        $weekdays = [];

        for ($i = 0; $i < 7; $i++) {
            $iso = (($firstDayOfWeek - 1 + $i) % 7) + 1;
            $weekdays[] = [
                'iso' => $iso,
                'name' => CalendarGrid::weekdayName($iso),
                'short' => CalendarGrid::weekdayShortName($iso),
                'isWeekend' => $this->workWeek->isWeekend($iso),
            ];
        }

        return $weekdays;
    }

    /**
     * Every occurrence in the range, bucketed by the day it is shown on. An
     * appointment that spans days shows up on each of them.
     *
     * @return array<string, array<int, array<string, mixed>>>
     */
    private function collectOccurrences(
        \DateTimeImmutable $rangeStart,
        \DateTimeImmutable $rangeEnd,
        string             $timeFormat,
        User               $user,
        \DateTimeImmutable $now
    ): array {
        $rangeEndOfDay = $rangeEnd->setTime(23, 59, 59);
        $buckets = [];

        foreach ($this->appointmentRepository->findInRange($rangeStart, $rangeEndOfDay, $user) as $appointment) {
            foreach ($this->occurrenceResolver->occurrencesBetween($appointment, $rangeStart, $rangeEndOfDay) as [$start, $end]) {
                $this->bucketOccurrence($buckets, $appointment, $start, $end, $rangeStart, $rangeEnd, $timeFormat, $now);
            }
        }

        foreach ($buckets as $key => $entries) {
            usort($entries, static function (array $left, array $right): int {
                return [$left['isAllDay'] ? 0 : 1, $left['sortKey']]
                    <=> [$right['isAllDay'] ? 0 : 1, $right['sortKey']];
            });
            $buckets[$key] = $entries;
        }

        return $buckets;
    }

    /**
     * @param array<string, array<int, array<string, mixed>>> $buckets
     */
    private function bucketOccurrence(
        array              &$buckets,
        Appointment        $appointment,
        \DateTimeImmutable $start,
        ?\DateTimeImmutable $end,
        \DateTimeImmutable $rangeStart,
        \DateTimeImmutable $rangeEnd,
        string             $timeFormat,
        \DateTimeImmutable $now
    ): void {
        $isAllDay = $this->isAllDay($start, $end);
        $isRunning = self::isRunning($start, $end, $isAllDay, $now);
        $isOver = self::isOver($start, $end, $isAllDay, $now);
        $lastDay = ($end ?? $start)->setTime(0, 0);
        $day = max($start->setTime(0, 0), $rangeStart);
        $lastDay = min($lastDay, $rangeEnd);

        while ($day <= $lastDay) {
            $isFirstDay = $day == $start->setTime(0, 0);
            $isLastDay = $day == ($end ?? $start)->setTime(0, 0);

            $buckets[$day->format('Y-m-d')][] = [
                'id' => $appointment->getId(),
                'title' => (string)$appointment->getTitle(),
                'description' => (string)$appointment->getDescription(),
                'color' => $this->colorOf((string)$appointment->getTitle()),
                'isAllDay' => $isAllDay,
                'isContinuation' => !$isFirstDay,
                'isRepeating' => $appointment->isRepeating(),
                'isVacation' => $this->vacationCategories->isVacation($appointment),
                'categories' => array_values(array_map(
                    static fn(Category $category): string => (string)$category->getName(),
                    $appointment->getCategories()->toArray()
                )),
                'hasReminder' => (int)$appointment->getReminderTimer() > 0,
                'isRunning' => $isRunning,
                'isOver' => $isOver,
                // Running in time is not started yet for an appointment with a
                // start condition: the worker starts it once the condition holds.
                'hasStartCondition' => $appointment->hasStartCondition(),
                'isStarted' => $appointment->isOccurrenceStarted($start),
                // With their offset, so the tile can keep isRunning and isOver
                // current in the browser without asking the server again.
                'startsAt' => $start->format(\DATE_ATOM),
                'endsAt' => $isAllDay
                    ? ($end ?? $start)->setTime(23, 59, 59)->format(\DATE_ATOM)
                    : $end?->format(\DATE_ATOM),
                'timeLabel' => $this->buildTimeLabel($start, $end, $isAllDay, $isFirstDay, $isLastDay, $timeFormat),
                'rangeLabel' => $this->buildRangeLabel($start, $end, $isAllDay, $timeFormat),
                'repeatLabel' => $this->buildRepeatLabel($appointment),
                'reminderLabel' => $this->buildReminderLabel((int)$appointment->getReminderTimer()),
                'sortKey' => $isFirstDay ? $start->format('H:i') : '00:00',
            ];

            $day = $day->modify('+1 day');
        }
    }

    /**
     * When each appointment of a day that is not over yet will be over, for the badge of a
     * tile minimized in the side panel of the app: the tile counts the ones still ahead and
     * keeps the count true to the clock. Vacations are no appointments one has to be at.
     *
     * @param array<int, array<string, mixed>> $entries The appointments of the day, as bucketed
     *
     * @return string[] DATE_ATOM moments - the end, or the start of one without an end
     */
    public static function openUntil(array $entries): array
    {
        $moments = [];
        foreach ($entries as $entry) {
            if (($entry['isOver'] ?? false) || ($entry['isVacation'] ?? false)) {
                continue;
            }
            $moment = $entry['endsAt'] ?? $entry['startsAt'] ?? null;
            if (is_string($moment) && $moment !== '') {
                $moments[] = $moment;
            }
        }

        return $moments;
    }

    /**
     * Started but not ended yet. An all-day appointment runs from the start of
     * its first day until its last day is over - a vacation from Monday to
     * Friday is running all week. Without an end an appointment is a point in
     * time and never runs.
     */
    public static function isRunning(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        bool                $isAllDay,
        \DateTimeImmutable  $now
    ): bool {
        if ($isAllDay) {
            return $end !== null && $start <= $now && !self::isOver($start, $end, true, $now);
        }

        return $end !== null && $start <= $now && $now < $end;
    }

    /**
     * Over once its end has passed - for an appointment without an end once it
     * started, for an all-day one once its last day is.
     */
    public static function isOver(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        bool                $isAllDay,
        \DateTimeImmutable  $now
    ): bool {
        if ($isAllDay) {
            return ($end ?? $start)->setTime(23, 59, 59) < $now;
        }

        return ($end ?? $start) <= $now;
    }

    private function isAllDay(\DateTimeImmutable $start, ?\DateTimeImmutable $end): bool
    {
        if ($start->format('H:i') !== '00:00') {
            return false;
        }

        return $end === null || in_array($end->format('H:i'), ['00:00', '23:59'], true);
    }

    private function buildTimeLabel(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        bool                $isAllDay,
        bool                $isFirstDay,
        bool                $isLastDay,
        string              $timeFormat
    ): string {
        if ($isAllDay) {
            return 'ganztägig';
        }

        if ($isFirstDay) {
            return $start->format($timeFormat);
        }

        if ($isLastDay && $end !== null) {
            return 'bis ' . $end->format($timeFormat);
        }

        return 'ganztägig';
    }

    private function buildRangeLabel(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        bool                $isAllDay,
        string              $timeFormat
    ): string {
        if ($isAllDay) {
            return $end === null || $start->format('Y-m-d') === $end->format('Y-m-d')
                ? 'ganztägig'
                : $start->format('d.m.Y') . ' – ' . $end->format('d.m.Y') . ', ganztägig';
        }

        if ($end === null) {
            return $start->format($timeFormat) . ' Uhr';
        }

        if ($start->format('Y-m-d') === $end->format('Y-m-d')) {
            return $start->format($timeFormat) . ' – ' . $end->format($timeFormat) . ' Uhr';
        }

        return $start->format('d.m. ' . $timeFormat) . ' – ' . $end->format('d.m. ' . $timeFormat);
    }

    private function buildRepeatLabel(Appointment $appointment): string
    {
        $interval = (int)$appointment->getRepeatInterval();

        return match ($appointment->getRepeatType()) {
            eRepeatType::NONE => '',
            eRepeatType::WEEKDAYS => 'in der Arbeitswoche',
            eRepeatType::WEEKEND => 'am Wochenende',
            eRepeatType::DAYS => self::describeDays($appointment->getRepeatDays(), $this->workWeek->weekStart()),
            eRepeatType::YEARLY => 'jährlich',
            eRepeatType::INTERVAL => match ($interval) {
                1 => 'täglich',
                7 => 'wöchentlich',
                14 => 'alle zwei Wochen',
                30 => 'monatlich',
                default => 'alle ' . $interval . ' Tage',
            },
        };
    }

    /**
     * The weekdays by their short names, in the order of the configured week -
     * "Mo, Mi, Fr".
     *
     * @param int[] $isoDays
     */
    public static function describeDays(array $isoDays, int $weekStart = WorkWeek::DEFAULT_WEEK_START): string
    {
        $ordered = array_filter(
            WorkWeek::daysFromTo($weekStart, ($weekStart + 5) % 7 + 1),
            static fn(int $day): bool => in_array($day, $isoDays, true)
        );

        return implode(', ', array_map(CalendarGrid::weekdayShortName(...), $ordered));
    }

    private function buildReminderLabel(int $seconds): string
    {
        if ($seconds < 1) {
            return '';
        }

        if ($seconds < 3600) {
            return (int)round($seconds / 60) . ' Min. vorher';
        }

        if ($seconds < 86400) {
            return (int)round($seconds / 3600) . ' Std. vorher';
        }

        return (int)round($seconds / 86400) . ' Tage vorher';
    }

    private function colorOf(string $title): string
    {
        $count = count(self::COLORS);
        $index = (crc32($title) % $count + $count) % $count;

        return self::COLORS[$index];
    }
}
