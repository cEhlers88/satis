<?php

namespace Cehlers88\AnalyticsCalendarBundle\Calendar;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;

/**
 * Builds the view model the calendar widget is rendered from.
 *
 * The factory answers three questions for a period: which days it is made of,
 * what happens on each of them, and where the navigation goes from here. A
 * repeating appointment is expanded into the occurrences that actually fall
 * into the period, so a template never has to know a recurrence rule.
 */
class CalendarViewFactory
{
    /**
     * Colours an appointment can get. They are picked from the title so the
     * same appointment keeps its colour without the entity having to store one.
     */
    private const COLORS = [
        '#4f83cc',
        '#5aa469',
        '#c2803a',
        '#8e6fbd',
        '#3f9c9c',
        '#c2557a',
        '#8b9a3f',
        '#5f8fa8',
    ];

    /** A series that never leaves the range must still not loop forever. */
    private const MAX_OCCURRENCES = 400;

    public function __construct(
        private AppointmentRepository $appointmentRepository
    ) {
    }

    /**
     * @param string $view          CalendarGrid::VIEW_MONTH or ::VIEW_WEEK
     * @param int    $firstDayOfWeek 1 = Monday … 7 = Sunday
     *
     * @return array The properties the calendar template renders
     */
    public function create(
        \DateTimeImmutable $anchor,
        string             $view,
        int                $firstDayOfWeek,
        string             $timeFormat = 'H:i',
        string             $dateFormat = 'd.m.Y'
    ): array {
        $anchor = $anchor->setTime(0, 0);
        $view = $view === CalendarGrid::VIEW_WEEK ? CalendarGrid::VIEW_WEEK : CalendarGrid::VIEW_MONTH;
        $firstDayOfWeek = min(7, max(1, $firstDayOfWeek));
        $today = new \DateTimeImmutable('today');

        [$rangeStart, $rangeEnd] = $this->resolveRange($anchor, $view, $firstDayOfWeek);

        $occurrencesByDay = $this->collectOccurrences($rangeStart, $rangeEnd, $timeFormat);

        $weeks = [];
        $day = $rangeStart;
        $appointmentCount = 0;

        while ($day <= $rangeEnd) {
            $week = [
                'number' => (int)$day->format('W'),
                'days' => [],
            ];

            for ($i = 0; $i < 7; $i++) {
                $key = $day->format('Y-m-d');
                $appointments = $occurrencesByDay[$key] ?? [];
                $appointmentCount += count($appointments);

                $week['days'][] = [
                    'date' => $key,
                    'day' => (int)$day->format('j'),
                    'label' => $day->format($dateFormat),
                    'weekdayName' => CalendarGrid::weekdayName((int)$day->format('N')),
                    'isToday' => $day == $today,
                    'isWeekend' => (int)$day->format('N') >= 6,
                    'isCurrentMonth' => $view === CalendarGrid::VIEW_WEEK
                        || $day->format('Y-m') === $anchor->format('Y-m'),
                    'isPast' => $day < $today,
                    'appointments' => $appointments,
                ];

                $day = $day->modify('+1 day');
            }

            $weeks[] = $week;
        }

        return [
            'view' => $view,
            'date' => $anchor->format('Y-m-d'),
            'today' => $today->format('Y-m-d'),
            'isCurrentPeriod' => $today >= $rangeStart && $today <= $rangeEnd,
            'firstDayOfWeek' => $firstDayOfWeek,
            'weekdays' => $this->buildWeekdays($firstDayOfWeek),
            'weeks' => $weeks,
            'periodTitle' => $this->buildPeriodTitle($anchor, $view, $rangeStart, $rangeEnd),
            'periodSubTitle' => $view === CalendarGrid::VIEW_WEEK
                ? 'KW ' . $rangeStart->format('W')
                : $rangeStart->format('d.m.') . ' – ' . $rangeEnd->format('d.m.Y'),
            'appointmentCount' => $appointmentCount,
            'previousDate' => $this->shift($anchor, $view, -1)->format('Y-m-d'),
            'nextDate' => $this->shift($anchor, $view, 1)->format('Y-m-d'),
            'rangeStart' => $rangeStart->format('Y-m-d'),
            'rangeEnd' => $rangeEnd->format('Y-m-d'),
            'timeFormat' => $timeFormat,
            'dateFormat' => $dateFormat,
        ];
    }

    /**
     * @return array{0: \DateTimeImmutable, 1: \DateTimeImmutable}
     */
    private function resolveRange(
        \DateTimeImmutable $anchor,
        string             $view,
        int                $firstDayOfWeek
    ): array {
        if ($view === CalendarGrid::VIEW_WEEK) {
            $start = CalendarGrid::startOfWeek($anchor, $firstDayOfWeek);

            return [$start, $start->modify('+6 days')];
        }

        $start = CalendarGrid::startOfWeek($anchor->modify('first day of this month'), $firstDayOfWeek);
        $end = CalendarGrid::startOfWeek($anchor->modify('last day of this month'), $firstDayOfWeek)
            ->modify('+6 days');

        return [$start, $end];
    }

    private function shift(\DateTimeImmutable $anchor, string $view, int $steps): \DateTimeImmutable
    {
        if ($view === CalendarGrid::VIEW_WEEK) {
            return $anchor->modify(($steps * 7) . ' days');
        }

        // Stepping from the first of the month keeps a 31st from skipping the
        // short month that follows it.
        return $anchor->modify('first day of this month')->modify($steps . ' month');
    }

    private function buildPeriodTitle(
        \DateTimeImmutable $anchor,
        string             $view,
        \DateTimeImmutable $rangeStart,
        \DateTimeImmutable $rangeEnd
    ): string {
        if ($view === CalendarGrid::VIEW_MONTH) {
            return CalendarGrid::monthName((int)$anchor->format('n')) . ' ' . $anchor->format('Y');
        }

        if ($rangeStart->format('n') === $rangeEnd->format('n')) {
            return CalendarGrid::monthName((int)$rangeStart->format('n')) . ' ' . $rangeStart->format('Y');
        }

        return CalendarGrid::monthName((int)$rangeStart->format('n'))
            . ' / ' . CalendarGrid::monthName((int)$rangeEnd->format('n'))
            . ' ' . $rangeEnd->format('Y');
    }

    /**
     * @return array<int, array{iso: int, name: string, short: string, isWeekend: bool}>
     */
    private function buildWeekdays(int $firstDayOfWeek): array
    {
        $weekdays = [];

        for ($i = 0; $i < 7; $i++) {
            $iso = (($firstDayOfWeek - 1 + $i) % 7) + 1;
            $weekdays[] = [
                'iso' => $iso,
                'name' => CalendarGrid::weekdayName($iso),
                'short' => CalendarGrid::weekdayShortName($iso),
                'isWeekend' => $iso >= 6,
            ];
        }

        return $weekdays;
    }

    /**
     * Every occurrence in the range, bucketed by the day it is shown on. An
     * appointment that spans days shows up on each of them.
     *
     * @return array<string, array<int, array<string, mixed>>>
     */
    private function collectOccurrences(
        \DateTimeImmutable $rangeStart,
        \DateTimeImmutable $rangeEnd,
        string             $timeFormat
    ): array {
        $rangeEndOfDay = $rangeEnd->setTime(23, 59, 59);
        $buckets = [];

        foreach ($this->appointmentRepository->findInRange($rangeStart, $rangeEndOfDay) as $appointment) {
            foreach ($this->expand($appointment, $rangeStart, $rangeEndOfDay) as [$start, $end]) {
                $this->bucketOccurrence($buckets, $appointment, $start, $end, $rangeStart, $rangeEnd, $timeFormat);
            }
        }

        foreach ($buckets as $key => $entries) {
            usort($entries, static function (array $left, array $right): int {
                return [$left['isAllDay'] ? 0 : 1, $left['sortKey']]
                    <=> [$right['isAllDay'] ? 0 : 1, $right['sortKey']];
            });
            $buckets[$key] = $entries;
        }

        return $buckets;
    }

    /**
     * The occurrences of an appointment that touch the range - a single one for
     * an appointment that does not repeat.
     *
     * @return \Generator<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    private function expand(
        Appointment        $appointment,
        \DateTimeImmutable $rangeStart,
        \DateTimeImmutable $rangeEnd
    ): \Generator {
        $start = \DateTimeImmutable::createFromInterface($appointment->getStartDate());
        $end = $appointment->getEndDate() === null
            ? null
            : \DateTimeImmutable::createFromInterface($appointment->getEndDate());
        $interval = (int)$appointment->getRepeatInterval();

        if ($interval < 1) {
            if (($end ?? $start) >= $rangeStart && $start <= $rangeEnd) {
                yield [$start, $end];
            }

            return;
        }

        // Skipping straight to the first occurrence that can still be in the
        // range keeps a long-running series from being walked from its start.
        $difference = $start->setTime(0, 0)->diff($rangeStart->setTime(0, 0));
        $daysBehind = $difference->invert ? -$difference->days : $difference->days;
        $step = $daysBehind > 0 ? (int)floor($daysBehind / $interval) : 0;

        for ($i = 0; $i < self::MAX_OCCURRENCES; $i++, $step++) {
            $offset = $step * $interval;
            $occurrenceStart = $start->modify('+' . $offset . ' days');

            if ($occurrenceStart > $rangeEnd) {
                return;
            }

            $occurrenceEnd = $end?->modify('+' . $offset . ' days');

            if (($occurrenceEnd ?? $occurrenceStart) >= $rangeStart) {
                yield [$occurrenceStart, $occurrenceEnd];
            }
        }
    }

    /**
     * @param array<string, array<int, array<string, mixed>>> $buckets
     */
    private function bucketOccurrence(
        array              &$buckets,
        Appointment        $appointment,
        \DateTimeImmutable $start,
        ?\DateTimeImmutable $end,
        \DateTimeImmutable $rangeStart,
        \DateTimeImmutable $rangeEnd,
        string             $timeFormat
    ): void {
        $isAllDay = $this->isAllDay($start, $end);
        $lastDay = ($end ?? $start)->setTime(0, 0);
        $day = max($start->setTime(0, 0), $rangeStart);
        $lastDay = min($lastDay, $rangeEnd);

        while ($day <= $lastDay) {
            $isFirstDay = $day == $start->setTime(0, 0);
            $isLastDay = $day == ($end ?? $start)->setTime(0, 0);

            $buckets[$day->format('Y-m-d')][] = [
                'id' => $appointment->getId(),
                'title' => (string)$appointment->getTitle(),
                'description' => (string)$appointment->getDescription(),
                'color' => $this->colorOf((string)$appointment->getTitle()),
                'isAllDay' => $isAllDay,
                'isContinuation' => !$isFirstDay,
                'isRepeating' => (int)$appointment->getRepeatInterval() > 0,
                'hasReminder' => (int)$appointment->getReminderTimer() > 0,
                'startsAt' => $start->format('Y-m-d\TH:i'),
                'endsAt' => $end?->format('Y-m-d\TH:i'),
                'timeLabel' => $this->buildTimeLabel($start, $end, $isAllDay, $isFirstDay, $isLastDay, $timeFormat),
                'rangeLabel' => $this->buildRangeLabel($start, $end, $isAllDay, $timeFormat),
                'repeatLabel' => $this->buildRepeatLabel((int)$appointment->getRepeatInterval()),
                'reminderLabel' => $this->buildReminderLabel((int)$appointment->getReminderTimer()),
                'sortKey' => $isFirstDay ? $start->format('H:i') : '00:00',
            ];

            $day = $day->modify('+1 day');
        }
    }

    private function isAllDay(\DateTimeImmutable $start, ?\DateTimeImmutable $end): bool
    {
        if ($start->format('H:i') !== '00:00') {
            return false;
        }

        return $end === null || in_array($end->format('H:i'), ['00:00', '23:59'], true);
    }

    private function buildTimeLabel(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        bool                $isAllDay,
        bool                $isFirstDay,
        bool                $isLastDay,
        string              $timeFormat
    ): string {
        if ($isAllDay) {
            return 'ganztägig';
        }

        if ($isFirstDay) {
            return $start->format($timeFormat);
        }

        if ($isLastDay && $end !== null) {
            return 'bis ' . $end->format($timeFormat);
        }

        return 'ganztägig';
    }

    private function buildRangeLabel(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        bool                $isAllDay,
        string              $timeFormat
    ): string {
        if ($isAllDay) {
            return $end === null || $start->format('Y-m-d') === $end->format('Y-m-d')
                ? 'ganztägig'
                : $start->format('d.m.Y') . ' – ' . $end->format('d.m.Y') . ', ganztägig';
        }

        if ($end === null) {
            return $start->format($timeFormat) . ' Uhr';
        }

        if ($start->format('Y-m-d') === $end->format('Y-m-d')) {
            return $start->format($timeFormat) . ' – ' . $end->format($timeFormat) . ' Uhr';
        }

        return $start->format('d.m. ' . $timeFormat) . ' – ' . $end->format('d.m. ' . $timeFormat);
    }

    private function buildRepeatLabel(int $interval): string
    {
        return match (true) {
            $interval < 1 => '',
            $interval === 1 => 'täglich',
            $interval === 7 => 'wöchentlich',
            $interval === 14 => 'alle zwei Wochen',
            $interval === 30 => 'monatlich',
            default => 'alle ' . $interval . ' Tage',
        };
    }

    private function buildReminderLabel(int $seconds): string
    {
        if ($seconds < 1) {
            return '';
        }

        if ($seconds < 3600) {
            return (int)round($seconds / 60) . ' Min. vorher';
        }

        if ($seconds < 86400) {
            return (int)round($seconds / 3600) . ' Std. vorher';
        }

        return (int)round($seconds / 86400) . ' Tage vorher';
    }

    private function colorOf(string $title): string
    {
        $count = count(self::COLORS);
        $index = (crc32($title) % $count + $count) % $count;

        return self::COLORS[$index];
    }
}
