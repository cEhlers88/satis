<?php

namespace Cehlers88\AnalyticsCalendarBundle\Calendar;

/**
 * The calendar as it is put on screen: the weeks of a period, the appointments
 * that fall into them and the dates the navigation moves to.
 *
 * Everything a template needs is on the array this returns - the template only
 * decides what it looks like, never what a day contains.
 */
class CalendarGrid
{
    public const VIEW_MONTH = 'month';
    public const VIEW_WEEK = 'week';

    /** German is what the rest of the bundle speaks, so the grid does too. */
    private const MONTH_NAMES = [
        1 => 'Januar', 'Februar', 'März', 'April', 'Mai', 'Juni',
        'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember',
    ];

    private const WEEKDAY_NAMES = [
        1 => 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag',
    ];

    private const WEEKDAY_SHORT_NAMES = [
        1 => 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So',
    ];

    public static function monthName(int $month): string
    {
        return self::MONTH_NAMES[$month] ?? '';
    }

    public static function weekdayName(int $isoWeekday): string
    {
        return self::WEEKDAY_NAMES[$isoWeekday] ?? '';
    }

    public static function weekdayShortName(int $isoWeekday): string
    {
        return self::WEEKDAY_SHORT_NAMES[$isoWeekday] ?? '';
    }

    /**
     * The first day of the week the given day belongs to, counted from the
     * weekday the calendar starts on.
     */
    public static function startOfWeek(\DateTimeImmutable $day, int $firstDayOfWeek): \DateTimeImmutable
    {
        $offset = ((int)$day->format('N') - $firstDayOfWeek + 7) % 7;

        return $day->modify('-' . $offset . ' days');
    }
}
