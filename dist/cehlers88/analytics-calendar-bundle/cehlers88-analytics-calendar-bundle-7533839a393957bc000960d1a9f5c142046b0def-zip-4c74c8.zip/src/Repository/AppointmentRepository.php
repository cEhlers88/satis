<?php

namespace Cehlers88\AnalyticsCalendarBundle\Repository;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Appointment>
 */
class AppointmentRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Appointment::class);
    }

    public function save(Appointment $appointment, bool $flush = true): Appointment
    {
        $this->getEntityManager()->persist($appointment);

        if ($flush) {
            $this->getEntityManager()->flush();
        }

        return $appointment;
    }

    public function remove(Appointment $appointment, bool $flush = true): void
    {
        $this->getEntityManager()->remove($appointment);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    /**
     * Every appointment that can put an occurrence into the given range.
     *
     * A repeating appointment is one of them as soon as its series starts
     * before the range ends - which of its occurrences actually land inside is
     * decided while the series is expanded, not here.
     *
     * @return Appointment[]
     */
    public function findInRange(\DateTimeInterface $from, \DateTimeInterface $to): array
    {
        return $this->createQueryBuilder('appointment')
            ->andWhere('appointment.startDate <= :to')
            ->andWhere(
                '(COALESCE(appointment.endDate, appointment.startDate) >= :from'
                . ' OR COALESCE(appointment.repeatInterval, 0) > 0)'
            )
            ->setParameter('from', $from)
            ->setParameter('to', $to)
            ->orderBy('appointment.startDate', 'ASC')
            ->getQuery()
            ->getResult();
    }
}
