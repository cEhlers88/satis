# AnalyticsCalendarBundle

A Symfony bundle for managing calendar appointments and events within the Analytics platform. It provides dashboard widgets, appointment scheduling, configurable date/time formats, and a macro system for programmatic calendar operations.

## Table of Contents

- [Requirements](#requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [JavaScript / Webpack Encore Integration](#javascript--webpack-encore-integration)
- [Widgets](#widgets)
  - [Calendar Widget](#calendar-widget)
  - [Time Widget](#time-widget)
- [Entity: Appointment](#entity-appointment)
- [Repository: AppointmentRepository](#repository-appointmentrepository)
- [Calendar view model: CalendarViewFactory](#calendar-view-model-calendarviewfactory)
- [Macros](#macros)
  - [AddAppointmentMacro](#addappointmentmacro)
- [Permissions](#permissions)
- [Changelog](#changelog)

## Requirements

- PHP 8.0+
- Symfony 6.0+
- `cehlers88/analytics-core` ^0.3

## Installation

### 1. Add the custom Satis repository to your `composer.json`

```json
{
    "repositories": [
        {
            "type": "composer",
            "url": "https://cehlers88.github.io/satis"
        }
    ]
}
```

### 2. Install the bundle via Composer

```bash
composer require cehlers88/analytics-calendar-bundle
```

### 3. Register the bundle (if not using Symfony Flex auto-discovery)

```php
// config/bundles.php
return [
    // ...
    Cehlers88\AnalyticsCalendarBundle\AnalyticsCalendarBundle::class => ['all' => true],
];
```

### 4. Update the database schema

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

This creates the `calendar_appointment` table used by the `Appointment` entity.

## JavaScript / Webpack Encore Integration

The bundle ships its JavaScript assets in `assets/index.ts` and exposes a
`package.json` so it can be registered as a local npm module in the host
Symfony application.  Follow the steps below to include the bundle's
JavaScript in your webpack-encore build.

### 1. Register the bundle as a local npm package

Add the bundle as a file-based dependency in your application's `package.json`:

```json
{
    "dependencies": {
        "@cehlers88/analytics-calendar-bundle": "file:vendor/cehlers88/analytics-calendar-bundle"
    }
}
```

Then install the new dependency:

```bash
yarn install
# or
npm install
```

This creates a symlink at
`node_modules/@cehlers88/analytics-calendar-bundle` that points to the
vendor directory, so webpack can resolve the module.

### 2. Add an entry point in `webpack.config.js`

Open your application's `webpack.config.js` and add an entry that imports
the bundle's assets:

```js
// webpack.config.js
const Encore = require('@symfony/webpack-encore');

Encore
    // … your existing configuration …
    .addEntry('analytics-calendar-bundle', '@cehlers88/analytics-calendar-bundle')
;

module.exports = Encore.getWebpackConfig();
```

> **Tip:** If you prefer to bundle the calendar assets together with your
> main application entry point instead of creating a separate file, you can
> import the module inside your existing entry file (e.g.
> `assets/app.ts`):
>
> ```ts
> import { initAnalyticsCalendarBundle } from '@cehlers88/analytics-calendar-bundle';
>
> document.addEventListener('DOMContentLoaded', () => {
>     initAnalyticsCalendarBundle();
> });
> ```

### 3. Build the assets

```bash
yarn encore dev   # development build
yarn encore prod  # production build
```

### 4. Include the compiled script in your Twig template

If you added a dedicated entry point in step 2, include it via the
`encore_entry_script_tags` helper:

```twig
{# base.html.twig #}
{{ encore_entry_script_tags('analytics-calendar-bundle') }}
```

### Available exports

| Export | Description |
| --- | --- |
| `initAnalyticsCalendarBundle()` | Convenience initialiser for the widgets that need one. Returns a function that stops what it started. |
| `initTimeWidget(selector?)` | Starts a one-second interval that updates the text content of every element matching `selector` (default: `'[data-widget="time"]'`) with the current locale time string. Returns a function that clears the interval. |
| `onCalendarEvent(name, handler, target?)` | Listens to one of the events a calendar widget emits. Returns a function that removes the listener. |
| `CalendarEvents` | The event names: `navigate`, `daySelected`, `appointmentCreated`, `appointmentDeleted`. |

> **Note:** the calendar widget initialises itself. The markup the server
> renders carries the script that wires navigation, the day picker and the
> appointment mask, so nothing has to start it from the host application.

#### Listening to what happens in a calendar

The events bubble up to the document, so one listener catches every calendar on
the page - including the ones a dashboard renders after the listener was
registered.

```ts
import { CalendarEvents, onCalendarEvent } from '@cehlers88/analytics-calendar-bundle';

// The widget moved to another period or view.
onCalendarEvent(CalendarEvents.navigate, ({ view, date }) => {
    console.log('Kalender zeigt jetzt', view, 'ab', date);
});

// A day was picked - which is also what opens the appointment mask.
onCalendarEvent(CalendarEvents.daySelected, ({ date }) => {
    console.log('Tag gewählt:', date);
});

// An appointment was saved.
onCalendarEvent(CalendarEvents.appointmentCreated, ({ id, date }) => {
    console.log('Termin', id, 'am', date, 'gespeichert');
});

// An appointment was deleted.
onCalendarEvent(CalendarEvents.appointmentDeleted, ({ id }) => {
    console.log('Termin', id, 'gelöscht');
});
```

## Configuration

The bundle exposes a **General Calendar Settings** group under the key `calendarBundle.general`, accessible through the *Kalenderverwaltung* (Calendar Management) menu in the Analytics admin panel.

| Configuration Key | Label | Type | Default | Description |
|---|---|---|---|---|
| `calendarBundle.general.defaultDateFormat` | Standard Datumsformat | Text | `d.m.Y` | PHP date format used for displaying dates |
| `calendarBundle.general.defaultTimeFormat` | Standard Zeitformat | Text | `H:i` | PHP date format used for displaying times |
| `calendarBundle.general.defaultDateTimeFormat` | Standard Datums- und Zeitformat | Text | `d.m.Y H:i` | PHP date format used for displaying date and time together |
| `calendarBundle.general.defaultWeekStart` | Standard Wochenstart | Select | `1` (Monday) | First day of the week: 1 = Monday … 7 = Sunday |

## Widgets

### Calendar Widget

**Widget name:** `calendar`
**Required role:** `ROLE_USER`
**Template:** `templates/widget/calendar.html.twig` (body: `templates/widget/_calendarBody.html.twig`)

Shows the appointments of a month or a week in the dark theme of the dashboard
and opens the mask for a new appointment on the day that was picked.

- **Monats- und Wochenansicht** - the head switches between them and steps
  through the periods; *Heute* jumps back and is marked while the current
  period is on screen.
- **Termine im Raster** - each day lists what happens on it, coloured per
  appointment and truncated to the configured number with a `+n` summary.
  A repeating appointment is expanded into the occurrences that fall into the
  period, and one that spans days appears on each of them.
- **Neuer Termin** - clicking a day (or the button in the foot) opens a modal
  with title, date, all-day switch, times, repetition, reminder and
  description. Saving stores the appointment and repaints the period.
- **Termindetails und Löschen** - clicking an appointment opens it in the same
  modal. *Löschen* asks before it acts: the first click arms the button, the
  second one removes the appointment and repaints the period. A repeating
  appointment is one entity, so the button says that the whole series goes with
  it.

Navigating, saving and deleting all go through `submitWidget()`; the widget answers with
the body rendered from the very same Twig template the first paint used, so
there is never a second idea of what a calendar looks like in the browser.

#### Settings

The settings a dashboard tile can be configured with:

| Setting | Type | Default | Description |
|---|---|---|---|
| `view` | Select (`month`, `week`) | `month` | Which view the tile starts with |
| `maxEntriesPerDay` | Number (1-8) | `3` | How many appointments a day shows before the rest is summarised |
| `showWeekNumbers` | Checkbox | `false` | Puts the calendar week in front of each week |

The weekday a calendar starts on comes from
`calendarBundle.general.defaultWeekStart`, the labels from
`defaultDateFormat` and `defaultTimeFormat` - see [Configuration](#configuration).
A `date` property (anything `DateTimeImmutable` understands, or a timestamp)
makes the tile start on another period than the current one.

#### Submit actions

`POST /api/submitWidget/calendar` understands three actions:

| `action` | Payload | Answer |
|---|---|---|
| `render` | `date`, `view`, `firstDayOfWeek`, `maxEntriesPerDay`, `showWeekNumbers` | `data.html` - the body of the tile for that period |
| `create` | `title`, `date`, `startTime`, `endDate`, `endTime`, `description`, `repeatInterval`, `reminderTimer` | `data.id`, `data.date` of the stored appointment |
| `delete` | `appointmentId` | `data.id` of the removed appointment |

> `appointmentId` and not `id`: the latter is the id of the widget instance,
> which the render action is given alongside it.

**Preload placeholders layout:**

| Row | Height | Column widths |
|-----|--------|---------------|
| 1 | 32 px | 50 % · 50 % |
| 2 | 240 px | 100 % |
| 3 | 32 px | 60 % · 40 % |

### Time Widget

**Widget name:** `time`

A minimal widget that displays the current time.

**Preload placeholders layout:**

| Row | Height | Column widths |
|-----|--------|---------------|
| 1 | 50 px | 50 % · 50 % |

**Template:** `templates/widget/time.html.twig`

## Entity: Appointment

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Entity\Appointment`  
**Database table:** `calendar_appointment`

| Property | Type | Nullable | Description |
|----------|------|----------|-------------|
| `id` | `int` | No | Auto-generated primary key |
| `title` | `string(255)` | No | Title of the appointment |
| `description` | `text` | Yes | Optional detailed description |
| `startDate` | `DateTime` | No | Start date and time |
| `endDate` | `DateTime` | Yes | Optional end date and time |
| `repeatInterval` | `int` | Yes | Recurrence interval in days |
| `reminderTimer` | `int` | Yes | Reminder offset in seconds before the appointment |

**Example usage:**

```php
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;

$appointment = new Appointment();
$appointment
    ->setTitle('Team Meeting')
    ->setStartDate(new \DateTime('2026-04-01 10:00'))
    ->setEndDate(new \DateTime('2026-04-01 11:00'))
    ->setDescription('Weekly sync call')
    ->setRepeatInterval(7)      // repeats every 7 days
    ->setReminderTimer(900);    // reminder 15 minutes (900 s) before start

$entityManager->persist($appointment);
$entityManager->flush();
```

All setters return `static` to allow method chaining.

## Repository: AppointmentRepository

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository`

Extends `Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository`, so all
standard Doctrine query methods are available, plus:

| Method | Description |
|---|---|
| `save(Appointment $appointment, bool $flush = true): Appointment` | Persists an appointment |
| `remove(Appointment $appointment, bool $flush = true): void` | Removes an appointment |
| `findInRange(\DateTimeInterface $from, \DateTimeInterface $to): array` | Every appointment that can put an occurrence into the range - a repeating one counts as soon as its series starts before the range ends |

```php
// Inject the repository via autowiring or fetch from the entity manager
$repository = $entityManager->getRepository(Appointment::class);

// Find all appointments
$appointments = $repository->findAll();

// Everything that happens in August
$appointments = $repository->findInRange(
    new \DateTime('2026-08-01 00:00:00'),
    new \DateTime('2026-08-31 23:59:59')
);
```

## Calendar view model: CalendarViewFactory

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Calendar\CalendarViewFactory`

Builds what the calendar template renders: the weeks of a period, the
appointments that fall into each of their days and the dates the navigation
moves to. Repeating appointments are expanded into their occurrences and
appointments that span days are put on each day they touch, so a template never
has to know a recurrence rule.

```php
$view = $calendarViewFactory->create(
    new \DateTimeImmutable('2026-08-28'),
    'month',   // or 'week'
    1,         // 1 = Monday … 7 = Sunday
    'H:i',
    'd.m.Y'
);

$view['periodTitle'];   // 'August 2026'
$view['weeks'];         // the weeks, each with its seven days
$view['nextDate'];      // where the '>' button goes
```

## Macros

Macros are reusable operations that can be invoked programmatically within the Analytics platform.

### AddAppointmentMacro

**Macro name:** `addAppointment`  
**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Macro\AddAppointmentMacro`  
**Description:** Adds an appointment to the calendar.

All calendar macros extend `AbstractCalendarMacro`, which sets the macro source to `"InfrastructureBundle"` during initialisation.

```php
// Resolve and run the macro through the Analytics macro runner
$macro = $container->get(AddAppointmentMacro::class);
$macro->init();
$result = $macro->run();
```

> **Note:** The `run()` method currently returns an empty result set. Appointment data input is planned for a future release.

## Permissions

The bundle defines a single permission used to control access to the calendar management interface:

| Permission | Value | Description |
|---|---|---|
| `EPermission::ACCESS_INFRASTRUCTURE` | `ACCESS_INFRASTRUCTURE` | Grants access to the calendar management area |

```php
use Cehlers88\AnalyticsCalendarBundle\ENUM\EPermission;

// Check all bundle permissions
$permissions = EPermission::getPermissions();
// Returns: ['ACCESS_INFRASTRUCTURE']
```

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a full version history.
