/**
 * AnalyticsCalendarBundle – JavaScript entry point.
 *
 * The calendar widget brings its own behaviour along: the markup the server
 * renders carries the script that wires navigation, the day picker and the
 * appointment mask, so nothing here has to start it. What this module adds is
 * the other side of that widget - a typed way for the host application to
 * listen to what happened in it - plus the initialiser of the time widget.
 *
 * Import and call {@link initAnalyticsCalendarBundle} once the DOM is ready in
 * your Symfony application's webpack-encore entry file.
 */

/** The events a calendar widget bubbles up to the document. */
export const CalendarEvents = {
    /** The widget moved to another period or view. */
    navigate: 'analytics-calendar:navigate',
    /** A day was picked, which is what opens the appointment mask. */
    daySelected: 'analytics-calendar:day-selected',
    /** An appointment was saved. */
    appointmentCreated: 'analytics-calendar:appointment-created',
    /** An appointment was deleted. */
    appointmentDeleted: 'analytics-calendar:appointment-deleted',
} as const;

export type CalendarEventName = (typeof CalendarEvents)[keyof typeof CalendarEvents];

export interface CalendarNavigateDetail {
    /** 'month' or 'week' */
    view: string;
    /** The anchor day of the period, as Y-m-d */
    date: string;
}

export interface CalendarDaySelectedDetail {
    /** The picked day, as Y-m-d */
    date: string;
}

export interface CalendarAppointmentCreatedDetail {
    /** Primary key of the stored appointment */
    id?: number;
    /** The day it starts on, as Y-m-d */
    date?: string;
}

export interface CalendarAppointmentDeletedDetail {
    /** Primary key of the removed appointment */
    id: number;
}

/**
 * Listens to one of the events a calendar widget emits.
 *
 * The events bubble, so listening on the document catches every calendar on
 * the page - including the ones a dashboard renders after this call.
 *
 * ```ts
 * import { CalendarEvents, onCalendarEvent } from '@cehlers88/analytics-calendar-bundle';
 *
 * onCalendarEvent(CalendarEvents.appointmentCreated, detail => {
 *     console.log('Termin gespeichert', detail.id);
 * });
 * ```
 *
 * @returns A function that removes the listener again.
 */
export function onCalendarEvent<TDetail = unknown>(
    eventName: CalendarEventName,
    handler: (detail: TDetail, event: CustomEvent<TDetail>) => void,
    target: EventTarget = document
): () => void {
    const listener = (event: Event): void => {
        const customEvent = event as CustomEvent<TDetail>;
        handler(customEvent.detail, customEvent);
    };

    target.addEventListener(eventName, listener);

    return () => target.removeEventListener(eventName, listener);
}

/**
 * Initialises every time widget on the page by starting a one-second interval
 * that updates the element's text content with the current locale time string.
 *
 * Returns a cleanup function that clears the interval when called, which is
 * useful for single-page applications or when widget containers are removed
 * from the DOM.
 *
 * @param containerSelector – CSS selector for the time widget element
 *   (default: `'[data-widget="time"]'`).
 * @returns A function that stops the live-clock interval.
 */
export function initTimeWidget(containerSelector: string = '[data-widget="time"]'): () => void {
    const containers = document.querySelectorAll<HTMLElement>(containerSelector);
    if (containers.length === 0) {
        return () => { /* nothing to clean up */ };
    }

    const update = (): void => {
        const timeStr = new Date().toLocaleTimeString();
        containers.forEach((el) => {
            el.textContent = timeStr;
        });
    };

    update();
    const intervalId = setInterval(update, 1_000);

    return () => clearInterval(intervalId);
}

/**
 * Convenience initialiser for the widgets of this bundle that need one.
 *
 * Intended to be called once the DOM is fully loaded:
 *
 * ```ts
 * import { initAnalyticsCalendarBundle } from '@cehlers88/analytics-calendar-bundle';
 *
 * document.addEventListener('DOMContentLoaded', () => {
 *     initAnalyticsCalendarBundle();
 * });
 * ```
 *
 * @returns A function that stops what was started.
 */
export function initAnalyticsCalendarBundle(): () => void {
    return initTimeWidget();
}

export default initAnalyticsCalendarBundle;
