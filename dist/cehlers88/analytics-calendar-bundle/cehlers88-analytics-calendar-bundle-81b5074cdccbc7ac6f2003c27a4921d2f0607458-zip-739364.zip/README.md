# AnalyticsCalendarBundle

A Symfony bundle for managing calendar appointments and events within the Analytics platform. It provides dashboard widgets, appointment scheduling, configurable date/time formats, and a macro system for programmatic calendar operations.

## Table of Contents

- [Requirements](#requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [JavaScript / Webpack Encore Integration](#javascript--webpack-encore-integration)
- [Widgets](#widgets)
  - [Calendar Widget](#calendar-widget)
  - [Time Widget](#time-widget)
- [Entity: Appointment](#entity-appointment)
- [Repository: AppointmentRepository](#repository-appointmentrepository)
- [Macros](#macros)
  - [AddAppointmentMacro](#addappointmentmacro)
- [Permissions](#permissions)
- [Changelog](#changelog)

## Requirements

- PHP 8.0+
- Symfony 6.0+
- `cehlers88/analytics-core` ^0.3

## Installation

### 1. Add the custom Satis repository to your `composer.json`

```json
{
    "repositories": [
        {
            "type": "composer",
            "url": "https://cehlers88.github.io/satis"
        }
    ]
}
```

### 2. Install the bundle via Composer

```bash
composer require cehlers88/analytics-calendar-bundle
```

### 3. Register the bundle (if not using Symfony Flex auto-discovery)

```php
// config/bundles.php
return [
    // ...
    Cehlers88\AnalyticsCalendarBundle\AnalyticsCalendarBundle::class => ['all' => true],
];
```

### 4. Update the database schema

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

This creates the `calendar_appointment` table used by the `Appointment` entity.

## JavaScript / Webpack Encore Integration

The bundle ships its JavaScript assets in `assets/index.ts` and exposes a
`package.json` so it can be registered as a local npm module in the host
Symfony application.  Follow the steps below to include the bundle's
JavaScript in your webpack-encore build.

### 1. Register the bundle as a local npm package

Add the bundle as a file-based dependency in your application's `package.json`:

```json
{
    "dependencies": {
        "@cehlers88/analytics-calendar-bundle": "file:vendor/cehlers88/analytics-calendar-bundle"
    }
}
```

Then install the new dependency:

```bash
yarn install
# or
npm install
```

This creates a symlink at
`node_modules/@cehlers88/analytics-calendar-bundle` that points to the
vendor directory, so webpack can resolve the module.

### 2. Add an entry point in `webpack.config.js`

Open your application's `webpack.config.js` and add an entry that imports
the bundle's assets:

```js
// webpack.config.js
const Encore = require('@symfony/webpack-encore');

Encore
    // … your existing configuration …
    .addEntry('analytics-calendar-bundle', '@cehlers88/analytics-calendar-bundle')
;

module.exports = Encore.getWebpackConfig();
```

> **Tip:** If you prefer to bundle the calendar assets together with your
> main application entry point instead of creating a separate file, you can
> import the module inside your existing entry file (e.g.
> `assets/app.ts`):
>
> ```ts
> import { initAnalyticsCalendarBundle } from '@cehlers88/analytics-calendar-bundle';
>
> document.addEventListener('DOMContentLoaded', () => {
>     initAnalyticsCalendarBundle();
> });
> ```

### 3. Build the assets

```bash
yarn encore dev   # development build
yarn encore prod  # production build
```

### 4. Include the compiled script in your Twig template

If you added a dedicated entry point in step 2, include it via the
`encore_entry_script_tags` helper:

```twig
{# base.html.twig #}
{{ encore_entry_script_tags('analytics-calendar-bundle') }}
```

### Available exports

| Export | Description |
| --- | --- |
| `initAnalyticsCalendarBundle()` | Convenience function – calls both initialisers below with their default selectors. |
| `initCalendarWidget(selector?)` | Highlights today's tile and wires navigation-button click events for every `button[data-calendar-nav]` element inside the same parent as `selector` (default: `'.calendar'`). Each button click dispatches a bubbling `analytics-calendar:navigate` CustomEvent with `detail.view` set to the button's label. |
| `initTimeWidget(selector?)` | Starts a one-second interval that updates the text content of every element matching `selector` (default: `'[data-widget="time"]'`) with the current locale time string. Clears any previously created interval to prevent memory leaks. |

#### Listening to navigation events

```ts
document.addEventListener('analytics-calendar:navigate', (event: Event) => {
    const { view } = (event as CustomEvent<{ view: string }>).detail;
    console.log('Calendar navigation requested:', view);
    // 'Monatsübersicht' | 'Heute' | 'Diese Woche'
});
```

#### Marking a time widget container in Twig

The time widget template uses a plain `time` string as its content. Add the
`data-widget="time"` attribute to the element you want the live clock to
target:

```twig
{# templates/widget/time.html.twig #}
<span data-widget="time"></span>
```

## Configuration

The bundle exposes a **General Calendar Settings** group under the key `calendarBundle.general`, accessible through the *Kalenderverwaltung* (Calendar Management) menu in the Analytics admin panel.

| Configuration Key | Label | Type | Default | Description |
|---|---|---|---|---|
| `calendarBundle.general.defaultDateFormat` | Standard Datumsformat | Text | `d.m.Y` | PHP date format used for displaying dates |
| `calendarBundle.general.defaultTimeFormat` | Standard Zeitformat | Text | `H:i` | PHP date format used for displaying times |
| `calendarBundle.general.defaultDateTimeFormat` | Standard Datums- und Zeitformat | Text | `d.m.Y H:i` | PHP date format used for displaying date and time together |
| `calendarBundle.general.defaultWeekStart` | Standard Wochenstart | Select | `1` (Monday) | First day of the week: 1 = Monday … 7 = Sunday |

## Widgets

### Calendar Widget

**Widget name:** `calendar`

Renders a monthly calendar grid (5 rows × 7 columns) in a dark-themed card. The widget exposes navigation buttons for *Monatsübersicht* (month view), *Heute* (today), and *Diese Woche* (this week).

**Required role:** `ROLE_USER`

**Preload placeholders layout:**

| Row | Height | Column widths |
|-----|--------|---------------|
| 1 | 50 px | 33 % · 33 % · 33 % |
| 2 | 220 px | 100 % |
| 3 | 50 px | 75 % · 25 % |

**Template:** `templates/widget/calendar.html.twig`

The template receives a `lines` property containing a two-dimensional array of day numbers that represents the calendar grid:

```php
[
    [1,  2,  3,  4,  5,  6,  7],
    [8,  9,  10, 11, 12, 13, 14],
    [15, 16, 17, 18, 19, 20, 21],
    [22, 23, 24, 25, 26, 27, 28],
    [29, 30, 31,  1,  2,  3,  4],
]
```

### Time Widget

**Widget name:** `time`

A minimal widget that displays the current time.

**Preload placeholders layout:**

| Row | Height | Column widths |
|-----|--------|---------------|
| 1 | 50 px | 50 % · 50 % |

**Template:** `templates/widget/time.html.twig`

## Entity: Appointment

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Entity\Appointment`  
**Database table:** `calendar_appointment`

| Property | Type | Nullable | Description |
|----------|------|----------|-------------|
| `id` | `int` | No | Auto-generated primary key |
| `title` | `string(255)` | No | Title of the appointment |
| `description` | `text` | Yes | Optional detailed description |
| `startDate` | `DateTime` | No | Start date and time |
| `endDate` | `DateTime` | Yes | Optional end date and time |
| `repeatInterval` | `int` | Yes | Recurrence interval in days |
| `reminderTimer` | `int` | Yes | Reminder offset in seconds before the appointment |

**Example usage:**

```php
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;

$appointment = new Appointment();
$appointment
    ->setTitle('Team Meeting')
    ->setStartDate(new \DateTime('2026-04-01 10:00'))
    ->setEndDate(new \DateTime('2026-04-01 11:00'))
    ->setDescription('Weekly sync call')
    ->setRepeatInterval(7)      // repeats every 7 days
    ->setReminderTimer(900);    // reminder 15 minutes (900 s) before start

$entityManager->persist($appointment);
$entityManager->flush();
```

All setters return `static` to allow method chaining.

## Repository: AppointmentRepository

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository`

Extends `Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository` and provides all standard Doctrine query methods out of the box:

```php
// Inject the repository via autowiring or fetch from the entity manager
$repository = $entityManager->getRepository(Appointment::class);

// Find all appointments
$appointments = $repository->findAll();

// Find a single appointment by primary key
$appointment = $repository->find($id);

// Find appointments matching specific criteria
$appointments = $repository->findBy(['title' => 'Team Meeting']);
```

## Macros

Macros are reusable operations that can be invoked programmatically within the Analytics platform.

### AddAppointmentMacro

**Macro name:** `addAppointment`  
**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Macro\AddAppointmentMacro`  
**Description:** Adds an appointment to the calendar.

All calendar macros extend `AbstractCalendarMacro`, which sets the macro source to `"InfrastructureBundle"` during initialisation.

```php
// Resolve and run the macro through the Analytics macro runner
$macro = $container->get(AddAppointmentMacro::class);
$macro->init();
$result = $macro->run();
```

> **Note:** The `run()` method currently returns an empty result set. Appointment data input is planned for a future release.

## Permissions

The bundle defines a single permission used to control access to the calendar management interface:

| Permission | Value | Description |
|---|---|---|
| `EPermission::ACCESS_INFRASTRUCTURE` | `ACCESS_INFRASTRUCTURE` | Grants access to the calendar management area |

```php
use Cehlers88\AnalyticsCalendarBundle\ENUM\EPermission;

// Check all bundle permissions
$permissions = EPermission::getPermissions();
// Returns: ['ACCESS_INFRASTRUCTURE']
```

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a full version history.
