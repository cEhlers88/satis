/**
 * AnalyticsCalendarBundle – JavaScript entry point.
 *
 * Exports initialisation helpers for the calendar and time widgets that this
 * bundle renders.  Import and call {@link initAnalyticsCalendarBundle} once
 * the DOM is ready in your Symfony application's webpack-encore entry file.
 */

/**
 * Initialises every calendar widget on the page.
 *
 * - Highlights today's day-tile with a visible outline.
 *   **Note:** the highlight is based solely on the day-of-month number that
 *   each tile displays.  If the widget renders a month other than the current
 *   one, tiles whose number coincidentally matches today's date will also be
 *   highlighted.  To avoid this, add a `data-calendar-month` and
 *   `data-calendar-year` attribute to the calendar container from your Twig
 *   template and filter accordingly in your own initialisation logic.
 * - Attaches click handlers to the navigation buttons (Monatsübersicht, Heute,
 *   Diese Woche) and dispatches a bubbling CustomEvent
 *   `analytics-calendar:navigate` whose `detail.view` property contains the
 *   button label so the host application can react to navigation requests.
 *
 * @param containerSelector – CSS selector for the calendar grid element
 *   (default: `'.calendar'`).
 */
export function initCalendarWidget(containerSelector: string = '.calendar'): void {
    const calendars = document.querySelectorAll<HTMLElement>(containerSelector);

    calendars.forEach((calendar) => {
        // Highlight the tile that matches today's day-of-month number.
        const today = new Date().getDate();
        calendar.querySelectorAll<HTMLElement>('.tile').forEach((tile) => {
            if (parseInt(tile.textContent ?? '', 10) === today) {
                tile.classList.add('tile--today');
            }
        });

        // Wire navigation buttons that are expected to be direct children of
        // the same parent container, identified by the data-calendar-nav attribute.
        const parent = calendar.parentElement;
        if (!parent) {
            return;
        }

        parent.querySelectorAll<HTMLButtonElement>('button[data-calendar-nav]').forEach((button) => {
            button.addEventListener('click', () => {
                calendar.dispatchEvent(
                    new CustomEvent('analytics-calendar:navigate', {
                        bubbles: true,
                        detail: { view: button.textContent?.trim() ?? '' },
                    })
                );
            });
        });
    });
}

/**
 * Initialises every time widget on the page by starting a one-second interval
 * that updates the element's text content with the current locale time string.
 *
 * Returns a cleanup function that clears the interval when called, which is
 * useful for single-page applications or when widget containers are removed
 * from the DOM.
 *
 * @param containerSelector – CSS selector for the time widget element
 *   (default: `'[data-widget="time"]'`).
 * @returns A function that stops the live-clock interval.
 */
export function initTimeWidget(containerSelector: string = '[data-widget="time"]'): () => void {
    const containers = document.querySelectorAll<HTMLElement>(containerSelector);
    if (containers.length === 0) {
        return () => { /* nothing to clean up */ };
    }

    const update = (): void => {
        const timeStr = new Date().toLocaleTimeString();
        containers.forEach((el) => {
            el.textContent = timeStr;
        });
    };

    update();
    const intervalId = setInterval(update, 1_000);

    return () => clearInterval(intervalId);
}

/**
 * Convenience initialiser – calls {@link initCalendarWidget} and
 * {@link initTimeWidget} with their default selectors.
 *
 * Intended to be called once the DOM is fully loaded:
 *
 * ```ts
 * import { initAnalyticsCalendarBundle } from '@cehlers88/analytics-calendar-bundle';
 *
 * document.addEventListener('DOMContentLoaded', () => {
 *     initAnalyticsCalendarBundle();
 * });
 * ```
 */
export function initAnalyticsCalendarBundle(): void {
    initCalendarWidget();
    initTimeWidget();
}

export default initAnalyticsCalendarBundle;
