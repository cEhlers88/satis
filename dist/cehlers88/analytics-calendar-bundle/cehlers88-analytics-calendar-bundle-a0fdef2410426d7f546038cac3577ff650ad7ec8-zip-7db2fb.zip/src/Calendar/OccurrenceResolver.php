<?php

namespace Cehlers88\AnalyticsCalendarBundle\Calendar;

use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;

/**
 * Knows when an appointment happens: the occurrences a series puts into a
 * range, the occurrence that started last and where an occurrence ends.
 *
 * The calendar and the command worker both ask here, so a recurrence rule is
 * only ever interpreted in one place. An occurrence keeps the wall-clock times
 * of the appointment - it is the appointment moved by whole days.
 */
class OccurrenceResolver
{
    /** A series that never leaves the range must still not loop forever. */
    private const MAX_OCCURRENCES = 400;

    public function __construct(private WorkWeek $workWeek = new WorkWeek())
    {
    }

    /**
     * The ISO weekdays a day-based series falls on, or null for a type that
     * does not repeat by weekday.
     *
     * @return int[]|null
     */
    public function repeatDaysOf(Appointment $appointment): ?array
    {
        return match ($appointment->getRepeatType()) {
            eRepeatType::WEEKDAYS => $this->workWeek->workDays(),
            eRepeatType::WEEKEND => $this->workWeek->weekendDays(),
            eRepeatType::DAYS => $appointment->getRepeatDays(),
            default => null,
        };
    }

    /**
     * The occurrences of an appointment that touch the range - a single one for
     * an appointment that does not repeat.
     *
     * @return \Generator<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    public function occurrencesBetween(
        Appointment        $appointment,
        \DateTimeImmutable $rangeStart,
        \DateTimeImmutable $rangeEnd
    ): \Generator {
        $start = $this->startOf($appointment);
        $end = $this->endOfSeriesStart($appointment);

        $repeatDays = $this->repeatDaysOf($appointment);

        if ($repeatDays !== null) {
            yield from $this->expandDays($start, $end, $repeatDays, $rangeStart, $rangeEnd);

            return;
        }

        if ($appointment->getRepeatType() === eRepeatType::INTERVAL) {
            yield from $this->expandInterval($start, $end, (int)$appointment->getRepeatInterval(), $rangeStart, $rangeEnd);

            return;
        }

        if (($end ?? $start) >= $rangeStart && $start <= $rangeEnd) {
            yield [$start, $end];
        }
    }

    /**
     * The start of the last occurrence that began at or before the moment, or
     * null while the appointment has not started yet.
     */
    public function latestStartAtOrBefore(Appointment $appointment, \DateTimeImmutable $moment): ?\DateTimeImmutable
    {
        $start = $this->startOf($appointment);

        if ($start > $moment) {
            return null;
        }

        $daysSinceStart = $this->daysBetween($start, $moment);

        if ($appointment->getRepeatType() === eRepeatType::INTERVAL) {
            $interval = (int)$appointment->getRepeatInterval();
            $offset = intdiv($daysSinceStart, $interval) * $interval;

            if ($this->shift($start, $offset) > $moment) {
                $offset -= $interval;
            }

            return $offset >= 0 ? $this->shift($start, $offset) : null;
        }

        $repeatDays = $this->repeatDaysOf($appointment);

        if ($repeatDays !== null) {
            // Every weekday comes round within a week, so a week back always
            // reaches the last occurrence - if the series has any day at all.
            for ($offset = $daysSinceStart; $offset >= max(0, $daysSinceStart - 7); $offset--) {
                $candidate = $this->shift($start, $offset);

                if ($candidate <= $moment && $this->fallsOn($candidate, $repeatDays)) {
                    return $candidate;
                }
            }

            return null;
        }

        return $start;
    }

    /**
     * The moment the occurrence that starts at the given moment is over - null
     * for an appointment without an end.
     *
     * An all-day appointment is stored from midnight to midnight of its last
     * day, and the calendar shows it on that last day too - so it is only over
     * once that day has passed.
     */
    public function endOf(Appointment $appointment, \DateTimeInterface $occurrenceStart): ?\DateTimeImmutable
    {
        $start = $this->startOf($appointment);
        $end = $this->endOfSeriesStart($appointment);

        if ($end === null) {
            return null;
        }

        if ($start->format('H:i') === '00:00' && $end->format('H:i:s') === '00:00:00') {
            $end = $end->modify('+1 day');
        }

        $occurrenceStart = \DateTimeImmutable::createFromInterface($occurrenceStart);

        return $this->shift($end, $this->daysBetween($start, $occurrenceStart));
    }

    /**
     * @return \Generator<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    private function expandInterval(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        int                 $interval,
        \DateTimeImmutable  $rangeStart,
        \DateTimeImmutable  $rangeEnd
    ): \Generator {
        // Skipping straight to the first occurrence that can still be in the
        // range keeps a long-running series from being walked from its start.
        $daysBehind = $this->daysBetween($start, $rangeStart);
        $step = $daysBehind > 0 ? intdiv($daysBehind, $interval) : 0;

        for ($i = 0; $i < self::MAX_OCCURRENCES; $i++, $step++) {
            $offset = $step * $interval;
            $occurrenceStart = $this->shift($start, $offset);

            if ($occurrenceStart > $rangeEnd) {
                return;
            }

            $occurrenceEnd = $end === null ? null : $this->shift($end, $offset);

            if (($occurrenceEnd ?? $occurrenceStart) >= $rangeStart) {
                yield [$occurrenceStart, $occurrenceEnd];
            }
        }
    }

    /**
     * Every day of the given weekdays from the start of the series on. The
     * walk begins as many days before the range as an occurrence lasts, so one
     * that began earlier and still runs into the range is not lost.
     *
     * @param int[] $repeatDays ISO weekdays - none yields nothing
     *
     * @return \Generator<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    private function expandDays(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        array               $repeatDays,
        \DateTimeImmutable  $rangeStart,
        \DateTimeImmutable  $rangeEnd
    ): \Generator {
        if ($repeatDays === []) {
            return;
        }

        $spanDays = $end === null ? 0 : max(0, $this->daysBetween($start, $end));
        $day = max($start->setTime(0, 0), $this->shift($rangeStart->setTime(0, 0), -$spanDays));

        for ($i = 0; $i < self::MAX_OCCURRENCES; $i++, $day = $day->modify('+1 day')) {
            if (!$this->fallsOn($day, $repeatDays)) {
                continue;
            }

            $offset = $this->daysBetween($start, $day);
            $occurrenceStart = $this->shift($start, $offset);

            if ($occurrenceStart > $rangeEnd) {
                return;
            }

            $occurrenceEnd = $end === null ? null : $this->shift($end, $offset);

            if (($occurrenceEnd ?? $occurrenceStart) >= $rangeStart) {
                yield [$occurrenceStart, $occurrenceEnd];
            }
        }
    }

    private function startOf(Appointment $appointment): \DateTimeImmutable
    {
        return \DateTimeImmutable::createFromInterface($appointment->getStartDate());
    }

    private function endOfSeriesStart(Appointment $appointment): ?\DateTimeImmutable
    {
        return $appointment->getEndDate() === null
            ? null
            : \DateTimeImmutable::createFromInterface($appointment->getEndDate());
    }

    /** Whole calendar days from one date to the other, negative when going back. */
    private function daysBetween(\DateTimeImmutable $from, \DateTimeImmutable $to): int
    {
        $difference = $from->setTime(0, 0)->diff($to->setTime(0, 0));

        return $difference->invert ? -$difference->days : $difference->days;
    }

    private function shift(\DateTimeImmutable $moment, int $days): \DateTimeImmutable
    {
        return $moment->modify(sprintf('%+d days', $days));
    }

    /**
     * @param int[] $repeatDays
     */
    private function fallsOn(\DateTimeImmutable $day, array $repeatDays): bool
    {
        return in_array((int)$day->format('N'), $repeatDays, true);
    }
}
