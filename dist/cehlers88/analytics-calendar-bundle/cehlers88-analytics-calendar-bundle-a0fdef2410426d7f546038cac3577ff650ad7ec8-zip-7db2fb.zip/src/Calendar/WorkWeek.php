<?php

namespace Cehlers88\AnalyticsCalendarBundle\Calendar;

use Cehlers88\AnalyticsCalendarBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;

/**
 * Which weekdays are work days and which are the weekend.
 *
 * The work week runs from the configured start of the week up to the
 * configured end of the work week; every day after that, up to the next start
 * of the week, is weekend. With the defaults that is Monday to Friday and
 * Saturday plus Sunday.
 *
 * Weekdays are ISO numbers: 1 = Monday … 7 = Sunday.
 */
class WorkWeek
{
    public const DEFAULT_WEEK_START = 1;
    public const DEFAULT_WORK_WEEK_END = 5;

    public function __construct(private ?ConfigurationProvider $configurationProvider = null)
    {
    }

    /**
     * @return int[] the work days, in the order of the week
     */
    public function workDays(): array
    {
        return self::daysFromTo($this->weekStart(), $this->workWeekEnd());
    }

    /**
     * @return int[] the weekend days, in the order of the week - none when the
     *               work week covers the whole week
     */
    public function weekendDays(): array
    {
        return array_values(array_diff(self::daysFromTo($this->weekStart(), ($this->weekStart() + 5) % 7 + 1), $this->workDays()));
    }

    public function isWeekend(int $isoWeekday): bool
    {
        return in_array($isoWeekday, $this->weekendDays(), true);
    }

    public function weekStart(): int
    {
        return self::clampDay($this->configurationValue('defaultWeekStart', self::DEFAULT_WEEK_START));
    }

    public function workWeekEnd(): int
    {
        return self::clampDay($this->configurationValue('workWeekEnd', self::DEFAULT_WORK_WEEK_END));
    }

    /**
     * The days from one weekday to another, both included, wrapping over the
     * end of the ISO week (Saturday to Monday is 6, 7, 1).
     *
     * @throws \InvalidArgumentException for a day outside 1 … 7
     * @return int[]
     */
    public static function daysFromTo(int $from, int $to): array
    {
        // Any other number would never be reached by the walk below.
        if ($from < 1 || $from > 7 || $to < 1 || $to > 7) {
            throw new \InvalidArgumentException(sprintf('Weekdays must be ISO weekdays 1 … 7, got %d and %d.', $from, $to));
        }

        $days = [$from];

        for ($day = $from; $day !== $to;) {
            $day = $day % 7 + 1;
            $days[] = $day;
        }

        return $days;
    }

    private static function clampDay(mixed $value): int
    {
        return min(7, max(1, (int)$value));
    }

    private function configurationValue(string $key, int $default): mixed
    {
        if ($this->configurationProvider === null) {
            return $default;
        }

        try {
            $value = $this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, $key, -1, $default);
        } catch (\Throwable) {
            return $default;
        }

        return $value === null || $value === '' ? $default : $value;
    }
}
