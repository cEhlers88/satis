<?php

namespace Cehlers88\AnalyticsCalendarBundle\ENUM;

/**
 * How an appointment repeats. An interval counts its days in
 * Appointment::$repeatInterval, a day selection lists its weekdays in
 * Appointment::$repeatDays; the other types need no further value.
 *
 * WEEKDAYS and WEEKEND follow the configured work week (Calendar\WorkWeek) -
 * Monday to Friday and Saturday plus Sunday unless configured otherwise.
 * WEEKDAYS keeps its stored value so existing series stay what they were.
 */
enum eRepeatType: string
{
    case NONE = 'none';
    case INTERVAL = 'interval';
    case WEEKDAYS = 'weekdays';
    case WEEKEND = 'weekend';
    case DAYS = 'days';

    public static function getLabel(eRepeatType $type): string
    {
        return match ($type) {
            self::NONE => 'Einmalig',
            self::INTERVAL => 'Intervall',
            self::WEEKDAYS => 'Arbeitswoche',
            self::WEEKEND => 'Wochenende',
            self::DAYS => 'Ausgewählte Wochentage',
        };
    }

    /**
     * The types that repeat on certain weekdays rather than every n days.
     *
     * @return self[]
     */
    public static function dayBasedTypes(): array
    {
        return [self::WEEKDAYS, self::WEEKEND, self::DAYS];
    }
}
