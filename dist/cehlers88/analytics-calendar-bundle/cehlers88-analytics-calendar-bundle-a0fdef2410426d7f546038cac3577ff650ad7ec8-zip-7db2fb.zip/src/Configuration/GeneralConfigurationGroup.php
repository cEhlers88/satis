<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 12:03
 */

namespace Cehlers88\AnalyticsCalendarBundle\Configuration;

use Cehlers88\AnalyticsCalendarBundle\Calendar\WorkWeek;
use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;

class GeneralConfigurationGroup extends AbstractConfigurationGroup
{
    public const KEY = 'calendarBundle.general';

    public function getItems(): array
    {
        $weekdays = [
            ['value' => '1', 'label' => 'Montag'],
            ['value' => '2', 'label' => 'Dienstag'],
            ['value' => '3', 'label' => 'Mittwoch'],
            ['value' => '4', 'label' => 'Donnerstag'],
            ['value' => '5', 'label' => 'Freitag'],
            ['value' => '6', 'label' => 'Samstag'],
            ['value' => '7', 'label' => 'Sonntag'],
        ];

        $weekStartSelect = ConfigurationItemDTO::create('defaultWeekStart', 'Standard Wochenstart', eInputType::SELECT, '1');
        $weekStartSelect->children = $weekdays;

        // The day after it starts the weekend (WorkWeek), which the repetitions
        // "Arbeitswoche" and "Wochenende" follow.
        $workWeekEndSelect = ConfigurationItemDTO::create('workWeekEnd', 'Ende der Arbeitswoche', eInputType::SELECT, (string)WorkWeek::DEFAULT_WORK_WEEK_END);
        $workWeekEndSelect->children = $weekdays;

        return [
            ConfigurationItemDTO::create('defaultDateFormat', 'Standard Datumsformat', eInputType::TEXT_SINGLE_LINE, 'd.m.Y'),
            ConfigurationItemDTO::create('defaultTimeFormat', 'Standard Zeitformat', eInputType::TEXT_SINGLE_LINE, 'H:i'),
            ConfigurationItemDTO::create('defaultDateTimeFormat', 'Standard Datums- und Zeitformat', eInputType::TEXT_SINGLE_LINE, 'd.m.Y H:i'),
            $weekStartSelect,
            $workWeekEndSelect,
        ];
    }

    public function getKey(): string
    {
        return self::KEY;
    }

    public function getGroupTitle(): string
    {
        return 'Allgemeine Kalendereinstellungen';
    }

    public function getGroupDescription(): string
    {
        return 'Allgemeine Einstellungen für das Kalendermodul';
    }
}