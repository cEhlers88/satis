<?php

namespace Cehlers88\AnalyticsCalendarBundle\Repository;

use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCore\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Appointment>
 */
class AppointmentRepository extends ServiceEntityRepository
{
    /** DQL condition for a series; expects the parameter "dayTypes" (dayTypeValues()). */
    private const IS_REPEATING = '(COALESCE(appointment.repeatInterval, 0) > 0 OR appointment.repeatType IN (:dayTypes))';

    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Appointment::class);
    }

    public function save(Appointment $appointment, bool $flush = true): Appointment
    {
        $this->getEntityManager()->persist($appointment);

        if ($flush) {
            $this->getEntityManager()->flush();
        }

        return $appointment;
    }

    public function remove(Appointment $appointment, bool $flush = true): void
    {
        $this->getEntityManager()->remove($appointment);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    /**
     * Every appointment of the user that can put an occurrence into the given
     * range.
     *
     * A repeating appointment is one of them as soon as its series starts
     * before the range ends - which of its occurrences actually land inside is
     * decided while the series is expanded, not here.
     *
     * @return Appointment[]
     */
    public function findInRange(\DateTimeInterface $from, \DateTimeInterface $to, User $user): array
    {
        return $this->createQueryBuilder('appointment')
            ->innerJoin('appointment.users', 'assignedUser')
            ->andWhere('assignedUser.id = :userId')
            ->setParameter('userId', $user->getId())
            ->andWhere('appointment.startDate <= :to')
            ->andWhere(
                '(COALESCE(appointment.endDate, appointment.startDate) >= :from'
                . ' OR ' . self::IS_REPEATING . ')'
            )
            ->setParameter('from', $from)
            ->setParameter('to', $to)
            ->setParameter('dayTypes', self::dayTypeValues())
            ->orderBy('appointment.startDate', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /** The appointment with the id, as long as it is assigned to the user. */
    public function findOneForUser(int $id, User $user): ?Appointment
    {
        return $this->createQueryBuilder('appointment')
            ->innerJoin('appointment.users', 'assignedUser')
            ->andWhere('appointment.id = :id')
            ->andWhere('assignedUser.id = :userId')
            ->setParameter('id', $id)
            ->setParameter('userId', $user->getId())
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * Every appointment with commands the worker may still have to run: it has
     * begun, and it is a series or a single appointment that is not done yet.
     *
     * A single appointment is done once its current start has been started and -
     * if it has an end - ended, or when it ended without ever being started.
     * "Its current start" matters: an appointment that ran before and was then
     * moved to a new time still carries the markers of that earlier run, so
     * they count only while they belong to the current start. Checking them for
     * NULL alone dropped such an appointment once its end had passed, and it
     * was never ended.
     *
     * @return Appointment[]
     */
    public function findWithPendingCommands(\DateTimeInterface $now): array
    {
        return $this->createQueryBuilder('appointment')
            ->andWhere('appointment.startDate <= :now')
            ->andWhere(
                '(appointment.startCommands IS NOT NULL'
                . ' OR appointment.endCommands IS NOT NULL'
                . ' OR appointment.firstStartCommands IS NOT NULL)'
            )
            ->andWhere(
                '(' . self::IS_REPEATING
                // not started for its current start yet, and not over either
                . ' OR ((appointment.lastStartedOccurrence IS NULL'
                . ' OR appointment.lastStartedOccurrence <> appointment.startDate)'
                . ' AND (appointment.endDate IS NULL OR appointment.endDate >= :now))'
                // running: started, but that start not ended yet
                . ' OR (appointment.endDate IS NOT NULL'
                . ' AND appointment.lastStartedOccurrence IS NOT NULL'
                . ' AND (appointment.lastEndedOccurrence IS NULL'
                . ' OR appointment.lastEndedOccurrence <> appointment.lastStartedOccurrence)))'
            )
            ->setParameter('now', $now)
            ->setParameter('dayTypes', self::dayTypeValues())
            ->orderBy('appointment.startDate', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @return string[] the stored values of the types that repeat by weekday
     */
    private static function dayTypeValues(): array
    {
        return array_map(static fn(eRepeatType $type): string => $type->value, eRepeatType::dayBasedTypes());
    }
}
