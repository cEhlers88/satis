<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 12:00
 */

namespace Cehlers88\AnalyticsCalendarBundle;

use Cehlers88\AnalyticsCalendarBundle\ENUM\EPermission;
use Cehlers88\AnalyticsCore\Support\AbstractBundlePlugin;
use Cehlers88\AnalyticsCore\Support\DTO\UI\MenuItemDTO;

class AnalyticsCalendarBundle extends AbstractBundlePlugin
{
    public static function getBundleName(): string
    {
        return new AnalyticsCalendarBundle()->getName();
    }

    public function getDescription(): string
    {
        return 'Bundle zur Verwaltung von Termininformationen.';
    }

    public function getMenuItems(): array
    {
        return [
            MenuItemDTO::create('Kalenderverwaltung', 'analytics_calendar_settings', [], '', [])
        ];
    }

    public function getPermissions(): array
    {
        return EPermission::getPermissions();
    }

    public function getVersion(): string
    {
        return '1.0.0';
    }

    public function handleInstall(): array
    {
        return [];
    }
}