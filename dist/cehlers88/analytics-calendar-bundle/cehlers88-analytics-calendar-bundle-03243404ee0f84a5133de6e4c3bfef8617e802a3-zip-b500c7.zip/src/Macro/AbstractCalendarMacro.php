<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 19:34
 */

namespace Cehlers88\AnalyticsCalendarBundle\Macro;

use Cehlers88\AnalyticsCore\Macro\AbstractMacro;

abstract class AbstractCalendarMacro extends AbstractMacro
{
    public function init(): AbstractCalendarMacro
    {
        $this->_source = "CalendarBundle";
        return $this->_init();
    }

    abstract protected function _init(): AbstractCalendarMacro;
}