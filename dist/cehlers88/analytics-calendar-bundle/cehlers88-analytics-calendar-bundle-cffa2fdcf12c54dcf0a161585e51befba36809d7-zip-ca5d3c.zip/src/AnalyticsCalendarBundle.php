<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 12:00
 */
namespace Cehlers88\AnalyticsCalendarBundle;

use Analytics\AbstractBundlePlugin;
use Analytics\DTO\UI\MenuItemDTO;
use Cehlers88\AnalyticsCalendarBundle\ENUM\EPermission;

class AnalyticsCalendarBundle extends AbstractBundlePlugin {

    public function getDescription():string {
        return 'Bundle zur Verwaltung von Termininformationen.';
    }
    public function getMenuItems():array {
        return [
            MenuItemDTO::create('Kalenderverwaltung', 'analytics_calendar_settings', [], '', [])
        ];
    }
    public function getPermissions():array {
        return EPermission::getPermissions();
    }
    public function getVersion():string {
        return '1.0.0';
    }
    public function handleInstall():array {
        return [];
    }
}