<?php

namespace Cehlers88\AnalyticsCalendarBundle\Widget;

use Analytics\Widget\AbstractWidget;

class TimeWidget extends AbstractWidget
{
    public function getName() : string {
        return 'time'; // bundle.widget
    }
    public function getPreloadPlaceholders(): array {
        return [
            ['height'=>'50px','boxes'=>[.5,.5]] // 30px height, 50% width for each box
        ];
    }
}