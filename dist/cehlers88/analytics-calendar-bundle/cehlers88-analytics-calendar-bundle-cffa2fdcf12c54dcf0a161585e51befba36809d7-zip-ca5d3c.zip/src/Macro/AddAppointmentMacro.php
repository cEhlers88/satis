<?php

namespace Cehlers88\AnalyticsCalendarBundle\Macro;

class AddAppointmentMacro extends AbstractCalendarMacro {

    public function __construct(

    ) {}

    protected function run(): ?array {
        return $this->_createRunResult([]);
    }

    public function _init(): AddAppointmentMacro {
        return $this;
    }

    public function getDescription(): string {
        return 'Add an appointment to the calendar';
    }

    public function getName(): string {
        return 'addAppointment';
    }
}