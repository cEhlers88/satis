<?php

namespace Cehlers88\AnalyticsCalendarBundle\Widget;

use Analytics\Widget\AbstractWidget;

class CalendarWidget extends AbstractWidget
{
    public function enrichProperties(array $properties): array
    {
        $properties['lines'] = [
            [1,2,3,4,5,6,7],
            [8,9,10,11,12,13,14],
            [15,16,17,18,19,20,21],
            [22,23,24,25,26,27,28],
            [29,30,31,1,2,3,4],
        ];
        return $properties;
    }
    public function getName() : string {
        return 'calendar';
    }
    public function getPreloadPlaceholders(): array {
        return [
            ['height'=>'50px','boxes'=>[.33,.33,.33]], // 30px height, 33% width for each box
            ['height'=>'220px','boxes'=>[1]], // 120px height, 100% width for 1 box
            ['height'=>'50px','boxes'=>[.75,.25]] // 30px height, 75% width for the first box and 25% width for the second box
        ];
    }

    public function getRequiredRoles(): array
    {
        return [
            'ROLE_USER'
        ];
    }
}