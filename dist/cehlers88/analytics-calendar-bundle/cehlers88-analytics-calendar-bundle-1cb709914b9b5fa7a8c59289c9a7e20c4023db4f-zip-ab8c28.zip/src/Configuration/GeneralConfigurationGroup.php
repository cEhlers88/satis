<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 26.05.2024
 * Time: 12:03
 */

namespace Cehlers88\AnalyticsCalendarBundle\Configuration;

use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\ENUM\eInputType;

class GeneralConfigurationGroup extends AbstractConfigurationGroup {
    public function getItems(): array {
        $weekStartSelect = ConfigurationItemDTO::create($this->getKey().'.defaultWeekStart', 'Standard Wochenstart', eInputType::SELECT, '1');
        $weekStartSelect->children = [
            ['value' => '1', 'label' => 'Montag'],
            ['value' => '2', 'label' => 'Dienstag'],
            ['value' => '3', 'label' => 'Mittwoch'],
            ['value' => '4', 'label' => 'Donnerstag'],
            ['value' => '5', 'label' => 'Freitag'],
            ['value' => '6', 'label' => 'Samstag'],
            ['value' => '7', 'label' => 'Sonntag'],
        ];

        return [
            ConfigurationItemDTO::create($this->getKey().'.defaultDateFormat', 'Standard Datumsformat', eInputType::TEXT_SINGLE_LINE, 'd.m.Y'),
            ConfigurationItemDTO::create($this->getKey().'.defaultTimeFormat', 'Standard Zeitformat', eInputType::TEXT_SINGLE_LINE, 'H:i'),
            ConfigurationItemDTO::create($this->getKey().'.defaultDateTimeFormat', 'Standard Datums- und Zeitformat', eInputType::TEXT_SINGLE_LINE, 'd.m.Y H:i'),
            $weekStartSelect,
        ];
    }
    public function getGroupTitle(): string {
        return 'Allgemeine Kalendereinstellungen';
    }
    public function getGroupDescription(): string
    {
        return 'Allgemeine Einstellungen für das Kalendermodul';
    }
    public function getKey(): string
    {
        return 'calendarBundle.general';
    }
}