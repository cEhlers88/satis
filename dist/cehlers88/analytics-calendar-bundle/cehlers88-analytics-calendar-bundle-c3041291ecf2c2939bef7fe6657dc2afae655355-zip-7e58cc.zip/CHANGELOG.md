# Changelog

## [1.0.1](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.0...v1.0.1) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.2.0@dev ([#4](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/4)) ([a6426ca](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/a6426ca8c32cc3c2070f0ec2fcc66899313ce00b))

## 1.0.0 (2026-01-21)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.7 ([#1](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/1)) ([3d226cf](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/3d226cfcbdd9df91e0f09d1ec7e15050bfafae57))
* Introduce AnalyticsCalendarBundle with core features and configuration. ([98a0247](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/98a0247560e3ad85204ebc803f6fc1d2327e8073))
