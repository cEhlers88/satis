<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 19:34
 */

namespace Cehlers88\AnalyticsCalendarBundle\Macro;

use Analytics\Macro\AbstractMacro;

abstract class AbstractCalendarMacro extends AbstractMacro {
    abstract protected function _init():AbstractCalendarMacro;
    public function init():AbstractCalendarMacro {
        $this->_source = "InfrastructureBundle";
        return $this->_init();
    }
}