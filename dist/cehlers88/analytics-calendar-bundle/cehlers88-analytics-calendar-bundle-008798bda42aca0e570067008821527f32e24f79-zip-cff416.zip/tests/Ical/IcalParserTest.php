<?php

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Ical;

use Cehlers88\AnalyticsCalendarBundle\Ical\IcalParseException;
use Cehlers88\AnalyticsCalendarBundle\Ical\IcalParser;
use PHPUnit\Framework\TestCase;

class IcalParserTest extends TestCase
{
    private IcalParser $parser;

    protected function setUp(): void
    {
        $this->parser = new IcalParser();
    }

    public function testItReadsNestedComponents(): void
    {
        $calendar = $this->parser->parseCalendar($this->buildStream([
            'BEGIN:VCALENDAR',
            'VERSION:2.0',
            'BEGIN:VEVENT',
            'UID:event-1',
            'BEGIN:VALARM',
            'ACTION:DISPLAY',
            'TRIGGER:-PT15M',
            'END:VALARM',
            'END:VEVENT',
            'END:VCALENDAR',
        ]));

        $event = $calendar->getComponent('VEVENT');

        self::assertNotNull($event);
        self::assertSame('event-1', $event->getValue('UID'));
        self::assertCount(1, $event->getComponents('VALARM'));
        self::assertSame('-PT15M', $event->getComponent('VALARM')?->getValue('TRIGGER'));
    }

    public function testItJoinsFoldedLines(): void
    {
        $calendar = $this->parser->parseCalendar($this->buildStream([
            'BEGIN:VCALENDAR',
            'BEGIN:VEVENT',
            'SUMMARY:Ein sehr langer Termin',
            ' titel über zwei Zeilen',
            'END:VEVENT',
            'END:VCALENDAR',
        ]));

        self::assertSame(
            'Ein sehr langer Termintitel über zwei Zeilen',
            $calendar->getComponent('VEVENT')?->getValue('SUMMARY'),
        );
    }

    public function testItReadsParameters(): void
    {
        $calendar = $this->parser->parseCalendar($this->buildStream([
            'BEGIN:VCALENDAR',
            'BEGIN:VEVENT',
            'DTSTART;TZID=Europe/Berlin:20260811T100000',
            'ATTENDEE;CN="Doe, John";ROLE=REQ-PARTICIPANT:mailto:john@example.com',
            'END:VEVENT',
            'END:VCALENDAR',
        ]));

        $event = $calendar->getComponent('VEVENT');

        self::assertSame('Europe/Berlin', $event?->getProperty('DTSTART')?->getParameter('TZID'));
        self::assertSame('20260811T100000', $event?->getValue('DTSTART'));

        $attendee = $event?->getProperty('ATTENDEE');

        // The colon inside the quoted parameter must not end the definition.
        self::assertSame('Doe, John', $attendee?->getParameter('CN'));
        self::assertSame('mailto:john@example.com', $attendee?->value);
        self::assertTrue($attendee?->hasParameterValue('ROLE', 'req-participant'));
    }

    public function testItUnescapesTextValuesOnDemand(): void
    {
        $calendar = $this->parser->parseCalendar($this->buildStream([
            'BEGIN:VCALENDAR',
            'BEGIN:VEVENT',
            'DESCRIPTION:Zeile 1\\nZeile 2\\, mit Komma\\; und Semikolon',
            'RRULE:FREQ=WEEKLY;BYDAY=MO,WE',
            'END:VEVENT',
            'END:VCALENDAR',
        ]));

        $event = $calendar->getComponent('VEVENT');

        self::assertSame(
            "Zeile 1\nZeile 2, mit Komma; und Semikolon",
            $event?->getTextValue('DESCRIPTION'),
        );
        // Structured values keep their delimiters.
        self::assertSame('FREQ=WEEKLY;BYDAY=MO,WE', $event?->getValue('RRULE'));
    }

    public function testItRejectsMismatchedComponents(): void
    {
        $this->expectException(IcalParseException::class);

        $this->parser->parse($this->buildStream([
            'BEGIN:VCALENDAR',
            'BEGIN:VEVENT',
            'END:VCALENDAR',
        ]));
    }

    public function testItRejectsUnterminatedComponents(): void
    {
        $this->expectException(IcalParseException::class);

        $this->parser->parse($this->buildStream([
            'BEGIN:VCALENDAR',
            'VERSION:2.0',
        ]));
    }

    public function testItRejectsAStreamWithoutCalendar(): void
    {
        $this->expectException(IcalParseException::class);

        $this->parser->parseCalendar('BEGIN:VEVENT' . "\r\n" . 'END:VEVENT' . "\r\n");
    }

    public function testItAcceptsUnixLineEndings(): void
    {
        $calendar = $this->parser->parseCalendar(
            "BEGIN:VCALENDAR\nBEGIN:VEVENT\nUID:unix\nEND:VEVENT\nEND:VCALENDAR\n",
        );

        self::assertSame('unix', $calendar->getComponent('VEVENT')?->getValue('UID'));
    }

    /**
     * @param string[] $lines
     */
    private function buildStream(array $lines): string
    {
        return implode("\r\n", $lines) . "\r\n";
    }
}
