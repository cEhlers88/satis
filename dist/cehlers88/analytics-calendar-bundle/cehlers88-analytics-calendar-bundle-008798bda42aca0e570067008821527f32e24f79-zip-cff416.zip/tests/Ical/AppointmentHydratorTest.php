<?php

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Ical;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Ical\AppointmentHydrator;
use Cehlers88\AnalyticsCalendarBundle\Ical\AppointmentSerializer;
use Cehlers88\AnalyticsCalendarBundle\Ical\IcalParseException;
use Cehlers88\AnalyticsCalendarBundle\Ical\IcalParser;
use PHPUnit\Framework\TestCase;

class AppointmentHydratorTest extends TestCase
{
    private AppointmentHydrator $hydrator;
    private IcalParser $parser;

    protected function setUp(): void
    {
        $this->hydrator = new AppointmentHydrator();
        $this->parser = new IcalParser();
    }

    public function testItReadsAnEventTheWayIosSendsIt(): void
    {
        $appointment = $this->hydrate([
            'UID:5C3AF6D1-6C1B-4C21-9F0E-8B1B4B0C7F11',
            'DTSTAMP:20260810T120000Z',
            'DTSTART;TZID=Europe/Berlin:20260811T100000',
            'DTEND;TZID=Europe/Berlin:20260811T113000',
            'SUMMARY:Zahnarzt',
            'LOCATION:Hauptstraße 1\, Hamburg',
            'DESCRIPTION:Bitte Karte mitbringen',
            'SEQUENCE:3',
        ]);

        self::assertSame('5C3AF6D1-6C1B-4C21-9F0E-8B1B4B0C7F11', $appointment->getUid());
        self::assertSame('Zahnarzt', $appointment->getTitle());
        self::assertSame('Hauptstraße 1, Hamburg', $appointment->getLocation());
        self::assertSame('Bitte Karte mitbringen', $appointment->getDescription());
        self::assertSame(3, $appointment->getSequence());
        self::assertSame('Europe/Berlin', $appointment->getTimezone());
        self::assertFalse($appointment->isAllDay());
        self::assertSame('2026-08-11 10:00:00', $appointment->getStartDate()?->format('Y-m-d H:i:s'));
        self::assertSame('2026-08-11 11:30:00', $appointment->getEndDate()?->format('Y-m-d H:i:s'));
    }

    public function testItConvertsUtcStampsIntoLocalTime(): void
    {
        $appointment = $this->hydrate([
            'UID:utc-event',
            'DTSTART:20260811T080000Z',
            'DTEND:20260811T093000Z',
            'SUMMARY:Telefonat',
        ]);

        self::assertSame('2026-08-11 10:00:00', $appointment->getStartDate()?->format('Y-m-d H:i:s'));
        self::assertNull($appointment->getTimezone(), 'A UTC stamp does not pin the appointment to a timezone.');
    }

    public function testItReadsAllDayEvents(): void
    {
        $appointment = $this->hydrate([
            'UID:all-day',
            'DTSTART;VALUE=DATE:20260811',
            'DTEND;VALUE=DATE:20260813',
            'SUMMARY:Urlaub',
        ]);

        self::assertTrue($appointment->isAllDay());
        self::assertSame('2026-08-11 00:00:00', $appointment->getStartDate()?->format('Y-m-d H:i:s'));
        self::assertSame('2026-08-13 00:00:00', $appointment->getEndDate()?->format('Y-m-d H:i:s'));
    }

    public function testASingleAllDayEventLastsOneDay(): void
    {
        $appointment = $this->hydrate([
            'UID:all-day-single',
            'DTSTART;VALUE=DATE:20260811',
            'SUMMARY:Feiertag',
        ]);

        self::assertSame('2026-08-12 00:00:00', $appointment->getEndDate()?->format('Y-m-d H:i:s'));
    }

    public function testItResolvesADurationIntoAnEndDate(): void
    {
        $appointment = $this->hydrate([
            'UID:duration',
            'DTSTART:20260811T080000Z',
            'DURATION:PT1H30M',
            'SUMMARY:Workshop',
        ]);

        self::assertSame('2026-08-11 11:30:00', $appointment->getEndDate()?->format('Y-m-d H:i:s'));
    }

    public function testItReadsTheReminderFromAnAlarm(): void
    {
        $appointment = $this->hydrate([
            'UID:with-alarm',
            'DTSTART:20260811T080000Z',
            'SUMMARY:Termin',
            'BEGIN:VALARM',
            'ACTION:DISPLAY',
            'TRIGGER:-PT30M',
            'END:VALARM',
        ]);

        self::assertSame(1800, $appointment->getReminderTimer());
    }

    public function testItIgnoresAlarmsRelativeToTheEnd(): void
    {
        $appointment = $this->hydrate([
            'UID:end-alarm',
            'DTSTART:20260811T080000Z',
            'DTEND:20260811T090000Z',
            'SUMMARY:Termin',
            'BEGIN:VALARM',
            'ACTION:DISPLAY',
            'TRIGGER;RELATED=END:-PT5M',
            'END:VALARM',
        ]);

        self::assertNull($appointment->getReminderTimer());
    }

    public function testItSimplifiesRecurrenceRulesItCanExpress(): void
    {
        $daily = $this->hydrate([
            'UID:daily',
            'DTSTART:20260811T080000Z',
            'SUMMARY:Standup',
            'RRULE:FREQ=DAILY;INTERVAL=3',
        ]);

        self::assertSame('FREQ=DAILY;INTERVAL=3', $daily->getRrule());
        self::assertSame(3, $daily->getRepeatInterval());

        $weekly = $this->hydrate([
            'UID:weekly',
            'DTSTART:20260811T080000Z',
            'SUMMARY:Jour fixe',
            'RRULE:FREQ=WEEKLY',
        ]);

        self::assertSame(7, $weekly->getRepeatInterval());
    }

    public function testItKeepsRulesItCannotSimplify(): void
    {
        $monthly = $this->hydrate([
            'UID:monthly',
            'DTSTART:20260811T080000Z',
            'SUMMARY:Miete',
            'RRULE:FREQ=MONTHLY;BYMONTHDAY=1',
        ]);

        self::assertSame('FREQ=MONTHLY;BYMONTHDAY=1', $monthly->getRrule());
        self::assertNull($monthly->getRepeatInterval());
    }

    public function testItPrefersTheMasterEventOverRecurrenceOverrides(): void
    {
        $calendar = $this->parser->parseCalendar(implode("\r\n", [
            'BEGIN:VCALENDAR',
            'BEGIN:VEVENT',
            'UID:series',
            'RECURRENCE-ID:20260818T080000Z',
            'DTSTART:20260818T090000Z',
            'SUMMARY:Verschobener Einzeltermin',
            'END:VEVENT',
            'BEGIN:VEVENT',
            'UID:series',
            'DTSTART:20260811T080000Z',
            'SUMMARY:Serientermin',
            'RRULE:FREQ=WEEKLY',
            'END:VEVENT',
            'END:VCALENDAR',
            '',
        ]));

        $master = $this->hydrator->findMasterEvent($calendar);

        self::assertSame('Serientermin', $master?->getValue('SUMMARY'));
    }

    public function testItFallsBackToAPlaceholderTitle(): void
    {
        $appointment = $this->hydrate([
            'UID:no-title',
            'DTSTART:20260811T080000Z',
        ]);

        self::assertSame('(ohne Titel)', $appointment->getTitle());
    }

    public function testItRejectsEventsWithoutAStart(): void
    {
        $this->expectException(IcalParseException::class);

        $this->hydrate([
            'UID:broken',
            'SUMMARY:Termin ohne Beginn',
        ]);
    }

    public function testItSurvivesARoundTripThroughTheSerializer(): void
    {
        $original = $this->hydrate([
            'UID:round-trip',
            'DTSTART;TZID=Europe/Berlin:20260811T100000',
            'DTEND;TZID=Europe/Berlin:20260811T113000',
            'SUMMARY:Besprechung',
            'DESCRIPTION:Mit Kaffee\, bitte',
            'LOCATION:Büro',
            'RRULE:FREQ=WEEKLY',
            'BEGIN:VALARM',
            'ACTION:DISPLAY',
            'TRIGGER:-PT10M',
            'END:VALARM',
        ]);

        $rendered = (new AppointmentSerializer())->render($original);
        $event = $this->hydrator->findMasterEvent($this->parser->parseCalendar($rendered));

        self::assertNotNull($event);

        $again = $this->hydrator->hydrate($event, new Appointment());

        self::assertSame($original->getUid(), $again->getUid());
        self::assertSame($original->getTitle(), $again->getTitle());
        self::assertSame($original->getDescription(), $again->getDescription());
        self::assertSame($original->getLocation(), $again->getLocation());
        self::assertSame($original->getRrule(), $again->getRrule());
        self::assertSame($original->getReminderTimer(), $again->getReminderTimer());
        self::assertEquals($original->getStartDate(), $again->getStartDate());
        self::assertEquals($original->getEndDate(), $again->getEndDate());
    }

    /**
     * @param string[] $eventLines
     */
    private function hydrate(array $eventLines): Appointment
    {
        $stream = implode("\r\n", array_merge(
            ['BEGIN:VCALENDAR', 'VERSION:2.0', 'BEGIN:VEVENT'],
            $eventLines,
            ['END:VEVENT', 'END:VCALENDAR', ''],
        ));

        $event = $this->hydrator->findMasterEvent($this->parser->parseCalendar($stream));

        self::assertNotNull($event);

        return $this->hydrator->hydrate($event, new Appointment());
    }
}
