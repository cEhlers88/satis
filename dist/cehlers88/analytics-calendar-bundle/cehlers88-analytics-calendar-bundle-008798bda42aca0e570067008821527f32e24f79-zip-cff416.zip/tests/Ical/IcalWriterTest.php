<?php

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Ical;

use Cehlers88\AnalyticsCalendarBundle\Ical\IcalComponent;
use Cehlers88\AnalyticsCalendarBundle\Ical\IcalParser;
use Cehlers88\AnalyticsCalendarBundle\Ical\IcalWriter;
use PHPUnit\Framework\TestCase;

class IcalWriterTest extends TestCase
{
    private IcalWriter $writer;

    protected function setUp(): void
    {
        $this->writer = new IcalWriter();
    }

    public function testItWritesComponentsWithCrlfEndings(): void
    {
        $calendar = new IcalComponent('VCALENDAR');
        $calendar->add('VERSION', '2.0');

        $event = new IcalComponent('VEVENT');
        $event->add('UID', 'event-1');
        $calendar->addComponent($event);

        self::assertSame(
            "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VEVENT\r\nUID:event-1\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n",
            $this->writer->write($calendar),
        );
    }

    public function testItFoldsLongLinesAndKeepsThemReadable(): void
    {
        $value = str_repeat('Ein langer Terminname. ', 12);
        $component = new IcalComponent('VEVENT');
        $component->add('SUMMARY', $value);

        $output = $this->writer->write($component);

        foreach (explode("\r\n", trim($output)) as $line) {
            self::assertLessThanOrEqual(75, strlen($line), 'Every content line stays within 75 octets.');
        }

        $parsed = (new IcalParser())->parse($output)->getComponent('VEVENT');
        self::assertSame($value, $parsed?->getValue('SUMMARY'), 'Folding survives a round-trip.');
    }

    public function testItNeverSplitsMultibyteCharacters(): void
    {
        $value = str_repeat('äöüß', 40);
        $component = new IcalComponent('VEVENT');
        $component->add('DESCRIPTION', $value);

        $output = $this->writer->write($component);

        foreach (explode("\r\n", trim($output)) as $line) {
            self::assertTrue(mb_check_encoding($line, 'UTF-8'), 'No line ends in the middle of a character.');
        }

        $parsed = (new IcalParser())->parse($output)->getComponent('VEVENT');
        self::assertSame($value, $parsed?->getValue('DESCRIPTION'));
    }

    public function testItQuotesParameterValuesContainingDelimiters(): void
    {
        $component = new IcalComponent('VEVENT');
        $component->add('ATTENDEE', 'mailto:john@example.com', ['CN' => 'Doe, John']);
        $component->add('DTSTART', '20260811T100000', ['TZID' => 'Europe/Berlin']);

        $output = $this->writer->write($component);

        self::assertStringContainsString('ATTENDEE;CN="Doe, John":mailto:john@example.com', $output);
        self::assertStringContainsString('DTSTART;TZID=Europe/Berlin:20260811T100000', $output);
    }

    public function testItWritesEveryCalendarOfARootComponent(): void
    {
        $root = new IcalComponent('ROOT');
        $root->addComponent(new IcalComponent('VCALENDAR'));
        $root->addComponent(new IcalComponent('VCALENDAR'));

        self::assertSame(2, substr_count($this->writer->write($root), 'BEGIN:VCALENDAR'));
    }
}
