<?php

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Ical;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Ical\AppointmentSerializer;
use Cehlers88\AnalyticsCalendarBundle\Ical\IcalParser;
use PHPUnit\Framework\TestCase;

class AppointmentSerializerTest extends TestCase
{
    private AppointmentSerializer $serializer;

    protected function setUp(): void
    {
        $this->serializer = new AppointmentSerializer();
    }

    public function testItWritesTimedAppointmentsInUtc(): void
    {
        // Europe/Berlin is two hours ahead of UTC in August.
        $event = $this->renderEvent($this->buildAppointment());

        self::assertSame('20260811T080000Z', $event['DTSTART']);
        self::assertSame('20260811T093000Z', $event['DTEND']);
    }

    public function testItWritesAllDayAppointmentsAsDates(): void
    {
        $appointment = $this->buildAppointment();
        $appointment
            ->setAllDay(true)
            ->setEndDate(new \DateTime('2026-08-12 00:00:00'));

        $calendar = (new IcalParser())->parseCalendar($this->serializer->render($appointment));
        $start = $calendar->getComponent('VEVENT')?->getProperty('DTSTART');

        self::assertSame('20260811', $start?->value);
        self::assertTrue($start?->hasParameterValue('VALUE', 'DATE'));
    }

    public function testItEscapesTextValues(): void
    {
        $appointment = $this->buildAppointment();
        $appointment->setDescription("Erste Zeile\nZweite, Zeile");

        $rendered = $this->serializer->render($appointment);
        self::assertStringContainsString('DESCRIPTION:Erste Zeile\\nZweite\\, Zeile', $rendered);

        $parsed = (new IcalParser())->parseCalendar($rendered);
        self::assertSame(
            "Erste Zeile\nZweite, Zeile",
            $parsed->getComponent('VEVENT')?->getTextValue('DESCRIPTION'),
        );
    }

    public function testItTurnsTheReminderIntoAnAlarm(): void
    {
        $appointment = $this->buildAppointment();
        $appointment->setReminderTimer(900);

        $calendar = (new IcalParser())->parseCalendar($this->serializer->render($appointment));
        $alarm = $calendar->getComponent('VEVENT')?->getComponent('VALARM');

        self::assertSame('DISPLAY', $alarm?->getValue('ACTION'));
        self::assertSame('-PT15M', $alarm?->getValue('TRIGGER'));
    }

    public function testItDerivesARecurrenceRuleFromTheRepeatInterval(): void
    {
        $weekly = $this->buildAppointment();
        $weekly->setRepeatInterval(7);
        self::assertSame('FREQ=WEEKLY', $this->renderEvent($weekly)['RRULE']);

        $everyThreeDays = $this->buildAppointment();
        $everyThreeDays->setRepeatInterval(3);
        self::assertSame('FREQ=DAILY;INTERVAL=3', $this->renderEvent($everyThreeDays)['RRULE']);

        $fortnightly = $this->buildAppointment();
        $fortnightly->setRepeatInterval(14);
        self::assertSame('FREQ=WEEKLY;INTERVAL=2', $this->renderEvent($fortnightly)['RRULE']);
    }

    public function testAnExplicitRuleWinsOverTheRepeatInterval(): void
    {
        $appointment = $this->buildAppointment();
        $appointment->setRepeatInterval(7)->setRrule('FREQ=MONTHLY;BYMONTHDAY=1');

        self::assertSame('FREQ=MONTHLY;BYMONTHDAY=1', $this->renderEvent($appointment)['RRULE']);
    }

    public function testTheRenderedObjectIsStable(): void
    {
        // The entity tag is derived from this output, so two renderings of an
        // unchanged appointment have to be identical.
        $appointment = $this->buildAppointment();

        self::assertSame($this->serializer->render($appointment), $this->serializer->render($appointment));
    }

    public function testItRendersACollectionWithRefreshHint(): void
    {
        $rendered = $this->serializer->renderCollection(
            [$this->buildAppointment(), $this->buildAppointment()],
            'Mein Kalender',
            3600,
        );

        $calendar = (new IcalParser())->parseCalendar($rendered);

        self::assertCount(2, $calendar->getComponents('VEVENT'));
        self::assertSame('Mein Kalender', $calendar->getTextValue('X-WR-CALNAME'));
        self::assertSame('PT1H', $calendar->getValue('REFRESH-INTERVAL'));
        self::assertSame('PT1H', $calendar->getValue('X-PUBLISHED-TTL'));
    }

    public function testGeneratedIdentifiersAreUnique(): void
    {
        self::assertNotSame($this->serializer->generateUid(), $this->serializer->generateUid());
    }

    /**
     * @return array<string, string> property name => value
     */
    private function renderEvent(Appointment $appointment): array
    {
        $calendar = (new IcalParser())->parseCalendar($this->serializer->render($appointment));
        $event = $calendar->getComponent('VEVENT');
        $values = [];

        foreach ($event?->getProperties() ?? [] as $property) {
            $values[$property->name] = $property->value;
        }

        return $values;
    }

    private function buildAppointment(): Appointment
    {
        $appointment = new Appointment();
        $appointment
            ->setTitle('Team Meeting')
            ->setStartDate(new \DateTime('2026-08-11 10:00:00'))
            ->setEndDate(new \DateTime('2026-08-11 11:30:00'))
            ->setUid('event-1@analytics-calendar')
            ->setCreatedAt(new \DateTime('2026-08-01 09:00:00'))
            ->setUpdatedAt(new \DateTime('2026-08-02 09:00:00'));

        return $appointment;
    }
}
