<?php

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Ical;

use Cehlers88\AnalyticsCalendarBundle\Ical\IcalDuration;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class IcalDurationTest extends TestCase
{
    /**
     * @return iterable<string, array{0: string, 1: int}>
     */
    public static function durations(): iterable
    {
        yield 'quarter of an hour before the start' => ['-PT15M', -900];
        yield 'one hour' => ['PT1H', 3600];
        yield 'one and a half hours' => ['PT1H30M', 5400];
        yield 'one day' => ['P1D', 86400];
        yield 'two weeks' => ['P2W', 1209600];
        yield 'explicitly positive' => ['+PT30S', 30];
        yield 'combined' => ['P1DT2H3M4S', 93784];
    }

    #[DataProvider('durations')]
    public function testItReadsDurations(string $value, int $expected): void
    {
        self::assertSame($expected, IcalDuration::toSeconds($value));
    }

    public function testItRejectsUnreadableValues(): void
    {
        self::assertNull(IcalDuration::toSeconds('15 Minuten'));
        self::assertNull(IcalDuration::toSeconds(''));
        self::assertNull(IcalDuration::toSeconds('PT'));
    }

    public function testItWritesTheLargestExactUnit(): void
    {
        self::assertSame('PT0S', IcalDuration::fromSeconds(0));
        self::assertSame('-PT15M', IcalDuration::fromSeconds(-900));
        self::assertSame('PT2H', IcalDuration::fromSeconds(7200));
        self::assertSame('P1D', IcalDuration::fromSeconds(86400));
        self::assertSame('P1W', IcalDuration::fromSeconds(604800));
        self::assertSame('PT45S', IcalDuration::fromSeconds(45));
        self::assertSame('PT90M', IcalDuration::fromSeconds(5400));
    }

    #[DataProvider('durations')]
    public function testWrittenDurationsCanBeReadBack(string $value, int $seconds): void
    {
        self::assertSame($seconds, IcalDuration::toSeconds(IcalDuration::fromSeconds($seconds)));
    }
}
