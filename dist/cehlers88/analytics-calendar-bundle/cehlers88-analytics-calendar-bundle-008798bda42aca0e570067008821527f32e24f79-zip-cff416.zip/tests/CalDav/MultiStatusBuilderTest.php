<?php

namespace Cehlers88\AnalyticsCalendarBundle\Tests\CalDav;

use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavNamespace;
use Cehlers88\AnalyticsCalendarBundle\CalDav\MultiStatusBuilder;
use PHPUnit\Framework\TestCase;

class MultiStatusBuilderTest extends TestCase
{
    public function testItSeparatesFoundFromMissingProperties(): void
    {
        $xml = (new MultiStatusBuilder())
            ->addResponse(
                '/caldav/calendars/1/default/',
                ['{DAV:}displayname' => 'Privat'],
                ['{DAV:}getetag', '{urn:ietf:params:xml:ns:caldav}calendar-timezone'],
            )
            ->toXml();

        $xpath = $this->xpath($xml);

        self::assertSame('/caldav/calendars/1/default/', $xpath->evaluate('string(//d:response/d:href)'));
        self::assertSame('Privat', $xpath->evaluate('string(//d:propstat[d:status="HTTP/1.1 200 OK"]/d:prop/d:displayname)'));
        self::assertSame(1.0, $xpath->evaluate('count(//d:propstat[d:status="HTTP/1.1 404 Not Found"]/d:prop/d:getetag)'));
        self::assertSame(1.0, $xpath->evaluate('count(//d:propstat[d:status="HTTP/1.1 404 Not Found"]/d:prop/c:calendar-timezone)'));
    }

    public function testItWritesNestedResourceTypes(): void
    {
        $xml = (new MultiStatusBuilder())
            ->addResponse('/caldav/calendars/1/default/', [
                '{DAV:}resourcetype' => MultiStatusBuilder::elements([
                    '{DAV:}collection',
                    '{urn:ietf:params:xml:ns:caldav}calendar',
                ]),
            ])
            ->toXml();

        $xpath = $this->xpath($xml);

        self::assertSame(1.0, $xpath->evaluate('count(//d:resourcetype/d:collection)'));
        self::assertSame(1.0, $xpath->evaluate('count(//d:resourcetype/c:calendar)'));
    }

    public function testItWritesHrefProperties(): void
    {
        $xml = (new MultiStatusBuilder())
            ->addResponse('/caldav/', [
                '{DAV:}current-user-principal' => MultiStatusBuilder::href('/caldav/principals/1/'),
            ])
            ->toXml();

        self::assertSame(
            '/caldav/principals/1/',
            $this->xpath($xml)->evaluate('string(//d:current-user-principal/d:href)'),
        );
    }

    public function testItReportsRemovedResourcesWithAStatusOnly(): void
    {
        $xml = (new MultiStatusBuilder())
            ->addStatusResponse('/caldav/calendars/1/default/gone.ics', 'HTTP/1.1 404 Not Found')
            ->setSyncToken('urn:x-analytics:calendar:sync:9')
            ->toXml();

        $xpath = $this->xpath($xml);

        self::assertSame('/caldav/calendars/1/default/gone.ics', $xpath->evaluate('string(//d:response/d:href)'));
        self::assertSame('HTTP/1.1 404 Not Found', $xpath->evaluate('string(//d:response/d:status)'));
        self::assertSame(0.0, $xpath->evaluate('count(//d:response/d:propstat)'));
        self::assertSame('urn:x-analytics:calendar:sync:9', $xpath->evaluate('string(/d:multistatus/d:sync-token)'));
    }

    public function testItEscapesTextValues(): void
    {
        $xml = (new MultiStatusBuilder())
            ->addResponse('/caldav/calendars/1/default/', ['{DAV:}displayname' => 'Arbeit & <Privat>'])
            ->toXml();

        self::assertStringNotContainsString('<Privat>', $xml);
        self::assertSame(
            'Arbeit & <Privat>',
            $this->xpath($xml)->evaluate('string(//d:displayname)'),
        );
    }

    private function xpath(string $xml): \DOMXPath
    {
        $document = new \DOMDocument();

        self::assertTrue($document->loadXML($xml), 'The builder produces well-formed XML.');

        $xpath = new \DOMXPath($document);
        $xpath->registerNamespace('d', CalDavNamespace::DAV);
        $xpath->registerNamespace('c', CalDavNamespace::CALDAV);
        $xpath->registerNamespace('cs', CalDavNamespace::CALENDARSERVER);
        $xpath->registerNamespace('ic', CalDavNamespace::APPLE);

        return $xpath;
    }
}
