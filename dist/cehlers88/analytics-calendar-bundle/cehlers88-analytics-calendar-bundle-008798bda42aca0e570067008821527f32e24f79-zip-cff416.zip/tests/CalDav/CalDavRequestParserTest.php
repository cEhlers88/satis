<?php

namespace Cehlers88\AnalyticsCalendarBundle\Tests\CalDav;

use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavRequestParser;
use Cehlers88\AnalyticsCalendarBundle\CalDav\ReportRequest;
use PHPUnit\Framework\TestCase;

class CalDavRequestParserTest extends TestCase
{
    private CalDavRequestParser $parser;

    protected function setUp(): void
    {
        $this->parser = new CalDavRequestParser();
    }

    public function testItReadsRequestedPropertiesRegardlessOfThePrefix(): void
    {
        // iOS uses "A"/"B" style prefixes; only the namespace matters.
        $request = $this->parser->parsePropfind(<<<'XML'
            <?xml version="1.0" encoding="UTF-8"?>
            <A:propfind xmlns:A="DAV:" xmlns:B="urn:ietf:params:xml:ns:caldav">
              <A:prop>
                <A:resourcetype/>
                <A:displayname/>
                <B:calendar-home-set/>
              </A:prop>
            </A:propfind>
            XML);

        self::assertFalse($request->allProp);
        self::assertSame([
            '{DAV:}resourcetype',
            '{DAV:}displayname',
            '{urn:ietf:params:xml:ns:caldav}calendar-home-set',
        ], $request->properties);
    }

    public function testAnEmptyBodyAsksForEverything(): void
    {
        self::assertTrue($this->parser->parsePropfind('')->allProp);
        self::assertTrue($this->parser->parsePropfind('   ')->allProp);
    }

    public function testItRecognisesAllpropAndPropname(): void
    {
        $allProp = $this->parser->parsePropfind('<d:propfind xmlns:d="DAV:"><d:allprop/></d:propfind>');
        self::assertTrue($allProp->allProp);

        $propName = $this->parser->parsePropfind('<d:propfind xmlns:d="DAV:"><d:propname/></d:propfind>');
        self::assertTrue($propName->propName);
        self::assertFalse($propName->allProp);
    }

    public function testItReadsACalendarQueryWithATimeRange(): void
    {
        $report = $this->parser->parseReport(<<<'XML'
            <?xml version="1.0" encoding="UTF-8"?>
            <C:calendar-query xmlns:D="DAV:" xmlns:C="urn:ietf:params:xml:ns:caldav">
              <D:prop>
                <D:getetag/>
                <C:calendar-data/>
              </D:prop>
              <C:filter>
                <C:comp-filter name="VCALENDAR">
                  <C:comp-filter name="VEVENT">
                    <C:time-range start="20260801T000000Z" end="20260901T000000Z"/>
                  </C:comp-filter>
                </C:comp-filter>
              </C:filter>
            </C:calendar-query>
            XML);

        self::assertSame(ReportRequest::CALENDAR_QUERY, $report->type);
        self::assertSame(['{DAV:}getetag', '{urn:ietf:params:xml:ns:caldav}calendar-data'], $report->properties);
        self::assertSame('2026-08-01T02:00:00+02:00', $report->rangeStart?->format(\DATE_ATOM));
        self::assertSame('2026-09-01T02:00:00+02:00', $report->rangeEnd?->format(\DATE_ATOM));
    }

    public function testATimeRangeMayBeOpenEnded(): void
    {
        $report = $this->parser->parseReport(<<<'XML'
            <C:calendar-query xmlns:D="DAV:" xmlns:C="urn:ietf:params:xml:ns:caldav">
              <D:prop><D:getetag/></D:prop>
              <C:filter>
                <C:comp-filter name="VCALENDAR">
                  <C:time-range start="20260801T000000Z"/>
                </C:comp-filter>
              </C:filter>
            </C:calendar-query>
            XML);

        self::assertNotNull($report->rangeStart);
        self::assertNull($report->rangeEnd);
    }

    public function testItReadsAMultiget(): void
    {
        $report = $this->parser->parseReport(<<<'XML'
            <C:calendar-multiget xmlns:D="DAV:" xmlns:C="urn:ietf:params:xml:ns:caldav">
              <D:prop><D:getetag/><C:calendar-data/></D:prop>
              <D:href>/caldav/calendars/1/default/a.ics</D:href>
              <D:href>/caldav/calendars/1/default/b.ics</D:href>
            </C:calendar-multiget>
            XML);

        self::assertSame(ReportRequest::CALENDAR_MULTIGET, $report->type);
        self::assertSame([
            '/caldav/calendars/1/default/a.ics',
            '/caldav/calendars/1/default/b.ics',
        ], $report->hrefs);
    }

    public function testItReadsASyncCollectionReport(): void
    {
        $report = $this->parser->parseReport(<<<'XML'
            <D:sync-collection xmlns:D="DAV:">
              <D:sync-token>urn:x-analytics:calendar:sync:12</D:sync-token>
              <D:sync-level>1</D:sync-level>
              <D:limit><D:nresults>25</D:nresults></D:limit>
              <D:prop><D:getetag/></D:prop>
            </D:sync-collection>
            XML);

        self::assertSame(ReportRequest::SYNC_COLLECTION, $report->type);
        self::assertSame('urn:x-analytics:calendar:sync:12', $report->syncToken);
        self::assertSame(25, $report->limit);
    }

    public function testAnInitialSyncHasAnEmptyToken(): void
    {
        $report = $this->parser->parseReport(<<<'XML'
            <D:sync-collection xmlns:D="DAV:">
              <D:sync-token/>
              <D:prop><D:getetag/></D:prop>
            </D:sync-collection>
            XML);

        self::assertSame('', $report->syncToken);
    }

    public function testItRefusesAReportWithoutABody(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        $this->parser->parseReport('');
    }

    public function testItIgnoresExternalEntities(): void
    {
        $body = <<<'XML'
            <?xml version="1.0"?>
            <!DOCTYPE propfind [<!ENTITY secret SYSTEM "file:///etc/passwd">]>
            <d:propfind xmlns:d="DAV:"><d:prop><d:displayname>&secret;</d:displayname></d:prop></d:propfind>
            XML;

        $request = $this->parser->parsePropfind($body);

        self::assertSame(['{DAV:}displayname'], $request->properties);
    }
}
