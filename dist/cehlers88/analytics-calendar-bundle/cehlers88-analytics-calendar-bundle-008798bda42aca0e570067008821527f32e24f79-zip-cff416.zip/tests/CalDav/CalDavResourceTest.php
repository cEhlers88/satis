<?php

namespace Cehlers88\AnalyticsCalendarBundle\Tests\CalDav;

use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavResource;
use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavUrlBuilder;
use PHPUnit\Framework\TestCase;

class CalDavResourceTest extends TestCase
{
    public function testItRecognisesTheRoot(): void
    {
        foreach (['', '/'] as $path) {
            self::assertSame(CalDavResource::TYPE_ROOT, CalDavResource::fromPath($path)->type);
        }
    }

    public function testItRecognisesAPrincipal(): void
    {
        $resource = CalDavResource::fromPath('/principals/42/');

        self::assertSame(CalDavResource::TYPE_PRINCIPAL, $resource->type);
        self::assertSame(42, $resource->userId);
    }

    public function testItRecognisesTheCalendarHome(): void
    {
        $resource = CalDavResource::fromPath('/calendars/42/');

        self::assertSame(CalDavResource::TYPE_HOME, $resource->type);
        self::assertSame(42, $resource->userId);
    }

    public function testItRecognisesACalendar(): void
    {
        $resource = CalDavResource::fromPath('/calendars/42/default/');

        self::assertSame(CalDavResource::TYPE_CALENDAR, $resource->type);
        self::assertSame(42, $resource->userId);
        self::assertSame('default', $resource->calendarUri);
        self::assertTrue($resource->isCollection());
    }

    public function testItRecognisesACalendarObject(): void
    {
        $resource = CalDavResource::fromPath('/calendars/42/default/abc-123.ics');

        self::assertSame(CalDavResource::TYPE_OBJECT, $resource->type);
        self::assertSame('default', $resource->calendarUri);
        self::assertSame('abc-123.ics', $resource->objectUri);
        self::assertFalse($resource->isCollection());
    }

    public function testItDecodesPercentEncodedSegments(): void
    {
        $resource = CalDavResource::fromPath('/calendars/42/privat/5C3AF6D1%2D6C1B.ics');

        self::assertSame('5C3AF6D1-6C1B.ics', $resource->objectUri);
    }

    public function testItRejectsUnknownPaths(): void
    {
        foreach ([
            '/somewhere/else/',
            '/calendars/',
            '/calendars/not-a-number/',
            '/principals/',
            '/calendars/42/default/sub/too-deep.ics',
        ] as $path) {
            self::assertSame(CalDavResource::TYPE_UNKNOWN, CalDavResource::fromPath($path)->type, $path);
        }
    }

    public function testGeneratedUrlsAreParsedBackIntoTheSameResource(): void
    {
        $urls = new CalDavUrlBuilder();
        $href = $urls->object(42, 'privat', 'a b+c.ics');
        $path = substr($href, strlen(CalDavResource::BASE_PATH));

        $resource = CalDavResource::fromPath($path);

        self::assertSame(CalDavResource::TYPE_OBJECT, $resource->type);
        self::assertSame(42, $resource->userId);
        self::assertSame('privat', $resource->calendarUri);
        self::assertSame('a b+c.ics', $resource->objectUri, 'Encoding and decoding of an href cancel out.');
    }
}
