<?php

namespace Cehlers88\AnalyticsCalendarBundle\Tests\CalDav;

use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavSyncToken;
use PHPUnit\Framework\TestCase;

class CalDavSyncTokenTest extends TestCase
{
    public function testItRoundTripsARevision(): void
    {
        self::assertSame(17, CalDavSyncToken::parse(CalDavSyncToken::format(17)));
    }

    public function testItIsAUri(): void
    {
        self::assertStringStartsWith('urn:', CalDavSyncToken::format(1));
    }

    public function testUnknownTokensForceAFullSynchronisation(): void
    {
        // Anything this server did not issue has to be answered with the whole
        // collection rather than with a delta.
        foreach ([null, '', '   ', 'http://example.com/ns/sync/5', 'urn:x-analytics:calendar:sync:abc'] as $token) {
            self::assertNull(CalDavSyncToken::parse($token));
        }
    }
}
