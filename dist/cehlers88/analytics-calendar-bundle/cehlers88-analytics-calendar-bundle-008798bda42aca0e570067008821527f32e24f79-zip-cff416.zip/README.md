# AnalyticsCalendarBundle

A Symfony bundle for managing calendar appointments and events within the Analytics platform. It provides dashboard widgets, appointment scheduling, configurable date/time formats, a macro system for programmatic calendar operations and a CalDAV endpoint that connects phones and desktop calendar clients.

## Table of Contents

- [Requirements](#requirements)
- [Installation](#installation)
- [Calendar Synchronisation (CalDAV & iCalendar feed)](#calendar-synchronisation-caldav--icalendar-feed)
  - [Enabling the endpoints](#enabling-the-endpoints)
  - [Issuing device credentials](#issuing-device-credentials)
  - [Endpoints](#endpoints)
  - [Console commands](#console-commands)
  - [How synchronisation works](#how-synchronisation-works)
- [Configuration](#configuration)
- [JavaScript / Webpack Encore Integration](#javascript--webpack-encore-integration)
- [Widgets](#widgets)
  - [Calendar Widget](#calendar-widget)
  - [Time Widget](#time-widget)
- [Entities](#entities)
  - [Appointment](#entity-appointment)
  - [Calendar](#entity-calendar)
  - [CalendarAccessToken](#entity-calendaraccesstoken)
  - [CalendarDeletedObject](#entity-calendardeletedobject)
- [Repository: AppointmentRepository](#repository-appointmentrepository)
- [Macros](#macros)
  - [AddAppointmentMacro](#addappointmentmacro)
- [Permissions](#permissions)
- [Tests](#tests)
- [Changelog](#changelog)

## Requirements

- PHP 8.0+
- Symfony 6.0+
- `cehlers88/analytics-core` ^0.3

## Installation

### 1. Add the custom Satis repository to your `composer.json`

```json
{
    "repositories": [
        {
            "type": "composer",
            "url": "https://cehlers88.github.io/satis"
        }
    ]
}
```

### 2. Install the bundle via Composer

```bash
composer require cehlers88/analytics-calendar-bundle
```

### 3. Register the bundle (if not using Symfony Flex auto-discovery)

```php
// config/bundles.php
return [
    // ...
    Cehlers88\AnalyticsCalendarBundle\AnalyticsCalendarBundle::class => ['all' => true],
];
```

### 4. Update the database schema

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

This creates the `calendar_appointment` table used by the `Appointment` entity, the calendar collections (`calendar_calendar`), the device credentials (`calendar_access_token`) and the deletion tombstones (`calendar_deleted_object`).

## Calendar Synchronisation (CalDAV & iCalendar feed)

The bundle exposes the appointments of an account through two standard
interfaces, so that the calendar app of a phone or desktop becomes a front end
for the appointments stored here:

| | CalDAV | iCalendar subscription |
|---|---|---|
| Read appointments | yes | yes |
| Create, change and delete from the device | yes | no |
| Authentication | HTTP Basic with a device secret | secret inside the URL |
| Protocols | RFC 4791 (CalDAV), RFC 6578 (WebDAV sync), RFC 6764 (discovery) | RFC 5545 |

> **Step-by-step guide for the iPhone (German):**
> [`docs/iphone-kalender.md`](docs/iphone-kalender.md)

### Enabling the endpoints

Import the routes of the bundle in the host application:

```yaml
# config/routes.yaml
analytics_calendar_bundle:
  resource: '@AnalyticsCalendarBundle/Resources/config/routes.yaml'
```

Do **not** add a `prefix`: calendar clients store the URLs permanently, so
`/caldav`, `/.well-known/caldav` and `/calendar/feed` are fixed paths.

No change to `security.yaml` is required. The endpoint authenticates itself
because calendar clients speak HTTP Basic and expect a `401` challenge on every
unauthenticated request, which a form-login firewall does not provide. The paths
have to stay reachable though — if the application restricts them through
`access_control`, add:

```yaml
security:
  access_control:
    - { path: ^/caldav, roles: PUBLIC_ACCESS }
    - { path: ^/calendar/feed, roles: PUBLIC_ACCESS }
```

The web server must pass every HTTP method through, including `PROPFIND`,
`PROPPATCH`, `REPORT`, `OPTIONS` and `MKCALENDAR`. FrankenPHP/Caddy and a
default nginx `fastcgi_pass`/`proxy_pass` already do.

Installations that already contain appointments run the setup command once, so
that the existing rows get a calendar and an iCalendar identifier:

```bash
php bin/console analytics:calendar:setup user@example.com
```

### Issuing device credentials

The account password is deliberately not accepted. A device stores its
credential permanently and sends it on every synchronisation, so it gets its own
revocable secret:

```bash
php bin/console analytics:calendar:token:create user@example.com \
    --label="iPhone" --base-url=https://analytics.example.com
```

The command prints server address, user name and the generated password once —
only its SHA-256 digest is stored.

### Endpoints

| Path | Purpose |
|---|---|
| `/.well-known/caldav` | discovery, redirects to the CalDAV root |
| `/caldav/` | collection root, answers `current-user-principal` |
| `/caldav/principals/{userId}/` | principal, answers `calendar-home-set` |
| `/caldav/calendars/{userId}/` | list of the calendars of the account |
| `/caldav/calendars/{userId}/{calendar}/` | one calendar collection |
| `/caldav/calendars/{userId}/{calendar}/{object}.ics` | one appointment |
| `/calendar/feed/{secret}.ics` | read-only feed over all calendars |
| `/calendar/feed/{secret}/{calendar}.ics` | read-only feed of one calendar |

Supported methods: `OPTIONS`, `GET`, `HEAD`, `PROPFIND`, `PROPPATCH`, `REPORT`,
`PUT`, `DELETE`, `MKCALENDAR`, `MKCOL`. Supported reports: `calendar-query`,
`calendar-multiget` and `sync-collection`.

A `GET` on a calendar collection returns the whole collection as one iCalendar
stream. That is not part of CalDAV, but it makes the endpoint inspectable with
`curl` while setting up a device.

### Console commands

| Command | Description |
|---|---|
| `analytics:calendar:setup <email>` | Creates the default calendar and assigns appointments that predate synchronisation. `--dry-run` reports without writing. |
| `analytics:calendar:token:create <email>` | Issues a credential. `--type=caldav\|feed`, `--label`, `--calendar`, `--expires`, `--base-url`. |
| `analytics:calendar:token:list [email]` | Lists the issued credentials with their state and last use. |
| `analytics:calendar:token:revoke <id>` | Revokes a credential, e.g. for a lost device. |

### How synchronisation works

Every change to a calendar object increases the revision counter of its
collection. The counter backs both the CalendarServer `ctag` and the WebDAV
`sync-token`, so a client asks only for the difference since its last
synchronisation instead of downloading every appointment again. Deletions leave
a `CalendarDeletedObject` tombstone behind, because the appointment row itself
is gone by the time the client asks.

A calendar object sent by a client is stored verbatim in `Appointment::icalData`
and handed back unchanged on the next `GET`. In addition, the properties this
bundle knows about are mapped onto the columns of the appointment, so the web
interface works with the same data. Properties outside that mapping (attendees,
attachments, custom `X-` properties) survive because of the verbatim copy.

Appointments created or changed inside the application go through
`CalendarObjectManager::save()`, which rebuilds the iCalendar representation,
recomputes the entity tag and bumps the revision counter:

```php
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarObjectManager;

$appointment = new Appointment();
$appointment->setTitle('Team Meeting')->setStartDate(new \DateTime('2026-04-01 10:00'));

$objectManager->save($appointment, $calendarManager->getDefaultCalendar($user));
```

Using the entity manager directly still works, but such an appointment is not
announced to connected devices until something else bumps the counter.

## JavaScript / Webpack Encore Integration

The bundle ships its JavaScript assets in `assets/index.ts` and exposes a
`package.json` so it can be registered as a local npm module in the host
Symfony application.  Follow the steps below to include the bundle's
JavaScript in your webpack-encore build.

### 1. Register the bundle as a local npm package

Add the bundle as a file-based dependency in your application's `package.json`:

```json
{
    "dependencies": {
        "@cehlers88/analytics-calendar-bundle": "file:vendor/cehlers88/analytics-calendar-bundle"
    }
}
```

Then install the new dependency:

```bash
yarn install
# or
npm install
```

This creates a symlink at
`node_modules/@cehlers88/analytics-calendar-bundle` that points to the
vendor directory, so webpack can resolve the module.

### 2. Add an entry point in `webpack.config.js`

Open your application's `webpack.config.js` and add an entry that imports
the bundle's assets:

```js
// webpack.config.js
const Encore = require('@symfony/webpack-encore');

Encore
    // … your existing configuration …
    .addEntry('analytics-calendar-bundle', '@cehlers88/analytics-calendar-bundle')
;

module.exports = Encore.getWebpackConfig();
```

> **Tip:** If you prefer to bundle the calendar assets together with your
> main application entry point instead of creating a separate file, you can
> import the module inside your existing entry file (e.g.
> `assets/app.ts`):
>
> ```ts
> import { initAnalyticsCalendarBundle } from '@cehlers88/analytics-calendar-bundle';
>
> document.addEventListener('DOMContentLoaded', () => {
>     initAnalyticsCalendarBundle();
> });
> ```

### 3. Build the assets

```bash
yarn encore dev   # development build
yarn encore prod  # production build
```

### 4. Include the compiled script in your Twig template

If you added a dedicated entry point in step 2, include it via the
`encore_entry_script_tags` helper:

```twig
{# base.html.twig #}
{{ encore_entry_script_tags('analytics-calendar-bundle') }}
```

### Available exports

| Export | Description |
| --- | --- |
| `initAnalyticsCalendarBundle()` | Convenience function – calls both initialisers below with their default selectors. |
| `initCalendarWidget(selector?)` | Highlights today's tile and wires navigation-button click events for every `button[data-calendar-nav]` element inside the same parent as `selector` (default: `'.calendar'`). Each button click dispatches a bubbling `analytics-calendar:navigate` CustomEvent with `detail.view` set to the button's label. |
| `initTimeWidget(selector?)` | Starts a one-second interval that updates the text content of every element matching `selector` (default: `'[data-widget="time"]'`) with the current locale time string. Clears any previously created interval to prevent memory leaks. |

#### Listening to navigation events

```ts
document.addEventListener('analytics-calendar:navigate', (event: Event) => {
    const { view } = (event as CustomEvent<{ view: string }>).detail;
    console.log('Calendar navigation requested:', view);
    // 'Monatsübersicht' | 'Heute' | 'Diese Woche'
});
```

#### Marking a time widget container in Twig

The time widget template uses a plain `time` string as its content. Add the
`data-widget="time"` attribute to the element you want the live clock to
target:

```twig
{# templates/widget/time.html.twig #}
<span data-widget="time"></span>
```

## Configuration

The bundle exposes a **General Calendar Settings** group under the key `calendarBundle.general`, accessible through the *Kalenderverwaltung* (Calendar Management) menu in the Analytics admin panel.

| Configuration Key | Label | Type | Default | Description |
|---|---|---|---|---|
| `calendarBundle.general.defaultDateFormat` | Standard Datumsformat | Text | `d.m.Y` | PHP date format used for displaying dates |
| `calendarBundle.general.defaultTimeFormat` | Standard Zeitformat | Text | `H:i` | PHP date format used for displaying times |
| `calendarBundle.general.defaultDateTimeFormat` | Standard Datums- und Zeitformat | Text | `d.m.Y H:i` | PHP date format used for displaying date and time together |
| `calendarBundle.general.defaultWeekStart` | Standard Wochenstart | Select | `1` (Monday) | First day of the week: 1 = Monday … 7 = Sunday |

## Widgets

### Calendar Widget

**Widget name:** `calendar`

Renders a monthly calendar grid (5 rows × 7 columns) in a dark-themed card. The widget exposes navigation buttons for *Monatsübersicht* (month view), *Heute* (today), and *Diese Woche* (this week).

**Required role:** `ROLE_USER`

**Preload placeholders layout:**

| Row | Height | Column widths |
|-----|--------|---------------|
| 1 | 50 px | 33 % · 33 % · 33 % |
| 2 | 220 px | 100 % |
| 3 | 50 px | 75 % · 25 % |

**Template:** `templates/widget/calendar.html.twig`

The template receives a `lines` property containing a two-dimensional array of day numbers that represents the calendar grid:

```php
[
    [1,  2,  3,  4,  5,  6,  7],
    [8,  9,  10, 11, 12, 13, 14],
    [15, 16, 17, 18, 19, 20, 21],
    [22, 23, 24, 25, 26, 27, 28],
    [29, 30, 31,  1,  2,  3,  4],
]
```

### Time Widget

**Widget name:** `time`

A minimal widget that displays the current time.

**Preload placeholders layout:**

| Row | Height | Column widths |
|-----|--------|---------------|
| 1 | 50 px | 50 % · 50 % |

**Template:** `templates/widget/time.html.twig`

## Entities

### Entity: Appointment

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Entity\Appointment`  
**Database table:** `calendar_appointment`

| Property | Type | Nullable | Description |
|----------|------|----------|-------------|
| `id` | `int` | No | Auto-generated primary key |
| `title` | `string(255)` | No | Title of the appointment |
| `description` | `text` | Yes | Optional detailed description |
| `startDate` | `DateTime` | No | Start date and time |
| `endDate` | `DateTime` | Yes | Optional end date and time |
| `repeatInterval` | `int` | Yes | Recurrence interval in days |
| `reminderTimer` | `int` | Yes | Reminder offset in seconds before the appointment |
| `calendar` | `Calendar` | Yes | Collection the appointment belongs to |
| `uid` | `string(255)` | Yes | iCalendar `UID`, generated locally or taken over from the client |
| `uri` | `string(255)` | Yes | File name inside the CalDAV collection, unique per calendar |
| `location` | `string(255)` | Yes | Place of the appointment |
| `allDay` | `bool` | No | Whether the appointment covers whole days |
| `rrule` | `string(255)` | Yes | Raw recurrence rule, e.g. `FREQ=WEEKLY;BYDAY=MO,WE` |
| `timezone` | `string(64)` | Yes | Olson identifier the client used |
| `sequence` | `int` | No | iCalendar revision counter of the object |
| `icalData` | `text` | Yes | Verbatim calendar object as delivered by a client |
| `etag` | `string(64)` | Yes | Entity tag derived from `icalData` |
| `syncRevision` | `int` | No | Revision of the calendar at the last change |
| `createdAt` / `updatedAt` | `DateTime` | Yes | Timestamps |

`repeatInterval` and `rrule` describe the same thing at different levels of
detail. A rule that is a plain daily or weekly repetition is mirrored into
`repeatInterval`; anything more specific keeps `repeatInterval` empty and lives
in `rrule` alone. When an appointment is rendered, `rrule` wins.

For all-day appointments `endDate` follows the iCalendar convention and is
*exclusive*: an appointment covering only 1 April ends on 2 April.

**Example usage:**

```php
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;

$appointment = new Appointment();
$appointment
    ->setTitle('Team Meeting')
    ->setStartDate(new \DateTime('2026-04-01 10:00'))
    ->setEndDate(new \DateTime('2026-04-01 11:00'))
    ->setDescription('Weekly sync call')
    ->setRepeatInterval(7)      // repeats every 7 days
    ->setReminderTimer(900);    // reminder 15 minutes (900 s) before start

$entityManager->persist($appointment);
$entityManager->flush();
```

All setters return `static` to allow method chaining.

### Entity: Calendar

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Entity\Calendar`  
**Database table:** `calendar_calendar`

One calendar collection of a user. Each collection shows up as a separate
calendar inside the calendar app of a connected device.

| Property | Type | Nullable | Description |
|----------|------|----------|-------------|
| `owner` | `User` | No | Account the calendar belongs to |
| `uri` | `string(64)` | No | Last path segment of the CalDAV URL, unique per owner |
| `displayName` | `string(255)` | No | Name shown by the client |
| `description` | `text` | Yes | Optional description |
| `color` | `string(9)` | Yes | Colour used by Apple clients, `#RRGGBB` or `#RRGGBBAA` |
| `timezone` | `string(64)` | Yes | Default timezone of the calendar |
| `syncToken` | `int` | No | Revision counter backing `ctag` and `sync-token` |
| `calendarOrder` | `int` | No | Sort order used by Apple clients |

The default calendar (`uri` = `default`) is created on first access, so a
freshly configured device always finds a collection.

### Entity: CalendarAccessToken

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Entity\CalendarAccessToken`  
**Database table:** `calendar_access_token`

The credential a calendar client authenticates with. Only the SHA-256 digest of
the secret is stored — the secret itself is shown once, when it is issued.

| Property | Type | Nullable | Description |
|----------|------|----------|-------------|
| `user` | `User` | No | Account the credential grants access to |
| `label` | `string(100)` | No | Name of the device |
| `type` | `EAccessTokenType` | No | `caldav` (read/write) or `feed` (read-only) |
| `tokenHash` | `string(64)` | No | SHA-256 digest of the secret, unique |
| `tokenPreview` | `string(16)` | No | First characters, for recognising it in listings |
| `calendar` | `Calendar` | Yes | Restriction to a single calendar; `NULL` means all |
| `expiresAt` | `DateTime` | Yes | Optional expiry |
| `lastUsedAt` | `DateTime` | Yes | Last successful use, updated at most every 5 minutes |
| `revokedAt` | `DateTime` | Yes | Set when the credential was withdrawn |

### Entity: CalendarDeletedObject

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Entity\CalendarDeletedObject`  
**Database table:** `calendar_deleted_object`

Tombstone of a removed appointment, holding calendar, `uri` and the revision at
which the deletion happened. WebDAV synchronisation needs it to report removals
to a client that syncs with a `sync-token`.

## Repository: AppointmentRepository

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository`

Extends `Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository` and provides all standard Doctrine query methods out of the box:

```php
// Inject the repository via autowiring or fetch from the entity manager
$repository = $entityManager->getRepository(Appointment::class);

// Find all appointments
$appointments = $repository->findAll();

// Find a single appointment by primary key
$appointment = $repository->find($id);

// Find appointments matching specific criteria
$appointments = $repository->findBy(['title' => 'Team Meeting']);
```

In addition it provides the lookups the CalDAV endpoint needs:

| Method | Description |
|---|---|
| `findByCalendar(Calendar)` | Every appointment of a collection, ordered by start |
| `findOneByCalendarAndUri(Calendar, string)` | The object behind a CalDAV URL |
| `findOneByCalendarAndUid(Calendar, string)` | Lookup by iCalendar `UID` |
| `findChangedSince(Calendar, int)` | Everything changed after a revision |
| `findInRange(Calendar, ?DateTimeInterface, ?DateTimeInterface)` | Appointments overlapping a period; recurring ones are always included, because whether an occurrence falls into the period is only known after the rule has been expanded |
| `findWithoutCalendar()` | Appointments not assigned to a collection yet |

## Macros

Macros are reusable operations that can be invoked programmatically within the Analytics platform.

### AddAppointmentMacro

**Macro name:** `addAppointment`  
**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Macro\AddAppointmentMacro`  
**Description:** Adds an appointment to the calendar.

All calendar macros extend `AbstractCalendarMacro`, which sets the macro source to `"InfrastructureBundle"` during initialisation.

```php
// Resolve and run the macro through the Analytics macro runner
$macro = $container->get(AddAppointmentMacro::class);
$macro->init();
$result = $macro->run();
```

> **Note:** The `run()` method currently returns an empty result set. Appointment data input is planned for a future release.

## Permissions

The bundle defines a single permission used to control access to the calendar management interface:

| Permission | Value | Description |
|---|---|---|
| `EPermission::ACCESS_INFRASTRUCTURE` | `ACCESS_INFRASTRUCTURE` | Grants access to the calendar management area |

```php
use Cehlers88\AnalyticsCalendarBundle\ENUM\EPermission;

// Check all bundle permissions
$permissions = EPermission::getPermissions();
// Returns: ['ACCESS_INFRASTRUCTURE']
```

## Tests

The iCalendar reader and writer, the mapping between appointments and calendar
objects and the CalDAV XML layer are covered by unit tests:

```bash
composer install
vendor/bin/phpunit
```

The suite fixes `date.timezone` to `Europe/Berlin`, because appointments are
stored as wall clock time of the server timezone and the conversion to and from
UTC is part of what is being tested.

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a full version history.
