# iPhone mit dem Kalender verbinden

Diese Anleitung beschreibt, wie du deine Termine künftig vollständig in
Analytics pflegst und sie auf dem iPhone (iPad, Mac, Apple Watch) siehst und
bearbeitest.

Es gibt zwei Wege. Der erste ist der, den du vermutlich willst:

| | **CalDAV-Account** | **Kalender-Abo** |
|---|---|---|
| Termine ansehen | ✅ | ✅ |
| Termine am iPhone anlegen/ändern/löschen | ✅ | ❌ nur lesend |
| Erinnerungen (Wecker) | ✅ | ✅ |
| Einrichtung | Account anlegen, Passwort eintippen | eine URL eintragen |
| Aktualisierung | sofort (Push-Abfrage durch iOS) | im Intervall, meist stündlich |

**Empfehlung:** CalDAV. Das Abo ist die einfache Variante, wenn ein Gerät den
Kalender nur anzeigen soll (z.B. ein fremdes Gerät oder ein Familienkalender).

---

## Inhalt

1. [Voraussetzungen](#1-voraussetzungen)
2. [Einmalige Einrichtung der Anwendung](#2-einmalige-einrichtung-der-anwendung)
3. [Zugang für ein Gerät erzeugen](#3-zugang-für-ein-gerät-erzeugen)
4. [iPhone einrichten – CalDAV](#4-iphone-einrichten--caldav)
5. [iPhone einrichten – Kalender-Abo](#5-iphone-einrichten--kalender-abo)
6. [Weitere Programme](#6-weitere-programme)
7. [Zugänge verwalten](#7-zugänge-verwalten)
8. [Sicherheit](#8-sicherheit)
9. [Wenn etwas nicht funktioniert](#9-wenn-etwas-nicht-funktioniert)
10. [Wie es technisch funktioniert](#10-wie-es-technisch-funktioniert)

---

## 1. Voraussetzungen

* Die Installation ist **über HTTPS** aus dem Internet erreichbar. iOS
  verweigert die Einrichtung eines CalDAV-Accounts über unverschlüsseltes HTTP,
  und das Gerätepasswort würde sonst im Klartext übertragen.
* Das Zertifikat ist gültig (Let's Encrypt reicht). Selbst signierte
  Zertifikate werden von iOS abgelehnt.
* Der Webserver leitet **alle** HTTP-Methoden an die Anwendung weiter. CalDAV
  benutzt neben `GET`/`PUT`/`DELETE` auch `PROPFIND`, `PROPPATCH`, `REPORT`,
  `OPTIONS` und `MKCALENDAR`. FrankenPHP/Caddy und die nginx-Konfiguration aus
  `nginx/site.conf` tun das bereits; nur wer eine eigene Regel mit
  `limit_except` betreibt, muss diese Methoden dort ergänzen.

## 2. Einmalige Einrichtung der Anwendung

### 2.1 Routen einbinden

Das Bundle bringt seine Routen mit, die Anwendung muss sie einmal importieren:

```yaml
# config/routes.yaml der Anwendung
analytics_calendar_bundle:
  resource: '@AnalyticsCalendarBundle/Resources/config/routes.yaml'
```

Bitte **ohne** `prefix`: Kalenderprogramme merken sich die Adressen dauerhaft,
die Pfade `/caldav`, `/.well-known/caldav` und `/calendar/feed` liegen deshalb
fest.

### 2.2 Datenbank aktualisieren

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

Dabei entstehen die Tabellen `calendar_calendar`, `calendar_access_token` und
`calendar_deleted_object`; `calendar_appointment` bekommt zusätzliche Spalten.
Bestehende Termine bleiben erhalten.

### 2.3 Vorhandene Termine übernehmen

Termine, die vor der Umstellung angelegt wurden, gehören noch zu keinem
Kalender und haben keine iCalendar-Kennung. Ein Befehl holt das nach:

```bash
php bin/console analytics:calendar:setup deine@adresse.de
```

Mit `--dry-run` siehst du vorher, wie viele Termine betroffen sind. Ohne
Altbestand ist der Aufruf nicht nötig – der Standardkalender entsteht beim
ersten Zugriff von selbst.

### 2.4 Zugriff prüfen

```bash
curl -i -X OPTIONS https://deine-domain.de/caldav/
```

Erwartet wird `204 No Content` mit einer Kopfzeile
`DAV: 1, 2, 3, access-control, calendar-access, extended-mkcol`. Fehlt sie,
kommen die Anfragen nicht bei der Anwendung an (siehe
[Abschnitt 9](#9-wenn-etwas-nicht-funktioniert)).

## 3. Zugang für ein Gerät erzeugen

Das Anmeldepasswort deines Benutzerkontos wird bewusst **nicht** akzeptiert.
Ein Telefon speichert die Zugangsdaten dauerhaft und schickt sie bei jeder
Synchronisation mit; deshalb bekommt jedes Gerät ein eigenes, jederzeit
widerrufbares Passwort.

```bash
php bin/console analytics:calendar:token:create deine@adresse.de \
    --label="iPhone 16" \
    --base-url=https://deine-domain.de
```

Ausgabe:

```
 Serveradresse   https://deine-domain.de/caldav/
 Benutzername    deine@adresse.de
 Passwort        hkm4p-qr7st-3wxyz-abc29
```

Das Passwort wird **nur dieses eine Mal angezeigt**. Geht es verloren, ziehst du
den Zugang zurück und erzeugst einen neuen.

Nützliche Optionen:

| Option | Bedeutung |
|---|---|
| `--label` | Bezeichnung des Geräts, erscheint in der Übersicht |
| `--type=feed` | erzeugt statt des CalDAV-Zugangs eine Abo-Adresse (Abschnitt 5) |
| `--calendar=privat` | beschränkt den Zugang auf einen einzelnen Kalender |
| `--expires="+1 year"` | lässt den Zugang automatisch ablaufen |
| `--base-url` | nur für die Anzeige der fertigen Adressen |

## 4. iPhone einrichten – CalDAV

1. **Einstellungen** öffnen.
2. **Apps → Kalender → Accounts → Account hinzufügen** (unter iOS 17 und älter:
   *Einstellungen → Kalender → Accounts → Account hinzufügen*).
3. **Andere** wählen.
4. Unter *KALENDER* auf **CalDAV-Account hinzufügen** tippen.
5. Eintragen:
   * **Server:** `deine-domain.de` — die Domain genügt, iOS findet den Dienst
     über `/.well-known/caldav` selbst. Falls das scheitert, trage die
     vollständige Adresse `https://deine-domain.de/caldav/` ein.
   * **Benutzername:** deine E-Mail-Adresse
   * **Passwort:** das erzeugte Gerätepasswort
   * **Beschreibung:** frei wählbar, z.B. „Analytics“
6. **Weiter** → iOS prüft die Verbindung → **Sichern**.

Danach erscheint der Kalender in der Kalender-App. Neue Termine legst du dort
über **Kalender** → *Analytics* an; sie stehen anschließend auch in der
Weboberfläche. Umgekehrt tauchen dort angelegte Termine nach der nächsten
Synchronisation auf dem Telefon auf (iOS fragt selbstständig nach, „Pull to
refresh“ in der Kalenderliste erzwingt es sofort).

> **Mehrere Kalender:** In der Kalender-App kannst du über *Kalender →
> Hinzufügen → Kalender hinzufügen* weitere Kalender im Account anlegen
> (z.B. „Privat“ und „Arbeit“). Sie entstehen dann auch serverseitig.

## 5. iPhone einrichten – Kalender-Abo

Nur lesend, dafür ohne Account:

```bash
php bin/console analytics:calendar:token:create deine@adresse.de \
    --type=feed --label="Abo iPhone" --base-url=https://deine-domain.de
```

Die Ausgabe enthält eine Adresse der Form
`https://deine-domain.de/calendar/feed/<geheimnis>.ics` sowie dieselbe Adresse
mit vorangestelltem `webcal://`.

**Am iPhone:** Einstellungen → **Apps → Kalender → Accounts → Account
hinzufügen → Andere → Kalenderabo hinzufügen**, dann die Adresse einfügen.

Alternativ genügt es, die `webcal://`-Adresse auf dem Telefon zu öffnen (z.B.
aus einer Nachricht heraus) – iOS bietet das Abo dann direkt an.

Einzelne Kalender lassen sich gezielt abonnieren, indem die URI des Kalenders
angehängt wird:
`https://deine-domain.de/calendar/feed/<geheimnis>/privat.ics`

## 6. Weitere Programme

Der Endpunkt ist Standard-CalDAV, die Zugangsdaten aus Abschnitt 3 gelten
überall:

* **macOS Kalender:** Kalender → Einstellungen → Accounts → „+“ → Anderer
  CalDAV-Account → Accounttyp *Manuell* → Benutzername, Passwort und
  Serveradresse `https://deine-domain.de/caldav/`.
* **Thunderbird:** Neuer Kalender → Im Netzwerk → CalDAV → Adresse
  `https://deine-domain.de/caldav/calendars/<benutzer-id>/default/`.
* **Android:** mit [DAVx⁵](https://www.davx5.com/) – Basisadresse und
  Zugangsdaten wie beim iPhone.

## 7. Zugänge verwalten

```bash
# Übersicht über alle vergebenen Zugänge
php bin/console analytics:calendar:token:list

# nur die eines Benutzers
php bin/console analytics:calendar:token:list deine@adresse.de

# Gerät verloren? Zugang sofort zurückziehen
php bin/console analytics:calendar:token:revoke 3
```

Die Übersicht zeigt Bezeichnung, Art, betroffenen Kalender, die ersten Zeichen
des Geheimnisses und wann der Zugang zuletzt benutzt wurde. Damit lässt sich
erkennen, ob ein Gerät noch synchronisiert.

## 8. Sicherheit

* Die Geheimnisse werden **nicht im Klartext gespeichert**, sondern nur als
  SHA-256-Prüfsumme. Ein Blick in die Datenbank verrät sie nicht.
* Jeder Zugang gilt für **genau ein Benutzerkonto**. Ein Zugriff auf den
  Kalenderzweig eines anderen Kontos wird mit `403` abgewiesen, selbst wenn die
  Adresse erraten wird.
* Ein zurückgezogener oder abgelaufener Zugang funktioniert ab dem nächsten
  Zugriff nicht mehr; das Telefon meldet dann einen Anmeldefehler.
* Die Abo-Adresse enthält das Geheimnis im Pfad. Wer sie kennt, kann die
  Termine lesen – behandle sie wie ein Passwort und benutze für ein Abo, das du
  weitergibst, einen eigenen, auf einen Kalender beschränkten Zugang.
* Antworten des Endpunkts werden mit `Cache-Control: no-store` ausgeliefert,
  damit keine Zwischenstation Kalenderdaten aufbewahrt.

## 9. Wenn etwas nicht funktioniert

**iOS meldet „Der Account konnte nicht überprüft werden“**

* Adresse mit `https://` und ohne Tippfehler? Zum Test die vollständige Adresse
  `https://deine-domain.de/caldav/` statt nur der Domain eintragen.
* Prüfen, ob der Endpunkt antwortet:

  ```bash
  curl -i -u 'deine@adresse.de:dein-geheimnis' \
       -X PROPFIND -H 'Depth: 0' https://deine-domain.de/caldav/
  ```

  Erwartet wird `207 Multi-Status` mit einem XML-Dokument. Kommt `401`, stimmen
  Benutzername oder Passwort nicht. Kommt `405`, blockiert der Webserver die
  Methode. Kommt `404`, ist die Route aus Abschnitt 2.1 nicht eingebunden.

**Anmeldung schlägt trotz richtigem Passwort fehl**

Manche Serverkonfigurationen reichen den `Authorization`-Header nicht an PHP
weiter. Für nginx mit PHP-FPM hilft:

```nginx
fastcgi_param HTTP_AUTHORIZATION $http_authorization;
```

Bei Apache:

```apache
CGIPassAuth On
```

**Der Kalender bleibt leer**

Termine aus der Zeit vor der Umstellung gehören noch zu keinem Kalender –
`php bin/console analytics:calendar:setup deine@adresse.de` ausführen
(Abschnitt 2.3).

**Änderungen kommen nicht an**

iOS synchronisiert Kalender in Intervallen. Unter *Einstellungen → Apps →
Kalender → Accounts → Datenabgleich* lässt sich das Intervall verkürzen. In der
Kalender-App erzwingt ein Herunterziehen der Kalenderliste einen sofortigen
Abgleich.

**Ein Termin verschwindet nach dem Anlegen wieder**

Das deutet auf eine abgelehnte Änderung hin. Ein Blick ins Server-Log zeigt die
Antwort auf das `PUT`: `400` bedeutet, dass das Kalenderobjekt nicht gelesen
werden konnte, `412` einen Änderungskonflikt (dann genügt meist ein erneuter
Abgleich).

## 10. Wie es technisch funktioniert

* Das Bundle stellt unter `/caldav` einen **CalDAV-Server** (RFC 4791) mit
  WebDAV-Synchronisation (RFC 6578) bereit. Jeder Kalender ist eine Sammlung,
  jeder Termin darin ein `.ics`-Objekt.
* Angemeldet wird sich per **HTTP Basic** – das ist, was Kalenderprogramme
  sprechen. Die Prüfung findet im Endpunkt selbst statt, nicht in der
  Symfony-Firewall, damit an der Sicherheitskonfiguration der Anwendung nichts
  geändert werden muss.
* Jede Änderung erhöht einen Zähler am Kalender. Aus ihm entstehen `ctag` und
  `sync-token`; das Telefon fragt darüber nur die Unterschiede seit seinem
  letzten Abgleich ab statt jedes Mal alle Termine.
* Gelöschte Termine hinterlassen einen Eintrag in `calendar_deleted_object`,
  damit die Löschung auch bei einem Abgleich über `sync-token` gemeldet werden
  kann.
* Ein vom Telefon geschicktes Kalenderobjekt wird **unverändert gespeichert**
  und beim nächsten Abruf unverändert zurückgegeben. Zusätzlich werden Titel,
  Zeitraum, Ort, Beschreibung, Wiederholung und Erinnerung in die Felder des
  Termins übernommen, damit die Weboberfläche und die Auswertungen damit
  arbeiten können. Eigenschaften, die dieses Bundle nicht kennt (Teilnehmer,
  Anhänge, eigene Felder), gehen dadurch trotzdem nicht verloren.
* Zeitangaben werden in UTC ausgeliefert. Termine über den ganzen Tag benutzen
  Datumswerte ohne Uhrzeit, ihr Ende ist – wie im Standard – der **Folgetag**.
