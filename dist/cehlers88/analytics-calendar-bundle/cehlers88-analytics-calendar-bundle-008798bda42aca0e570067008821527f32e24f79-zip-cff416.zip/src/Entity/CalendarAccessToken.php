<?php

namespace Cehlers88\AnalyticsCalendarBundle\Entity;

use Cehlers88\AnalyticsCalendarBundle\ENUM\EAccessTokenType;
use Cehlers88\AnalyticsCalendarBundle\Repository\CalendarAccessTokenRepository;
use Cehlers88\AnalyticsCore\Entity\User;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * Credential a calendar client uses to reach the calendar of a single user.
 *
 * The secret itself is never stored; only its SHA-256 digest is kept so that a
 * leaked database does not hand out calendar access. Because the secret is a
 * 256 bit random value, an unsalted digest is sufficient here and it keeps the
 * lookup a single indexed query.
 */
#[ORM\Entity(repositoryClass: CalendarAccessTokenRepository::class)]
#[ORM\Table(name: 'calendar_access_token')]
#[ORM\UniqueConstraint(name: 'UNIQ_CALENDAR_TOKEN_HASH', columns: ['token_hash'])]
class CalendarAccessToken
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private ?User $user = null;

    /**
     * Human readable name of the device, e.g. "iPhone von Christoph".
     */
    #[ORM\Column(length: 100)]
    private string $label = '';

    #[ORM\Column(length: 16, enumType: EAccessTokenType::class)]
    private EAccessTokenType $type = EAccessTokenType::CALDAV;

    #[ORM\Column(length: 64)]
    private string $tokenHash = '';

    /**
     * First characters of the secret, so an existing token can be recognised in
     * listings without being able to reconstruct it.
     */
    #[ORM\Column(length: 16)]
    private string $tokenPreview = '';

    /**
     * Optional restriction to a single calendar. NULL grants access to every
     * calendar of the user.
     */
    #[ORM\ManyToOne(targetEntity: Calendar::class)]
    #[ORM\JoinColumn(nullable: true, onDelete: 'CASCADE')]
    private ?Calendar $calendar = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $createdAt;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $expiresAt = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $lastUsedAt = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $revokedAt = null;

    public function __construct()
    {
        $this->createdAt = new \DateTime();
    }

    /**
     * Hashes a plaintext secret the same way it is stored.
     */
    public static function hashSecret(string $secret): string
    {
        return hash('sha256', $secret);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(User $user): static
    {
        $this->user = $user;

        return $this;
    }

    public function getLabel(): string
    {
        return $this->label;
    }

    public function setLabel(string $label): static
    {
        $this->label = $label;

        return $this;
    }

    public function getType(): EAccessTokenType
    {
        return $this->type;
    }

    public function setType(EAccessTokenType $type): static
    {
        $this->type = $type;

        return $this;
    }

    public function getTokenHash(): string
    {
        return $this->tokenHash;
    }

    public function setTokenHash(string $tokenHash): static
    {
        $this->tokenHash = $tokenHash;

        return $this;
    }

    public function getTokenPreview(): string
    {
        return $this->tokenPreview;
    }

    public function setTokenPreview(string $tokenPreview): static
    {
        $this->tokenPreview = $tokenPreview;

        return $this;
    }

    public function getCalendar(): ?Calendar
    {
        return $this->calendar;
    }

    public function setCalendar(?Calendar $calendar): static
    {
        $this->calendar = $calendar;

        return $this;
    }

    public function getCreatedAt(): \DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): static
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getExpiresAt(): ?\DateTimeInterface
    {
        return $this->expiresAt;
    }

    public function setExpiresAt(?\DateTimeInterface $expiresAt): static
    {
        $this->expiresAt = $expiresAt;

        return $this;
    }

    public function getLastUsedAt(): ?\DateTimeInterface
    {
        return $this->lastUsedAt;
    }

    public function setLastUsedAt(?\DateTimeInterface $lastUsedAt): static
    {
        $this->lastUsedAt = $lastUsedAt;

        return $this;
    }

    public function getRevokedAt(): ?\DateTimeInterface
    {
        return $this->revokedAt;
    }

    public function setRevokedAt(?\DateTimeInterface $revokedAt): static
    {
        $this->revokedAt = $revokedAt;

        return $this;
    }

    public function isRevoked(): bool
    {
        return null !== $this->revokedAt;
    }

    public function isExpired(?\DateTimeInterface $now = null): bool
    {
        if (null === $this->expiresAt) {
            return false;
        }

        return $this->expiresAt < ($now ?? new \DateTime());
    }

    public function isUsable(?\DateTimeInterface $now = null): bool
    {
        return !$this->isRevoked() && !$this->isExpired($now);
    }
}
