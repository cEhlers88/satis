<?php

namespace Cehlers88\AnalyticsCalendarBundle\Entity;

use Cehlers88\AnalyticsCalendarBundle\Repository\CalendarDeletedObjectRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * Tombstone of a removed calendar object.
 *
 * WebDAV sync (RFC 6578) requires the server to be able to tell a client which
 * resources vanished since the client's last sync token. Because the row of the
 * appointment itself is gone by then, the deletion is recorded here.
 */
#[ORM\Entity(repositoryClass: CalendarDeletedObjectRepository::class)]
#[ORM\Table(name: 'calendar_deleted_object')]
#[ORM\Index(name: 'IDX_DELETED_OBJECT_SYNC', columns: ['calendar_id', 'sync_revision'])]
class CalendarDeletedObject
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Calendar::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private ?Calendar $calendar = null;

    #[ORM\Column(length: 255)]
    private string $uri = '';

    #[ORM\Column]
    private int $syncRevision = 0;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $deletedAt;

    public function __construct()
    {
        $this->deletedAt = new \DateTime();
    }

    public static function create(Calendar $calendar, string $uri, int $syncRevision): self
    {
        $tombstone = new self();
        $tombstone->calendar = $calendar;
        $tombstone->uri = $uri;
        $tombstone->syncRevision = $syncRevision;

        return $tombstone;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCalendar(): ?Calendar
    {
        return $this->calendar;
    }

    public function setCalendar(Calendar $calendar): static
    {
        $this->calendar = $calendar;

        return $this;
    }

    public function getUri(): string
    {
        return $this->uri;
    }

    public function setUri(string $uri): static
    {
        $this->uri = $uri;

        return $this;
    }

    public function getSyncRevision(): int
    {
        return $this->syncRevision;
    }

    public function setSyncRevision(int $syncRevision): static
    {
        $this->syncRevision = $syncRevision;

        return $this;
    }

    public function getDeletedAt(): \DateTimeInterface
    {
        return $this->deletedAt;
    }

    public function setDeletedAt(\DateTimeInterface $deletedAt): static
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }
}
