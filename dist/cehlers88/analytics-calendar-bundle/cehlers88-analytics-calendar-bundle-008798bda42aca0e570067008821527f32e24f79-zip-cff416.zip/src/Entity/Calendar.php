<?php

namespace Cehlers88\AnalyticsCalendarBundle\Entity;

use Cehlers88\AnalyticsCalendarBundle\Repository\CalendarRepository;
use Cehlers88\AnalyticsCore\Entity\User;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * A calendar collection. Every calendar is exposed as one CalDAV collection and
 * therefore shows up as a separate calendar inside the iOS calendar app.
 */
#[ORM\Entity(repositoryClass: CalendarRepository::class)]
#[ORM\Table(name: 'calendar_calendar')]
#[ORM\UniqueConstraint(name: 'UNIQ_CALENDAR_OWNER_URI', columns: ['owner_id', 'uri'])]
class Calendar
{
    public const DEFAULT_URI = 'default';
    public const DEFAULT_DISPLAY_NAME = 'Kalender';
    public const DEFAULT_COLOR = '#3b82f6';

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private ?User $owner = null;

    /**
     * Last path segment of the CalDAV collection URL. Must be stable, because
     * clients remember it.
     */
    #[ORM\Column(length: 64)]
    private string $uri = self::DEFAULT_URI;

    #[ORM\Column(length: 255)]
    private string $displayName = self::DEFAULT_DISPLAY_NAME;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    /**
     * Colour shown by Apple clients, either #RRGGBB or #RRGGBBAA.
     */
    #[ORM\Column(length: 9, nullable: true)]
    private ?string $color = self::DEFAULT_COLOR;

    #[ORM\Column(length: 64, nullable: true)]
    private ?string $timezone = null;

    /**
     * Monotonically increasing revision counter. It backs both the WebDAV
     * sync-token and the CalendarServer ctag, so any change to any object of
     * this collection must increase it.
     */
    #[ORM\Column(options: ['default' => 1])]
    private int $syncToken = 1;

    #[ORM\Column(options: ['default' => 0])]
    private int $calendarOrder = 0;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $createdAt;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $updatedAt;

    /**
     * @var Collection<int, Appointment>
     */
    #[ORM\OneToMany(targetEntity: Appointment::class, mappedBy: 'calendar')]
    private Collection $appointments;

    public function __construct()
    {
        $this->appointments = new ArrayCollection();
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
    }

    public static function create(User $owner, string $uri = self::DEFAULT_URI, string $displayName = self::DEFAULT_DISPLAY_NAME): self
    {
        $calendar = new self();
        $calendar->owner = $owner;
        $calendar->uri = $uri;
        $calendar->displayName = $displayName;

        return $calendar;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getOwner(): ?User
    {
        return $this->owner;
    }

    public function setOwner(User $owner): static
    {
        $this->owner = $owner;

        return $this;
    }

    public function getUri(): string
    {
        return $this->uri;
    }

    public function setUri(string $uri): static
    {
        $this->uri = $uri;

        return $this;
    }

    public function getDisplayName(): string
    {
        return $this->displayName;
    }

    public function setDisplayName(string $displayName): static
    {
        $this->displayName = $displayName;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getColor(): ?string
    {
        return $this->color;
    }

    public function setColor(?string $color): static
    {
        $this->color = $color;

        return $this;
    }

    public function getTimezone(): ?string
    {
        return $this->timezone;
    }

    public function setTimezone(?string $timezone): static
    {
        $this->timezone = $timezone;

        return $this;
    }

    public function getSyncToken(): int
    {
        return $this->syncToken;
    }

    public function setSyncToken(int $syncToken): static
    {
        $this->syncToken = $syncToken;

        return $this;
    }

    /**
     * Increases the revision counter and returns the new value. Every created,
     * changed or deleted calendar object has to be stamped with it.
     */
    public function bumpSyncToken(): int
    {
        ++$this->syncToken;
        $this->updatedAt = new \DateTime();

        return $this->syncToken;
    }

    public function getCalendarOrder(): int
    {
        return $this->calendarOrder;
    }

    public function setCalendarOrder(int $calendarOrder): static
    {
        $this->calendarOrder = $calendarOrder;

        return $this;
    }

    public function getCreatedAt(): \DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): static
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedAt(): \DateTimeInterface
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(\DateTimeInterface $updatedAt): static
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * @return Collection<int, Appointment>
     */
    public function getAppointments(): Collection
    {
        return $this->appointments;
    }

    /**
     * Entity tag of the whole collection ("ctag"). Apple clients use it to
     * detect whether a full re-scan of the collection is necessary at all.
     */
    public function getCtag(): string
    {
        return sprintf('%d-%d', $this->id ?? 0, $this->syncToken);
    }
}
