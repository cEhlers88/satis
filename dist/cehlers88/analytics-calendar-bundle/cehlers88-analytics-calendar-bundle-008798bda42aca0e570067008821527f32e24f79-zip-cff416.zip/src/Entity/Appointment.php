<?php

namespace Cehlers88\AnalyticsCalendarBundle\Entity;

use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: AppointmentRepository::class)]
#[ORM\Table(name: 'calendar_appointment')]
#[ORM\UniqueConstraint(name: 'UNIQ_APPOINTMENT_CALENDAR_URI', columns: ['calendar_id', 'uri'])]
#[ORM\Index(name: 'IDX_APPOINTMENT_UID', columns: ['uid'])]
#[ORM\Index(name: 'IDX_APPOINTMENT_SYNC', columns: ['calendar_id', 'sync_revision'])]
class Appointment
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $startDate = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $endDate = null;

    #[ORM\Column(nullable: true)]
    private ?int $repeatInterval = null;

    #[ORM\Column(nullable: true)]
    private ?int $reminderTimer = null;

    #[ORM\Column(length: 255)]
    private ?string $title = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    #[ORM\ManyToOne(targetEntity: Calendar::class, inversedBy: 'appointments')]
    #[ORM\JoinColumn(nullable: true, onDelete: 'CASCADE')]
    private ?Calendar $calendar = null;

    /**
     * Globally unique iCalendar identifier (RFC 5545 "UID"). It is generated
     * locally for appointments created inside the application and taken over
     * unchanged for appointments pushed by a CalDAV client.
     */
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $uid = null;

    /**
     * File name of the object inside its CalDAV collection, e.g.
     * "3F2504E0-4F89-11D3-9A0C-0305E82C3301.ics".
     */
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $uri = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $location = null;

    #[ORM\Column(options: ['default' => false])]
    private bool $allDay = false;

    /**
     * Raw RFC 5545 recurrence rule, e.g. "FREQ=WEEKLY;BYDAY=MO,WE".
     * `repeatInterval` stays in place as the simplified representation used by
     * the older parts of the bundle.
     */
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $rrule = null;

    /**
     * Olson timezone identifier the client used for this appointment.
     */
    #[ORM\Column(length: 64, nullable: true)]
    private ?string $timezone = null;

    #[ORM\Column(options: ['default' => 0])]
    private int $sequence = 0;

    /**
     * Verbatim iCalendar object as delivered by the client. Keeping it allows
     * lossless round-trips of properties this bundle does not map onto its own
     * columns (attendees, attachments, custom X- properties, ...).
     */
    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $icalData = null;

    #[ORM\Column(length: 64, nullable: true)]
    private ?string $etag = null;

    /**
     * Value of the owning calendar's sync token at the time of the last change.
     */
    #[ORM\Column(options: ['default' => 0])]
    private int $syncRevision = 0;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $createdAt = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $updatedAt = null;

    public function __construct()
    {
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getStartDate(): ?\DateTimeInterface
    {
        return $this->startDate;
    }

    public function setStartDate(\DateTimeInterface $startDate): static
    {
        $this->startDate = $startDate;

        return $this;
    }

    public function getEndDate(): ?\DateTimeInterface
    {
        return $this->endDate;
    }

    public function setEndDate(?\DateTimeInterface $endDate): static
    {
        $this->endDate = $endDate;

        return $this;
    }

    public function getRepeatInterval(): ?int
    {
        return $this->repeatInterval;
    }

    public function setRepeatInterval(?int $repeatInterval): static
    {
        $this->repeatInterval = $repeatInterval;

        return $this;
    }

    public function getReminderTimer(): ?int
    {
        return $this->reminderTimer;
    }

    public function setReminderTimer(?int $reminderTimer): static
    {
        $this->reminderTimer = $reminderTimer;

        return $this;
    }

    public function getTitle(): ?string
    {
        return $this->title;
    }

    public function setTitle(string $title): static
    {
        $this->title = $title;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getCalendar(): ?Calendar
    {
        return $this->calendar;
    }

    public function setCalendar(?Calendar $calendar): static
    {
        $this->calendar = $calendar;

        return $this;
    }

    public function getUid(): ?string
    {
        return $this->uid;
    }

    public function setUid(?string $uid): static
    {
        $this->uid = $uid;

        return $this;
    }

    public function getUri(): ?string
    {
        return $this->uri;
    }

    public function setUri(?string $uri): static
    {
        $this->uri = $uri;

        return $this;
    }

    public function getLocation(): ?string
    {
        return $this->location;
    }

    public function setLocation(?string $location): static
    {
        $this->location = $location;

        return $this;
    }

    public function isAllDay(): bool
    {
        return $this->allDay;
    }

    public function setAllDay(bool $allDay): static
    {
        $this->allDay = $allDay;

        return $this;
    }

    public function getRrule(): ?string
    {
        return $this->rrule;
    }

    public function setRrule(?string $rrule): static
    {
        $this->rrule = $rrule;

        return $this;
    }

    public function getTimezone(): ?string
    {
        return $this->timezone;
    }

    public function setTimezone(?string $timezone): static
    {
        $this->timezone = $timezone;

        return $this;
    }

    public function getSequence(): int
    {
        return $this->sequence;
    }

    public function setSequence(int $sequence): static
    {
        $this->sequence = $sequence;

        return $this;
    }

    public function getIcalData(): ?string
    {
        return $this->icalData;
    }

    public function setIcalData(?string $icalData): static
    {
        $this->icalData = $icalData;

        return $this;
    }

    public function getEtag(): ?string
    {
        return $this->etag;
    }

    public function setEtag(?string $etag): static
    {
        $this->etag = $etag;

        return $this;
    }

    public function getSyncRevision(): int
    {
        return $this->syncRevision;
    }

    public function setSyncRevision(int $syncRevision): static
    {
        $this->syncRevision = $syncRevision;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(?\DateTimeInterface $createdAt): static
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(?\DateTimeInterface $updatedAt): static
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }
}
