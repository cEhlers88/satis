<?php

namespace Cehlers88\AnalyticsCalendarBundle\CalDav;

/**
 * Reads the XML bodies of PROPFIND and REPORT requests.
 */
class CalDavRequestParser
{
    /**
     * An empty body is allowed and means "every property" (RFC 4918).
     */
    public function parsePropfind(string $body): PropfindRequest
    {
        $root = $this->loadRoot($body);

        if (null === $root) {
            return new PropfindRequest(allProp: true);
        }

        $properties = [];
        $allProp = false;
        $propName = false;

        foreach ($this->childElements($root) as $child) {
            switch ($this->clarkName($child)) {
                case '{DAV:}allprop':
                    $allProp = true;
                    break;
                case '{DAV:}propname':
                    $propName = true;
                    break;
                case '{DAV:}prop':
                    foreach ($this->childElements($child) as $requested) {
                        $properties[] = $this->clarkName($requested);
                    }
                    break;
            }
        }

        if ([] === $properties && !$propName) {
            $allProp = true;
        }

        return new PropfindRequest(array_values(array_unique($properties)), $allProp, $propName);
    }

    /**
     * @throws \InvalidArgumentException when the body is not a known report
     */
    public function parseReport(string $body): ReportRequest
    {
        $root = $this->loadRoot($body);

        if (null === $root) {
            throw new \InvalidArgumentException('A REPORT request requires a body.');
        }

        $type = $this->clarkName($root);
        $properties = [];
        $hrefs = [];
        $syncToken = null;
        $limit = null;
        $rangeStart = null;
        $rangeEnd = null;

        foreach ($this->childElements($root) as $child) {
            switch ($this->clarkName($child)) {
                case '{DAV:}prop':
                    foreach ($this->childElements($child) as $requested) {
                        $properties[] = $this->clarkName($requested);
                    }
                    break;
                case '{DAV:}href':
                    $hrefs[] = trim($child->textContent);
                    break;
                case '{DAV:}sync-token':
                    $syncToken = trim($child->textContent);
                    break;
                case '{DAV:}limit':
                case '{urn:ietf:params:xml:ns:caldav}limit':
                    $limit = $this->extractLimit($child);
                    break;
                case '{urn:ietf:params:xml:ns:caldav}filter':
                    [$rangeStart, $rangeEnd] = $this->extractTimeRange($child);
                    break;
            }
        }

        return new ReportRequest(
            $type,
            array_values(array_unique($properties)),
            $hrefs,
            $rangeStart,
            $rangeEnd,
            $syncToken,
            $limit,
        );
    }

    /**
     * Reads the outermost time-range of a calendar-query filter. Nested
     * component filters are not evaluated separately: the range of the whole
     * query is enough to narrow the result down, and CalDAV explicitly allows a
     * server to return more than the client asked for.
     *
     * @return array{0: \DateTimeInterface|null, 1: \DateTimeInterface|null}
     */
    private function extractTimeRange(\DOMElement $element): array
    {
        foreach ($element->getElementsByTagNameNS(CalDavNamespace::CALDAV, 'time-range') as $range) {
            return [
                $this->parseUtcStamp($range->getAttribute('start')),
                $this->parseUtcStamp($range->getAttribute('end')),
            ];
        }

        return [null, null];
    }

    private function extractLimit(\DOMElement $element): ?int
    {
        foreach ($this->childElements($element) as $child) {
            if ('nresults' === $child->localName) {
                $value = (int)trim($child->textContent);

                return $value > 0 ? $value : null;
            }
        }

        $value = (int)trim($element->textContent);

        return $value > 0 ? $value : null;
    }

    private function parseUtcStamp(string $value): ?\DateTimeInterface
    {
        $value = trim($value);

        if ('' === $value) {
            return null;
        }

        $utc = new \DateTimeZone('UTC');
        $date = \DateTimeImmutable::createFromFormat('Ymd\THis\Z', $value, $utc)
            ?: \DateTimeImmutable::createFromFormat('Ymd|', $value, $utc);

        return false === $date ? null : $date->setTimezone(new \DateTimeZone(date_default_timezone_get()));
    }

    private function loadRoot(string $body): ?\DOMElement
    {
        if ('' === trim($body)) {
            return null;
        }

        $document = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);

        try {
            // The bodies are supplied by an authenticated client, but parsing
            // stays locked down: no network access and no entity substitution,
            // so a request cannot pull the server into an XXE attack.
            $loaded = $document->loadXML($body, LIBXML_NONET);
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }

        if (!$loaded || !$document->documentElement instanceof \DOMElement) {
            return null;
        }

        return $document->documentElement;
    }

    /**
     * @return \DOMElement[]
     */
    private function childElements(\DOMNode $node): array
    {
        $elements = [];

        foreach ($node->childNodes as $child) {
            if ($child instanceof \DOMElement) {
                $elements[] = $child;
            }
        }

        return $elements;
    }

    private function clarkName(\DOMElement $element): string
    {
        return CalDavNamespace::name((string)$element->namespaceURI, (string)$element->localName);
    }
}
