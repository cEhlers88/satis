<?php

namespace Cehlers88\AnalyticsCalendarBundle\CalDav;

/**
 * Builds the hrefs of the CalDAV resource tree.
 *
 * Clients store these URLs permanently, so they have to stay stable and they
 * have to be percent-encoded exactly once – which is why every href of a
 * response is produced here instead of in the XML builder.
 */
class CalDavUrlBuilder
{
    public function __construct(private readonly string $basePath = CalDavResource::BASE_PATH)
    {
    }

    public function root(): string
    {
        return $this->basePath . '/';
    }

    public function principal(int $userId): string
    {
        return $this->basePath . '/principals/' . $this->encode((string)$userId) . '/';
    }

    public function calendarHome(int $userId): string
    {
        return $this->basePath . '/calendars/' . $this->encode((string)$userId) . '/';
    }

    public function calendar(int $userId, string $calendarUri): string
    {
        return $this->calendarHome($userId) . $this->encode($calendarUri) . '/';
    }

    public function object(int $userId, string $calendarUri, string $objectUri): string
    {
        return $this->calendar($userId, $calendarUri) . $this->encode($objectUri);
    }

    private function encode(string $segment): string
    {
        return rawurlencode($segment);
    }
}
