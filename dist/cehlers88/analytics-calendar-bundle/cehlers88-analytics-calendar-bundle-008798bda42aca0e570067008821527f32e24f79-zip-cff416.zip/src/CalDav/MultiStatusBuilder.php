<?php

namespace Cehlers88\AnalyticsCalendarBundle\CalDav;

/**
 * Builds the "207 Multi-Status" documents PROPFIND and REPORT answer with.
 */
class MultiStatusBuilder
{
    private \DOMDocument $document;
    private \DOMElement $multistatus;

    public function __construct()
    {
        $this->document = new \DOMDocument('1.0', 'utf-8');
        $this->document->formatOutput = true;

        $this->multistatus = $this->document->createElementNS(
            CalDavNamespace::DAV,
            CalDavNamespace::PREFIXES[CalDavNamespace::DAV] . ':multistatus',
        );

        foreach (CalDavNamespace::PREFIXES as $namespace => $prefix) {
            if (CalDavNamespace::DAV === $namespace) {
                continue;
            }

            $this->multistatus->setAttributeNS('http://www.w3.org/2000/xmlns/', 'xmlns:' . $prefix, $namespace);
        }

        $this->document->appendChild($this->multistatus);
    }

    /**
     * Adds one resource to the answer.
     *
     * @param array<string, string|\Closure|null> $properties Clark notation name => value.
     *                                                        A closure receives the property element and may append
     *                                                        arbitrary children to it.
     * @param string[]                            $notFound   Clark notation names the resource does not provide
     */
    public function addResponse(string $href, array $properties, array $notFound = []): static
    {
        $response = $this->appendElement($this->multistatus, CalDavNamespace::DAV, 'response');
        $this->appendElement($response, CalDavNamespace::DAV, 'href', $href);

        if ([] !== $properties) {
            $propstat = $this->appendElement($response, CalDavNamespace::DAV, 'propstat');
            $prop = $this->appendElement($propstat, CalDavNamespace::DAV, 'prop');

            foreach ($properties as $name => $value) {
                $element = $this->createPropertyElement($name);
                $prop->appendChild($element);

                if ($value instanceof \Closure) {
                    $value($element, $this->document);
                } elseif (null !== $value) {
                    $element->appendChild($this->document->createTextNode($value));
                }
            }

            $this->appendElement($propstat, CalDavNamespace::DAV, 'status', 'HTTP/1.1 200 OK');
        }

        if ([] !== $notFound) {
            $propstat = $this->appendElement($response, CalDavNamespace::DAV, 'propstat');
            $prop = $this->appendElement($propstat, CalDavNamespace::DAV, 'prop');

            foreach ($notFound as $name) {
                $prop->appendChild($this->createPropertyElement($name));
            }

            $this->appendElement($propstat, CalDavNamespace::DAV, 'status', 'HTTP/1.1 404 Not Found');
        }

        return $this;
    }

    /**
     * Adds a resource that only carries a status, which is how RFC 6578 reports
     * objects that have been removed since the client's last synchronisation.
     */
    public function addStatusResponse(string $href, string $status): static
    {
        $response = $this->appendElement($this->multistatus, CalDavNamespace::DAV, 'response');
        $this->appendElement($response, CalDavNamespace::DAV, 'href', $href);
        $this->appendElement($response, CalDavNamespace::DAV, 'status', $status);

        return $this;
    }

    public function setSyncToken(string $syncToken): static
    {
        $this->appendElement($this->multistatus, CalDavNamespace::DAV, 'sync-token', $syncToken);

        return $this;
    }

    public function toXml(): string
    {
        return (string)$this->document->saveXML();
    }

    /**
     * A property element whose value is a single href.
     */
    public static function href(string $href): \Closure
    {
        return static function (\DOMElement $element, \DOMDocument $document) use ($href): void {
            $child = $document->createElementNS(CalDavNamespace::DAV, 'd:href');
            $child->appendChild($document->createTextNode($href));
            $element->appendChild($child);
        };
    }

    /**
     * A property element containing a list of empty child elements, e.g. the
     * resourcetype of a calendar collection.
     *
     * @param string[] $names Clark notation names
     */
    public static function elements(array $names): \Closure
    {
        return static function (\DOMElement $element, \DOMDocument $document) use ($names): void {
            foreach ($names as $name) {
                [$namespace, $localName] = CalDavNamespace::split($name);
                $prefix = CalDavNamespace::PREFIXES[$namespace] ?? 'd';
                $element->appendChild($document->createElementNS($namespace, $prefix . ':' . $localName));
            }
        };
    }

    private function createPropertyElement(string $clarkName): \DOMElement
    {
        [$namespace, $localName] = CalDavNamespace::split($clarkName);

        if ('' === $namespace) {
            return $this->document->createElement($localName);
        }

        $prefix = CalDavNamespace::PREFIXES[$namespace] ?? 'x' . substr(md5($namespace), 0, 6);

        return $this->document->createElementNS($namespace, $prefix . ':' . $localName);
    }

    private function appendElement(\DOMElement $parent, string $namespace, string $localName, ?string $value = null): \DOMElement
    {
        $prefix = CalDavNamespace::PREFIXES[$namespace] ?? 'd';
        $element = $this->document->createElementNS($namespace, $prefix . ':' . $localName);

        if (null !== $value) {
            $element->appendChild($this->document->createTextNode($value));
        }

        $parent->appendChild($element);

        return $element;
    }
}
