<?php

namespace Cehlers88\AnalyticsCalendarBundle\CalDav;

/**
 * The parsed body of a PROPFIND request.
 */
final class PropfindRequest
{
    /**
     * @param string[] $properties Clark notation names the client asked for
     */
    public function __construct(
        public readonly array $properties = [],
        public readonly bool  $allProp = false,
        public readonly bool  $propName = false,
    ) {
    }
}
