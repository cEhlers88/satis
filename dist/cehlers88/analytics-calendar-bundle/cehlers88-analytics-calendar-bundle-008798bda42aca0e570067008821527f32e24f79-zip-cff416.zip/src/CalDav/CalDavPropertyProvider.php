<?php

namespace Cehlers88\AnalyticsCalendarBundle\CalDav;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Entity\Calendar;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarObjectManager;
use Cehlers88\AnalyticsCore\Entity\User;

/**
 * Answers the WebDAV/CalDAV properties of the resources of the tree.
 *
 * Only properties a client actually asks for are computed; everything unknown
 * is reported back as "404 Not Found" inside the multi-status document, which
 * is what the specification requires and what keeps iOS from retrying.
 */
class CalDavPropertyProvider
{
    public const MAX_RESOURCE_SIZE = 10485760;

    private const REPORTS = [
        ReportRequest::CALENDAR_QUERY,
        ReportRequest::CALENDAR_MULTIGET,
        ReportRequest::SYNC_COLLECTION,
        '{DAV:}principal-property-search',
        '{DAV:}expand-property',
    ];

    private const PRIVILEGES = ['read', 'write', 'write-content', 'write-properties', 'bind', 'unbind'];

    public function __construct(
        private readonly CalDavUrlBuilder      $urls,
        private readonly CalendarObjectManager $objects,
    ) {
    }

    /**
     * @param string[] $requested
     *
     * @return array{0: array<string, string|\Closure|null>, 1: string[]} found and missing properties
     */
    public function forPrincipal(User $user, array $requested, bool $allProp): array
    {
        $userId = (int)$user->getId();

        return $this->select([
            '{DAV:}resourcetype' => MultiStatusBuilder::elements(['{DAV:}collection', '{DAV:}principal']),
            '{DAV:}displayname' => $user->getUserIdentifier(),
            '{DAV:}principal-URL' => MultiStatusBuilder::href($this->urls->principal($userId)),
            '{DAV:}current-user-principal' => MultiStatusBuilder::href($this->urls->principal($userId)),
            '{DAV:}owner' => MultiStatusBuilder::href($this->urls->principal($userId)),
            '{DAV:}supported-report-set' => $this->supportedReportSet(),
            '{DAV:}current-user-privilege-set' => $this->privilegeSet(),
            '{urn:ietf:params:xml:ns:caldav}calendar-home-set' => MultiStatusBuilder::href($this->urls->calendarHome($userId)),
            '{urn:ietf:params:xml:ns:caldav}calendar-user-address-set' => MultiStatusBuilder::href('mailto:' . $user->getUserIdentifier()),
        ], $requested, $allProp);
    }

    /**
     * @param string[] $requested
     *
     * @return array{0: array<string, string|\Closure|null>, 1: string[]}
     */
    public function forHome(User $user, array $requested, bool $allProp): array
    {
        $userId = (int)$user->getId();

        return $this->select([
            '{DAV:}resourcetype' => MultiStatusBuilder::elements(['{DAV:}collection']),
            '{DAV:}displayname' => 'Kalender',
            '{DAV:}current-user-principal' => MultiStatusBuilder::href($this->urls->principal($userId)),
            '{DAV:}principal-URL' => MultiStatusBuilder::href($this->urls->principal($userId)),
            '{DAV:}owner' => MultiStatusBuilder::href($this->urls->principal($userId)),
            '{DAV:}supported-report-set' => $this->supportedReportSet(),
            '{DAV:}current-user-privilege-set' => $this->privilegeSet(),
            '{urn:ietf:params:xml:ns:caldav}calendar-home-set' => MultiStatusBuilder::href($this->urls->calendarHome($userId)),
        ], $requested, $allProp);
    }

    /**
     * Properties of the root collection. It exists so that a client which was
     * given only the server address can discover the principal from there.
     *
     * @param string[] $requested
     *
     * @return array{0: array<string, string|\Closure|null>, 1: string[]}
     */
    public function forRoot(User $user, array $requested, bool $allProp): array
    {
        $userId = (int)$user->getId();

        return $this->select([
            '{DAV:}resourcetype' => MultiStatusBuilder::elements(['{DAV:}collection']),
            '{DAV:}displayname' => 'Analytics Kalender',
            '{DAV:}current-user-principal' => MultiStatusBuilder::href($this->urls->principal($userId)),
            '{DAV:}principal-URL' => MultiStatusBuilder::href($this->urls->principal($userId)),
            '{DAV:}supported-report-set' => $this->supportedReportSet(),
            '{urn:ietf:params:xml:ns:caldav}calendar-home-set' => MultiStatusBuilder::href($this->urls->calendarHome($userId)),
        ], $requested, $allProp);
    }

    /**
     * @param string[] $requested
     *
     * @return array{0: array<string, string|\Closure|null>, 1: string[]}
     */
    public function forCalendar(Calendar $calendar, array $requested, bool $allProp): array
    {
        $userId = (int)$calendar->getOwner()?->getId();

        $available = [
            '{DAV:}resourcetype' => MultiStatusBuilder::elements([
                '{DAV:}collection',
                '{urn:ietf:params:xml:ns:caldav}calendar',
            ]),
            '{DAV:}displayname' => $calendar->getDisplayName(),
            '{DAV:}owner' => MultiStatusBuilder::href($this->urls->principal($userId)),
            '{DAV:}current-user-principal' => MultiStatusBuilder::href($this->urls->principal($userId)),
            '{DAV:}supported-report-set' => $this->supportedReportSet(),
            '{DAV:}current-user-privilege-set' => $this->privilegeSet(),
            '{DAV:}sync-token' => CalDavSyncToken::format($calendar->getSyncToken()),
            '{DAV:}getlastmodified' => $calendar->getUpdatedAt()->format(\DATE_RFC7231),
            '{http://calendarserver.org/ns/}getctag' => $calendar->getCtag(),
            '{http://apple.com/ns/ical/}calendar-color' => $calendar->getColor(),
            '{http://apple.com/ns/ical/}calendar-order' => (string)$calendar->getCalendarOrder(),
            '{urn:ietf:params:xml:ns:caldav}calendar-description' => $calendar->getDescription() ?? $calendar->getDisplayName(),
            '{urn:ietf:params:xml:ns:caldav}supported-calendar-component-set' => $this->supportedComponentSet(),
            '{urn:ietf:params:xml:ns:caldav}supported-calendar-data' => $this->supportedCalendarData(),
            '{urn:ietf:params:xml:ns:caldav}max-resource-size' => (string)self::MAX_RESOURCE_SIZE,
            '{urn:ietf:params:xml:ns:caldav}schedule-calendar-transp' => MultiStatusBuilder::elements([
                '{urn:ietf:params:xml:ns:caldav}opaque',
            ]),
        ];

        return $this->select($available, $requested, $allProp);
    }

    /**
     * @param string[] $requested
     *
     * @return array{0: array<string, string|\Closure|null>, 1: string[]}
     */
    public function forObject(Appointment $appointment, array $requested, bool $allProp): array
    {
        $icalData = null;
        $needsData = $allProp
            || in_array('{urn:ietf:params:xml:ns:caldav}calendar-data', $requested, true)
            || in_array('{DAV:}getcontentlength', $requested, true);

        if ($needsData) {
            $icalData = $this->objects->getIcalData($appointment);
        }

        $available = [
            '{DAV:}resourcetype' => null,
            '{DAV:}getetag' => $this->objects->getEtag($appointment),
            '{DAV:}getcontenttype' => 'text/calendar; charset=utf-8; component=vevent',
            '{DAV:}getlastmodified' => ($appointment->getUpdatedAt() ?? new \DateTime())->format(\DATE_RFC7231),
        ];

        if (null !== $icalData) {
            $available['{DAV:}getcontentlength'] = (string)strlen($icalData);
        }

        // calendar-data is expensive and must not be part of an allprop answer.
        if (in_array('{urn:ietf:params:xml:ns:caldav}calendar-data', $requested, true)) {
            $available['{urn:ietf:params:xml:ns:caldav}calendar-data'] = (string)$icalData;
        }

        return $this->select($available, $requested, $allProp);
    }

    /**
     * @param array<string, string|\Closure|null> $available
     * @param string[]                            $requested
     *
     * @return array{0: array<string, string|\Closure|null>, 1: string[]}
     */
    private function select(array $available, array $requested, bool $allProp): array
    {
        if ($allProp) {
            return [$available, []];
        }

        $found = [];
        $notFound = [];

        foreach ($requested as $name) {
            if (array_key_exists($name, $available)) {
                $found[$name] = $available[$name];
                continue;
            }

            $notFound[] = $name;
        }

        return [$found, $notFound];
    }

    private function supportedReportSet(): \Closure
    {
        return static function (\DOMElement $element, \DOMDocument $document): void {
            foreach (self::REPORTS as $report) {
                [$namespace, $localName] = CalDavNamespace::split($report);
                $prefix = CalDavNamespace::PREFIXES[$namespace] ?? 'd';

                $supported = $document->createElementNS(CalDavNamespace::DAV, 'd:supported-report');
                $wrapper = $document->createElementNS(CalDavNamespace::DAV, 'd:report');
                $wrapper->appendChild($document->createElementNS($namespace, $prefix . ':' . $localName));
                $supported->appendChild($wrapper);
                $element->appendChild($supported);
            }
        };
    }

    private function privilegeSet(): \Closure
    {
        return static function (\DOMElement $element, \DOMDocument $document): void {
            foreach (self::PRIVILEGES as $privilege) {
                $wrapper = $document->createElementNS(CalDavNamespace::DAV, 'd:privilege');
                $wrapper->appendChild($document->createElementNS(CalDavNamespace::DAV, 'd:' . $privilege));
                $element->appendChild($wrapper);
            }
        };
    }

    private function supportedComponentSet(): \Closure
    {
        return static function (\DOMElement $element, \DOMDocument $document): void {
            $component = $document->createElementNS(CalDavNamespace::CALDAV, 'c:comp');
            $component->setAttribute('name', 'VEVENT');
            $element->appendChild($component);
        };
    }

    private function supportedCalendarData(): \Closure
    {
        return static function (\DOMElement $element, \DOMDocument $document): void {
            $data = $document->createElementNS(CalDavNamespace::CALDAV, 'c:calendar-data');
            $data->setAttribute('content-type', 'text/calendar');
            $data->setAttribute('version', '2.0');
            $element->appendChild($data);
        };
    }
}
