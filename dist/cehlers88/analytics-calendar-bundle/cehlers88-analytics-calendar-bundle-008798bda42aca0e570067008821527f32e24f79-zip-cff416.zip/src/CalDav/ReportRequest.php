<?php

namespace Cehlers88\AnalyticsCalendarBundle\CalDav;

/**
 * The parsed body of a REPORT request.
 */
final class ReportRequest
{
    public const CALENDAR_QUERY = '{urn:ietf:params:xml:ns:caldav}calendar-query';
    public const CALENDAR_MULTIGET = '{urn:ietf:params:xml:ns:caldav}calendar-multiget';
    public const SYNC_COLLECTION = '{DAV:}sync-collection';

    /**
     * @param string[] $properties Clark notation names the client asked for
     * @param string[] $hrefs      resources named by a calendar-multiget
     */
    public function __construct(
        public readonly string             $type,
        public readonly array              $properties = [],
        public readonly array              $hrefs = [],
        public readonly ?\DateTimeInterface $rangeStart = null,
        public readonly ?\DateTimeInterface $rangeEnd = null,
        public readonly ?string            $syncToken = null,
        public readonly ?int               $limit = null,
    ) {
    }
}
