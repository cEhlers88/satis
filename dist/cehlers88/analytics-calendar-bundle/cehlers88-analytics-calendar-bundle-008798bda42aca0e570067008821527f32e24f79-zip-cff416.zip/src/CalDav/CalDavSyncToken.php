<?php

namespace Cehlers88\AnalyticsCalendarBundle\CalDav;

/**
 * Translation between the revision counter of a calendar and the sync-token
 * URI a client stores (RFC 6578).
 */
final class CalDavSyncToken
{
    public const PREFIX = 'urn:x-analytics:calendar:sync:';

    public static function format(int $revision): string
    {
        return self::PREFIX . $revision;
    }

    /**
     * Returns the revision encoded in a token, or NULL when the client sent a
     * token this server did not issue. The caller then has to answer with a
     * complete listing instead of a delta.
     */
    public static function parse(?string $token): ?int
    {
        if (null === $token || '' === trim($token)) {
            return null;
        }

        $token = trim($token);

        if (!str_starts_with($token, self::PREFIX)) {
            return null;
        }

        $revision = substr($token, strlen(self::PREFIX));

        return ctype_digit($revision) ? (int)$revision : null;
    }
}
