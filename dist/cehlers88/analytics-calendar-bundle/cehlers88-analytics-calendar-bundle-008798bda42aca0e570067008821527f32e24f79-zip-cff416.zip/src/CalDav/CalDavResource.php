<?php

namespace Cehlers88\AnalyticsCalendarBundle\CalDav;

/**
 * The address of a resource inside the CalDAV tree.
 *
 * The tree is intentionally flat:
 *
 *   /caldav/                                       collection root
 *   /caldav/principals/{userId}/                   principal of one account
 *   /caldav/calendars/{userId}/                    calendar-home-set
 *   /caldav/calendars/{userId}/{calendar}/         one calendar collection
 *   /caldav/calendars/{userId}/{calendar}/{o}.ics  one calendar object
 */
final class CalDavResource
{
    public const BASE_PATH = '/caldav';

    public const TYPE_ROOT = 'root';
    public const TYPE_PRINCIPAL = 'principal';
    public const TYPE_HOME = 'home';
    public const TYPE_CALENDAR = 'calendar';
    public const TYPE_OBJECT = 'object';
    public const TYPE_UNKNOWN = 'unknown';

    private function __construct(
        public readonly string  $type,
        public readonly ?int    $userId = null,
        public readonly ?string $calendarUri = null,
        public readonly ?string $objectUri = null,
    ) {
    }

    public static function fromPath(string $path): self
    {
        $segments = array_values(array_filter(explode('/', trim($path, '/')), static fn(string $segment): bool => '' !== $segment));
        $segments = array_map(static fn(string $segment): string => rawurldecode($segment), $segments);

        if ([] === $segments) {
            return new self(self::TYPE_ROOT);
        }

        $collection = array_shift($segments);
        $userId = isset($segments[0]) && ctype_digit($segments[0]) ? (int)array_shift($segments) : null;

        if ('principals' === $collection) {
            return null === $userId ? new self(self::TYPE_UNKNOWN) : new self(self::TYPE_PRINCIPAL, $userId);
        }

        if ('calendars' !== $collection || null === $userId) {
            return new self(self::TYPE_UNKNOWN);
        }

        return match (count($segments)) {
            0 => new self(self::TYPE_HOME, $userId),
            1 => new self(self::TYPE_CALENDAR, $userId, $segments[0]),
            2 => new self(self::TYPE_OBJECT, $userId, $segments[0], $segments[1]),
            default => new self(self::TYPE_UNKNOWN),
        };
    }

    public function isCollection(): bool
    {
        return self::TYPE_OBJECT !== $this->type;
    }
}
