<?php

namespace Cehlers88\AnalyticsCalendarBundle\CalDav;

/**
 * XML namespaces used by WebDAV and CalDAV.
 *
 * Property names are handed around in Clark notation ("{DAV:}displayname"),
 * which is what a namespace aware XML reader produces for an element and which
 * therefore keeps the code independent of the prefixes a client happens to use.
 */
final class CalDavNamespace
{
    public const DAV = 'DAV:';
    public const CALDAV = 'urn:ietf:params:xml:ns:caldav';

    /**
     * Non standard extensions of the CalendarServer project (getctag) that
     * Apple clients rely on.
     */
    public const CALENDARSERVER = 'http://calendarserver.org/ns/';

    /**
     * Apple specific display properties (calendar colour and ordering).
     */
    public const APPLE = 'http://apple.com/ns/ical/';

    /**
     * @var array<string, string> namespace => preferred prefix
     */
    public const PREFIXES = [
        self::DAV => 'd',
        self::CALDAV => 'c',
        self::CALENDARSERVER => 'cs',
        self::APPLE => 'ic',
    ];

    public static function name(string $namespace, string $localName): string
    {
        return '{' . $namespace . '}' . $localName;
    }

    /**
     * Splits a Clark notation name into namespace and local name.
     *
     * @return array{0: string, 1: string}
     */
    public static function split(string $clarkName): array
    {
        if (!str_starts_with($clarkName, '{')) {
            return ['', $clarkName];
        }

        $end = strpos($clarkName, '}');

        if (false === $end) {
            return ['', $clarkName];
        }

        return [substr($clarkName, 1, $end - 1), substr($clarkName, $end + 1)];
    }
}
