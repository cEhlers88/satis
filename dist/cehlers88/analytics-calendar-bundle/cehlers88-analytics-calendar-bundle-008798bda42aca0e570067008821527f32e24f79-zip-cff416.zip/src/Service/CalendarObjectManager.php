<?php

namespace Cehlers88\AnalyticsCalendarBundle\Service;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Entity\Calendar;
use Cehlers88\AnalyticsCalendarBundle\Entity\CalendarDeletedObject;
use Cehlers88\AnalyticsCalendarBundle\Ical\AppointmentHydrator;
use Cehlers88\AnalyticsCalendarBundle\Ical\AppointmentSerializer;
use Cehlers88\AnalyticsCalendarBundle\Ical\IcalParseException;
use Cehlers88\AnalyticsCalendarBundle\Ical\IcalParser;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Single point through which calendar objects are written.
 *
 * Every change has to pass through here because three things must stay in sync:
 * the appointment itself, its iCalendar representation together with the entity
 * tag derived from it, and the revision counter of the owning collection that
 * drives WebDAV synchronisation.
 */
class CalendarObjectManager
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly IcalParser             $parser = new IcalParser(),
        private readonly AppointmentHydrator    $hydrator = new AppointmentHydrator(),
        private readonly AppointmentSerializer  $serializer = new AppointmentSerializer(),
    ) {
    }

    /**
     * The iCalendar object of an appointment. Appointments pushed by a client
     * are returned byte for byte as they were received; everything else is
     * rendered from the stored fields.
     */
    public function getIcalData(Appointment $appointment): string
    {
        $stored = $appointment->getIcalData();

        return null === $stored || '' === trim($stored)
            ? $this->serializer->render($appointment)
            : $stored;
    }

    /**
     * Entity tag of an appointment, including the quotes required by RFC 9110.
     */
    public function getEtag(Appointment $appointment): string
    {
        return $appointment->getEtag() ?? self::computeEtag($this->getIcalData($appointment));
    }

    public static function computeEtag(string $icalData): string
    {
        return '"' . md5($icalData) . '"';
    }

    /**
     * Stores a calendar object that a CalDAV client has sent.
     *
     * @throws IcalParseException when the payload is not a usable VEVENT
     */
    public function storeFromClient(Calendar $calendar, string $uri, string $icalData, ?Appointment $existing = null): Appointment
    {
        $event = $this->hydrator->findMasterEvent($this->parser->parseCalendar($icalData));

        if (null === $event) {
            throw new IcalParseException('The calendar object does not contain a VEVENT component.');
        }

        $appointment = $existing ?? new Appointment();
        $this->hydrator->hydrate($event, $appointment);

        $appointment->setCalendar($calendar);
        $appointment->setUri($uri);
        $appointment->setIcalData($icalData);
        $appointment->setEtag(self::computeEtag($icalData));

        if (null === $appointment->getUid()) {
            $appointment->setUid($this->serializer->generateUid());
        }

        $this->stamp($appointment, $calendar);
        $this->entityManager->persist($appointment);
        $this->entityManager->flush();

        return $appointment;
    }

    /**
     * Stores an appointment that was created or changed inside the application.
     * Its iCalendar representation is rebuilt so that connected devices pick the
     * change up on their next synchronisation.
     */
    public function save(Appointment $appointment, ?Calendar $calendar = null): Appointment
    {
        $calendar ??= $appointment->getCalendar();

        if (null === $calendar) {
            throw new \InvalidArgumentException('The appointment is not assigned to a calendar.');
        }

        $appointment->setCalendar($calendar);
        $appointment->setUpdatedAt(new \DateTime());

        if (null === $appointment->getUid()) {
            $appointment->setUid($this->serializer->generateUid());
        }

        if (null === $appointment->getUri()) {
            $appointment->setUri($this->buildUri($appointment->getUid()));
        }

        if (null !== $appointment->getId()) {
            $appointment->setSequence($appointment->getSequence() + 1);
        }

        $icalData = $this->serializer->render($appointment);
        $appointment->setIcalData($icalData);
        $appointment->setEtag(self::computeEtag($icalData));

        $this->stamp($appointment, $calendar);
        $this->entityManager->persist($appointment);
        $this->entityManager->flush();

        return $appointment;
    }

    /**
     * Removes an appointment and leaves a tombstone behind, so that clients
     * synchronising with a sync-token learn about the deletion.
     */
    public function delete(Appointment $appointment): void
    {
        $calendar = $appointment->getCalendar();

        if (null !== $calendar) {
            $revision = $calendar->bumpSyncToken();
            $this->entityManager->persist(
                CalendarDeletedObject::create($calendar, (string)$appointment->getUri(), $revision),
            );
            $this->entityManager->persist($calendar);
        }

        $this->entityManager->remove($appointment);
        $this->entityManager->flush();
    }

    /**
     * Completes appointments that were created before this bundle spoke CalDAV:
     * they have neither a collection nor a UID, so no client could address
     * them. All of them share one new revision, which is enough because a
     * client either knows none of them yet or has to fetch all of them anyway.
     *
     * @param iterable<Appointment> $appointments
     *
     * @return int the number of appointments that were changed
     */
    public function backfill(Calendar $calendar, iterable $appointments): int
    {
        $revision = $calendar->bumpSyncToken();
        $changed = 0;

        foreach ($appointments as $appointment) {
            $appointment->setCalendar($calendar);

            if (null === $appointment->getUid()) {
                $appointment->setUid($this->serializer->generateUid());
            }

            if (null === $appointment->getUri()) {
                $appointment->setUri($this->buildUri((string)$appointment->getUid()));
            }

            if (null === $appointment->getIcalData()) {
                $icalData = $this->serializer->render($appointment);
                $appointment->setIcalData($icalData);
                $appointment->setEtag(self::computeEtag($icalData));
            }

            $appointment->setSyncRevision($revision);
            $this->entityManager->persist($appointment);
            ++$changed;
        }

        $this->entityManager->persist($calendar);
        $this->entityManager->flush();

        return $changed;
    }

    /**
     * Builds the file name a calendar object is reachable under.
     */
    public function buildUri(string $uid): string
    {
        $safe = preg_replace('/[^A-Za-z0-9._-]/', '-', $uid) ?? $uid;

        return substr($safe, 0, 250) . '.ics';
    }

    private function stamp(Appointment $appointment, Calendar $calendar): void
    {
        $appointment->setSyncRevision($calendar->bumpSyncToken());
        $this->entityManager->persist($calendar);
    }
}
