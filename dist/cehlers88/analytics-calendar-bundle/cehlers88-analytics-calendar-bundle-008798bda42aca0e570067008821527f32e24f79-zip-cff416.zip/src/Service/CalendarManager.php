<?php

namespace Cehlers88\AnalyticsCalendarBundle\Service;

use Cehlers88\AnalyticsCalendarBundle\Entity\Calendar;
use Cehlers88\AnalyticsCalendarBundle\Repository\CalendarRepository;
use Cehlers88\AnalyticsCore\Entity\User;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Creates and looks up the calendar collections of a user.
 */
class CalendarManager
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly CalendarRepository     $calendarRepository,
    ) {
    }

    /**
     * @return Calendar[]
     */
    public function getCalendars(User $user): array
    {
        $calendars = $this->calendarRepository->findByOwner($user);

        if ([] === $calendars) {
            $calendars = [$this->getDefaultCalendar($user)];
        }

        return $calendars;
    }

    /**
     * Returns the default calendar of the user and creates it on first access,
     * so that a freshly configured device immediately finds a collection.
     */
    public function getDefaultCalendar(User $user): Calendar
    {
        $calendar = $this->calendarRepository->findOneByOwnerAndUri($user, Calendar::DEFAULT_URI);

        if (null === $calendar) {
            $calendar = $this->createCalendar($user, Calendar::DEFAULT_URI, Calendar::DEFAULT_DISPLAY_NAME);
        }

        return $calendar;
    }

    public function findCalendar(User $user, string $uri): ?Calendar
    {
        return $this->calendarRepository->findOneByOwnerAndUri($user, $uri);
    }

    public function createCalendar(User $user, string $uri, string $displayName, ?string $color = null): Calendar
    {
        $calendar = Calendar::create($user, $this->normalizeUri($uri), $displayName);

        if (null !== $color) {
            $calendar->setColor($color);
        }

        $this->entityManager->persist($calendar);
        $this->entityManager->flush();

        return $calendar;
    }

    public function save(Calendar $calendar): void
    {
        $calendar->setUpdatedAt(new \DateTime());
        $this->entityManager->persist($calendar);
        $this->entityManager->flush();
    }

    public function remove(Calendar $calendar): void
    {
        $this->entityManager->remove($calendar);
        $this->entityManager->flush();
    }

    /**
     * Reduces a display name to something that is safe inside a URL path.
     */
    public function normalizeUri(string $uri): string
    {
        $uri = strtolower(trim($uri));
        $uri = str_replace(['ä', 'ö', 'ü', 'ß'], ['ae', 'oe', 'ue', 'ss'], $uri);
        $uri = preg_replace('/[^a-z0-9._-]+/', '-', $uri) ?? $uri;
        $uri = trim($uri, '-');

        return '' === $uri ? Calendar::DEFAULT_URI : substr($uri, 0, 64);
    }
}
