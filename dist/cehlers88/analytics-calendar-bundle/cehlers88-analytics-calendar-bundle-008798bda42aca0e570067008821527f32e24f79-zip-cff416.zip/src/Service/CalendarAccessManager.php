<?php

namespace Cehlers88\AnalyticsCalendarBundle\Service;

use Cehlers88\AnalyticsCalendarBundle\ENUM\EAccessTokenType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Calendar;
use Cehlers88\AnalyticsCalendarBundle\Entity\CalendarAccessToken;
use Cehlers88\AnalyticsCalendarBundle\Repository\CalendarAccessTokenRepository;
use Cehlers88\AnalyticsCore\Entity\User;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Issues and verifies the credentials external calendar clients use.
 *
 * The login password of the user is deliberately not accepted: a phone stores
 * the credential permanently and hands it out on every synchronisation, so it
 * gets its own secret that can be revoked without touching the account.
 */
class CalendarAccessManager
{
    /**
     * Alphabet without characters that are easy to confuse when the secret is
     * typed into the account settings of a phone.
     */
    private const ALPHABET = 'abcdefghjkmnpqrstuvwxyz23456789';

    private const CALDAV_GROUPS = 4;
    private const CALDAV_GROUP_SIZE = 5;
    private const FEED_TOKEN_BYTES = 24;

    /**
     * A token is only stamped as used again after this many seconds, to keep a
     * polling client from writing to the database on every request.
     */
    private const LAST_USED_THROTTLE = 300;

    public function __construct(
        private readonly EntityManagerInterface        $entityManager,
        private readonly CalendarAccessTokenRepository $tokenRepository,
    ) {
    }

    /**
     * Creates a new credential. The plaintext secret is returned once and
     * cannot be recovered afterwards.
     *
     * @return array{0: CalendarAccessToken, 1: string} the token and its secret
     */
    public function issueToken(
        User               $user,
        string             $label,
        EAccessTokenType   $type = EAccessTokenType::CALDAV,
        ?Calendar          $calendar = null,
        ?\DateTimeInterface $expiresAt = null,
    ): array {
        $secret = EAccessTokenType::FEED === $type
            ? bin2hex(random_bytes(self::FEED_TOKEN_BYTES))
            : $this->generateReadableSecret();

        $token = new CalendarAccessToken();
        $token
            ->setUser($user)
            ->setLabel($label)
            ->setType($type)
            ->setCalendar($calendar)
            ->setExpiresAt($expiresAt)
            ->setTokenHash(CalendarAccessToken::hashSecret($secret))
            ->setTokenPreview(substr($secret, 0, 6));

        $this->entityManager->persist($token);
        $this->entityManager->flush();

        return [$token, $secret];
    }

    /**
     * Verifies HTTP-Basic credentials of a CalDAV client.
     *
     * The user name has to match the account the token belongs to; that keeps a
     * token from silently working for the wrong account when several are
     * configured on the same device.
     */
    public function authenticateCaldav(string $username, string $secret): ?CalendarAccessToken
    {
        $token = $this->tokenRepository->findOneBySecret($secret, EAccessTokenType::CALDAV);

        if (null === $token || !$token->isUsable()) {
            return null;
        }

        $identifier = $token->getUser()?->getUserIdentifier() ?? '';

        if (0 !== strcasecmp($identifier, trim($username))) {
            return null;
        }

        $this->stampUsage($token);

        return $token;
    }

    /**
     * Resolves the secret contained in the URL of a subscription feed.
     */
    public function resolveFeedToken(string $secret): ?CalendarAccessToken
    {
        $token = $this->tokenRepository->findOneBySecret($secret, EAccessTokenType::FEED);

        if (null === $token || !$token->isUsable()) {
            return null;
        }

        $this->stampUsage($token);

        return $token;
    }

    public function revoke(CalendarAccessToken $token): void
    {
        $token->setRevokedAt(new \DateTime());
        $this->entityManager->persist($token);
        $this->entityManager->flush();
    }

    /**
     * @return CalendarAccessToken[]
     */
    public function listTokens(?User $user = null): array
    {
        return null === $user
            ? $this->tokenRepository->findAllOrdered()
            : $this->tokenRepository->findByUser($user);
    }

    /**
     * Groups of readable characters, e.g. "hkm4p-qr7st-3wxyz-abc29".
     */
    private function generateReadableSecret(): string
    {
        $alphabetLength = strlen(self::ALPHABET) - 1;
        $groups = [];

        for ($group = 0; $group < self::CALDAV_GROUPS; ++$group) {
            $characters = '';

            for ($index = 0; $index < self::CALDAV_GROUP_SIZE; ++$index) {
                $characters .= self::ALPHABET[random_int(0, $alphabetLength)];
            }

            $groups[] = $characters;
        }

        return implode('-', $groups);
    }

    private function stampUsage(CalendarAccessToken $token): void
    {
        $lastUsed = $token->getLastUsedAt();

        if (null !== $lastUsed && (time() - $lastUsed->getTimestamp()) < self::LAST_USED_THROTTLE) {
            return;
        }

        $token->setLastUsedAt(new \DateTime());
        $this->entityManager->persist($token);
        $this->entityManager->flush();
    }
}
