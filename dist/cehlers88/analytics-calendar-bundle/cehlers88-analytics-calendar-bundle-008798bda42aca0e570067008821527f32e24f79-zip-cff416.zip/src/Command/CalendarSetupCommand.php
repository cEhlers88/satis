<?php

namespace Cehlers88\AnalyticsCalendarBundle\Command;

use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavResource;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarManager;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarObjectManager;
use Cehlers88\AnalyticsCore\Repository\UserRepository;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

/**
 * Prepares an account for calendar synchronisation.
 *
 * Running it is only necessary once and only for installations that already
 * contain appointments: those were stored before the bundle knew about
 * calendar collections and iCalendar identifiers, and without them no client
 * can address them.
 */
#[AsCommand(
    name: 'analytics:calendar:setup',
    description: 'Bereitet einen Benutzer für die Kalender-Synchronisation vor und ordnet vorhandene Termine einem Kalender zu.',
)]
class CalendarSetupCommand extends Command
{
    public function __construct(
        private readonly CalendarManager       $calendarManager,
        private readonly CalendarObjectManager $objectManager,
        private readonly AppointmentRepository $appointmentRepository,
        private readonly UserRepository        $userRepository,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addArgument('email', InputArgument::REQUIRED, 'E-Mail-Adresse des Benutzers')
            ->addOption('calendar', 'c', InputOption::VALUE_REQUIRED, 'URI des Zielkalenders (Standard: der Standardkalender)')
            ->addOption('dry-run', null, InputOption::VALUE_NONE, 'Nur anzeigen, was geändert würde');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $email = (string)$input->getArgument('email');
        $user = $this->userRepository->findOneBy(['email' => $email]);

        if (null === $user) {
            $io->error(sprintf('Es gibt keinen Benutzer mit der E-Mail-Adresse "%s".', $email));

            return Command::FAILURE;
        }

        $calendarUri = $input->getOption('calendar');
        $calendar = null === $calendarUri
            ? $this->calendarManager->getDefaultCalendar($user)
            : $this->calendarManager->findCalendar($user, (string)$calendarUri);

        if (null === $calendar) {
            $io->error(sprintf('Der Benutzer besitzt keinen Kalender mit der URI "%s".', $calendarUri));

            return Command::FAILURE;
        }

        $orphans = $this->appointmentRepository->findWithoutCalendar();

        if ($input->getOption('dry-run')) {
            $io->info(sprintf('%d Termine würden dem Kalender "%s" zugeordnet.', count($orphans), $calendar->getDisplayName()));

            return Command::SUCCESS;
        }

        $changed = $this->objectManager->backfill($calendar, $orphans);

        $io->success(sprintf(
            'Kalender "%s" ist eingerichtet, %d vorhandene Termine wurden übernommen.',
            $calendar->getDisplayName(),
            $changed,
        ));

        $io->definitionList(
            ['CalDAV-Adresse' => CalDavResource::BASE_PATH . '/'],
            ['Kalender-URI' => $calendar->getUri()],
            ['Benutzername' => $user->getUserIdentifier()],
        );
        $io->text('Ein Passwort für ein Gerät erzeugt "analytics:calendar:token:create ' . $email . '".');

        return Command::SUCCESS;
    }
}
