<?php

namespace Cehlers88\AnalyticsCalendarBundle\Command;

use Cehlers88\AnalyticsCalendarBundle\Repository\CalendarAccessTokenRepository;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarAccessManager;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'analytics:calendar:token:revoke',
    description: 'Zieht einen Kalender-Zugang zurück, z.B. wenn ein Gerät verloren gegangen ist.',
)]
class CalendarTokenRevokeCommand extends Command
{
    public function __construct(
        private readonly CalendarAccessManager         $accessManager,
        private readonly CalendarAccessTokenRepository $tokenRepository,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addArgument('id', InputArgument::REQUIRED, 'ID des Zugangs (siehe analytics:calendar:token:list)');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $token = $this->tokenRepository->find((int)$input->getArgument('id'));

        if (null === $token) {
            $io->error('Es gibt keinen Zugang mit dieser ID.');

            return Command::FAILURE;
        }

        if ($token->isRevoked()) {
            $io->info(sprintf('Der Zugang "%s" wurde bereits am %s zurückgezogen.', $token->getLabel(), $token->getRevokedAt()?->format('d.m.Y H:i')));

            return Command::SUCCESS;
        }

        $this->accessManager->revoke($token);
        $io->success(sprintf('Der Zugang "%s" wurde zurückgezogen und funktioniert ab sofort nicht mehr.', $token->getLabel()));

        return Command::SUCCESS;
    }
}
