<?php

namespace Cehlers88\AnalyticsCalendarBundle\Command;

use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavResource;
use Cehlers88\AnalyticsCalendarBundle\ENUM\EAccessTokenType;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarAccessManager;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarManager;
use Cehlers88\AnalyticsCore\Repository\UserRepository;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

/**
 * Creates the credential a phone or a calendar client authenticates with.
 */
#[AsCommand(
    name: 'analytics:calendar:token:create',
    description: 'Erstellt einen Zugangsschlüssel für ein Kalender-Gerät (CalDAV oder Abo-Feed).',
)]
class CalendarTokenCreateCommand extends Command
{
    public function __construct(
        private readonly CalendarAccessManager $accessManager,
        private readonly CalendarManager       $calendarManager,
        private readonly UserRepository        $userRepository,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addArgument('email', InputArgument::REQUIRED, 'E-Mail-Adresse des Benutzers')
            ->addOption('label', 'l', InputOption::VALUE_REQUIRED, 'Bezeichnung des Geräts', 'iPhone')
            ->addOption('type', 't', InputOption::VALUE_REQUIRED, sprintf('Art des Zugangs (%s)', implode('|', EAccessTokenType::getValues())), EAccessTokenType::CALDAV->value)
            ->addOption('calendar', 'c', InputOption::VALUE_REQUIRED, 'Beschränkung auf einen einzelnen Kalender (dessen URI)')
            ->addOption('expires', null, InputOption::VALUE_REQUIRED, 'Ablaufdatum, z.B. "2027-01-01" oder "+1 year"')
            ->addOption('base-url', 'b', InputOption::VALUE_REQUIRED, 'Öffentliche Adresse der Installation, z.B. https://analytics.example.com');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $email = (string)$input->getArgument('email');
        $user = $this->userRepository->findOneBy(['email' => $email]);

        if (null === $user) {
            $io->error(sprintf('Es gibt keinen Benutzer mit der E-Mail-Adresse "%s".', $email));

            return Command::FAILURE;
        }

        $type = EAccessTokenType::tryFrom((string)$input->getOption('type'));

        if (null === $type) {
            $io->error(sprintf('Unbekannte Zugangsart. Erlaubt sind: %s.', implode(', ', EAccessTokenType::getValues())));

            return Command::FAILURE;
        }

        $calendar = null;
        $calendarUri = $input->getOption('calendar');

        if (null !== $calendarUri) {
            $calendar = $this->calendarManager->findCalendar($user, (string)$calendarUri);

            if (null === $calendar) {
                $io->error(sprintf('Der Benutzer besitzt keinen Kalender mit der URI "%s".', $calendarUri));

                return Command::FAILURE;
            }
        }

        $expiresAt = null;
        $expires = $input->getOption('expires');

        if (null !== $expires) {
            try {
                $expiresAt = new \DateTime((string)$expires);
            } catch (\Exception) {
                $io->error(sprintf('Das Ablaufdatum "%s" konnte nicht gelesen werden.', $expires));

                return Command::FAILURE;
            }
        }

        // Makes sure the device finds at least one collection right away.
        $this->calendarManager->getDefaultCalendar($user);

        [$token, $secret] = $this->accessManager->issueToken(
            $user,
            (string)$input->getOption('label'),
            $type,
            $calendar,
            $expiresAt,
        );

        $baseUrl = rtrim((string)($input->getOption('base-url') ?? ''), '/');
        $baseUrl = '' === $baseUrl ? 'https://DEINE-DOMAIN' : $baseUrl;

        $io->success(sprintf('Zugang "%s" (#%d) wurde angelegt.', $token->getLabel(), (int)$token->getId()));
        $io->warning('Das Passwort wird nur dieses eine Mal angezeigt und kann später nicht erneut ausgelesen werden.');

        if (EAccessTokenType::CALDAV === $type) {
            $io->definitionList(
                ['Serveradresse' => $baseUrl . CalDavResource::BASE_PATH . '/'],
                ['Benutzername' => $user->getUserIdentifier()],
                ['Passwort' => $secret],
            );
            $io->text('iPhone: Einstellungen → Apps → Kalender → Accounts → Account hinzufügen → Andere → CalDAV-Account hinzufügen.');

            return Command::SUCCESS;
        }

        $feedUrl = $baseUrl . '/calendar/feed/' . $secret . '.ics';
        $io->definitionList(
            ['Abo-Adresse' => $feedUrl],
            ['webcal' => preg_replace('#^https?://#', 'webcal://', $feedUrl)],
        );
        $io->text('iPhone: Einstellungen → Apps → Kalender → Accounts → Account hinzufügen → Andere → Kalenderabo hinzufügen.');

        return Command::SUCCESS;
    }
}
