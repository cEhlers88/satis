<?php

namespace Cehlers88\AnalyticsCalendarBundle\Command;

use Cehlers88\AnalyticsCalendarBundle\Entity\CalendarAccessToken;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarAccessManager;
use Cehlers88\AnalyticsCore\Repository\UserRepository;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'analytics:calendar:token:list',
    description: 'Listet die vergebenen Kalender-Zugänge auf.',
)]
class CalendarTokenListCommand extends Command
{
    public function __construct(
        private readonly CalendarAccessManager $accessManager,
        private readonly UserRepository        $userRepository,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addArgument('email', InputArgument::OPTIONAL, 'Nur die Zugänge dieses Benutzers anzeigen');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $email = $input->getArgument('email');
        $user = null;

        if (null !== $email) {
            $user = $this->userRepository->findOneBy(['email' => (string)$email]);

            if (null === $user) {
                $io->error(sprintf('Es gibt keinen Benutzer mit der E-Mail-Adresse "%s".', $email));

                return Command::FAILURE;
            }
        }

        $tokens = $this->accessManager->listTokens($user);

        if ([] === $tokens) {
            $io->info('Es wurden noch keine Kalender-Zugänge vergeben.');

            return Command::SUCCESS;
        }

        $io->table(
            ['ID', 'Benutzer', 'Bezeichnung', 'Art', 'Kalender', 'Beginnt mit', 'Zuletzt genutzt', 'Status'],
            array_map(static function (CalendarAccessToken $token): array {
                return [
                    (string)$token->getId(),
                    (string)$token->getUser()?->getUserIdentifier(),
                    $token->getLabel(),
                    $token->getType()->value,
                    $token->getCalendar()?->getUri() ?? 'alle',
                    $token->getTokenPreview() . '…',
                    $token->getLastUsedAt()?->format('d.m.Y H:i') ?? 'nie',
                    match (true) {
                        $token->isRevoked() => 'widerrufen',
                        $token->isExpired() => 'abgelaufen',
                        default => 'aktiv',
                    },
                ];
            }, $tokens),
        );

        return Command::SUCCESS;
    }
}
