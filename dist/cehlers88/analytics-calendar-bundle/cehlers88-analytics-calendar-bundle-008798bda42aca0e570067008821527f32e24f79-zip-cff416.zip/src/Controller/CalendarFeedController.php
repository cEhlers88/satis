<?php

namespace Cehlers88\AnalyticsCalendarBundle\Controller;

use Cehlers88\AnalyticsCalendarBundle\Entity\Calendar;
use Cehlers88\AnalyticsCalendarBundle\Ical\AppointmentSerializer;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarAccessManager;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarManager;
use Cehlers88\AnalyticsCore\Entity\User;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * Read-only iCalendar subscription feed.
 *
 * It is the small alternative to the CalDAV endpoint: a device subscribes to
 * the URL and shows the appointments, but cannot change them. Everything a
 * subscriber needs sits in the URL, so it also works on devices where adding a
 * full account is not wanted.
 */
class CalendarFeedController
{
    /**
     * How often a subscriber should look for changes. iOS treats this as a hint
     * and additionally refreshes on its own schedule.
     */
    private const REFRESH_INTERVAL = 3600;

    private const TOKEN_PATTERN = '[a-f0-9]{32,64}';

    public function __construct(
        private readonly CalendarAccessManager $accessManager,
        private readonly CalendarManager       $calendarManager,
        private readonly AppointmentRepository $appointmentRepository,
        private readonly AppointmentSerializer $serializer,
    ) {
    }

    #[Route(
        path: '/calendar/feed/{token}.ics',
        name: 'analytics_calendar_feed',
        requirements: ['token' => self::TOKEN_PATTERN],
        methods: ['GET', 'HEAD'],
    )]
    #[Route(
        path: '/calendar/feed/{token}/{calendar}.ics',
        name: 'analytics_calendar_feed_single',
        requirements: ['token' => self::TOKEN_PATTERN, 'calendar' => '[A-Za-z0-9._-]+'],
        methods: ['GET', 'HEAD'],
    )]
    public function feed(Request $request, string $token, ?string $calendar = null): Response
    {
        $accessToken = $this->accessManager->resolveFeedToken($token);
        $user = $accessToken?->getUser();

        if (null === $accessToken || !$user instanceof User) {
            // An unknown, revoked or expired secret is indistinguishable from a
            // feed that does not exist.
            return new Response('', Response::HTTP_NOT_FOUND);
        }

        $calendars = $this->resolveCalendars($user, $accessToken->getCalendar(), $calendar);

        if ([] === $calendars) {
            return new Response('', Response::HTTP_NOT_FOUND);
        }

        $appointments = [];
        $revision = 0;

        foreach ($calendars as $entry) {
            $revision += $entry->getSyncToken();

            foreach ($this->appointmentRepository->findByCalendar($entry) as $appointment) {
                $appointments[] = $appointment;
            }
        }

        $name = 1 === count($calendars) ? $calendars[0]->getDisplayName() : 'Analytics Kalender';
        $etag = sprintf('"%s"', md5($accessToken->getId() . ':' . $revision . ':' . count($appointments)));

        $response = new Response('', Response::HTTP_OK, [
            'Content-Type' => 'text/calendar; charset=utf-8',
            'Content-Disposition' => 'inline; filename="calendar.ics"',
            'Cache-Control' => 'no-cache, private',
        ]);
        $response->setEtag($etag);

        // Subscribed calendars are polled regularly; answering an unchanged
        // feed with "304 Not Modified" keeps those polls cheap.
        if ($response->isNotModified($request)) {
            return $response;
        }

        $response->setContent($this->serializer->renderCollection($appointments, $name, self::REFRESH_INTERVAL));

        return $response;
    }

    /**
     * @return Calendar[]
     */
    private function resolveCalendars(User $user, ?Calendar $restriction, ?string $requestedUri): array
    {
        if (null !== $restriction) {
            return null === $requestedUri || $restriction->getUri() === $requestedUri ? [$restriction] : [];
        }

        if (null === $requestedUri) {
            return $this->calendarManager->getCalendars($user);
        }

        $calendar = $this->calendarManager->findCalendar($user, $requestedUri);

        return null === $calendar ? [] : [$calendar];
    }
}
