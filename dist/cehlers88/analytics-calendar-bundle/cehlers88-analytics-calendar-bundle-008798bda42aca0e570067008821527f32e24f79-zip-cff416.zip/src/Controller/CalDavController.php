<?php

namespace Cehlers88\AnalyticsCalendarBundle\Controller;

use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavNamespace;
use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavPropertyProvider;
use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavRequestParser;
use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavResource;
use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavSyncToken;
use Cehlers88\AnalyticsCalendarBundle\CalDav\CalDavUrlBuilder;
use Cehlers88\AnalyticsCalendarBundle\CalDav\MultiStatusBuilder;
use Cehlers88\AnalyticsCalendarBundle\CalDav\ReportRequest;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Entity\Calendar;
use Cehlers88\AnalyticsCalendarBundle\Entity\CalendarAccessToken;
use Cehlers88\AnalyticsCalendarBundle\Ical\AppointmentSerializer;
use Cehlers88\AnalyticsCalendarBundle\Ical\IcalParseException;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCalendarBundle\Repository\CalendarDeletedObjectRepository;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarAccessManager;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarManager;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarObjectManager;
use Cehlers88\AnalyticsCore\Entity\User;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * CalDAV endpoint (RFC 4791) with WebDAV synchronisation (RFC 6578).
 *
 * It exposes the appointments of one account as calendar collections so that
 * the built-in calendar app of iOS, iPadOS and macOS – and any other CalDAV
 * client – can read *and* write them.
 *
 * Authentication deliberately does not run through the Symfony firewall: a
 * calendar client speaks HTTP Basic and expects a "401" challenge on every
 * unauthenticated request, and it authenticates with a revocable device secret
 * instead of the account password. Both is handled here, which keeps the
 * endpoint working without any change to the security configuration of the
 * host application.
 */
class CalDavController
{
    private const REALM = 'Analytics Kalender';

    private const DAV_CAPABILITIES = '1, 2, 3, access-control, calendar-access, extended-mkcol';

    private const ALLOWED_METHODS = 'OPTIONS, GET, HEAD, PROPFIND, PROPPATCH, REPORT, PUT, DELETE, MKCALENDAR, MKCOL';

    private const CONTENT_TYPE_XML = 'application/xml; charset=utf-8';
    private const CONTENT_TYPE_ICAL = 'text/calendar; charset=utf-8';

    public function __construct(
        private readonly CalendarAccessManager           $accessManager,
        private readonly CalendarManager                 $calendarManager,
        private readonly CalendarObjectManager           $objectManager,
        private readonly AppointmentRepository           $appointmentRepository,
        private readonly CalendarDeletedObjectRepository $deletedObjectRepository,
        private readonly CalDavPropertyProvider          $propertyProvider,
        private readonly CalDavRequestParser             $requestParser,
        private readonly CalDavUrlBuilder                $urls,
        private readonly AppointmentSerializer           $serializer,
    ) {
    }

    /**
     * Service discovery: clients that were given only the host name look for
     * the calendar service under its well-known URL (RFC 6764).
     */
    #[Route(
        path: '/.well-known/caldav',
        name: 'analytics_calendar_caldav_wellknown',
        methods: ['GET', 'HEAD', 'OPTIONS', 'PROPFIND', 'REPORT', 'PUT', 'DELETE', 'PROPPATCH', 'MKCALENDAR', 'MKCOL'],
    )]
    public function wellKnown(): Response
    {
        return new RedirectResponse($this->urls->root(), Response::HTTP_MOVED_PERMANENTLY);
    }

    #[Route(
        path: CalDavResource::BASE_PATH,
        name: 'analytics_calendar_caldav_root',
        defaults: ['path' => ''],
        methods: ['GET', 'HEAD', 'OPTIONS', 'PROPFIND', 'PROPPATCH', 'REPORT', 'PUT', 'DELETE', 'MKCALENDAR', 'MKCOL'],
    )]
    #[Route(
        path: CalDavResource::BASE_PATH . '/{path}',
        name: 'analytics_calendar_caldav',
        requirements: ['path' => '.*'],
        defaults: ['path' => ''],
        methods: ['GET', 'HEAD', 'OPTIONS', 'PROPFIND', 'PROPPATCH', 'REPORT', 'PUT', 'DELETE', 'MKCALENDAR', 'MKCOL'],
    )]
    public function handle(Request $request): Response
    {
        $method = strtoupper($request->getMethod());

        if ('OPTIONS' === $method) {
            return $this->decorate(new Response('', Response::HTTP_NO_CONTENT));
        }

        $token = $this->authenticate($request);

        if (null === $token) {
            return $this->challenge();
        }

        $user = $token->getUser();

        if (!$user instanceof User) {
            return $this->challenge();
        }

        // The still percent-encoded path info is used instead of the routing
        // parameter, which the router has already decoded: hrefs a client sends
        // inside a REPORT body arrive encoded too, and both have to be decoded
        // exactly once to address the same resource.
        $resource = CalDavResource::fromPath($this->stripBasePath($request->getPathInfo()));

        if (CalDavResource::TYPE_UNKNOWN === $resource->type) {
            return $this->decorate(new Response('', Response::HTTP_NOT_FOUND));
        }

        // Every account only ever sees its own branch of the tree.
        if (null !== $resource->userId && $resource->userId !== (int)$user->getId()) {
            return $this->decorate(new Response('', Response::HTTP_FORBIDDEN));
        }

        try {
            return $this->decorate(match ($method) {
                'PROPFIND' => $this->propfind($request, $resource, $user, $token),
                'PROPPATCH' => $this->proppatch($request, $resource, $user, $token),
                'REPORT' => $this->report($request, $resource, $user, $token),
                'GET', 'HEAD' => $this->get($resource, $user, $token),
                'PUT' => $this->put($request, $resource, $user, $token),
                'DELETE' => $this->delete($resource, $user, $token),
                'MKCALENDAR', 'MKCOL' => $this->makeCalendar($request, $resource, $user, $token),
                default => new Response('', Response::HTTP_METHOD_NOT_ALLOWED),
            });
        } catch (IcalParseException $exception) {
            return $this->decorate(new Response($exception->getMessage(), Response::HTTP_BAD_REQUEST));
        }
    }

    // ---------------------------------------------------------------- methods

    private function propfind(Request $request, CalDavResource $resource, User $user, CalendarAccessToken $token): Response
    {
        $propfind = $this->requestParser->parsePropfind($request->getContent());
        $depth = $this->resolveDepth($request);
        $builder = new MultiStatusBuilder();

        switch ($resource->type) {
            case CalDavResource::TYPE_ROOT:
                [$found, $missing] = $this->propertyProvider->forRoot($user, $propfind->properties, $propfind->allProp);
                $builder->addResponse($this->urls->root(), $found, $missing);

                if ($depth > 0) {
                    [$found, $missing] = $this->propertyProvider->forHome($user, $propfind->properties, $propfind->allProp);
                    $builder->addResponse($this->urls->calendarHome((int)$user->getId()), $found, $missing);
                }
                break;

            case CalDavResource::TYPE_PRINCIPAL:
                [$found, $missing] = $this->propertyProvider->forPrincipal($user, $propfind->properties, $propfind->allProp);
                $builder->addResponse($this->urls->principal((int)$user->getId()), $found, $missing);
                break;

            case CalDavResource::TYPE_HOME:
                [$found, $missing] = $this->propertyProvider->forHome($user, $propfind->properties, $propfind->allProp);
                $builder->addResponse($this->urls->calendarHome((int)$user->getId()), $found, $missing);

                if ($depth > 0) {
                    foreach ($this->accessibleCalendars($user, $token) as $calendar) {
                        [$found, $missing] = $this->propertyProvider->forCalendar($calendar, $propfind->properties, $propfind->allProp);
                        $builder->addResponse($this->calendarHref($calendar), $found, $missing);
                    }
                }
                break;

            case CalDavResource::TYPE_CALENDAR:
                $calendar = $this->resolveCalendar($resource, $user, $token);

                if (null === $calendar) {
                    return new Response('', Response::HTTP_NOT_FOUND);
                }

                [$found, $missing] = $this->propertyProvider->forCalendar($calendar, $propfind->properties, $propfind->allProp);
                $builder->addResponse($this->calendarHref($calendar), $found, $missing);

                if ($depth > 0) {
                    foreach ($this->appointmentRepository->findByCalendar($calendar) as $appointment) {
                        [$found, $missing] = $this->propertyProvider->forObject($appointment, $propfind->properties, $propfind->allProp);
                        $builder->addResponse($this->objectHref($calendar, $appointment), $found, $missing);
                    }
                }
                break;

            case CalDavResource::TYPE_OBJECT:
                $calendar = $this->resolveCalendar($resource, $user, $token);
                $appointment = null === $calendar
                    ? null
                    : $this->appointmentRepository->findOneByCalendarAndUri($calendar, (string)$resource->objectUri);

                if (null === $calendar || null === $appointment) {
                    return new Response('', Response::HTTP_NOT_FOUND);
                }

                [$found, $missing] = $this->propertyProvider->forObject($appointment, $propfind->properties, $propfind->allProp);
                $builder->addResponse($this->objectHref($calendar, $appointment), $found, $missing);
                break;
        }

        return $this->multiStatus($builder);
    }

    /**
     * Applies the property changes a client makes when a calendar is renamed or
     * recoloured on the device.
     */
    private function proppatch(Request $request, CalDavResource $resource, User $user, CalendarAccessToken $token): Response
    {
        $calendar = $this->resolveCalendar($resource, $user, $token);

        if (CalDavResource::TYPE_CALENDAR !== $resource->type || null === $calendar) {
            return new Response('', Response::HTTP_FORBIDDEN);
        }

        $document = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);

        try {
            $loaded = $document->loadXML($request->getContent(), LIBXML_NONET);
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }

        if (!$loaded) {
            return new Response('', Response::HTTP_BAD_REQUEST);
        }

        $accepted = [];
        $rejected = [];

        foreach ($document->getElementsByTagNameNS(CalDavNamespace::DAV, 'prop') as $prop) {
            foreach ($prop->childNodes as $property) {
                if (!$property instanceof \DOMElement) {
                    continue;
                }

                $name = CalDavNamespace::name((string)$property->namespaceURI, (string)$property->localName);
                $value = trim($property->textContent);

                switch ($name) {
                    case '{DAV:}displayname':
                        $calendar->setDisplayName('' === $value ? $calendar->getDisplayName() : $value);
                        $accepted[] = $name;
                        break;
                    case '{urn:ietf:params:xml:ns:caldav}calendar-description':
                        $calendar->setDescription('' === $value ? null : $value);
                        $accepted[] = $name;
                        break;
                    case '{http://apple.com/ns/ical/}calendar-color':
                        $calendar->setColor('' === $value ? null : substr($value, 0, 9));
                        $accepted[] = $name;
                        break;
                    case '{http://apple.com/ns/ical/}calendar-order':
                        $calendar->setCalendarOrder((int)$value);
                        $accepted[] = $name;
                        break;
                    default:
                        $rejected[] = $name;
                }
            }
        }

        if ([] !== $accepted) {
            $calendar->bumpSyncToken();
            $this->calendarManager->save($calendar);
        }

        $builder = new MultiStatusBuilder();
        $builder->addResponse(
            $this->calendarHref($calendar),
            array_fill_keys($accepted, null),
            $rejected,
        );

        return $this->multiStatus($builder);
    }

    private function report(Request $request, CalDavResource $resource, User $user, CalendarAccessToken $token): Response
    {
        try {
            $report = $this->requestParser->parseReport($request->getContent());
        } catch (\InvalidArgumentException) {
            return new Response('', Response::HTTP_BAD_REQUEST);
        }

        $calendar = $this->resolveCalendar($resource, $user, $token);

        if (null === $calendar) {
            return new Response('', Response::HTTP_NOT_FOUND);
        }

        return match ($report->type) {
            ReportRequest::CALENDAR_QUERY => $this->calendarQuery($report, $calendar),
            ReportRequest::CALENDAR_MULTIGET => $this->calendarMultiget($report, $calendar),
            ReportRequest::SYNC_COLLECTION => $this->syncCollection($report, $calendar),
            default => new Response('', Response::HTTP_BAD_REQUEST),
        };
    }

    private function calendarQuery(ReportRequest $report, Calendar $calendar): Response
    {
        $appointments = $this->appointmentRepository->findInRange($calendar, $report->rangeStart, $report->rangeEnd);

        if (null !== $report->limit) {
            $appointments = array_slice($appointments, 0, $report->limit);
        }

        $builder = new MultiStatusBuilder();

        foreach ($appointments as $appointment) {
            [$found, $missing] = $this->propertyProvider->forObject($appointment, $report->properties, false);
            $builder->addResponse($this->objectHref($calendar, $appointment), $found, $missing);
        }

        return $this->multiStatus($builder);
    }

    private function calendarMultiget(ReportRequest $report, Calendar $calendar): Response
    {
        $builder = new MultiStatusBuilder();

        foreach ($report->hrefs as $href) {
            $requested = CalDavResource::fromPath($this->stripBasePath($href));
            $appointment = CalDavResource::TYPE_OBJECT === $requested->type
                ? $this->appointmentRepository->findOneByCalendarAndUri($calendar, (string)$requested->objectUri)
                : null;

            if (null === $appointment) {
                $builder->addStatusResponse($href, 'HTTP/1.1 404 Not Found');
                continue;
            }

            [$found, $missing] = $this->propertyProvider->forObject($appointment, $report->properties, false);
            $builder->addResponse($this->objectHref($calendar, $appointment), $found, $missing);
        }

        return $this->multiStatus($builder);
    }

    /**
     * Delta synchronisation (RFC 6578): reports everything that changed since
     * the revision the client remembers. Without a usable token the complete
     * collection is returned, which is also what an initial synchronisation
     * asks for.
     */
    private function syncCollection(ReportRequest $report, Calendar $calendar): Response
    {
        $since = CalDavSyncToken::parse($report->syncToken);
        $builder = new MultiStatusBuilder();

        $appointments = null === $since
            ? $this->appointmentRepository->findByCalendar($calendar)
            : $this->appointmentRepository->findChangedSince($calendar, $since);

        foreach ($appointments as $appointment) {
            [$found, $missing] = $this->propertyProvider->forObject($appointment, $report->properties, false);
            $builder->addResponse($this->objectHref($calendar, $appointment), $found, $missing);
        }

        if (null !== $since) {
            foreach ($this->deletedObjectRepository->findDeletedSince($calendar, $since) as $deleted) {
                $builder->addStatusResponse(
                    $this->urls->object((int)$calendar->getOwner()?->getId(), $calendar->getUri(), $deleted->getUri()),
                    'HTTP/1.1 404 Not Found',
                );
            }
        }

        $builder->setSyncToken(CalDavSyncToken::format($calendar->getSyncToken()));

        return $this->multiStatus($builder);
    }

    private function get(CalDavResource $resource, User $user, CalendarAccessToken $token): Response
    {
        $calendar = $this->resolveCalendar($resource, $user, $token);

        if (null === $calendar) {
            return new Response('', Response::HTTP_NOT_FOUND);
        }

        if (CalDavResource::TYPE_CALENDAR === $resource->type) {
            // Not required by CalDAV, but it makes the collection readable with
            // a plain browser or curl, which helps when debugging a device.
            $body = $this->serializer->renderCollection(
                $this->appointmentRepository->findByCalendar($calendar),
                $calendar->getDisplayName(),
            );

            return new Response($body, Response::HTTP_OK, ['Content-Type' => self::CONTENT_TYPE_ICAL]);
        }

        if (CalDavResource::TYPE_OBJECT !== $resource->type) {
            return new Response('', Response::HTTP_NOT_FOUND);
        }

        $appointment = $this->appointmentRepository->findOneByCalendarAndUri($calendar, (string)$resource->objectUri);

        if (null === $appointment) {
            return new Response('', Response::HTTP_NOT_FOUND);
        }

        return new Response($this->objectManager->getIcalData($appointment), Response::HTTP_OK, [
            'Content-Type' => self::CONTENT_TYPE_ICAL,
            'ETag' => $this->objectManager->getEtag($appointment),
        ]);
    }

    private function put(Request $request, CalDavResource $resource, User $user, CalendarAccessToken $token): Response
    {
        if (CalDavResource::TYPE_OBJECT !== $resource->type) {
            return new Response('', Response::HTTP_METHOD_NOT_ALLOWED);
        }

        $calendar = $this->resolveCalendar($resource, $user, $token);

        if (null === $calendar) {
            return new Response('', Response::HTTP_NOT_FOUND);
        }

        $body = $request->getContent();

        if (strlen($body) > CalDavPropertyProvider::MAX_RESOURCE_SIZE) {
            return new Response('', Response::HTTP_REQUEST_ENTITY_TOO_LARGE);
        }

        $uri = (string)$resource->objectUri;
        $existing = $this->appointmentRepository->findOneByCalendarAndUri($calendar, $uri);
        $currentEtag = null === $existing ? null : $this->objectManager->getEtag($existing);

        if (!$this->preconditionsPass($request, $currentEtag)) {
            return new Response('', Response::HTTP_PRECONDITION_FAILED);
        }

        $appointment = $this->objectManager->storeFromClient($calendar, $uri, $body, $existing);

        return new Response('', null === $existing ? Response::HTTP_CREATED : Response::HTTP_NO_CONTENT, [
            'ETag' => $this->objectManager->getEtag($appointment),
        ]);
    }

    private function delete(CalDavResource $resource, User $user, CalendarAccessToken $token): Response
    {
        $calendar = $this->resolveCalendar($resource, $user, $token);

        if (null === $calendar) {
            return new Response('', Response::HTTP_NOT_FOUND);
        }

        if (CalDavResource::TYPE_CALENDAR === $resource->type) {
            $this->calendarManager->remove($calendar);

            return new Response('', Response::HTTP_NO_CONTENT);
        }

        if (CalDavResource::TYPE_OBJECT !== $resource->type) {
            return new Response('', Response::HTTP_METHOD_NOT_ALLOWED);
        }

        $appointment = $this->appointmentRepository->findOneByCalendarAndUri($calendar, (string)$resource->objectUri);

        if (null === $appointment) {
            return new Response('', Response::HTTP_NOT_FOUND);
        }

        $this->objectManager->delete($appointment);

        return new Response('', Response::HTTP_NO_CONTENT);
    }

    private function makeCalendar(Request $request, CalDavResource $resource, User $user, CalendarAccessToken $token): Response
    {
        if (CalDavResource::TYPE_CALENDAR !== $resource->type) {
            return new Response('', Response::HTTP_METHOD_NOT_ALLOWED);
        }

        if (null !== $token->getCalendar()) {
            // A token bound to a single calendar must not create further ones.
            return new Response('', Response::HTTP_FORBIDDEN);
        }

        $uri = (string)$resource->calendarUri;

        if (null !== $this->calendarManager->findCalendar($user, $uri)) {
            return new Response('', Response::HTTP_METHOD_NOT_ALLOWED);
        }

        $calendar = $this->calendarManager->createCalendar($user, $uri, $uri);

        // A MKCALENDAR body carries the same DAV:set/DAV:prop structure as a
        // PROPPATCH, so display name and colour of the new collection are taken
        // over by the same code. Its result is not reported back: the creation
        // itself succeeded either way.
        $this->proppatch($request, $resource, $user, $token);

        return new Response('', Response::HTTP_CREATED, ['Location' => $this->calendarHref($calendar)]);
    }

    // ---------------------------------------------------------------- helpers

    private function authenticate(Request $request): ?CalendarAccessToken
    {
        $username = $request->getUser();
        $password = $request->getPassword();

        if (null === $username || null === $password) {
            return null;
        }

        return $this->accessManager->authenticateCaldav($username, $password);
    }

    private function challenge(): Response
    {
        return $this->decorate(new Response('', Response::HTTP_UNAUTHORIZED, [
            'WWW-Authenticate' => sprintf('Basic realm="%s", charset="UTF-8"', self::REALM),
        ]));
    }

    /**
     * @return Calendar[]
     */
    private function accessibleCalendars(User $user, CalendarAccessToken $token): array
    {
        $restriction = $token->getCalendar();

        return null === $restriction ? $this->calendarManager->getCalendars($user) : [$restriction];
    }

    private function resolveCalendar(CalDavResource $resource, User $user, CalendarAccessToken $token): ?Calendar
    {
        if (null === $resource->calendarUri) {
            return null;
        }

        $restriction = $token->getCalendar();

        if (null !== $restriction) {
            return $restriction->getUri() === $resource->calendarUri ? $restriction : null;
        }

        if (Calendar::DEFAULT_URI === $resource->calendarUri) {
            return $this->calendarManager->getDefaultCalendar($user);
        }

        return $this->calendarManager->findCalendar($user, $resource->calendarUri);
    }

    private function calendarHref(Calendar $calendar): string
    {
        return $this->urls->calendar((int)$calendar->getOwner()?->getId(), $calendar->getUri());
    }

    private function objectHref(Calendar $calendar, Appointment $appointment): string
    {
        return $this->urls->object(
            (int)$calendar->getOwner()?->getId(),
            $calendar->getUri(),
            (string)$appointment->getUri(),
        );
    }

    /**
     * Evaluates the conditional headers of a PUT: "If-None-Match: *" guards a
     * creation against overwriting, "If-Match" guards an update against a
     * change somebody else made in the meantime.
     */
    private function preconditionsPass(Request $request, ?string $currentEtag): bool
    {
        $ifNoneMatch = $request->headers->get('If-None-Match');

        if (null !== $ifNoneMatch && '*' === trim($ifNoneMatch) && null !== $currentEtag) {
            return false;
        }

        $ifMatch = $request->headers->get('If-Match');

        if (null === $ifMatch) {
            return true;
        }

        $ifMatch = trim($ifMatch);

        if ('*' === $ifMatch) {
            return null !== $currentEtag;
        }

        if (null === $currentEtag) {
            return false;
        }

        foreach (explode(',', $ifMatch) as $candidate) {
            $candidate = trim($candidate);
            $candidate = preg_replace('/^W\//', '', $candidate) ?? $candidate;

            if ($candidate === $currentEtag) {
                return true;
            }
        }

        return false;
    }

    private function resolveDepth(Request $request): int
    {
        $depth = strtolower(trim((string)$request->headers->get('Depth', '0')));

        return match ($depth) {
            '0' => 0,
            '1' => 1,
            'infinity' => 1,
            default => 0,
        };
    }

    /**
     * Turns an absolute href a client sent back into a path relative to the
     * CalDAV root.
     */
    private function stripBasePath(string $href): string
    {
        $path = parse_url(trim($href), PHP_URL_PATH);
        $path = is_string($path) ? $path : $href;
        $base = CalDavResource::BASE_PATH;

        return str_starts_with($path, $base) ? substr($path, strlen($base)) : $path;
    }

    private function multiStatus(MultiStatusBuilder $builder): Response
    {
        return new Response($builder->toXml(), 207, ['Content-Type' => self::CONTENT_TYPE_XML]);
    }

    private function decorate(Response $response): Response
    {
        $response->headers->set('DAV', self::DAV_CAPABILITIES);
        $response->headers->set('Allow', self::ALLOWED_METHODS);
        // Calendar data must never be served from an intermediate cache.
        $response->headers->set('Cache-Control', 'no-store, private');

        return $response;
    }
}
