<?php

namespace Cehlers88\AnalyticsCalendarBundle\Repository;

use Cehlers88\AnalyticsCalendarBundle\Entity\Calendar;
use Cehlers88\AnalyticsCore\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Calendar>
 */
class CalendarRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Calendar::class);
    }

    /**
     * @return Calendar[]
     */
    public function findByOwner(User $owner): array
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.owner = :owner')
            ->setParameter('owner', $owner)
            ->orderBy('c.calendarOrder', 'ASC')
            ->addOrderBy('c.id', 'ASC')
            ->getQuery()
            ->getResult();
    }

    public function findOneByOwnerAndUri(User $owner, string $uri): ?Calendar
    {
        return $this->findOneBy(['owner' => $owner, 'uri' => $uri]);
    }
}
