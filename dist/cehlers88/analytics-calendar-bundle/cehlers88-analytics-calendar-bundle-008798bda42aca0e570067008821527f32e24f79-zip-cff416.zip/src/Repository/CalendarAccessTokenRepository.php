<?php

namespace Cehlers88\AnalyticsCalendarBundle\Repository;

use Cehlers88\AnalyticsCalendarBundle\ENUM\EAccessTokenType;
use Cehlers88\AnalyticsCalendarBundle\Entity\CalendarAccessToken;
use Cehlers88\AnalyticsCore\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<CalendarAccessToken>
 */
class CalendarAccessTokenRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CalendarAccessToken::class);
    }

    public function findOneBySecret(string $secret, EAccessTokenType $type): ?CalendarAccessToken
    {
        return $this->findOneBy([
            'tokenHash' => CalendarAccessToken::hashSecret($secret),
            'type' => $type,
        ]);
    }

    /**
     * @return CalendarAccessToken[]
     */
    public function findByUser(User $user): array
    {
        return $this->createQueryBuilder('t')
            ->andWhere('t.user = :user')
            ->setParameter('user', $user)
            ->orderBy('t.createdAt', 'DESC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @return CalendarAccessToken[]
     */
    public function findAllOrdered(): array
    {
        return $this->createQueryBuilder('t')
            ->orderBy('t.createdAt', 'DESC')
            ->getQuery()
            ->getResult();
    }
}
