<?php

namespace Cehlers88\AnalyticsCalendarBundle\Repository;

use Cehlers88\AnalyticsCalendarBundle\Entity\Calendar;
use Cehlers88\AnalyticsCalendarBundle\Entity\CalendarDeletedObject;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<CalendarDeletedObject>
 */
class CalendarDeletedObjectRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CalendarDeletedObject::class);
    }

    /**
     * @return CalendarDeletedObject[]
     */
    public function findDeletedSince(Calendar $calendar, int $syncRevision): array
    {
        return $this->createQueryBuilder('d')
            ->andWhere('d.calendar = :calendar')
            ->andWhere('d.syncRevision > :revision')
            ->setParameter('calendar', $calendar)
            ->setParameter('revision', $syncRevision)
            ->orderBy('d.syncRevision', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * Drops tombstones that are older than the given revision. Clients that did
     * not sync since then have to fall back to a full synchronisation anyway.
     */
    public function purgeOlderThan(Calendar $calendar, int $syncRevision): int
    {
        return (int)$this->createQueryBuilder('d')
            ->delete()
            ->andWhere('d.calendar = :calendar')
            ->andWhere('d.syncRevision <= :revision')
            ->setParameter('calendar', $calendar)
            ->setParameter('revision', $syncRevision)
            ->getQuery()
            ->execute();
    }
}
