<?php

namespace Cehlers88\AnalyticsCalendarBundle\Repository;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Entity\Calendar;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Appointment>
 */
class AppointmentRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Appointment::class);
    }

    /**
     * @return Appointment[]
     */
    public function findByCalendar(Calendar $calendar): array
    {
        return $this->createQueryBuilder('a')
            ->andWhere('a.calendar = :calendar')
            ->setParameter('calendar', $calendar)
            ->orderBy('a.startDate', 'ASC')
            ->getQuery()
            ->getResult();
    }

    public function findOneByCalendarAndUri(Calendar $calendar, string $uri): ?Appointment
    {
        return $this->findOneBy(['calendar' => $calendar, 'uri' => $uri]);
    }

    public function findOneByCalendarAndUid(Calendar $calendar, string $uid): ?Appointment
    {
        return $this->findOneBy(['calendar' => $calendar, 'uid' => $uid]);
    }

    /**
     * Appointments that changed after the given calendar revision.
     *
     * @return Appointment[]
     */
    public function findChangedSince(Calendar $calendar, int $syncRevision): array
    {
        return $this->createQueryBuilder('a')
            ->andWhere('a.calendar = :calendar')
            ->andWhere('a.syncRevision > :revision')
            ->setParameter('calendar', $calendar)
            ->setParameter('revision', $syncRevision)
            ->orderBy('a.syncRevision', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * Appointments overlapping the given period.
     *
     * Recurring appointments are always included, because whether one of their
     * occurrences falls into the period can only be decided after the
     * recurrence rule has been expanded.
     *
     * @return Appointment[]
     */
    public function findInRange(Calendar $calendar, ?\DateTimeInterface $start, ?\DateTimeInterface $end): array
    {
        $queryBuilder = $this->createQueryBuilder('a')
            ->andWhere('a.calendar = :calendar')
            ->setParameter('calendar', $calendar)
            ->orderBy('a.startDate', 'ASC');

        // The parentheses are written out: Doctrine passes string conditions
        // through unchanged, so without them the OR would escape the AND that
        // limits the result to this calendar.
        if (null !== $end) {
            $queryBuilder
                ->andWhere('(a.startDate <= :end OR a.rrule IS NOT NULL OR a.repeatInterval IS NOT NULL)')
                ->setParameter('end', $end);
        }

        if (null !== $start) {
            $queryBuilder
                ->andWhere('(COALESCE(a.endDate, a.startDate) >= :start OR a.rrule IS NOT NULL OR a.repeatInterval IS NOT NULL)')
                ->setParameter('start', $start);
        }

        return $queryBuilder->getQuery()->getResult();
    }

    /**
     * Appointments that have not been assigned to a calendar collection yet.
     *
     * @return Appointment[]
     */
    public function findWithoutCalendar(): array
    {
        return $this->createQueryBuilder('a')
            ->andWhere('a.calendar IS NULL')
            ->orderBy('a.id', 'ASC')
            ->getQuery()
            ->getResult();
    }
}
