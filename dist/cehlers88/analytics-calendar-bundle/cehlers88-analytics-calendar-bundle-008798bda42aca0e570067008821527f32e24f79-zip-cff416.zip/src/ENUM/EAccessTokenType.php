<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 */

namespace Cehlers88\AnalyticsCalendarBundle\ENUM;

/**
 * Types of access tokens that can be issued for external calendar clients.
 */
enum EAccessTokenType: string
{
    /**
     * App specific password used as HTTP-Basic password by a CalDAV client
     * (iPhone, iPad, macOS, Thunderbird, ...). Allows read *and* write access.
     */
    case CALDAV = 'caldav';

    /**
     * Secret contained in the URL of a read-only iCalendar subscription feed
     * (webcal://). Allows read access only.
     */
    case FEED = 'feed';

    /**
     * @return string[]
     */
    public static function getValues(): array
    {
        return array_map(static fn(self $case): string => $case->value, self::cases());
    }
}
