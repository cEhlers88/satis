<?php

namespace Cehlers88\AnalyticsCalendarBundle\Ical;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;

/**
 * Renders appointments as iCalendar objects.
 *
 * Timed appointments are always written in UTC. That is the one representation
 * every client reads without needing an accompanying VTIMEZONE definition, and
 * the stored value is unambiguous because Doctrine hands back the appointment
 * in the timezone PHP is configured with.
 */
class AppointmentSerializer
{
    public const PRODUCT_ID = '-//C-Ehlers//AnalyticsCalendarBundle//DE';

    public function __construct(private readonly IcalWriter $writer = new IcalWriter())
    {
    }

    /**
     * A complete VCALENDAR containing a single appointment – the representation
     * a CalDAV client fetches for one calendar object resource.
     */
    public function render(Appointment $appointment): string
    {
        return $this->writer->write($this->buildCalendar([$appointment]));
    }

    /**
     * A complete VCALENDAR containing every given appointment – used by the
     * read-only subscription feed and by GET on a whole collection.
     *
     * @param iterable<Appointment> $appointments
     */
    public function renderCollection(iterable $appointments, ?string $name = null, ?int $refreshIntervalSeconds = null): string
    {
        $calendar = $this->buildCalendar($appointments);

        if (null !== $name) {
            $calendar->add('X-WR-CALNAME', IcalProperty::escapeText($name));
        }

        if (null !== $refreshIntervalSeconds) {
            $duration = IcalDuration::fromSeconds($refreshIntervalSeconds);
            // REFRESH-INTERVAL is the standardised property (RFC 7986); the
            // X- variant is what older Apple clients look at.
            $calendar->add('REFRESH-INTERVAL', $duration, ['VALUE' => 'DURATION']);
            $calendar->add('X-PUBLISHED-TTL', $duration);
        }

        return $this->writer->write($calendar);
    }

    /**
     * The VEVENT of a single appointment, without the surrounding VCALENDAR.
     */
    public function buildEvent(Appointment $appointment): IcalComponent
    {
        $event = new IcalComponent('VEVENT');
        $event->add('UID', $appointment->getUid() ?? $this->generateUid());
        $event->add('DTSTAMP', $this->formatUtc($appointment->getUpdatedAt() ?? $appointment->getCreatedAt() ?? new \DateTime()));

        $start = $appointment->getStartDate();
        if (null !== $start) {
            $this->addDateProperty($event, 'DTSTART', $start, $appointment->isAllDay());
        }

        $end = $appointment->getEndDate();
        if (null !== $end) {
            $this->addDateProperty($event, 'DTEND', $end, $appointment->isAllDay());
        }

        $event->add('SUMMARY', IcalProperty::escapeText((string)$appointment->getTitle()));

        if (null !== $appointment->getDescription() && '' !== $appointment->getDescription()) {
            $event->add('DESCRIPTION', IcalProperty::escapeText($appointment->getDescription()));
        }

        if (null !== $appointment->getLocation() && '' !== $appointment->getLocation()) {
            $event->add('LOCATION', IcalProperty::escapeText($appointment->getLocation()));
        }

        $rrule = $appointment->getRrule() ?? $this->buildRruleFromRepeatInterval($appointment->getRepeatInterval());
        if (null !== $rrule) {
            $event->add('RRULE', $rrule);
        }

        $event->add('SEQUENCE', (string)$appointment->getSequence());

        if (null !== $appointment->getCreatedAt()) {
            $event->add('CREATED', $this->formatUtc($appointment->getCreatedAt()));
        }

        if (null !== $appointment->getUpdatedAt()) {
            $event->add('LAST-MODIFIED', $this->formatUtc($appointment->getUpdatedAt()));
        }

        $reminder = $appointment->getReminderTimer();
        if (null !== $reminder && $reminder > 0) {
            $alarm = new IcalComponent('VALARM');
            $alarm->add('ACTION', 'DISPLAY');
            $alarm->add('DESCRIPTION', IcalProperty::escapeText((string)$appointment->getTitle()));
            $alarm->add('TRIGGER', IcalDuration::fromSeconds(-$reminder));
            $event->addComponent($alarm);
        }

        return $event;
    }

    public function generateUid(): string
    {
        return sprintf(
            '%s-%s@analytics-calendar',
            bin2hex(random_bytes(8)),
            bin2hex(random_bytes(4)),
        );
    }

    /**
     * @param iterable<Appointment> $appointments
     */
    private function buildCalendar(iterable $appointments): IcalComponent
    {
        $calendar = new IcalComponent('VCALENDAR');
        $calendar->add('VERSION', '2.0');
        $calendar->add('PRODID', self::PRODUCT_ID);
        $calendar->add('CALSCALE', 'GREGORIAN');

        foreach ($appointments as $appointment) {
            $calendar->addComponent($this->buildEvent($appointment));
        }

        return $calendar;
    }

    private function addDateProperty(IcalComponent $event, string $name, \DateTimeInterface $value, bool $allDay): void
    {
        if ($allDay) {
            $event->add($name, $value->format('Ymd'), ['VALUE' => 'DATE']);

            return;
        }

        $event->add($name, $this->formatUtc($value));
    }

    private function formatUtc(\DateTimeInterface $value): string
    {
        return (\DateTimeImmutable::createFromInterface($value))
            ->setTimezone(new \DateTimeZone('UTC'))
            ->format('Ymd\THis\Z');
    }

    /**
     * Maps the simplified `repeatInterval` (a number of days) onto a recurrence
     * rule, so appointments created before this bundle knew about RRULEs still
     * repeat on the phone.
     */
    private function buildRruleFromRepeatInterval(?int $repeatInterval): ?string
    {
        if (null === $repeatInterval || $repeatInterval < 1) {
            return null;
        }

        if (0 === $repeatInterval % 7) {
            $weeks = intdiv($repeatInterval, 7);

            return 1 === $weeks ? 'FREQ=WEEKLY' : 'FREQ=WEEKLY;INTERVAL=' . $weeks;
        }

        return 1 === $repeatInterval ? 'FREQ=DAILY' : 'FREQ=DAILY;INTERVAL=' . $repeatInterval;
    }
}
