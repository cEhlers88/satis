<?php

namespace Cehlers88\AnalyticsCalendarBundle\Ical;

/**
 * Conversion between the iCalendar DURATION value type (RFC 5545, section
 * 3.3.6) and a plain number of seconds.
 */
final class IcalDuration
{
    private const PATTERN = '/^(?<sign>[+-])?P(?:(?<weeks>\d+)W|(?:(?<days>\d+)D)?(?:T(?:(?<hours>\d+)H)?(?:(?<minutes>\d+)M)?(?:(?<seconds>\d+)S)?)?)$/';

    /**
     * Returns the duration in seconds, negative for durations pointing into the
     * past, or NULL when the value cannot be read.
     */
    public static function toSeconds(string $value): ?int
    {
        $value = trim($value);

        if (!preg_match(self::PATTERN, $value, $matches)) {
            return null;
        }

        // "P" and "PT" match the grammar but carry no component at all.
        $components = array_filter(
            [$matches['weeks'] ?? '', $matches['days'] ?? '', $matches['hours'] ?? '', $matches['minutes'] ?? '', $matches['seconds'] ?? ''],
            static fn(string $component): bool => '' !== $component,
        );

        if ([] === $components) {
            return null;
        }

        $seconds = 0;
        $seconds += (int)($matches['weeks'] ?? 0) * 604800;
        $seconds += (int)($matches['days'] ?? 0) * 86400;
        $seconds += (int)($matches['hours'] ?? 0) * 3600;
        $seconds += (int)($matches['minutes'] ?? 0) * 60;
        $seconds += (int)($matches['seconds'] ?? 0);

        return '-' === ($matches['sign'] ?? '') ? -$seconds : $seconds;
    }

    /**
     * Renders a number of seconds as a DURATION value, using the largest unit
     * that still describes the value exactly.
     */
    public static function fromSeconds(int $seconds): string
    {
        $sign = $seconds < 0 ? '-' : '';
        $seconds = abs($seconds);

        if (0 === $seconds) {
            return 'PT0S';
        }

        if (0 === $seconds % 604800) {
            return $sign . 'P' . intdiv($seconds, 604800) . 'W';
        }

        if (0 === $seconds % 86400) {
            return $sign . 'P' . intdiv($seconds, 86400) . 'D';
        }

        if (0 === $seconds % 3600) {
            return $sign . 'PT' . intdiv($seconds, 3600) . 'H';
        }

        if (0 === $seconds % 60) {
            return $sign . 'PT' . intdiv($seconds, 60) . 'M';
        }

        return $sign . 'PT' . $seconds . 'S';
    }
}
