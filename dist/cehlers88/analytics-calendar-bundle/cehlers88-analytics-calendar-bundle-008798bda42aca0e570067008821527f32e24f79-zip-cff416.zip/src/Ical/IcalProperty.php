<?php

namespace Cehlers88\AnalyticsCalendarBundle\Ical;

/**
 * A single content line of an iCalendar stream (RFC 5545, section 3.1).
 *
 * The value is kept exactly as it appears in the stream; escaping of TEXT
 * values is applied by {@see getTextValue()} and by {@see IcalWriter} so that
 * value types which must not be unescaped (DATE-TIME, RRULE, ...) stay intact.
 */
class IcalProperty
{
    /**
     * @param array<string, string[]> $parameters
     */
    public function __construct(
        public readonly string $name,
        public readonly string $value,
        public readonly array  $parameters = [],
    ) {
    }

    public function getParameter(string $name, ?string $default = null): ?string
    {
        $values = $this->parameters[strtoupper($name)] ?? [];

        return $values[0] ?? $default;
    }

    /**
     * @return string[]
     */
    public function getParameterValues(string $name): array
    {
        return $this->parameters[strtoupper($name)] ?? [];
    }

    public function hasParameterValue(string $name, string $value): bool
    {
        foreach ($this->getParameterValues($name) as $candidate) {
            if (0 === strcasecmp($candidate, $value)) {
                return true;
            }
        }

        return false;
    }

    /**
     * The value with the TEXT escaping of RFC 5545 section 3.3.11 removed.
     */
    public function getTextValue(): string
    {
        return self::unescapeText($this->value);
    }

    public static function unescapeText(string $value): string
    {
        $result = '';
        $length = strlen($value);

        for ($i = 0; $i < $length; ++$i) {
            $character = $value[$i];

            if ('\\' !== $character || $i + 1 >= $length) {
                $result .= $character;
                continue;
            }

            $next = $value[++$i];
            $result .= match ($next) {
                'n', 'N' => "\n",
                '\\', ',', ';' => $next,
                default => '\\' . $next,
            };
        }

        return $result;
    }

    public static function escapeText(string $value): string
    {
        return str_replace(
            ["\\", "\r\n", "\n", "\r", ';', ','],
            ['\\\\', '\\n', '\\n', '\\n', '\\;', '\\,'],
            $value,
        );
    }
}
