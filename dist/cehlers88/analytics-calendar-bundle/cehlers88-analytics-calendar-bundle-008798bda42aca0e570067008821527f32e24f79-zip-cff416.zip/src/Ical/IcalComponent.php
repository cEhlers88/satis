<?php

namespace Cehlers88\AnalyticsCalendarBundle\Ical;

/**
 * A component of an iCalendar stream, e.g. VCALENDAR, VEVENT or VALARM.
 */
class IcalComponent
{
    /**
     * @var IcalProperty[]
     */
    private array $properties = [];

    /**
     * @var IcalComponent[]
     */
    private array $components = [];

    public function __construct(public readonly string $name)
    {
    }

    /**
     * @param array<string, string[]>|array<string, string> $parameters
     */
    public function add(string $name, string $value, array $parameters = []): static
    {
        $normalized = [];
        foreach ($parameters as $parameterName => $parameterValue) {
            $normalized[strtoupper($parameterName)] = is_array($parameterValue) ? array_values($parameterValue) : [$parameterValue];
        }

        $this->properties[] = new IcalProperty(strtoupper($name), $value, $normalized);

        return $this;
    }

    public function addProperty(IcalProperty $property): static
    {
        $this->properties[] = $property;

        return $this;
    }

    public function addComponent(IcalComponent $component): static
    {
        $this->components[] = $component;

        return $this;
    }

    public function getProperty(string $name): ?IcalProperty
    {
        $name = strtoupper($name);

        foreach ($this->properties as $property) {
            if ($property->name === $name) {
                return $property;
            }
        }

        return null;
    }

    /**
     * @return IcalProperty[]
     */
    public function getProperties(?string $name = null): array
    {
        if (null === $name) {
            return $this->properties;
        }

        $name = strtoupper($name);

        return array_values(array_filter(
            $this->properties,
            static fn(IcalProperty $property): bool => $property->name === $name,
        ));
    }

    /**
     * Raw value of the first property with the given name.
     */
    public function getValue(string $name, ?string $default = null): ?string
    {
        return $this->getProperty($name)?->value ?? $default;
    }

    /**
     * Unescaped value of the first property with the given name.
     */
    public function getTextValue(string $name, ?string $default = null): ?string
    {
        $property = $this->getProperty($name);

        return null === $property ? $default : $property->getTextValue();
    }

    public function getComponent(string $name): ?IcalComponent
    {
        $name = strtoupper($name);

        foreach ($this->components as $component) {
            if ($component->name === $name) {
                return $component;
            }
        }

        return null;
    }

    /**
     * @return IcalComponent[]
     */
    public function getComponents(?string $name = null): array
    {
        if (null === $name) {
            return $this->components;
        }

        $name = strtoupper($name);

        return array_values(array_filter(
            $this->components,
            static fn(IcalComponent $component): bool => $component->name === $name,
        ));
    }

    public function removeProperties(string $name): static
    {
        $name = strtoupper($name);

        $this->properties = array_values(array_filter(
            $this->properties,
            static fn(IcalProperty $property): bool => $property->name !== $name,
        ));

        return $this;
    }

    public function __toString(): string
    {
        return (new IcalWriter())->write($this);
    }
}
