<?php

namespace Cehlers88\AnalyticsCalendarBundle\Ical;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;

/**
 * Maps a VEVENT delivered by a calendar client onto an {@see Appointment}.
 *
 * Only the properties the application itself works with are mapped; everything
 * else survives because the calendar object is additionally stored verbatim in
 * {@see Appointment::getIcalData()}.
 */
class AppointmentHydrator
{
    /**
     * Returns the VEVENT that describes the appointment itself. A calendar
     * object may additionally contain overrides for single occurrences of a
     * recurring appointment; those carry a RECURRENCE-ID and are skipped here.
     */
    public function findMasterEvent(IcalComponent $calendar): ?IcalComponent
    {
        $events = $calendar->getComponents('VEVENT');

        foreach ($events as $event) {
            if (null === $event->getProperty('RECURRENCE-ID')) {
                return $event;
            }
        }

        return $events[0] ?? null;
    }

    /**
     * @throws IcalParseException when the event lacks a usable start date
     */
    public function hydrate(IcalComponent $event, Appointment $appointment): Appointment
    {
        $start = $event->getProperty('DTSTART');

        if (null === $start) {
            throw new IcalParseException('The VEVENT does not contain a DTSTART property.');
        }

        [$startDate, $allDay, $timezone] = $this->parseDate($start);

        $appointment->setStartDate($startDate);
        $appointment->setAllDay($allDay);
        $appointment->setTimezone($timezone);
        $appointment->setEndDate($this->resolveEnd($event, $startDate, $allDay));

        $uid = $event->getTextValue('UID');
        if (null !== $uid && '' !== $uid) {
            $appointment->setUid($uid);
        }

        $summary = $event->getTextValue('SUMMARY');
        $appointment->setTitle('' === (string)$summary ? '(ohne Titel)' : (string)$summary);

        $appointment->setDescription($this->emptyToNull($event->getTextValue('DESCRIPTION')));
        $appointment->setLocation($this->emptyToNull($event->getTextValue('LOCATION')));

        $rrule = $this->emptyToNull($event->getValue('RRULE'));
        $appointment->setRrule($rrule);
        $appointment->setRepeatInterval($this->extractRepeatInterval($rrule));

        $appointment->setSequence((int)($event->getValue('SEQUENCE') ?? 0));
        $appointment->setReminderTimer($this->extractReminderTimer($event, $startDate));

        $created = $event->getProperty('CREATED');
        if (null !== $created && null === $appointment->getId()) {
            $appointment->setCreatedAt($this->parseDate($created)[0]);
        }

        $appointment->setUpdatedAt(new \DateTime());

        return $appointment;
    }

    /**
     * @return array{0: \DateTime, 1: bool, 2: string|null} date, all-day flag and Olson timezone
     */
    private function parseDate(IcalProperty $property): array
    {
        $value = trim($property->value);
        $serverTimezone = new \DateTimeZone(date_default_timezone_get());
        $isDate = $property->hasParameterValue('VALUE', 'DATE') || 1 === preg_match('/^\d{8}$/', $value);

        if ($isDate) {
            $date = \DateTime::createFromFormat('Ymd|', $value, $serverTimezone);

            if (false === $date) {
                throw new IcalParseException(sprintf('Unreadable DATE value "%s".', $value));
            }

            return [$date, true, null];
        }

        $tzid = $property->getParameter('TZID');
        $timezone = $this->resolveTimezone($tzid) ?? $serverTimezone;

        if (str_ends_with($value, 'Z')) {
            $timezone = new \DateTimeZone('UTC');
            $tzid = null;
        }

        $date = \DateTime::createFromFormat('Ymd\THis', rtrim($value, 'Z'), $timezone);

        if (false === $date) {
            throw new IcalParseException(sprintf('Unreadable DATE-TIME value "%s".', $value));
        }

        // Doctrine persists the wall clock time of the PHP default timezone, so
        // everything is normalised to it before it is handed to the entity.
        $date->setTimezone($serverTimezone);

        return [$date, false, null === $tzid ? null : $timezone->getName()];
    }

    private function resolveTimezone(?string $tzid): ?\DateTimeZone
    {
        if (null === $tzid || '' === $tzid) {
            return null;
        }

        try {
            return new \DateTimeZone($tzid);
        } catch (\Exception) {
            // Clients may send Windows style identifiers this bundle does not
            // know; the appointment is then interpreted in server local time.
            return null;
        }
    }

    private function resolveEnd(IcalComponent $event, \DateTime $start, bool $allDay): ?\DateTime
    {
        $end = $event->getProperty('DTEND');

        if (null !== $end) {
            return $this->parseDate($end)[0];
        }

        $duration = $event->getValue('DURATION');

        if (null !== $duration) {
            $seconds = IcalDuration::toSeconds($duration);

            if (null !== $seconds) {
                return (clone $start)->modify(sprintf('%+d seconds', $seconds));
            }
        }

        if ($allDay) {
            // RFC 5545: an all-day event without DTEND lasts exactly one day.
            return (clone $start)->modify('+1 day');
        }

        return null;
    }

    /**
     * Derives the simplified repeat interval in days from a recurrence rule.
     * Rules this bundle cannot express that way keep `repeatInterval` empty –
     * the full rule stays available in `rrule`.
     */
    private function extractRepeatInterval(?string $rrule): ?int
    {
        if (null === $rrule) {
            return null;
        }

        $parts = [];
        foreach (explode(';', $rrule) as $segment) {
            $pair = explode('=', $segment, 2);

            if (2 === count($pair)) {
                $parts[strtoupper(trim($pair[0]))] = strtoupper(trim($pair[1]));
            }
        }

        $interval = isset($parts['INTERVAL']) ? max(1, (int)$parts['INTERVAL']) : 1;

        return match ($parts['FREQ'] ?? null) {
            'DAILY' => $interval,
            'WEEKLY' => $interval * 7,
            default => null,
        };
    }

    /**
     * Number of seconds between the reminder and the start of the appointment.
     */
    private function extractReminderTimer(IcalComponent $event, \DateTime $start): ?int
    {
        foreach ($event->getComponents('VALARM') as $alarm) {
            $trigger = $alarm->getProperty('TRIGGER');

            if (null === $trigger) {
                continue;
            }

            if ($trigger->hasParameterValue('VALUE', 'DATE-TIME')) {
                $absolute = $this->parseDate($trigger)[0];

                return max(0, $start->getTimestamp() - $absolute->getTimestamp());
            }

            $seconds = IcalDuration::toSeconds($trigger->value);

            if (null === $seconds) {
                continue;
            }

            // Alarms relative to the end of the appointment are not expressible
            // through `reminderTimer`; they stay in the raw calendar object.
            if ($trigger->hasParameterValue('RELATED', 'END')) {
                continue;
            }

            return abs($seconds);
        }

        return null;
    }

    private function emptyToNull(?string $value): ?string
    {
        return null === $value || '' === trim($value) ? null : $value;
    }
}
