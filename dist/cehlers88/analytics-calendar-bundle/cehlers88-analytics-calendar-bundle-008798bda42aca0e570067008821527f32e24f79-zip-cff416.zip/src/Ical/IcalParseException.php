<?php

namespace Cehlers88\AnalyticsCalendarBundle\Ical;

/**
 * Raised when an iCalendar stream cannot be read. CalDAV maps it onto a
 * "400 Bad Request" answer for the offending PUT.
 */
class IcalParseException extends \RuntimeException
{
}
