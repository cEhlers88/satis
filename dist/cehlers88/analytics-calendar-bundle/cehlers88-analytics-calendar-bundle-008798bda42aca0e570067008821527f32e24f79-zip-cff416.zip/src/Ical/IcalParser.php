<?php

namespace Cehlers88\AnalyticsCalendarBundle\Ical;

/**
 * Minimal RFC 5545 reader.
 *
 * It understands the grammar of the format (line unfolding, parameters, nested
 * components) but does not interpret any value: turning a DTSTART into a
 * DateTime is the job of {@see AppointmentHydrator}. That keeps the parser
 * lossless, which matters because calendar objects delivered by a client are
 * stored verbatim and handed back on the next GET.
 */
class IcalParser
{
    /**
     * @throws IcalParseException
     */
    public function parse(string $input): IcalComponent
    {
        $root = new IcalComponent('ROOT');
        /** @var IcalComponent[] $stack */
        $stack = [$root];

        foreach ($this->unfold($input) as $line) {
            if ('' === trim($line)) {
                continue;
            }

            [$name, $parameters, $value] = $this->parseLine($line);

            if ('BEGIN' === $name) {
                $component = new IcalComponent(strtoupper($value));
                $stack[count($stack) - 1]->addComponent($component);
                $stack[] = $component;
                continue;
            }

            if ('END' === $name) {
                if (count($stack) < 2) {
                    throw new IcalParseException(sprintf('Unexpected END:%s without matching BEGIN.', $value));
                }

                $closed = array_pop($stack);
                if ($closed->name !== strtoupper($value)) {
                    throw new IcalParseException(sprintf('END:%s does not match BEGIN:%s.', $value, $closed->name));
                }

                continue;
            }

            $stack[count($stack) - 1]->addProperty(new IcalProperty($name, $value, $parameters));
        }

        if (count($stack) > 1) {
            throw new IcalParseException(sprintf('Unterminated component BEGIN:%s.', $stack[count($stack) - 1]->name));
        }

        return $root;
    }

    /**
     * Returns the first VCALENDAR of the stream.
     *
     * @throws IcalParseException
     */
    public function parseCalendar(string $input): IcalComponent
    {
        $calendar = $this->parse($input)->getComponent('VCALENDAR');

        if (null === $calendar) {
            throw new IcalParseException('The iCalendar stream does not contain a VCALENDAR component.');
        }

        return $calendar;
    }

    /**
     * Joins folded content lines back together (RFC 5545, section 3.1).
     *
     * @return string[]
     */
    private function unfold(string $input): array
    {
        $input = str_replace(["\r\n", "\r"], "\n", $input);
        // A CRLF followed by a single white space character is a fold.
        $input = preg_replace("/\n[ \t]/", '', $input) ?? $input;

        return explode("\n", $input);
    }

    /**
     * @return array{0: string, 1: array<string, string[]>, 2: string}
     *
     * @throws IcalParseException
     */
    private function parseLine(string $line): array
    {
        $colonPosition = $this->findValueSeparator($line);

        if (null === $colonPosition) {
            throw new IcalParseException(sprintf('Malformed content line without value separator: "%s".', $line));
        }

        $definition = substr($line, 0, $colonPosition);
        $value = substr($line, $colonPosition + 1);
        $segments = $this->splitUnquoted($definition, ';');
        $name = strtoupper(array_shift($segments) ?? '');

        if ('' === $name) {
            throw new IcalParseException(sprintf('Content line without property name: "%s".', $line));
        }

        $parameters = [];
        foreach ($segments as $segment) {
            $equalsPosition = strpos($segment, '=');

            if (false === $equalsPosition) {
                // Parameters without a value are illegal but appear in the wild;
                // keep them addressable instead of failing the whole request.
                $parameters[strtoupper($segment)][] = '';
                continue;
            }

            $parameterName = strtoupper(substr($segment, 0, $equalsPosition));
            foreach ($this->splitUnquoted(substr($segment, $equalsPosition + 1), ',') as $parameterValue) {
                $parameters[$parameterName][] = $this->stripQuotes($parameterValue);
            }
        }

        return [$name, $parameters, $value];
    }

    /**
     * Position of the colon that separates the property definition from its
     * value, ignoring colons inside quoted parameter values.
     */
    private function findValueSeparator(string $line): ?int
    {
        $quoted = false;
        $length = strlen($line);

        for ($i = 0; $i < $length; ++$i) {
            $character = $line[$i];

            if ('"' === $character) {
                $quoted = !$quoted;
                continue;
            }

            if (':' === $character && !$quoted) {
                return $i;
            }
        }

        return null;
    }

    /**
     * @return string[]
     */
    private function splitUnquoted(string $input, string $delimiter): array
    {
        $segments = [];
        $current = '';
        $quoted = false;
        $length = strlen($input);

        for ($i = 0; $i < $length; ++$i) {
            $character = $input[$i];

            if ('"' === $character) {
                $quoted = !$quoted;
                $current .= $character;
                continue;
            }

            if ($character === $delimiter && !$quoted) {
                $segments[] = $current;
                $current = '';
                continue;
            }

            $current .= $character;
        }

        $segments[] = $current;

        return $segments;
    }

    private function stripQuotes(string $value): string
    {
        if (strlen($value) >= 2 && str_starts_with($value, '"') && str_ends_with($value, '"')) {
            return substr($value, 1, -1);
        }

        return $value;
    }
}
