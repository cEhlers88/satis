<?php

namespace Cehlers88\AnalyticsCalendarBundle\Ical;

/**
 * Serialises an {@see IcalComponent} tree back into an RFC 5545 stream,
 * including CRLF line endings and folding of long content lines.
 */
class IcalWriter
{
    private const LINE_LENGTH = 75;
    private const LINE_ENDING = "\r\n";

    public function write(IcalComponent $component): string
    {
        if ('ROOT' === $component->name) {
            $output = '';
            foreach ($component->getComponents() as $child) {
                $output .= $this->write($child);
            }

            return $output;
        }

        $lines = [];
        $lines[] = 'BEGIN:' . $component->name;

        foreach ($component->getProperties() as $property) {
            $lines[] = $this->renderProperty($property);
        }

        foreach ($component->getComponents() as $child) {
            $lines[] = rtrim($this->write($child), self::LINE_ENDING);
        }

        $lines[] = 'END:' . $component->name;

        $output = '';
        foreach ($lines as $line) {
            // Nested components already carry their own folded line endings.
            $output .= (str_contains($line, self::LINE_ENDING) ? $line : $this->fold($line)) . self::LINE_ENDING;
        }

        return $output;
    }

    private function renderProperty(IcalProperty $property): string
    {
        $line = $property->name;

        foreach ($property->parameters as $name => $values) {
            $rendered = array_map($this->renderParameterValue(...), $values);
            $line .= ';' . $name . '=' . implode(',', $rendered);
        }

        return $line . ':' . $property->value;
    }

    private function renderParameterValue(string $value): string
    {
        if ('' === $value) {
            return '""';
        }

        // Quoting is required as soon as the value contains a delimiter.
        if (preg_match('/[";:,]/', $value)) {
            return '"' . str_replace('"', '', $value) . '"';
        }

        return $value;
    }

    /**
     * Splits a content line into chunks of at most 75 octets. Continuation
     * lines are prefixed with a single space; multi-byte characters are never
     * split apart.
     */
    private function fold(string $line): string
    {
        if (strlen($line) <= self::LINE_LENGTH) {
            return $line;
        }

        $characters = preg_split('//u', $line, -1, PREG_SPLIT_NO_EMPTY);

        if (false === $characters) {
            // Not valid UTF-8 – fall back to a byte-wise split.
            return implode(self::LINE_ENDING . ' ', str_split($line, self::LINE_LENGTH - 1));
        }

        $lines = [];
        $current = '';
        $limit = self::LINE_LENGTH;

        foreach ($characters as $character) {
            if (strlen($current) + strlen($character) > $limit) {
                $lines[] = $current;
                $current = '';
                // Every following line loses one octet to the leading space.
                $limit = self::LINE_LENGTH - 1;
            }

            $current .= $character;
        }

        if ('' !== $current) {
            $lines[] = $current;
        }

        return implode(self::LINE_ENDING . ' ', $lines);
    }
}
