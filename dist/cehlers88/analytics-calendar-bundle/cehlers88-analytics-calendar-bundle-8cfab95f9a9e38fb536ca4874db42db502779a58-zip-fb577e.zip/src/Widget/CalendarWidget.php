<?php

namespace Cehlers88\AnalyticsCalendarBundle\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Cehlers88\AnalyticsCalendarBundle\Calendar\CalendarGrid;
use Cehlers88\AnalyticsCalendarBundle\Calendar\CalendarViewFactory;
use Cehlers88\AnalyticsCalendarBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Widget\AbstractWidget;
use Twig\Environment;

/**
 * The calendar tile: the appointments of a month or a week, and the mask that
 * puts a new one into the day that was picked.
 *
 * Navigating and saving both go through submit() rather than through a full
 * re-render, so the tile only ever exchanges its body - which is rendered from
 * the same template the first paint uses.
 */
class CalendarWidget extends AbstractWidget
{
    private const BODY_TEMPLATE = 'widget/_calendarBody.html.twig';

    public function __construct(
        private CalendarViewFactory   $calendarViewFactory,
        private AppointmentRepository $appointmentRepository,
        private ConfigurationProvider $configurationProvider,
        private Environment           $twig
    )
    {
    }

    public function getRequiredRoles(): array
    {
        return [
            'ROLE_USER',
        ];
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '32px', 'boxes' => [.5, .5]],
            ['height' => '240px', 'boxes' => [1]],
            ['height' => '32px', 'boxes' => [.6, .4]],
        ];
    }

    /**
     * @return PropertyDTO[]
     */
    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                'view',
                CalendarGrid::VIEW_MONTH,
                'string',
                true,
                'Ansicht',
                false,
                'Mit welcher Ansicht die Kachel startet.',
                [
                    'options' => [
                        CalendarGrid::VIEW_MONTH => 'Monat',
                        CalendarGrid::VIEW_WEEK => 'Woche',
                    ],
                ]
            ),
            PropertyDTO::create(
                'maxEntriesPerDay',
                3,
                'int',
                true,
                'Termine pro Tag',
                false,
                'Wie viele Termine ein Tag zeigt, bevor der Rest zusammengefasst wird.',
                ['min' => 1, 'max' => 8]
            ),
            PropertyDTO::create(
                'showWeekNumbers',
                false,
                'bool',
                true,
                'Kalenderwochen anzeigen',
                false,
                'Stellt jeder Woche ihre Kalenderwoche voran.'
            ),
        ];
    }

    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        return match ($data['action'] ?? '') {
            'render' => $this->renderBody($data),
            'create' => $this->createAppointment($data),
            'delete' => $this->deleteAppointment($data),
            default => WidgetSubmitResultDTO::createError(400, 'Unbekannte Aktion'),
        };
    }

    /**
     * The body of the tile for the period that was navigated to. The template
     * stays the single source of what a calendar looks like - the client only
     * swaps the markup it gets back in.
     */
    private function renderBody(array $data): WidgetSubmitResultDTO
    {
        try {
            $html = $this->twig->render(self::BODY_TEMPLATE, [
                'id' => $data['id'] ?? uniqid(),
                ...$this->enrichProperties($data),
            ]);
        } catch (\Throwable $exception) {
            return WidgetSubmitResultDTO::createError(500, 'Kalender konnte nicht gerendert werden.');
        }

        return WidgetSubmitResultDTO::createSuccess('', ['html' => $html], 200);
    }

    public function enrichProperties(array $properties): array
    {
        return [
            ...$properties,
            ...$this->buildViewProperties($properties),
            'widgetName' => $this->getName(),
            'maxEntriesPerDay' => $this->readMaxEntriesPerDay($properties),
            'showWeekNumbers' => $this->readFlag($properties, 'showWeekNumbers'),
            'repeatOptions' => $this->getRepeatOptions(),
            'reminderOptions' => $this->getReminderOptions(),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function buildViewProperties(array $properties): array
    {
        return $this->calendarViewFactory->create(
            $this->parseAnchor($properties['date'] ?? null),
            $this->readView($properties),
            $this->readFirstDayOfWeek($properties),
            (string)$this->getConfigurationValue('defaultTimeFormat', 'H:i'),
            (string)$this->getConfigurationValue('defaultDateFormat', 'd.m.Y')
        );
    }

    private function parseAnchor(mixed $date): \DateTimeImmutable
    {
        if (is_numeric($date)) {
            return new \DateTimeImmutable()->setTimestamp((int)$date);
        }

        if (is_string($date) && trim($date) !== '') {
            try {
                return new \DateTimeImmutable($date);
            } catch (\Exception) {
                // A date the tile can not read is no reason to show nothing.
            }
        }

        return new \DateTimeImmutable('today');
    }
    
    private function readView(array $properties): string
    {
        $view = (string)($properties['view'] ?? CalendarGrid::VIEW_MONTH);

        return $view === CalendarGrid::VIEW_WEEK ? CalendarGrid::VIEW_WEEK : CalendarGrid::VIEW_MONTH;
    }

    /**
     * The weekday the calendar starts on: what the tile was given, otherwise
     * what the bundle is configured with.
     */
    private function readFirstDayOfWeek(array $properties): int
    {
        $configured = $properties['firstDayOfWeek']
            ?? $this->getConfigurationValue('defaultWeekStart', 1);

        return min(7, max(1, (int)$configured));
    }

    private function getConfigurationValue(string $key, mixed $default): mixed
    {
        try {
            $value = $this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, $key, -1, $default);
        } catch (\Throwable) {
            return $default;
        }

        return $value === null || $value === '' ? $default : $value;
    }

    public function getName(): string
    {
        return 'calendar';
    }

    private function readMaxEntriesPerDay(array $properties): int
    {
        return min(8, max(1, (int)($properties['maxEntriesPerDay'] ?? 3)));
    }

    private function readFlag(array $properties, string $name): bool
    {
        return filter_var($properties[$name] ?? false, FILTER_VALIDATE_BOOL);
    }

    /**
     * @return array<int, string>
     */
    private function getRepeatOptions(): array
    {
        return [
            0 => 'Einmalig',
            1 => 'Täglich',
            7 => 'Wöchentlich',
            14 => 'Alle zwei Wochen',
            30 => 'Monatlich',
        ];
    }

    /**
     * @return array<int, string>
     */
    private function getReminderOptions(): array
    {
        return [
            0 => 'Keine Erinnerung',
            300 => '5 Minuten vorher',
            900 => '15 Minuten vorher',
            1800 => '30 Minuten vorher',
            3600 => '1 Stunde vorher',
            86400 => '1 Tag vorher',
        ];
    }

    private function createAppointment(array $data): WidgetSubmitResultDTO
    {
        $title = trim((string)($data['title'] ?? ''));

        if ($title === '') {
            return WidgetSubmitResultDTO::createError(422, 'Bitte einen Titel angeben.');
        }

        $start = $this->parseDateTime($data['date'] ?? '', $data['startTime'] ?? '');

        if ($start === null) {
            return WidgetSubmitResultDTO::createError(422, 'Bitte ein gültiges Datum angeben.');
        }

        // An appointment only gets an end when one was actually submitted -
        // an empty end would otherwise land on midnight of the same day.
        $endDate = trim((string)($data['endDate'] ?? ''));
        $endTime = trim((string)($data['endTime'] ?? ''));
        $end = $endDate === '' && $endTime === ''
            ? null
            : $this->parseDateTime($endDate === '' ? ($data['date'] ?? '') : $endDate, $endTime);

        if ($end !== null && $end < $start) {
            return WidgetSubmitResultDTO::createError(422, 'Das Ende liegt vor dem Beginn.');
        }

        $appointment = new Appointment()
            ->setTitle($title)
            ->setDescription($this->nullIfBlank((string)($data['description'] ?? '')))
            ->setStartDate($start)
            ->setEndDate($end)
            ->setRepeatInterval($this->positiveIntOrNull($data['repeatInterval'] ?? null))
            ->setReminderTimer($this->positiveIntOrNull($data['reminderTimer'] ?? null));

        try {
            $this->appointmentRepository->save($appointment);
        } catch (\Throwable $exception) {
            return WidgetSubmitResultDTO::createError(500, 'Der Termin konnte nicht gespeichert werden.');
        }

        return WidgetSubmitResultDTO::createSuccess('Termin gespeichert', [
            'id' => $appointment->getId(),
            'date' => $start->format('Y-m-d'),
        ], 201);
    }

    private function parseDateTime(mixed $date, mixed $time): ?\DateTime
    {
        $date = trim((string)$date);

        if ($date === '') {
            return null;
        }

        $time = trim((string)$time);
        $time = $time === '' ? '00:00' : $time;

        $parsed = \DateTime::createFromFormat('Y-m-d H:i', $date . ' ' . substr($time, 0, 5));
        $errors = \DateTime::getLastErrors();

        if (
            $parsed === false
            || (($errors['warning_count'] ?? 0) > 0)
            || (($errors['error_count'] ?? 0) > 0)
        ) {
            return null;
        }

        return $parsed->setTime(
            (int)$parsed->format('H'),
            (int)$parsed->format('i'),
            0
        );
    }

    private function nullIfBlank(string $value): ?string
    {
        return trim($value) === '' ? null : trim($value);
    }

    private function positiveIntOrNull(mixed $value): ?int
    {
        return (int)$value > 0 ? (int)$value : null;
    }

    /**
     * Removes the appointment the detail view was opened with. A repeating
     * appointment is one entity, so this takes the whole series with it - which
     * is what the mask says before it asks.
     */
    private function deleteAppointment(array $data): WidgetSubmitResultDTO
    {
        // Deliberately not 'id': that is the id of the widget instance, which
        // the render action is given alongside it.
        $id = (int)($data['appointmentId'] ?? 0);

        if ($id < 1) {
            return WidgetSubmitResultDTO::createError(422, 'Kein Termin ausgewählt.');
        }

        $appointment = $this->appointmentRepository->find($id);

        if ($appointment === null) {
            return WidgetSubmitResultDTO::createError(404, 'Der Termin existiert nicht mehr.');
        }

        try {
            $this->appointmentRepository->remove($appointment);
        } catch (\Throwable $exception) {
            return WidgetSubmitResultDTO::createError(500, 'Der Termin konnte nicht gelöscht werden.');
        }

        return WidgetSubmitResultDTO::createSuccess('Termin gelöscht', ['id' => $id], 200);
    }
}
