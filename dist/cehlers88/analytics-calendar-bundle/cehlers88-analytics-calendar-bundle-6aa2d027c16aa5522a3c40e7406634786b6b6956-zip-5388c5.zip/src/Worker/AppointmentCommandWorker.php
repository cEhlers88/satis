<?php

namespace Cehlers88\AnalyticsCalendarBundle\Worker;

use Cehlers88\AnalyticsCalendarBundle\Calendar\OccurrenceResolver;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Worker\AbstractWorker;

/**
 * Startet und beendet Termine: sobald ein Termin (oder eine seiner
 * Wiederholungen) beginnt, laufen seine Start-Commands - beim allerersten Start
 * vorher die First-Start-Commands - und sobald er endet, seine End-Commands.
 *
 * The occurrence that was started or ended is stored on the appointment before
 * its commands run, so no occurrence is handled twice: a command that fails is
 * reported as a warning, not retried on the next run.
 */
class AppointmentCommandWorker extends AbstractWorker
{
    private const TRIGGER_FIRST_START = 'first start';
    private const TRIGGER_START = 'start';
    private const TRIGGER_END = 'end';

    private \DateTimeImmutable $now;

    public function __construct(
        private AppointmentRepository $appointmentRepository,
        private OccurrenceResolver    $occurrenceResolver,
        private CommandFactory        $commandFactory
    )
    {
        $this->now = new \DateTimeImmutable();
        $this->addProperty(PropertyDTO::create(
            'max_start_delay',
            -1,
            'int',
            true,
            'Max. Startverzögerung (Sekunden)',
            false,
            'Wie lange nach Beginn ein verpasster Start noch nachgeholt wird. -1 holt jeden Start nach, der noch nicht geendet hat.'
        ));
    }

    public function getWorkingObjects(): array
    {
        // One moment for the whole run, so an appointment is not judged against
        // a later clock than the query that found it.
        $this->now = new \DateTimeImmutable();

        return $this->appointmentRepository->findWithPendingCommands($this->now);
    }

    public function handleWorkingObjects(array $workingObjects): array
    {
        $started = 0;
        $ended = 0;

        /** @var Appointment $appointment */
        foreach ($workingObjects as $appointment) {
            // The running occurrence ends before the next one may start.
            if ($this->handleEnd($appointment)) {
                $ended++;
            }

            if ($this->handleStart($appointment)) {
                $started++;
            }
        }

        $this->addResultMessage(sprintf('%d appointment(s) started, %d ended.', $started, $ended));

        return [];
    }

    private function handleEnd(Appointment $appointment): bool
    {
        $occurrence = $appointment->getLastStartedOccurrence();

        if ($occurrence === null || $occurrence == $appointment->getLastEndedOccurrence()) {
            return false;
        }

        $end = $this->occurrenceResolver->endOf($appointment, $occurrence);

        if ($end === null || $end > $this->now) {
            return false;
        }

        $appointment->setLastEndedOccurrence($occurrence);
        $this->appointmentRepository->save($appointment);

        $this->runCommands($appointment, self::TRIGGER_END, $appointment->getEndCommands());

        return true;
    }

    private function handleStart(Appointment $appointment): bool
    {
        $occurrence = $this->occurrenceResolver->latestStartAtOrBefore($appointment, $this->now);
        $lastStarted = $appointment->getLastStartedOccurrence();

        if ($occurrence === null || ($lastStarted !== null && $occurrence <= $lastStarted)) {
            return false;
        }

        if ($this->isMissed($appointment, $occurrence)) {
            $this->logInfo(sprintf(
                'Appointment #%d: occurrence of %s was missed, its start is skipped.',
                $appointment->getId(),
                $occurrence->format('Y-m-d H:i')
            ), true);

            return false;
        }

        $isFirstStart = $lastStarted === null;

        $appointment->setLastStartedOccurrence($occurrence);
        $this->appointmentRepository->save($appointment);

        if ($isFirstStart) {
            $this->runCommands($appointment, self::TRIGGER_FIRST_START, $appointment->getFirstStartCommands());
        }

        $this->runCommands($appointment, self::TRIGGER_START, $appointment->getStartCommands());

        return true;
    }

    /**
     * An occurrence that is already over, or began longer ago than the worker
     * is allowed to catch up on, is not started any more.
     */
    private function isMissed(Appointment $appointment, \DateTimeImmutable $occurrence): bool
    {
        $end = $this->occurrenceResolver->endOf($appointment, $occurrence);

        if ($end !== null && $end <= $this->now) {
            return true;
        }

        $maxStartDelay = (int)$this->getPropertyValue('max_start_delay', -1);

        return $maxStartDelay >= 0
            && $this->now->getTimestamp() - $occurrence->getTimestamp() > $maxStartDelay;
    }

    private function runCommands(Appointment $appointment, string $trigger, ?array $definition): void
    {
        if (empty($definition)) {
            return;
        }

        $commands = $this->commandFactory->evalDefinitionArray($definition, true);

        if (
            !$commands instanceof CommandGroupDTO
            || count($commands->commands) === 0
            || in_array(null, $commands->commands, true)
        ) {
            $this->logWarning(sprintf(
                'Appointment #%d: the %s commands are no valid command definition.',
                $appointment->getId(),
                $trigger
            ));

            return;
        }

        // Commands always run in an application - the one of the appointment,
        // not the one the worker happens to be registered for.
        $application = $appointment->getApplication();

        if ($application === null) {
            $this->logWarning(sprintf(
                'Appointment #%d: the %s commands need an application to run in.',
                $appointment->getId(),
                $trigger
            ));

            return;
        }

        $commandPlayer = $this->macroPlayer->getMacroEnvironment()->getCommandPlayer();
        $commandPlayer->setApplication($application);

        try {
            $commandPlayer->run($commands);
            $this->logInfo(sprintf(
                'Appointment #%d "%s": %s commands executed.',
                $appointment->getId(),
                $appointment->getTitle(),
                $trigger
            ));
        } catch (\Throwable $exception) {
            $this->logWarning(sprintf(
                'Appointment #%d: %s commands failed: %s',
                $appointment->getId(),
                $trigger,
                $exception->getMessage()
            ));
        }
    }
}
