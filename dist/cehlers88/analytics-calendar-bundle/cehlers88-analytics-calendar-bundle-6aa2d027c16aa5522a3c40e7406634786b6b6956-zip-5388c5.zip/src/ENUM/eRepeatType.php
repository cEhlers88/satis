<?php

namespace Cehlers88\AnalyticsCalendarBundle\ENUM;

/**
 * How an appointment repeats. An interval counts its days in
 * Appointment::$repeatInterval, the other types need no further value.
 */
enum eRepeatType: string
{
    case NONE = 'none';
    case INTERVAL = 'interval';
    case WEEKDAYS = 'weekdays';

    public static function getLabel(eRepeatType $type): string
    {
        return match ($type) {
            self::NONE => 'Einmalig',
            self::INTERVAL => 'Intervall',
            self::WEEKDAYS => 'Mo – Fr',
        };
    }
}
