<?php

namespace Cehlers88\AnalyticsCalendarBundle\Entity;

use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\User;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: AppointmentRepository::class)]
#[ORM\Table(name: 'calendar_appointment')]
class Appointment
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $startDate = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $endDate = null;

    /** Days between two occurrences - only read for eRepeatType::INTERVAL. */
    #[ORM\Column(nullable: true)]
    private ?int $repeatInterval = null;

    /**
     * Nullable so rows from before the column existed stay readable - they are
     * an interval or nothing, which getRepeatType() derives from repeatInterval.
     */
    #[ORM\Column(nullable: true)]
    private ?eRepeatType $repeatType = null;

    #[ORM\Column(nullable: true)]
    private ?int $reminderTimer = null;

    #[ORM\Column(length: 255)]
    private ?string $title = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    /** Command definitions run whenever an occurrence starts. */
    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $startCommands = null;

    /** Command definitions run whenever an occurrence ends. */
    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $endCommands = null;

    /** Command definitions run only when the very first occurrence starts. */
    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $firstStartCommands = null;

    /**
     * The application the commands run in - required as soon as there are
     * commands. Deleting the application leaves the appointment without one.
     */
    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?Application $application = null;

    /** The start of the occurrence the worker started last. */
    #[ORM\Column(type: Types::DATETIME_IMMUTABLE, nullable: true)]
    private ?\DateTimeImmutable $lastStartedOccurrence = null;

    /** The start of the occurrence the worker ended last. */
    #[ORM\Column(type: Types::DATETIME_IMMUTABLE, nullable: true)]
    private ?\DateTimeImmutable $lastEndedOccurrence = null;

    /**
     * @var Collection<int, User>
     */
    #[ORM\ManyToMany(targetEntity: User::class)]
    #[ORM\JoinTable(name: 'calendar_appointment_user')]
    private Collection $users;

    public function __construct()
    {
        $this->users = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getStartDate(): ?\DateTimeInterface
    {
        return $this->startDate;
    }

    public function setStartDate(\DateTimeInterface $startDate): static
    {
        $this->startDate = $startDate;

        return $this;
    }

    public function getEndDate(): ?\DateTimeInterface
    {
        return $this->endDate;
    }

    public function setEndDate(?\DateTimeInterface $endDate): static
    {
        $this->endDate = $endDate;

        return $this;
    }

    public function getRepeatInterval(): ?int
    {
        return $this->repeatInterval;
    }

    /**
     * A positive interval makes the appointment an interval series, removing
     * the interval ends one.
     */
    public function setRepeatInterval(?int $repeatInterval): static
    {
        $this->repeatInterval = $repeatInterval;

        if ((int)$repeatInterval > 0) {
            $this->repeatType = eRepeatType::INTERVAL;
        } elseif ($this->repeatType === eRepeatType::INTERVAL) {
            $this->repeatType = eRepeatType::NONE;
        }

        return $this;
    }

    public function getRepeatType(): eRepeatType
    {
        if ($this->repeatType === eRepeatType::WEEKDAYS) {
            return eRepeatType::WEEKDAYS;
        }

        return (int)$this->repeatInterval > 0 ? eRepeatType::INTERVAL : eRepeatType::NONE;
    }

    /**
     * Every type but an interval has no use for a day count, so it is dropped.
     */
    public function setRepeatType(eRepeatType $repeatType): static
    {
        $this->repeatType = $repeatType;

        if ($repeatType !== eRepeatType::INTERVAL) {
            $this->repeatInterval = null;
        }

        return $this;
    }

    public function isRepeating(): bool
    {
        return $this->getRepeatType() !== eRepeatType::NONE;
    }

    public function getReminderTimer(): ?int
    {
        return $this->reminderTimer;
    }

    public function setReminderTimer(?int $reminderTimer): static
    {
        $this->reminderTimer = $reminderTimer;

        return $this;
    }

    public function getTitle(): ?string
    {
        return $this->title;
    }

    public function setTitle(string $title): static
    {
        $this->title = $title;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getStartCommands(): ?array
    {
        return $this->startCommands;
    }

    public function setStartCommands(?array $startCommands): static
    {
        $this->startCommands = $startCommands ?: null;

        return $this;
    }

    public function getEndCommands(): ?array
    {
        return $this->endCommands;
    }

    public function setEndCommands(?array $endCommands): static
    {
        $this->endCommands = $endCommands ?: null;

        return $this;
    }

    public function getFirstStartCommands(): ?array
    {
        return $this->firstStartCommands;
    }

    public function setFirstStartCommands(?array $firstStartCommands): static
    {
        $this->firstStartCommands = $firstStartCommands ?: null;

        return $this;
    }

    public function getApplication(): ?Application
    {
        return $this->application;
    }

    public function setApplication(?Application $application): static
    {
        $this->application = $application;

        return $this;
    }

    public function hasCommands(): bool
    {
        return $this->startCommands !== null
            || $this->endCommands !== null
            || $this->firstStartCommands !== null;
    }

    public function getLastStartedOccurrence(): ?\DateTimeImmutable
    {
        return $this->lastStartedOccurrence;
    }

    public function setLastStartedOccurrence(?\DateTimeImmutable $lastStartedOccurrence): static
    {
        $this->lastStartedOccurrence = $lastStartedOccurrence;

        return $this;
    }

    public function getLastEndedOccurrence(): ?\DateTimeImmutable
    {
        return $this->lastEndedOccurrence;
    }

    public function setLastEndedOccurrence(?\DateTimeImmutable $lastEndedOccurrence): static
    {
        $this->lastEndedOccurrence = $lastEndedOccurrence;

        return $this;
    }

    /**
     * @return Collection<int, User>
     */
    public function getUsers(): Collection
    {
        return $this->users;
    }

    public function addUser(User $user): static
    {
        if (!$this->users->contains($user)) {
            $this->users->add($user);
        }

        return $this;
    }

    public function removeUser(User $user): static
    {
        $this->users->removeElement($user);

        return $this;
    }
}
