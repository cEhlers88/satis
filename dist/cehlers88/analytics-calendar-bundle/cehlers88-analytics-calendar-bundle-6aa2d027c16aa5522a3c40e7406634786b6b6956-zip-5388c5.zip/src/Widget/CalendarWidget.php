<?php

namespace Cehlers88\AnalyticsCalendarBundle\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Cehlers88\AnalyticsCalendarBundle\Calendar\CalendarGrid;
use Cehlers88\AnalyticsCalendarBundle\Calendar\CalendarViewFactory;
use Cehlers88\AnalyticsCalendarBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\UserRepository;
use Cehlers88\AnalyticsCore\Widget\AbstractWidget;
use Symfony\Bundle\SecurityBundle\Security;
use Twig\Environment;

/**
 * The calendar tile: the appointments of a month or a week that are assigned
 * to the user looking at it, and the mask that creates and edits them.
 *
 * Navigating, loading and saving all go through submit() rather than through a
 * full re-render, so the tile only ever exchanges its body - which is rendered
 * from the same template the first paint uses.
 */
class CalendarWidget extends AbstractWidget
{
    private const BODY_TEMPLATE = 'widget/_calendarBody.html.twig';

    /** The command fields of the mask, and how an error message names them. */
    private const COMMAND_FIELDS = [
        'startCommands' => 'Start-Commands',
        'endCommands' => 'End-Commands',
        'firstStartCommands' => 'First-Start-Commands',
    ];

    public function __construct(
        private CalendarViewFactory   $calendarViewFactory,
        private AppointmentRepository $appointmentRepository,
        private ConfigurationProvider $configurationProvider,
        private Environment           $twig,
        private UserRepository        $userRepository,
        private Security              $security,
        private ApplicationRepository $applicationRepository
    )
    {
    }

    public function getRequiredRoles(): array
    {
        return [
            'ROLE_USER',
        ];
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '32px', 'boxes' => [.5, .5]],
            ['height' => '240px', 'boxes' => [1]],
            ['height' => '32px', 'boxes' => [.6, .4]],
        ];
    }

    /**
     * @return PropertyDTO[]
     */
    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                'view',
                CalendarGrid::VIEW_MONTH,
                'string',
                true,
                'Ansicht',
                false,
                'Mit welcher Ansicht die Kachel startet.',
                [
                    'options' => [
                        CalendarGrid::VIEW_MONTH => 'Monat',
                        CalendarGrid::VIEW_WEEK => 'Woche',
                    ],
                ]
            ),
            PropertyDTO::create(
                'maxEntriesPerDay',
                3,
                'int',
                true,
                'Termine pro Tag',
                false,
                'Wie viele Termine ein Tag zeigt, bevor der Rest zusammengefasst wird.',
                ['min' => 1, 'max' => 8]
            ),
            PropertyDTO::create(
                'showWeekNumbers',
                false,
                'bool',
                true,
                'Kalenderwochen anzeigen',
                false,
                'Stellt jeder Woche ihre Kalenderwoche voran.'
            ),
        ];
    }

    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        $user = $this->resolveRequestUser($user);

        return match ($data['action'] ?? '') {
            'render' => $this->renderBody($data),
            'load' => $this->loadAppointment($data, $user),
            'create' => $this->storeAppointment(new Appointment(), $data, $user),
            'update' => $this->updateAppointment($data, $user),
            'delete' => $this->deleteAppointment($data, $user),
            default => WidgetSubmitResultDTO::createError(400, 'Unbekannte Aktion'),
        };
    }

    /**
     * The body of the tile for the period that was navigated to. The template
     * stays the single source of what a calendar looks like - the client only
     * swaps the markup it gets back in.
     */
    private function renderBody(array $data): WidgetSubmitResultDTO
    {
        try {
            $html = $this->twig->render(self::BODY_TEMPLATE, [
                'id' => $data['id'] ?? uniqid(),
                ...$this->enrichProperties($data),
            ]);
        } catch (\Throwable $exception) {
            return WidgetSubmitResultDTO::createError(500, 'Kalender konnte nicht gerendert werden.');
        }

        return WidgetSubmitResultDTO::createSuccess('', ['html' => $html], 200);
    }

    public function enrichProperties(array $properties): array
    {
        return [
            ...$properties,
            ...$this->buildViewProperties($properties),
            'widgetName' => $this->getName(),
            'maxEntriesPerDay' => $this->readMaxEntriesPerDay($properties),
            'showWeekNumbers' => $this->readFlag($properties, 'showWeekNumbers'),
            'repeatOptions' => $this->getRepeatOptions(),
            'reminderOptions' => $this->getReminderOptions(),
            'userOptions' => $this->getUserOptions(),
            'applicationOptions' => $this->getApplicationOptions(),
            'currentUserId' => $this->getCurrentUser()?->getId(),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function buildViewProperties(array $properties): array
    {
        return $this->calendarViewFactory->create(
            $this->parseAnchor($properties['date'] ?? null),
            $this->readView($properties),
            $this->readFirstDayOfWeek($properties),
            (string)$this->getConfigurationValue('defaultTimeFormat', 'H:i'),
            (string)$this->getConfigurationValue('defaultDateFormat', 'd.m.Y'),
            $this->getCurrentUser()
        );
    }

    private function parseAnchor(mixed $date): \DateTimeImmutable
    {
        if (is_numeric($date)) {
            return new \DateTimeImmutable()->setTimestamp((int)$date);
        }

        if (is_string($date) && trim($date) !== '') {
            try {
                return new \DateTimeImmutable($date);
            } catch (\Exception) {
                // A date the tile can not read is no reason to show nothing.
            }
        }

        return new \DateTimeImmutable('today');
    }

    private function readView(array $properties): string
    {
        $view = (string)($properties['view'] ?? CalendarGrid::VIEW_MONTH);

        return $view === CalendarGrid::VIEW_WEEK ? CalendarGrid::VIEW_WEEK : CalendarGrid::VIEW_MONTH;
    }

    /**
     * The weekday the calendar starts on: what the tile was given, otherwise
     * what the bundle is configured with.
     */
    private function readFirstDayOfWeek(array $properties): int
    {
        $configured = $properties['firstDayOfWeek']
            ?? $this->getConfigurationValue('defaultWeekStart', 1);

        return min(7, max(1, (int)$configured));
    }

    private function getConfigurationValue(string $key, mixed $default): mixed
    {
        try {
            $value = $this->configurationProvider->getValue(GeneralConfigurationGroup::KEY, $key, -1, $default);
        } catch (\Throwable) {
            return $default;
        }

        return $value === null || $value === '' ? $default : $value;
    }

    public function getName(): string
    {
        return 'calendar';
    }

    private function readMaxEntriesPerDay(array $properties): int
    {
        return min(8, max(1, (int)($properties['maxEntriesPerDay'] ?? 3)));
    }

    private function readFlag(array $properties, string $name): bool
    {
        return filter_var($properties[$name] ?? false, FILTER_VALIDATE_BOOL);
    }

    /**
     * A number is an interval in days, eRepeatType::WEEKDAYS the Monday to
     * Friday series.
     *
     * @return array<int|string, string>
     */
    private function getRepeatOptions(): array
    {
        return [
            0 => 'Einmalig',
            1 => 'Täglich',
            eRepeatType::WEEKDAYS->value => eRepeatType::getLabel(eRepeatType::WEEKDAYS),
            7 => 'Wöchentlich',
            14 => 'Alle zwei Wochen',
            30 => 'Monatlich',
        ];
    }

    /**
     * @return array<int, string>
     */
    private function getReminderOptions(): array
    {
        return [
            0 => 'Keine Erinnerung',
            300 => '5 Minuten vorher',
            900 => '15 Minuten vorher',
            1800 => '30 Minuten vorher',
            3600 => '1 Stunde vorher',
            86400 => '1 Tag vorher',
        ];
    }

    /**
     * @return array<int, string>
     */
    private function getUserOptions(): array
    {
        try {
            $users = $this->userRepository->findBy([], ['email' => 'ASC']);
        } catch (\Throwable) {
            return [];
        }

        $options = [];

        foreach ($users as $user) {
            $options[(int)$user->getId()] = (string)$user->getEmail();
        }

        return $options;
    }

    /**
     * The applications the user may read - every one for an admin. The core
     * repository applies that rule itself.
     *
     * @return Application[]
     */
    private function getReadableApplications(): array
    {
        try {
            return array_values($this->applicationRepository->findAll());
        } catch (\Throwable) {
            return [];
        }
    }

    /**
     * @return array<int, string>
     */
    private function getApplicationOptions(): array
    {
        $options = [];

        foreach ($this->getReadableApplications() as $application) {
            $options[(int)$application->getId()] = (string)$application->getName();
        }

        return $options;
    }

    /**
     * The application picked for the commands: null when none was picked,
     * false when it does not exist or the user may not read it.
     */
    private function findReadableApplication(mixed $applicationId): Application|false|null
    {
        $applicationId = (int)$applicationId;

        if ($applicationId < 1) {
            return null;
        }

        foreach ($this->getReadableApplications() as $application) {
            if ($application->getId() === $applicationId) {
                return $application;
            }
        }

        return false;
    }

    private function getCurrentUser(): ?User
    {
        $user = $this->security->getUser();

        return $user instanceof User ? $user : null;
    }

    /**
     * The user a request acts for, re-read so the appointment is linked to a
     * user the entity manager actually manages.
     */
    private function resolveRequestUser(?User $user): ?User
    {
        $user ??= $this->getCurrentUser();

        return $user?->getId() === null ? null : $this->userRepository->find($user->getId());
    }

    /**
     * An appointment of the user the request acts for. Someone else's
     * appointment is answered like one that does not exist, so its id tells
     * nothing about it.
     */
    private function findOwnAppointment(array $data, ?User $user): Appointment|WidgetSubmitResultDTO
    {
        // Deliberately not 'id': that is the id of the widget instance, which
        // the render action is given alongside it.
        $id = (int)($data['appointmentId'] ?? 0);

        if ($id < 1) {
            return WidgetSubmitResultDTO::createError(422, 'Kein Termin ausgewählt.');
        }

        $appointment = $user === null ? null : $this->appointmentRepository->findOneForUser($id, $user);

        if ($appointment === null) {
            return WidgetSubmitResultDTO::createError(404, 'Der Termin existiert nicht mehr.');
        }

        return $appointment;
    }

    /**
     * Everything the mask needs to edit an appointment, in the shape its fields
     * submit it. A series is edited as a whole, so the dates are the ones of
     * its first occurrence.
     */
    private function loadAppointment(array $data, ?User $user): WidgetSubmitResultDTO
    {
        $appointment = $this->findOwnAppointment($data, $user);

        if ($appointment instanceof WidgetSubmitResultDTO) {
            return $appointment;
        }

        $start = \DateTimeImmutable::createFromInterface($appointment->getStartDate());
        $end = $appointment->getEndDate() === null
            ? null
            : \DateTimeImmutable::createFromInterface($appointment->getEndDate());
        // Without an end the switch would give the appointment one on saving.
        $isAllDay = $end !== null
            && $start->format('H:i') === '00:00'
            && in_array($end->format('H:i'), ['00:00', '23:59'], true);

        return WidgetSubmitResultDTO::createSuccess('', [
            'id' => $appointment->getId(),
            'title' => (string)$appointment->getTitle(),
            'description' => (string)$appointment->getDescription(),
            'date' => $start->format('Y-m-d'),
            'startTime' => $isAllDay ? '' : $start->format('H:i'),
            'endDate' => $end?->format('Y-m-d') ?? '',
            'endTime' => $isAllDay || $end === null ? '' : $end->format('H:i'),
            'isAllDay' => $isAllDay,
            'repeatInterval' => $this->repeatValueOf($appointment),
            'isRepeating' => $appointment->isRepeating(),
            'reminderTimer' => (int)$appointment->getReminderTimer(),
            'applicationId' => $appointment->getApplication()?->getId(),
            'userIds' => $appointment->getUsers()->map(
                static fn(User $assignedUser): int => (int)$assignedUser->getId()
            )->getValues(),
            'startCommands' => $appointment->getStartCommands(),
            'endCommands' => $appointment->getEndCommands(),
            'firstStartCommands' => $appointment->getFirstStartCommands(),
        ], 200);
    }

    /** The repetition the way the select of the mask names it. */
    private function repeatValueOf(Appointment $appointment): string
    {
        return match ($appointment->getRepeatType()) {
            eRepeatType::WEEKDAYS => eRepeatType::WEEKDAYS->value,
            eRepeatType::INTERVAL => (string)(int)$appointment->getRepeatInterval(),
            eRepeatType::NONE => '0',
        };
    }

    private function updateAppointment(array $data, ?User $user): WidgetSubmitResultDTO
    {
        $appointment = $this->findOwnAppointment($data, $user);

        if ($appointment instanceof WidgetSubmitResultDTO) {
            return $appointment;
        }

        return $this->storeAppointment($appointment, $data, $user);
    }

    /**
     * Validates what the mask submitted and puts it on the appointment - a new
     * one or the one that is edited. Nothing is changed unless all of it is
     * valid.
     */
    private function storeAppointment(Appointment $appointment, array $data, ?User $user): WidgetSubmitResultDTO
    {
        $title = trim((string)($data['title'] ?? ''));

        if ($title === '') {
            return WidgetSubmitResultDTO::createError(422, 'Bitte einen Titel angeben.');
        }

        $start = $this->parseDateTime($data['date'] ?? '', $data['startTime'] ?? '');

        if ($start === null) {
            return WidgetSubmitResultDTO::createError(422, 'Bitte ein gültiges Datum angeben.');
        }

        // An appointment only gets an end when one was actually submitted -
        // an empty end would otherwise land on midnight of the same day.
        $endDate = trim((string)($data['endDate'] ?? ''));
        $endTime = trim((string)($data['endTime'] ?? ''));
        $end = $endDate === '' && $endTime === ''
            ? null
            : $this->parseDateTime($endDate === '' ? ($data['date'] ?? '') : $endDate, $endTime);

        if ($end !== null && $end < $start) {
            return WidgetSubmitResultDTO::createError(422, 'Das Ende liegt vor dem Beginn.');
        }

        $isWeekdays = (string)($data['repeatInterval'] ?? '') === eRepeatType::WEEKDAYS->value;
        $interval = $isWeekdays ? null : $this->positiveIntOrNull($data['repeatInterval'] ?? null);
        $isRepeating = $isWeekdays || $interval !== null;

        $commands = [];

        foreach (self::COMMAND_FIELDS as $key => $label) {
            $commands[$key] = $this->parseCommands($data[$key] ?? '');

            if ($commands[$key] === false) {
                return WidgetSubmitResultDTO::createError(422, $label . ' müssen ein JSON-Array mit Command-Definitionen sein.');
            }
        }

        if ($commands['endCommands'] !== null && $end === null) {
            return WidgetSubmitResultDTO::createError(422, 'End-Commands brauchen ein Ende des Termins.');
        }

        if ($commands['firstStartCommands'] !== null && !$isRepeating) {
            return WidgetSubmitResultDTO::createError(422, 'First-Start-Commands gibt es nur für Termine, die sich wiederholen.');
        }

        $application = $this->findReadableApplication($data['applicationId'] ?? null);

        if ($application === false) {
            return WidgetSubmitResultDTO::createError(422, 'Die ausgewählte Application existiert nicht oder ist nicht freigegeben.');
        }

        $hasCommands = $commands['startCommands'] !== null
            || $commands['endCommands'] !== null
            || $commands['firstStartCommands'] !== null;

        if ($hasCommands && $application === null) {
            return WidgetSubmitResultDTO::createError(422, 'Commands brauchen eine Application, in der sie ausgeführt werden.');
        }

        $users = $this->resolveUsers($data['userIds'] ?? null, $user);

        if ($users === null) {
            return WidgetSubmitResultDTO::createError(422, 'Mindestens ein ausgewählter Benutzer existiert nicht.');
        }

        if ($users === []) {
            return WidgetSubmitResultDTO::createError(422, 'Der Termin muss mindestens einem Benutzer zugewiesen sein.');
        }

        $isNew = $appointment->getId() === null;

        $appointment
            ->setTitle($title)
            ->setDescription($this->nullIfBlank((string)($data['description'] ?? '')))
            ->setStartDate($start)
            ->setEndDate($end)
            ->setReminderTimer($this->positiveIntOrNull($data['reminderTimer'] ?? null))
            ->setStartCommands($commands['startCommands'])
            ->setEndCommands($commands['endCommands'])
            ->setFirstStartCommands($commands['firstStartCommands'])
            ->setApplication($application);

        match (true) {
            $isWeekdays => $appointment->setRepeatType(eRepeatType::WEEKDAYS),
            $interval !== null => $appointment->setRepeatInterval($interval),
            default => $appointment->setRepeatType(eRepeatType::NONE),
        };

        foreach ($appointment->getUsers()->toArray() as $assignedUser) {
            if (!in_array($assignedUser, $users, true)) {
                $appointment->removeUser($assignedUser);
            }
        }

        foreach ($users as $assignedUser) {
            $appointment->addUser($assignedUser);
        }

        try {
            $this->appointmentRepository->save($appointment);
        } catch (\Throwable $exception) {
            return WidgetSubmitResultDTO::createError(500, 'Der Termin konnte nicht gespeichert werden.');
        }

        return WidgetSubmitResultDTO::createSuccess($isNew ? 'Termin gespeichert' : 'Termin aktualisiert', [
            'id' => $appointment->getId(),
            'date' => $start->format('Y-m-d'),
        ], $isNew ? 201 : 200);
    }

    private function parseDateTime(mixed $date, mixed $time): ?\DateTime
    {
        $date = trim((string)$date);

        if ($date === '') {
            return null;
        }

        $time = trim((string)$time);
        $time = $time === '' ? '00:00' : $time;

        $parsed = \DateTime::createFromFormat('Y-m-d H:i', $date . ' ' . substr($time, 0, 5));
        $errors = \DateTime::getLastErrors();

        if (
            $parsed === false
            || (($errors['warning_count'] ?? 0) > 0)
            || (($errors['error_count'] ?? 0) > 0)
        ) {
            return null;
        }

        return $parsed->setTime(
            (int)$parsed->format('H'),
            (int)$parsed->format('i'),
            0
        );
    }

    private function nullIfBlank(string $value): ?string
    {
        return trim($value) === '' ? null : trim($value);
    }

    private function positiveIntOrNull(mixed $value): ?int
    {
        return (int)$value > 0 ? (int)$value : null;
    }

    /**
     * A command field as it is stored: null when it was left empty, false when
     * it is not a JSON list of command definitions.
     */
    private function parseCommands(mixed $value): array|false|null
    {
        $value = trim((string)$value);

        if ($value === '') {
            return null;
        }

        $decoded = json_decode($value, true);

        return is_array($decoded) && $decoded !== [] && array_is_list($decoded) ? $decoded : false;
    }

    /**
     * The users an appointment is assigned to: the ones picked in the mask, or
     * the user the request acts for when nobody was picked.
     *
     * @param mixed $userIds A list of ids or a comma separated string of them
     *
     * @return User[]|null null when one of the picked users does not exist
     */
    private function resolveUsers(mixed $userIds, ?User $currentUser): ?array
    {
        $ids = is_array($userIds) ? $userIds : explode(',', (string)$userIds);
        $ids = array_values(array_unique(array_filter(
            array_map('intval', $ids),
            static fn(int $id): bool => $id > 0
        )));

        if ($ids === []) {
            return $currentUser === null ? [] : [$currentUser];
        }

        $users = $this->userRepository->findBy(['id' => $ids]);

        return count($users) === count($ids) ? $users : null;
    }

    /**
     * Removes the appointment the mask was opened with. A repeating
     * appointment is one entity, so this takes the whole series with it - which
     * is what the mask says before it asks.
     */
    private function deleteAppointment(array $data, ?User $user): WidgetSubmitResultDTO
    {
        $appointment = $this->findOwnAppointment($data, $user);

        if ($appointment instanceof WidgetSubmitResultDTO) {
            return $appointment;
        }

        $id = $appointment->getId();

        try {
            $this->appointmentRepository->remove($appointment);
        } catch (\Throwable $exception) {
            return WidgetSubmitResultDTO::createError(500, 'Der Termin konnte nicht gelöscht werden.');
        }

        return WidgetSubmitResultDTO::createSuccess('Termin gelöscht', ['id' => $id], 200);
    }
}
