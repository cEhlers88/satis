<?php

namespace Cehlers88\AnalyticsCalendarBundle\Calendar;

use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;

/**
 * Knows when an appointment happens: the occurrences a series puts into a
 * range, the occurrence that started last and where an occurrence ends.
 *
 * The calendar and the command worker both ask here, so a recurrence rule is
 * only ever interpreted in one place. An occurrence keeps the wall-clock times
 * of the appointment - it is the appointment moved by whole days.
 */
class OccurrenceResolver
{
    /** A series that never leaves the range must still not loop forever. */
    private const MAX_OCCURRENCES = 400;

    /**
     * The occurrences of an appointment that touch the range - a single one for
     * an appointment that does not repeat.
     *
     * @return \Generator<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    public function occurrencesBetween(
        Appointment        $appointment,
        \DateTimeImmutable $rangeStart,
        \DateTimeImmutable $rangeEnd
    ): \Generator {
        $start = $this->startOf($appointment);
        $end = $this->endOfSeriesStart($appointment);

        if ($appointment->getRepeatType() === eRepeatType::WEEKDAYS) {
            yield from $this->expandWeekdays($start, $end, $rangeStart, $rangeEnd);

            return;
        }

        if ($appointment->getRepeatType() === eRepeatType::INTERVAL) {
            yield from $this->expandInterval($start, $end, (int)$appointment->getRepeatInterval(), $rangeStart, $rangeEnd);

            return;
        }

        if (($end ?? $start) >= $rangeStart && $start <= $rangeEnd) {
            yield [$start, $end];
        }
    }

    /**
     * The start of the last occurrence that began at or before the moment, or
     * null while the appointment has not started yet.
     */
    public function latestStartAtOrBefore(Appointment $appointment, \DateTimeImmutable $moment): ?\DateTimeImmutable
    {
        $start = $this->startOf($appointment);

        if ($start > $moment) {
            return null;
        }

        $daysSinceStart = $this->daysBetween($start, $moment);

        if ($appointment->getRepeatType() === eRepeatType::INTERVAL) {
            $interval = (int)$appointment->getRepeatInterval();
            $offset = intdiv($daysSinceStart, $interval) * $interval;

            if ($this->shift($start, $offset) > $moment) {
                $offset -= $interval;
            }

            return $offset >= 0 ? $this->shift($start, $offset) : null;
        }

        if ($appointment->getRepeatType() === eRepeatType::WEEKDAYS) {
            // A weekend is never longer than two days, so a week back always
            // reaches the last weekday.
            for ($offset = $daysSinceStart; $offset >= max(0, $daysSinceStart - 7); $offset--) {
                $candidate = $this->shift($start, $offset);

                if ($candidate <= $moment && $this->isWeekday($candidate)) {
                    return $candidate;
                }
            }

            return null;
        }

        return $start;
    }

    /**
     * The moment the occurrence that starts at the given moment is over - null
     * for an appointment without an end.
     *
     * An all-day appointment is stored from midnight to midnight of its last
     * day, and the calendar shows it on that last day too - so it is only over
     * once that day has passed.
     */
    public function endOf(Appointment $appointment, \DateTimeInterface $occurrenceStart): ?\DateTimeImmutable
    {
        $start = $this->startOf($appointment);
        $end = $this->endOfSeriesStart($appointment);

        if ($end === null) {
            return null;
        }

        if ($start->format('H:i') === '00:00' && $end->format('H:i:s') === '00:00:00') {
            $end = $end->modify('+1 day');
        }

        $occurrenceStart = \DateTimeImmutable::createFromInterface($occurrenceStart);

        return $this->shift($end, $this->daysBetween($start, $occurrenceStart));
    }

    /**
     * @return \Generator<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    private function expandInterval(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        int                 $interval,
        \DateTimeImmutable  $rangeStart,
        \DateTimeImmutable  $rangeEnd
    ): \Generator {
        // Skipping straight to the first occurrence that can still be in the
        // range keeps a long-running series from being walked from its start.
        $daysBehind = $this->daysBetween($start, $rangeStart);
        $step = $daysBehind > 0 ? intdiv($daysBehind, $interval) : 0;

        for ($i = 0; $i < self::MAX_OCCURRENCES; $i++, $step++) {
            $offset = $step * $interval;
            $occurrenceStart = $this->shift($start, $offset);

            if ($occurrenceStart > $rangeEnd) {
                return;
            }

            $occurrenceEnd = $end === null ? null : $this->shift($end, $offset);

            if (($occurrenceEnd ?? $occurrenceStart) >= $rangeStart) {
                yield [$occurrenceStart, $occurrenceEnd];
            }
        }
    }

    /**
     * Every Monday to Friday from the start of the series on. The walk begins
     * as many days before the range as an occurrence lasts, so one that began
     * earlier and still runs into the range is not lost.
     *
     * @return \Generator<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    private function expandWeekdays(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        \DateTimeImmutable  $rangeStart,
        \DateTimeImmutable  $rangeEnd
    ): \Generator {
        $spanDays = $end === null ? 0 : max(0, $this->daysBetween($start, $end));
        $day = max($start->setTime(0, 0), $this->shift($rangeStart->setTime(0, 0), -$spanDays));

        for ($i = 0; $i < self::MAX_OCCURRENCES; $i++, $day = $day->modify('+1 day')) {
            if (!$this->isWeekday($day)) {
                continue;
            }

            $offset = $this->daysBetween($start, $day);
            $occurrenceStart = $this->shift($start, $offset);

            if ($occurrenceStart > $rangeEnd) {
                return;
            }

            $occurrenceEnd = $end === null ? null : $this->shift($end, $offset);

            if (($occurrenceEnd ?? $occurrenceStart) >= $rangeStart) {
                yield [$occurrenceStart, $occurrenceEnd];
            }
        }
    }

    private function startOf(Appointment $appointment): \DateTimeImmutable
    {
        return \DateTimeImmutable::createFromInterface($appointment->getStartDate());
    }

    private function endOfSeriesStart(Appointment $appointment): ?\DateTimeImmutable
    {
        return $appointment->getEndDate() === null
            ? null
            : \DateTimeImmutable::createFromInterface($appointment->getEndDate());
    }

    /** Whole calendar days from one date to the other, negative when going back. */
    private function daysBetween(\DateTimeImmutable $from, \DateTimeImmutable $to): int
    {
        $difference = $from->setTime(0, 0)->diff($to->setTime(0, 0));

        return $difference->invert ? -$difference->days : $difference->days;
    }

    private function shift(\DateTimeImmutable $moment, int $days): \DateTimeImmutable
    {
        return $moment->modify(sprintf('%+d days', $days));
    }

    private function isWeekday(\DateTimeImmutable $day): bool
    {
        return (int)$day->format('N') <= 5;
    }
}
