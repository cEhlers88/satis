<?php

namespace Cehlers88\AnalyticsCalendarBundle\Worker;

use Cehlers88\AnalyticsCalendarBundle\Calendar\OccurrenceResolver;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCore\Command\DTO\CommandGroupDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Factory\CommandFactory;
use Cehlers88\AnalyticsCore\Worker\AbstractWorker;

/**
 * Startet und beendet Termine: sobald ein Termin (oder eine seiner
 * Wiederholungen) beginnt, laufen seine Start-Commands - beim allerersten Start
 * vorher die First-Start-Commands - und sobald er endet, seine End-Commands.
 *
 * The occurrence that was started or ended is stored on the appointment before
 * its commands run, so no occurrence is handled twice: a command that fails is
 * reported as a warning, not retried on the next run.
 */
class AppointmentCommandWorker extends AbstractWorker
{
    private const TRIGGER_FIRST_START = 'first start';
    private const TRIGGER_START = 'start';
    private const TRIGGER_END = 'end';

    private \DateTimeImmutable $now;
    private int $ended = 0;

    public function __construct(
        private AppointmentRepository $appointmentRepository,
        private OccurrenceResolver    $occurrenceResolver,
        private CommandFactory        $commandFactory
    )
    {
        $this->now = new \DateTimeImmutable();
        $this->addProperty(PropertyDTO::create(
            'max_start_delay',
            -1,
            'int',
            true,
            'Max. Startverzögerung (Sekunden)',
            false,
            'Wie lange nach Beginn ein verpasster Start noch nachgeholt wird - bei einem Termin, der erst während er schon lief angelegt oder geändert wurde, ab diesem Zeitpunkt. -1 holt jeden Start nach, der noch nicht geendet hat.'
        ));
    }

    public function getWorkingObjects(): array
    {
        // One moment for the whole run, so an appointment is not judged against
        // a later clock than the query that found it.
        $this->now = new \DateTimeImmutable();

        return $this->appointmentRepository->findWithPendingCommands($this->now);
    }

    public function handleWorkingObjects(array $workingObjects): array
    {
        $started = 0;
        $this->ended = 0;

        /** @var Appointment $appointment */
        foreach ($workingObjects as $appointment) {
            // The running occurrence ends before the next one may start.
            $this->handleEnd($appointment);

            if ($this->handleStart($appointment)) {
                $started++;
            }
        }

        $this->addResultMessage(sprintf('%d appointment(s) started, %d ended.', $started, $this->ended));

        return [];
    }

    /**
     * Ends the running occurrence once it is over - or right away when the
     * next occurrence of the series is about to start, so start and end
     * commands always take turns, even in a series whose occurrences overlap.
     */
    private function handleEnd(Appointment $appointment, bool $beforeNextStart = false): bool
    {
        $occurrence = $appointment->getLastStartedOccurrence();

        if ($occurrence === null || $occurrence == $appointment->getLastEndedOccurrence()) {
            return false;
        }

        $end = $this->occurrenceResolver->endOf($appointment, $occurrence);

        if ($end === null || ($end > $this->now && !$beforeNextStart)) {
            return false;
        }

        $appointment->setLastEndedOccurrence($occurrence);
        $this->appointmentRepository->save($appointment);

        $this->runCommands($appointment, self::TRIGGER_END, $appointment->getEndCommands());
        $this->ended++;

        return true;
    }

    private function handleStart(Appointment $appointment): bool
    {
        $occurrence = $this->occurrenceResolver->latestStartAtOrBefore($appointment, $this->now);
        $lastStarted = $appointment->getLastStartedOccurrence();

        if ($occurrence === null || $this->wasStarted($appointment, $occurrence, $lastStarted)) {
            return false;
        }

        if ($this->isMissed($appointment, $occurrence)) {
            $this->logInfo(sprintf(
                'Appointment #%d: occurrence of %s was missed, its start is skipped.',
                $appointment->getId(),
                $occurrence->format('Y-m-d H:i')
            ), true);

            return false;
        }

        // A series whose occurrences overlap is still running the previous one.
        $this->handleEnd($appointment, true);

        $isFirstStart = $lastStarted === null;

        $appointment->setLastStartedOccurrence($occurrence);
        $this->appointmentRepository->save($appointment);

        if ($isFirstStart) {
            $this->runCommands($appointment, self::TRIGGER_FIRST_START, $appointment->getFirstStartCommands());
        }

        $this->runCommands($appointment, self::TRIGGER_START, $appointment->getStartCommands());

        return true;
    }

    /**
     * A series moves forward, so every occurrence up to the last started one is
     * done. A single appointment has just one occurrence - its start - and is
     * started again when it was moved to another time, earlier ones included.
     */
    private function wasStarted(Appointment $appointment, \DateTimeImmutable $occurrence, ?\DateTimeImmutable $lastStarted): bool
    {
        if ($lastStarted === null) {
            return false;
        }

        return $appointment->isRepeating() ? $occurrence <= $lastStarted : $occurrence == $lastStarted;
    }

    /**
     * An occurrence that is already over, or began longer ago than the worker
     * is allowed to catch up on, is not started any more.
     *
     * The delay counts from the moment the start could first have been run: an
     * appointment created (or moved) while it is already running - 9:00 to
     * 14:30, saved at 12:00 - did not miss its start, it is simply late, so
     * it starts now and ends at 14:30.
     */
    private function isMissed(Appointment $appointment, \DateTimeImmutable $occurrence): bool
    {
        $end = $this->occurrenceResolver->endOf($appointment, $occurrence);

        if ($end !== null && $end <= $this->now) {
            return true;
        }

        $maxStartDelay = $this->maxStartDelay();

        if ($maxStartDelay < 0) {
            return false;
        }

        $knownSince = $appointment->getUpdatedAt() ?? $appointment->getCreatedAt();
        $due = $knownSince !== null && $knownSince > $occurrence
            ? \DateTimeImmutable::createFromInterface($knownSince)
            : $occurrence;

        return $this->now->getTimestamp() - $due->getTimestamp() > $maxStartDelay;
    }

    /**
     * Values saved through the worker card are strings - an emptied field must
     * not turn into a delay of 0 seconds, which would skip nearly every start.
     */
    private function maxStartDelay(): int
    {
        $value = $this->getPropertyValue('max_start_delay', -1);

        return is_numeric($value) ? (int)$value : -1;
    }

    private function runCommands(Appointment $appointment, string $trigger, ?array $definition): void
    {
        if (empty($definition)) {
            return;
        }

        $commands = $this->commandFactory->evalDefinitionArray($definition, true);

        if (
            !$commands instanceof CommandGroupDTO
            || count($commands->commands) === 0
            || in_array(null, $commands->commands, true)
        ) {
            $this->logWarning(sprintf(
                'Appointment #%d: the %s commands are no valid command definition.',
                $appointment->getId(),
                $trigger
            ));

            return;
        }

        // Commands always run in an application - the one of the appointment,
        // not the one the worker happens to be registered for.
        $application = $appointment->getApplication();

        if ($application === null) {
            $this->logWarning(sprintf(
                'Appointment #%d: the %s commands need an application to run in.',
                $appointment->getId(),
                $trigger
            ));

            return;
        }

        $commandPlayer = $this->macroPlayer->getMacroEnvironment()->getCommandPlayer();
        $commandPlayer->setApplication($application);

        try {
            $commandPlayer->run($commands);
            $this->logInfo(sprintf(
                'Appointment #%d "%s": %s commands executed.',
                $appointment->getId(),
                $appointment->getTitle(),
                $trigger
            ));
        } catch (\Throwable $exception) {
            $this->logWarning(sprintf(
                'Appointment #%d: %s commands failed: %s',
                $appointment->getId(),
                $trigger,
                $exception->getMessage()
            ));
        }
    }
}
