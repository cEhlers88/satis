# Changelog

## [1.1.13](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.12...v1.1.13) (2026-08-14)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.11 ([#71](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/71)) ([209aef2](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/209aef272bd0e8882cef65573f5f5172d74888a6))

## [1.1.12](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.11...v1.1.12) (2026-08-11)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.10 ([#68](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/68)) ([5c455e5](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/5c455e52ba042c1b47163abcf586a3cd212a5699))

## [1.1.11](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.10...v1.1.11) (2026-07-18)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.7 ([#66](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/66)) ([54e4121](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/54e4121c40349b288efe6a799b58d3631237e0fa))

## [1.1.10](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.9...v1.1.10) (2026-07-12)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.3 ([#62](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/62)) ([1a6e4b6](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/1a6e4b6445e54a0203a6cff98a53f49ac611646a))
* **deps:** update dependency cehlers88/analytics-core to v1.39.4 ([#64](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/64)) ([4757955](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/4757955b5707c12d6ca161102cca84f2806ebc04))
* **deps:** update dependency cehlers88/analytics-core to v1.39.5 ([#65](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/65)) ([a8221e7](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/a8221e7604465bada659f1386f056b8c93eea259))

## [1.1.9](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.8...v1.1.9) (2026-06-21)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.1 ([#60](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/60)) ([4ea3273](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/4ea3273b146748868ac42ab47b1c676945c58cb8))
* Refactor imports to use AbstractMacro from AnalyticsCore ([fc55a2d](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/fc55a2d9f7acdcea5f2817548b941d3dc919d56c))
* Replaced imports of `MenuItemDTO` with the correct path `Cehlers88\AnalyticsCore\Support\DTO\UI\MenuItemDTO` in multiple bundles. This ensures consistency and resolves potential namespace issues. ([d70d2df](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/d70d2df6c0037a2e8cdf6944e5cfd2d654d02515))
* Update service configuration and adjust _source reference in AbstractCalendarMacro ([7b8551d](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/7b8551d67c2078e04d3f85b534eb2e4c3dd92167))

## [1.1.8](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.7...v1.1.8) (2026-06-14)


### Miscellaneous Chores

* bump `cehlers88/analytics-core` to v1.38.8 in composer.lock ([0372ce1](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/0372ce1769b2a8caecb07626658c76613700641f))

## [1.1.7](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.6...v1.1.7) (2026-06-14)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.38.7 ([#57](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/57)) ([8c3a015](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/8c3a015ea6829474e25cf2d33e9521857ab33fb9))
* Refactor GeneralConfigurationGroup and update service tags in AnalyticsCalendarBundle ([fcad0f9](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/fcad0f9c0c1efb01ab12222318655098651be91e))

## [1.1.6](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.5...v1.1.6) (2026-05-24)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.38.2 ([#55](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/55)) ([b84b8c2](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/b84b8c20e45dc9b77ba9ee4d5a6f2245f94e3d7e))

## [1.1.5](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.4...v1.1.5) (2026-05-16)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.34.0 ([#53](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/53)) ([a323fcf](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/a323fcfc3eafa94f560fd18b015832cfb01a6608))

## [1.1.4](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.3...v1.1.4) (2026-05-10)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.30.0 ([#51](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/51)) ([081352f](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/081352fbbcabf651b4e6ac7d99f2ea5f9152ffb4))

## [1.1.3](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.2...v1.1.3) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.2 ([#50](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/50)) ([df2892f](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/df2892f26b7461cf081de5b0a51263dcae1fb4d2))
* Update analytics-core dependency version to "1.*[@dev](https://github.com/dev)" in composer.json ([c8b9180](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/c8b91808b7d0fc85b4c1c3de34cb595cd7822a37))
* Update branch alias format in composer.json files ([f423e97](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/f423e97aeefd316e6416bb35a03e619d3d577457))

## [1.1.2](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.1...v1.1.2) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.24.0 ([#46](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/46)) ([07f21b2](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/07f21b21977b39cd629c27ca4a81392d2c99cf18))
* **deps:** update dependency cehlers88/analytics-core to v1.25.1 ([#48](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/48)) ([835cacf](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/835cacfebc6c667058cb8b47ae4929c5f9d627bb))

## [1.1.1](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.1.0...v1.1.1) (2026-05-02)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.21.0 ([#43](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/43)) ([064ae1b](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/064ae1b369e701694d7f9313e8254286fdeeb01e))
* **deps:** update dependency cehlers88/analytics-core to v1.22.1 ([#45](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/45)) ([36d224b](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/36d224bb899a4ef1e58bca144a6ec41542ab7d36))

## [1.1.0](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.13...v1.1.0) (2026-04-26)


### Features

* expose JS assets with webpack-encore integration guide ([#40](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/40)) ([72e8017](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/72e80177fd373635784e6f8e4da3fe0d4e8c9c7f))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.20.0 ([#38](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/38)) ([e8471b2](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/e8471b2654d68c732f1603981eccd4a3bf6a8636))
* **deps:** update googleapis/release-please-action action to v5 ([#42](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/42)) ([af7f129](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/af7f129846dddff7ac871c0b3128b1cb3de98bff))

## [1.0.13](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.12...v1.0.13) (2026-04-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.16.1 ([#35](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/35)) ([ee267ba](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/ee267ba2820d5e3ea15df44070efb31c0f1c6dcc))
* **deps:** update dependency cehlers88/analytics-core to v1.17.0 ([#37](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/37)) ([e4fb320](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/e4fb320e42714db3770d0cd4ea40e1ada0a4e568))
* Refactor AnalyticsCalendarBundle to follow PSR-12 coding standards and update AbstractBundlePlugin reference ([7c02561](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/7c025616e728318da1c380710fba29f7beade9a4))

## [1.0.12](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.11...v1.0.12) (2026-04-13)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.15.0 ([#32](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/32)) ([c0d69aa](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/c0d69aadafe512227d440005d0c24c910437e8e4))
* **deps:** update dependency cehlers88/analytics-core to v1.16.0 ([#34](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/34)) ([7320775](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/73207759e968fa0ef9a44b8f63eb95257fd1aaed))

## [1.0.11](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.10...v1.0.11) (2026-03-29)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.3.13 ([#28](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/28)) ([dc56450](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/dc564507d16e81516deb961b2c3e878312d9f309))
* **deps:** update dependency cehlers88/analytics-core to v1.4.1 ([#30](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/30)) ([d07556a](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/d07556ad3b56118f513e711df4523c016aaabc32))
* **deps:** update dependency cehlers88/analytics-core to v1.6.0 ([#31](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/31)) ([639fe54](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/639fe54f3a85acb9457cadc30fe7a96304fbaa15))

## [1.0.10](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.9...v1.0.10) (2026-03-24)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.3.6 ([#26](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/26)) ([b56fc6f](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/b56fc6f5df453b7b79306194cfd83b791efd2967))
* Upgraded the analytics-core package to v1.3.7 to include the latest changes and improvements. Updated the associated reference, distribution URL, and checksum to match the new version. ([56f3bf6](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/56f3bf690ca45d216705a576df8a1ececc0fcce7))

## [1.0.9](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.8...v1.0.9) (2026-03-23)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.1.3 ([#23](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/23)) ([e129075](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/e129075318b37559a7c8cc81bc9b3193775fbee8))
* **deps:** update dependency cehlers88/analytics-core to v1.3.5 ([#25](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/25)) ([a9f83e7](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/a9f83e7af6478e76afe0f21c4d28cf3aaf5b1338))

## [1.0.8](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.7...v1.0.8) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([838e7bb](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/838e7bbe8ebbc3177beddf524e5dfc753b1cc35f))

## [1.0.7](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.6...v1.0.7) (2026-03-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.5.4 ([#18](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/18)) ([ccf6e1c](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/ccf6e1c154890c0e8e30a1c928474aee77cdfd91))
* **deps:** update dependency cehlers88/analytics-core to v0.5.5 ([#20](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/20)) ([874cfa2](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/874cfa2d181a4b3099c9f9e0aa483ebf99454555))

## [1.0.6](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.5...v1.0.6) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.5 ([#17](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/17)) ([c882fcd](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/c882fcde8a9ecc411480e29fe58b51acc30ae6d6))
* **deps:** update dependency cehlers88/analytics-core to v0.4.2 ([#15](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/15)) ([cb7106d](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/cb7106db3bb54180b6de995c1eac7d8ab55d2c1b))

## [1.0.5](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.4...v1.0.5) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.4.1 ([#13](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/13)) ([11a20be](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/11a20beb2094bf40dc831eeafbf62caf78c280d8))

## [1.0.4](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.3...v1.0.4) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([3c3a4d8](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/3c3a4d8d17e5798e10d06455143de0de0b7872ad))

## [1.0.3](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.2...v1.0.3) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.1 ([#10](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/10)) ([adb7f91](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/adb7f9188042d5338c1d1ae732ab15a5f398b7dd))
* Update analytics-core dependency to use dev-main ([3c31914](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/3c319142447a589a3c11efae1560807c2a16e2e2))

## [1.0.2](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.1...v1.0.2) (2026-03-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.3 ([#7](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/7)) ([eac0b9a](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/eac0b9ae85fd05670c829996e77c2c4a3352dd47))
* **deps:** update dependency cehlers88/analytics-core to v0.2.1 ([#3](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/3)) ([6909f00](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/6909f0045d042b159b899a428e43796039009bc9))
* Update composer.json to align branch alias and dependency versioning ([e29b46b](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/e29b46b2895865727b1925a29f1e25481e4cc26b))

## [1.0.1](https://github.com/cEhlers88/AnalyticsCalendarBundle/compare/v1.0.0...v1.0.1) (2026-01-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.2.0@dev ([#4](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/4)) ([a6426ca](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/a6426ca8c32cc3c2070f0ec2fcc66899313ce00b))

## 1.0.0 (2026-01-21)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.7 ([#1](https://github.com/cEhlers88/AnalyticsCalendarBundle/issues/1)) ([3d226cf](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/3d226cfcbdd9df91e0f09d1ec7e15050bfafae57))
* Introduce AnalyticsCalendarBundle with core features and configuration. ([98a0247](https://github.com/cEhlers88/AnalyticsCalendarBundle/commit/98a0247560e3ad85204ebc803f6fc1d2327e8073))
