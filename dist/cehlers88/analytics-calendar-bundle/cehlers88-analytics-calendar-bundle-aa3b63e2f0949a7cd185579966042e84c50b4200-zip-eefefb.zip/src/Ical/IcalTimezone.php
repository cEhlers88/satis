<?php

namespace Cehlers88\AnalyticsCalendarBundle\Ical;

/**
 * Builds the VTIMEZONE component RFC 5545 requires next to every TZID.
 *
 * Only recurring appointments are written with a TZID: their occurrences keep
 * the wall-clock time across daylight saving changes, which a series anchored
 * in UTC would not. The definition is derived from the two transitions PHP's
 * timezone database knows for the year the series starts in, expressed as
 * yearly rules - the form Apple and every other client understand.
 */
final class IcalTimezone
{
    private const WEEKDAY_CODES = [1 => 'MO', 2 => 'TU', 3 => 'WE', 4 => 'TH', 5 => 'FR', 6 => 'SA', 7 => 'SU'];

    /**
     * @param int $year the year the earliest series starts in
     */
    public static function build(\DateTimeZone $timezone, int $year): IcalComponent
    {
        // The observances have to begin before the first occurrence, which may
        // lie before this year's first transition.
        --$year;

        $component = new IcalComponent('VTIMEZONE');
        $component->add('TZID', $timezone->getName());

        $yearStart = (new \DateTimeImmutable(sprintf('%04d-01-01 00:00:00', $year), new \DateTimeZone('UTC')))->getTimestamp();
        $yearEnd = (new \DateTimeImmutable(sprintf('%04d-12-31 23:59:59', $year), new \DateTimeZone('UTC')))->getTimestamp();

        // The first entry getTransitions() returns is the state at the start of
        // the range, not a transition, so it carries the offset before the first change.
        $transitions = $timezone->getTransitions($yearStart, $yearEnd) ?: [];
        $initial = array_shift($transitions);

        if (null === $initial) {
            $offset = $timezone->getOffset(new \DateTimeImmutable('@' . $yearStart));
            $initial = ['offset' => $offset, 'isdst' => false, 'abbr' => ''];
        }

        if (2 !== count($transitions)) {
            // No daylight saving (or an irregular year): one fixed offset.
            $standard = new IcalComponent('STANDARD');
            $standard->add('DTSTART', '19700101T000000');
            $standard->add('TZOFFSETFROM', self::formatOffset($initial['offset']));
            $standard->add('TZOFFSETTO', self::formatOffset($initial['offset']));
            self::addName($standard, $initial['abbr']);
            $component->addComponent($standard);

            return $component;
        }

        $previousOffset = $initial['offset'];

        foreach ($transitions as $transition) {
            $local = (new \DateTimeImmutable('@' . ($transition['ts'] + $previousOffset)));
            $isoWeekday = (int)$local->format('N');
            $day = (int)$local->format('j');
            $ordinal = $day + 7 > (int)$local->format('t') ? -1 : intdiv($day - 1, 7) + 1;

            $part = new IcalComponent($transition['isdst'] ? 'DAYLIGHT' : 'STANDARD');
            $part->add('DTSTART', $local->format('Ymd\THis'));
            $part->add('TZOFFSETFROM', self::formatOffset($previousOffset));
            $part->add('TZOFFSETTO', self::formatOffset($transition['offset']));
            $part->add('RRULE', sprintf(
                'FREQ=YEARLY;BYMONTH=%d;BYDAY=%d%s',
                (int)$local->format('n'),
                $ordinal,
                self::WEEKDAY_CODES[$isoWeekday]
            ));
            self::addName($part, $transition['abbr']);
            $component->addComponent($part);

            $previousOffset = $transition['offset'];
        }

        return $component;
    }

    public static function formatOffset(int $seconds): string
    {
        $sign = $seconds < 0 ? '-' : '+';
        $seconds = abs($seconds);

        return sprintf('%s%02d%02d', $sign, intdiv($seconds, 3600), intdiv($seconds % 3600, 60));
    }

    private static function addName(IcalComponent $component, string $abbreviation): void
    {
        // PHP reports zones without a name as "+03" and the like - not a name.
        if ('' !== $abbreviation && 1 !== preg_match('/^[+-]\d/', $abbreviation)) {
            $component->add('TZNAME', $abbreviation);
        }
    }
}
