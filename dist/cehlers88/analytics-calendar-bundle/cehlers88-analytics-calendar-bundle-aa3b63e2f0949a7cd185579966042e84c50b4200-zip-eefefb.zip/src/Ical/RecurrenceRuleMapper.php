<?php

namespace Cehlers88\AnalyticsCalendarBundle\Ical;

use Cehlers88\AnalyticsCalendarBundle\Calendar\OccurrenceResolver;
use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;

/**
 * Translates between RFC 5545 recurrence rules and the repeat fields the
 * application works with (repeatType, repeatInterval, repeatDays).
 *
 * The application knows fewer kinds of series than iCalendar, so a client rule
 * is mapped onto the closest repeat type while the rule itself is kept in
 * Appointment::$rrule. When the appointment is rendered again, that rule is
 * only used while it still maps onto the current repeat fields - as soon as the
 * series was changed inside the application, the rule is rebuilt from them.
 */
class RecurrenceRuleMapper
{
    private const WEEKDAY_CODES = [1 => 'MO', 2 => 'TU', 3 => 'WE', 4 => 'TH', 5 => 'FR', 6 => 'SA', 7 => 'SU'];

    public function __construct(private readonly OccurrenceResolver $occurrenceResolver = new OccurrenceResolver())
    {
    }

    /**
     * Stores a client rule on the appointment together with the repeat fields
     * it maps onto.
     */
    public function applyRule(Appointment $appointment, ?string $rrule): void
    {
        [$type, $interval, $days] = self::toRepeatFields($rrule);

        $appointment->setRrule($rrule);
        $appointment->setRepeatType($type);

        match ($type) {
            eRepeatType::INTERVAL => $appointment->setRepeatInterval($interval),
            eRepeatType::DAYS => $appointment->setRepeatDays($days),
            default => null,
        };
    }

    /**
     * The rule an appointment is rendered with: the stored client rule while it
     * still describes the current series, a rule built from the repeat fields
     * otherwise, and null for an appointment that does not repeat.
     */
    public function ruleFor(Appointment $appointment): ?string
    {
        $stored = $appointment->getRrule();

        if (null !== $stored && self::toRepeatFields($stored) === $this->currentRepeatFields($appointment)) {
            return $stored;
        }

        return $this->buildRule($appointment);
    }

    /**
     * Monthly rules, yearly rules with an interval or BYDAY, weekly rules with
     * an interval on several weekdays and anything with BYMONTH, BYSETPOS & co.
     * have no counterpart in the application; they map onto NONE, so the
     * application shows the first occurrence while the device, which reads the
     * stored rule, shows them all.
     * COUNT, UNTIL and WKST do not change which kind of series it is and are
     * ignored here.
     *
     * @return array{0: eRepeatType, 1: ?int, 2: int[]} type, interval in days and ISO weekdays
     */
    public static function toRepeatFields(?string $rrule): array
    {
        $none = [eRepeatType::NONE, null, []];

        if (null === $rrule || '' === trim($rrule)) {
            return $none;
        }

        $parts = [];
        foreach (explode(';', $rrule) as $segment) {
            $pair = explode('=', $segment, 2);

            if (2 === count($pair)) {
                $parts[strtoupper(trim($pair[0]))] = strtoupper(trim($pair[1]));
            }
        }

        $unsupported = array_diff(array_keys($parts), ['FREQ', 'INTERVAL', 'BYDAY', 'COUNT', 'UNTIL', 'WKST']);

        if ([] !== $unsupported) {
            return $none;
        }

        $interval = isset($parts['INTERVAL']) ? max(1, (int)$parts['INTERVAL']) : 1;
        $days = isset($parts['BYDAY']) ? self::parseWeekdays($parts['BYDAY']) : null;

        // A BYDAY that could not be read, e.g. one with an ordinal like "1MO".
        if ([] === $days) {
            return $none;
        }

        return match ($parts['FREQ'] ?? null) {
            'DAILY' => match (true) {
                null === $days => [eRepeatType::INTERVAL, $interval, []],
                1 === $interval => [eRepeatType::DAYS, null, $days],
                default => $none,
            },
            'WEEKLY' => match (true) {
                null === $days => [eRepeatType::INTERVAL, $interval * 7, []],
                1 === $interval => [eRepeatType::DAYS, null, $days],
                default => $none,
            },
            'YEARLY' => null === $days && 1 === $interval ? [eRepeatType::YEARLY, null, []] : $none,
            default => $none,
        };
    }

    /**
     * @return array{0: eRepeatType, 1: ?int, 2: int[]}
     */
    private function currentRepeatFields(Appointment $appointment): array
    {
        $type = $appointment->getRepeatType();

        return [
            $type,
            eRepeatType::INTERVAL === $type ? $appointment->getRepeatInterval() : null,
            eRepeatType::DAYS === $type ? $appointment->getRepeatDays() : [],
        ];
    }

    private function buildRule(Appointment $appointment): ?string
    {
        if (eRepeatType::YEARLY === $appointment->getRepeatType()) {
            return 'FREQ=YEARLY';
        }

        if (eRepeatType::INTERVAL === $appointment->getRepeatType()) {
            $days = (int)$appointment->getRepeatInterval();

            if (0 === $days % 7) {
                $weeks = intdiv($days, 7);

                return 1 === $weeks ? 'FREQ=WEEKLY' : 'FREQ=WEEKLY;INTERVAL=' . $weeks;
            }

            return 1 === $days ? 'FREQ=DAILY' : 'FREQ=DAILY;INTERVAL=' . $days;
        }

        // WEEKDAYS and WEEKEND are resolved against the configured work week
        // here, so the device sees the days the application expands them to.
        $weekdays = $this->occurrenceResolver->repeatDaysOf($appointment);

        if (null === $weekdays || [] === $weekdays) {
            return null;
        }

        sort($weekdays);

        return 'FREQ=WEEKLY;BYDAY=' . implode(',', array_map(
            static fn(int $day): string => self::WEEKDAY_CODES[$day],
            $weekdays
        ));
    }

    /**
     * @return int[] ISO weekdays, sorted - empty when the list holds anything
     *               but plain weekday codes
     */
    private static function parseWeekdays(string $byDay): array
    {
        $codes = array_flip(self::WEEKDAY_CODES);
        $days = [];

        foreach (explode(',', $byDay) as $code) {
            $code = trim($code);

            if (!isset($codes[$code])) {
                return [];
            }

            $days[] = $codes[$code];
        }

        $days = array_values(array_unique($days));
        sort($days);

        return $days;
    }
}
