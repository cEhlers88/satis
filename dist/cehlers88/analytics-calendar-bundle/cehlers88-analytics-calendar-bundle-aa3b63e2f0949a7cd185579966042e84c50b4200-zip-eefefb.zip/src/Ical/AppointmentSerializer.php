<?php

namespace Cehlers88\AnalyticsCalendarBundle\Ical;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;

/**
 * Renders appointments as iCalendar objects.
 *
 * Single timed appointments are written in UTC. That is the one representation
 * every client reads without needing an accompanying VTIMEZONE definition, and
 * the stored value is unambiguous because Doctrine hands back the appointment
 * in the timezone PHP is configured with.
 *
 * Recurring timed appointments are the exception: the application repeats them
 * at the same wall-clock time, so they are written in the server timezone with
 * a VTIMEZONE - anchored in UTC, every occurrence on the other side of a
 * daylight saving change would be off by an hour on the device.
 */
class AppointmentSerializer
{
    public const PRODUCT_ID = '-//C-Ehlers//AnalyticsCalendarBundle//DE';

    public function __construct(
        private readonly IcalWriter           $writer = new IcalWriter(),
        private readonly RecurrenceRuleMapper $recurrenceRuleMapper = new RecurrenceRuleMapper(),
    ) {
    }

    /**
     * A complete VCALENDAR containing a single appointment – the representation
     * a CalDAV client fetches for one calendar object resource.
     */
    public function render(Appointment $appointment): string
    {
        return $this->writer->write($this->buildCalendar([$appointment]));
    }

    /**
     * A complete VCALENDAR containing every given appointment – used by the
     * read-only subscription feed and by GET on a whole collection.
     *
     * @param iterable<Appointment> $appointments
     */
    public function renderCollection(iterable $appointments, ?string $name = null, ?int $refreshIntervalSeconds = null): string
    {
        $calendar = $this->buildCalendar($appointments);

        if (null !== $name) {
            $calendar->add('X-WR-CALNAME', IcalProperty::escapeText($name));
        }

        if (null !== $refreshIntervalSeconds) {
            $duration = IcalDuration::fromSeconds($refreshIntervalSeconds);
            // REFRESH-INTERVAL is the standardised property (RFC 7986); the
            // X- variant is what older Apple clients look at.
            $calendar->add('REFRESH-INTERVAL', $duration, ['VALUE' => 'DURATION']);
            $calendar->add('X-PUBLISHED-TTL', $duration);
        }

        return $this->writer->write($calendar);
    }

    /**
     * The VEVENT of a single appointment, without the surrounding VCALENDAR.
     */
    public function buildEvent(Appointment $appointment): IcalComponent
    {
        $event = new IcalComponent('VEVENT');
        $event->add('UID', $appointment->getUid() ?? $this->generateUid());
        $event->add('DTSTAMP', $this->formatUtc($appointment->getUpdatedAt() ?? $appointment->getCreatedAt() ?? new \DateTime()));

        $rrule = $this->recurrenceRuleMapper->ruleFor($appointment);
        $timezone = null !== $rrule ? $this->localTimezoneFor($appointment) : null;

        $start = $appointment->getStartDate();
        if (null !== $start) {
            $this->addDateProperty($event, 'DTSTART', $start, $appointment->isAllDay(), $timezone);
        }

        $end = $appointment->getEndDate();
        if (null !== $end) {
            $this->addDateProperty($event, 'DTEND', $end, $appointment->isAllDay(), $timezone);
        }

        $event->add('SUMMARY', IcalProperty::escapeText((string)$appointment->getTitle()));

        if (null !== $appointment->getDescription() && '' !== $appointment->getDescription()) {
            $event->add('DESCRIPTION', IcalProperty::escapeText($appointment->getDescription()));
        }

        if (null !== $appointment->getLocation() && '' !== $appointment->getLocation()) {
            $event->add('LOCATION', IcalProperty::escapeText($appointment->getLocation()));
        }

        if (null !== $rrule) {
            $event->add('RRULE', $rrule);
        }

        $event->add('SEQUENCE', (string)$appointment->getSequence());

        if (null !== $appointment->getCreatedAt()) {
            $event->add('CREATED', $this->formatUtc($appointment->getCreatedAt()));
        }

        if (null !== $appointment->getUpdatedAt()) {
            $event->add('LAST-MODIFIED', $this->formatUtc($appointment->getUpdatedAt()));
        }

        $reminder = $appointment->getReminderTimer();
        if (null !== $reminder && $reminder > 0) {
            $alarm = new IcalComponent('VALARM');
            $alarm->add('ACTION', 'DISPLAY');
            $alarm->add('DESCRIPTION', IcalProperty::escapeText((string)$appointment->getTitle()));
            $alarm->add('TRIGGER', IcalDuration::fromSeconds(-$reminder));
            $event->addComponent($alarm);
        }

        return $event;
    }

    public function generateUid(): string
    {
        return sprintf(
            '%s-%s@analytics-calendar',
            bin2hex(random_bytes(8)),
            bin2hex(random_bytes(4)),
        );
    }

    /**
     * @param iterable<Appointment> $appointments
     */
    private function buildCalendar(iterable $appointments): IcalComponent
    {
        $calendar = new IcalComponent('VCALENDAR');
        $calendar->add('VERSION', '2.0');
        $calendar->add('PRODID', self::PRODUCT_ID);
        $calendar->add('CALSCALE', 'GREGORIAN');

        $events = [];
        $firstLocalYear = null;

        foreach ($appointments as $appointment) {
            $events[] = $this->buildEvent($appointment);

            if (null !== $this->recurrenceRuleMapper->ruleFor($appointment)
                && null !== $this->localTimezoneFor($appointment)
                && null !== $appointment->getStartDate()
            ) {
                $year = (int)$appointment->getStartDate()->format('Y');
                $firstLocalYear = null === $firstLocalYear ? $year : min($firstLocalYear, $year);
            }
        }

        if (null !== $firstLocalYear) {
            $calendar->addComponent(IcalTimezone::build(new \DateTimeZone(date_default_timezone_get()), $firstLocalYear));
        }

        foreach ($events as $event) {
            $calendar->addComponent($event);
        }

        return $calendar;
    }

    private function addDateProperty(IcalComponent $event, string $name, \DateTimeInterface $value, bool $allDay, ?\DateTimeZone $timezone = null): void
    {
        if ($allDay) {
            $event->add($name, $value->format('Ymd'), ['VALUE' => 'DATE']);

            return;
        }

        if (null !== $timezone) {
            $local = \DateTimeImmutable::createFromInterface($value)->setTimezone($timezone);
            $event->add($name, $local->format('Ymd\THis'), ['TZID' => $timezone->getName()]);

            return;
        }

        $event->add($name, $this->formatUtc($value));
    }

    /**
     * The timezone a recurring timed appointment is written in - none for an
     * all-day one, and none when the server runs on UTC anyway.
     */
    private function localTimezoneFor(Appointment $appointment): ?\DateTimeZone
    {
        if ($appointment->isAllDay()) {
            return null;
        }

        $timezone = new \DateTimeZone(date_default_timezone_get());

        return 'UTC' === $timezone->getName() ? null : $timezone;
    }

    private function formatUtc(\DateTimeInterface $value): string
    {
        return (\DateTimeImmutable::createFromInterface($value))
            ->setTimezone(new \DateTimeZone('UTC'))
            ->format('Ymd\THis\Z');
    }
}
