<?php

namespace Cehlers88\AnalyticsCalendarBundle\Calendar;

use Cehlers88\AnalyticsCalendarBundle\Configuration\GeneralConfigurationGroup;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\Entity\Category;
use Cehlers88\AnalyticsCore\Repository\CategoryGroupRepository;
use Symfony\Contracts\Service\ResetInterface;

/**
 * Which categories mean vacation: those of the category group the setting
 * "Kategorie-Gruppe für Urlaub" names (GeneralConfigurationGroup::KEY_VACATION_CATEGORY_GROUP).
 * An appointment with one of them is a vacation.
 *
 * Without the setting, or with a group that no longer exists, nothing is a
 * vacation. The ids are read once per request; reset() drops them between
 * the requests of a long-running worker, so a changed setting shows at once.
 */
class VacationCategories implements ResetInterface
{
    /** @var list<int>|null */
    private ?array $categoryIds = null;

    public function __construct(
        private ?ConfigurationProvider   $configurationProvider = null,
        private ?CategoryGroupRepository $categoryGroupRepository = null,
    ) {
    }

    /**
     * @return list<int> the ids of the categories that mean vacation
     */
    public function categoryIds(): array
    {
        return $this->categoryIds ??= $this->readCategoryIds();
    }

    public function reset(): void
    {
        $this->categoryIds = null;
    }

    public function isVacationCategory(Category $category): bool
    {
        return in_array((int)$category->getId(), $this->categoryIds(), true);
    }

    public function isVacation(Appointment $appointment): bool
    {
        if ($this->categoryIds() === []) {
            return false;
        }

        foreach ($appointment->getCategories() as $category) {
            if ($this->isVacationCategory($category)) {
                return true;
            }
        }

        return false;
    }

    /** @return list<int> */
    private function readCategoryIds(): array
    {
        if ($this->configurationProvider === null || $this->categoryGroupRepository === null) {
            return [];
        }

        try {
            $groupId = $this->configurationProvider->getValue(
                GeneralConfigurationGroup::KEY,
                GeneralConfigurationGroup::KEY_VACATION_CATEGORY_GROUP,
                -1,
                null
            );
            $group = is_numeric($groupId) && (int)$groupId > 0 ? $this->categoryGroupRepository->find((int)$groupId) : null;
        } catch (\Throwable) {
            return [];
        }

        if ($group === null) {
            return [];
        }

        return array_values(array_map(
            static fn(Category $category): int => (int)$category->getId(),
            $group->getCategories()->toArray()
        ));
    }
}
