<?php

namespace Cehlers88\AnalyticsCalendarBundle\Macro;

use Cehlers88\AnalyticsCalendarBundle\Calendar\OccurrenceResolver;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\UserRepository;

/**
 * The appointments that are active at some moment of a range - one entry per occurrence, so a
 * series that is active more than once in the range is listed more than once.
 *
 * The range is rangeStart … rangeStop; without rangeStop it is the moment rangeStart alone.
 * A filter that is not given (-1, null or empty) is ignored - without rangeStart that is the
 * range, and every appointment is listed with the dates of its series.
 */
class GetAppointmentsMacro extends AbstractCalendarMacro
{
    private const PROPERTY_USER = 'user';
    private const PROPERTY_APPLICATION = 'application';
    private const PROPERTY_RANGE_START = 'rangeStart';
    private const PROPERTY_RANGE_STOP = 'rangeStop';
    private const PROPERTY_LIMIT = 'limit';

    /** What a filter that is not given holds. */
    private const NOT_GIVEN = -1;

    public function __construct(
        private readonly AppointmentRepository $appointmentRepository,
        private readonly OccurrenceResolver    $occurrenceResolver,
        private readonly UserRepository        $userRepository,
        private readonly ApplicationRepository $applicationRepository,
    )
    {
    }

    public function _init(): GetAppointmentsMacro
    {
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_USER, ['mixed'], 'Only appointments of this user - id or e-mail address; -1: every user', self::NOT_GIVEN))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_APPLICATION, ['mixed'], 'Only appointments of this application - id or name; -1: every application', self::NOT_GIVEN))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_RANGE_START, ['string'], 'The first moment the appointment may be active at (e.g. "now", "2026-10-18 08:00", "today"); empty: no range', 'now'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_RANGE_STOP, ['string'], 'The last moment of the range; empty: only the moment rangeStart', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_LIMIT, ['int'], 'At most this many appointments, the earliest first; 0 or less: all', 100));
        return $this;
    }

    public function getDescription(): string
    {
        return 'Get the appointments that are active at a moment or at some moment of a range - optionally of one user or application.';
    }

    public function getName(): string
    {
        return 'getAppointments';
    }

    protected function run(): ?array
    {
        try {
            $user = $this->user($this->getPropertyValue(self::PROPERTY_USER));
            $application = $this->application($this->getPropertyValue(self::PROPERTY_APPLICATION));
            $from = self::moment($this->getPropertyValue(self::PROPERTY_RANGE_START), self::PROPERTY_RANGE_START);
            $to = $from === null ? null : self::moment($this->getPropertyValue(self::PROPERTY_RANGE_STOP), self::PROPERTY_RANGE_STOP);
        } catch (\InvalidArgumentException $exception) {
            return $this->_createRunResult([], ErrorDTO::create(422, $exception->getMessage()));
        }
        if ($from !== null && $to !== null && $to < $from) {
            [$from, $to] = [$to, $from];
        }

        $candidates = $this->appointmentRepository->findCandidates(
            $user,
            $application,
            // a day earlier: an all-day appointment is active until its last day is over
            $from?->modify('-1 day'),
            $to ?? $from
        );

        $appointments = [];
        foreach ($candidates as $appointment) {
            $occurrences = $from === null
                ? [[self::immutable($appointment->getStartDate()), self::immutable($appointment->getEndDate())]]
                : $this->occurrenceResolver->activeOccurrencesIn($appointment, $from, $to);

            foreach ($occurrences as [$start, $end]) {
                $appointments[] = self::describe($appointment, $start, $end);
            }
        }

        usort($appointments, static fn(array $a, array $b): int => [$a['start'], $a['id']] <=> [$b['start'], $b['id']]);

        $limit = (int)$this->getPropertyValue(self::PROPERTY_LIMIT);
        if ($limit > 0) {
            $appointments = array_slice($appointments, 0, $limit);
        }

        return $this->_createRunResult($appointments);
    }

    /**
     * One occurrence of an appointment as the macro returns it - the dates in ISO 8601, so
     * they sort and compare as text.
     *
     * @return array<string, mixed>
     */
    public static function describe(Appointment $appointment, \DateTimeImmutable $start, ?\DateTimeImmutable $end): array
    {
        return [
            'id' => $appointment->getId(),
            'title' => $appointment->getTitle(),
            'description' => $appointment->getDescription(),
            'location' => $appointment->getLocation(),
            'start' => $start->format(\DateTimeInterface::ATOM),
            'end' => $end?->format(\DateTimeInterface::ATOM),
            'allDay' => $appointment->isAllDay(),
            'repeating' => $appointment->isRepeating(),
            'applicationId' => $appointment->getApplication()?->getId(),
            'calendarId' => $appointment->getCalendar()?->getId(),
            'categories' => array_values(array_map(
                static fn($category): string => (string)$category->getName(),
                $appointment->getCategories()->toArray()
            )),
            'users' => array_values(array_map(
                static fn(User $user): ?int => $user->getId(),
                $appointment->getUsers()->toArray()
            )),
        ];
    }

    /**
     * A moment of the range: a date the way PHP reads it ("now", "today 08:00", "+2 days",
     * "2026-10-18 08:00"), a timestamp or a date a command produced. Null when not given.
     */
    public static function moment(mixed $value, string $property): ?\DateTimeImmutable
    {
        if ($value instanceof \DateTimeInterface) {
            return \DateTimeImmutable::createFromInterface($value);
        }
        if (self::isNotGiven($value)) {
            return null;
        }
        if (is_int($value) || (is_string($value) && preg_match('/^\d{9,}$/', $value) === 1)) {
            return (new \DateTimeImmutable())->setTimestamp((int)$value);
        }
        if (is_string($value)) {
            try {
                return new \DateTimeImmutable($value);
            } catch (\Exception) {
                // below
            }
        }

        throw new \InvalidArgumentException(sprintf('%s: "%s" is no date.', $property, is_scalar($value) ? $value : get_debug_type($value)));
    }

    public static function isNotGiven(mixed $value): bool
    {
        return $value === null
            || $value === self::NOT_GIVEN
            || (is_string($value) && (trim($value) === '' || trim($value) === (string)self::NOT_GIVEN));
    }

    private function user(mixed $value): ?User
    {
        if ($value instanceof User || self::isNotGiven($value)) {
            return $value instanceof User ? $value : null;
        }
        $user = is_numeric($value)
            ? $this->userRepository->find((int)$value)
            : $this->userRepository->findOneBy(['email' => trim((string)$value)]);

        if (!$user instanceof User) {
            throw new \InvalidArgumentException(sprintf('user: there is no user "%s".', is_scalar($value) ? $value : get_debug_type($value)));
        }

        return $user;
    }

    private function application(mixed $value): ?Application
    {
        if ($value instanceof Application || self::isNotGiven($value)) {
            return $value instanceof Application ? $value : null;
        }
        $application = is_numeric($value)
            ? $this->applicationRepository->find((int)$value)
            : $this->applicationRepository->findOneBy(['name' => trim((string)$value)]);

        if (!$application instanceof Application) {
            throw new \InvalidArgumentException(sprintf('application: there is no application "%s".', is_scalar($value) ? $value : get_debug_type($value)));
        }

        return $application;
    }

    private static function immutable(?\DateTimeInterface $moment): ?\DateTimeImmutable
    {
        return $moment === null ? null : \DateTimeImmutable::createFromInterface($moment);
    }
}
