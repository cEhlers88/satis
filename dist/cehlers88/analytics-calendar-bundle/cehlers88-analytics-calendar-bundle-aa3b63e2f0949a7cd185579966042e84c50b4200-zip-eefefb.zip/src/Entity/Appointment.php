<?php

namespace Cehlers88\AnalyticsCalendarBundle\Entity;

use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\Category;
use Cehlers88\AnalyticsCore\Entity\User;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: AppointmentRepository::class)]
#[ORM\Table(name: 'calendar_appointment')]
#[ORM\UniqueConstraint(name: 'UNIQ_APPOINTMENT_CALENDAR_URI', columns: ['calendar_id', 'uri'])]
#[ORM\Index(name: 'IDX_APPOINTMENT_UID', columns: ['uid'])]
#[ORM\Index(name: 'IDX_APPOINTMENT_SYNC', columns: ['calendar_id', 'sync_revision'])]
class Appointment
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $startDate = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $endDate = null;

    /** Days between two occurrences - only read for eRepeatType::INTERVAL. */
    #[ORM\Column(nullable: true)]
    private ?int $repeatInterval = null;

    /**
     * Nullable so rows from before the column existed stay readable - they are
     * an interval or nothing, which getRepeatType() derives from repeatInterval.
     */
    #[ORM\Column(nullable: true)]
    private ?eRepeatType $repeatType = null;

    /**
     * ISO weekdays (1 = Monday … 7 = Sunday) the series falls on - only read
     * for eRepeatType::DAYS.
     */
    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $repeatDays = null;

    #[ORM\Column(nullable: true)]
    private ?int $reminderTimer = null;

    #[ORM\Column(length: 255)]
    private ?string $title = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    #[ORM\ManyToOne(targetEntity: Calendar::class, inversedBy: 'appointments')]
    #[ORM\JoinColumn(nullable: true, onDelete: 'CASCADE')]
    private ?Calendar $calendar = null;

    /**
     * Globally unique iCalendar identifier (RFC 5545 "UID"). It is generated
     * locally for appointments created inside the application and taken over
     * unchanged for appointments pushed by a CalDAV client.
     */
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $uid = null;

    /**
     * File name of the object inside its CalDAV collection, e.g.
     * "3F2504E0-4F89-11D3-9A0C-0305E82C3301.ics".
     */
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $uri = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $location = null;

    #[ORM\Column(options: ['default' => false])]
    private bool $allDay = false;

    /**
     * Raw RFC 5545 recurrence rule, e.g. "FREQ=WEEKLY;BYDAY=MO,WE".
     * `repeatInterval` stays in place as the simplified representation used by
     * the older parts of the bundle.
     */
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $rrule = null;

    /**
     * Olson timezone identifier the client used for this appointment.
     */
    #[ORM\Column(length: 64, nullable: true)]
    private ?string $timezone = null;

    #[ORM\Column(options: ['default' => 0])]
    private int $sequence = 0;

    /**
     * Verbatim iCalendar object as delivered by the client. Keeping it allows
     * lossless round-trips of properties this bundle does not map onto its own
     * columns (attendees, attachments, custom X- properties, ...).
     */
    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $icalData = null;

    #[ORM\Column(length: 64, nullable: true)]
    private ?string $etag = null;

    /**
     * Value of the owning calendar's sync token at the time of the last change.
     */
    #[ORM\Column(options: ['default' => 0])]
    private int $syncRevision = 0;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $createdAt = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $updatedAt = null;

    /** Command definitions run whenever an occurrence starts. */
    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $startCommands = null;

    /** Command definitions run whenever an occurrence ends. */
    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $endCommands = null;

    /** Command definitions run only when the very first occurrence starts. */
    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $firstStartCommands = null;

    /**
     * Optional condition group - `["&&", [["==", [["get_var", {…}], "on"]]]]` -
     * that has to hold before the worker starts an occurrence. Its commands run
     * in the application of the appointment; until it holds, the occurrence
     * stays not started and the worker asks again on its next run.
     */
    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $startCondition = null;

    /**
     * The application the commands run in - required as soon as there are
     * commands. Deleting the application leaves the appointment without one.
     */
    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?Application $application = null;

    /** The start of the occurrence the worker started last. */
    #[ORM\Column(type: Types::DATETIME_IMMUTABLE, nullable: true)]
    private ?\DateTimeImmutable $lastStartedOccurrence = null;

    /** The start of the occurrence the worker ended last. */
    #[ORM\Column(type: Types::DATETIME_IMMUTABLE, nullable: true)]
    private ?\DateTimeImmutable $lastEndedOccurrence = null;

    /**
     * When the worker started the appointment for the very first time - kept
     * apart from lastStartedOccurrence, so an appointment set back to "not
     * started" does not run its first-start commands again. Rows from before
     * the column only have lastStartedOccurrence, see hasFirstStarted().
     */
    #[ORM\Column(type: Types::DATETIME_IMMUTABLE, nullable: true)]
    private ?\DateTimeImmutable $firstStartedAt = null;

    /**
     * @var Collection<int, User>
     */
    #[ORM\ManyToMany(targetEntity: User::class)]
    #[ORM\JoinTable(name: 'calendar_appointment_user')]
    private Collection $users;

    /**
     * Optional categories - a category of the group configured as vacation
     * (VacationCategories) makes the appointment a vacation.
     *
     * @var Collection<int, Category>
     */
    #[ORM\ManyToMany(targetEntity: Category::class)]
    #[ORM\JoinTable(name: 'calendar_appointment_category')]
    #[ORM\JoinColumn(onDelete: 'CASCADE')]
    #[ORM\InverseJoinColumn(onDelete: 'CASCADE')]
    private Collection $categories;

    public function __construct()
    {
        $this->users = new ArrayCollection();
        $this->categories = new ArrayCollection();
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getStartDate(): ?\DateTimeInterface
    {
        return $this->startDate;
    }

    public function setStartDate(\DateTimeInterface $startDate): static
    {
        $this->startDate = $startDate;

        return $this;
    }

    public function getEndDate(): ?\DateTimeInterface
    {
        return $this->endDate;
    }

    public function setEndDate(?\DateTimeInterface $endDate): static
    {
        $this->endDate = $endDate;

        return $this;
    }

    public function getRepeatInterval(): ?int
    {
        return $this->repeatInterval;
    }

    /**
     * A positive interval makes the appointment an interval series, removing
     * the interval ends one.
     */
    public function setRepeatInterval(?int $repeatInterval): static
    {
        $this->repeatInterval = $repeatInterval;

        if ((int)$repeatInterval > 0) {
            $this->repeatType = eRepeatType::INTERVAL;
            $this->repeatDays = null;
        } elseif ($this->repeatType === eRepeatType::INTERVAL) {
            $this->repeatType = eRepeatType::NONE;
        }

        return $this;
    }

    public function getRepeatType(): eRepeatType
    {
        if (in_array($this->repeatType, eRepeatType::seriesWithoutInterval(), true)) {
            return $this->repeatType;
        }

        return (int)$this->repeatInterval > 0 ? eRepeatType::INTERVAL : eRepeatType::NONE;
    }

    /**
     * Every type but an interval has no use for a day count, every type but a
     * day selection none for weekdays, so they are dropped.
     */
    public function setRepeatType(eRepeatType $repeatType): static
    {
        $this->repeatType = $repeatType;

        if ($repeatType !== eRepeatType::INTERVAL) {
            $this->repeatInterval = null;
        }

        if ($repeatType !== eRepeatType::DAYS) {
            $this->repeatDays = null;
        }

        return $this;
    }

    /**
     * @return int[] the ISO weekdays of a day selection, sorted - empty for
     *               every other type
     */
    public function getRepeatDays(): array
    {
        return self::normalizeDays($this->repeatDays ?? []);
    }

    /**
     * @param int[]|null $repeatDays ISO weekdays; anything outside 1 … 7 is dropped
     */
    public function setRepeatDays(?array $repeatDays): static
    {
        $days = self::normalizeDays($repeatDays ?? []);
        $this->repeatDays = $days === [] ? null : $days;

        return $this;
    }

    /**
     * @return int[]
     */
    private static function normalizeDays(array $days): array
    {
        $days = array_values(array_unique(array_filter(
            array_map('intval', $days),
            static fn(int $day): bool => $day >= 1 && $day <= 7
        )));
        sort($days);

        return $days;
    }

    public function isRepeating(): bool
    {
        return $this->getRepeatType() !== eRepeatType::NONE;
    }

    public function getReminderTimer(): ?int
    {
        return $this->reminderTimer;
    }

    public function setReminderTimer(?int $reminderTimer): static
    {
        $this->reminderTimer = $reminderTimer;

        return $this;
    }

    public function getTitle(): ?string
    {
        return $this->title;
    }

    public function setTitle(string $title): static
    {
        $this->title = $title;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getCalendar(): ?Calendar
    {
        return $this->calendar;
    }

    public function setCalendar(?Calendar $calendar): static
    {
        $this->calendar = $calendar;

        return $this;
    }

    public function getStartCommands(): ?array
    {
        return $this->startCommands;
    }

    public function setStartCommands(?array $startCommands): static
    {
        $this->startCommands = $startCommands ?: null;

        return $this;
    }

    public function getUid(): ?string
    {
        return $this->uid;
    }

    public function setUid(?string $uid): static
    {
        $this->uid = $uid;

        return $this;
    }

    public function getEndCommands(): ?array
    {
        return $this->endCommands;
    }

    public function setEndCommands(?array $endCommands): static
    {
        $this->endCommands = $endCommands ?: null;

        return $this;
    }

    public function getUri(): ?string
    {
        return $this->uri;
    }

    public function setUri(?string $uri): static
    {
        $this->uri = $uri;

        return $this;
    }

    public function getFirstStartCommands(): ?array
    {
        return $this->firstStartCommands;
    }

    public function setFirstStartCommands(?array $firstStartCommands): static
    {
        $this->firstStartCommands = $firstStartCommands ?: null;

        return $this;
    }

    public function getStartCondition(): ?array
    {
        return $this->startCondition;
    }

    public function setStartCondition(?array $startCondition): static
    {
        $this->startCondition = $startCondition ?: null;

        return $this;
    }

    public function hasStartCondition(): bool
    {
        return $this->startCondition !== null;
    }

    public function getLocation(): ?string
    {
        return $this->location;
    }

    public function setLocation(?string $location): static
    {
        $this->location = $location;

        return $this;
    }

    public function getApplication(): ?Application
    {
        return $this->application;
    }

    public function setApplication(?Application $application): static
    {
        $this->application = $application;

        return $this;
    }

    public function isAllDay(): bool
    {
        return $this->allDay;
    }

    public function setAllDay(bool $allDay): static
    {
        $this->allDay = $allDay;

        return $this;
    }

    public function hasCommands(): bool
    {
        return $this->startCommands !== null
            || $this->endCommands !== null
            || $this->firstStartCommands !== null;
    }

    public function getLastStartedOccurrence(): ?\DateTimeImmutable
    {
        return $this->lastStartedOccurrence;
    }

    public function setLastStartedOccurrence(?\DateTimeImmutable $lastStartedOccurrence): static
    {
        $this->lastStartedOccurrence = $lastStartedOccurrence;

        return $this;
    }

    public function getRrule(): ?string
    {
        return $this->rrule;
    }

    public function setRrule(?string $rrule): static
    {
        $this->rrule = $rrule;

        return $this;
    }

    public function getLastEndedOccurrence(): ?\DateTimeImmutable
    {
        return $this->lastEndedOccurrence;
    }

    public function setLastEndedOccurrence(?\DateTimeImmutable $lastEndedOccurrence): static
    {
        $this->lastEndedOccurrence = $lastEndedOccurrence;

        return $this;
    }

    public function getFirstStartedAt(): ?\DateTimeImmutable
    {
        return $this->firstStartedAt;
    }

    public function setFirstStartedAt(?\DateTimeImmutable $firstStartedAt): static
    {
        $this->firstStartedAt = $firstStartedAt;

        return $this;
    }

    public function hasFirstStarted(): bool
    {
        return $this->firstStartedAt !== null || $this->lastStartedOccurrence !== null;
    }

    /**
     * Started by the worker and not ended yet.
     */
    public function isActive(): bool
    {
        return $this->lastStartedOccurrence !== null
            && $this->lastStartedOccurrence != $this->lastEndedOccurrence;
    }

    /**
     * Whether the worker started the occurrence that begins at the given
     * moment and has not ended it yet.
     */
    public function isOccurrenceStarted(\DateTimeInterface $occurrenceStart): bool
    {
        return $this->isActive() && $this->lastStartedOccurrence == $occurrenceStart;
    }

    /**
     * Sets the appointment back to "not started": its end commands do not
     * run, and the worker picks up the current occurrence as one still to
     * start on its next run - the first-start commands stay done.
     *
     * Counts as a save, so a max_start_delay of the worker is measured from
     * now and does not skip the start because the occurrence began long ago.
     */
    public function resetStart(): static
    {
        $this->firstStartedAt ??= $this->lastStartedOccurrence;
        $this->lastStartedOccurrence = null;
        $this->lastEndedOccurrence = null;
        $this->updatedAt = new \DateTime();

        return $this;
    }

    /**
     * Like resetStart(), and the first start counts as never run either: the
     * next start runs the first-start commands again.
     */
    public function resetFirstStart(): static
    {
        $this->resetStart();
        $this->firstStartedAt = null;

        return $this;
    }

    public function getTimezone(): ?string
    {
        return $this->timezone;
    }

    public function setTimezone(?string $timezone): static
    {
        $this->timezone = $timezone;

        return $this;
    }

    /**
     * @return Collection<int, User>
     */
    public function getUsers(): Collection
    {
        return $this->users;
    }

    public function addUser(User $user): static
    {
        if (!$this->users->contains($user)) {
            $this->users->add($user);
        }

        return $this;
    }

    public function getSequence(): int
    {
        return $this->sequence;
    }

    public function setSequence(int $sequence): static
    {
        $this->sequence = $sequence;

        return $this;
    }

    public function removeUser(User $user): static
    {
        $this->users->removeElement($user);

        return $this;
    }

    public function getIcalData(): ?string
    {
        return $this->icalData;
    }

    public function setIcalData(?string $icalData): static
    {
        $this->icalData = $icalData;

        return $this;
    }

    /**
     * @return Collection<int, Category>
     */
    public function getCategories(): Collection
    {
        return $this->categories;
    }

    public function addCategory(Category $category): static
    {
        if (!$this->categories->contains($category)) {
            $this->categories->add($category);
        }

        return $this;
    }

    public function getEtag(): ?string
    {
        return $this->etag;
    }

    public function setEtag(?string $etag): static
    {
        $this->etag = $etag;

        return $this;
    }

    public function getSyncRevision(): int
    {
        return $this->syncRevision;
    }

    public function setSyncRevision(int $syncRevision): static
    {
        $this->syncRevision = $syncRevision;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(?\DateTimeInterface $createdAt): static
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(?\DateTimeInterface $updatedAt): static
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    public function removeCategory(Category $category): static
    {
        $this->categories->removeElement($category);

        return $this;
    }
}
