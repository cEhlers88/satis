<?php

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Ical;

use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Ical\RecurrenceRuleMapper;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class RecurrenceRuleMapperTest extends TestCase
{
    /**
     * @return iterable<string, array{0: ?string, 1: eRepeatType, 2: ?int, 3: int[]}>
     */
    public static function rules(): iterable
    {
        yield 'none' => [null, eRepeatType::NONE, null, []];
        yield 'daily' => ['FREQ=DAILY', eRepeatType::INTERVAL, 1, []];
        yield 'every third day' => ['FREQ=DAILY;INTERVAL=3', eRepeatType::INTERVAL, 3, []];
        yield 'weekly' => ['FREQ=WEEKLY', eRepeatType::INTERVAL, 7, []];
        yield 'fortnightly' => ['FREQ=WEEKLY;INTERVAL=2', eRepeatType::INTERVAL, 14, []];
        yield 'iPhone "every weekday"' => ['FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR', eRepeatType::DAYS, null, [1, 2, 3, 4, 5]];
        yield 'daily on some days' => ['FREQ=DAILY;BYDAY=SA,SU', eRepeatType::DAYS, null, [6, 7]];
        yield 'end of series is ignored' => ['FREQ=WEEKLY;BYDAY=WE;UNTIL=20261231T000000Z', eRepeatType::DAYS, null, [3]];
        yield 'every other week on two days' => ['FREQ=WEEKLY;INTERVAL=2;BYDAY=MO,TH', eRepeatType::NONE, null, []];
        yield 'monthly' => ['FREQ=MONTHLY;BYMONTHDAY=1', eRepeatType::NONE, null, []];
        yield 'yearly' => ['FREQ=YEARLY', eRepeatType::YEARLY, null, []];
        yield 'every other year' => ['FREQ=YEARLY;INTERVAL=2', eRepeatType::NONE, null, []];
        yield 'yearly on a month' => ['FREQ=YEARLY;BYMONTH=3', eRepeatType::NONE, null, []];
        yield 'ordinal weekday' => ['FREQ=WEEKLY;BYDAY=1MO', eRepeatType::NONE, null, []];
    }

    #[DataProvider('rules')]
    public function testItMapsRulesOntoRepeatFields(?string $rule, eRepeatType $type, ?int $interval, array $days): void
    {
        self::assertSame([$type, $interval, $days], RecurrenceRuleMapper::toRepeatFields($rule));
    }
}
