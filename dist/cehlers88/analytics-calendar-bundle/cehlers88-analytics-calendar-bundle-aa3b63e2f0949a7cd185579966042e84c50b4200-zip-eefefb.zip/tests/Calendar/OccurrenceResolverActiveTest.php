<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Calendar;

use Cehlers88\AnalyticsCalendarBundle\Calendar\OccurrenceResolver;
use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

/** Which occurrences are active at a moment, or at some moment of a range. */
class OccurrenceResolverActiveTest extends TestCase
{
    private static function appointment(string $start, ?string $end, bool $allDay = false): Appointment
    {
        return (new Appointment())
            ->setTitle('x')
            ->setStartDate(new \DateTime($start))
            ->setEndDate($end === null ? null : new \DateTime($end))
            ->setAllDay($allDay);
    }

    /** @return list<string> the starts of the active occurrences */
    private static function active(Appointment $appointment, string $from, ?string $to = null): array
    {
        return array_map(
            static fn(array $occurrence): string => $occurrence[0]->format('Y-m-d H:i'),
            (new OccurrenceResolver())->activeOccurrencesIn($appointment, new \DateTimeImmutable($from), $to === null ? null : new \DateTimeImmutable($to))
        );
    }

    /** @return iterable<string, array{string, ?string, bool, string, ?string, bool}> */
    public static function cases(): iterable
    {
        // appointment start, end, all day | range start, range stop | active
        yield 'a moment while it runs' => ['2026-10-18 09:00', '2026-10-18 10:00', false, '2026-10-18 09:30', null, true];
        yield 'the moment it starts' => ['2026-10-18 09:00', '2026-10-18 10:00', false, '2026-10-18 09:00', null, true];
        yield 'the moment it ends - over' => ['2026-10-18 09:00', '2026-10-18 10:00', false, '2026-10-18 10:00', null, false];
        yield 'a moment before' => ['2026-10-18 09:00', '2026-10-18 10:00', false, '2026-10-18 08:59', null, false];
        yield 'a range it starts in' => ['2026-10-18 09:00', '2026-10-18 10:00', false, '2026-10-18 08:00', '2026-10-18 09:00', true];
        yield 'a range inside it' => ['2026-10-18 09:00', '2026-10-18 12:00', false, '2026-10-18 10:00', '2026-10-18 11:00', true];
        yield 'a range that ends before it' => ['2026-10-18 09:00', '2026-10-18 10:00', false, '2026-10-18 07:00', '2026-10-18 08:30', false];
        yield 'a range given backwards' => ['2026-10-18 09:00', '2026-10-18 10:00', false, '2026-10-18 11:00', '2026-10-18 09:30', true];
        yield 'all day: late on its day' => ['2026-10-18 00:00', '2026-10-18 23:59', true, '2026-10-18 23:59:30', null, true];
        yield 'all day: the next day' => ['2026-10-18 00:00', '2026-10-18 23:59', true, '2026-10-19 00:00', null, false];
        yield 'all day up to midnight of its last day: on that day' => ['2026-10-16 00:00', '2026-10-18 00:00', true, '2026-10-18 15:00', null, true];
        yield 'without an end: at its start' => ['2026-10-18 09:00', null, false, '2026-10-18 09:00', null, true];
        yield 'without an end: a minute later' => ['2026-10-18 09:00', null, false, '2026-10-18 09:01', null, false];
        yield 'without an end: in a range' => ['2026-10-18 09:00', null, false, '2026-10-18 08:00', '2026-10-18 10:00', true];
    }

    #[DataProvider('cases')]
    public function testWhetherAnAppointmentIsActive(string $start, ?string $end, bool $allDay, string $from, ?string $to, bool $active): void
    {
        self::assertSame($active, self::active(self::appointment($start, $end, $allDay), $from, $to) !== []);
    }

    public function testASeriesIsListedOncePerOccurrenceInTheRange(): void
    {
        $daily = self::appointment('2026-10-01 09:00', '2026-10-01 10:00')->setRepeatType(eRepeatType::INTERVAL)->setRepeatInterval(1);

        self::assertSame(['2026-10-18 09:00'], self::active($daily, '2026-10-18 09:15'));
        self::assertSame([], self::active($daily, '2026-10-18 11:00'));
        self::assertSame(
            ['2026-10-18 09:00', '2026-10-19 09:00', '2026-10-20 09:00'],
            self::active($daily, '2026-10-18 09:30', '2026-10-20 09:00')
        );
    }

    public function testAnOccurrenceThatStartedTheDayBeforeIsStillFound(): void
    {
        $overnight = self::appointment('2026-10-01 22:00', '2026-10-02 06:00')->setRepeatType(eRepeatType::DAYS)->setRepeatDays([6]);

        // Saturday 2026-10-17 22:00 until Sunday 06:00
        self::assertSame(['2026-10-17 22:00'], self::active($overnight, '2026-10-18 05:00'));
    }
}
