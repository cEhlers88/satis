<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Calendar;

use Cehlers88\AnalyticsCalendarBundle\Calendar\OccurrenceResolver;
use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use PHPUnit\Framework\TestCase;

/** A series that comes back once a year, e.g. a birthday. */
class OccurrenceResolverYearlyTest extends TestCase
{
    private static function yearly(string $start, ?string $end): Appointment
    {
        return (new Appointment())
            ->setTitle('x')
            ->setStartDate(new \DateTime($start))
            ->setEndDate($end === null ? null : new \DateTime($end))
            ->setRepeatType(eRepeatType::YEARLY);
    }

    /** @return list<string> the starts of the occurrences touching the range */
    private static function between(Appointment $appointment, string $from, string $to): array
    {
        $occurrences = (new OccurrenceResolver())->occurrencesBetween(
            $appointment,
            new \DateTimeImmutable($from),
            new \DateTimeImmutable($to)
        );

        return array_map(
            static fn(array $occurrence): string => $occurrence[0]->format('Y-m-d H:i'),
            iterator_to_array($occurrences, false)
        );
    }

    public function testItIsASeries(): void
    {
        $birthday = self::yearly('2020-03-14 00:00', '2020-03-14 23:59');

        self::assertSame(eRepeatType::YEARLY, $birthday->getRepeatType());
        self::assertTrue($birthday->isRepeating());
    }

    public function testItComesBackOnTheSameDayEveryYear(): void
    {
        $birthday = self::yearly('2020-03-14 00:00', '2020-03-14 23:59');

        self::assertSame(['2026-03-14 00:00'], self::between($birthday, '2026-03-01', '2026-03-31 23:59'));
        self::assertSame([], self::between($birthday, '2026-04-01', '2026-04-30 23:59'));
        self::assertSame(
            ['2026-03-14 00:00', '2027-03-14 00:00', '2028-03-14 00:00'],
            self::between($birthday, '2026-01-01', '2028-12-31')
        );
    }

    public function testNothingBeforeTheStartOfTheSeries(): void
    {
        $birthday = self::yearly('2026-03-14 00:00', '2026-03-14 23:59');

        self::assertSame([], self::between($birthday, '2025-03-01', '2025-03-31'));
    }

    public function testTheEndMovesAlongAndAnOccurrenceRunningIntoTheRangeIsFound(): void
    {
        $newYear = self::yearly('2024-12-31 20:00', '2025-01-01 02:00');
        $resolver = new OccurrenceResolver();

        $occurrences = iterator_to_array($resolver->occurrencesBetween(
            $newYear,
            new \DateTimeImmutable('2027-01-01 00:00'),
            new \DateTimeImmutable('2027-01-01 23:59')
        ), false);

        self::assertCount(1, $occurrences);
        self::assertSame('2026-12-31 20:00', $occurrences[0][0]->format('Y-m-d H:i'));
        self::assertSame('2027-01-01 02:00', $occurrences[0][1]->format('Y-m-d H:i'));
    }

    public function testA29thOfFebruaryFallsOnThe28thInOtherYears(): void
    {
        $leapDay = self::yearly('2024-02-29 09:00', '2024-02-29 10:00');

        self::assertSame(
            ['2025-02-28 09:00', '2028-02-29 09:00'],
            array_values(array_filter(
                self::between($leapDay, '2025-01-01', '2028-12-31'),
                static fn(string $start): bool => in_array(substr($start, 0, 4), ['2025', '2028'], true)
            ))
        );
    }

    public function testTheLatestStart(): void
    {
        $birthday = self::yearly('2020-03-14 09:00', '2020-03-14 10:00');
        $resolver = new OccurrenceResolver();

        self::assertSame('2026-03-14 09:00', $resolver->latestStartAtOrBefore($birthday, new \DateTimeImmutable('2026-10-25 12:00'))?->format('Y-m-d H:i'));
        self::assertSame('2025-03-14 09:00', $resolver->latestStartAtOrBefore($birthday, new \DateTimeImmutable('2026-03-14 08:59'))?->format('Y-m-d H:i'));
        self::assertSame('2026-03-14 09:00', $resolver->latestStartAtOrBefore($birthday, new \DateTimeImmutable('2026-03-14 09:00'))?->format('Y-m-d H:i'));
        self::assertNull($resolver->latestStartAtOrBefore($birthday, new \DateTimeImmutable('2020-03-14 08:00')));
    }

    public function testItIsActiveOnItsDay(): void
    {
        $birthday = self::yearly('2020-03-14 00:00', '2020-03-14 23:59')->setAllDay(true);
        $resolver = new OccurrenceResolver();

        self::assertCount(1, $resolver->activeOccurrencesIn($birthday, new \DateTimeImmutable('2026-03-14 18:00')));
        self::assertCount(0, $resolver->activeOccurrencesIn($birthday, new \DateTimeImmutable('2026-03-15 00:00')));
    }
}
