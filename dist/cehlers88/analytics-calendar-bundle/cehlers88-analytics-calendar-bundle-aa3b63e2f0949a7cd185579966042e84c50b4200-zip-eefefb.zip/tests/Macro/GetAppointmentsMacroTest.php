<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Macro;

use Cehlers88\AnalyticsCalendarBundle\Calendar\OccurrenceResolver;
use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Macro\GetAppointmentsMacro;
use Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\UserRepository;
use PHPUnit\Framework\TestCase;

class GetAppointmentsMacroTest extends TestCase
{
    /** What the repository was asked for: user, application, from, to. */
    private array $asked = [];

    private static function appointment(int $id, string $start, ?string $end): Appointment
    {
        $appointment = (new Appointment())
            ->setTitle('Appointment ' . $id)
            ->setStartDate(new \DateTime($start))
            ->setEndDate($end === null ? null : new \DateTime($end));
        (new \ReflectionProperty(Appointment::class, 'id'))->setValue($appointment, $id);

        return $appointment;
    }

    /**
     * @param Appointment[] $appointments what the repository finds
     * @return array{error: mixed, returnValue: mixed}
     */
    private function getAppointments(array $arguments, array $appointments = [], ?User $user = null, ?Application $application = null): array
    {
        $repository = $this->createStub(AppointmentRepository::class);
        $repository->method('findCandidates')->willReturnCallback(function (...$given) use ($appointments) {
            $this->asked = $given;

            return $appointments;
        });
        $users = $this->createStub(UserRepository::class);
        $users->method('find')->willReturn($user);
        $users->method('findOneBy')->willReturn($user);
        $applications = $this->createStub(ApplicationRepository::class);
        $applications->method('find')->willReturn($application);
        $applications->method('findOneBy')->willReturn($application);

        $macro = new GetAppointmentsMacro($repository, new OccurrenceResolver(), $users, $applications);
        $macro->setMacroEnvironment($this->createStub(MacroEnvironment::class));

        return $macro->execute($arguments + ['user' => -1, 'application' => -1, 'rangeStart' => 'now', 'rangeStop' => '', 'limit' => 100]);
    }

    public function testWithoutAnEndOfTheRangeTheStartIsTheOnlyMomentChecked(): void
    {
        $result = $this->getAppointments(['rangeStart' => '2026-10-18 09:30'], [
            self::appointment(1, '2026-10-18 09:00', '2026-10-18 10:00'),
            self::appointment(2, '2026-10-18 10:00', '2026-10-18 11:00'),
        ]);

        self::assertNull($result['error']);
        self::assertSame([1], array_column($result['returnValue'], 'id'));
        self::assertSame('2026-10-18T09:00:00', substr($result['returnValue'][0]['start'], 0, 19));
    }

    public function testARangeTakesEveryAppointmentActiveAtSomeMomentOfIt(): void
    {
        $result = $this->getAppointments(['rangeStart' => '2026-10-18 09:30', 'rangeStop' => '2026-10-18 10:30'], [
            self::appointment(2, '2026-10-18 10:00', '2026-10-18 11:00'),
            self::appointment(1, '2026-10-18 09:00', '2026-10-18 10:00'),
            self::appointment(3, '2026-10-18 11:00', '2026-10-18 12:00'),
        ]);

        self::assertSame([1, 2], array_column($result['returnValue'], 'id'), 'the earliest first');
    }

    public function testFiltersThatAreNotGivenAreNotPassedOn(): void
    {
        $this->getAppointments(['user' => -1, 'application' => '', 'rangeStart' => '2026-10-18 09:30']);

        self::assertNull($this->asked[0], 'no user filter');
        self::assertNull($this->asked[1], 'no application filter');
        self::assertSame('2026-10-17 09:30', $this->asked[2]->format('Y-m-d H:i'), 'a day earlier, for all-day appointments');
        self::assertSame('2026-10-18 09:30', $this->asked[3]->format('Y-m-d H:i'));
    }

    public function testWithoutARangeEveryAppointmentIsListedWithTheDatesOfItsSeries(): void
    {
        $series = self::appointment(1, '2026-01-01 09:00', '2026-01-01 10:00')->setRepeatType(eRepeatType::INTERVAL)->setRepeatInterval(7);

        $result = $this->getAppointments(['rangeStart' => ''], [$series]);

        self::assertSame([null, null, null, null], $this->asked);
        self::assertCount(1, $result['returnValue']);
        self::assertTrue($result['returnValue'][0]['repeating']);
        self::assertStringStartsWith('2026-01-01T09:00', $result['returnValue'][0]['start']);
    }

    public function testTheGivenFiltersAreResolvedAndPassedOn(): void
    {
        $user = $this->createStub(User::class);
        $application = $this->createStub(Application::class);

        $this->getAppointments(['user' => 'ada@example.test', 'application' => 3], [], $user, $application);

        self::assertSame($user, $this->asked[0]);
        self::assertSame($application, $this->asked[1]);
    }

    public function testAnUnknownUserOrADateThatIsNoneIsAnError(): void
    {
        self::assertNotNull($this->getAppointments(['user' => 'nobody@example.test'])['error']);
        self::assertNotNull($this->getAppointments(['rangeStart' => 'not a date'])['error']);
        self::assertSame([], $this->asked, 'nothing was looked for');
    }

    public function testTheLimitKeepsTheEarliest(): void
    {
        $daily = self::appointment(1, '2026-10-01 09:00', '2026-10-01 10:00')->setRepeatType(eRepeatType::INTERVAL)->setRepeatInterval(1);

        $limited = $this->getAppointments(['rangeStart' => '2026-10-18 00:00', 'rangeStop' => '2026-10-24 23:00', 'limit' => 2], [$daily]);
        $unlimited = $this->getAppointments(['rangeStart' => '2026-10-18 00:00', 'rangeStop' => '2026-10-24 23:00', 'limit' => 0], [$daily]);

        self::assertSame(['2026-10-18', '2026-10-19'], array_map(static fn(array $entry): string => substr($entry['start'], 0, 10), $limited['returnValue']));
        self::assertCount(7, $unlimited['returnValue']);
    }
}
