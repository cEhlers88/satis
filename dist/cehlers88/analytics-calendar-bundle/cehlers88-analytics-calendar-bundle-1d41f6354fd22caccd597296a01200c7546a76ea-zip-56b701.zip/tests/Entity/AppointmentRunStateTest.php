<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Entity;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use PHPUnit\Framework\TestCase;

/** Whether the worker has started an appointment, and setting it back. */
class AppointmentRunStateTest extends TestCase
{
    private static function started(?string $lastStarted, ?string $lastEnded = null): Appointment
    {
        return (new Appointment())
            ->setTitle('x')
            ->setStartDate(new \DateTime('2026-10-19 09:00'))
            ->setLastStartedOccurrence($lastStarted === null ? null : new \DateTimeImmutable($lastStarted))
            ->setLastEndedOccurrence($lastEnded === null ? null : new \DateTimeImmutable($lastEnded));
    }

    public function testNeverStartedIsNeitherActiveNorFirstStarted(): void
    {
        $appointment = self::started(null);

        self::assertFalse($appointment->isActive());
        self::assertFalse($appointment->hasFirstStarted());
    }

    public function testStartedAndNotEndedIsActive(): void
    {
        self::assertTrue(self::started('2026-10-19 09:00')->isActive());
        self::assertTrue(self::started('2026-10-19 09:00', '2026-10-18 09:00')->isActive());
        self::assertFalse(self::started('2026-10-19 09:00', '2026-10-19 09:00')->isActive());
    }

    public function testRowsFromBeforeTheColumnCountAsFirstStarted(): void
    {
        self::assertTrue(self::started('2026-10-19 09:00', '2026-10-19 09:00')->hasFirstStarted());
    }

    public function testResetStartKeepsTheFirstStart(): void
    {
        $appointment = self::started('2026-10-19 09:00', '2026-10-18 09:00')
            ->setUpdatedAt(new \DateTime('2026-10-01 00:00'));

        $appointment->resetStart();

        self::assertFalse($appointment->isActive());
        self::assertNull($appointment->getLastStartedOccurrence());
        self::assertNull($appointment->getLastEndedOccurrence());
        self::assertTrue($appointment->hasFirstStarted());
        self::assertEquals(new \DateTimeImmutable('2026-10-19 09:00'), $appointment->getFirstStartedAt());
        // A save, so the worker's max_start_delay counts from the reset.
        self::assertGreaterThan(new \DateTime('2026-10-01 00:00'), $appointment->getUpdatedAt());
    }

    public function testResetStartDoesNotOverwriteAKnownFirstStart(): void
    {
        $appointment = self::started('2026-10-19 09:00')
            ->setFirstStartedAt(new \DateTimeImmutable('2026-10-01 09:00'));

        $appointment->resetStart();

        self::assertEquals(new \DateTimeImmutable('2026-10-01 09:00'), $appointment->getFirstStartedAt());
    }

    public function testResetFirstStartForgetsEverything(): void
    {
        $appointment = self::started('2026-10-19 09:00')
            ->setFirstStartedAt(new \DateTimeImmutable('2026-10-01 09:00'));

        $appointment->resetFirstStart();

        self::assertFalse($appointment->isActive());
        self::assertFalse($appointment->hasFirstStarted());
        self::assertNull($appointment->getFirstStartedAt());
    }
}
