<?php

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Calendar;

use Cehlers88\AnalyticsCalendarBundle\Calendar\CalendarViewFactory;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class CalendarViewFactoryTest extends TestCase
{
    private const NOW = '2026-10-16 10:05';

    /**
     * @return iterable<string, array{0: string, 1: ?string, 2: bool, 3: bool, 4: bool}>
     */
    public static function occurrences(): iterable
    {
        // start, end, all day, running, over
        yield 'running' => ['2026-10-16 09:30', '2026-10-16 10:30', false, true, false];
        yield 'starts this very minute' => ['2026-10-16 10:05', '2026-10-16 11:00', false, true, false];
        yield 'ended this very minute' => ['2026-10-16 09:00', '2026-10-16 10:05', false, false, true];
        yield 'still to come' => ['2026-10-16 12:30', '2026-10-16 13:30', false, false, false];
        yield 'over' => ['2026-10-16 07:00', '2026-10-16 08:00', false, false, true];
        yield 'overnight, into today' => ['2026-10-15 22:30', '2026-10-16 11:00', false, true, false];
        yield 'without an end, started' => ['2026-10-16 09:00', null, false, false, true];
        yield 'without an end, to come' => ['2026-10-16 17:00', null, false, false, false];
        yield 'all day today' => ['2026-10-16 00:00', '2026-10-16 23:59', true, true, false];
        yield 'all day yesterday' => ['2026-10-15 00:00', '2026-10-15 23:59', true, false, true];
        yield 'all day tomorrow' => ['2026-10-17 00:00', '2026-10-17 23:59', true, false, false];
        yield 'all day, ending at midnight of its last day' => ['2026-10-14 00:00', '2026-10-16 00:00', true, true, false];
        yield 'all day over several days, today in between' => ['2026-10-12 00:00', '2026-10-17 00:00', true, true, false];
        yield 'all day without an end' => ['2026-10-16 00:00', null, true, false, false];
    }

    #[DataProvider('occurrences')]
    public function testItTellsRunningAndOverApart(
        string  $start,
        ?string $end,
        bool    $isAllDay,
        bool    $isRunning,
        bool    $isOver
    ): void {
        $start = new \DateTimeImmutable($start);
        $end = $end === null ? null : new \DateTimeImmutable($end);
        $now = new \DateTimeImmutable(self::NOW);

        self::assertSame($isRunning, CalendarViewFactory::isRunning($start, $end, $isAllDay, $now), 'running');
        self::assertSame($isOver, CalendarViewFactory::isOver($start, $end, $isAllDay, $now), 'over');
    }

    public function testOpenUntilListsWhenTheAppointmentsStillAheadAreOver(): void
    {
        $entries = [
            ['isOver' => true, 'isVacation' => false, 'startsAt' => '2026-10-16T07:00:00+02:00', 'endsAt' => '2026-10-16T08:00:00+02:00'],
            ['isOver' => false, 'isVacation' => false, 'startsAt' => '2026-10-16T09:30:00+02:00', 'endsAt' => '2026-10-16T10:30:00+02:00'],
            ['isOver' => false, 'isVacation' => true, 'startsAt' => '2026-10-16T00:00:00+02:00', 'endsAt' => '2026-10-16T23:59:59+02:00'],
            ['isOver' => false, 'isVacation' => false, 'startsAt' => '2026-10-16T17:00:00+02:00', 'endsAt' => null],
        ];

        self::assertSame(
            ['2026-10-16T10:30:00+02:00', '2026-10-16T17:00:00+02:00'],
            CalendarViewFactory::openUntil($entries)
        );
        self::assertSame([], CalendarViewFactory::openUntil([]));
    }
}
