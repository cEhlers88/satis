<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCalendarBundle\Tests\Macro;

use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Entity\Calendar;
use Cehlers88\AnalyticsCalendarBundle\Macro\AddAppointmentMacro;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarManager;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarObjectManager;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Macro\MacroEnvironment;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\UserRepository;
use PHPUnit\Framework\TestCase;

class AddAppointmentMacroTest extends TestCase
{
    /** @var array{0: Appointment, 1: ?Calendar}[] what was saved, into which calendar */
    private array $saved = [];
    private Calendar $calendar;
    private User $user;

    protected function setUp(): void
    {
        $this->calendar = new Calendar();
        $this->user = $this->createStub(User::class);
        $this->user->method('getId')->willReturn(7);
    }

    private function addAppointment(array $arguments, bool $protectedMode = false, bool $knownUser = true): array
    {
        $objects = $this->createStub(CalendarObjectManager::class);
        $objects->method('save')->willReturnCallback(function (Appointment $appointment, ?Calendar $calendar) {
            $this->saved[] = [$appointment, $calendar];

            return $appointment;
        });
        $calendars = $this->createStub(CalendarManager::class);
        $calendars->method('getDefaultCalendar')->willReturn($this->calendar);
        $users = $this->createStub(UserRepository::class);
        $users->method('find')->willReturn($knownUser ? $this->user : null);
        $users->method('findOneBy')->willReturn($knownUser ? $this->user : null);

        $environment = $this->createStub(MacroEnvironment::class);
        $environment->method('isProtectedMode')->willReturn($protectedMode);

        $macro = new AddAppointmentMacro($objects, $calendars, $users, $this->createStub(ApplicationRepository::class));
        $macro->setMacroEnvironment($environment);

        return $macro->execute($arguments);
    }

    public function testSavesTheAppointmentIntoTheDefaultCalendarOfTheUser(): void
    {
        $result = $this->addAppointment([
            'title' => ' Zählerstand ablesen ',
            'start' => '2026-11-20 09:00',
            'end' => '2026-11-20 09:30',
            'location' => 'Keller',
            'user' => 'christoph@example.org',
            'reminderTimer' => 15,
        ]);

        $this->assertFalse($result['hasError']);
        $this->assertCount(1, $this->saved);
        [$appointment, $calendar] = $this->saved[0];
        $this->assertSame($this->calendar, $calendar);
        $this->assertSame('Zählerstand ablesen', $appointment->getTitle());
        $this->assertSame('Keller', $appointment->getLocation());
        $this->assertNull($appointment->getDescription());
        $this->assertSame(900, $appointment->getReminderTimer()); // seconds
        $this->assertSame([$this->user], $appointment->getUsers()->toArray());
        $this->assertFalse($appointment->isRepeating());

        $this->assertSame('Zählerstand ablesen', $result['returnValue']['title']);
        $this->assertSame((new \DateTimeImmutable('2026-11-20 09:00'))->format(DATE_ATOM), $result['returnValue']['start']);
        $this->assertSame((new \DateTimeImmutable('2026-11-20 09:30'))->format(DATE_ATOM), $result['returnValue']['end']);
        $this->assertSame([7], $result['returnValue']['users']);
    }

    public function testAnAllDayAppointmentLastsUntilMidnightAfterItsLastDay(): void
    {
        $result = $this->addAppointment([
            'title' => 'Urlaub',
            'start' => '2026-12-21 14:00',
            'end' => '2026-12-23',
            'allDay' => 'true',
            'user' => 7,
        ]);

        $this->assertFalse($result['hasError']);
        $this->assertTrue($result['returnValue']['allDay']);
        $this->assertSame((new \DateTimeImmutable('2026-12-21 00:00'))->format(DATE_ATOM), $result['returnValue']['start']);
        $this->assertSame((new \DateTimeImmutable('2026-12-24 00:00'))->format(DATE_ATOM), $result['returnValue']['end']);
    }

    public function testAMomentInAnotherTimezoneIsStoredAsServerTime(): void
    {
        $previous = date_default_timezone_get();
        date_default_timezone_set('Europe/Berlin');
        try {
            $this->addAppointment(['title' => 'X', 'start' => '2026-11-20T09:00:00Z', 'user' => 7]);
        } finally {
            date_default_timezone_set($previous);
        }

        $this->assertSame('2026-11-20 10:00', $this->saved[0][0]->getStartDate()->format('Y-m-d H:i'));
    }

    public function testAnAllDayAppointmentWithoutEndIsOneDay(): void
    {
        $result = $this->addAppointment(['title' => 'Vertrag läuft aus', 'start' => '2027-03-31', 'allDay' => true, 'user' => 7]);

        $this->assertSame((new \DateTimeImmutable('2027-04-01 00:00'))->format(DATE_ATOM), $result['returnValue']['end']);
    }

    public static function dataProviderForInvalidArguments(): array
    {
        return [
            'no title' => [['title' => ' ', 'start' => 'tomorrow', 'user' => 7]],
            'no start' => [['title' => 'X', 'start' => '', 'user' => 7]],
            'no date' => [['title' => 'X', 'start' => 'irgendwann', 'user' => 7]],
            'no user' => [['title' => 'X', 'start' => 'tomorrow', 'user' => '']],
            'end before start' => [['title' => 'X', 'start' => '2026-11-20 10:00', 'end' => '2026-11-20 09:00', 'user' => 7]],
            'all-day: last day before the first' => [['title' => 'X', 'start' => '2026-11-20', 'end' => '2026-11-19', 'allDay' => true, 'user' => 7]],
        ];
    }

    #[\PHPUnit\Framework\Attributes\DataProvider('dataProviderForInvalidArguments')]
    public function testInvalidArgumentsSaveNothing(array $arguments): void
    {
        $result = $this->addAppointment($arguments);

        $this->assertTrue($result['hasError']);
        $this->assertSame(422, $result['error']->number);
        $this->assertSame([], $this->saved);
    }

    public function testAnUnknownUserIsAnError(): void
    {
        $result = $this->addAppointment(['title' => 'X', 'start' => 'tomorrow', 'user' => 'nobody@example.org'], false, false);

        $this->assertTrue($result['hasError']);
        $this->assertStringContainsString('there is no user', $result['error']->message);
    }

    public function testProtectedModeSavesNothing(): void
    {
        $result = $this->addAppointment(['title' => 'X', 'start' => '2026-11-20 09:00', 'user' => 7], true);

        $this->assertFalse($result['hasError']);
        $this->assertSame([], $this->saved);
        $this->assertNull($result['returnValue']['id']);
        $this->assertSame('X', $result['returnValue']['title']);
    }
}
