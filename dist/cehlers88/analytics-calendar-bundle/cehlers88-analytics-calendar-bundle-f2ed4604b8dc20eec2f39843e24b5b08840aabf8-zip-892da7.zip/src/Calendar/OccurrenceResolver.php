<?php

namespace Cehlers88\AnalyticsCalendarBundle\Calendar;

use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;

/**
 * Knows when an appointment happens: the occurrences a series puts into a
 * range, the occurrence that started last and where an occurrence ends.
 *
 * The calendar and the command worker both ask here, so a recurrence rule is
 * only ever interpreted in one place. An occurrence keeps the wall-clock times
 * of the appointment - it is the appointment moved by whole days.
 *
 * A yearly series returns on the day and month of its start; a start on
 * 29 February falls on 28 February in the other years, so a birthday on that
 * day is not skipped for three years.
 */
class OccurrenceResolver
{
    /** A series that never leaves the range must still not loop forever. */
    private const MAX_OCCURRENCES = 400;

    public function __construct(private WorkWeek $workWeek = new WorkWeek())
    {
    }

    /**
     * The ISO weekdays a day-based series falls on, or null for a type that
     * does not repeat by weekday.
     *
     * @return int[]|null
     */
    public function repeatDaysOf(Appointment $appointment): ?array
    {
        return match ($appointment->getRepeatType()) {
            eRepeatType::WEEKDAYS => $this->workWeek->workDays(),
            eRepeatType::WEEKEND => $this->workWeek->weekendDays(),
            eRepeatType::DAYS => $appointment->getRepeatDays(),
            default => null,
        };
    }

    /**
     * The occurrences of an appointment that touch the range - a single one for
     * an appointment that does not repeat.
     *
     * @return \Generator<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    public function occurrencesBetween(
        Appointment        $appointment,
        \DateTimeImmutable $rangeStart,
        \DateTimeImmutable $rangeEnd
    ): \Generator {
        $start = $this->startOf($appointment);
        $end = $this->endOfSeriesStart($appointment);

        $repeatDays = $this->repeatDaysOf($appointment);

        if ($repeatDays !== null) {
            yield from $this->expandDays($start, $end, $repeatDays, $rangeStart, $rangeEnd);

            return;
        }

        if ($appointment->getRepeatType() === eRepeatType::YEARLY) {
            yield from $this->expandYearly($start, $end, $rangeStart, $rangeEnd);

            return;
        }

        if ($appointment->getRepeatType() === eRepeatType::INTERVAL) {
            yield from $this->expandInterval($start, $end, (int)$appointment->getRepeatInterval(), $rangeStart, $rangeEnd);

            return;
        }

        if (($end ?? $start) >= $rangeStart && $start <= $rangeEnd) {
            yield [$start, $end];
        }
    }

    /**
     * The occurrences of an appointment that are active at some moment of the range - with
     * `$to` null, at the moment `$from` itself.
     *
     * An occurrence is active from its start until its end, the end itself no longer. An
     * all-day one lasts until its last day is over (see endOf()); one without an end is
     * active at its start only. The end that is handed back is the end of the occurrence as
     * the appointment has it.
     *
     * @return list<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    public function activeOccurrencesIn(
        Appointment         $appointment,
        \DateTimeImmutable  $from,
        ?\DateTimeImmutable $to = null
    ): array {
        $to ??= $from;
        if ($to < $from) {
            [$from, $to] = [$to, $from];
        }

        $active = [];
        // a day earlier: an all-day occurrence stored up to midnight of its last day is
        // still active on that day, which occurrencesBetween() does not know
        foreach ($this->occurrencesBetween($appointment, $from->modify('-1 day'), $to) as [$start, $end]) {
            $activeUntil = $this->activeUntil($appointment, $start);

            $isActive = $activeUntil === null
                ? $start >= $from && $start <= $to
                : $start <= $to && $activeUntil > $from;

            if ($isActive) {
                $active[] = [$start, $end];
            }
        }

        return $active;
    }

    /**
     * The moment the occurrence that starts at the given moment is no longer active - null
     * for one without an end. An all-day occurrence is active until its last day is over.
     */
    private function activeUntil(Appointment $appointment, \DateTimeImmutable $occurrenceStart): ?\DateTimeImmutable
    {
        $end = $this->endOf($appointment, $occurrenceStart);
        if ($end === null || !$appointment->isAllDay() || $end->format('H:i:s') === '00:00:00') {
            return $end;
        }

        // stored up to the last minute of its last day (23:59) - over with that day
        return $end->setTime(0, 0)->modify('+1 day');
    }

    /**
     * The start of the last occurrence that began at or before the moment, or
     * null while the appointment has not started yet.
     */
    public function latestStartAtOrBefore(Appointment $appointment, \DateTimeImmutable $moment): ?\DateTimeImmutable
    {
        $start = $this->startOf($appointment);

        if ($start > $moment) {
            return null;
        }

        if ($appointment->getRepeatType() === eRepeatType::YEARLY) {
            $candidate = $this->inYear($start, (int)$moment->format('Y'));

            // the start lies at or before the moment, so the year before is never ahead of it
            return $candidate <= $moment ? $candidate : $this->inYear($start, (int)$moment->format('Y') - 1);
        }

        $daysSinceStart = $this->daysBetween($start, $moment);

        if ($appointment->getRepeatType() === eRepeatType::INTERVAL) {
            $interval = (int)$appointment->getRepeatInterval();
            $offset = intdiv($daysSinceStart, $interval) * $interval;

            if ($this->shift($start, $offset) > $moment) {
                $offset -= $interval;
            }

            return $offset >= 0 ? $this->shift($start, $offset) : null;
        }

        $repeatDays = $this->repeatDaysOf($appointment);

        if ($repeatDays !== null) {
            // Every weekday comes round within a week, so a week back always
            // reaches the last occurrence - if the series has any day at all.
            for ($offset = $daysSinceStart; $offset >= max(0, $daysSinceStart - 7); $offset--) {
                $candidate = $this->shift($start, $offset);

                if ($candidate <= $moment && $this->fallsOn($candidate, $repeatDays)) {
                    return $candidate;
                }
            }

            return null;
        }

        return $start;
    }

    /**
     * The moment the occurrence that starts at the given moment is over - null
     * for an appointment without an end.
     *
     * An all-day appointment is stored from midnight to midnight of its last
     * day, and the calendar shows it on that last day too - so it is only over
     * once that day has passed.
     */
    public function endOf(Appointment $appointment, \DateTimeInterface $occurrenceStart): ?\DateTimeImmutable
    {
        $start = $this->startOf($appointment);
        $end = $this->endOfSeriesStart($appointment);

        if ($end === null) {
            return null;
        }

        if ($start->format('H:i') === '00:00' && $end->format('H:i:s') === '00:00:00') {
            $end = $end->modify('+1 day');
        }

        $occurrenceStart = \DateTimeImmutable::createFromInterface($occurrenceStart);

        return $this->shift($end, $this->daysBetween($start, $occurrenceStart));
    }

    /**
     * @return \Generator<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    private function expandInterval(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        int                 $interval,
        \DateTimeImmutable  $rangeStart,
        \DateTimeImmutable  $rangeEnd
    ): \Generator {
        // Skipping straight to the first occurrence that can still be in the
        // range keeps a long-running series from being walked from its start -
        // as many days earlier as an occurrence lasts, so one that began before
        // the range and still runs into it (22:00 until 06:00) is not lost.
        $spanDays = $end === null ? 0 : max(0, $this->daysBetween($start, $end));
        $daysBehind = $this->daysBetween($start, $rangeStart) - $spanDays;
        $step = $daysBehind > 0 ? intdiv($daysBehind, $interval) : 0;

        for ($i = 0; $i < self::MAX_OCCURRENCES; $i++, $step++) {
            $offset = $step * $interval;
            $occurrenceStart = $this->shift($start, $offset);

            if ($occurrenceStart > $rangeEnd) {
                return;
            }

            $occurrenceEnd = $end === null ? null : $this->shift($end, $offset);

            if (($occurrenceEnd ?? $occurrenceStart) >= $rangeStart) {
                yield [$occurrenceStart, $occurrenceEnd];
            }
        }
    }

    /**
     * One occurrence a year from the start of the series on. The first year
     * looked at is the one of the moment an occurrence lasting as long as the
     * appointment would have to start to still reach into the range.
     *
     * @return \Generator<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    private function expandYearly(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        \DateTimeImmutable  $rangeStart,
        \DateTimeImmutable  $rangeEnd
    ): \Generator {
        $spanDays = $end === null ? 0 : max(0, $this->daysBetween($start, $end));
        $year = max((int)$start->format('Y'), (int)$this->shift($rangeStart, -$spanDays)->format('Y'));

        for ($i = 0; $i < self::MAX_OCCURRENCES; $i++, $year++) {
            $occurrenceStart = $this->inYear($start, $year);

            if ($occurrenceStart > $rangeEnd) {
                return;
            }

            $occurrenceEnd = $end === null ? null : $this->shift($end, $this->daysBetween($start, $occurrenceStart));

            if (($occurrenceEnd ?? $occurrenceStart) >= $rangeStart) {
                yield [$occurrenceStart, $occurrenceEnd];
            }
        }
    }

    /**
     * Every day of the given weekdays from the start of the series on. The
     * walk begins as many days before the range as an occurrence lasts, so one
     * that began earlier and still runs into the range is not lost.
     *
     * @param int[] $repeatDays ISO weekdays - none yields nothing
     *
     * @return \Generator<array{0: \DateTimeImmutable, 1: ?\DateTimeImmutable}>
     */
    private function expandDays(
        \DateTimeImmutable  $start,
        ?\DateTimeImmutable $end,
        array               $repeatDays,
        \DateTimeImmutable  $rangeStart,
        \DateTimeImmutable  $rangeEnd
    ): \Generator {
        if ($repeatDays === []) {
            return;
        }

        $spanDays = $end === null ? 0 : max(0, $this->daysBetween($start, $end));
        $day = max($start->setTime(0, 0), $this->shift($rangeStart->setTime(0, 0), -$spanDays));

        for ($i = 0; $i < self::MAX_OCCURRENCES; $i++, $day = $day->modify('+1 day')) {
            if (!$this->fallsOn($day, $repeatDays)) {
                continue;
            }

            $offset = $this->daysBetween($start, $day);
            $occurrenceStart = $this->shift($start, $offset);

            if ($occurrenceStart > $rangeEnd) {
                return;
            }

            $occurrenceEnd = $end === null ? null : $this->shift($end, $offset);

            if (($occurrenceEnd ?? $occurrenceStart) >= $rangeStart) {
                yield [$occurrenceStart, $occurrenceEnd];
            }
        }
    }

    private function startOf(Appointment $appointment): \DateTimeImmutable
    {
        return \DateTimeImmutable::createFromInterface($appointment->getStartDate());
    }

    private function endOfSeriesStart(Appointment $appointment): ?\DateTimeImmutable
    {
        return $appointment->getEndDate() === null
            ? null
            : \DateTimeImmutable::createFromInterface($appointment->getEndDate());
    }

    /** Whole calendar days from one date to the other, negative when going back. */
    private function daysBetween(\DateTimeImmutable $from, \DateTimeImmutable $to): int
    {
        $difference = $from->setTime(0, 0)->diff($to->setTime(0, 0));

        return $difference->invert ? -$difference->days : $difference->days;
    }

    private function shift(\DateTimeImmutable $moment, int $days): \DateTimeImmutable
    {
        return $moment->modify(sprintf('%+d days', $days));
    }

    /**
     * The moment moved into another year, keeping day, month and time - the
     * last day of the month when the month is shorter that year (29 February).
     */
    private function inYear(\DateTimeImmutable $moment, int $year): \DateTimeImmutable
    {
        $month = (int)$moment->format('n');
        $daysInMonth = (int)$moment->setDate($year, $month, 1)->format('t');

        return $moment->setDate($year, $month, min((int)$moment->format('j'), $daysInMonth));
    }

    /**
     * @param int[] $repeatDays
     */
    private function fallsOn(\DateTimeImmutable $day, array $repeatDays): bool
    {
        return in_array((int)$day->format('N'), $repeatDays, true);
    }
}
