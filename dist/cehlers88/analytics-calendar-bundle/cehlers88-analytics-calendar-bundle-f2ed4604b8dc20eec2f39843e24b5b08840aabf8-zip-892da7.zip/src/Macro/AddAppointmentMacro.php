<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCalendarBundle\Macro;

use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarManager;
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarObjectManager;
use Cehlers88\AnalyticsCore\DTO\ErrorDTO;
use Cehlers88\AnalyticsCore\Macro\DTO\MacroPropertyDTO;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\UserRepository;

/**
 * Puts a single appointment into the calendar of a user - a procedure can note the date a
 * contract runs out or a reminder to read a meter. It is saved the way the calendar widget
 * saves one (CalendarObjectManager), into the user's default calendar, so connected devices
 * (CalDAV, the feed) see it on their next synchronisation.
 *
 * Series, start/end commands and conditions stay with the calendar widget; a command that
 * writes those would be a second, smaller editor for them.
 *
 * An all-day appointment is stored like the iCalendar import stores one: from midnight of its
 * first day to midnight after its last day. In the protected mode nothing is saved, the result
 * describes the appointment with the id null.
 */
class AddAppointmentMacro extends AbstractCalendarMacro
{
    use ResolvesUserAndApplication;

    private const string PROPERTY_TITLE = 'title';
    private const string PROPERTY_START = 'start';
    private const string PROPERTY_END = 'end';
    private const string PROPERTY_ALL_DAY = 'allDay';
    private const string PROPERTY_DESCRIPTION = 'description';
    private const string PROPERTY_LOCATION = 'location';
    private const string PROPERTY_USER = 'user';
    private const string PROPERTY_APPLICATION = 'application';
    private const string PROPERTY_REMINDER = 'reminderTimer';

    public function __construct(
        private readonly CalendarObjectManager $calendarObjectManager,
        private readonly CalendarManager       $calendarManager,
        private readonly UserRepository        $userRepository,
        private readonly ApplicationRepository $applicationRepository,
    )
    {
    }

    public function _init(): AddAppointmentMacro
    {
        $this
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_TITLE, ['string'], 'Title of the appointment'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_START, ['string'], 'When it begins (e.g. "2026-11-20 09:00", "tomorrow 08:00", "+3 days")'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_END, ['string'], 'When it ends - with allDay its last day; empty: no end (all-day: that one day)', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_ALL_DAY, ['bool'], 'Whether it lasts whole days', false))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_DESCRIPTION, ['string'], 'Text of the appointment', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_LOCATION, ['string'], 'Where it takes place', ''))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_USER, ['mixed'], 'Whose calendar it goes into - id or e-mail address'))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_APPLICATION, ['mixed'], 'The application it belongs to - id or name; -1: none', -1))
            ->setProperty(MacroPropertyDTO::create(self::PROPERTY_REMINDER, ['int'], 'Minutes before the start to remind of it; 0: no reminder', 0));

        return $this;
    }

    public function getDescription(): string
    {
        return 'Adds an appointment to the calendar of a user.';
    }

    public function getName(): string
    {
        return 'addAppointment';
    }

    protected function run(): ?array
    {
        $title = trim((string)$this->getPropertyValue(self::PROPERTY_TITLE));
        $allDay = filter_var($this->getPropertyValue(self::PROPERTY_ALL_DAY), FILTER_VALIDATE_BOOLEAN);
        $description = trim((string)$this->getPropertyValue(self::PROPERTY_DESCRIPTION));
        $location = trim((string)$this->getPropertyValue(self::PROPERTY_LOCATION));
        $reminder = (int)$this->getPropertyValue(self::PROPERTY_REMINDER);

        if ($title === '') {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'An appointment needs a title.'));
        }

        try {
            $start = GetAppointmentsMacro::moment($this->getPropertyValue(self::PROPERTY_START), self::PROPERTY_START);
            $end = GetAppointmentsMacro::moment($this->getPropertyValue(self::PROPERTY_END), self::PROPERTY_END);
            $user = $this->user($this->getPropertyValue(self::PROPERTY_USER));
            $application = $this->application($this->getPropertyValue(self::PROPERTY_APPLICATION));
        } catch (\InvalidArgumentException $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(422, $exception->getMessage()));
        }

        if ($start === null) {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'An appointment needs a start.'));
        }
        if ($user === null) {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'An appointment needs the user whose calendar it goes into.'));
        }
        if ($allDay) {
            $start = $start->setTime(0, 0);
            if ($end !== null && $end->setTime(0, 0) < $start) {
                return $this->_createRunResult(null, ErrorDTO::create(422, 'The last day lies before the first.'));
            }
            // exclusive, like DTEND of an all-day VEVENT: midnight after the last day
            $end = ($end ?? $start)->setTime(0, 0)->modify('+1 day');
        } else {
            // the columns keep no timezone - a moment given in another one ("…Z") is stored
            // as the server's wall-clock time, like AppointmentHydrator::parseDate() does
            $serverTimezone = new \DateTimeZone(date_default_timezone_get());
            $start = $start->setTimezone($serverTimezone);
            $end = $end?->setTimezone($serverTimezone);
        }
        if ($end !== null && $end < $start) {
            return $this->_createRunResult(null, ErrorDTO::create(422, 'The end lies before the start.'));
        }

        $appointment = (new Appointment())
            ->setTitle($title)
            ->setStartDate(\DateTime::createFromImmutable($start))
            ->setEndDate($end === null ? null : \DateTime::createFromImmutable($end))
            ->setAllDay($allDay)
            ->setDescription($description === '' ? null : $description)
            ->setLocation($location === '' ? null : $location)
            // stored in seconds (AppointmentSerializer, the calendar widget)
            ->setReminderTimer($reminder > 0 ? $reminder * 60 : null)
            ->setRepeatType(eRepeatType::NONE)
            ->setApplication($application)
            ->addUser($user);

        try {
            $this->runProtectedFragment(fn(): Appointment => $this->calendarObjectManager->save(
                $appointment,
                $this->calendarManager->getDefaultCalendar($user)
            ));
        } catch (\Throwable $exception) {
            return $this->_createRunResult(null, ErrorDTO::create(500, $exception->getMessage()));
        }

        return $this->_createRunResult(GetAppointmentsMacro::describe($appointment, $start, $end));
    }
}
