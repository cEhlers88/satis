<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsCalendarBundle\Macro;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\User;

/**
 * The user (id or e-mail address) and the application (id or name) a calendar macro is given -
 * read the same way by every one of them. A value that is not given
 * (GetAppointmentsMacro::isNotGiven()) is null; one that names nobody is an error.
 *
 * Needs the properties $userRepository and $applicationRepository.
 */
trait ResolvesUserAndApplication
{
    private function user(mixed $value): ?User
    {
        if ($value instanceof User || GetAppointmentsMacro::isNotGiven($value)) {
            return $value instanceof User ? $value : null;
        }
        $user = is_numeric($value)
            ? $this->userRepository->find((int)$value)
            : $this->userRepository->findOneBy(['email' => trim((string)$value)]);

        if (!$user instanceof User) {
            throw new \InvalidArgumentException(sprintf('user: there is no user "%s".', is_scalar($value) ? $value : get_debug_type($value)));
        }

        return $user;
    }

    private function application(mixed $value): ?Application
    {
        if ($value instanceof Application || GetAppointmentsMacro::isNotGiven($value)) {
            return $value instanceof Application ? $value : null;
        }
        $application = is_numeric($value)
            ? $this->applicationRepository->find((int)$value)
            : $this->applicationRepository->findOneBy(['name' => trim((string)$value)]);

        if (!$application instanceof Application) {
            throw new \InvalidArgumentException(sprintf('application: there is no application "%s".', is_scalar($value) ? $value : get_debug_type($value)));
        }

        return $application;
    }
}
