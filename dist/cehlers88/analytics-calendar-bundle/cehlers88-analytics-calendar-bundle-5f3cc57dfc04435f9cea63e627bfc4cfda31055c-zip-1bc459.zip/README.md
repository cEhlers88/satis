# AnalyticsCalendarBundle

A Symfony bundle for managing calendar appointments and events within the Analytics platform. It provides dashboard widgets, appointment scheduling, configurable date/time formats, a macro system for programmatic calendar operations and a CalDAV endpoint that connects phones and desktop calendar clients.

## Table of Contents

- [Requirements](#requirements)
- [Installation](#installation)
- [Calendar Synchronisation (CalDAV & iCalendar feed)](#calendar-synchronisation-caldav--icalendar-feed)
  - [Enabling the endpoints](#enabling-the-endpoints)
  - [Issuing device credentials](#issuing-device-credentials)
  - [Endpoints](#endpoints)
  - [Console commands](#console-commands)
  - [How synchronisation works](#how-synchronisation-works)
- [Configuration](#configuration)
- [JavaScript / Webpack Encore Integration](#javascript--webpack-encore-integration)
- [Widgets](#widgets)
  - [Calendar Widget](#calendar-widget)
  - [Time Widget](#time-widget)
- [Entities](#entities)
  - [Appointment](#entity-appointment)
  - [Calendar](#entity-calendar)
  - [CalendarAccessToken](#entity-calendaraccesstoken)
  - [CalendarDeletedObject](#entity-calendardeletedobject)
- [Repository: AppointmentRepository](#repository-appointmentrepository)
- [Calendar view model: CalendarViewFactory](#calendar-view-model-calendarviewfactory)
- [Macros](#macros)
  - [AddAppointmentMacro](#addappointmentmacro)
- [Worker: AppointmentCommandWorker](#worker-appointmentcommandworker)
- [Permissions](#permissions)
- [Tests](#tests)
- [Changelog](#changelog)

## Requirements

- PHP 8.0+
- Symfony 6.0+
- `cehlers88/analytics-core` ^0.3

## Installation

### 1. Add the custom Satis repository to your `composer.json`

```json
{
    "repositories": [
        {
            "type": "composer",
            "url": "https://cehlers88.github.io/satis"
        }
    ]
}
```

### 2. Install the bundle via Composer

```bash
composer require cehlers88/analytics-calendar-bundle
```

### 3. Register the bundle (if not using Symfony Flex auto-discovery)

```php
// config/bundles.php
return [
    // ...
    Cehlers88\AnalyticsCalendarBundle\AnalyticsCalendarBundle::class => ['all' => true],
];
```

### 4. Update the database schema

```bash
php bin/console doctrine:migrations:diff
php bin/console doctrine:migrations:migrate
```

This creates the `calendar_appointment` table used by the `Appointment` entity, the calendar collections (`calendar_calendar`), the device credentials (`calendar_access_token`) and the deletion tombstones (`calendar_deleted_object`).

## Calendar Synchronisation (CalDAV & iCalendar feed)

The bundle exposes the appointments of an account through two standard
interfaces, so that the calendar app of a phone or desktop becomes a front end
for the appointments stored here:

| | CalDAV | iCalendar subscription |
|---|---|---|
| Read appointments | yes | yes |
| Create, change and delete from the device | yes | no |
| Authentication | HTTP Basic with a device secret | secret inside the URL |
| Protocols | RFC 4791 (CalDAV), RFC 6578 (WebDAV sync), RFC 6764 (discovery) | RFC 5545 |

> **Step-by-step guide for the iPhone (German):**
> [`docs/iphone-kalender.md`](docs/iphone-kalender.md)

### Enabling the endpoints

Import the routes of the bundle in the host application:

```yaml
# config/routes.yaml
analytics_calendar_bundle:
  resource: '@AnalyticsCalendarBundle/Resources/config/routes.yaml'
```

Do **not** add a `prefix`: calendar clients store the URLs permanently, so
`/caldav`, `/.well-known/caldav` and `/calendar/feed` are fixed paths.

No change to `security.yaml` is required. The endpoint authenticates itself
because calendar clients speak HTTP Basic and expect a `401` challenge on every
unauthenticated request, which a form-login firewall does not provide. The paths
have to stay reachable though — if the application restricts them through
`access_control`, add:

```yaml
security:
  access_control:
    - { path: ^/caldav, roles: PUBLIC_ACCESS }
    - { path: ^/calendar/feed, roles: PUBLIC_ACCESS }
```

The web server must pass every HTTP method through, including `PROPFIND`,
`PROPPATCH`, `REPORT`, `OPTIONS` and `MKCALENDAR`. FrankenPHP/Caddy and a
default nginx `fastcgi_pass`/`proxy_pass` already do.

Installations that already contain appointments run the setup command once, so
that the existing rows get a calendar and an iCalendar identifier:

```bash
php bin/console analytics:calendar:setup user@example.com
```

### Issuing device credentials

The account password is deliberately not accepted. A device stores its
credential permanently and sends it on every synchronisation, so it gets its own
revocable secret:

```bash
php bin/console analytics:calendar:token:create user@example.com \
    --label="iPhone" --base-url=https://analytics.example.com
```

The command prints server address, user name and the generated password once —
only its SHA-256 digest is stored.

### Endpoints

| Path | Purpose |
|---|---|
| `/.well-known/caldav` | discovery, redirects to the CalDAV root |
| `/caldav/` | collection root, answers `current-user-principal` |
| `/caldav/principals/{userId}/` | principal, answers `calendar-home-set` |
| `/caldav/calendars/{userId}/` | list of the calendars of the account |
| `/caldav/calendars/{userId}/{calendar}/` | one calendar collection |
| `/caldav/calendars/{userId}/{calendar}/{object}.ics` | one appointment |
| `/calendar/feed/{secret}.ics` | read-only feed over all calendars |
| `/calendar/feed/{secret}/{calendar}.ics` | read-only feed of one calendar |

Supported methods: `OPTIONS`, `GET`, `HEAD`, `PROPFIND`, `PROPPATCH`, `REPORT`,
`PUT`, `DELETE`, `MKCALENDAR`, `MKCOL`. Supported reports: `calendar-query`,
`calendar-multiget` and `sync-collection`.

A `GET` on a calendar collection returns the whole collection as one iCalendar
stream. That is not part of CalDAV, but it makes the endpoint inspectable with
`curl` while setting up a device.

### Console commands

| Command | Description |
|---|---|
| `analytics:calendar:setup <email>` | Creates the default calendar and assigns appointments that predate synchronisation. `--dry-run` reports without writing. |
| `analytics:calendar:token:create <email>` | Issues a credential. `--type=caldav\|feed`, `--label`, `--calendar`, `--expires`, `--base-url`. |
| `analytics:calendar:token:list [email]` | Lists the issued credentials with their state and last use. |
| `analytics:calendar:token:revoke <id>` | Revokes a credential, e.g. for a lost device. |

### How synchronisation works

Every change to a calendar object increases the revision counter of its
collection. The counter backs both the CalendarServer `ctag` and the WebDAV
`sync-token`, so a client asks only for the difference since its last
synchronisation instead of downloading every appointment again. Deletions leave
a `CalendarDeletedObject` tombstone behind, because the appointment row itself
is gone by the time the client asks.

A calendar object sent by a client is stored verbatim in `Appointment::icalData`
and handed back unchanged on the next `GET`. In addition, the properties this
bundle knows about are mapped onto the columns of the appointment, so the web
interface works with the same data. Properties outside that mapping (attendees,
attachments, custom `X-` properties) survive because of the verbatim copy.

Appointments created or changed inside the application go through
`CalendarObjectManager::save()`, which rebuilds the iCalendar representation,
recomputes the entity tag and bumps the revision counter:

```php
use Cehlers88\AnalyticsCalendarBundle\Service\CalendarObjectManager;

$appointment = new Appointment();
$appointment->setTitle('Team Meeting')->setStartDate(new \DateTime('2026-04-01 10:00'));

$objectManager->save($appointment, $calendarManager->getDefaultCalendar($user));
```

Using the entity manager directly still works, but such an appointment is not
announced to connected devices until something else bumps the counter.

## JavaScript / Webpack Encore Integration

The bundle ships its JavaScript assets in `assets/index.ts` and exposes a
`package.json` so it can be registered as a local npm module in the host
Symfony application.  Follow the steps below to include the bundle's
JavaScript in your webpack-encore build.

### 1. Register the bundle as a local npm package

Add the bundle as a file-based dependency in your application's `package.json`:

```json
{
    "dependencies": {
        "@cehlers88/analytics-calendar-bundle": "file:vendor/cehlers88/analytics-calendar-bundle"
    }
}
```

Then install the new dependency:

```bash
yarn install
# or
npm install
```

This creates a symlink at
`node_modules/@cehlers88/analytics-calendar-bundle` that points to the
vendor directory, so webpack can resolve the module.

### 2. Add an entry point in `webpack.config.js`

Open your application's `webpack.config.js` and add an entry that imports
the bundle's assets:

```js
// webpack.config.js
const Encore = require('@symfony/webpack-encore');

Encore
    // … your existing configuration …
    .addEntry('analytics-calendar-bundle', '@cehlers88/analytics-calendar-bundle')
;

module.exports = Encore.getWebpackConfig();
```

> **Tip:** If you prefer to bundle the calendar assets together with your
> main application entry point instead of creating a separate file, you can
> import the module inside your existing entry file (e.g.
> `assets/app.ts`):
>
> ```ts
> import { initAnalyticsCalendarBundle } from '@cehlers88/analytics-calendar-bundle';
>
> document.addEventListener('DOMContentLoaded', () => {
>     initAnalyticsCalendarBundle();
> });
> ```

### 3. Build the assets

```bash
yarn encore dev   # development build
yarn encore prod  # production build
```

### 4. Include the compiled script in your Twig template

If you added a dedicated entry point in step 2, include it via the
`encore_entry_script_tags` helper:

```twig
{# base.html.twig #}
{{ encore_entry_script_tags('analytics-calendar-bundle') }}
```

### Available exports

| Export | Description |
| --- | --- |
| `initAnalyticsCalendarBundle()` | Convenience initialiser for the widgets that need one. Returns a function that stops what it started. |
| `initTimeWidget(selector?)` | Starts a one-second interval that updates the text content of every element matching `selector` (default: `'[data-widget="time"]'`) with the current locale time string. Returns a function that clears the interval. |
| `onCalendarEvent(name, handler, target?)` | Listens to one of the events a calendar widget emits. Returns a function that removes the listener. |
| `CalendarEvents` | The event names: `navigate`, `daySelected`, `appointmentCreated`, `appointmentUpdated`, `appointmentDeleted`. |

> **Note:** the calendar widget initialises itself. The markup the server
> renders carries the script that wires navigation, the day picker and the
> appointment mask, so nothing has to start it from the host application.

#### Listening to what happens in a calendar

The events bubble up to the document, so one listener catches every calendar on
the page - including the ones a dashboard renders after the listener was
registered.

```ts
import { CalendarEvents, onCalendarEvent } from '@cehlers88/analytics-calendar-bundle';

// The widget moved to another period or view.
onCalendarEvent(CalendarEvents.navigate, ({ view, date }) => {
    console.log('Kalender zeigt jetzt', view, 'ab', date);
});

// A day was picked - which is also what opens the appointment mask.
onCalendarEvent(CalendarEvents.daySelected, ({ date }) => {
    console.log('Tag gewählt:', date);
});

// An appointment was saved.
onCalendarEvent(CalendarEvents.appointmentCreated, ({ id, date }) => {
    console.log('Termin', id, 'am', date, 'gespeichert');
});

// An existing appointment was edited.
onCalendarEvent(CalendarEvents.appointmentUpdated, ({ id, date }) => {
    console.log('Termin', id, 'bearbeitet, beginnt am', date);
});

// An appointment was deleted.
onCalendarEvent(CalendarEvents.appointmentDeleted, ({ id }) => {
    console.log('Termin', id, 'gelöscht');
});
```

## Configuration

The bundle exposes a **General Calendar Settings** group under the key `calendarBundle.general`, accessible through the *Kalenderverwaltung* (Calendar Management) menu in the Analytics admin panel.

| Configuration Key | Label | Type | Default | Description |
|---|---|---|---|---|
| `calendarBundle.general.defaultDateFormat` | Standard Datumsformat | Text | `d.m.Y` | PHP date format used for displaying dates |
| `calendarBundle.general.defaultTimeFormat` | Standard Zeitformat | Text | `H:i` | PHP date format used for displaying times |
| `calendarBundle.general.defaultDateTimeFormat` | Standard Datums- und Zeitformat | Text | `d.m.Y H:i` | PHP date format used for displaying date and time together |
| `calendarBundle.general.defaultWeekStart` | Standard Wochenstart | Select | `1` (Monday) | First day of the week: 1 = Monday … 7 = Sunday |
| `calendarBundle.general.workWeekEnd` | Ende der Arbeitswoche | Select | `5` (Friday) | Last day of the work week: 1 = Monday … 7 = Sunday. The work week runs from `defaultWeekStart` up to this day; every day after it, up to the next start of the week, is weekend |
| `calendarBundle.general.vacationCategoryGroup` | Kategorie-Gruppe für Urlaub | Select | – (none) | The category group (AnalyticsCore `CategoryGroup`) whose categories mean vacation: an appointment with one of them is a vacation |

`Calendar\WorkWeek` reads both values and is the one place that knows which
days are work days and which are weekend - the repetitions *Arbeitswoche* and
*Wochenende* follow it, and the calendar shades the weekend days it names.

`Calendar\VacationCategories` reads `vacationCategoryGroup` and is the one place
that knows what a vacation is: `isVacation($appointment)` is true when the
appointment has a category of that group, `categoryIds()` names them. Without the
setting, or with a group that no longer exists, nothing is a vacation. The
calendar marks vacations (striped, with a sun), and the mask names the
categories of the group "(Urlaub)".

## Widgets

### Calendar Widget

**Widget name:** `calendar`
**Required role:** `ROLE_USER`
**Template:** `templates/widget/calendar.html.twig` (body: `templates/widget/_calendarBody.html.twig`)

Shows the appointments of a month or a week in the dark theme of the dashboard
and opens the mask for a new appointment on the day that was picked.

- **Monats- und Wochenansicht** - the head switches between them and steps
  through the periods; *Heute* jumps back and is marked while the current
  period is on screen.
- **Termine im Raster** - each day lists what happens on it, coloured per
  appointment and truncated to the configured number with a `+n` summary.
  A repeating appointment is expanded into the occurrences that fall into the
  period, and one that spans days appears on each of them.
- **Nur eigene Termine** - a user only ever sees, loads, edits and deletes the
  appointments assigned to them. Someone else's appointment is answered like
  one that does not exist.
- **Neuer Termin** - clicking a day (or the button in the foot) opens the mask.
  It is split in two columns so it stays compact: on the left *when* - title,
  date, all-day switch, times, repetition, reminder and description; on the right *who and what* - the assigned users (the logged-in
  user is preselected), the application the commands run in and the start,
  first-start and end commands, each edited in an `<exec-viewer>` of the host
  application that starts empty. The application list only offers what the user
  may read. The first-start commands only
  show for a series. Saving stores the appointment and repaints the period.
- **Wiederholung** - besides *einmalig* and the intervals (daily, weekly, every
  two weeks, monthly) a series can repeat in the *Arbeitswoche* or on the
  *Wochenende* - both follow the configured work week and name their days in
  the select - or on *Ausgewählte Wochentage*, which shows a checkbox per
  weekday (preselected with the weekday of the date). Saving refuses a day
  selection without a day.
- **Maximieren** - the button next to *Schließen* lets the mask take the whole
  screen, like the tool windows of the host application; the browser remembers
  the choice. On a narrow screen the mask always takes the whole screen.
- **Benutzer und Kategorien** - both are picked in a `<suggest-input multiple>` of
  the host application: typing (or just focusing) the field offers the users or
  categories, every pick becomes a chip and its × takes it off again. A new
  appointment starts with the current user.
- **Termin bearbeiten und Löschen** - clicking an appointment loads it into the
  same mask with every attribute editable. A series is edited as a whole, which
  the mask says. *Löschen* asks before it acts: the first click arms the button,
  the second one removes the appointment and repaints the period. A repeating
  appointment is one entity, so the button says that the whole series goes with
  it.

Navigating, loading, saving and deleting all go through `submitWidget()`; the widget answers with
the body rendered from the very same Twig template the first paint used, so
there is never a second idea of what a calendar looks like in the browser.

#### Settings

The settings a dashboard tile can be configured with:

| Setting | Type | Default | Description |
|---|---|---|---|
| `view` | Select (`month`, `week`) | `month` | Which view the tile starts with |
| `maxEntriesPerDay` | Number (1-8) | `3` | How many appointments a day shows before the rest is summarised |
| `showWeekNumbers` | Checkbox | `false` | Puts the calendar week in front of each week |

The weekday a calendar starts on comes from
`calendarBundle.general.defaultWeekStart`, the labels from
`defaultDateFormat` and `defaultTimeFormat` - see [Configuration](#configuration).
A `date` property (anything `DateTimeImmutable` understands, or a timestamp)
makes the tile start on another period than the current one.

#### Submit actions

`POST /api/submitWidget/calendar` understands these actions. Every one of them
acts for the logged-in user: `load`, `update` and `delete` answer `404` for an
appointment that is not assigned to them.

| `action` | Payload | Answer |
|---|---|---|
| `render` | `date`, `view`, `firstDayOfWeek`, `maxEntriesPerDay`, `showWeekNumbers` | `data.html` - the body of the tile for that period, with the user's appointments |
| `load` | `appointmentId` | `data` - the appointment in the shape `create` takes it (`title`, `date`, `startTime`, `endDate`, `endTime`, `isAllDay`, `repeatInterval`, `repeatDays`, `isRepeating`, `reminderTimer`, `userIds`, `categoryIds`, `description`, the three command lists, `applicationId`) |
| `create` | `title`, `date`, `startTime`, `endDate`, `endTime`, `description`, `repeatInterval`, `repeatDays`, `reminderTimer`, `userIds`, `categoryIds`, `startCommands`, `endCommands`, `firstStartCommands`, `applicationId` | `data.id`, `data.date` of the stored appointment |
| `update` | `appointmentId` plus everything `create` takes - it replaces all attributes | `data.id`, `data.date` of the edited appointment |
| `delete` | `appointmentId` | `data.id` of the removed appointment |

> `appointmentId` and not `id`: the latter is the id of the widget instance,
> which the render action is given alongside it.

What `create` expects of the newer fields:

| Field | Value | Rejected (422) when |
|---|---|---|
| `repeatInterval` | `0` (none), a number of days, `weekdays` for the work week, `weekend` for the weekend, or `days` for the weekdays in `repeatDays` | `weekend` while the work week covers every day |
| `repeatDays` | Only with `repeatInterval` = `days`: comma separated ISO weekdays (or a list), 1 = Monday … 7 = Sunday | no valid weekday is given |
| `userIds` | Comma separated user ids (or a list). Empty assigns the logged-in user | a picked user does not exist, or nobody can be assigned |
| `categoryIds` | Comma separated category ids (or a list). Optional - empty stores none | a picked category does not exist |
| `applicationId` | Id of an application the user may read (every one for an admin). Empty stores none | the application does not exist or is not readable by the user; empty while any command is set |
| `startCommands`, `endCommands`, `firstStartCommands` | A JSON list of command definitions, e.g. `[["commandName", {"argument": "Wert"}]]`. Empty stores nothing | the value is not a non-empty JSON list; `endCommands` on an appointment without end; `firstStartCommands` on an appointment that does not repeat |

**Preload placeholders layout:**

| Row | Height | Column widths |
|-----|--------|---------------|
| 1 | 32 px | 50 % · 50 % |
| 2 | 240 px | 100 % |
| 3 | 32 px | 60 % · 40 % |

### Time Widget

**Widget name:** `time`

A minimal widget that displays the current time.

**Preload placeholders layout:**

| Row | Height | Column widths |
|-----|--------|---------------|
| 1 | 50 px | 50 % · 50 % |

**Template:** `templates/widget/time.html.twig`

## Entities

### Entity: Appointment

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Entity\Appointment`  
**Database table:** `calendar_appointment`

| Property | Type | Nullable | Description |
|----------|------|----------|-------------|
| `id` | `int` | No | Auto-generated primary key |
| `title` | `string(255)` | No | Title of the appointment |
| `description` | `text` | Yes | Optional detailed description |
| `startDate` | `DateTime` | No | Start date and time |
| `endDate` | `DateTime` | Yes | Optional end date and time |
| `repeatType` | `eRepeatType` | Yes | `none`, `interval`, `weekdays` (the configured work week), `weekend` (the configured weekend) or `days` (the weekdays in `repeatDays`). Read it through `getRepeatType()`, which also understands rows stored before the column existed |
| `repeatInterval` | `int` | Yes | Recurrence interval in days - only used for `eRepeatType::INTERVAL` |
| `repeatDays` | `json` | Yes | ISO weekdays (1 = Monday … 7 = Sunday) of the series - only used for `eRepeatType::DAYS` |
| `reminderTimer` | `int` | Yes | Reminder offset in seconds before the appointment |
| `calendar` | `Calendar` | Yes | Collection the appointment belongs to |
| `uid` | `string(255)` | Yes | iCalendar `UID`, generated locally or taken over from the client |
| `uri` | `string(255)` | Yes | File name inside the CalDAV collection, unique per calendar |
| `location` | `string(255)` | Yes | Place of the appointment |
| `allDay` | `bool` | No | Whether the appointment covers whole days |
| `rrule` | `string(255)` | Yes | Raw recurrence rule, e.g. `FREQ=WEEKLY;BYDAY=MO,WE` |
| `timezone` | `string(64)` | Yes | Olson identifier the client used |
| `sequence` | `int` | No | iCalendar revision counter of the object |
| `icalData` | `text` | Yes | Verbatim calendar object as delivered by a client |
| `etag` | `string(64)` | Yes | Entity tag derived from `icalData` |
| `syncRevision` | `int` | No | Revision of the calendar at the last change |
| `createdAt` / `updatedAt` | `DateTime` | Yes | Timestamps |
| `users` | `Collection<User>` | No | The users the appointment is assigned to (join table `calendar_appointment_user`) |
| `categories` | `Collection<Category>` | No | Optional categories (AnalyticsCore `Category`, join table `calendar_appointment_category`); a category of the vacation group makes the appointment a vacation. Deleting a category takes it off its appointments |
| `startCommands` | `json` | Yes | Command definitions run whenever an occurrence starts |
| `endCommands` | `json` | Yes | Command definitions run whenever an occurrence ends |
| `firstStartCommands` | `json` | Yes | Command definitions run only when the first occurrence of a series starts, before `startCommands` |
| `application` | `Application` | Yes | The application the commands run in - required as soon as the appointment has commands. Deleting the application sets it to `null` |
| `lastStartedOccurrence` | `DateTimeImmutable` | Yes | Start of the occurrence the worker started last - maintained by the worker |
| `lastEndedOccurrence` | `DateTimeImmutable` | Yes | Start of the occurrence the worker ended last - maintained by the worker |

`rrule` is the recurrence rule exactly as a calendar client sent it. The
repeat fields above are what the application works with, and the two are kept
in step by `Ical\RecurrenceRuleMapper`: a client rule is mapped onto the
closest repeat type (`FREQ=DAILY` → interval, `FREQ=WEEKLY` without `BYDAY` →
interval in weeks, `FREQ=WEEKLY;BYDAY=…` → `days`; monthly and yearly rules
stay `none` in the application). When an appointment is rendered, the stored
`rrule` is used as long as it still maps onto the current repeat fields - so
`COUNT`, `UNTIL` and friends survive - and is replaced by a rule built from the
repeat fields once they were changed in the application.

For all-day appointments `endDate` follows the iCalendar convention and is
*exclusive*: an appointment covering only 1 April ends on 2 April.

`setRepeatInterval()` with a positive value makes the appointment an interval
series, `setRepeatType()` drops the interval for every other type and the
weekdays for every type but `DAYS`, so the fields never contradict each other.
`setRepeatDays()` keeps only the days 1 … 7, sorted and without duplicates. `isRepeating()` and `hasCommands()` answer
the obvious questions.

**Example usage:**

```php
use Cehlers88\AnalyticsCalendarBundle\ENUM\eRepeatType;
use Cehlers88\AnalyticsCalendarBundle\Entity\Appointment;

$appointment = new Appointment();
$appointment
    ->setTitle('Team Meeting')
    ->setStartDate(new \DateTime('2026-04-01 10:00'))
    ->setEndDate(new \DateTime('2026-04-01 11:00'))
    ->setDescription('Weekly sync call')
    ->setRepeatInterval(7)      // repeats every 7 days
    ->setReminderTimer(900)     // reminder 15 minutes (900 s) before start
    ->addUser($user);

// Every Monday, Wednesday and Friday
$training = new Appointment();
$training
    ->setTitle('Training')
    ->setStartDate(new \DateTime('2026-04-01 18:00'))
    ->setRepeatType(eRepeatType::DAYS)
    ->setRepeatDays([1, 3, 5])
    ->addUser($user);

// Every day of the work week, with commands
$office = new Appointment();
$office
    ->setTitle('Büro')
    ->setStartDate(new \DateTime('2026-04-01 08:00'))
    ->setEndDate(new \DateTime('2026-04-01 17:00'))
    ->setRepeatType(eRepeatType::WEEKDAYS)
    ->setFirstStartCommands([['setupOffice', []]])
    ->setStartCommands([['lightOn', ['room' => 'office']]])
    ->setEndCommands([['lightOff', ['room' => 'office']]])
    ->setApplication($application)   // the commands run in this application
    ->addUser($user);

$entityManager->persist($appointment);
$entityManager->persist($office);
$entityManager->flush();
```

All setters return `static` to allow method chaining.

> **Schema update:** the column `repeatDays` (`repeat_days`) is new. Run
> `doctrine:migrations:diff` and `doctrine:migrations:migrate` in the host
> application; existing appointments keep their repetition.

> **Schema update:** this version adds the columns above and the join table.
> Run `doctrine:migrations:diff` and `doctrine:migrations:migrate` in the host
> application. Existing appointments have no users assigned yet - assign them
> once after migrating.

> **Schema update:** the join table `calendar_appointment_category` of the
> categories is new. Run `doctrine:migrations:diff` and
> `doctrine:migrations:migrate` in the host application; existing appointments
> start without categories.

### Entity: Calendar

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Entity\Calendar`  
**Database table:** `calendar_calendar`

One calendar collection of a user. Each collection shows up as a separate
calendar inside the calendar app of a connected device.

| Property | Type | Nullable | Description |
|----------|------|----------|-------------|
| `owner` | `User` | No | Account the calendar belongs to |
| `uri` | `string(64)` | No | Last path segment of the CalDAV URL, unique per owner |
| `displayName` | `string(255)` | No | Name shown by the client |
| `description` | `text` | Yes | Optional description |
| `color` | `string(9)` | Yes | Colour used by Apple clients, `#RRGGBB` or `#RRGGBBAA` |
| `timezone` | `string(64)` | Yes | Default timezone of the calendar |
| `syncToken` | `int` | No | Revision counter backing `ctag` and `sync-token` |
| `calendarOrder` | `int` | No | Sort order used by Apple clients |

The default calendar (`uri` = `default`) is created on first access, so a
freshly configured device always finds a collection.

### Entity: CalendarAccessToken

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Entity\CalendarAccessToken`  
**Database table:** `calendar_access_token`

The credential a calendar client authenticates with. Only the SHA-256 digest of
the secret is stored — the secret itself is shown once, when it is issued.

| Property | Type | Nullable | Description |
|----------|------|----------|-------------|
| `user` | `User` | No | Account the credential grants access to |
| `label` | `string(100)` | No | Name of the device |
| `type` | `EAccessTokenType` | No | `caldav` (read/write) or `feed` (read-only) |
| `tokenHash` | `string(64)` | No | SHA-256 digest of the secret, unique |
| `tokenPreview` | `string(16)` | No | First characters, for recognising it in listings |
| `calendar` | `Calendar` | Yes | Restriction to a single calendar; `NULL` means all |
| `expiresAt` | `DateTime` | Yes | Optional expiry |
| `lastUsedAt` | `DateTime` | Yes | Last successful use, updated at most every 5 minutes |
| `revokedAt` | `DateTime` | Yes | Set when the credential was withdrawn |

### Entity: CalendarDeletedObject

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Entity\CalendarDeletedObject`  
**Database table:** `calendar_deleted_object`

Tombstone of a removed appointment, holding calendar, `uri` and the revision at
which the deletion happened. WebDAV synchronisation needs it to report removals
to a client that syncs with a `sync-token`.

## Repository: AppointmentRepository

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Repository\AppointmentRepository`

Extends `Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository`, so all
standard Doctrine query methods are available, plus:

| Method | Description |
|---|---|
| `save(Appointment $appointment, bool $flush = true): Appointment` | Persists an appointment |
| `remove(Appointment $appointment, bool $flush = true): void` | Removes an appointment |
| `findInRange(\DateTimeInterface $from, \DateTimeInterface $to, User $user): array` | Every appointment assigned to the user that can put an occurrence into the range - a repeating one counts as soon as its series starts before the range ends |
| `findOneForUser(int $id, User $user): ?Appointment` | The appointment with the id, as long as it is assigned to the user |
| `findWithPendingCommands(\DateTimeInterface $now): array` | Every appointment with commands that has begun and is not done yet - a series, or a single appointment that still has to be started or ended |

```php
// Inject the repository via autowiring or fetch from the entity manager
$repository = $entityManager->getRepository(Appointment::class);

// Find all appointments
$appointments = $repository->findAll();

// Everything the user has in August
$appointments = $repository->findInRange(
    new \DateTime('2026-08-01 00:00:00'),
    new \DateTime('2026-08-31 23:59:59'),
    $user
);
```

In addition it provides the lookups the CalDAV endpoint needs:

| Method | Description |
|---|---|
| `findByCalendar(Calendar)` | Every appointment of a collection, ordered by start |
| `findOneByCalendarAndUri(Calendar, string)` | The object behind a CalDAV URL |
| `findOneByCalendarAndUid(Calendar, string)` | Lookup by iCalendar `UID` |
| `findChangedSince(Calendar, int)` | Everything changed after a revision |
| `findInCalendarRange(Calendar, ?DateTimeInterface, ?DateTimeInterface)` | Appointments overlapping a period; recurring ones are always included, because whether an occurrence falls into the period is only known after the rule has been expanded |
| `findWithoutCalendar(?User)` | Appointments not assigned to a collection yet - with a user, those assigned to that user or to nobody |

## Calendar view model: CalendarViewFactory

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Calendar\CalendarViewFactory`

Builds what the calendar template renders: the weeks of a period, the
appointments that fall into each of their days and the dates the navigation
moves to. Repeating appointments are expanded into their occurrences and
appointments that span days are put on each day they touch, so a template never
has to know a recurrence rule.

```php
$view = $calendarViewFactory->create(
    new \DateTimeImmutable('2026-08-28'),
    'month',   // or 'week'
    1,         // 1 = Monday … 7 = Sunday
    'H:i',
    'd.m.Y',
    $user      // whose appointments are shown - without a user the grid stays empty
);

$view['periodTitle'];   // 'August 2026'
$view['weeks'];         // the weeks, each with its seven days
$view['nextDate'];      // where the '>' button goes
```

Every appointment of a day carries, besides its title, times and labels,
`categories` (the names of its categories) and `isVacation`
(`VacationCategories`).

## Macros

Macros are reusable operations that can be invoked programmatically within the Analytics platform.

### AddAppointmentMacro

**Macro name:** `addAppointment`  
**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Macro\AddAppointmentMacro`  
**Description:** Adds an appointment to the calendar.

All calendar macros extend `AbstractCalendarMacro`, which sets the macro source to `"InfrastructureBundle"` during initialisation.

```php
// Resolve and run the macro through the Analytics macro runner
$macro = $container->get(AddAppointmentMacro::class);
$macro->init();
$result = $macro->run();
```

> **Note:** The `run()` method currently returns an empty result set. Appointment data input is planned for a future release.

## Worker: AppointmentCommandWorker

**Namespace:** `Cehlers88\AnalyticsCalendarBundle\Worker\AppointmentCommandWorker`

Starts and ends appointments by running their commands through the core
`CommandPlayer` - always in the application of the appointment, not in the one
the worker is registered for. Register it as a worker in the Analytics application and let it
run every minute - how precisely commands fire depends on that schedule.

On each run, for every appointment `findWithPendingCommands()` returns:

1. **End** - if the occurrence it started last is over, its `endCommands` run.
   An appointment without end never ends; an all-day appointment is over once
   its last day has passed.
2. **Start** - if an occurrence began that is newer than the one started last,
   `firstStartCommands` run first when nothing was ever started, then
   `startCommands`.

An appointment that does not repeat has a single occurrence - its start. Moved
to another time after it ran, it is started and ended again for the new time;
the markers of the earlier run do not count for it.

When the worker was not running, only the latest occurrence is considered, and
it is skipped if it is already over or began longer ago than `max_start_delay`.
Its end commands are then not run either - an end always belongs to a start.

The occurrence is written to `lastStartedOccurrence` / `lastEndedOccurrence`
*before* its commands run, so nothing is executed twice. A command definition
that is invalid, or a command that fails, is reported as a worker warning and
not retried. The same goes for an appointment without application: its
occurrence counts as started or ended, but no command runs.

| Property | Type | Default | Description |
|---|---|---|---|
| `max_start_delay` | `int` | `-1` | Seconds after its start in which a missed occurrence is still started. `-1` starts every occurrence that is not over yet |

Which occurrences a series has is decided by
`Calendar\OccurrenceResolver` - the same service the calendar widget expands its
appointments with, so the worker and the calendar always agree.

## Permissions

The bundle defines a single permission used to control access to the calendar management interface:

| Permission | Value | Description |
|---|---|---|
| `EPermission::ACCESS_INFRASTRUCTURE` | `ACCESS_INFRASTRUCTURE` | Grants access to the calendar management area |

```php
use Cehlers88\AnalyticsCalendarBundle\ENUM\EPermission;

// Check all bundle permissions
$permissions = EPermission::getPermissions();
// Returns: ['ACCESS_INFRASTRUCTURE']
```

## Tests

The iCalendar reader and writer, the mapping between appointments and calendar
objects and the CalDAV XML layer are covered by unit tests:

```bash
composer install
vendor/bin/phpunit
```

The suite fixes `date.timezone` to `Europe/Berlin`, because appointments are
stored as wall clock time of the server timezone and the conversion to and from
UTC is part of what is being tested.

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a full version history.
