<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;

class EnrichTrackingEntityJob extends AbstractWorkerJob
{
    private const EMPTY_HASH = '0000000000000000000000000000000000000000';
    public const BUFFER_REPO_FETCH_KEY = 'BUFFER.git_repo_fetch';

    public function __construct()
    {
        $this->setType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION);
    }

    /**
     * @param TrackingBuffer $object
     * @return AbstractWorkerJob
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        if ($object->getData()['key'] === self::BUFFER_REPO_FETCH_KEY) {
            return $this;
        }

        try {
            $handlerData = $object->getHandlerData();
            $data = $object->getData();

            if (is_string($data['body'])) {
                $data['body'] = json_decode($data['body'], true);
                $object->setData($data);
            }

            if (!isset($handlerData['eventReason']) || empty($handlerData['eventReason'])) {
                $handlerData['eventReason'] = $this->evalEventReason($data['body']);
            }
            if (!isset($handlerData['repositoryName']) || empty($handlerData['repositoryName'])) {
                $handlerData['repositoryName'] = $this->evalRepositoryName($data['body']);
            }

            $object
                ->setHandlerData($handlerData);

        } catch (\Exception $e) {
            $this->_logger->error('Error while work on object "' . $e->getMessage() . '"');
        }

        return $this;
    }

    private function evalEventReason(array $bodyData): string
    {
        $reason = '';

        if (isset($bodyData['workflow_job'])) {
            switch ($bodyData['action']) {
                case 'completed':
                    return 'workflow_job_completed';
            }
        }

        if (isset($bodyData['workflow_run'])) {
            switch ($bodyData['action']) {
                case 'completed':
                    return 'workflow_run_completed';
            }
        }

        if (isset($bodyData['pull_request'])) {
            switch ($bodyData['action']) {
                case 'assigned':
                    return 'pull_request_assigned';
                case 'edited':
                    return 'pull_request_edited';
                case 'opened':
                    return 'pull_request_opened';
                case 'review_requested':
                    return 'review_requested';
            }
        }

        if (isset($bodyData['issue'])) {
            switch ($bodyData['action']) {
                case 'assigned':
                    return 'issue_assigned';
                case 'opened':
                    return 'issue_opened';
            }
        }

        if (isset($bodyData['repository'])) {
            if (isset($bodyData['zen'])) {
                return 'ping';
            }
            if (isset($bodyData['before']) && $bodyData['before'] === self::EMPTY_HASH) {
                return 'first_branch_push';
            }
            if (isset($bodyData['after']) && $bodyData['after'] === self::EMPTY_HASH) {
                return 'branch_delete';
            }
            if (isset($bodyData['pusher'])) {
                return 'push';
            }
        }

        return $reason;
    }

    private function evalRepositoryName(array $bodyData): string
    {
        if (isset($bodyData['repository'])) {
            return $bodyData['repository']['full_name'];
        }

        return '';
    }

    public function getDescription(): string
    {
        return 'Enrich Tracking Buffer with additional data based on data from GitHub.';
    }
}