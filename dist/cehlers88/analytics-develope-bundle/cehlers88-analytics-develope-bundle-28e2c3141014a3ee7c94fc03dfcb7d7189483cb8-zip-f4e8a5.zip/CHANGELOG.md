# Changelog

## [1.2.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.2.0...v1.2.1) (2026-06-14)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.38.7 ([#66](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/66)) ([7017f28](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/7017f28b290319cedd9a2f020ab190ca4ce876b2))

## [1.2.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.10...v1.2.0) (2026-05-25)


### Features

* add `FetchRepositoryDetailInfosJob` and `EnrichTrackingEntityJob` classes for enhanced repository tracking and data enrichment ([d7494b9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/d7494b9528aeb6b894899a7ce94a66df719bbd22))
* add `GitIssue` custom object class with state and title handling functionality ([d0b5c46](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/d0b5c4668fa78dfcbfa9544e68bcb5a9fcf6eb2f))
* add `GitTrackingBufferWorker` class and integrate it into `FetchRepositoryDetailInfosJob` ([5a08b50](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/5a08b500450e8e23e7740e4fadb10ccaf37a1f55))
* add service tagging for `WorkerInterface` and `JobInterface` in services configuration ([0d932fc](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/0d932fc1e6780a22da946bb793cfef3d8018eab5))


### Miscellaneous Chores

* bump analytics-core to v1.38.5 in composer.lock ([c72b682](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c72b682c8b8c8234a692d2fce89e9fb6fa7730e7))
* refactor: update import path for `SetTrackingBuffersStateToProcessedFinishedJob` in `GitTrackingBufferWorker` ([efe4ba3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/efe4ba34625da98d46bc6aee6f270a594fb0a172))

## [1.1.10](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.9...v1.1.10) (2026-05-24)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.38.1 ([#60](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/60)) ([68e73e7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/68e73e7021154a846e412b69769a1779f79bb19b))
* **deps:** update dependency cehlers88/analytics-core to v1.38.2 ([#63](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/63)) ([ce0b8c8](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/ce0b8c8b8c9bd8760d1c3a4b36015cc609dba85a))
* Update entities to extend AbstractTaggedEntity ([77ddf10](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/77ddf10217e96452a6850bce6e4f6723ed202844))

## [1.1.9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.8...v1.1.9) (2026-05-17)


### Miscellaneous Chores

* bump analytics-core to v1.38.0 in composer.lock ([5237bef](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/5237bef0d838dd5da27b11c1c1e9cc43e4b2ae95))
* refactor: comment out default property initialization in `DevelopWorker` constructor and update `PropertyDTO` import ([1d9db13](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1d9db13d33a0bf5f0939fe0efeff5bf3c220614b))

## [1.1.8](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.7...v1.1.8) (2026-05-16)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.34.0 ([#58](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/58)) ([1896632](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/18966325d2555dc2971c16b3c44ab40645082ff1))

## [1.1.7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.6...v1.1.7) (2026-05-10)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.30.0 ([#56](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/56)) ([1736119](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1736119c884f6939c81896c9cd3a2f3e687f0f13))

## [1.1.6](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.5...v1.1.6) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.2 ([#55](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/55)) ([9d07d4d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/9d07d4dd42139cf512775c92a9648ad6b5df1931))
* Update branch alias format in composer.json files ([6e4fc3d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/6e4fc3d3adec2fbea35c9f796035adc7fdf7b66b))

## [1.1.5](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.4...v1.1.5) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.25.1 ([#52](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/52)) ([af3131c](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/af3131c055b5a89f467ee3213d0b467279ea2f00))

## [1.1.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.3...v1.1.4) (2026-05-02)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.21.0 ([#45](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/45)) ([5739af7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/5739af7452b106198098c77c5774c0fc4e78d472))
* **deps:** update dependency cehlers88/analytics-core to v1.21.2 ([#47](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/47)) ([1841dd5](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1841dd5ff06e4dccaa410c0e7b95fc057ccedace))
* **deps:** update dependency cehlers88/analytics-core to v1.21.3 ([#50](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/50)) ([51b373e](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/51b373e365ca32b54b3fbe06443d87754155ded8))
* **deps:** update dependency cehlers88/analytics-core to v1.22.1 ([#51](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/51)) ([b45e02b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/b45e02b4e103dd826b1bab91de03d19d4ce39620))

## [1.1.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.2...v1.1.3) (2026-04-26)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.20.0 ([#42](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/42)) ([0bcc573](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/0bcc5733b89778c260425d878607cfa60b799186))
* **deps:** update googleapis/release-please-action action to v5 ([#43](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/43)) ([97ef1da](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/97ef1da5a97302e1cbcd952cb794a6b3b4b38b5d))

## [1.1.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.1...v1.1.2) (2026-04-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.16.1 ([#39](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/39)) ([e62deb1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e62deb1e41822ea9cf26d6dd3c96039975deb69d))
* **deps:** update dependency cehlers88/analytics-core to v1.17.0 ([#40](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/40)) ([854a42f](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/854a42f35c83f8b805632cfebea2407865599878))

## [1.1.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.0...v1.1.1) (2026-04-13)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.15.0 ([#36](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/36)) ([2ee44e1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/2ee44e17eab4c5a61af633ec306efd31389b3817))
* **deps:** update dependency cehlers88/analytics-core to v1.16.0 ([#38](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/38)) ([8abd7bf](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/8abd7bf93b3ca9968a0412e043f6fd3661cad092))

## [1.1.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.0.2...v1.1.0) (2026-03-29)


### Features

* add default property initialization in `DevelopWorker` constructor ([f597302](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f597302373e09adc12b6c823badcb8d144d8affe))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.3.13 ([#32](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/32)) ([4ff784b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/4ff784be5157bb20f89a8f197d44c47a15cf63f2))
* **deps:** update dependency cehlers88/analytics-core to v1.4.1 ([#34](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/34)) ([5a113ce](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/5a113cecfddb5adf1b61911b42c82c101bea0872))
* **deps:** update dependency cehlers88/analytics-core to v1.6.0 ([#35](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/35)) ([e10e71c](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e10e71c11a00afe882ec2189b326fa060983e54a))

## [1.0.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.0.1...v1.0.2) (2026-03-26)


### Miscellaneous Chores

* remove unnecessary blank line in `DevelopWorker` class definition ([28d1789](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/28d17890f46d38e55e40a031b5726fe41129c24b))

## [1.0.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.0.0...v1.0.1) (2026-03-26)


### Miscellaneous Chores

* bump analytics-core to v1.3.11 in composer.lock ([33f3c9a](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/33f3c9adede30c77c027d37caf27eab1b3f18343))
* **deps:** update dependency cehlers88/analytics-core to v1.3.10 ([#30](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/30)) ([cd8d0a0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/cd8d0a05e8a5efab8d9b4a46e5633647c08ce007))
* **deps:** update dependency cehlers88/analytics-core to v1.3.6 ([#28](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/28)) ([ae27042](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/ae2704213e10417053d8eaaaebeb7a6bc660348f))
* enhance DevelopWorker with job handling and buffer repository integration ([258c007](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/258c007fd7153ae9c029efb35f4966b6fc2dedb4))
* Upgraded the analytics-core package to v1.3.7 to include the latest changes and improvements. Updated the associated reference, distribution URL, and checksum to match the new version. ([e4d32f0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e4d32f0af6d5181bf7f1f12b11842e9dd53885ee))

## [1.0.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.6...v1.0.0) (2026-03-23)


### ⚠ BREAKING CHANGES

* remove unused configuration group code in AnalyticsDevelopeBundle

### Features

* remove unused configuration group code in AnalyticsDevelopeBundle ([4c36b17](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/4c36b17472a536594f48b6e551ac830f42a08d6e))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.1.3 ([#25](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/25)) ([bcbbee9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/bcbbee91fe16d29397c445a55b520423d3339642))
* **deps:** update dependency cehlers88/analytics-core to v1.3.5 ([#27](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/27)) ([4ec60a9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/4ec60a9218daf1326657b84c540464e24632fe9e))

## [0.2.6](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.5...v0.2.6) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([97744bb](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/97744bbd806fd223df86159c8227786f6d6bac6c))

## [0.2.5](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.4...v0.2.5) (2026-03-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.5.3 ([#20](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/20)) ([1e713ee](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1e713eee6b197f58a5c7eff54e03722eafb044eb))
* **deps:** update dependency cehlers88/analytics-core to v0.5.5 ([#22](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/22)) ([1ac609a](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1ac609af5e6b497c090a8f40428ea8c5d54c2a6d))

## [0.2.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.3...v0.2.4) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.5 ([#19](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/19)) ([8aa417d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/8aa417ddc827e6cbc1d6017006c83fa5805dba30))
* **deps:** update dependency cehlers88/analytics-core to v0.4.2 ([#14](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/14)) ([fa4cfad](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/fa4cfade68493fbae9ed669002814f68d8c088e2))

## [0.2.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.2...v0.2.3) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([b6c385b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/b6c385bad2213abaed7a40b400798863c2a73e47))

## [0.2.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.1...v0.2.2) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([be375b8](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/be375b86faa0a260c12871a6aabfa9b7b1fb5421))

## [0.2.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.0...v0.2.1) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.4 ([#13](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/13)) ([893c765](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/893c765b6be12138a2f34bb22c7e3b9012a6bd9e))

## [0.2.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.4...v0.2.0) (2026-03-19)


### Features

* add DevelopWorker and update dependency to analytics-core ^1 ([fc6d36b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/fc6d36b76ceaee8302502b359007009e7a561fdc))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/9)) ([e0d383c](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e0d383c4664e6ce5698bb6c848ffd36621b011d9))
* downgrade analytics-core dependency to ^0.3 ([1e511c7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1e511c7bade6d3a74a41cc25c1feb9ecf8c56ade))

## [0.1.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.3...v0.1.4) (2026-01-22)


### Miscellaneous Chores

* Update dependency versions for analytics-core ([f2a8d15](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2a8d154ac14f01f7e39afb22b0a6e6d616217ff))

## [0.1.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.2...v0.1.3) (2026-01-21)


### Miscellaneous Chores

* add GitHub Actions workflow to trigger Satis rebuild on release ([7ba6034](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/7ba60343f9c515be0aee3f6ae55be094a75e66a9))

## [0.1.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([cf67e17](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/cf67e17329ebd56e001bb3102676a4439e6ad844))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([f2aae12](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2aae12077ba3b0790fb23eadd527cd40e4d85c8))

## [0.1.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([c39c6af](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c39c6af44469b9065e75f992998cbce6b579bce4))
