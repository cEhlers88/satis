<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 01.11.2025
 * Time: 11:14
 */

namespace Cehlers88\AnalyticsDevelopeBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\DTO\ExtendedRoleDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Observer\ObserverProvider;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsDevelopeBundle\AnalyticsDevelopeBundle;
use Cehlers88\AnalyticsDevelopeBundle\Observer\Message\RemoteDebugObserverMessage;
use Symfony\Component\HttpFoundation\Request;

class RemoteDebugServiceEndpointRunner extends AbstractServiceEndpointRunner
{
    public function __construct(
        private readonly ObserverProvider $observerProvider
    )
    {
    }

    /*public function handleRequest(string $endpointName, Request $request): ServiceEndpointRunnerResultDTO
    {
        $this->observerProvider->dispatch(new RemoteDebugObserverMessage(
            $request->
        ));

        return ServiceEndpointRunnerResultDTO::createSuccess([
            'user' => $this->getUser()->getId(),
        ], 'executed booking');
    }*/

    public function handleRemoteDebug(array $requestData): ServiceEndpointRunnerResultDTO
    {
        $this->observerProvider->dispatch(new RemoteDebugObserverMessage(
            $requestData['source'],
            $requestData['message'] ?? '',
            $requestData['data'] ?? null,
            $requestData['level'] ?? 'debug',
            $requestData['context'] ?? ''
        ));

        return ServiceEndpointRunnerResultDTO::createSuccess($requestData, 'executed remote debug');
    }

    public function getEndpoints(): mixed
    {
        return [
            EndpointDefinitionDTO::create('remoteDebug', ['POST'], [
                PropertyDTO::create('source', '', 'string'),
                PropertyDTO::create('message', '', 'string', true),
                PropertyDTO::create('data', ["foo" => "bar"], 'mixed', true),
                PropertyDTO::create('level', 'debug', 'string', true),
                PropertyDTO::create('context', '', 'string', true),
            ], [], '', [$this, 'handleRemoteDebug']),
        ];
    }

    public function getBundleName(): string
    {
        return AnalyticsDevelopeBundle::NAME;
    }

    public function getRequiredRoles(): array
    {
        return [
            ExtendedRoleDTO::createAnyOf(
                'IS_LAN_DEVICE',
                'ALLOW_REMOTE_DEBUG'
            )
        ];
    }
}