<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Observer\Message;

use Cehlers88\AnalyticsCore\Observer\Message\ObserverMessageInterface;

class RemoteDebugObserverMessage implements ObserverMessageInterface
{
    public const KEY = 'develop.remote_debug';

    public function __construct(
        public string $source,
        public string $message = '',
        public mixed  $data = null,
        public string $level = 'debug',
        public string $context = '',
    )
    {

    }

    public function getKey(): string
    {
        return self::KEY;
    }
}