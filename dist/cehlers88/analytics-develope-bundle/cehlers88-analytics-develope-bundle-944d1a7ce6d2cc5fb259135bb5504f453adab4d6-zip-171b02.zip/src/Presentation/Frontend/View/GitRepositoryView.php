<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Presentation\Frontend\View;

use Cehlers88\AnalyticsCore\DTO\BadgeDTO;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\ViewInterface;

/** View representation of an Application entity. */
class GitRepositoryView extends CustomObjectView implements ViewInterface
{

}