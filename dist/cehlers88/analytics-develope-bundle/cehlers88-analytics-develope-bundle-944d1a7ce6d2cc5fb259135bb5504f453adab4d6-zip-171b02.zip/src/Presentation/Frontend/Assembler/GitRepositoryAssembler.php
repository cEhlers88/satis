<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Backend\JSON\CustomObjectAttributeJson;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\CustomObjectAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitRepository;
use Cehlers88\AnalyticsDevelopeBundle\Presentation\Frontend\View\GitRepositoryView;
use Cehlers88\AnalyticsInfrastructureBundle\CustomObject\SmartDevice;
use Cehlers88\AnalyticsInfrastructureBundle\Presentation\Frontend\View\SmartDeviceView;

class GitRepositoryAssembler extends CustomObjectAssembler
{
    protected string $viewClass = GitRepositoryView::class;

    public function canHandle(string $className): bool
    {
        return $className === GitRepository::class;
    }
}