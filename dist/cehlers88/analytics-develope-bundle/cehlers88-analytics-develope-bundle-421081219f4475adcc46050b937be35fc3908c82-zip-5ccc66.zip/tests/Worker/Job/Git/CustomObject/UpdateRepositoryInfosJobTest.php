<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Worker\Job\Git\CustomObject;

use Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\CustomObject\UpdateRepositoryInfosJob;
use PHPUnit\Framework\TestCase;

class UpdateRepositoryInfosJobTest extends TestCase
{
    public function testTheLinkHeaderTellsWhetherMorePagesFollow(): void
    {
        $next = '<https://api.github.com/repositories/1/issues?page=2>; rel="next", <https://api.github.com/repositories/1/issues?page=3>; rel="last"';
        $last = '<https://api.github.com/repositories/1/issues?page=1>; rel="prev"';

        $this->assertTrue(UpdateRepositoryInfosJob::hasNextPage(['link' => [$next]]));
        $this->assertTrue(UpdateRepositoryInfosJob::hasNextPage(['Link: ' . $next]));
        $this->assertFalse(UpdateRepositoryInfosJob::hasNextPage(['link' => [$last]]));
        $this->assertFalse(UpdateRepositoryInfosJob::hasNextPage([]));
    }
}
