<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\GitHub;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitIssue;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitRepository;
use Cehlers88\AnalyticsDevelopeBundle\GitHub\GitHubWebhookSynchronizer;
use PHPUnit\Framework\TestCase;

class GitHubWebhookSynchronizerTest extends TestCase
{
    private GitRepository $repository;
    private array $saved = [];
    private GitHubWebhookSynchronizer $synchronizer;

    protected function setUp(): void
    {
        $this->repository = new class extends GitRepository {
            public function getId(): int
            {
                return 12;
            }
        };
        $this->repository->setRepositoryPath('cEhlers88/AnalyticsCore');

        $provider = $this->createMock(CustomObjectProvider::class);
        $provider->method('getCustomEntitiesByClassName')->willReturnCallback(
            fn(string $class) => $class === GitRepository::class ? [$this->repository] : []
        );
        $provider->method('createNewCustomEntity')->willReturnCallback(fn(string $class) => new $class());
        $provider->method('save')->willReturnCallback(function ($object) {
            $this->saved[] = $object;
        });

        $this->synchronizer = new GitHubWebhookSynchronizer($provider);
    }

    private static function repositoryPayload(array $repository = []): array
    {
        return $repository + [
            'full_name' => 'cEhlers88/AnalyticsCore',
            'html_url' => 'https://github.com/cEhlers88/AnalyticsCore',
            'default_branch' => 'main',
            'stargazers_count' => 3,
            'open_issues_count' => 2,
        ];
    }

    public function testUntrackedRepositoriesAreIgnored(): void
    {
        $this->assertFalse($this->synchronizer->apply(['repository' => ['full_name' => 'someone/else']], new \DateTimeImmutable()));
        $this->assertFalse($this->synchronizer->apply(['zen' => 'Keep it simple.'], new \DateTimeImmutable()));
        $this->synchronizer->flush();

        $this->assertSame([], $this->saved);
    }

    public function testTheRepositorySnapshotOnlyMovesForward(): void
    {
        $this->assertTrue($this->synchronizer->apply(['repository' => self::repositoryPayload(['full_name' => 'cehlers88/analyticscore', 'stargazers_count' => 5])], new \DateTimeImmutable('2026-10-22 10:00:00 UTC')));
        $this->synchronizer->apply(['repository' => self::repositoryPayload(['stargazers_count' => 4])], new \DateTimeImmutable('2026-10-22 09:00:00 UTC'));
        $this->synchronizer->flush();

        $this->assertSame('5', $this->repository->getAttribute('stargazers_count'));
        $this->assertSame('2026-10-22T10:00:00Z', $this->repository->getAttribute('webhook_received_at'));
        $this->assertSame('cEhlers88/AnalyticsCore', $this->repository->getRepositoryPath());
        $this->assertSame([$this->repository], $this->saved);
    }

    public function testWorkflowRunsOfTheDefaultBranchSetTheCiStatus(): void
    {
        $run = fn(string $branch, string $status, ?string $conclusion, string $updatedAt) => [
            'repository' => self::repositoryPayload(),
            'workflow_run' => ['head_branch' => $branch, 'status' => $status, 'conclusion' => $conclusion,
                'name' => 'CI', 'html_url' => 'https://github.com/run/1', 'updated_at' => $updatedAt],
        ];
        $now = new \DateTimeImmutable();

        $this->synchronizer->apply($run('main', 'completed', 'failure', '2026-10-22T10:00:00Z'), $now);
        $this->synchronizer->apply($run('feature', 'completed', 'success', '2026-10-22T11:00:00Z'), $now);
        $this->synchronizer->apply($run('main', 'in_progress', null, '2026-10-22T09:00:00Z'), $now);

        $this->assertSame('failure', $this->repository->getAttribute('ci_status'));
        $this->assertSame('https://github.com/run/1', $this->repository->getAttribute('ci_run_url'));
    }

    public function testPublishedReleasesAndOpenPullRequests(): void
    {
        $now = new \DateTimeImmutable();
        $this->synchronizer->apply(['action' => 'published', 'repository' => self::repositoryPayload(),
            'release' => ['tag_name' => 'v1.67.0', 'published_at' => '2026-10-21T21:15:22Z', 'draft' => false, 'prerelease' => false]], $now);
        $this->synchronizer->apply(['action' => 'published', 'repository' => self::repositoryPayload(),
            'release' => ['tag_name' => 'v2.0.0-rc1', 'published_at' => '2026-10-22T00:00:00Z', 'prerelease' => true]], $now);

        foreach ([[5, 'open'], [6, 'open'], [5, 'closed'], [7, 'open'], [6, 'open']] as [$number, $state]) {
            $this->synchronizer->apply(['action' => 'x', 'repository' => self::repositoryPayload(),
                'pull_request' => ['number' => $number, 'state' => $state]], $now);
        }

        $this->assertSame('v1.67.0', $this->repository->getAttribute('latest_release_tag'));
        $this->assertSame('2026-10-21T21:15:22Z', $this->repository->getAttribute('latest_release_published_at'));
        $this->assertSame('[6,7]', $this->repository->getAttribute('open_pull_requests'));
        $this->assertSame('2', $this->repository->getAttribute('open_pull_requests_count'));
    }

    public function testIssuesAreCreatedOnceAndUpdatedByNewerEvents(): void
    {
        $issue = fn(string $title, string $state, string $updatedAt) => [
            'number' => 91, 'title' => $title, 'state' => $state, 'updated_at' => $updatedAt,
            'labels' => [['name' => 'bug', 'color' => 'd73a4a']], 'user' => ['login' => 'cEhlers88'],
        ];
        $now = new \DateTimeImmutable();

        $this->synchronizer->apply(['action' => 'opened', 'repository' => self::repositoryPayload(), 'issue' => $issue('Bug', 'open', '2026-10-22T08:00:00Z')], $now);
        $this->synchronizer->apply(['action' => 'closed', 'repository' => self::repositoryPayload(), 'issue' => $issue('Bug fixed', 'closed', '2026-10-22T09:00:00Z')], $now);
        $this->synchronizer->apply(['action' => 'edited', 'repository' => self::repositoryPayload(), 'issue' => $issue('Old', 'open', '2026-10-22T08:30:00Z')], $now);
        // Comments on pull requests come as issue events; they are no issues.
        $this->synchronizer->apply(['action' => 'created', 'repository' => self::repositoryPayload(),
            'issue' => ['number' => 92, 'pull_request' => ['url' => '…']] + $issue('PR', 'open', '2026-10-22T08:00:00Z')], $now);
        $this->synchronizer->flush();

        $issues = array_values(array_filter($this->saved, fn($object) => $object instanceof GitIssue));
        $this->assertCount(1, $issues);
        $this->assertSame(12, $issues[0]->getParentId());
        $this->assertSame('Bug fixed', $issues[0]->getName());
        $this->assertSame('closed', $issues[0]->getState());
        $this->assertSame('[{"name":"bug","color":"d73a4a"}]', $issues[0]->getAttribute('labels'));
        $this->assertSame([$issues[0]], $this->repository->getChildObjects());
    }

    public function testAKnownIssueIsFoundAmongTheChildren(): void
    {
        $known = new class extends GitIssue {
            public function getId(): int
            {
                return 40;
            }
        };
        $known->setAttribute('number', '91')->setAttribute('updated_at', '2026-10-22T08:00:00Z');
        $this->repository->setChildObjects([$known]);

        $this->synchronizer->apply(['action' => 'deleted', 'repository' => self::repositoryPayload(),
            'issue' => ['number' => 91, 'title' => 'Gone', 'state' => 'open', 'updated_at' => '2026-10-22T09:00:00Z']], new \DateTimeImmutable());
        $this->synchronizer->flush();

        $this->assertSame('closed', $known->getState());
        $this->assertSame('deleted', $known->getAttribute('state_reason'));
        $this->assertContains($known, $this->saved);
        $this->assertCount(1, $this->repository->getChildObjects());
    }
}
