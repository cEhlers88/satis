<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\GitHub;

use Cehlers88\AnalyticsDevelopeBundle\GitHub\GitHubAttributeMapper;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class GitHubAttributeMapperTest extends TestCase
{
    public function testARepositoryBecomesFlatStringAttributes(): void
    {
        $attributes = GitHubAttributeMapper::mapRepository([
            'full_name' => 'cEhlers88/AnalyticsCore',
            'description' => null,
            'html_url' => 'https://github.com/cEhlers88/AnalyticsCore',
            'private' => true,
            'archived' => false,
            'fork' => false,
            'default_branch' => 'main',
            'license' => ['spdx_id' => 'MIT'],
            'stargazers_count' => 3,
            'watchers_count' => 3,
            'forks_count' => 0,
            'open_issues_count' => 7,
            'topics' => ['symfony', 'analytics'],
            'pushed_at' => 1729576800,
        ]);

        $this->assertSame([
            'full_name' => 'cEhlers88/AnalyticsCore',
            'description' => '',
            'html_url' => 'https://github.com/cEhlers88/AnalyticsCore',
            'visibility' => 'private',
            'archived' => '0',
            'fork' => '0',
            'default_branch' => 'main',
            'license_spdx_id' => 'MIT',
            'stargazers_count' => '3',
            'forks_count' => '0',
            'open_issues_and_pull_requests_count' => '7',
            'topics' => '["symfony","analytics"]',
            'pushed_at' => '2024-10-22T06:00:00Z',
        ], $attributes);
    }

    public function testWatchersComeOnlyFromTheRestResponse(): void
    {
        $this->assertSame('2', GitHubAttributeMapper::mapRepository(['subscribers_count' => 2])['subscribers_count']);
        $this->assertArrayNotHasKey('subscribers_count', GitHubAttributeMapper::mapRepository(['watchers_count' => 2]));
    }

    public function testAnIssueKeepsWhatTheTileShows(): void
    {
        $attributes = GitHubAttributeMapper::mapIssue([
            'number' => 91,
            'title' => 'Tile for GitRepository',
            'state' => 'closed',
            'state_reason' => 'completed',
            'html_url' => 'https://github.com/o/r/issues/91',
            'user' => ['login' => 'cEhlers88'],
            'labels' => [['name' => 'bug', 'color' => 'd73a4a', 'id' => 1]],
            'assignees' => [['login' => 'a'], ['login' => 'b']],
            'comments' => 4,
            'milestone' => null,
            'created_at' => '2026-09-10T08:12:00Z',
            'updated_at' => '2026-09-12T21:03:00+02:00',
            'closed_at' => '2026-09-12T19:03:00Z',
            'body' => str_repeat('x', 600),
        ]);

        $this->assertSame('91', $attributes['number']);
        $this->assertSame('[{"name":"bug","color":"d73a4a"}]', $attributes['labels']);
        $this->assertSame('["a","b"]', $attributes['assignees']);
        $this->assertSame('cEhlers88', $attributes['user_login']);
        $this->assertNull($attributes['milestone_title']);
        $this->assertSame('2026-09-12T19:03:00Z', $attributes['updated_at']);
        $this->assertSame(501, mb_strlen($attributes['body']));
    }

    public static function workflowRuns(): array
    {
        return [
            'success' => [['status' => 'completed', 'conclusion' => 'success'], 'success'],
            'skipped' => [['status' => 'completed', 'conclusion' => 'skipped'], 'success'],
            'failure' => [['status' => 'completed', 'conclusion' => 'failure'], 'failure'],
            'timed out' => [['status' => 'completed', 'conclusion' => 'timed_out'], 'failure'],
            'cancelled' => [['status' => 'completed', 'conclusion' => 'cancelled'], 'cancelled'],
            'running' => [['status' => 'in_progress', 'conclusion' => null], 'in_progress'],
            'requested' => [['status' => 'requested'], 'queued'],
        ];
    }

    #[DataProvider('workflowRuns')]
    public function testTheCiStatusOfAWorkflowRun(array $run, string $status): void
    {
        $this->assertSame($status, GitHubAttributeMapper::ciStatus($run));
    }

    public function testTimesCompareAsStrings(): void
    {
        $this->assertTrue(GitHubAttributeMapper::isNotOlder('2026-01-02T00:00:00Z', null));
        $this->assertTrue(GitHubAttributeMapper::isNotOlder('2026-01-02T00:00:00Z', '2026-01-02T00:00:00Z'));
        $this->assertFalse(GitHubAttributeMapper::isNotOlder('2026-01-01T23:59:59Z', '2026-01-02T00:00:00Z'));
        $this->assertFalse(GitHubAttributeMapper::isNotOlder(null, '2026-01-02T00:00:00Z'));
        $this->assertNull(GitHubAttributeMapper::timestamp('no date'));
    }
}
