<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\GitHub;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitIssue;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitRepository;
use Cehlers88\AnalyticsDevelopeBundle\GitHub\GitHubIssueSynchronizer;
use Cehlers88\AnalyticsDevelopeBundle\GitHub\GitHubWebhookSynchronizer;
use PHPUnit\Framework\TestCase;

class GitHubIssueSynchronizerTest extends TestCase
{
    private GitRepository $repository;
    private array $saved = [];
    private CustomObjectProvider $provider;
    private GitHubIssueSynchronizer $synchronizer;

    protected function setUp(): void
    {
        $this->repository = new class extends GitRepository {
            public function getId(): int
            {
                return 12;
            }
        };
        $this->repository->setRepositoryPath('cEhlers88/AnalyticsCore');
        // What GitHub's repository response brings: 2 issues + 1 pull request.
        $this->repository->setAttribute('open_issues_and_pull_requests_count', '3');

        $this->provider = $this->createStub(CustomObjectProvider::class);
        $this->provider->method('getCustomEntitiesByClassName')->willReturnCallback(
            fn(string $class) => $class === GitRepository::class ? [$this->repository] : []
        );
        $this->provider->method('createNewCustomEntity')->willReturnCallback(fn(string $class) => new $class());
        $this->provider->method('save')->willReturnCallback(function ($object) {
            $this->saved[] = $object;
        });

        $this->synchronizer = new GitHubIssueSynchronizer($this->provider);
    }

    private static function issue(int $number, string $title, string $updatedAt = '2026-10-22T08:00:00Z', array $extra = []): array
    {
        return $extra + [
            'number' => $number, 'title' => $title, 'state' => 'open', 'updated_at' => $updatedAt,
            'labels' => [['name' => 'bug', 'color' => 'd73a4a']], 'user' => ['login' => 'cEhlers88'],
        ];
    }

    private static function knownIssue(int $id, int $number, string $updatedAt): GitIssue
    {
        $issue = new class extends GitIssue {
            public int $id = 0;

            public function getId(): int
            {
                return $this->id;
            }
        };
        $issue->id = $id;
        $issue->setAttribute('number', (string)$number)->setAttribute('updated_at', $updatedAt)->setState('open');

        return $issue;
    }

    public function testPullRequestsAreNoIssues(): void
    {
        $this->synchronizer->apply($this->repository, [
            self::issue(1, 'First'),
            self::issue(2, 'Second'),
            self::issue(3, 'A pull request', extra: ['pull_request' => ['url' => '…']]),
        ], true, new \DateTimeImmutable('2026-10-24T10:00:00Z'));

        $this->assertCount(2, $this->saved);
        $this->assertSame(['First', 'Second'], array_map(fn(GitIssue $issue) => $issue->getName(), $this->saved));
        $this->assertSame(12, $this->saved[0]->getParentId());
        $this->assertSame('[{"name":"bug","color":"d73a4a"}]', $this->saved[0]->getAttribute('labels'));
        $this->assertSame($this->saved, $this->repository->getChildObjects());

        $this->assertSame('2', $this->repository->getAttribute('open_issues_count'));
        $this->assertSame('[3]', $this->repository->getAttribute('open_pull_requests'));
        $this->assertSame('1', $this->repository->getAttribute('open_pull_requests_count'));
        $this->assertSame('2026-10-24T10:00:00Z', $this->repository->getAttribute('issues_synced_at'));
    }

    public function testKnownIssuesAreUpdatedAndMissingOnesClosed(): void
    {
        $updated = self::knownIssue(40, 1, '2026-10-22T08:00:00Z');
        $newerByWebhook = self::knownIssue(41, 2, '2026-10-23T08:00:00Z');
        $gone = self::knownIssue(42, 3, '2026-10-22T08:00:00Z');
        $this->repository->setChildObjects([$updated, $newerByWebhook, $gone]);

        $this->synchronizer->apply($this->repository, [
            self::issue(1, 'Renamed', '2026-10-22T09:00:00Z'),
            self::issue(2, 'Stale', '2026-10-22T09:00:00Z'),
        ], true, new \DateTimeImmutable());

        $this->assertSame('Renamed', $updated->getName());
        $this->assertNotSame('Stale', $newerByWebhook->getName());
        $this->assertSame('closed', $gone->getState());
        $this->assertSame([$updated, $gone], $this->saved);
        $this->assertCount(3, $this->repository->getChildObjects());
        $this->assertSame('2', $this->repository->getAttribute('open_issues_count'));
    }

    public function testAnIncompleteListNeitherClosesNorCountsExactly(): void
    {
        $notOnThisPage = self::knownIssue(42, 9, '2026-10-22T08:00:00Z');
        $this->repository->setChildObjects([$notOnThisPage]);
        $this->repository->setAttribute('open_issues_and_pull_requests_count', '40');
        $this->repository->setAttribute('issues_synced_at', '2026-10-20T10:00:00Z');

        $this->synchronizer->apply($this->repository, [
            self::issue(1, 'First'),
            self::issue(3, 'A pull request', extra: ['pull_request' => ['url' => '…']]),
        ], false, new \DateTimeImmutable());

        $this->assertSame('open', $notOnThisPage->getState());
        $this->assertSame('39', $this->repository->getAttribute('open_issues_count'));
        $this->assertFalse($this->repository->hasAttribute('open_pull_requests_count'));
        $this->assertFalse($this->repository->hasAttribute('issues_synced_at'));
    }

    public function testWebhooksRecountOnceTheIssuesWereSynced(): void
    {
        $this->synchronizer->apply($this->repository, [self::issue(1, 'First'), self::issue(2, 'Second')], true, new \DateTimeImmutable());
        $this->assertSame('2', $this->repository->getAttribute('open_issues_count'));

        $webhooks = new GitHubWebhookSynchronizer($this->provider);
        $webhooks->apply([
            'action' => 'closed',
            'repository' => ['full_name' => 'cEhlers88/AnalyticsCore', 'open_issues_count' => 5],
            'issue' => self::issue(2, 'Second', '2026-10-22T09:00:00Z', ['state' => 'closed']),
        ], new \DateTimeImmutable());
        $webhooks->flush();

        $this->assertSame('1', $this->repository->getAttribute('open_issues_count'));
        $this->assertSame('5', $this->repository->getAttribute('open_issues_and_pull_requests_count'));
    }
}
