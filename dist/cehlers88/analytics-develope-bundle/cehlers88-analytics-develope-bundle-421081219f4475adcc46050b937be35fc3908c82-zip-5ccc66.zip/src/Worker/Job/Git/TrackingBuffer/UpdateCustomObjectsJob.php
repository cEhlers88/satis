<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\TrackingBuffer;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Cehlers88\AnalyticsDevelopeBundle\GitHub\GitHubWebhookSynchronizer;

/**
 * Brings the GitRepository / GitIssue custom objects up to date with the received webhooks.
 * Runs on the end so the buffers can be applied oldest first; each buffer is applied once
 * and marked with handlerData[HANDLER_DATA_KEY] (true when it belonged to a tracked repository).
 */
class UpdateCustomObjectsJob extends AbstractWorkerJob
{
    public const HANDLER_DATA_KEY = 'customObjectsUpdated';

    /** @var TrackingBuffer[] */
    private array $buffers = [];

    public function __construct(
        private readonly GitHubWebhookSynchronizer $synchronizer,
    )
    {
        $this->setType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_END);
    }

    public function willHandle(object $workingObject): bool
    {
        return $workingObject instanceof TrackingBuffer
            && !array_key_exists(self::HANDLER_DATA_KEY, $workingObject->getHandlerData() ?? []);
    }

    /**
     * @param TrackingBuffer $object
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $this->buffers[] = $object;

        return $this;
    }

    protected function startJob(): void
    {
        $this->buffers = [];
        $this->synchronizer->reset();
    }

    protected function finishJob(): void
    {
        usort($this->buffers, fn(TrackingBuffer $a, TrackingBuffer $b) => ($a->getId() ?? PHP_INT_MAX) <=> ($b->getId() ?? PHP_INT_MAX));

        foreach ($this->buffers as $buffer) {
            $body = $buffer->getData()['body'] ?? null;
            if (is_string($body)) {
                $body = json_decode($body, true);
            }

            $handlerData = $buffer->getHandlerData() ?? [];
            try {
                $handlerData[self::HANDLER_DATA_KEY] = is_array($body)
                    && $this->synchronizer->apply($body, $buffer->getCreatedAt() ?? new \DateTimeImmutable());
            } catch (\Throwable $e) {
                $this->logWarning(sprintf('Tracking buffer %s: custom objects not updated: %s', $buffer->getId(), $e->getMessage()));
                continue;
            }
            $buffer->setHandlerData($handlerData);
        }

        try {
            $this->synchronizer->flush();
        } catch (\Throwable $e) {
            $this->logWarning('Saving the git custom objects failed: ' . $e->getMessage());
        }
        $this->buffers = [];

        parent::finishJob();
    }

    public function getDescription(): string
    {
        return 'Update the GitRepository and GitIssue custom objects with the data from GitHub webhooks.';
    }
}
