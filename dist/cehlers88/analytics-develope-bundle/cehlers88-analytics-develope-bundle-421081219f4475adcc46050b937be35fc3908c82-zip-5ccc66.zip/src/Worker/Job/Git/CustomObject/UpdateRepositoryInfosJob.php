<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\CustomObject;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Executor\ExecutorInterface;
use Cehlers88\AnalyticsCore\Executor\ExecutorProvider;
use Cehlers88\AnalyticsCore\Executor\ExternalServiceExecutor;
use Cehlers88\AnalyticsCore\Support\DTO\CurlResponseDTO;
use Cehlers88\AnalyticsCore\Support\Logging\SimpleConsoleLogger;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitRepository;
use Cehlers88\AnalyticsDevelopeBundle\GitHub\GitHubAttributeMapper;
use Cehlers88\AnalyticsDevelopeBundle\GitHub\GitHubIssueSynchronizer;

class UpdateRepositoryInfosJob extends AbstractWorkerJob
{
    public function __construct(
        private readonly ExecutorProvider        $executorProvider,
        private readonly CustomObjectProvider    $customObjectProvider,
        private readonly GitHubIssueSynchronizer $issueSynchronizer,
    )
    {
        $this->setType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_END);
    }

    /**
     * @param GitRepository $object
     * @return AbstractWorkerJob
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $repository = $this->callGitHub('getRepository', $object);
        if ($repository !== null) {
            $object->setAttribute('raw', json_encode($repository->body));

            $body = self::decode($repository->body);
            if (is_array($body)) {
                foreach (GitHubAttributeMapper::mapRepository($body) as $name => $value) {
                    $object->setAttribute($name, $value);
                }
            }
        }

        // The repository's open_issues_count includes the pull requests, the issue list tells them apart.
        $issues = $this->callGitHub('getIssues', $object);
        if ($issues !== null) {
            $items = self::decode($issues->body);
            if (is_array($items) && array_is_list($items)) {
                $this->issueSynchronizer->apply(
                    $object,
                    $items,
                    !self::hasNextPage($issues->headers),
                    new \DateTimeImmutable()
                );
            }
        }

        $this->customObjectProvider->save($object);

        return $this;
    }

    /** The response of a successful call, null otherwise. */
    private function callGitHub(string $functionName, GitRepository $object): ?CurlResponseDTO
    {
        $exec = $this->getExternalServiceExecutor();
        $exec
            ->setPropertyValue(ExternalServiceExecutor::KEY_SERVICE_NAME, 'GitHub')
            ->setPropertyValue(ExternalServiceExecutor::KEY_FUNCTION_NAME, $functionName)
            ->setPropertyValue(ExternalServiceExecutor::KEY_ARGUMENTS, ["repositoryName" => $object->getRepositoryPath()])
            ->setPropertyValue(ExternalServiceExecutor::KEY_OPTIONS, []);

        $exec->enableDebugMode(true);
        $exec->setLogger(new SimpleConsoleLogger());
        $exec->run();

        $lastResult = $exec->getLastResult();

        return $lastResult instanceof CurlResponseDTO && $lastResult->statusCode === 200 ? $lastResult : null;
    }

    private static function decode(mixed $body): mixed
    {
        return is_string($body) ? json_decode($body, true) : json_decode(json_encode($body), true);
    }

    /** GitHub pages lists and names the next page in the Link header. */
    public static function hasNextPage(array $headers): bool
    {
        foreach ($headers as $name => $value) {
            $line = is_string($name) ? $name . ': ' . implode(', ', (array)$value) : implode(', ', (array)$value);
            if (stripos($line, 'link:') === 0 && str_contains($line, 'rel="next"')) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return ExternalServiceExecutor
     */
    private function getExternalServiceExecutor(): ExecutorInterface
    {
        return $this->executorProvider->getExecutor(ExternalServiceExecutor::class);
    }

    public function getDescription(): string
    {
        return 'Update the repository and its issues from the GitHub REST API.';
    }
}