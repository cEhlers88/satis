<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitIssue;

/** Same JSON decoding as for the repository, for issues shown on their own. */
class GitIssueAssembler extends GitRepositoryAssembler
{
    protected string $viewClass = CustomObjectView::class;

    public function canHandle(string $className): bool
    {
        return $className === GitIssue::class;
    }
}
