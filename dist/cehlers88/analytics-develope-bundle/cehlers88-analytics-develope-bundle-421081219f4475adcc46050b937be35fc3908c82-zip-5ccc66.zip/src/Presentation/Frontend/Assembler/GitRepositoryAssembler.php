<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\CustomObjectAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitRepository;
use Cehlers88\AnalyticsDevelopeBundle\GitHub\GitHubAttributeMapper;
use Cehlers88\AnalyticsDevelopeBundle\Presentation\Frontend\View\GitRepositoryView;

class GitRepositoryAssembler extends CustomObjectAssembler
{
    protected string $viewClass = GitRepositoryView::class;

    public function canHandle(string $className): bool
    {
        return $className === GitRepository::class;
    }

    /**
     * Lists and maps are stored as JSON strings; the tiles want them as arrays.
     * The GitIssue children are assembled by this assembler as well, so it covers their attributes too.
     */
    protected function enrichView(EntityInterface|AbstractCustomObject $entity, CustomObjectView $view): CustomObjectView
    {
        foreach (GitHubAttributeMapper::JSON_ATTRIBUTES as $name) {
            $value = $view->attribute->{$name} ?? null;
            if (!is_string($value)) {
                continue;
            }
            $decoded = json_decode($value, true);
            if (is_array($decoded)) {
                $view->attribute->{$name} = $decoded;
            }
        }

        return $view;
    }
}
