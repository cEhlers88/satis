<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\GitHub;

/**
 * Turns GitHub payloads (webhooks as well as REST responses) into the flat attributes the
 * GitRepository and GitIssue custom objects keep.
 *
 * Attribute values are stored as strings (CustomEntityAttribute::$value is a TEXT column):
 * lists and maps are JSON encoded - the names in JSON_ATTRIBUTES - and timestamps are
 * normalized to UTC ISO 8601, so that comparing two of them as strings compares the times.
 */
final class GitHubAttributeMapper
{
    public const JSON_ATTRIBUTES = ['labels', 'assignees', 'topics', 'languages', 'open_pull_requests'];

    private const MAX_BODY_LENGTH = 500;

    /**
     * Only what every repository payload carries. Values that need further API calls
     * (languages, latest release, ...) are filled elsewhere and are left untouched here.
     */
    public static function mapRepository(array $repository): array
    {
        $attributes = [
            'full_name' => $repository['full_name'] ?? null,
            'description' => $repository['description'] ?? '',
            'html_url' => $repository['html_url'] ?? null,
            'visibility' => $repository['visibility'] ?? (isset($repository['private']) ? ($repository['private'] ? 'private' : 'public') : null),
            'archived' => $repository['archived'] ?? null,
            'fork' => $repository['fork'] ?? null,
            'default_branch' => $repository['default_branch'] ?? null,
            'license_spdx_id' => is_array($repository['license'] ?? null) ? ($repository['license']['spdx_id'] ?? null) : null,
            'stargazers_count' => $repository['stargazers_count'] ?? null,
            'forks_count' => $repository['forks_count'] ?? null,
            // GitHub counts open pull requests as issues too; open_issues_count itself is
            // counted from the issues by GitHubIssueSynchronizer.
            'open_issues_and_pull_requests_count' => $repository['open_issues_count'] ?? null,
            'topics' => $repository['topics'] ?? null,
            'pushed_at' => self::timestamp($repository['pushed_at'] ?? null),
        ];
        // Only the REST response knows the watchers; in webhooks "watchers_count" means stars.
        if (array_key_exists('subscribers_count', $repository)) {
            $attributes['subscribers_count'] = $repository['subscribers_count'];
        }

        return self::toAttributeValues(array_filter($attributes, fn($value) => $value !== null));
    }

    public static function mapIssue(array $issue): array
    {
        $body = (string)($issue['body'] ?? '');
        if (mb_strlen($body) > self::MAX_BODY_LENGTH) {
            $body = mb_substr($body, 0, self::MAX_BODY_LENGTH) . '…';
        }

        return self::toAttributeValues([
            'number' => $issue['number'] ?? null,
            'title' => $issue['title'] ?? '',
            'state' => $issue['state'] ?? 'open',
            'state_reason' => $issue['state_reason'] ?? null,
            'html_url' => $issue['html_url'] ?? null,
            'user_login' => $issue['user']['login'] ?? null,
            'labels' => array_values(array_map(
                fn($label) => is_array($label)
                    ? ['name' => $label['name'] ?? '', 'color' => $label['color'] ?? null]
                    : ['name' => (string)$label, 'color' => null],
                $issue['labels'] ?? []
            )),
            'assignees' => array_values(array_filter(array_map(
                fn($assignee) => is_array($assignee) ? ($assignee['login'] ?? null) : $assignee,
                $issue['assignees'] ?? []
            ))),
            'comments' => $issue['comments'] ?? 0,
            'milestone_title' => $issue['milestone']['title'] ?? null,
            'created_at' => self::timestamp($issue['created_at'] ?? null),
            'updated_at' => self::timestamp($issue['updated_at'] ?? null),
            'closed_at' => self::timestamp($issue['closed_at'] ?? null),
            'body' => $body,
        ]);
    }

    /**
     * The value the repository tile shows for a workflow run: the conclusion once it is
     * completed, otherwise whether it runs or waits.
     */
    public static function ciStatus(array $workflowRun): string
    {
        $status = $workflowRun['status'] ?? '';
        if ($status === 'in_progress') {
            return 'in_progress';
        }
        if ($status !== 'completed') {
            return 'queued';
        }

        return match ($workflowRun['conclusion'] ?? '') {
            'success', 'neutral', 'skipped' => 'success',
            'cancelled' => 'cancelled',
            default => 'failure',
        };
    }

    /** GitHub sends ISO strings, but unix timestamps for "pushed_at" in push events. */
    public static function timestamp(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        try {
            $date = is_int($value) || (is_string($value) && ctype_digit($value))
                ? new \DateTimeImmutable('@' . $value)
                : new \DateTimeImmutable((string)$value);
        } catch (\Exception) {
            return null;
        }

        return $date->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d\TH:i:s\Z');
    }

    /** True when $candidate is not older than $current (missing values count as oldest). */
    public static function isNotOlder(?string $candidate, ?string $current): bool
    {
        if ($current === null || $current === '') {
            return true;
        }
        if ($candidate === null || $candidate === '') {
            return false;
        }

        return strcmp($candidate, $current) >= 0;
    }

    public static function toAttributeValue(mixed $value): ?string
    {
        return match (true) {
            $value === null => null,
            is_bool($value) => $value ? '1' : '0',
            is_array($value) => json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            default => (string)$value,
        };
    }

    private static function toAttributeValues(array $attributes): array
    {
        return array_map(self::toAttributeValue(...), $attributes);
    }
}
