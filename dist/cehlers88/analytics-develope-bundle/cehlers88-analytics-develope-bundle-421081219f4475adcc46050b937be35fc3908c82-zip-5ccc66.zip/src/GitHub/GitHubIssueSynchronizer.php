<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\GitHub;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitIssue;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitRepository;

/**
 * Applies the REST list of a repository's issues ("GET /repos/{owner}/{repo}/issues") to its
 * GitIssue children and counts them.
 *
 * GitHub lists pull requests as issues as well (they carry a "pull_request" key), and the
 * repository's own open_issues_count counts both. So the pull requests are taken out here, and
 * open_issues_count of the GitRepository becomes the number of open issues only; GitHub's
 * number is kept as open_issues_and_pull_requests_count.
 *
 * Issues are saved here, the repository is left for the caller to save.
 */
final class GitHubIssueSynchronizer
{
    public function __construct(
        private readonly CustomObjectProvider $customObjectProvider,
    )
    {
    }

    /**
     * @param array $items    the decoded response: issues and pull requests
     * @param bool  $complete false when GitHub has further pages - then issues missing from
     *                        $items are not closed, and the count is estimated
     */
    public function apply(GitRepository $repository, array $items, bool $complete, \DateTimeInterface $syncedAt): void
    {
        $issues = [];
        $openPullRequests = [];
        foreach ($items as $item) {
            if (!is_array($item) || !isset($item['number'])) {
                continue;
            }
            if (array_key_exists('pull_request', $item)) {
                if (($item['state'] ?? 'open') === 'open') {
                    $openPullRequests[] = (int)$item['number'];
                }
                continue;
            }
            $issues[(int)$item['number']] = $item;
        }

        $children = $this->issuesByNumber($repository);
        $newIssues = [];

        foreach ($issues as $number => $issueData) {
            $attributes = GitHubAttributeMapper::mapIssue($issueData);
            $issue = $children[$number] ?? null;

            if ($issue === null) {
                $issue = $this->customObjectProvider->createNewCustomEntity(GitIssue::class);
                $issue->setParentId($repository->getId());
                $children[$number] = $issue;
                $newIssues[] = $issue;
            } elseif (!GitHubAttributeMapper::isNotOlder($attributes['updated_at'], $issue->getAttribute('updated_at'))) {
                // A webhook already brought a newer state.
                continue;
            }

            $issue->setName($attributes['title'] !== '' ? $attributes['title'] : '#' . $number);
            $this->setAttributes($issue, $attributes);
        }

        // A complete list holds every open issue, so an open child missing from it was closed,
        // deleted or transferred without a webhook telling us.
        if ($complete) {
            foreach ($children as $number => $issue) {
                if (!isset($issues[$number]) && $issue->getState() === GitIssue::STATE_OPEN) {
                    $this->setAttributes($issue, ['state' => GitIssue::STATE_CLOSED]);
                }
            }
        }

        if ($newIssues !== []) {
            $repository->setChildObjects([...$repository->getChildObjects(), ...$newIssues]);
        }

        $openIssues = self::countOpenIssues($repository);
        $attributes = [
            'open_issues_count' => (string)$openIssues,
            'issues_synced_at' => GitHubAttributeMapper::timestamp($syncedAt->format(\DateTimeInterface::ATOM)),
        ];

        if ($complete) {
            sort($openPullRequests);
            $attributes['open_pull_requests'] = GitHubAttributeMapper::toAttributeValue($openPullRequests);
            $attributes['open_pull_requests_count'] = (string)count($openPullRequests);
        } else {
            // Only one page: GitHub's total minus the pull requests seen is closer than either number.
            $total = $repository->getAttribute('open_issues_and_pull_requests_count');
            if (is_numeric($total)) {
                $attributes['open_issues_count'] = (string)max($openIssues, (int)$total - count($openPullRequests));
            }
            // Without the full set of issues the webhooks must not recount them.
            unset($attributes['issues_synced_at']);
            $repository->removeAttribute('issues_synced_at');
        }

        foreach ($attributes as $name => $value) {
            $repository->setAttribute($name, $value);
        }
    }

    /**
     * Number of open GitIssue children - the open_issues_count once a complete list was synced.
     */
    public static function countOpenIssues(GitRepository $repository): int
    {
        return count(array_filter(
            $repository->getChildObjects(),
            fn($child) => $child instanceof GitIssue && $child->getState() === GitIssue::STATE_OPEN
        ));
    }

    /** @return array<int, GitIssue> */
    private function issuesByNumber(GitRepository $repository): array
    {
        $issues = [];
        foreach ($repository->getChildObjects() as $child) {
            if ($child instanceof GitIssue && is_numeric($child->getAttribute('number'))) {
                $issues[(int)$child->getAttribute('number')] = $child;
            }
        }

        return $issues;
    }

    /** Sets the attributes and saves the issue if anything differs (or it is new). */
    private function setAttributes(GitIssue $issue, array $attributes): void
    {
        $changed = false;
        foreach ($attributes as $name => $value) {
            if ($issue->hasAttribute($name) && $issue->getAttribute($name) === $value) {
                continue;
            }
            if (!$issue->hasAttribute($name) && $value === null) {
                continue;
            }
            $issue->setAttribute($name, $value);
            $changed = true;
        }

        if ($changed || $issue->getId() <= 0) {
            $this->customObjectProvider->save($issue);
        }
    }
}
