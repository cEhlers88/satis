<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\GitHub;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitIssue;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitRepository;

/**
 * Applies GitHub webhook payloads to the GitRepository custom objects (matched by their
 * repository_path) and their GitIssue children. Repositories nobody created a custom object
 * for are ignored; issues of a known repository are created on their first event.
 *
 * Payloads may arrive late or twice, so each kind of value only moves forward in time:
 * the repository snapshot by the time the webhook was received, issues by their updated_at,
 * the CI status by the run's updated_at and the release by its published_at.
 *
 * Changes are collected and written once by flush(): a new GitIssue gets no id back from
 * CustomObjectProvider::save(), so saving it twice would store it twice.
 */
final class GitHubWebhookSynchronizer
{
    /** @var array<string, GitRepository>|null lower-cased repository path => object */
    private ?array $repositories = null;

    /** @var array<int, GitRepository|GitIssue> spl_object_id => object */
    private array $changed = [];

    public function __construct(
        private readonly CustomObjectProvider $customObjectProvider,
    )
    {
    }

    /** Forget the loaded objects, e.g. at the start of a worker run. */
    public function reset(): void
    {
        $this->repositories = null;
        $this->changed = [];
    }

    /**
     * @return bool whether the payload belongs to a tracked repository
     */
    public function apply(array $payload, \DateTimeInterface $receivedAt): bool
    {
        $repositoryData = $payload['repository'] ?? null;
        if (!is_array($repositoryData) || empty($repositoryData['full_name'])) {
            return false;
        }

        $repository = $this->findRepository((string)$repositoryData['full_name']);
        if ($repository === null) {
            return false;
        }

        $received = GitHubAttributeMapper::timestamp($receivedAt->format(\DateTimeInterface::ATOM));
        if (GitHubAttributeMapper::isNotOlder($received, $repository->getAttribute('webhook_received_at'))) {
            $this->setAttributes($repository, GitHubAttributeMapper::mapRepository($repositoryData) + ['webhook_received_at' => $received]);
        }

        if (is_array($payload['workflow_run'] ?? null)) {
            $this->applyWorkflowRun($repository, $payload['workflow_run'], $repositoryData['default_branch'] ?? null);
        }
        if (is_array($payload['release'] ?? null)) {
            $this->applyRelease($repository, $payload['release'], (string)($payload['action'] ?? ''));
        }
        if (is_array($payload['pull_request'] ?? null)) {
            $this->applyPullRequest($repository, $payload['pull_request']);
        }
        if (is_array($payload['issue'] ?? null) && !isset($payload['issue']['pull_request'])) {
            $this->applyIssue($repository, $payload['issue'], (string)($payload['action'] ?? ''));
        }

        return true;
    }

    /** Save every object apply() changed. */
    public function flush(): void
    {
        $changed = $this->changed;
        $this->changed = [];

        foreach ($changed as $object) {
            $this->customObjectProvider->save($object);
        }
    }

    private function applyWorkflowRun(GitRepository $repository, array $run, ?string $defaultBranch): void
    {
        // The tile shows the state of the default branch, not of every feature branch.
        if ($defaultBranch !== null && ($run['head_branch'] ?? null) !== $defaultBranch) {
            return;
        }

        $updatedAt = GitHubAttributeMapper::timestamp($run['updated_at'] ?? null);
        if (!GitHubAttributeMapper::isNotOlder($updatedAt, $repository->getAttribute('ci_updated_at'))) {
            return;
        }

        $this->setAttributes($repository, [
            'ci_status' => GitHubAttributeMapper::ciStatus($run),
            'ci_workflow_name' => GitHubAttributeMapper::toAttributeValue($run['name'] ?? null),
            'ci_run_url' => GitHubAttributeMapper::toAttributeValue($run['html_url'] ?? null),
            'ci_updated_at' => $updatedAt,
        ]);
    }

    private function applyRelease(GitRepository $repository, array $release, string $action): void
    {
        if (!in_array($action, ['published', 'released'], true) || !empty($release['draft']) || !empty($release['prerelease'])) {
            return;
        }

        $publishedAt = GitHubAttributeMapper::timestamp($release['published_at'] ?? null);
        if (!GitHubAttributeMapper::isNotOlder($publishedAt, $repository->getAttribute('latest_release_published_at'))) {
            return;
        }

        $this->setAttributes($repository, [
            'latest_release_tag' => GitHubAttributeMapper::toAttributeValue($release['tag_name'] ?? null),
            'latest_release_published_at' => $publishedAt,
        ]);
    }

    /**
     * Webhooks carry no count of open pull requests, so the numbers of the open ones are
     * kept and counted - it covers the pull requests seen since the webhook was set up.
     */
    private function applyPullRequest(GitRepository $repository, array $pullRequest): void
    {
        if (!isset($pullRequest['number'])) {
            return;
        }

        $open = json_decode((string)$repository->getAttribute('open_pull_requests', '[]'), true);
        $open = is_array($open) ? $open : [];
        $number = (int)$pullRequest['number'];

        if (($pullRequest['state'] ?? '') === 'open') {
            $open[] = $number;
        } else {
            $open = array_diff($open, [$number]);
        }
        $open = array_values(array_unique(array_map('intval', $open)));
        sort($open);

        $this->setAttributes($repository, [
            'open_pull_requests' => GitHubAttributeMapper::toAttributeValue($open),
            'open_pull_requests_count' => (string)count($open),
        ]);
    }

    private function applyIssue(GitRepository $repository, array $issueData, string $action): void
    {
        if (!isset($issueData['number'])) {
            return;
        }

        $issue = $this->findIssue($repository, (int)$issueData['number']);
        $attributes = GitHubAttributeMapper::mapIssue($issueData);

        if ($issue === null) {
            if ($action === 'deleted' || $action === 'transferred') {
                return;
            }
            $issue = $this->customObjectProvider->createNewCustomEntity(GitIssue::class);
            $issue->setParentId($repository->getId());
            $repository->setChildObjects([...$repository->getChildObjects(), $issue]);
        } elseif (!GitHubAttributeMapper::isNotOlder($attributes['updated_at'], $issue->getAttribute('updated_at'))) {
            return;
        }

        // A deleted or transferred issue is gone from this repository; the tile hides it.
        if ($action === 'deleted' || $action === 'transferred') {
            $attributes['state'] = GitIssue::STATE_CLOSED;
            $attributes['state_reason'] = $action;
        }

        $issue->setName($attributes['title'] !== '' ? $attributes['title'] : '#' . $attributes['number']);
        $this->setAttributes($issue, $attributes);

        // Recounting is only right once UpdateRepositoryInfosJob brought every open issue.
        if ($repository->hasAttribute('issues_synced_at')) {
            $this->setAttributes($repository, [
                'open_issues_count' => (string)GitHubIssueSynchronizer::countOpenIssues($repository),
            ]);
        }
    }

    private function findRepository(string $fullName): ?GitRepository
    {
        if ($this->repositories === null) {
            $this->repositories = [];
            foreach ($this->customObjectProvider->getCustomEntitiesByClassName(GitRepository::class) as $repository) {
                $path = strtolower(trim($repository->getRepositoryPath(), " /"));
                if ($path !== '') {
                    $this->repositories[$path] = $repository;
                }
            }
        }

        return $this->repositories[strtolower($fullName)] ?? null;
    }

    private function findIssue(GitRepository $repository, int $number): ?GitIssue
    {
        foreach ($repository->getChildObjects() as $child) {
            if ($child instanceof GitIssue && (int)$child->getAttribute('number') === $number) {
                return $child;
            }
        }

        return null;
    }

    /** Sets the attributes and remembers the object for flush() if anything differs. */
    private function setAttributes(GitRepository|GitIssue $object, array $attributes): void
    {
        $changed = false;
        foreach ($attributes as $name => $value) {
            if ($object->hasAttribute($name) && $object->getAttribute($name) === $value) {
                continue;
            }
            if (!$object->hasAttribute($name) && $value === null) {
                continue;
            }
            $object->setAttribute($name, $value);
            $changed = true;
        }

        if ($changed || $object->getId() <= 0) {
            $this->changed[spl_object_id($object)] = $object;
        }
    }
}
