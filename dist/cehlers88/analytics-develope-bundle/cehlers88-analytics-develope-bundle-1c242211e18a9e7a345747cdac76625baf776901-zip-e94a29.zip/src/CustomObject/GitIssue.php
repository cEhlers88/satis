<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:36
 */

namespace Cehlers88\AnalyticsDevelopeBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

class GitIssue extends AbstractCustomObject
{
    public const STATE_OPEN = 'open';
    public const STATE_CLOSED = 'closed';

    public function getTitle(): string
    {
        return $this->getAttribute('title', '');
    }

    public function setTitle(string $title): static
    {
        return $this->setAttribute('title', $title);
    }

    public function getState(): string
    {
        return $this->getAttribute('state', self::STATE_OPEN);
    }

    public function setState(string $state): static
    {
        return $this->setAttribute('state', $state);
    }
}