<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Worker;

use Cehlers88\AnalyticsCore\Worker\AbstractWorker;
use Cehlers88\AnalyticsCore\Worker\Job\SetTrackingBuffersStateToProcessedFinishedJob;
use Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\EnrichTrackingEntityJob;

class GitTrackingBufferWorker extends AbstractWorker
{
    public const BUFFER_REPO_FETCH_KEY = 'BUFFER.git_repo_fetch';
    private const REQUIRED_DATA_KEYS = [
        self::BUFFER_REPO_FETCH_KEY,
        'SERVICE_ENDPOINT.git_webhook'
    ];

    public function getRequiredJobs(): array
    {
        return [
            EnrichTrackingEntityJob::class,
            //FetchRepositoryDetailInfosJob::class,
            SetTrackingBuffersStateToProcessedFinishedJob::class
        ];
    }

    public function handleError(string $error, array $data): void
    {
        switch ($error) {
            default:
                parent::handleError($error, $data);
        }
    }

    public function getWorkingObjects(): array
    {
        return $this->trackingBufferRepository->findByAnyDataKeyValue(self::REQUIRED_DATA_KEYS);
    }
}