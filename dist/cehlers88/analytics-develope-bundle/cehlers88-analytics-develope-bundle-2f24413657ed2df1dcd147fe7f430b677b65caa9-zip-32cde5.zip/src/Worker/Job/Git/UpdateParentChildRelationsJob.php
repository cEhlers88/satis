<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;

class UpdateParentChildRelationsJob extends AbstractWorkerJob
{
    public const CHECK_RUN_COMPLETED_EVENT_REASON = 'check_run_completed';
    public const CHECK_SUITE_COMPLETED_EVENT_REASON = 'check_suite_completed';
    public const CHECK_SUITE_IN_PROGRESS_EVENT_REASON = 'check_suite_in_progress';
    public const WORKFLOW_RUN_COMPLETED_EVENT_REASON = 'workflow_run_completed';
    public const WORKFLOW_RUN_IN_PROGRESS_EVENT_REASON = 'workflow_run_in_progress';
    public const WORKFLOW_RUN_REQUESTED_EVENT_REASON = 'workflow_run_requested';
    public const WORKFLOW_JOB_COMPLETED_EVENT_REASON = 'workflow_job_completed';
    public const WORKFLOW_JOB_QUEUED_EVENT_REASON = 'workflow_job_queued';
    public const WORKFLOW_JOB_IN_PROGRESS_EVENT_REASON = 'workflow_job_in_progress';

    private array $buffer = [];

    public function __construct(
        private readonly TrackingBufferRepository $trackingBufferRepository,
    )
    {
        $this->setType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_END);
    }

    /**
     * @param TrackingBuffer $object
     * @return AbstractWorkerJob
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $handlerData = $object->getHandlerData() ?? [];

        if (!isset($handlerData['refId']) || empty($handlerData['refId'])) {
            $this->logWarning('No refId found in trackingBuffer->handlerData', true);
            return $this;
        }

        if ($this->trackingBufferHasParentEvent($object)) {
            $this->buffer['children'][] = $object;
        }

        if (!$this->trackingBufferIsParentEvent($object)) {
            return $this;
        }

        $refId = $handlerData['refId'];
        $eventReason = $handlerData['eventReason'];

        if (!isset($this->buffer[$eventReason])) {
            $this->buffer[$eventReason] = [];
        }

        $refIdSplit = explode('|', $refId);
        foreach ($refIdSplit as $refId) {
            $this->buffer[$eventReason][$refId] = $object;
        }


        return $this;
    }

    private function trackingBufferHasParentEvent(TrackingBuffer $trackingBuffer): bool
    {
        $childEvents = [
            'check_run_created',
            self::CHECK_RUN_COMPLETED_EVENT_REASON,
            self::CHECK_SUITE_COMPLETED_EVENT_REASON,
            self::WORKFLOW_JOB_IN_PROGRESS_EVENT_REASON,
            self::WORKFLOW_JOB_COMPLETED_EVENT_REASON,
            self::WORKFLOW_JOB_QUEUED_EVENT_REASON,
            self::WORKFLOW_RUN_COMPLETED_EVENT_REASON,
            self::WORKFLOW_RUN_IN_PROGRESS_EVENT_REASON,
        ];

        $trackingEventHandlerData = $trackingBuffer->getHandlerData() ?? [];
        $trackingEventReason = $trackingEventHandlerData['eventReason'] ?? '';

        if (empty($trackingEventReason)) {
            return false;
        }

        $result = in_array($trackingEventReason, $childEvents);

        return $result;
    }

    private function trackingBufferIsParentEvent(TrackingBuffer $trackingBuffer): bool
    {
        $parentEvents = [
            'check_run_created',
            'check_suite_in_progress',
            'workflow_run_in_progress',
            self::WORKFLOW_JOB_QUEUED_EVENT_REASON,
            self::WORKFLOW_RUN_REQUESTED_EVENT_REASON,
        ];
        $trackingEventHandlerData = $trackingBuffer->getHandlerData() ?? [];
        $trackingEventReason = $trackingEventHandlerData['eventReason'] ?? '';

        return in_array($trackingEventReason, $parentEvents);
    }

    public function getDescription(): string
    {
        return 'Enrich Tracking Buffer with additional data based on data from GitHub.';
    }

    protected function startJob(): void
    {
        $this->buffer = [
            'children' => []
        ];
    }

    protected function finishJob(): void
    {
        $relations = [
            'check_run_created' => self::WORKFLOW_JOB_QUEUED_EVENT_REASON,
            self::CHECK_RUN_COMPLETED_EVENT_REASON => 'check_run_created',

            self::CHECK_SUITE_COMPLETED_EVENT_REASON => self::CHECK_SUITE_IN_PROGRESS_EVENT_REASON,

            self::WORKFLOW_JOB_IN_PROGRESS_EVENT_REASON => self::WORKFLOW_JOB_QUEUED_EVENT_REASON,
            self::WORKFLOW_JOB_COMPLETED_EVENT_REASON => self::WORKFLOW_JOB_QUEUED_EVENT_REASON,
            self::WORKFLOW_JOB_QUEUED_EVENT_REASON => self::WORKFLOW_RUN_REQUESTED_EVENT_REASON,

            self::WORKFLOW_RUN_COMPLETED_EVENT_REASON => self::WORKFLOW_RUN_REQUESTED_EVENT_REASON,
            self::WORKFLOW_RUN_IN_PROGRESS_EVENT_REASON => self::WORKFLOW_RUN_REQUESTED_EVENT_REASON,
        ];

        $children = $this->buffer['children'] ?? [];
        /** @var TrackingBuffer $child */
        foreach ($children as $child) {
            $childHandlerData = $child->getHandlerData() ?? [];
            $refId = $childHandlerData['refId'] ?? '';
            $childEventReason = $childHandlerData['eventReason'] ?? '';
            $parentEventReason = $relations[$childEventReason] ?? '';

            if (empty($parentEventReason) || empty($refId)) {
                continue;
            }
            $parentEventReasonBuffer = $this->buffer[$parentEventReason] ?? [];

            if (empty($parentEventReasonBuffer)) {
                continue;
            }
            /** @var ?TrackingBuffer $parent */
            $parent = null;
            $refIdSplit = explode('|', $refId);
            foreach ($refIdSplit as $refId) {
                if (isset($parentEventReasonBuffer[$refId])) {
                    $parent = $parentEventReasonBuffer[$refId];
                    break;
                }
            }
            if (empty($parent)) {
                continue;
            }
            $child->setParent($parent);
        }
    }
}