# Changelog

## [0.2.6](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.5...v0.2.6) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([97744bb](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/97744bbd806fd223df86159c8227786f6d6bac6c))

## [0.2.5](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.4...v0.2.5) (2026-03-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.5.3 ([#20](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/20)) ([1e713ee](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1e713eee6b197f58a5c7eff54e03722eafb044eb))
* **deps:** update dependency cehlers88/analytics-core to v0.5.5 ([#22](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/22)) ([1ac609a](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1ac609af5e6b497c090a8f40428ea8c5d54c2a6d))

## [0.2.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.3...v0.2.4) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.5 ([#19](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/19)) ([8aa417d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/8aa417ddc827e6cbc1d6017006c83fa5805dba30))
* **deps:** update dependency cehlers88/analytics-core to v0.4.2 ([#14](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/14)) ([fa4cfad](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/fa4cfade68493fbae9ed669002814f68d8c088e2))

## [0.2.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.2...v0.2.3) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([b6c385b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/b6c385bad2213abaed7a40b400798863c2a73e47))

## [0.2.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.1...v0.2.2) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([be375b8](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/be375b86faa0a260c12871a6aabfa9b7b1fb5421))

## [0.2.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.0...v0.2.1) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.4 ([#13](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/13)) ([893c765](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/893c765b6be12138a2f34bb22c7e3b9012a6bd9e))

## [0.2.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.4...v0.2.0) (2026-03-19)


### Features

* add DevelopWorker and update dependency to analytics-core ^1 ([fc6d36b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/fc6d36b76ceaee8302502b359007009e7a561fdc))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/9)) ([e0d383c](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e0d383c4664e6ce5698bb6c848ffd36621b011d9))
* downgrade analytics-core dependency to ^0.3 ([1e511c7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1e511c7bade6d3a74a41cc25c1feb9ecf8c56ade))

## [0.1.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.3...v0.1.4) (2026-01-22)


### Miscellaneous Chores

* Update dependency versions for analytics-core ([f2a8d15](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2a8d154ac14f01f7e39afb22b0a6e6d616217ff))

## [0.1.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.2...v0.1.3) (2026-01-21)


### Miscellaneous Chores

* add GitHub Actions workflow to trigger Satis rebuild on release ([7ba6034](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/7ba60343f9c515be0aee3f6ae55be094a75e66a9))

## [0.1.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([cf67e17](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/cf67e17329ebd56e001bb3102676a4439e6ad844))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([f2aae12](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2aae12077ba3b0790fb23eadd527cd40e4d85c8))

## [0.1.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([c39c6af](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c39c6af44469b9065e75f992998cbce6b579bce4))
