# Changelog

## [1.8.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.8.0...v1.8.1) (2026-10-09)


### Bug Fixes

* **ui:** use the theme palette in the SQL console and changelog editor ([#95](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/95)) ([0192ce8](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/0192ce8df9fc0ef526f01a35becbc2e47c097d7c))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.47.0 ([#94](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/94)) ([198966e](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/198966e4d99caa417f8f2851c3589589fe478cbb))

## [1.8.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.7.0...v1.8.0) (2026-09-26)


### Features

* replace toolbar elements with `ribbon-menu` interface for `ChangelogEditor` and `SqlConsole`; refactor JavaScript logic accordingly; add tests for SQL Guard, query model, and connection storage ([89c853f](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/89c853f99b79ae8ff5aee452d1e2765fd05097d5))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.42.7 ([#92](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/92)) ([e4c83c4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e4c83c4c66743dfcf132236f33fe82481b6ffb92))

## [1.7.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.6.0...v1.7.0) (2026-09-20)


### Features

* add route check to `ChangelogSubscriber` to ensure tools and targets are only available when routes are imported ([f8f6d15](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f8f6d153cbcaab0b18dffe6249be241bf89eaedd))
* add SQL Console directory configuration in `AnalyticsDevelopeBundle` services.yaml ([fe78d78](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/fe78d7803249e74133ab98ba79a9f29b83b6e403))
* introduce `SqlGuard` class for SQL normalization, validation, and execution control; add SQL Console tool with UI templates and JavaScript logic ([3b88d46](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/3b88d46368e28342ac137c4a39fd00afb57041cf))

## [1.6.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.5.1...v1.6.0) (2026-09-19)


### Features

* introduce `ChangelogEditor` tool with backend controller, event subscriber, and UI templates for changelog management ([6bebe33](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/6bebe3338ee15bf2c17bdc1cf7a7ed9329c0dae4))
* update bundle description and add changelog directory configuration in `AnalyticsDevelopeBundle` ([262c001](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/262c0014d82551b0c61c89b7dc15cae9784d2f05))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.42.5 ([#89](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/89)) ([c05ff22](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c05ff22526746702190414b4a1ea47b9c15a01eb))

## [1.5.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.5.0...v1.5.1) (2026-09-18)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.42.3 ([#87](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/87)) ([896e76d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/896e76dbd11fb420911b683fc51458db3b9a3856))

## [1.5.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.4.0...v1.5.0) (2026-09-13)


### Features

* add `GitIssue` and `GitRepository` tile templates and enhance `GitIssue` custom object with tile template definition ([e9ecb50](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e9ecb50a86cf8c62a855708dad4226e8c3ad3fb9))
* add validation method to `UpdateParentChildRelationsJob` for parent-child combination checks ([44e0f9a](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/44e0f9a08e7e29dd7f0d705df3043150dccb0223))
* enhance `UpdateRepositoryInfosJob` with external service execution and response handling, add `generateRefId` method to `EnrichTrackingEntityJob` ([14e3217](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/14e3217616b724a3650c269e20aeb34085a44e5f))
* restructure Git job namespaces and add `UpdateRepositoryInfosJob` and `GitRepositoriesInfosWorker` for better handling of Git repository data ([440290d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/440290d760519baed72674af98f48384c03cca86))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.42.0 ([#85](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/85)) ([353f459](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/353f4597bb818acb572643f2b50c6b6325207a4e))

## [1.4.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.3.2...v1.4.0) (2026-09-11)


### Features

* add `UpdateStateJob` and `UpdateParentChildRelationsJob` to `GitTrackingBufferWorker` for enhanced tracking buffer processing ([60ecb28](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/60ecb28d08f5b8ac7f3307bfb621c6cdc8e82e76))

## [1.3.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.3.1...v1.3.2) (2026-08-27)


### Miscellaneous Chores

* bump `cehlers88/analytics-core` to v1.40.1 in `composer.lock` ([d1ba009](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/d1ba009dc5594b5cd3c6267f7b4d085e4cc13c52))

## [1.3.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.3.0...v1.3.1) (2026-08-27)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.40.0 ([#81](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/81)) ([b74ee73](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/b74ee73c42b8ae769c366ad3a366cda6d7edace4))

## [1.3.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.2.7...v1.3.0) (2026-08-20)


### Features

* add `RemoteDebugObserverMessage` class to implement `ObserverMessageInterface` ([10f954d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/10f954dbf81936542f5dd878ecea755bcbd0137c))
* add `RemoteDebugServiceEndpointRunner` with remote debug handling and endpoint definitions ([162cbd3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/162cbd3cb6e43ba990ffb1ad39348ce8ae300524))
* add service tagging for `ServiceEndpointRunnerInterface` in services configuration ([fec7e8d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/fec7e8de51f226f36582baf964b1a562792b4b3f))


### Miscellaneous Chores

* add bundle name constant and update description in `AnalyticsDevelopeBundle` ([7893179](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/78931790b420d5a0b93758bbb30643ac452b7469))
* **deps:** update dependency cehlers88/analytics-core to v1.39.12 ([#79](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/79)) ([35ac552](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/35ac55254023af5d749a58ecdc59df0d3e8c9880))

## [1.2.7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.2.6...v1.2.7) (2026-08-11)


### Miscellaneous Chores

* add missing context parameter to logger in `EnrichTrackingEntityJob` error handling ([de4758b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/de4758badc2220b4c5083c6cf93e27a728873fa1))
* **deps:** update dependency cehlers88/analytics-core to v1.39.10 ([#78](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/78)) ([1756e18](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1756e18a5714ede15b374cc11deeeea398e29ec3))

## [1.2.6](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.2.5...v1.2.6) (2026-07-18)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.7 ([#75](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/75)) ([315007a](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/315007a9781343cd90ce910c8941c9a485e78af9))

## [1.2.5](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.2.4...v1.2.5) (2026-07-12)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.5 ([#73](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/73)) ([386c5a1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/386c5a15a087c418237fb0782c9a1e0e05feba94))

## [1.2.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.2.3...v1.2.4) (2026-07-10)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.3 ([#71](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/71)) ([c9db3ea](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c9db3eaca062c387eb3d325668b172845b0fafe8))

## [1.2.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.2.2...v1.2.3) (2026-06-21)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.39.0 ([#69](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/69)) ([4da0fb9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/4da0fb91ede096ccea46772c27019bd66246fe88))
* Replaced imports of `MenuItemDTO` with the correct path `Cehlers88\AnalyticsCore\Support\DTO\UI\MenuItemDTO` in multiple bundles. This ensures consistency and resolves potential namespace issues. ([e71bb66](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e71bb6681b026d47341656e824ee89adc5a6d87e))

## [1.2.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.2.1...v1.2.2) (2026-06-14)


### Miscellaneous Chores

* bump `cehlers88/analytics-core` to v1.38.8 in composer.lock ([0484634](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/0484634345df49f2adcd967d4a73f4849e24bb57))

## [1.2.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.2.0...v1.2.1) (2026-06-14)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.38.7 ([#66](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/66)) ([7017f28](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/7017f28b290319cedd9a2f020ab190ca4ce876b2))

## [1.2.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.10...v1.2.0) (2026-05-25)


### Features

* add `FetchRepositoryDetailInfosJob` and `EnrichTrackingEntityJob` classes for enhanced repository tracking and data enrichment ([d7494b9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/d7494b9528aeb6b894899a7ce94a66df719bbd22))
* add `GitIssue` custom object class with state and title handling functionality ([d0b5c46](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/d0b5c4668fa78dfcbfa9544e68bcb5a9fcf6eb2f))
* add `GitTrackingBufferWorker` class and integrate it into `FetchRepositoryDetailInfosJob` ([5a08b50](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/5a08b500450e8e23e7740e4fadb10ccaf37a1f55))
* add service tagging for `WorkerInterface` and `JobInterface` in services configuration ([0d932fc](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/0d932fc1e6780a22da946bb793cfef3d8018eab5))


### Miscellaneous Chores

* bump analytics-core to v1.38.5 in composer.lock ([c72b682](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c72b682c8b8c8234a692d2fce89e9fb6fa7730e7))
* refactor: update import path for `SetTrackingBuffersStateToProcessedFinishedJob` in `GitTrackingBufferWorker` ([efe4ba3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/efe4ba34625da98d46bc6aee6f270a594fb0a172))

## [1.1.10](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.9...v1.1.10) (2026-05-24)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.38.1 ([#60](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/60)) ([68e73e7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/68e73e7021154a846e412b69769a1779f79bb19b))
* **deps:** update dependency cehlers88/analytics-core to v1.38.2 ([#63](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/63)) ([ce0b8c8](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/ce0b8c8b8c9bd8760d1c3a4b36015cc609dba85a))
* Update entities to extend AbstractTaggedEntity ([77ddf10](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/77ddf10217e96452a6850bce6e4f6723ed202844))

## [1.1.9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.8...v1.1.9) (2026-05-17)


### Miscellaneous Chores

* bump analytics-core to v1.38.0 in composer.lock ([5237bef](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/5237bef0d838dd5da27b11c1c1e9cc43e4b2ae95))
* refactor: comment out default property initialization in `DevelopWorker` constructor and update `PropertyDTO` import ([1d9db13](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1d9db13d33a0bf5f0939fe0efeff5bf3c220614b))

## [1.1.8](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.7...v1.1.8) (2026-05-16)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.34.0 ([#58](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/58)) ([1896632](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/18966325d2555dc2971c16b3c44ab40645082ff1))

## [1.1.7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.6...v1.1.7) (2026-05-10)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.30.0 ([#56](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/56)) ([1736119](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1736119c884f6939c81896c9cd3a2f3e687f0f13))

## [1.1.6](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.5...v1.1.6) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.28.2 ([#55](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/55)) ([9d07d4d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/9d07d4dd42139cf512775c92a9648ad6b5df1931))
* Update branch alias format in composer.json files ([6e4fc3d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/6e4fc3d3adec2fbea35c9f796035adc7fdf7b66b))

## [1.1.5](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.4...v1.1.5) (2026-05-03)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.25.1 ([#52](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/52)) ([af3131c](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/af3131c055b5a89f467ee3213d0b467279ea2f00))

## [1.1.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.3...v1.1.4) (2026-05-02)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.21.0 ([#45](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/45)) ([5739af7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/5739af7452b106198098c77c5774c0fc4e78d472))
* **deps:** update dependency cehlers88/analytics-core to v1.21.2 ([#47](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/47)) ([1841dd5](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1841dd5ff06e4dccaa410c0e7b95fc057ccedace))
* **deps:** update dependency cehlers88/analytics-core to v1.21.3 ([#50](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/50)) ([51b373e](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/51b373e365ca32b54b3fbe06443d87754155ded8))
* **deps:** update dependency cehlers88/analytics-core to v1.22.1 ([#51](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/51)) ([b45e02b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/b45e02b4e103dd826b1bab91de03d19d4ce39620))

## [1.1.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.2...v1.1.3) (2026-04-26)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.20.0 ([#42](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/42)) ([0bcc573](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/0bcc5733b89778c260425d878607cfa60b799186))
* **deps:** update googleapis/release-please-action action to v5 ([#43](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/43)) ([97ef1da](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/97ef1da5a97302e1cbcd952cb794a6b3b4b38b5d))

## [1.1.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.1...v1.1.2) (2026-04-19)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.16.1 ([#39](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/39)) ([e62deb1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e62deb1e41822ea9cf26d6dd3c96039975deb69d))
* **deps:** update dependency cehlers88/analytics-core to v1.17.0 ([#40](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/40)) ([854a42f](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/854a42f35c83f8b805632cfebea2407865599878))

## [1.1.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.1.0...v1.1.1) (2026-04-13)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.15.0 ([#36](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/36)) ([2ee44e1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/2ee44e17eab4c5a61af633ec306efd31389b3817))
* **deps:** update dependency cehlers88/analytics-core to v1.16.0 ([#38](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/38)) ([8abd7bf](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/8abd7bf93b3ca9968a0412e043f6fd3661cad092))

## [1.1.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.0.2...v1.1.0) (2026-03-29)


### Features

* add default property initialization in `DevelopWorker` constructor ([f597302](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f597302373e09adc12b6c823badcb8d144d8affe))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.3.13 ([#32](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/32)) ([4ff784b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/4ff784be5157bb20f89a8f197d44c47a15cf63f2))
* **deps:** update dependency cehlers88/analytics-core to v1.4.1 ([#34](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/34)) ([5a113ce](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/5a113cecfddb5adf1b61911b42c82c101bea0872))
* **deps:** update dependency cehlers88/analytics-core to v1.6.0 ([#35](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/35)) ([e10e71c](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e10e71c11a00afe882ec2189b326fa060983e54a))

## [1.0.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.0.1...v1.0.2) (2026-03-26)


### Miscellaneous Chores

* remove unnecessary blank line in `DevelopWorker` class definition ([28d1789](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/28d17890f46d38e55e40a031b5726fe41129c24b))

## [1.0.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.0.0...v1.0.1) (2026-03-26)


### Miscellaneous Chores

* bump analytics-core to v1.3.11 in composer.lock ([33f3c9a](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/33f3c9adede30c77c027d37caf27eab1b3f18343))
* **deps:** update dependency cehlers88/analytics-core to v1.3.10 ([#30](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/30)) ([cd8d0a0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/cd8d0a05e8a5efab8d9b4a46e5633647c08ce007))
* **deps:** update dependency cehlers88/analytics-core to v1.3.6 ([#28](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/28)) ([ae27042](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/ae2704213e10417053d8eaaaebeb7a6bc660348f))
* enhance DevelopWorker with job handling and buffer repository integration ([258c007](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/258c007fd7153ae9c029efb35f4966b6fc2dedb4))
* Upgraded the analytics-core package to v1.3.7 to include the latest changes and improvements. Updated the associated reference, distribution URL, and checksum to match the new version. ([e4d32f0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e4d32f0af6d5181bf7f1f12b11842e9dd53885ee))

## [1.0.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.6...v1.0.0) (2026-03-23)


### ⚠ BREAKING CHANGES

* remove unused configuration group code in AnalyticsDevelopeBundle

### Features

* remove unused configuration group code in AnalyticsDevelopeBundle ([4c36b17](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/4c36b17472a536594f48b6e551ac830f42a08d6e))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.1.3 ([#25](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/25)) ([bcbbee9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/bcbbee91fe16d29397c445a55b520423d3339642))
* **deps:** update dependency cehlers88/analytics-core to v1.3.5 ([#27](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/27)) ([4ec60a9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/4ec60a9218daf1326657b84c540464e24632fe9e))

## [0.2.6](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.5...v0.2.6) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([97744bb](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/97744bbd806fd223df86159c8227786f6d6bac6c))

## [0.2.5](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.4...v0.2.5) (2026-03-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.5.3 ([#20](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/20)) ([1e713ee](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1e713eee6b197f58a5c7eff54e03722eafb044eb))
* **deps:** update dependency cehlers88/analytics-core to v0.5.5 ([#22](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/22)) ([1ac609a](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1ac609af5e6b497c090a8f40428ea8c5d54c2a6d))

## [0.2.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.3...v0.2.4) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.5 ([#19](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/19)) ([8aa417d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/8aa417ddc827e6cbc1d6017006c83fa5805dba30))
* **deps:** update dependency cehlers88/analytics-core to v0.4.2 ([#14](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/14)) ([fa4cfad](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/fa4cfade68493fbae9ed669002814f68d8c088e2))

## [0.2.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.2...v0.2.3) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([b6c385b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/b6c385bad2213abaed7a40b400798863c2a73e47))

## [0.2.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.1...v0.2.2) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([be375b8](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/be375b86faa0a260c12871a6aabfa9b7b1fb5421))

## [0.2.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.0...v0.2.1) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.4 ([#13](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/13)) ([893c765](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/893c765b6be12138a2f34bb22c7e3b9012a6bd9e))

## [0.2.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.4...v0.2.0) (2026-03-19)


### Features

* add DevelopWorker and update dependency to analytics-core ^1 ([fc6d36b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/fc6d36b76ceaee8302502b359007009e7a561fdc))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/9)) ([e0d383c](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e0d383c4664e6ce5698bb6c848ffd36621b011d9))
* downgrade analytics-core dependency to ^0.3 ([1e511c7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1e511c7bade6d3a74a41cc25c1feb9ecf8c56ade))

## [0.1.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.3...v0.1.4) (2026-01-22)


### Miscellaneous Chores

* Update dependency versions for analytics-core ([f2a8d15](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2a8d154ac14f01f7e39afb22b0a6e6d616217ff))

## [0.1.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.2...v0.1.3) (2026-01-21)


### Miscellaneous Chores

* add GitHub Actions workflow to trigger Satis rebuild on release ([7ba6034](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/7ba60343f9c515be0aee3f6ae55be094a75e66a9))

## [0.1.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([cf67e17](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/cf67e17329ebd56e001bb3102676a4439e6ad844))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([f2aae12](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2aae12077ba3b0790fb23eadd527cd40e4d85c8))

## [0.1.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([c39c6af](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c39c6af44469b9065e75f992998cbce6b579bce4))
