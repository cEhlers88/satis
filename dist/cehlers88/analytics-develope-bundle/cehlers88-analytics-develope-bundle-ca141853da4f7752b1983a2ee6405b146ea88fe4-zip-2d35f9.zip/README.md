# Analytics Develope Bundle

A Symfony bundle for development management within the Analytics system.

## Description

The Analytics Develope Bundle provides development tools and configuration management for the Analytics platform. It enables developers to manage git repositories and configure development settings through the Analytics interface.

## Requirements

- PHP 7.4 or higher
- Symfony 5.x or higher
- [cehlers88/analytics-core](https://github.com/cEhlers88/AnalyticsCore) ^0.1

## Installation

Install the bundle using Composer:

```bash
composer require cehlers88/analytics-develope-bundle
```

## Configuration

The bundle provides configuration options for managing development repositories:

### General Configuration

The bundle includes a general configuration group (`developeBundle.general`) that allows you to:

- Define self-managing repositories
- Configure repository types (Application or Plugin)
- Link git repositories to the Analytics system

### Services

The bundle automatically registers its services when Symfony's autowiring is enabled. Configuration is located in `src/Resources/config/services.yaml`.

## Features

### Git Repository Management

The bundle provides a `GitRepository` custom object that allows you to:

- Store repository path information
- Manage git repositories through the Analytics interface
- Associate repositories with the Analytics system

### Claude Console Webhooks

Receives the webhooks of a Claude Console workspace (*Settings → Workspaces → Webhooks*,
`platform.claude.com/settings/workspaces/default/webhooks`) and keeps what they report in a
`ClaudeWorkspace` custom object per workspace, with a tile.

1. In the Console, add an endpoint with the URL
   `https://<host>/api/se/AnalyticsDevelopeBundle.claudeWebhook` and pick the event types.
2. Copy the signing secret (`whsec_…`, shown only once) into the constant
   `ANTHROPIC_WEBHOOK_SIGNING_KEY` (settings → Constants, type password).
3. Add a worker of the class `ClaudeWebhookBufferWorker` and let it run like the git one.

Optional query parameters: `?application=<id>` stores the deliveries in that application and
reads the constant there first (server value as fallback); `?constant=ANTHROPIC_WEBHOOK_SIGNING_KEY_<SUFFIX>`
lets several Console endpoints use their own secrets. Only names with that prefix are accepted.

- **Endpoint** (`ServiceEndpointRunner\ClaudeWebhookServiceEndpointRunner`): public like every
  `/api/se` call; the signature (Standard Webhooks: HMAC-SHA256 over
  `{webhook-id}.{webhook-timestamp}.{body}`, five minutes tolerance) is the authentication.
  Verified deliveries are only stored as tracking buffer `SERVICE_ENDPOINT.claude_webhook` and
  answered at once; a wrong signature gets 400, a missing secret 503.
- **Worker** (`ClaudeWebhookBufferWorker` → `UpdateClaudeWorkspacesJob` →
  `Claude\Webhook\ClaudeWebhookSynchronizer`): creates the workspace object on its first event
  and keeps event counts, the last 100 events (retries are recognised by the event id), the
  last known status of up to 200 sessions, deployment runs, agents, credentials, … and the
  counters of the tile (open/running/waiting sessions, failed runs, failed credentials,
  paused deployments). Events arrive out of order, so a status only moves forward by the
  event's `created_at`.
- The events are thin - type and id of the resource, no content. Fetching the session itself
  (`GET /v1/sessions/{id}`) would need an API key and is not done.

### Configuration Groups

- **General Configuration Group**: Manage general developer settings including repository configurations

### Changelog Editor

A tool on the dashboard's tools page to read and write the changelog - formatted like the
notes, written as Markdown, with images (pasted, dropped or picked; PNG, JPEG, GIF, WebP).
Two files on the server, below `var/changelog` or `CHANGELOG_DIRECTORY`:

- `current.md` - what has changed since the last release,
- `history.md` - the past releases, the newest first; *Abschließen…* moves the current
  changelog on top of it under a title and the date.

The bundle knows no other bundle and no class of the application - it takes part through
the events of AnalyticsCore only (`EventSubscriber\ChangelogSubscriber`):

- `CollectToolsEvent` - brings the tool to the tools page,
- `CollectChangelogTargetsEvent` - says there is a changelog,
- `AddChangelogEntriesEvent` - takes entries others hand over, e.g. the done tasks of a note.

The application imports the routes (`@AnalyticsDevelopeBundle/Controller/`, below
`/admin_api/develope/changelog`) and registers `templates/` as a Twig path.

### SQL Console

A tool on the dashboard's tools page (administrators only) to run database queries and to
put them together visually:

- **Connections**: the database the application itself runs on is always there and is only
  ever read from. Every other one is entered here - type (MySQL/MariaDB, PostgreSQL,
  SQLite), server, port, database, user and password - and can be tried out before it is
  saved. They are kept in `connections.json` below `var/sql-console` or
  `SQL_CONSOLE_DIRECTORY`; the passwords are encrypted with a key derived from the
  application secret and never leave the server (`SqlSecret`, `SqlConnectionStorage`).
- **Running**: one statement at a time. A reading statement gets a LIMIT unless it brings
  its own; anything that writes runs only on a connection that is not marked "only read
  from" *and* with "Schreiben erlauben" switched on. Several statements behind a semicolon
  are refused (`SqlGuard`).
- **The mask** takes the height of its window (`tool-fill`): the list of tables, the
  canvas and the result each scroll in themselves instead of growing the window downwards.
- **Visually**: the tables of the database are listed, a click puts one on the canvas.
  Foreign keys between the tables on the canvas become JOINs by themselves, a drag from one
  column onto another makes a further one, and the kind of join (INNER, LEFT, RIGHT),
  columns, filters and sorting are set there; the view (*Visuell* / *SQL*), DISTINCT and
  LIMIT are on the ribbon, what a statement did stands in the status bar of the window. The query is a model
  (`SqlQueryModel`), which the server turns into SQL - and back, as far as it can read a
  statement; what it cannot read (sub-queries, unions, functions) leaves the visual view
  untouched and says so.

The application needs nothing but the routes it already imports for the Changelog Editor.

## Usage

Once installed and configured, the bundle integrates seamlessly with the Analytics platform. Access the development configuration through the Analytics interface menu item "Dokumentverwaltung".

## Bundle Information

- **Version**: 1.0.0
- **Type**: Symfony Bundle
- **License**: Proprietary
- **Namespace**: `Cehlers88\AnalyticsDevelopeBundle`

## Author

**Christoph Ehlers**  
Email: webmaster@c-ehlers.de

## License

This bundle is proprietary software.
