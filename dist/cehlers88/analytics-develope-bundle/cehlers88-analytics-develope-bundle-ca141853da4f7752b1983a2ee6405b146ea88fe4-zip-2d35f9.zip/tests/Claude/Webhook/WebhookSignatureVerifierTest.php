<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Claude\Webhook;

use Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook\WebhookSignatureVerifier;
use Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook\WebhookVerificationException;
use PHPUnit\Framework\TestCase;

final class WebhookSignatureVerifierTest extends TestCase
{
    // the example of the Standard Webhooks specification
    private const SECRET = 'whsec_MfKQ9r8GKYqrTwjUPD8ILPZIo2LaLaSw';
    private const ID = 'msg_p5jXN8AQM9LWM0D4loKWxJek';
    private const TIMESTAMP = 1614265330;
    private const BODY = '{"test": 2432232314}';
    private const SIGNATURE = 'v1,g0hM9SsE+OTPJTGt/tmIKtSyZlE3uFJELVlNIOLJ1OE=';

    private static function headers(string $signature = self::SIGNATURE, int|string $timestamp = self::TIMESTAMP): array
    {
        return ['Webhook-Id' => self::ID, 'webhook-timestamp' => (string)$timestamp, 'webhook-signature' => $signature];
    }

    public function testTheSpecificationsExampleIsAccepted(): void
    {
        (new WebhookSignatureVerifier())->verify(self::SECRET, self::BODY, self::headers(), self::TIMESTAMP + 10);

        $this->addToAssertionCount(1);
    }

    public function testAnyOfSeveralSignaturesMayMatch(): void
    {
        (new WebhookSignatureVerifier())->verify(self::SECRET, self::BODY, self::headers('v1,bm90IGl0 v2,whatever ' . self::SIGNATURE), self::TIMESTAMP);

        $this->addToAssertionCount(1);
    }

    /** @return iterable<string, array{string, string, array<string, string>, int}> */
    public static function refusedDeliveries(): iterable
    {
        yield 'changed body' => [self::SECRET, '{"test": 2432232315}', self::headers(), self::TIMESTAMP];
        yield 'other secret' => ['whsec_' . base64_encode(str_repeat('x', 32)), self::BODY, self::headers(), self::TIMESTAMP];
        yield 'too old' => [self::SECRET, self::BODY, self::headers(), self::TIMESTAMP + 301];
        yield 'from the future' => [self::SECRET, self::BODY, self::headers(), self::TIMESTAMP - 301];
        yield 'no signature' => [self::SECRET, self::BODY, self::headers(''), self::TIMESTAMP];
        yield 'unversioned signature' => [self::SECRET, self::BODY, self::headers(substr(self::SIGNATURE, 3)), self::TIMESTAMP];
        yield 'timestamp no number' => [self::SECRET, self::BODY, self::headers(self::SIGNATURE, '1614265330.5'), self::TIMESTAMP];
        yield 'no secret' => ['', self::BODY, self::headers(), self::TIMESTAMP];
    }

    #[\PHPUnit\Framework\Attributes\DataProvider('refusedDeliveries')]
    public function testDeliveriesThatDoNotMatchAreRefused(string $secret, string $body, array $headers, int $now): void
    {
        $this->expectException(WebhookVerificationException::class);

        (new WebhookSignatureVerifier())->verify($secret, $body, $headers, $now);
    }

    public function testASecretWithoutPrefixIsTheSameKey(): void
    {
        self::assertSame(
            WebhookSignatureVerifier::key(self::SECRET),
            WebhookSignatureVerifier::key(substr(self::SECRET, strlen(WebhookSignatureVerifier::SECRET_PREFIX)))
        );
    }
}
