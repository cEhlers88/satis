<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Claude\Webhook;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook\ClaudeWebhookSynchronizer;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\ClaudeWorkspace;
use PHPUnit\Framework\TestCase;

final class ClaudeWebhookSynchronizerTest extends TestCase
{
    /** @var ClaudeWorkspace[] */
    private array $existing = [];
    private array $saved = [];
    private int $created = 0;
    private ClaudeWebhookSynchronizer $synchronizer;

    protected function setUp(): void
    {
        $provider = $this->createMock(CustomObjectProvider::class);
        $provider->method('getCustomEntitiesByClassName')->willReturnCallback(
            fn(string $class) => $class === ClaudeWorkspace::class ? $this->existing : []
        );
        $provider->method('createNewCustomEntity')->willReturnCallback(function (string $class) {
            $this->created++;

            return new $class();
        });
        $provider->method('save')->willReturnCallback(function ($object) {
            $this->saved[] = $object;
        });

        $this->synchronizer = new ClaudeWebhookSynchronizer($provider);
    }

    private static function event(string $id, string $type, string $resourceId, string $createdAt, string $workspace = 'ws-1', array $data = []): array
    {
        return [
            'type' => 'event',
            'id' => $id,
            'created_at' => $createdAt,
            'data' => $data + ['type' => $type, 'id' => $resourceId, 'organization_id' => 'org-1', 'workspace_id' => $workspace],
        ];
    }

    private function apply(array ...$events): void
    {
        foreach ($events as $event) {
            $this->synchronizer->apply($event, new \DateTimeImmutable('2026-11-06 12:00 UTC'));
        }
        $this->synchronizer->flush();
    }

    private static function json(ClaudeWorkspace $workspace, string $name): array
    {
        return json_decode((string)$workspace->getAttribute($name), true);
    }

    public function testTheFirstEventCreatesTheWorkspaceOnce(): void
    {
        $this->apply(
            self::event('whe_1', 'session.status_run_started', 'sesn_1', '2026-11-06T10:00:00Z'),
            self::event('whe_2', 'session.status_idled', 'sesn_1', '2026-11-06T10:01:00Z'),
        );

        self::assertSame(1, $this->created);
        self::assertCount(1, $this->saved);
        $workspace = $this->saved[0];
        self::assertSame('ws-1', $workspace->getWorkspaceId());
        self::assertSame('org-1', $workspace->getAttribute('organization_id'));
        self::assertSame('Claude Workspace ws-1', $workspace->getName());
        self::assertSame('2', $workspace->getAttribute('events_total'));
        self::assertSame('session.status_idled', $workspace->getAttribute('last_event_type'));
        self::assertSame('1', $workspace->getAttribute('open_sessions_count'));
        self::assertSame('1', $workspace->getAttribute('waiting_sessions_count'));
        self::assertSame('0', $workspace->getAttribute('running_sessions_count'));
        self::assertSame(['session.status_idled' => 1, 'session.status_run_started' => 1], self::json($workspace, 'event_counts'));
    }

    public function testRetriesOfAnEventCountOnce(): void
    {
        $event = self::event('whe_1', 'deployment_run.failed', 'drun_1', '2026-11-06T10:00:00Z');
        $this->apply($event, $event, $event);

        $workspace = $this->saved[0];
        self::assertSame('1', $workspace->getAttribute('events_total'));
        self::assertCount(1, self::json($workspace, 'recent_events'));
        self::assertSame('1', $workspace->getAttribute('failed_runs_count'));
        self::assertSame('drun_1', $workspace->getAttribute('last_failed_run_id'));
    }

    public function testALateEventDoesNotTurnBackTheStatus(): void
    {
        $this->apply(
            self::event('whe_2', 'session.status_terminated', 'sesn_1', '2026-11-06T10:05:00Z'),
            self::event('whe_1', 'session.status_idled', 'sesn_1', '2026-11-06T10:01:00Z'),
            // thread events say nothing about the session's own status
            self::event('whe_3', 'session.thread_idled', 'sesn_2', '2026-11-06T10:02:00Z', 'ws-1', ['session_thread_id' => 'thr_1']),
            self::event('whe_4', 'session.status_run_started', 'sesn_2', '2026-11-06T10:01:00Z'),
        );

        $workspace = $this->saved[0];
        $resources = self::json($workspace, 'resources');
        self::assertSame('terminated', $resources['session:sesn_1']['status']);
        self::assertSame('running', $resources['session:sesn_2']['status'], 'the thread event is newer but keeps the status');
        self::assertSame('session.thread_idled', $resources['session:sesn_2']['event']);
        self::assertSame('thr_1', $resources['session:sesn_2']['session_thread_id']);
        self::assertSame('1', $workspace->getAttribute('open_sessions_count'));
        self::assertSame('1', $workspace->getAttribute('running_sessions_count'));
        // newest first by when they happened, not by arrival
        self::assertSame(['whe_2', 'whe_3', 'whe_1', 'whe_4'], array_column(self::json($workspace, 'recent_events'), 'id'));
        self::assertSame('session.status_terminated', $workspace->getAttribute('last_event_type'));
    }

    public function testWorkspacesAreFoundByTheirIdAndKeptApart(): void
    {
        $known = new class extends ClaudeWorkspace {
            public function getId(): int
            {
                return 7;
            }
        };
        $known->setName('Produktion')->setWorkspaceId('ws-1');
        $this->existing = [$known];

        $this->apply(
            self::event('whe_1', 'vault_credential.refresh_failed', 'vcrd_1', '2026-11-06T10:00:00Z', 'ws-1', ['vault_id' => 'vlt_1']),
            self::event('whe_2', 'deployment.paused', 'depl_1', '2026-11-06T10:00:00Z', 'ws-2'),
        );

        self::assertSame(1, $this->created);
        self::assertCount(2, $this->saved);
        self::assertSame('Produktion', $known->getName());
        self::assertSame('1', $known->getAttribute('failed_credentials_count'));
        self::assertSame('vlt_1', self::json($known, 'resources')['vault_credential:vcrd_1']['vault_id']);
        self::assertSame('1', $this->saved[1]->getAttribute('paused_deployments_count'));
    }

    public function testAnythingButAnEventIsIgnored(): void
    {
        self::assertFalse($this->synchronizer->apply(['hello' => 'world'], new \DateTimeImmutable()));
        self::assertFalse($this->synchronizer->apply(['id' => 'whe_1', 'data' => ['id' => 'x']], new \DateTimeImmutable()));
        $this->synchronizer->flush();

        self::assertSame([], $this->saved);
    }

    public function testListsStayBounded(): void
    {
        $events = [];
        for ($i = 0; $i < ClaudeWebhookSynchronizer::MAX_RESOURCES + 20; $i++) {
            $events[] = self::event('whe_' . $i, $i % 2 ? 'session.status_terminated' : 'session.status_run_started', 'sesn_' . $i, sprintf('2026-11-06T10:%02d:%02dZ', intdiv($i, 60), $i % 60));
        }
        $this->apply(...$events);

        $workspace = $this->saved[0];
        $resources = self::json($workspace, 'resources');
        self::assertCount(ClaudeWebhookSynchronizer::MAX_RESOURCES, $resources);
        self::assertCount(ClaudeWebhookSynchronizer::RECENT_EVENTS, self::json($workspace, 'recent_events'));
        // ended sessions made room, every running one is still there
        self::assertSame((string)((ClaudeWebhookSynchronizer::MAX_RESOURCES + 20) / 2), $workspace->getAttribute('running_sessions_count'));
    }

    public function testARetryOfALateEventCountsOnceEvenWhenItIsNoLongerShown(): void
    {
        $events = [];
        for ($i = 0; $i < ClaudeWebhookSynchronizer::RECENT_EVENTS; $i++) {
            $events[] = self::event('whe_new_' . $i, 'agent.updated', 'agent_1', '2026-11-06T11:00:00Z');
        }
        $late = self::event('whe_late', 'session.status_idled', 'sesn_1', '2026-11-06T09:00:00Z');
        $this->apply(...[...$events, $late, $late]);

        $workspace = $this->saved[0];
        self::assertNotContains('whe_late', array_column(self::json($workspace, 'recent_events'), 'id'));
        self::assertSame((string)(ClaudeWebhookSynchronizer::RECENT_EVENTS + 1), $workspace->getAttribute('events_total'));
        self::assertSame(1, self::json($workspace, 'event_counts')['session.status_idled']);
    }

    public function testAnEndedSessionThatMadeRoomIsNotReopenedByALateEvent(): void
    {
        $events = [];
        for ($i = 0; $i < ClaudeWebhookSynchronizer::MAX_RESOURCES; $i++) {
            $events[] = self::event('whe_agent_' . $i, 'agent.created', 'agent_' . $i, '2026-11-06T10:00:00Z');
        }
        $events[] = self::event('whe_end', 'session.status_terminated', 'sesn_1', '2026-11-06T10:05:00Z');
        $events[] = self::event('whe_start', 'session.status_run_started', 'sesn_1', '2026-11-06T10:01:00Z');
        $this->apply(...$events);

        $workspace = $this->saved[0];
        self::assertArrayNotHasKey('session:sesn_1', self::json($workspace, 'resources'));
        self::assertArrayHasKey('session:sesn_1', self::json($workspace, 'ended_resources'));
        self::assertSame('0', $workspace->getAttribute('open_sessions_count'));
        self::assertSame('0', $workspace->getAttribute('running_sessions_count'));
    }

    public function testFractionsOfASecondKeepTheOrder(): void
    {
        $this->apply(
            self::event('whe_2', 'session.status_terminated', 'sesn_1', '2026-11-06T10:00:00.900Z'),
            self::event('whe_1', 'session.status_run_started', 'sesn_1', '2026-11-06T10:00:00.100Z'),
        );

        $resources = self::json($this->saved[0], 'resources');
        self::assertSame('terminated', $resources['session:sesn_1']['status']);
        self::assertSame('2026-11-06T10:00:00.900000Z', $resources['session:sesn_1']['status_at']);
    }

    public function testStatusesOfTheEventTypes(): void
    {
        self::assertSame('idle', ClaudeWebhookSynchronizer::statusOf('session.status_idled'));
        self::assertSame('running', ClaudeWebhookSynchronizer::statusOf('deployment_run.started'));
        self::assertSame('paused', ClaudeWebhookSynchronizer::statusOf('deployment.paused'));
        self::assertSame('active', ClaudeWebhookSynchronizer::statusOf('agent.created'));
        self::assertSame('deleted', ClaudeWebhookSynchronizer::statusOf('memory_store.deleted'));
        self::assertNull(ClaudeWebhookSynchronizer::statusOf('session.updated'));
        self::assertNull(ClaudeWebhookSynchronizer::statusOf('session.outcome_evaluation_ended'));
    }
}
