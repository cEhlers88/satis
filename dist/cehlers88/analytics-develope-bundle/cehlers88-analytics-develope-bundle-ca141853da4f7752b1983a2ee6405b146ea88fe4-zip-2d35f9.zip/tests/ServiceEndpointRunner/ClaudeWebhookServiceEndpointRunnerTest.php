<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageService;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AnthropicUsageClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\ClaudeCodeAnalyticsClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\OpenAiUsageClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\StatusPageClient;
use Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook\WebhookSignatureVerifier;
use Cehlers88\AnalyticsDevelopeBundle\ServiceEndpointRunner\ClaudeWebhookServiceEndpointRunner;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Cache\Adapter\ArrayAdapter;
use Symfony\Component\HttpClient\MockHttpClient;
use Symfony\Component\HttpFoundation\Request;

final class ClaudeWebhookServiceEndpointRunnerTest extends TestCase
{
    private const SECRET = 'whsec_MfKQ9r8GKYqrTwjUPD8ILPZIo2LaLaSw';
    private const ENDPOINT = 'AnalyticsDevelopeBundle.claudeWebhook';

    /** @var TrackingBuffer[] */
    private array $saved = [];

    private function runner(array $constants): ClaudeWebhookServiceEndpointRunner
    {
        $configuration = $this->createMock(ConfigurationProvider::class);
        $configuration->method('getValue')->willReturnCallback(
            static fn(string $group, string $item, int $applicationId = -1, mixed $default = null): mixed
                => $constants[($applicationId > 0 ? '@' . $applicationId . ':' : '') . $group . '.' . $item] ?? $default
        );
        $http = new MockHttpClient(static fn() => throw new \LogicException('no request expected'));
        $constantService = new AiUsageService(new AnthropicUsageClient($http), new OpenAiUsageClient($http), $configuration, new ArrayAdapter(), new ClaudeCodeAnalyticsClient($http), new StatusPageClient($http));

        $applications = $this->createMock(ApplicationRepository::class);
        $applications->method('find')->willReturnCallback(function ($id) {
            if (!in_array($id, [1, 3], true)) {
                return null;
            }
            $application = $this->createMock(Application::class);
            $application->method('getId')->willReturn($id);

            return $application;
        });

        $buffers = $this->createMock(TrackingBufferRepository::class);
        $buffers->method('save')->willReturnCallback(function (TrackingBuffer $buffer) use ($buffers) {
            $this->saved[] = $buffer;

            return $buffers;
        });

        return new ClaudeWebhookServiceEndpointRunner(new WebhookSignatureVerifier(), $constantService, $applications, $buffers);
    }

    private static function request(string $body, string $secret = self::SECRET, string $query = '', ?int $timestamp = null): Request
    {
        $timestamp = (string)($timestamp ?? time());
        $signature = WebhookSignatureVerifier::sign(WebhookSignatureVerifier::key($secret), 'msg_1', $timestamp, $body);
        $request = Request::create('/api/se/' . self::ENDPOINT . $query, 'POST', [], [], [], ['CONTENT_TYPE' => 'application/json'], $body);
        $request->headers->add(['webhook-id' => 'msg_1', 'webhook-timestamp' => $timestamp, 'webhook-signature' => 'v1,' . $signature]);

        return $request;
    }

    private static function body(): string
    {
        return json_encode(['type' => 'event', 'id' => 'whe_1', 'created_at' => '2026-11-06T10:00:00Z',
            'data' => ['type' => 'session.status_idled', 'id' => 'sesn_1', 'organization_id' => 'org', 'workspace_id' => 'ws']]);
    }

    public function testASignedDeliveryIsStoredAsTrackingBuffer(): void
    {
        $result = $this->runner(['CONSTANT.ANTHROPIC_WEBHOOK_SIGNING_KEY' => self::SECRET])->runEndpoint(self::ENDPOINT, self::request(self::body()));

        self::assertFalse($result->hasError, $result->message);
        self::assertSame(200, $result->statusCode);
        self::assertSame(['received' => 'whe_1'], $result->data);
        self::assertCount(1, $this->saved);
        $data = $this->saved[0]->getData();
        self::assertSame(ClaudeWebhookServiceEndpointRunner::BUFFER_KEY, $data['key']);
        self::assertSame('session.status_idled', $data['data']['eventType']);
        self::assertSame('whe_1', $data['body']['id']);
        self::assertSame(1, $this->saved[0]->getApplication()->getId());
    }

    public function testAWrongSignatureIsRefusedAndNothingStored(): void
    {
        $other = 'whsec_' . base64_encode(str_repeat('k', 32));
        $result = $this->runner(['CONSTANT.ANTHROPIC_WEBHOOK_SIGNING_KEY' => self::SECRET])->runEndpoint(self::ENDPOINT, self::request(self::body(), $other));

        self::assertTrue($result->hasError);
        self::assertSame(400, $result->statusCode);
        self::assertSame([], $this->saved);
    }

    public function testAReplayedDeliveryIsRefused(): void
    {
        $result = $this->runner(['CONSTANT.ANTHROPIC_WEBHOOK_SIGNING_KEY' => self::SECRET])->runEndpoint(self::ENDPOINT, self::request(self::body(), self::SECRET, '', time() - 3600));

        self::assertSame(400, $result->statusCode);
        self::assertSame([], $this->saved);
    }

    public function testWithoutSecretTheEndpointAnswersUnavailable(): void
    {
        $result = $this->runner([])->runEndpoint(self::ENDPOINT, self::request(self::body()));

        self::assertSame(503, $result->statusCode);
        self::assertStringContainsString('ANTHROPIC_WEBHOOK_SIGNING_KEY', $result->message);
    }

    public function testTheApplicationsOwnSecretAndASecondConstant(): void
    {
        $runner = $this->runner([
            'CONSTANT.ANTHROPIC_WEBHOOK_SIGNING_KEY' => 'whsec_' . base64_encode('server'),
            '@3:CONSTANT.ANTHROPIC_WEBHOOK_SIGNING_KEY_PROD' => self::SECRET,
        ]);

        $result = $runner->runEndpoint(self::ENDPOINT, self::request(self::body(), self::SECRET, '?application=3&constant=ANTHROPIC_WEBHOOK_SIGNING_KEY_PROD'));
        self::assertFalse($result->hasError, $result->message);
        self::assertSame(3, $this->saved[0]->getApplication()->getId());

        // only constants of the webhook can be named, and only existing applications
        self::assertSame(400, $runner->runEndpoint(self::ENDPOINT, self::request(self::body(), self::SECRET, '?constant=OPENAI_API_KEY'))->statusCode);
        self::assertSame(400, $runner->runEndpoint(self::ENDPOINT, self::request(self::body(), self::SECRET, '?application=99'))->statusCode);
    }

    public function testTheEndpointNeedsNoSignIn(): void
    {
        $runner = $this->runner([]);

        self::assertSame([], $runner->getRequiredRoles());
        self::assertTrue($runner->canHandle(self::ENDPOINT, Request::create('/', 'POST')));
        self::assertFalse($runner->canHandle(self::ENDPOINT, Request::create('/', 'GET')));
    }
}
