<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Worker\Job\Claude;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook\ClaudeWebhookSynchronizer;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\ClaudeWorkspace;
use Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Claude\UpdateClaudeWorkspacesJob;
use PHPUnit\Framework\TestCase;

final class UpdateClaudeWorkspacesJobTest extends TestCase
{
    private static function buffer(mixed $body): TrackingBuffer
    {
        $buffer = new TrackingBuffer();
        $buffer->setState(eTrackingBufferState::NEW)->setTimestamp(new \DateTime('2026-11-06 10:00 UTC'))
            ->setData(['key' => 'SERVICE_ENDPOINT.claude_webhook', 'body' => $body]);

        return $buffer;
    }

    public function testEventsReachTheWorkspaceAndTheBuffersAreFinished(): void
    {
        $saved = [];
        $provider = $this->createMock(CustomObjectProvider::class);
        $provider->method('getCustomEntitiesByClassName')->willReturn([]);
        $provider->method('createNewCustomEntity')->willReturnCallback(fn(string $class) => new $class());
        $provider->method('save')->willReturnCallback(function ($object) use (&$saved) {
            $saved[] = $object;
        });
        $repository = $this->createMock(TrackingBufferRepository::class);
        $repository->expects(self::once())->method('flush');

        $event = ['type' => 'event', 'id' => 'whe_1', 'created_at' => '2026-11-06T10:00:00Z',
            'data' => ['type' => 'session.status_run_started', 'id' => 'sesn_1', 'workspace_id' => 'ws']];
        $buffers = [self::buffer($event), self::buffer(json_encode($event)), self::buffer(['zen' => 'test'])];

        $job = new UpdateClaudeWorkspacesJob(new ClaudeWebhookSynchronizer($provider), $repository);
        $job->setWorkingObjects($buffers);
        $job->run();

        self::assertCount(1, $saved);
        self::assertInstanceOf(ClaudeWorkspace::class, $saved[0]);
        self::assertSame('1', $saved[0]->getAttribute('events_total'), 'the second buffer is a retry of the first');
        foreach ($buffers as $buffer) {
            self::assertSame(eTrackingBufferState::PROCESSED_FINISHED, $buffer->getState());
        }
        self::assertTrue($buffers[0]->getHandlerData()[UpdateClaudeWorkspacesJob::HANDLER_DATA_KEY]);
        self::assertFalse($buffers[2]->getHandlerData()[UpdateClaudeWorkspacesJob::HANDLER_DATA_KEY]);
    }
}
