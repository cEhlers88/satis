<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

/**
 * A workspace of the Claude Console whose webhooks reach this installation - created by
 * ClaudeWebhookSynchronizer on its first event, one per workspace_id. The name is only set
 * then and may be changed freely; the workspace is recognised by its workspace_id.
 *
 * Lists and maps are stored as JSON strings (ClaudeWebhookSynchronizer::JSON_ATTRIBUTES),
 * ClaudeWorkspaceAssembler hands them to the tile as arrays.
 */
class ClaudeWorkspace extends AbstractCustomObject
{
    public function getWorkspaceId(): string
    {
        return (string)$this->getAttribute('workspace_id', '');
    }

    public function setWorkspaceId(string $workspaceId): static
    {
        return $this->setAttribute('workspace_id', $workspaceId);
    }

    public function getTileTemplate(): ?string
    {
        return 'customObject/tile/claudeWorkspace.html.twig';
    }
}
