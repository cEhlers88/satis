<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\ServiceEndpointRunner;

use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\AbstractServiceEndpointRunner;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\EndpointDefinitionDTO;
use Cehlers88\AnalyticsCore\ServiceEndpointRunner\DTO\ServiceEndpointRunnerResultDTO;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageService;
use Cehlers88\AnalyticsDevelopeBundle\AnalyticsDevelopeBundle;
use Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook\WebhookSignatureVerifier;
use Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook\WebhookVerificationException;
use Symfony\Component\HttpFoundation\Request;

/**
 * Receives the webhooks of the Claude Console (Settings → Workspaces → Webhooks):
 *
 *   POST /api/se/AnalyticsDevelopeBundle.claudeWebhook[?application=<id>][&constant=<name>]
 *
 * The endpoint is public like every /api/se call - what keeps strangers out is the signature,
 * checked against the endpoint's signing secret ("whsec_…", shown once when the endpoint is
 * created in the Console). It is read from the constant ANTHROPIC_WEBHOOK_SIGNING_KEY
 * (settings → Constants; the name the Anthropic SDKs use too), the application's own value
 * first when ?application= names one. Several Console endpoints with their own secrets can
 * use ?constant=ANTHROPIC_WEBHOOK_SIGNING_KEY_<SUFFIX> - only names with that prefix, so the
 * query string cannot point the check at some other constant.
 *
 * A verified delivery is only stored as tracking buffer (key SERVICE_ENDPOINT.claude_webhook)
 * and answered at once - Anthropic asks for a quick 2xx and retries anything else. The
 * ClaudeWebhookBufferWorker then brings the ClaudeWorkspace custom objects up to date.
 */
final class ClaudeWebhookServiceEndpointRunner extends AbstractServiceEndpointRunner
{
    public const ENDPOINT = 'claudeWebhook';
    public const BUFFER_KEY = TrackingBuffer::KEY_SERVICE_ENDPOINT . '.claude_webhook';
    public const DEFAULT_CONSTANT = 'ANTHROPIC_WEBHOOK_SIGNING_KEY';
    /** The application the buffers belong to when the url names none - the one /api/se runs in. */
    public const DEFAULT_APPLICATION_ID = 1;

    public function __construct(
        private readonly WebhookSignatureVerifier $verifier,
        private readonly AiUsageService           $constants,
        private readonly ApplicationRepository    $applicationRepository,
        private readonly TrackingBufferRepository $trackingBufferRepository,
    )
    {
    }

    public function getEndpoints(): mixed
    {
        return [
            EndpointDefinitionDTO::create(
                self::ENDPOINT,
                ['POST'],
                [],
                [],
                'Webhook der Claude Console (Workspaces → Webhooks). Signiert nach Standard Webhooks; '
                . 'Signing-Secret in der Konstante ' . self::DEFAULT_CONSTANT . '.'
            )->withSuccessExample(['received' => 'whe_01…'], 'Claude webhook received'),
        ];
    }

    public function getBundleName(): string
    {
        return AnalyticsDevelopeBundle::NAME;
    }

    /** Anthropic cannot sign in - the signature is the authentication. */
    public function getRequiredRoles(): array
    {
        return [];
    }

    public function handleRequest(string $endpointName, Request $request): ServiceEndpointRunnerResultDTO
    {
        $constantName = $this->constantName((string)$request->query->get('constant', ''));
        if ($constantName === null) {
            return ServiceEndpointRunnerResultDTO::createError(sprintf('constant must start with %s', self::DEFAULT_CONSTANT), 400);
        }

        $application = $this->application((string)$request->query->get('application', ''));
        if ($application === null) {
            return ServiceEndpointRunnerResultDTO::createError('Unknown application', 400);
        }

        $secret = $this->constants->constantValue($constantName, (int)$application->getId());
        if ($secret === '') {
            // not the sender's fault: a 5xx makes Anthropic retry until the secret is entered
            return ServiceEndpointRunnerResultDTO::createError(sprintf('Signing secret not configured (constant %s)', $constantName), 503);
        }

        $body = $request->getContent();
        try {
            $this->verifier->verify($secret, $body, [
                'webhook-id' => $request->headers->get('webhook-id'),
                'webhook-timestamp' => $request->headers->get('webhook-timestamp'),
                'webhook-signature' => $request->headers->get('webhook-signature'),
            ]);
        } catch (WebhookVerificationException $exception) {
            return ServiceEndpointRunnerResultDTO::createError('Invalid signature: ' . $exception->getMessage(), 400);
        }

        $event = json_decode($body, true);
        if (!is_array($event)) {
            return ServiceEndpointRunnerResultDTO::createError('Body is no JSON object', 400);
        }

        $trackingBuffer = new TrackingBuffer();
        $trackingBuffer
            ->setApplication($application)
            ->setTimestamp(new \DateTime())
            ->setState(eTrackingBufferState::NEW)
            ->setData([
                'key' => self::BUFFER_KEY,
                'data' => [
                    'webhookId' => (string)$request->headers->get('webhook-id'),
                    'eventType' => is_array($event['data'] ?? null) ? (string)($event['data']['type'] ?? '') : '',
                ],
                'body' => $event,
            ])
            ->setNote('');
        $this->trackingBufferRepository->save($trackingBuffer, true);

        return ServiceEndpointRunnerResultDTO::createSuccess(['received' => (string)($event['id'] ?? '')], 'Claude webhook received');
    }

    private function constantName(string $requested): ?string
    {
        $requested = AiUsageService::normalizeConstantName($requested);
        if ($requested === '') {
            return self::DEFAULT_CONSTANT;
        }

        return str_starts_with($requested, self::DEFAULT_CONSTANT) ? $requested : null;
    }

    private function application(string $requested): ?Application
    {
        if ($requested !== '' && preg_match('/^\d+$/', $requested) !== 1) {
            return null;
        }
        $application = $this->applicationRepository->find($requested === '' ? self::DEFAULT_APPLICATION_ID : (int)$requested);

        return $application instanceof Application ? $application : null;
    }
}
