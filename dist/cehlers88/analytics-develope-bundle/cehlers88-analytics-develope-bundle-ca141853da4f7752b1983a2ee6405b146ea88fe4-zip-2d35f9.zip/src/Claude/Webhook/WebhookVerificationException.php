<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook;

/** A delivery that cannot be shown to come from Anthropic - it is refused, not stored. */
final class WebhookVerificationException extends \RuntimeException
{
}
