<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook;

use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\ClaudeWorkspace;

/**
 * Applies the events of the Claude Console webhooks to one ClaudeWorkspace custom object per
 * workspace - created on the workspace's first event, so nothing has to be set up besides the
 * endpoint itself.
 *
 * The events are thin: {type: "event", id, created_at, data: {type, id, organization_id,
 * workspace_id, …}} - which resource changed and how, never the resource itself. So the
 * workspace keeps
 *   - event_counts / events_total     how many events of each type arrived,
 *   - recent_events                   the newest ones (also what duplicates are told apart by),
 *   - resources                       the last known status of each session, deployment run,
 *                                     agent, … ("<kind>:<id>" => {kind, id, status, event, at}),
 *   - the counters the tile shows (open/running/waiting sessions, failed runs, credentials).
 *
 * Anthropic retries a delivery up to three times and does not keep the order, so an event id
 * seen before is skipped, and a resource's status only moves forward by the events'
 * created_at - a late "idled" never overwrites a newer "terminated".
 *
 * Everything lives in a few attributes of one object instead of a custom object per session:
 * custom objects cannot be deleted from here, and sessions come and go by the hundred.
 */
final class ClaudeWebhookSynchronizer
{
    /** Events kept per workspace - enough to recognise every retry of the last minutes. */
    public const RECENT_EVENTS = 100;
    /** Event ids remembered in the order they arrived - Anthropic's retries all fall within minutes. */
    public const SEEN_EVENT_IDS = 500;
    /** Resources that ended and made room, with the time of their last status. */
    public const MAX_ENDED_RESOURCES = 500;
    /** Resources kept per workspace; deleted and ended ones make room first. */
    public const MAX_RESOURCES = 200;

    public const JSON_ATTRIBUTES = ['event_counts', 'recent_events', 'resources', 'seen_event_ids', 'ended_resources'];

    /** Session states in which the session still exists and may work again. */
    public const OPEN_SESSION_STATES = ['created', 'pending', 'running', 'idle', 'requires_action', 'rescheduled', 'budget_reached'];
    /** Session states that wait for someone (a tool approval, a new message, more budget). */
    public const WAITING_SESSION_STATES = ['idle', 'requires_action', 'budget_reached'];

    /**
     * Event action => status of the resource, per kind ('*' for every kind). Actions not
     * listed (session.updated, session.thread_*, session.outcome_evaluation_ended, …) say
     * nothing about the resource's own status and leave it as it is.
     */
    private const STATUS_BY_ACTION = [
        'session' => [
            'created' => 'created',
            'pending' => 'pending',
            'running' => 'running',
            'status_run_started' => 'running',
            'idled' => 'idle',
            'status_idled' => 'idle',
            'requires_action' => 'requires_action',
            'status_rescheduled' => 'rescheduled',
            'budget_reached' => 'budget_reached',
            'status_terminated' => 'terminated',
            'archived' => 'archived',
            'deleted' => 'deleted',
        ],
        'deployment_run' => [
            'started' => 'running',
            'succeeded' => 'succeeded',
            'failed' => 'failed',
        ],
        'vault_credential' => [
            'refresh_failed' => 'refresh_failed',
        ],
        'user_profile' => [
            'enforcement_action_opened' => 'enforcement_action_open',
            'enforcement_action_resolved' => 'active',
        ],
        '*' => [
            'created' => 'active',
            'unpaused' => 'active',
            'paused' => 'paused',
            'archived' => 'archived',
            'deleted' => 'deleted',
        ],
    ];

    /** States a resource no longer comes back from - these make room first. */
    private const FINAL_STATES = ['deleted', 'archived', 'terminated', 'succeeded', 'failed'];

    /** @var array<string, ClaudeWorkspace>|null workspace_id => object */
    private ?array $workspaces = null;

    /** @var array<int, ClaudeWorkspace> spl_object_id => object */
    private array $changed = [];

    public function __construct(
        private readonly CustomObjectProvider $customObjectProvider,
    )
    {
    }

    /** Forget the loaded objects, e.g. at the start of a worker run. */
    public function reset(): void
    {
        $this->workspaces = null;
        $this->changed = [];
    }

    /**
     * @param array<string, mixed> $event the decoded body of a delivery
     *
     * @return bool whether it was a webhook event (false for anything else, e.g. a test call)
     */
    public function apply(array $event, \DateTimeInterface $receivedAt): bool
    {
        $data = $event['data'] ?? null;
        $eventId = is_string($event['id'] ?? null) ? $event['id'] : '';
        if (!is_array($data) || $eventId === '' || !is_string($data['type'] ?? null) || $data['type'] === '') {
            return false;
        }

        $type = $data['type'];
        $workspaceId = is_string($data['workspace_id'] ?? null) && $data['workspace_id'] !== '' ? $data['workspace_id'] : 'default';
        $createdAt = self::timestamp($event['created_at'] ?? null) ?? self::timestamp($receivedAt->format(\DateTimeInterface::ATOM));
        $resourceId = is_scalar($data['id'] ?? null) ? (string)$data['id'] : '';

        $workspace = $this->findOrCreateWorkspace($workspaceId, $data);
        // Kept apart from recent_events, which is ordered by when the events happened: a late
        // event would fall out of it at once and its retry would count again.
        $seenIds = array_values(array_filter(self::decodeMap($workspace->getAttribute('seen_event_ids')), 'is_string'));
        if (in_array($eventId, $seenIds, true)) {
            return true;
        }
        $seenIds[] = $eventId;
        $seenIds = array_slice($seenIds, -self::SEEN_EVENT_IDS);

        $recent = self::decodeList($workspace->getAttribute('recent_events'));

        $entry = ['id' => $eventId, 'type' => $type, 'resource_id' => $resourceId, 'created_at' => $createdAt];
        foreach (['session_thread_id', 'vault_id', 'enforcement_action_id'] as $extra) {
            if (is_scalar($data[$extra] ?? null) && (string)$data[$extra] !== '') {
                $entry[$extra] = (string)$data[$extra];
            }
        }
        $recent[] = $entry;
        // newest first, by when the event happened - not by when it arrived
        usort($recent, static fn(array $a, array $b): int => strcmp((string)($b['created_at'] ?? ''), (string)($a['created_at'] ?? '')));
        $recent = array_slice($recent, 0, self::RECENT_EVENTS);

        $counts = self::decodeMap($workspace->getAttribute('event_counts'));
        $counts[$type] = (int)($counts[$type] ?? 0) + 1;
        ksort($counts);

        $resources = self::decodeMap($workspace->getAttribute('resources'));
        $ended = self::decodeMap($workspace->getAttribute('ended_resources'));
        if ($resourceId !== '') {
            $resources = $this->applyToResource($resources, $ended, $type, $resourceId, $createdAt, $entry);
        }

        $attributes = [
            'organization_id' => is_string($data['organization_id'] ?? null) ? $data['organization_id'] : $workspace->getAttribute('organization_id'),
            'events_total' => (string)((int)$workspace->getAttribute('events_total', '0') + 1),
            'event_counts' => self::encode($counts),
            'recent_events' => self::encode($recent),
            'resources' => self::encode($resources),
            'ended_resources' => self::encode($ended),
            'seen_event_ids' => self::encode($seenIds),
            'last_received_at' => self::timestamp($receivedAt->format(\DateTimeInterface::ATOM)),
        ] + self::counters($resources);

        if (strcmp((string)$createdAt, (string)$workspace->getAttribute('last_event_at', '')) >= 0) {
            $attributes['last_event_type'] = $type;
            $attributes['last_event_at'] = $createdAt;
        }
        if ($type === 'deployment_run.failed'
            && strcmp((string)$createdAt, (string)$workspace->getAttribute('last_failed_run_at', '')) >= 0) {
            $attributes['last_failed_run_at'] = $createdAt;
            $attributes['last_failed_run_id'] = $resourceId;
        }

        $this->setAttributes($workspace, $attributes);

        return true;
    }

    /** Save every workspace apply() changed. */
    public function flush(): void
    {
        $changed = $this->changed;
        $this->changed = [];

        foreach ($changed as $workspace) {
            $this->customObjectProvider->save($workspace);
        }
    }

    /** The status an event gives its resource; null when it says nothing about it. */
    public static function statusOf(string $type): ?string
    {
        [$kind, $action] = array_pad(explode('.', $type, 2), 2, '');

        return self::STATUS_BY_ACTION[$kind][$action] ?? self::STATUS_BY_ACTION['*'][$action] ?? null;
    }

    /** "session.status_idled" => "session". */
    public static function kindOf(string $type): string
    {
        return explode('.', $type, 2)[0];
    }

    /**
     * @param array<string, array<string, mixed>> $resources
     * @param array<string, string> $ended "<kind>:<id>" => status_at of resources that made room
     * @param array<string, string> $entry
     *
     * @return array<string, array<string, mixed>>
     */
    private function applyToResource(array $resources, array &$ended, string $type, string $resourceId, ?string $createdAt, array $entry): array
    {
        $kind = self::kindOf($type);
        $key = $kind . ':' . $resourceId;

        // A resource that ended and made room stays ended: a late event from before its end
        // must not bring it back as running.
        if (!isset($resources[$key]) && isset($ended[$key]) && strcmp((string)$createdAt, (string)$ended[$key]) < 0) {
            return $resources;
        }
        unset($ended[$key]);
        $resource = is_array($resources[$key] ?? null) ? $resources[$key] : ['kind' => $kind, 'id' => $resourceId, 'status' => ''];

        // Only newer events move the resource on, an older one arriving late changes nothing.
        // The status keeps its own time: a late "run_started" still counts after a newer
        // thread event, which said nothing about the status.
        $status = self::statusOf($type);
        if ($status !== null && strcmp((string)$createdAt, (string)($resource['status_at'] ?? '')) >= 0) {
            $resource['status'] = $status;
            $resource['status_at'] = $createdAt;
        } elseif (($resource['status'] ?? '') === '' && $kind !== 'session') {
            // e.g. an agent first seen with "agent.updated" - it exists, whatever happened before
            $resource['status'] = 'active';
        }
        if (strcmp((string)$createdAt, (string)($resource['at'] ?? '')) >= 0) {
            $resource['event'] = $type;
            $resource['at'] = $createdAt;
        }
        foreach (['session_thread_id', 'vault_id'] as $extra) {
            if (isset($entry[$extra])) {
                $resource[$extra] = $entry[$extra];
            }
        }
        $resources[$key] = $resource;

        if (count($resources) > self::MAX_RESOURCES) {
            // ended ones first, then the ones that have not changed for longest
            uasort($resources, static function (array $a, array $b): int {
                $aFinal = in_array($a['status'] ?? '', self::FINAL_STATES, true);
                $bFinal = in_array($b['status'] ?? '', self::FINAL_STATES, true);

                return $aFinal === $bFinal ? strcmp((string)($b['at'] ?? ''), (string)($a['at'] ?? '')) : ($aFinal ? 1 : -1);
            });
            foreach (array_slice($resources, self::MAX_RESOURCES, null, true) as $evictedKey => $evicted) {
                if (in_array($evicted['status'] ?? '', self::FINAL_STATES, true)) {
                    $ended[$evictedKey] = (string)($evicted['status_at'] ?? $evicted['at'] ?? '');
                }
            }
            $ended = array_slice($ended, -self::MAX_ENDED_RESOURCES, null, true);
            $resources = array_slice($resources, 0, self::MAX_RESOURCES, true);
        }
        ksort($resources);

        return $resources;
    }

    /**
     * @param array<string, array<string, mixed>> $resources
     *
     * @return array<string, string>
     */
    private static function counters(array $resources): array
    {
        $counters = ['open_sessions_count' => 0, 'running_sessions_count' => 0, 'waiting_sessions_count' => 0,
            'failed_runs_count' => 0, 'failed_credentials_count' => 0, 'paused_deployments_count' => 0];

        foreach ($resources as $resource) {
            $status = (string)($resource['status'] ?? '');
            switch ($resource['kind'] ?? '') {
                case 'session':
                    $counters['open_sessions_count'] += in_array($status, self::OPEN_SESSION_STATES, true) ? 1 : 0;
                    $counters['running_sessions_count'] += $status === 'running' ? 1 : 0;
                    $counters['waiting_sessions_count'] += in_array($status, self::WAITING_SESSION_STATES, true) ? 1 : 0;
                    break;
                case 'deployment_run':
                    $counters['failed_runs_count'] += $status === 'failed' ? 1 : 0;
                    break;
                case 'vault_credential':
                    $counters['failed_credentials_count'] += $status === 'refresh_failed' ? 1 : 0;
                    break;
                case 'deployment':
                    $counters['paused_deployments_count'] += $status === 'paused' ? 1 : 0;
                    break;
            }
        }

        return array_map('strval', $counters);
    }

    /** @param array<string, mixed> $data */
    private function findOrCreateWorkspace(string $workspaceId, array $data): ClaudeWorkspace
    {
        if ($this->workspaces === null) {
            $this->workspaces = [];
            foreach ($this->customObjectProvider->getCustomEntitiesByClassName(ClaudeWorkspace::class) as $workspace) {
                if ($workspace instanceof ClaudeWorkspace && $workspace->getWorkspaceId() !== '') {
                    $this->workspaces[$workspace->getWorkspaceId()] = $workspace;
                }
            }
        }

        if (!isset($this->workspaces[$workspaceId])) {
            /** @var ClaudeWorkspace $workspace */
            $workspace = $this->customObjectProvider->createNewCustomEntity(ClaudeWorkspace::class);
            $workspace->setName($workspaceId === 'default' ? 'Claude Workspace' : 'Claude Workspace ' . substr($workspaceId, 0, 8));
            $workspace->setWorkspaceId($workspaceId);
            if (is_string($data['organization_id'] ?? null)) {
                $workspace->setAttribute('organization_id', $data['organization_id']);
            }
            // saved once by flush(), a new object gets no id back from save()
            $this->changed[spl_object_id($workspace)] = $workspace;
            $this->workspaces[$workspaceId] = $workspace;
        }

        return $this->workspaces[$workspaceId];
    }

    /** Sets the attributes and remembers the workspace for flush() if anything differs. */
    private function setAttributes(ClaudeWorkspace $workspace, array $attributes): void
    {
        foreach ($attributes as $name => $value) {
            if ($value === null || ($workspace->hasAttribute($name) && $workspace->getAttribute($name) === $value)) {
                continue;
            }
            $workspace->setAttribute($name, $value);
            $this->changed[spl_object_id($workspace)] = $workspace;
        }
    }

    /**
     * RFC 3339 in UTC with a fixed six-digit fraction, so the strings compare like the times
     * they stand for - also within one second.
     */
    public static function timestamp(mixed $value): ?string
    {
        if (!is_string($value) || trim($value) === '') {
            return null;
        }
        try {
            return (new \DateTimeImmutable($value))->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d\TH:i:s.u\Z');
        } catch (\Exception) {
            return null;
        }
    }

    private static function encode(array $value): string
    {
        return (string)json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    /** @return list<array<string, mixed>> */
    private static function decodeList(mixed $value): array
    {
        $decoded = is_string($value) ? json_decode($value, true) : $value;

        return is_array($decoded) ? array_values(array_filter($decoded, 'is_array')) : [];
    }

    /** @return array<string, mixed> */
    private static function decodeMap(mixed $value): array
    {
        $decoded = is_string($value) ? json_decode($value, true) : $value;

        return is_array($decoded) ? $decoded : [];
    }
}
