<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook;

/**
 * Checks the signature of a Claude Console webhook delivery. Anthropic signs them after the
 * Standard Webhooks scheme (https://www.standardwebhooks.com), which its SDKs verify with
 * webhooks.unwrap():
 *
 *   signed content  "{webhook-id}.{webhook-timestamp}.{raw body}"
 *   signature       base64(HMAC-SHA256(signed content, secret))
 *   secret          the "whsec_…" value of the endpoint, base64 after the prefix
 *   header          "webhook-signature: v1,<signature> [v1,<signature> …]" - several while
 *                   a secret is being rotated, any one of them may match
 *
 * The timestamp is renewed for every delivery attempt, so a tolerance of five minutes (the
 * SDKs' one) refuses replayed requests without refusing Anthropic's own retries.
 */
final class WebhookSignatureVerifier
{
    public const TOLERANCE_SECONDS = 300;
    public const SECRET_PREFIX = 'whsec_';

    /**
     * @param array<string, string|null> $headers webhook-id, webhook-timestamp and webhook-signature
     *
     * @throws WebhookVerificationException
     */
    public function verify(string $secret, string $body, array $headers, ?int $now = null): void
    {
        $headers = array_change_key_case($headers, CASE_LOWER);
        $id = trim((string)($headers['webhook-id'] ?? ''));
        $timestamp = trim((string)($headers['webhook-timestamp'] ?? ''));
        $signatures = trim((string)($headers['webhook-signature'] ?? ''));

        if ($id === '' || $timestamp === '' || $signatures === '') {
            throw new WebhookVerificationException('Missing webhook-id, webhook-timestamp or webhook-signature header');
        }
        if (preg_match('/^\d{1,12}$/', $timestamp) !== 1) {
            throw new WebhookVerificationException('Invalid webhook-timestamp header');
        }
        if (abs(($now ?? time()) - (int)$timestamp) > self::TOLERANCE_SECONDS) {
            throw new WebhookVerificationException('Webhook timestamp outside the tolerance of five minutes');
        }

        $expected = self::sign(self::key($secret), $id, $timestamp, $body);
        foreach (preg_split('/\s+/', $signatures) ?: [] as $versioned) {
            [$version, $signature] = array_pad(explode(',', $versioned, 2), 2, '');
            if ($version === 'v1' && hash_equals($expected, $signature)) {
                return;
            }
        }

        throw new WebhookVerificationException('No matching webhook signature');
    }

    /** The signature of a delivery - what the header carries after "v1,". */
    public static function sign(string $key, string $id, string $timestamp, string $body): string
    {
        return base64_encode(hash_hmac('sha256', $id . '.' . $timestamp . '.' . $body, $key, true));
    }

    /**
     * The HMAC key of a "whsec_…" secret. Anything that is no base64 after the prefix is
     * taken as it is, so a secret pasted with a stray character fails the signature check
     * instead of silently turning into a different key.
     *
     * @throws WebhookVerificationException
     */
    public static function key(string $secret): string
    {
        $secret = trim($secret);
        if ($secret === '') {
            throw new WebhookVerificationException('No signing secret configured');
        }
        if (str_starts_with($secret, self::SECRET_PREFIX)) {
            $secret = substr($secret, strlen(self::SECRET_PREFIX));
        }
        $decoded = base64_decode($secret, true);

        return $decoded === false || $decoded === '' ? $secret : $decoded;
    }
}
