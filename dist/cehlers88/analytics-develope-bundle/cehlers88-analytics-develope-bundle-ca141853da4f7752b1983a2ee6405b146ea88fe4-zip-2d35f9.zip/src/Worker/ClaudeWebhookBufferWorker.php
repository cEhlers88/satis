<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Worker;

use Cehlers88\AnalyticsCore\Worker\AbstractWorker;
use Cehlers88\AnalyticsDevelopeBundle\ServiceEndpointRunner\ClaudeWebhookServiceEndpointRunner;
use Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Claude\UpdateClaudeWorkspacesJob;

/**
 * Works off the deliveries ClaudeWebhookServiceEndpointRunner stored: brings the
 * ClaudeWorkspace custom objects up to date and finishes the buffers.
 */
class ClaudeWebhookBufferWorker extends AbstractWorker
{
    public function getRequiredJobs(): array
    {
        return [
            UpdateClaudeWorkspacesJob::class,
        ];
    }

    public function getWorkingObjects(): array
    {
        return $this->trackingBufferRepository->findByAnyDataKeyValue([ClaudeWebhookServiceEndpointRunner::BUFFER_KEY]);
    }
}
