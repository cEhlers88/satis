<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Claude;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook\ClaudeWebhookSynchronizer;

/**
 * Applies the received Claude webhook events to the ClaudeWorkspace custom objects, oldest
 * buffer first, and finishes each buffer - an event needs nothing else. A buffer that fails
 * stays NEW and is tried again on the next run.
 */
class UpdateClaudeWorkspacesJob extends AbstractWorkerJob
{
    public const HANDLER_DATA_KEY = 'claudeWorkspaceUpdated';

    /** @var TrackingBuffer[] */
    private array $buffers = [];

    public function __construct(
        private readonly ClaudeWebhookSynchronizer $synchronizer,
        private readonly TrackingBufferRepository  $trackingBufferRepository,
    )
    {
        $this->setType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_END);
    }

    public function willHandle(object $workingObject): bool
    {
        return $workingObject instanceof TrackingBuffer;
    }

    /**
     * @param TrackingBuffer $object
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $this->buffers[] = $object;

        return $this;
    }

    protected function startJob(): void
    {
        $this->buffers = [];
        $this->synchronizer->reset();
    }

    protected function finishJob(): void
    {
        usort($this->buffers, fn(TrackingBuffer $a, TrackingBuffer $b) => ($a->getId() ?? PHP_INT_MAX) <=> ($b->getId() ?? PHP_INT_MAX));

        $applied = [];
        foreach ($this->buffers as $buffer) {
            $body = $buffer->getData()['body'] ?? null;
            if (is_string($body)) {
                $body = json_decode($body, true);
            }

            try {
                $isEvent = is_array($body) && $this->synchronizer->apply($body, $buffer->getTimestamp() ?? new \DateTimeImmutable());
            } catch (\Throwable $e) {
                $this->logWarning(sprintf('Tracking buffer %s: Claude workspace not updated: %s', $buffer->getId(), $e->getMessage()));
                continue;
            }
            $applied[] = [$buffer, $isEvent];
        }

        foreach ($applied as [$buffer, $isEvent]) {
            $buffer->setHandlerData([...($buffer->getHandlerData() ?? []), self::HANDLER_DATA_KEY => $isEvent]);
            $buffer->setState(eTrackingBufferState::PROCESSED_FINISHED);
        }

        try {
            $this->synchronizer->flush();
            // the workspaces may all be unchanged (nothing but retries) - the buffers are saved anyway
            $this->trackingBufferRepository->flush();
        } catch (\Throwable $e) {
            // the buffers stay NEW and are applied again on the next run
            foreach ($applied as [$buffer]) {
                $buffer->setState(eTrackingBufferState::NEW);
            }
            $this->logWarning('Saving the Claude workspaces failed: ' . $e->getMessage());
        }
        $this->buffers = [];

        parent::finishJob();
    }

    public function getDescription(): string
    {
        return 'Update the ClaudeWorkspace custom objects with the events of the Claude Console webhooks.';
    }
}
