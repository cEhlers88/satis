<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Presentation\Frontend\Assembler;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;
use Cehlers88\AnalyticsCore\Entity\EntityInterface;
use Cehlers88\AnalyticsCore\Presentation\Frontend\Assembler\CustomObjectAssembler;
use Cehlers88\AnalyticsCore\Presentation\Frontend\View\CustomObjectView;
use Cehlers88\AnalyticsDevelopeBundle\Claude\Webhook\ClaudeWebhookSynchronizer;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\ClaudeWorkspace;

class ClaudeWorkspaceAssembler extends CustomObjectAssembler
{
    public function canHandle(string $className): bool
    {
        return $className === ClaudeWorkspace::class;
    }

    /** Lists and maps are stored as JSON strings; the tile wants them as arrays. */
    protected function enrichView(EntityInterface|AbstractCustomObject $entity, CustomObjectView $view): CustomObjectView
    {
        foreach (ClaudeWebhookSynchronizer::JSON_ATTRIBUTES as $name) {
            $value = $view->attribute->{$name} ?? null;
            if (!is_string($value)) {
                continue;
            }
            $decoded = json_decode($value, true);
            if (is_array($decoded)) {
                $view->attribute->{$name} = $decoded;
            }
        }

        return $view;
    }
}
