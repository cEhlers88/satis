# Changelog

## [0.1.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([c39c6af](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c39c6af44469b9065e75f992998cbce6b579bce4))
