<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:36
 */

namespace Cehlers88\AnalyticsDevelopeBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

class GitRepository extends AbstractCustomObject
{
    public function getRepositoryPath(): string
    {
        return $this->getAttribute('repository_path', '');
    }

    public function setRepositoryPath(string $RepositoryPath): static
    {
        return $this->setAttribute('repository_path', $RepositoryPath);
    }
}