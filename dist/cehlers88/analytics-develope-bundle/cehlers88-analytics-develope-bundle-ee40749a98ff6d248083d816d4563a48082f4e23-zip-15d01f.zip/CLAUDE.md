# CLAUDE.md

Guidance for AI assistants working in this repository.

## What this repository is

`cehlers88/analytics-develope-bundle` — a **Symfony bundle plugin** for the private Analytics
platform. It adds developer/DevOps tooling to Analytics: git repository & issue custom objects,
GitHub-webhook tracking-buffer processing, and a remote-debug service endpoint.

It is a **library, not an application**. There is no `bin/console`, no kernel, no `vendor/`, no
test suite, and no CI that builds or lints PHP. The code only runs when installed into the host
Analytics application, so most changes cannot be executed or verified locally — review carefully
instead of relying on running anything.

- Composer type: `symfony-bundle`, license `proprietary`
- PSR-4 root: `Cehlers88\AnalyticsDevelopeBundle\` → `src/`
- PHP: **>= 8.4** (transitively required by `cehlers88/analytics-core`; the README's "PHP 7.4"
  line is stale — the code uses constructor promotion, `static` returns, `readonly`, enums)
- Sole runtime dependency: `cehlers88/analytics-core` (`1.*@dev`), pulled from the private Satis
  repository `https://cehlers88.github.io/satis`

## Layout

```
src/
  AnalyticsDevelopeBundle.php          # Bundle plugin entry point (extends AbstractBundlePlugin)
  Configuration/
    GeneralConfigurationGroup.php      # Config group key `developeBundle.general`
  CustomObject/
    GitRepository.php                  # attribute: repository_path; tile template
    GitIssue.php                       # attributes: title, state (open/closed)
  Observer/Message/
    RemoteDebugObserverMessage.php     # observer message key `develop.remote_debug`
  Presentation/Frontend/
    Assembler/GitRepositoryAssembler.php
    View/GitRepositoryView.php
  ServiceEndpointRunner/
    RemoteDebugServiceEndpointRunner.php  # POST endpoint `remoteDebug`
  Worker/
    DevelopWorker.php
    GitTrackingBufferWorker.php        # processes GitHub webhook tracking buffers
    Job/Git/EnrichTrackingEntityJob.php
    Job/Git/FetchRepositoryDetailInfosJob.php
  Resources/config/services.yaml       # DI wiring + tags
templates/
  customObject/tile/gitRepository.html.twig   # currently a stub ("dummy")
.github/workflows/                     # release-please + Satis rebuild dispatch
```

## Core concepts (all defined in `analytics-core`)

Everything here is an extension point of the core. When adding a class, find the matching abstract
base in `analytics-core` and follow its contract; do not invent new base classes.

- **Bundle plugin** — `AbstractBundlePlugin`. `AnalyticsDevelopeBundle` declares menu items,
  permissions, configuration groups, version and description. `self::NAME` is the bundle
  identifier used by e.g. `getBundleName()` on endpoint runners.
- **Custom objects** — `AbstractCustomObject`. Data lives in a generic attribute bag; expose it
  through typed `getX()`/`setX()` pairs that delegate to
  `getAttribute('snake_case_key', $default)` / `setAttribute(...)`. `setAttribute()` returns
  `static`, so setters `return $this->setAttribute(...)` for chaining. `getTileTemplate()`
  returns a path relative to `templates/`.
- **Configuration groups** — `AbstractConfigurationGroup`. `getKey()` is the persisted key;
  `getItems()` returns `ConfigurationItemDTO` factories (`createSelect`, `createRepeat`, …).
- **Workers & jobs** — `AbstractWorker` supplies `getWorkingObjects()` (usually via the injected
  `trackingBufferRepository`) and `getRequiredJobs()`, an ordered list of job classes.
  `AbstractWorkerJob` sets an `eWorkerJobType` in its constructor and implements
  `workOnObject()`, optionally `willHandle()`, `startJob()`, `finishJob()`.
- **Service endpoint runners** — `AbstractServiceEndpointRunner`. `getEndpoints()` returns
  `EndpointDefinitionDTO::create(name, methods, PropertyDTO[], …, callable)`; access control comes
  from `getRequiredRoles()` (`ExtendedRoleDTO`).
- **Observer messages** — implement `ObserverMessageInterface` with a `public const KEY` and
  dispatch through `ObserverProvider::dispatch()`.
- **Presentation** — an `*Assembler` (extending `CustomObjectAssembler`) sets `$viewClass` and
  answers `canHandle(string $className)`; the `*View` extends `CustomObjectView`.

## Dependency injection

`src/Resources/config/services.yaml` is the only wiring file. Autowire + autoconfigure are on and
the whole `src/` tree is registered, so **new classes usually need no explicit service entry** —
they get tagged automatically by `_instanceof` on the core interfaces:

| Interface (in `analytics-core`) | Tag |
| --- | --- |
| `Presentation\Assembler\AssemblerInterface` | `analytics.assemblers` |
| `Worker\WorkerInterface` | `analytics.worker` |
| `Worker\Job\JobInterface` | `worker_job` |
| `ServiceEndpointRunner\ServiceEndpointRunnerInterface` | `analytics.service_endpoint_runner` |

Two namespaces are tagged by directory and made `public`: `Configuration\` →
`analytics.configuration`, `CustomObject\` → `custom_object`. If you add a new *kind* of extension
point, add the corresponding `_instanceof` block rather than a per-class definition.

## GitHub webhook pipeline

1. The host application stores incoming webhooks as `TrackingBuffer` rows keyed
   `SERVICE_ENDPOINT.git_webhook` (or `BUFFER.git_repo_fetch`).
2. `GitTrackingBufferWorker::getWorkingObjects()` picks them up via
   `findByAnyDataKeyValue(REQUIRED_DATA_KEYS)`.
3. `EnrichTrackingEntityJob` json-decodes `data['body']` and derives `handlerData['eventReason']`
   (`push`, `first_branch_push`, `branch_delete`, `ping`, `pull_request_*`, `issue_*`,
   `workflow_run_completed`, `workflow_job_completed`) and `handlerData['repositoryName']`
   (`repository.full_name`). Add new event kinds in `evalEventReason()`.
4. `SetTrackingBuffersStateToProcessedFinishedJob` (from core) closes the buffers.

`FetchRepositoryDetailInfosJob` collects repository names and enqueues a follow-up
`BUFFER.git_repo_fetch` buffer, but is **commented out** of the worker's job list — it is
incomplete, not dead code to delete.

Note the duplicated constant: `GitTrackingBufferWorker::BUFFER_REPO_FETCH_KEY` and
`EnrichTrackingEntityJob::BUFFER_REPO_FETCH_KEY` both hold `'BUFFER.git_repo_fetch'`. Keep them in
sync if you touch either.

## Known rough edges (do not "fix" incidentally)

Leave these alone unless the task is explicitly about them; several are intentional work-in-progress.

- `AnalyticsDevelopeBundle` imports `Cehlers88\AnalyticsDocumentsBundle\ENUM\EPermission` and
  `GitRepositoryAssembler` imports `Cehlers88\AnalyticsInfrastructureBundle\…` — **sibling bundles
  that are not in `composer.json`**. `FetchRepositoryDetailInfosJob` and `DevelopWorker` import
  from the host application's `Analytics\…` namespace. These resolve only inside a full Analytics
  installation; static analysis will flag them.
- `getConfigurationGroups()` and `getMenuItems()` return empty arrays even though
  `GeneralConfigurationGroup` exists (it is picked up via the `analytics.configuration` tag).
- `GeneralConfigurationGroup::getGitRepositoriesAsSelectOptions()` has a dead `$t` assignment and
  calls the provider twice.
- `RemoteDebugServiceEndpointRunner` has a commented-out `handleRequest()` with an unfinished
  expression.
- `templates/customObject/tile/gitRepository.html.twig` is the literal string `dummy`.
- German and English are mixed in user-facing labels (config group titles are German). Match the
  surrounding text when editing a label.

## Conventions

- File header docblocks in the PhpStorm style (`Created by PhpStorm. / User: Christoph Ehlers …`)
  appear on older files; new files (e.g. the Presentation classes) omit them. Either is fine —
  match neighbouring files.
- Private worker-job state uses a leading underscore (`$_repositories`); everything else does not.
- German labels/descriptions in configuration DTOs, English in code and commit messages.
- No PHPUnit, PHPStan, PHP-CS-Fixer or `.editorconfig` in the repo — there is nothing to run
  before committing. Verify by reading, and by checking the corresponding base class in
  `analytics-core` (see `composer.lock` for the pinned version, currently `v1.40.1`).

## Git & release workflow

- **Conventional Commits are mandatory** — `release-please` derives versions and `CHANGELOG.md`
  from them. Use `feat:` (minor), `fix:` (patch), `chore:` / `chore(deps):` (no release).
  Match the existing style, which backticks identifiers:
  `feat: add \`GitRepositoryView\` … for \`GitRepository\` integration`.
- Never hand-edit `CHANGELOG.md` or the version in `composer.json`/`getVersion()` — release-please
  owns them (`.github/workflows/release-please.yml`, `release-type: php`, triggered on push to
  `main`).
- `composer.lock` **is committed** and is bumped by Renovate PRs (`chore(deps): update dependency
  cehlers88/analytics-core to vX.Y.Z`). Only touch it when the task is a dependency bump; there is
  no `vendor/` and `composer install` needs access to the private Satis repo.
- Publishing `.github/workflows/trigger-satis.yml`: on a published GitHub release, dispatches
  `build.yml` in `cEhlers88/satis` so the package index is rebuilt.
- Work on the branch you were assigned, push with `git push -u origin <branch>`, and do not open a
  PR unless asked.

## Where to look for answers

Behaviour questions almost always end in `analytics-core`, which is not vendored here. Read
`composer.lock` for the exact pinned commit and consult
[`cEhlers88/AnalyticsCore`](https://github.com/cEhlers88/AnalyticsCore) for the abstract classes
and DTO factory signatures before changing a contract.
