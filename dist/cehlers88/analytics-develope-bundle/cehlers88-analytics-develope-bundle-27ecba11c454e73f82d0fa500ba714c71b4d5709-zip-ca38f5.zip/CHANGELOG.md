# Changelog

## [0.2.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.0...v0.2.1) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.4 ([#13](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/13)) ([893c765](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/893c765b6be12138a2f34bb22c7e3b9012a6bd9e))

## [0.2.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.4...v0.2.0) (2026-03-19)


### Features

* add DevelopWorker and update dependency to analytics-core ^1 ([fc6d36b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/fc6d36b76ceaee8302502b359007009e7a561fdc))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/9)) ([e0d383c](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e0d383c4664e6ce5698bb6c848ffd36621b011d9))
* downgrade analytics-core dependency to ^0.3 ([1e511c7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1e511c7bade6d3a74a41cc25c1feb9ecf8c56ade))

## [0.1.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.3...v0.1.4) (2026-01-22)


### Miscellaneous Chores

* Update dependency versions for analytics-core ([f2a8d15](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2a8d154ac14f01f7e39afb22b0a6e6d616217ff))

## [0.1.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.2...v0.1.3) (2026-01-21)


### Miscellaneous Chores

* add GitHub Actions workflow to trigger Satis rebuild on release ([7ba6034](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/7ba60343f9c515be0aee3f6ae55be094a75e66a9))

## [0.1.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([cf67e17](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/cf67e17329ebd56e001bb3102676a4439e6ad844))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([f2aae12](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2aae12077ba3b0790fb23eadd527cd40e4d85c8))

## [0.1.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([c39c6af](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c39c6af44469b9065e75f992998cbce6b579bce4))
