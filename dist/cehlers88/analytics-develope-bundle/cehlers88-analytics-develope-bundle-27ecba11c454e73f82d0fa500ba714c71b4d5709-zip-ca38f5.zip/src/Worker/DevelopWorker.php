<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 13.09.2024
 * Time: 12:32
 */

namespace Cehlers88\AnalyticsDevelopeBundle\Worker;

use Cehlers88\AnalyticsCore\Worker\AbstractWorker;

class DevelopWorker extends AbstractWorker
{
    public function getWorkingObjects(): array
    {
        return [];
        //return $this->trackingBufferRepository->getUnfinished($this->getApplicationId(),100);
    }
}