<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 11.10.2024
 * Time: 21:36
 */

namespace Cehlers88\AnalyticsDevelopeBundle\CustomObject;

use Cehlers88\AnalyticsCore\CustomObject\AbstractCustomObject;

class GitRepository extends AbstractCustomObject
{
    public function getRepositoryPath(): string
    {
        return $this->getAttribute('repository_path', '');
    }

    public function setRepositoryPath(string $RepositoryPath): static
    {
        return $this->setAttribute('repository_path', $RepositoryPath);
    }

    public function getGithubOwner(): string
    {
        return $this->getAttribute('owner', '');
    }

    public function setGithubOwner(string $githubOwner): static
    {
        return $this->setAttribute('owner', $githubOwner);
    }

    public function getGithubRepo(): string
    {
        return $this->getAttribute('repo', '');
    }

    public function setGithubRepo(string $githubRepo): static
    {
        return $this->setAttribute('repo', $githubRepo);
    }

    public function getGithubToken(): string
    {
        return $this->getAttribute('token', '');
    }

    public function setGithubToken(string $githubToken): static
    {
        return $this->setAttribute('token', $githubToken);
    }
}