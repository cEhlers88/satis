<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 30.04.2026
 * Time: 11:00
 */

namespace Cehlers88\AnalyticsDevelopeBundle\Service;

use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitRepository;

class GitHubIssueService
{
    private const GITHUB_API_BASE_URL = 'https://api.github.com';

    /**
     * Creates a GitHub issue from a tracking buffer object.
     *
     * The tracking buffer is expected to expose its data via a toArray() method
     * or public properties. The issue title and body are derived from the buffer's
     * data so that error details are immediately visible in the GitHub issue.
     *
     * @param object       $trackingBuffer The error tracking buffer to turn into an issue.
     * @param GitRepository $repository    The Git repository to create the issue in.
     * @param string[]      $labels        Optional labels to attach to the created issue.
     *
     * @return array The decoded GitHub API response for the created issue.
     *
     * @throws \RuntimeException When the GitHub API call fails or the repository is not fully configured.
     */
    public function createIssueFromTrackingBuffer(
        object $trackingBuffer,
        GitRepository $repository,
        array $labels = []
    ): array {
        $owner = $repository->getGithubOwner();
        $repo  = $repository->getGithubRepo();
        $token = $repository->getGithubToken();

        if ($owner === '' || $repo === '' || $token === '') {
            throw new \RuntimeException(
                'GitRepository is not fully configured for GitHub: owner, repo, and token are required.'
            );
        }

        $title = $this->buildIssueTitle($trackingBuffer);
        $body  = $this->buildIssueBody($trackingBuffer);

        return $this->postIssue($owner, $repo, $token, $title, $body, $labels);
    }

    /**
     * Builds the issue title from the tracking buffer.
     */
    private function buildIssueTitle(object $trackingBuffer): string
    {
        if (method_exists($trackingBuffer, 'getTitle') && $trackingBuffer->getTitle() !== '') {
            return $trackingBuffer->getTitle();
        }

        if (method_exists($trackingBuffer, 'getMessage') && $trackingBuffer->getMessage() !== '') {
            $message = $trackingBuffer->getMessage();
            return mb_strlen($message) > 100 ? mb_substr($message, 0, 97) . '...' : $message;
        }

        return '[Error] Tracking buffer #' . (method_exists($trackingBuffer, 'getId')
            ? $trackingBuffer->getId()
            : spl_object_id($trackingBuffer));
    }

    /**
     * Builds the issue body from the tracking buffer.
     */
    private function buildIssueBody(object $trackingBuffer): string
    {
        $lines = ['## Error Tracking Buffer', ''];

        $data = method_exists($trackingBuffer, 'toArray')
            ? $trackingBuffer->toArray()
            : $this->objectToArray($trackingBuffer);

        foreach ($data as $key => $value) {
            $formattedValue = is_array($value) || is_object($value)
                ? json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
                : (string) $value;

            $lines[] = '**' . ucfirst((string) $key) . ':** ' . $formattedValue;
        }

        return implode("\n", $lines);
    }

    /**
     * Converts a plain object to an associative array using public getters.
     *
     * @return array<string, mixed>
     */
    private function objectToArray(object $object): array
    {
        $data = [];

        foreach (get_class_methods($object) as $method) {
            if (strpos($method, 'get') === 0 && $method !== 'getClass') {
                $property = lcfirst(substr($method, 3));
                try {
                    $data[$property] = $object->$method();
                } catch (\Throwable) {
                    // Skip getters that require arguments or throw exceptions
                }
            }
        }

        return $data;
    }

    /**
     * Sends the issue creation request to the GitHub REST API.
     *
     * @param string   $owner  Repository owner (user or organization).
     * @param string   $repo   Repository name.
     * @param string   $token  Personal access token with `repo` scope.
     * @param string   $title  Issue title.
     * @param string   $body   Issue body (Markdown).
     * @param string[] $labels Labels to attach to the issue.
     *
     * @return array Decoded JSON response from the GitHub API.
     *
     * @throws \RuntimeException On cURL or API errors.
     */
    private function postIssue(
        string $owner,
        string $repo,
        string $token,
        string $title,
        string $body,
        array $labels
    ): array {
        $url     = sprintf('%s/repos/%s/%s/issues', self::GITHUB_API_BASE_URL, $owner, $repo);
        $payload = ['title' => $title, 'body' => $body];

        if ($labels !== []) {
            $payload['labels'] = array_values($labels);
        }

        $ch = curl_init($url);

        if ($ch === false) {
            throw new \RuntimeException('Failed to initialize cURL.');
        }

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => [
                'Accept: application/vnd.github+json',
                'Authorization: Bearer ' . $token,
                'Content-Type: application/json',
                'X-GitHub-Api-Version: 2022-11-28',
                'User-Agent: AnalyticsDevelopeBundle',
            ],
        ]);

        $response   = curl_exec($ch);
        $curlError  = curl_error($ch);
        $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false || $curlError !== '') {
            throw new \RuntimeException('GitHub API request failed: ' . $curlError);
        }

        $decoded = json_decode((string) $response, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \RuntimeException(
                sprintf('Failed to parse GitHub API response (HTTP %d): %s', $httpStatus, json_last_error_msg())
            );
        }

        if ($httpStatus !== 201) {
            $message = $decoded['message'] ?? '[no message]';
            throw new \RuntimeException(
                sprintf('GitHub API returned HTTP %d: %s', $httpStatus, $message)
            );
        }

        return $decoded;
    }
}
