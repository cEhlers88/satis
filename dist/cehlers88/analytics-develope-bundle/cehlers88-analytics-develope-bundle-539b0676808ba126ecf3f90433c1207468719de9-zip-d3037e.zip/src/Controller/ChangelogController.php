<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Controller;

use Cehlers88\AnalyticsDevelopeBundle\Changelog\ChangelogConflictException;
use Cehlers88\AnalyticsDevelopeBundle\Changelog\ChangelogRenderer;
use Cehlers88\AnalyticsDevelopeBundle\Changelog\ChangelogStorage;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * The backend of the Changelog Editor tool: the current changelog and the history of past
 * ones (ChangelogStorage), rendered as the notes are, and the images they show.
 */
#[Route('/admin_api/develope/changelog', name: 'analytics_develope_changelog_')]
final class ChangelogController extends AbstractController
{
    public const CSRF_TOKEN_ID = 'changelog';

    public function __construct(
        private readonly ChangelogStorage  $storage,
        private readonly ChangelogRenderer $renderer,
    ) {
    }

    /** Both documents - their text, revision and HTML. */
    #[Route('', name: 'show', methods: ['GET'])]
    public function show(): JsonResponse
    {
        $this->denyUnlessDashboardUser();

        return $this->json($this->documents());
    }

    /** JSON body: {content, baseRevision?, force?} */
    #[Route('/documents/{document}', name: 'save', requirements: ['document' => 'current|history'], methods: ['PUT'])]
    public function save(string $document, Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $body = $this->body($request);
        if (!is_string($body['content'] ?? null)) {
            return $this->json(['message' => 'There is no text to save.'], 400);
        }

        try {
            $this->storage->write(
                $document,
                $body['content'],
                is_string($body['baseRevision'] ?? null) ? $body['baseRevision'] : null,
                ($body['force'] ?? false) === true
            );
        } catch (ChangelogConflictException $conflict) {
            return $this->json([
                'message' => 'Someone changed the changelog meanwhile.',
                'content' => $conflict->currentContent,
                'revision' => $conflict->currentRevision,
            ], 409);
        } catch (\InvalidArgumentException $exception) {
            return $this->json(['message' => $exception->getMessage()], 400);
        }

        return $this->json($this->documents());
    }

    /** The HTML of a text while it is written. JSON body: {content} */
    #[Route('/preview', name: 'preview', methods: ['POST'])]
    public function preview(Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $content = $this->body($request)['content'] ?? '';

        return $this->json(['html' => $this->renderer->render(is_string($content) ? mb_substr($content, 0, ChangelogStorage::MAX_DOCUMENT_BYTES) : '')]);
    }

    /** Moves the current changelog on top of the history. JSON body: {title} */
    #[Route('/release', name: 'release', methods: ['POST'])]
    public function release(Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }

        try {
            $heading = $this->storage->release((string)($this->body($request)['title'] ?? ''));
        } catch (\InvalidArgumentException $exception) {
            return $this->json(['message' => $exception->getMessage()], 400);
        }

        return $this->json(['message' => sprintf('Released as "%s".', ltrim($heading, '# '))] + $this->documents());
    }

    /** An image for the changelog (form field "image"); answers the Markdown that shows it. */
    #[Route('/images', name: 'image_upload', methods: ['POST'])]
    public function uploadImage(Request $request): JsonResponse
    {
        $this->denyUnlessDashboardUser();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $file = $request->files->get('image');
        if (!$file instanceof UploadedFile || !$file->isValid()) {
            return $this->json(['message' => 'The image did not arrive - it may be too large for the server.'], 400);
        }

        try {
            $id = $this->storage->addImage($file->getPathname(), $file->getClientOriginalName());
        } catch (\InvalidArgumentException $exception) {
            return $this->json(['message' => $exception->getMessage()], 400);
        }
        $alt = trim(str_replace([']', '['], '', pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME)));

        return $this->json([
            'id' => $id,
            'markdown' => sprintf('![%s](%s%s)', $alt !== '' ? $alt : 'Bild', ChangelogRenderer::IMAGE_SCHEME, $id),
        ], 201);
    }

    #[Route('/images/{id}', name: 'image', requirements: ['id' => '[a-f0-9]{16}\.(png|jpg|gif|webp)'], methods: ['GET'])]
    public function image(string $id): Response
    {
        $this->denyUnlessDashboardUser();
        $path = $this->storage->imagePath($id);
        if ($path === null) {
            throw $this->createNotFoundException();
        }
        $response = new BinaryFileResponse($path);
        $response->headers->set('Content-Type', ChangelogStorage::IMAGE_TYPES[pathinfo($id, PATHINFO_EXTENSION)]);
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        // an image never changes - its id is new for every upload
        $response->setPrivate();
        $response->setMaxAge(31536000);

        return $response;
    }

    /** @return array<string, array{content: string, revision: string, html: string}> */
    private function documents(): array
    {
        $documents = [];
        foreach (ChangelogStorage::DOCUMENTS as $document) {
            $read = $this->storage->read($document);
            $documents[$document] = [...$read, 'html' => $this->renderer->render($read['content'])];
        }

        return $documents;
    }

    /** @return array<string, mixed> */
    private function body(Request $request): array
    {
        try {
            return $request->toArray();
        } catch (\Throwable) {
            return [];
        }
    }

    private function denyUnlessDashboardUser(): void
    {
        if (!$this->isGranted('ROLE_DASHBOARD') && !$this->isGranted('ROLE_ADMIN')) {
            throw $this->createAccessDeniedException('The changelog is kept on the dashboard.');
        }
    }

    private function refuseWithoutToken(Request $request): ?JsonResponse
    {
        return $this->isCsrfTokenValid(self::CSRF_TOKEN_ID, (string)$request->headers->get('X-CSRF-Token', ''))
            ? null
            : $this->json(['message' => 'Invalid CSRF token - reload the page'], 403);
    }
}
