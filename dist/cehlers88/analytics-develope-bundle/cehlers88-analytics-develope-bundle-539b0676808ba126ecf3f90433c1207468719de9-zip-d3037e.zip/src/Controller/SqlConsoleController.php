<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Controller;

use Cehlers88\AnalyticsDevelopeBundle\Sql\SqlConnectionStorage;
use Cehlers88\AnalyticsDevelopeBundle\Sql\SqlGuard;
use Cehlers88\AnalyticsDevelopeBundle\Sql\SqlQueryModel;
use Cehlers88\AnalyticsDevelopeBundle\Sql\SqlRunner;
use Doctrine\DBAL\Exception as DbalException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;

/**
 * The backend of the SQL Console tool: the saved connections, what a database is made of,
 * the statements that are run and the query behind the visual view.
 *
 * Administrators only - every route asks for ROLE_ADMIN, and everything that changes
 * something or runs a statement carries the CSRF token "sql_console". Nothing here tries
 * to make SQL safe: an administrator with this tool can do what an administrator with a
 * database client can do. What it does do is keep the two ways of hurting yourself by
 * accident away: a connection can be marked as "only read from", and a statement that
 * writes runs only when that was switched on knowingly (SqlGuard).
 */
#[Route('/admin_api/develope/sql-console', name: 'analytics_develope_sql_console_')]
final class SqlConsoleController extends AbstractController
{
    public const CSRF_TOKEN_ID = 'sql_console';

    public function __construct(
        private readonly SqlConnectionStorage $connections,
        private readonly SqlRunner            $runner,
    ) {
    }

    /** The connections to pick from - never with a password. */
    #[Route('/connections', name: 'connections', methods: ['GET'])]
    public function connections(): JsonResponse
    {
        $this->denyUnlessAdmin();

        return $this->json([
            'connections' => $this->connections->describeAll(),
            'drivers' => SqlConnectionStorage::DRIVERS,
            'defaultLimit' => SqlRunner::DEFAULT_LIMIT,
            'maxLimit' => SqlRunner::MAX_LIMIT,
        ]);
    }

    /** JSON body: {id?, name, driver, host, port, database, user, password, readOnly} */
    #[Route('/connections', name: 'save_connection', methods: ['POST'])]
    public function saveConnection(Request $request): JsonResponse
    {
        $this->denyUnlessAdmin();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }

        try {
            $connection = $this->connections->save($this->body($request));
        } catch (\InvalidArgumentException $exception) {
            return $this->json(['message' => $exception->getMessage()], 400);
        }

        return $this->json(['message' => sprintf('Verbindung "%s" gespeichert', $connection['name']), 'connection' => $connection]);
    }

    #[Route('/connections/{id}', name: 'delete_connection', requirements: ['id' => '[a-f0-9]{12}'], methods: ['DELETE'])]
    public function deleteConnection(string $id, Request $request): JsonResponse
    {
        $this->denyUnlessAdmin();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $this->connections->remove($id);

        return $this->json(['message' => 'Die Verbindung ist entfernt', 'connections' => $this->connections->describeAll()]);
    }

    /**
     * Tries a connection out - the saved one by its id, or the one in the mask before it is
     * saved. JSON body: the fields of the mask.
     */
    #[Route('/connections/test', name: 'test_connection', methods: ['POST'])]
    public function testConnection(Request $request): JsonResponse
    {
        $this->denyUnlessAdmin();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $body = $this->body($request);

        try {
            $id = (string)($body['id'] ?? '');
            $connection = $id === SqlConnectionStorage::APPLICATION
                ? $this->runner->connect($id)
                : $this->runner->connect('', $this->connections->paramsOf($body));
            $tables = count($this->runner->schema($connection)['tables']);
        } catch (\Throwable $exception) {
            return $this->json(['message' => self::readable($exception)], 400);
        }

        return $this->json(['message' => sprintf('Verbindung steht - %d %s gefunden.', $tables, $tables === 1 ? 'Tabelle' : 'Tabellen')]);
    }

    /** What the database is made of - the tables, their columns and the foreign keys. */
    #[Route('/schema/{connectionId}', name: 'schema', methods: ['GET'])]
    public function schema(string $connectionId): JsonResponse
    {
        $this->denyUnlessAdmin();

        try {
            $schema = $this->runner->schema($this->runner->connect($connectionId));
        } catch (\Throwable $exception) {
            return $this->json(['message' => self::readable($exception)], 400);
        }

        return $this->json([
            ...$schema,
            'readOnly' => $this->connections->isReadOnly($connectionId),
        ]);
    }

    /** JSON body: {connection, sql, limit, allowWrite} */
    #[Route('/query', name: 'query', methods: ['POST'])]
    public function query(Request $request): JsonResponse
    {
        $this->denyUnlessAdmin();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $body = $this->body($request);
        $connectionId = (string)($body['connection'] ?? SqlConnectionStorage::APPLICATION);
        $sql = (string)($body['sql'] ?? '');
        $allowWrite = ($body['allowWrite'] ?? false) === true;

        $refusal = SqlGuard::refuse($sql, !$this->connections->isReadOnly($connectionId), $allowWrite);
        if ($refusal !== null) {
            return $this->json(['message' => $refusal], 400);
        }

        try {
            $result = $this->runner->run(
                $this->runner->connect($connectionId),
                $sql,
                (int)($body['limit'] ?? SqlRunner::DEFAULT_LIMIT),
                $allowWrite,
            );
        } catch (\Throwable $exception) {
            return $this->json(['message' => self::readable($exception)], 400);
        }

        return $this->json([
            ...$result,
            'message' => $result['affected'] !== null
                ? sprintf('%d %s geändert', $result['affected'], $result['affected'] === 1 ? 'Zeile' : 'Zeilen')
                : sprintf('%d %s', $result['rowCount'], $result['rowCount'] === 1 ? 'Zeile' : 'Zeilen'),
        ]);
    }

    /**
     * Between the visual view and the written SQL. JSON body: {model, quote} for the SQL of
     * a model, {sql} for the model behind a SELECT - `model` is null when the statement is
     * more than the visual view can show.
     */
    #[Route('/model', name: 'model', methods: ['POST'])]
    public function model(Request $request): JsonResponse
    {
        $this->denyUnlessAdmin();
        if (($refused = $this->refuseWithoutToken($request)) !== null) {
            return $refused;
        }
        $body = $this->body($request);

        if (is_array($body['model'] ?? null)) {
            $quote = (string)($body['quote'] ?? '`');

            return $this->json(['sql' => SqlQueryModel::toSql($body['model'], $quote === '"' ? '"' : '`')]);
        }

        $model = SqlQueryModel::fromSql((string)($body['sql'] ?? ''));

        return $this->json([
            'model' => $model,
            'message' => $model === null
                ? 'Diese Abfrage lässt sich nicht visuell darstellen - die visuelle Ansicht bleibt, wie sie ist.'
                : '',
        ]);
    }

    private function denyUnlessAdmin(): void
    {
        // the tool is for administrators; /admin_api has no access control of its own
        if (!$this->isGranted('ROLE_ADMIN')) {
            throw $this->createAccessDeniedException('Die SQL-Konsole ist Administratoren vorbehalten.');
        }
    }

    private function refuseWithoutToken(Request $request): ?JsonResponse
    {
        $token = $request->headers->get('X-CSRF-Token') ?? '';

        return $this->isCsrfTokenValid(self::CSRF_TOKEN_ID, $token)
            ? null
            : $this->json(['message' => 'Der Sicherheitsschlüssel passt nicht - bitte die Seite neu laden.'], 403);
    }

    /** @return array<string, mixed> */
    private function body(Request $request): array
    {
        try {
            return $request->toArray();
        } catch (\Throwable) {
            return [];
        }
    }

    /** What went wrong, without the stack of DBAL around it. */
    private static function readable(\Throwable $exception): string
    {
        $message = $exception->getMessage();
        if ($exception instanceof DbalException && $exception->getPrevious() !== null) {
            $message = $exception->getPrevious()->getMessage();
        }
        $message = preg_replace('/^An exception occurred while executing[^:]*:\s*/i', '', $message) ?? $message;

        return mb_substr(trim($message), 0, 1000);
    }
}
