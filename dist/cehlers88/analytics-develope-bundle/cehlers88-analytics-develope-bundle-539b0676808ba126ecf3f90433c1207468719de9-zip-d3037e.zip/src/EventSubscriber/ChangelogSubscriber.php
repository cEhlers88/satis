<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\EventSubscriber;

use Cehlers88\AnalyticsCore\Event\Changelog\AddChangelogEntriesEvent;
use Cehlers88\AnalyticsCore\Event\Changelog\CollectChangelogTargetsEvent;
use Cehlers88\AnalyticsCore\Event\Tool\CollectToolsEvent;
use Cehlers88\AnalyticsDevelopeBundle\Changelog\ChangelogStorage;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

/**
 * How the bundle takes part in the rest of the installation - through the events of
 * AnalyticsCore only, no class of the application or of another bundle is known here:
 *  - it brings the Changelog Editor to the tools page (CollectToolsEvent),
 *  - it says it keeps a changelog (CollectChangelogTargetsEvent),
 *  - and it takes the entries others move there - the done tasks of a note (AddChangelogEntriesEvent).
 */
final class ChangelogSubscriber implements EventSubscriberInterface
{
    public const TARGET = 'develope.changelog';
    /** A route of ChangelogController - it exists only when the application imports the bundle's routes. */
    private const ROUTE = 'analytics_develope_changelog_show';

    private ?bool $routesImported = null;

    public function __construct(
        private readonly ChangelogStorage      $storage,
        private readonly UrlGeneratorInterface $urlGenerator,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            CollectToolsEvent::class => 'onCollectTools',
            CollectChangelogTargetsEvent::class => 'onCollectChangelogTargets',
            AddChangelogEntriesEvent::class => 'onAddChangelogEntries',
        ];
    }

    public function onCollectTools(CollectToolsEvent $event): void
    {
        // without its routes the tool could not render (path()) and would break the whole
        // tools page - it is left out until config/routes imports @AnalyticsDevelopeBundle/Controller/
        if (!$this->routesImported()) {
            return;
        }
        $event->addTool([
            'name' => 'changelogEditor',
            'title' => 'Changelog Editor',
            'description' => 'Read and write the changelog - the current one and the history of past releases, with images',
            'categories' => ['Development', 'Workspace'],
            'teaser' => 'teaser/changelogEditor.html.twig',
            'template' => 'changelogEditor.html.twig',
            'scripts' => ['script/changelogEditor.js.twig'],
            'styles' => ['style/changelogEditor.html.twig'],
            'routes' => ['analytics_develope_changelog_'],
        ]);
    }

    public function onCollectChangelogTargets(CollectChangelogTargetsEvent $event): void
    {
        // a changelog nobody can open is no place to move tasks to
        if (!$this->routesImported()) {
            return;
        }
        $event->addTarget(self::TARGET, 'Changelog');
    }

    public function onAddChangelogEntries(AddChangelogEntriesEvent $event): void
    {
        if ($event->isHandled() || ($event->target !== null && $event->target !== self::TARGET)) {
            return;
        }
        $event->accept(self::TARGET, $this->storage->appendEntries($event->entries));
    }

    private function routesImported(): bool
    {
        if ($this->routesImported === null) {
            try {
                $this->urlGenerator->generate(self::ROUTE);
                $this->routesImported = true;
            } catch (RouteNotFoundException) {
                $this->routesImported = false;
            }
        }

        return $this->routesImported;
    }
}
