<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\EventSubscriber;

use Cehlers88\AnalyticsCore\Event\Tool\CollectToolsEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

/**
 * Brings the SQL Console to the tools page of the dashboard - through the event of
 * AnalyticsCore, so no class of the application is known here.
 *
 * Like the Changelog Editor the tool is only offered once its routes are imported, and
 * only to administrators (`requiredRoles`), which SqlConsoleController checks again.
 */
final class SqlConsoleSubscriber implements EventSubscriberInterface
{
    /** A route of SqlConsoleController - it exists only when the application imports the bundle's routes. */
    private const ROUTE = 'analytics_develope_sql_console_connections';

    private ?bool $routesImported = null;

    public function __construct(
        private readonly UrlGeneratorInterface $urlGenerator,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            CollectToolsEvent::class => 'onCollectTools',
        ];
    }

    public function onCollectTools(CollectToolsEvent $event): void
    {
        if (!$this->routesImported()) {
            return;
        }
        $event->addTool([
            'name' => 'sqlConsole',
            'title' => 'SQL Console',
            'description' => 'Datenbankabfragen schreiben, visuell zusammenklicken und ausführen - auf der Anwendungsdatenbank oder einer anderen',
            'categories' => ['Development', 'Data'],
            'teaser' => 'teaser/sqlConsole.html.twig',
            'template' => 'sqlConsole.html.twig',
            'scripts' => ['script/sqlConsole.js.twig'],
            'styles' => ['style/sqlConsole.html.twig'],
            'routes' => ['analytics_develope_sql_console_'],
            'requiredRoles' => ['ROLE_ADMIN'],
        ]);
    }

    private function routesImported(): bool
    {
        if ($this->routesImported === null) {
            try {
                $this->urlGenerator->generate(self::ROUTE);
                $this->routesImported = true;
            } catch (RouteNotFoundException) {
                $this->routesImported = false;
            }
        }

        return $this->routesImported;
    }
}
