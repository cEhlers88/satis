<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Sql;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\DriverManager;
use Doctrine\DBAL\Exception as DbalException;
use Doctrine\DBAL\Types\Type;

/**
 * Runs the statements of the SQL console and reads what a database is made of.
 *
 * Every connection goes through DBAL: the one of the application as the service it
 * already is, every other one opened here from what was saved (SqlConnectionStorage).
 * Whether a statement may run at all is SqlGuard's business, not this one's.
 */
class SqlRunner
{
    public const DEFAULT_LIMIT = 200;
    public const MAX_LIMIT = 2000;
    /** Longer values are cut for the table of results - the cell says so. */
    public const MAX_CELL_LENGTH = 500;

    public function __construct(
        private readonly Connection           $applicationConnection,
        private readonly SqlConnectionStorage $connections,
    ) {
    }

    /**
     * @param array<string, mixed>|null $params a connection that is only being tried out
     * @throws DbalException
     */
    public function connect(string $connectionId, ?array $params = null): Connection
    {
        if ($params !== null) {
            return DriverManager::getConnection($params);
        }
        if ($connectionId === SqlConnectionStorage::APPLICATION) {
            return $this->applicationConnection;
        }

        return DriverManager::getConnection($this->connections->params($connectionId));
    }

    /**
     * Runs one statement and says what came back.
     *
     * @return array{columns: list<string>, rows: list<list<string|null>>, rowCount: int, duration: float, kind: string, truncated: bool, affected: int|null}
     * @throws DbalException
     */
    public function run(Connection $connection, string $sql, int $limit = self::DEFAULT_LIMIT, bool $allowWrite = false): array
    {
        $limit = max(0, min($limit, self::MAX_LIMIT));
        $statement = SqlGuard::isReading($sql) ? SqlGuard::withLimit($sql, $limit) : SqlGuard::normalize($sql);
        $kind = SqlGuard::kindOf($statement);
        $started = microtime(true);

        if (!SqlGuard::isReading($statement)) {
            $affected = (int)$connection->executeStatement($statement);

            return [
                'columns' => [], 'rows' => [], 'rowCount' => 0, 'kind' => $kind, 'truncated' => false,
                'affected' => $affected, 'duration' => microtime(true) - $started,
            ];
        }

        $result = $connection->executeQuery($statement);
        $columns = [];
        $rows = [];
        $truncated = false;
        foreach ($result->iterateAssociative() as $row) {
            if ($columns === []) {
                $columns = array_keys($row);
            }
            if ($limit > 0 && count($rows) >= $limit) {
                // there is more than was asked for - the console says so
                $truncated = true;
                break;
            }
            $rows[] = array_map(self::cell(...), array_values($row));
        }

        return [
            'columns' => array_map(static fn($name): string => (string)$name, $columns),
            'rows' => $rows,
            'rowCount' => count($rows),
            'kind' => $kind,
            'truncated' => $truncated,
            'affected' => null,
            'duration' => microtime(true) - $started,
        ];
    }

    /**
     * The tables of a database with their columns, keys and the foreign keys between them -
     * what the visual view is drawn from.
     *
     * @return array{tables: list<array<string, mixed>>, platform: string, quote: string}
     * @throws DbalException
     */
    public function schema(Connection $connection): array
    {
        $manager = $connection->createSchemaManager();
        $platform = $connection->getDatabasePlatform();
        $quote = str_contains(strtolower($platform::class), 'mysql') || str_contains(strtolower($platform::class), 'maria') ? '`' : '"';

        $tables = [];
        foreach ($manager->listTables() as $table) {
            $primary = $table->getPrimaryKey()?->getColumns() ?? [];
            $foreign = [];
            foreach ($table->getForeignKeys() as $key) {
                foreach ($key->getLocalColumns() as $index => $column) {
                    $foreign[] = [
                        'column' => $column,
                        'table' => $key->getForeignTableName(),
                        'referenced' => $key->getForeignColumns()[$index] ?? '',
                    ];
                }
            }
            $tables[] = [
                'name' => $table->getName(),
                'columns' => array_map(static fn($column): array => [
                    'name' => $column->getName(),
                    'type' => Type::getTypeRegistry()->lookupName($column->getType()),
                    'notNull' => $column->getNotnull(),
                ], array_values($table->getColumns())),
                'primary' => $primary,
                'foreignKeys' => $foreign,
            ];
        }
        usort($tables, static fn(array $left, array $right): int => strcasecmp($left['name'], $right['name']));

        return ['tables' => $tables, 'platform' => $platform::class, 'quote' => $quote];
    }

    /** A value as the table of results shows it - long ones cut, binary ones named. */
    private static function cell(mixed $value): ?string
    {
        if ($value === null) {
            return null;
        }
        if (is_bool($value)) {
            return $value ? '1' : '0';
        }
        if (is_resource($value)) {
            return '[Binärdaten]';
        }
        $text = is_scalar($value) ? (string)$value : json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $text = (string)$text;
        if (!mb_check_encoding($text, 'UTF-8')) {
            return sprintf('[Binärdaten, %d Bytes]', strlen($text));
        }

        return mb_strlen($text) > self::MAX_CELL_LENGTH
            ? mb_substr($text, 0, self::MAX_CELL_LENGTH) . ' …'
            : $text;
    }
}
