<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Sql;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Keeps the passwords of the saved database connections out of plain sight.
 *
 * They are encrypted with a key derived from the application secret, so the file of the
 * connections alone is of no use - and a password never leaves the server anyway
 * (SqlConnectionStorage hands out the connections without them). A new application secret
 * makes the stored passwords unreadable; they have to be entered again, which is said
 * where it shows (SqlConsoleController).
 */
class SqlSecret
{
    private const PREFIX = 'enc:v1:';

    public function __construct(
        #[Autowire('%kernel.secret%')]
        private readonly string $applicationSecret,
    ) {
    }

    public function encrypt(string $value): string
    {
        if ($value === '') {
            return '';
        }
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);

        return self::PREFIX . base64_encode($nonce . sodium_crypto_secretbox($value, $nonce, $this->key()));
    }

    /** The password again, or null when it cannot be read (another application secret). */
    public function decrypt(string $value): ?string
    {
        if ($value === '') {
            return '';
        }
        if (!str_starts_with($value, self::PREFIX)) {
            // written before there was any encryption - taken as it is, and encrypted on the next save
            return $value;
        }
        $raw = base64_decode(substr($value, strlen(self::PREFIX)), true);
        if ($raw === false || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
            return null;
        }
        $plain = sodium_crypto_secretbox_open(
            substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            $this->key(),
        );

        return $plain === false ? null : $plain;
    }

    private function key(): string
    {
        return sodium_crypto_generichash($this->applicationSecret, 'analytics-sql-console', SODIUM_CRYPTO_SECRETBOX_KEYBYTES);
    }
}
