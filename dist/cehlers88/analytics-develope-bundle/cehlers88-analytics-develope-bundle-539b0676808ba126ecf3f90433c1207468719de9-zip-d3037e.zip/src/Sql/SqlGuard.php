<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Sql;

/**
 * What a statement is - and whether it may run.
 *
 * The SQL console is a tool for administrators, not a fence: it does not try to make
 * dangerous SQL safe. What it does do is refuse to run anything that writes unless that
 * was asked for explicitly on a connection that allows it at all, and refuse several
 * statements in one go - so a query that was meant to read never deletes anything on the
 * way (and no second statement rides along behind a semicolon).
 */
final class SqlGuard
{
    public const READING = ['select', 'show', 'explain', 'describe', 'desc', 'with', 'analyze', 'pragma'];
    public const WRITING = ['insert', 'update', 'delete', 'replace', 'merge', 'upsert', 'call', 'do'];
    public const STRUCTURE = ['create', 'alter', 'drop', 'truncate', 'rename', 'grant', 'revoke', 'set', 'lock', 'unlock', 'commit', 'rollback', 'begin', 'start', 'vacuum', 'attach', 'detach'];

    /** The statement without comments, leading whitespace and a trailing semicolon. */
    public static function normalize(string $sql): string
    {
        $withoutComments = preg_replace(
            ['~/\*.*?\*/~s', '~--[^\n]*~', '~#[^\n]*~'],
            ' ',
            $sql,
        ) ?? $sql;

        return trim(rtrim(trim($withoutComments), ';'));
    }

    /** The first word of the statement, lower case - "select", "insert", "" for nothing at all. */
    public static function kindOf(string $sql): string
    {
        $normalized = self::normalize($sql);
        // "(SELECT …)" and "WITH x AS (…) SELECT …" are reading as well
        $normalized = ltrim($normalized, "( \t\n\r");

        return preg_match('/^([a-z]+)/i', $normalized, $match) === 1 ? strtolower($match[1]) : '';
    }

    public static function isReading(string $sql): bool
    {
        return in_array(self::kindOf($sql), self::READING, true);
    }

    /**
     * Whether more than one statement was sent - a semicolon inside a string or a comment
     * does not count.
     */
    public static function hasSeveralStatements(string $sql): bool
    {
        $rest = self::normalize($sql);
        $length = strlen($rest);
        $quote = null;
        for ($index = 0; $index < $length; $index++) {
            $character = $rest[$index];
            if ($quote !== null) {
                if ($character === '\\') {
                    $index++;
                    continue;
                }
                if ($character === $quote) {
                    $quote = null;
                }
                continue;
            }
            if ($character === "'" || $character === '"' || $character === '`') {
                $quote = $character;
                continue;
            }
            if ($character === ';' && trim(substr($rest, $index + 1)) !== '') {
                return true;
            }
        }

        return false;
    }

    /**
     * Says why a statement may not run - null when it may.
     *
     * @param bool $connectionAllowsWriting the connection is not marked "only read from"
     * @param bool $writingWasAsked the request said so, knowingly
     */
    public static function refuse(string $sql, bool $connectionAllowsWriting, bool $writingWasAsked): ?string
    {
        if (self::normalize($sql) === '') {
            return 'Da ist keine Abfrage.';
        }
        if (self::hasSeveralStatements($sql)) {
            return 'Bitte nur eine Anweisung auf einmal - mehrere durch Semikolon getrennte werden nicht ausgeführt.';
        }
        if (self::isReading($sql)) {
            return null;
        }

        $kind = strtoupper(self::kindOf($sql));
        if (!$connectionAllowsWriting) {
            return sprintf('Diese Verbindung ist auf Lesen beschränkt - "%s" wird nicht ausgeführt.', $kind);
        }
        if (!$writingWasAsked) {
            return sprintf('"%s" verändert Daten. Dafür muss „Schreiben erlauben“ eingeschaltet sein.', $kind);
        }

        return null;
    }

    /**
     * A reading statement with a limit, so a table with a million rows does not end up in
     * the browser. An existing LIMIT is left alone, and anything but a plain SELECT is
     * left alone as well.
     */
    public static function withLimit(string $sql, int $limit): string
    {
        $normalized = self::normalize($sql);
        if ($limit <= 0 || self::kindOf($normalized) !== 'select') {
            return $normalized;
        }
        if (preg_match('/\blimit\s+\d/i', $normalized) === 1) {
            return $normalized;
        }

        return $normalized . ' LIMIT ' . $limit;
    }
}
