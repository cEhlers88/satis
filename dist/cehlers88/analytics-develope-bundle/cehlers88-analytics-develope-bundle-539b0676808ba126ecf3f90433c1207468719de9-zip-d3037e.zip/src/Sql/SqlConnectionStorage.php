<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Sql;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * The database connections of the SQL console, as a JSON file below the directory of the
 * tool (SQL_CONSOLE_DIRECTORY, by default var/sql-console).
 *
 * The connection of the application itself is always there and cannot be changed here -
 * it is the one the application runs on (id "app"). Everything else is entered by an
 * administrator: driver, server, port, database, user and password, the password
 * encrypted (SqlSecret).
 *
 * Nothing that leaves this class carries a password: describe() is what the browser gets,
 * params() what DBAL needs, and the two are never mixed up.
 */
class SqlConnectionStorage
{
    /** The connection of the application - always offered, never edited here. */
    public const APPLICATION = 'app';
    public const APPLICATION_LABEL = 'Anwendungsdatenbank';

    /** What can be connected to; everything else is refused. */
    public const DRIVERS = [
        'pdo_mysql' => 'MySQL / MariaDB',
        'pdo_pgsql' => 'PostgreSQL',
        'pdo_sqlite' => 'SQLite (Datei)',
    ];

    public const DEFAULT_PORTS = ['pdo_mysql' => 3306, 'pdo_pgsql' => 5432];
    public const ID = '/^[a-f0-9]{12}$/D';

    public function __construct(
        #[Autowire('%analytics_develope.sql_console.directory%')]
        private readonly string    $directory,
        private readonly SqlSecret $secret,
    ) {
    }

    /**
     * Every connection as the browser gets it - the application's one first, then the
     * saved ones; no passwords, only whether one is stored.
     *
     * @return list<array<string, mixed>>
     */
    public function describeAll(): array
    {
        $connections = [[
            'id' => self::APPLICATION,
            'name' => self::APPLICATION_LABEL,
            'driver' => '',
            'host' => '',
            'port' => null,
            'database' => '',
            'user' => '',
            'hasPassword' => false,
            'readOnly' => true,
            'application' => true,
        ]];
        foreach ($this->read() as $connection) {
            $connections[] = self::describe($connection);
        }

        return $connections;
    }

    /** @return array<string, mixed>|null */
    public function find(string $id): ?array
    {
        foreach ($this->read() as $connection) {
            if ($connection['id'] === $id) {
                return $connection;
            }
        }

        return null;
    }

    /**
     * Saves a connection - a new one without an id, an existing one with it. An empty
     * password on an existing connection keeps the one that is stored.
     *
     * @param array<string, mixed> $input
     * @return array<string, mixed> the connection as the browser gets it
     */
    public function save(array $input): array
    {
        $id = (string)($input['id'] ?? '');
        $existing = $id === '' ? null : $this->find($id);
        if ($id !== '' && $existing === null) {
            throw new \InvalidArgumentException('Diese Verbindung gibt es nicht (mehr).');
        }

        $driver = (string)($input['driver'] ?? '');
        if (!array_key_exists($driver, self::DRIVERS)) {
            throw new \InvalidArgumentException('Diesen Datenbanktyp gibt es nicht.');
        }
        $name = trim((string)($input['name'] ?? ''));
        $database = trim((string)($input['database'] ?? ''));
        if ($name === '') {
            throw new \InvalidArgumentException('Die Verbindung braucht einen Namen.');
        }
        if ($database === '') {
            throw new \InvalidArgumentException($driver === 'pdo_sqlite' ? 'Die SQLite-Datei fehlt.' : 'Der Name der Datenbank fehlt.');
        }

        $password = (string)($input['password'] ?? '');
        $connection = [
            'id' => $id !== '' ? $id : $this->newId(),
            'name' => mb_substr($name, 0, 120),
            'driver' => $driver,
            'host' => trim((string)($input['host'] ?? '')),
            'port' => ($input['port'] ?? '') === '' ? null : (int)$input['port'],
            'database' => $database,
            'user' => trim((string)($input['user'] ?? '')),
            'password' => $password !== ''
                ? $this->secret->encrypt($password)
                : (string)($existing['password'] ?? ''),
            // a connection that is only ever read from - the default, and a good default
            'readOnly' => ($input['readOnly'] ?? true) !== false,
        ];

        $connections = array_values(array_filter($this->read(), static fn(array $each): bool => $each['id'] !== $connection['id']));
        $connections[] = $connection;
        $this->write($connections);

        return self::describe($connection);
    }

    public function remove(string $id): void
    {
        $connections = array_values(array_filter($this->read(), static fn(array $each): bool => $each['id'] !== $id));
        $this->write($connections);
    }

    /**
     * What DBAL needs to connect - with the password, so this never goes anywhere near a
     * response.
     *
     * @return array<string, mixed>
     */
    public function params(string $id): array
    {
        $connection = $this->find($id);
        if ($connection === null) {
            throw new \InvalidArgumentException('Diese Verbindung gibt es nicht (mehr).');
        }
        $password = $this->secret->decrypt((string)$connection['password']);
        if ($password === null) {
            throw new \RuntimeException('Das gespeicherte Passwort lässt sich nicht mehr entschlüsseln - bitte neu eingeben.');
        }

        $params = ['driver' => $connection['driver']];
        if ($connection['driver'] === 'pdo_sqlite') {
            $params['path'] = $connection['database'];

            return $params;
        }

        return [
            ...$params,
            'host' => $connection['host'] !== '' ? $connection['host'] : '127.0.0.1',
            'port' => $connection['port'] ?? (self::DEFAULT_PORTS[$connection['driver']] ?? null),
            'dbname' => $connection['database'],
            'user' => $connection['user'],
            'password' => $password,
        ];
    }

    /**
     * The params of a connection that is only being tried out, before it is saved.
     *
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    public function paramsOf(array $input): array
    {
        $driver = (string)($input['driver'] ?? '');
        if (!array_key_exists($driver, self::DRIVERS)) {
            throw new \InvalidArgumentException('Diesen Datenbanktyp gibt es nicht.');
        }
        if ($driver === 'pdo_sqlite') {
            return ['driver' => $driver, 'path' => (string)($input['database'] ?? '')];
        }

        $password = (string)($input['password'] ?? '');
        if ($password === '' && ($input['id'] ?? '') !== '') {
            $password = (string)($this->params((string)$input['id'])['password'] ?? '');
        }

        return [
            'driver' => $driver,
            'host' => ($input['host'] ?? '') !== '' ? (string)$input['host'] : '127.0.0.1',
            'port' => ($input['port'] ?? '') === '' ? (self::DEFAULT_PORTS[$driver] ?? null) : (int)$input['port'],
            'dbname' => (string)($input['database'] ?? ''),
            'user' => (string)($input['user'] ?? ''),
            'password' => $password,
        ];
    }

    public function isReadOnly(string $id): bool
    {
        if ($id === self::APPLICATION) {
            return true;
        }

        return ($this->find($id)['readOnly'] ?? true) !== false;
    }

    /**
     * @param array<string, mixed> $connection
     * @return array<string, mixed>
     */
    private static function describe(array $connection): array
    {
        $shown = $connection;
        unset($shown['password']);
        $shown['hasPassword'] = ($connection['password'] ?? '') !== '';
        $shown['application'] = false;

        return $shown;
    }

    /** @return list<array<string, mixed>> */
    private function read(): array
    {
        $file = $this->file();
        if (!is_file($file)) {
            return [];
        }
        $data = json_decode((string)file_get_contents($file), true);
        if (!is_array($data)) {
            return [];
        }

        return array_values(array_filter(
            $data,
            static fn($entry): bool => is_array($entry) && is_string($entry['id'] ?? null) && $entry['id'] !== self::APPLICATION,
        ));
    }

    /** @param list<array<string, mixed>> $connections */
    private function write(array $connections): void
    {
        if (!is_dir($this->directory) && !mkdir($this->directory, 0775, true) && !is_dir($this->directory)) {
            throw new \RuntimeException(sprintf('Das Verzeichnis "%s" lässt sich nicht anlegen.', $this->directory));
        }
        $file = $this->file();
        $temporary = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
        file_put_contents($temporary, json_encode($connections, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        // passwords are in there: nobody but the application reads this
        @chmod($temporary, 0600);
        rename($temporary, $file);
    }

    private function newId(): string
    {
        do {
            $id = bin2hex(random_bytes(6));
        } while ($this->find($id) !== null);

        return $id;
    }

    private function file(): string
    {
        return $this->directory . '/connections.json';
    }
}
