<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Sql;

/**
 * The query behind the visual view of the SQL console: which tables, how they are joined,
 * which columns are read, what is filtered and sorted.
 *
 * Both directions live here, so the visual view and the written SQL stay two views of one
 * thing:
 *
 *   toSql()    the model as SQL - what the console shows and runs,
 *   fromSql()  a SELECT back into the model - null when it is more than this understands
 *              (sub-queries, unions, functions in the join condition …). The console then
 *              says so instead of quietly dropping half the query.
 *
 * The model:
 *   from     {table, alias}
 *   joins    [{type: inner|left|right, table, alias, on: [{left: {alias, column}, right: {alias, column}}]}]
 *   columns  [{alias, column, as}] - empty means every column
 *   where    [{alias, column, operator, value, connector: AND|OR}]
 *   orderBy  [{alias, column, direction}]
 *   limit    int, distinct bool
 */
final class SqlQueryModel
{
    public const JOIN_TYPES = ['inner' => 'INNER JOIN', 'left' => 'LEFT JOIN', 'right' => 'RIGHT JOIN'];
    public const OPERATORS = ['=', '<>', '<', '<=', '>', '>=', 'LIKE', 'NOT LIKE', 'IN', 'IS NULL', 'IS NOT NULL'];

    private const NAME = '[A-Za-z_][A-Za-z0-9_$]*';

    /**
     * @param array<string, mixed> $model
     * @param string $quote the identifier quote of the platform - ` for MySQL, " elsewhere
     */
    public static function toSql(array $model, string $quote = '`'): string
    {
        $from = self::readTable($model['from'] ?? null);
        if ($from === null) {
            return '';
        }
        $name = static fn(string $identifier): string => $quote . str_replace($quote, $quote . $quote, $identifier) . $quote;
        $reference = static fn(array $field): string => $name($field['alias']) . '.' . ($field['column'] === '*' ? '*' : $name($field['column']));

        $columns = [];
        foreach (self::readColumns($model['columns'] ?? []) as $column) {
            $columns[] = $reference($column) . ($column['as'] !== '' ? ' AS ' . $name($column['as']) : '');
        }

        $sql = 'SELECT ' . (($model['distinct'] ?? false) === true ? 'DISTINCT ' : '')
            . ($columns === [] ? '*' : implode(', ', $columns))
            . "\nFROM " . $name($from['table']) . ' ' . $name($from['alias']);

        foreach (self::readJoins($model['joins'] ?? []) as $join) {
            $conditions = array_map(
                static fn(array $on): string => $reference($on['left']) . ' = ' . $reference($on['right']),
                $join['on'],
            );
            $sql .= "\n" . self::JOIN_TYPES[$join['type']] . ' ' . $name($join['table']) . ' ' . $name($join['alias'])
                . ($conditions === [] ? '' : ' ON ' . implode(' AND ', $conditions));
        }

        $where = self::readConditions($model['where'] ?? []);
        foreach ($where as $index => $condition) {
            $sql .= $index === 0 ? "\nWHERE " : "\n  " . $condition['connector'] . ' ';
            $sql .= $reference($condition) . ' ' . $condition['operator'];
            if (!in_array($condition['operator'], ['IS NULL', 'IS NOT NULL'], true)) {
                $sql .= ' ' . self::literal($condition['value'], $condition['operator']);
            }
        }

        $orderBy = [];
        foreach (self::readOrderBy($model['orderBy'] ?? []) as $order) {
            $orderBy[] = $reference($order) . ' ' . $order['direction'];
        }
        if ($orderBy !== []) {
            $sql .= "\nORDER BY " . implode(', ', $orderBy);
        }

        $limit = (int)($model['limit'] ?? 0);
        if ($limit > 0) {
            $sql .= "\nLIMIT " . $limit;
        }

        return $sql;
    }

    /**
     * A SELECT as the model behind it - null when it is more than the visual view can show.
     *
     * @return array<string, mixed>|null
     */
    public static function fromSql(string $sql): ?array
    {
        $statement = preg_replace('/\s+/', ' ', SqlGuard::normalize($sql)) ?? '';
        if ($statement === '' || stripos($statement, 'select') !== 0) {
            return null;
        }
        // one SELECT of one or more tables - nothing nested, nothing joined together with UNION
        if (preg_match('/\b(union|select)\b/i', substr($statement, 6)) === 1) {
            return null;
        }

        $pattern = '/^select\s+(?<distinct>distinct\s+)?(?<columns>.+?)\s+from\s+(?<tables>.+?)'
            . '(?:\s+where\s+(?<where>.+?))?'
            . '(?:\s+order\s+by\s+(?<order>.+?))?'
            . '(?:\s+limit\s+(?<limit>\d+))?$/i';
        if (preg_match($pattern, $statement, $match) !== 1) {
            return null;
        }
        if (preg_match('/\b(group\s+by|having)\b/i', $statement) === 1) {
            return null;
        }

        $tables = self::parseTables($match['tables']);
        if ($tables === null) {
            return null;
        }
        $columns = self::parseColumns($match['columns'], $tables['from']['alias']);
        if ($columns === null) {
            return null;
        }
        $where = self::parseWhere($match['where'] ?? '');
        if ($where === null) {
            return null;
        }
        $orderBy = self::parseOrderBy($match['order'] ?? '', $tables['from']['alias']);
        if ($orderBy === null) {
            return null;
        }

        return [
            'from' => $tables['from'],
            'joins' => $tables['joins'],
            'columns' => $columns,
            'where' => $where,
            'orderBy' => $orderBy,
            'limit' => isset($match['limit']) && $match['limit'] !== '' ? (int)$match['limit'] : 0,
            'distinct' => ($match['distinct'] ?? '') !== '',
        ];
    }

    /** @return array{from: array{table: string, alias: string}, joins: list<array<string, mixed>>}|null */
    private static function parseTables(string $source): ?array
    {
        // split at every JOIN, keeping the kind of join that stood in front of it
        $parts = preg_split(
            '/\s+((?:inner|left(?:\s+outer)?|right(?:\s+outer)?|cross)\s+)?join\s+/i',
            trim($source),
            -1,
            PREG_SPLIT_DELIM_CAPTURE,
        );
        if ($parts === false || $parts === []) {
            return null;
        }

        $from = self::parseTableReference((string)array_shift($parts));
        if ($from === null) {
            return null;
        }

        $joins = [];
        // what is left comes in pairs: the kind of join, then the table with its condition
        foreach (array_chunk($parts, 2) as $pair) {
            [$type, $rest] = [strtolower(trim((string)($pair[0] ?? ''))), (string)($pair[1] ?? '')];
            if (preg_match('/^(?<table>.+?)\s+on\s+(?<on>.+)$/i', trim($rest), $match) !== 1) {
                return null;
            }
            $table = self::parseTableReference($match['table']);
            $on = self::parseOn($match['on']);
            if ($table === null || $on === null) {
                return null;
            }
            $type = trim(preg_replace('/\s+outer/i', '', $type) ?? '');
            $joins[] = [
                'type' => array_key_exists($type, self::JOIN_TYPES) ? $type : 'inner',
                'table' => $table['table'],
                'alias' => $table['alias'],
                'on' => $on,
            ];
        }

        return ['from' => $from, 'joins' => $joins];
    }

    /** @return array{table: string, alias: string}|null */
    private static function parseTableReference(string $source): ?array
    {
        if (preg_match('/^(?<table>' . self::NAME . '|`[^`]+`|"[^"]+")(?:\s+(?:as\s+)?(?<alias>' . self::NAME . '|`[^`]+`|"[^"]+"))?$/i', trim($source), $match) !== 1) {
            return null;
        }
        $table = self::unquote($match['table']);

        return ['table' => $table, 'alias' => self::unquote($match['alias'] ?? '') ?: $table];
    }

    /** @return list<array{left: array{alias: string, column: string}, right: array{alias: string, column: string}}>|null */
    private static function parseOn(string $source): ?array
    {
        $conditions = [];
        foreach (preg_split('/\s+and\s+/i', trim($source)) ?: [] as $condition) {
            $field = '(?:(?<%1$sAlias>' . self::NAME . '|`[^`]+`|"[^"]+")\.)?(?<%1$sColumn>' . self::NAME . '|`[^`]+`|"[^"]+")';
            $pattern = '/^' . sprintf($field, 'left') . '\s*=\s*' . sprintf($field, 'right') . '$/i';
            if (preg_match($pattern, trim($condition), $match) !== 1) {
                return null;
            }
            $conditions[] = [
                'left' => ['alias' => self::unquote($match['leftAlias'] ?? ''), 'column' => self::unquote($match['leftColumn'])],
                'right' => ['alias' => self::unquote($match['rightAlias'] ?? ''), 'column' => self::unquote($match['rightColumn'])],
            ];
        }

        return $conditions === [] ? null : $conditions;
    }

    /** @return list<array{alias: string, column: string, as: string}>|null */
    private static function parseColumns(string $source, string $defaultAlias): ?array
    {
        $source = trim($source);
        if ($source === '*') {
            return [];
        }
        $columns = [];
        foreach (explode(',', $source) as $part) {
            $pattern = '/^(?:(?<alias>' . self::NAME . '|`[^`]+`|"[^"]+")\.)?(?<column>\*|' . self::NAME . '|`[^`]+`|"[^"]+")'
                . '(?:\s+(?:as\s+)?(?<as>' . self::NAME . '|`[^`]+`|"[^"]+"))?$/i';
            if (preg_match($pattern, trim($part), $match) !== 1) {
                return null;
            }
            $columns[] = [
                'alias' => self::unquote($match['alias'] ?? '') ?: $defaultAlias,
                'column' => self::unquote($match['column']),
                'as' => self::unquote($match['as'] ?? ''),
            ];
        }

        return $columns;
    }

    /** @return list<array<string, mixed>>|null */
    private static function parseWhere(string $source): ?array
    {
        $source = trim($source);
        if ($source === '') {
            return [];
        }
        $parts = preg_split('/\s+(and|or)\s+/i', $source, -1, PREG_SPLIT_DELIM_CAPTURE);
        if ($parts === false) {
            return null;
        }

        $conditions = [];
        $connector = 'AND';
        foreach ($parts as $index => $part) {
            if ($index % 2 === 1) {
                $connector = strtoupper(trim($part));
                continue;
            }
            $pattern = '/^(?:(?<alias>' . self::NAME . '|`[^`]+`|"[^"]+")\.)?(?<column>' . self::NAME . '|`[^`]+`|"[^"]+")\s*'
                . '(?<operator>=|<>|!=|<=|>=|<|>|not\s+like|like|in|is\s+not\s+null|is\s+null)\s*(?<value>.*)$/i';
            if (preg_match($pattern, trim($part), $match) !== 1) {
                return null;
            }
            $operator = strtoupper(preg_replace('/\s+/', ' ', trim($match['operator'])) ?? '');
            $operator = $operator === '!=' ? '<>' : $operator;
            $conditions[] = [
                'alias' => self::unquote($match['alias'] ?? ''),
                'column' => self::unquote($match['column']),
                'operator' => $operator,
                'value' => self::unliteral(trim($match['value'])),
                'connector' => $index === 0 ? 'AND' : $connector,
            ];
        }

        return $conditions;
    }

    /** @return list<array{alias: string, column: string, direction: string}>|null */
    private static function parseOrderBy(string $source, string $defaultAlias): ?array
    {
        $source = trim($source);
        if ($source === '') {
            return [];
        }
        $orders = [];
        foreach (explode(',', $source) as $part) {
            $pattern = '/^(?:(?<alias>' . self::NAME . '|`[^`]+`|"[^"]+")\.)?(?<column>' . self::NAME . '|`[^`]+`|"[^"]+")(?:\s+(?<direction>asc|desc))?$/i';
            if (preg_match($pattern, trim($part), $match) !== 1) {
                return null;
            }
            $orders[] = [
                'alias' => self::unquote($match['alias'] ?? '') ?: $defaultAlias,
                'column' => self::unquote($match['column']),
                'direction' => strtoupper($match['direction'] ?? 'ASC') === 'DESC' ? 'DESC' : 'ASC',
            ];
        }

        return $orders;
    }

    /** @return array{table: string, alias: string}|null */
    private static function readTable(mixed $from): ?array
    {
        if (!is_array($from)) {
            return null;
        }
        $table = self::identifier($from['table'] ?? '');
        if ($table === '') {
            return null;
        }

        return ['table' => $table, 'alias' => self::identifier($from['alias'] ?? '') ?: $table];
    }

    /** @return list<array{alias: string, column: string, as: string}> */
    private static function readColumns(mixed $columns): array
    {
        $read = [];
        foreach (is_array($columns) ? $columns : [] as $column) {
            if (!is_array($column)) {
                continue;
            }
            $name = ($column['column'] ?? '') === '*' ? '*' : self::identifier($column['column'] ?? '');
            $alias = self::identifier($column['alias'] ?? '');
            if ($name !== '' && $alias !== '') {
                $read[] = ['alias' => $alias, 'column' => $name, 'as' => self::identifier($column['as'] ?? '')];
            }
        }

        return $read;
    }

    /** @return list<array<string, mixed>> */
    private static function readJoins(mixed $joins): array
    {
        $read = [];
        foreach (is_array($joins) ? $joins : [] as $join) {
            if (!is_array($join)) {
                continue;
            }
            $table = self::readTable($join);
            $type = strtolower((string)($join['type'] ?? 'inner'));
            if ($table === null) {
                continue;
            }
            $on = [];
            foreach (is_array($join['on'] ?? null) ? $join['on'] : [] as $condition) {
                $left = self::readField($condition['left'] ?? null);
                $right = self::readField($condition['right'] ?? null);
                if ($left !== null && $right !== null) {
                    $on[] = ['left' => $left, 'right' => $right];
                }
            }
            $read[] = [
                'type' => array_key_exists($type, self::JOIN_TYPES) ? $type : 'inner',
                'table' => $table['table'],
                'alias' => $table['alias'],
                'on' => $on,
            ];
        }

        return $read;
    }

    /** @return list<array<string, mixed>> */
    private static function readConditions(mixed $conditions): array
    {
        $read = [];
        foreach (is_array($conditions) ? $conditions : [] as $condition) {
            $field = self::readField($condition);
            $operator = strtoupper(trim((string)($condition['operator'] ?? '=')));
            if ($field === null || !in_array($operator, self::OPERATORS, true)) {
                continue;
            }
            $read[] = [
                ...$field,
                'operator' => $operator,
                'value' => (string)($condition['value'] ?? ''),
                'connector' => strtoupper((string)($condition['connector'] ?? 'AND')) === 'OR' ? 'OR' : 'AND',
            ];
        }

        return $read;
    }

    /** @return list<array{alias: string, column: string, direction: string}> */
    private static function readOrderBy(mixed $orders): array
    {
        $read = [];
        foreach (is_array($orders) ? $orders : [] as $order) {
            $field = self::readField($order);
            if ($field !== null) {
                $read[] = [...$field, 'direction' => strtoupper((string)($order['direction'] ?? 'ASC')) === 'DESC' ? 'DESC' : 'ASC'];
            }
        }

        return $read;
    }

    /** @return array{alias: string, column: string}|null */
    private static function readField(mixed $field): ?array
    {
        if (!is_array($field)) {
            return null;
        }
        $alias = self::identifier($field['alias'] ?? '');
        $column = ($field['column'] ?? '') === '*' ? '*' : self::identifier($field['column'] ?? '');

        return $alias === '' || $column === '' ? null : ['alias' => $alias, 'column' => $column];
    }

    /** Names come from the browser: only what can be a name of a table, column or alias. */
    private static function identifier(mixed $value): string
    {
        $value = is_string($value) ? trim($value) : '';

        return preg_match('/^' . self::NAME . '$/', $value) === 1 ? $value : '';
    }

    private static function unquote(string $value): string
    {
        return trim(trim($value), '`"');
    }

    /** A value as it goes into the statement - numbers as they are, everything else quoted. */
    private static function literal(string $value, string $operator): string
    {
        if ($operator === 'IN') {
            $parts = array_map(
                static fn(string $part): string => self::literal(trim($part), '='),
                explode(',', trim($value, "() \t")),
            );

            return '(' . implode(', ', $parts) . ')';
        }
        if ($value === '') {
            return "''";
        }
        if (preg_match('/^-?\d+(\.\d+)?$/', $value) === 1) {
            return $value;
        }
        if (in_array(strtoupper($value), ['NULL', 'TRUE', 'FALSE'], true)) {
            return strtoupper($value);
        }

        return "'" . str_replace("'", "''", $value) . "'";
    }

    /** The other way round: the literal of a statement as the value of the mask. */
    private static function unliteral(string $value): string
    {
        $value = trim($value);
        if (strlen($value) >= 2 && $value[0] === "'" && str_ends_with($value, "'")) {
            return str_replace("''", "'", substr($value, 1, -1));
        }

        return $value;
    }
}
