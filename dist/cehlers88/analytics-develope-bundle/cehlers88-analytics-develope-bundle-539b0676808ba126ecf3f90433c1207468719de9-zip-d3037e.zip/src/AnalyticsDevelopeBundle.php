<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 18:59
 */

namespace Cehlers88\AnalyticsDevelopeBundle;

use Cehlers88\AnalyticsCore\Support\AbstractBundlePlugin;
use Cehlers88\AnalyticsCore\Support\DTO\UI\MenuItemDTO;
use Cehlers88\AnalyticsDocumentsBundle\ENUM\EPermission;

class AnalyticsDevelopeBundle extends AbstractBundlePlugin
{
    public const NAME = 'AnalyticsDevelopeBundle';

    public function getConfigurationGroups(): array
    {
        return [];
    }

    public function getDescription(): string
    {
        return 'Git-Repositories, ihre Issues und Werkzeuge rund um die Entwicklung.';
    }

    public function getMenuItems(): array
    {
        return [

        ];
    }

    public function getPermissions(): array
    {
        return EPermission::getPermissions();
    }

    public function getVersion(): string
    {
        return '1.0.0';
    }
}