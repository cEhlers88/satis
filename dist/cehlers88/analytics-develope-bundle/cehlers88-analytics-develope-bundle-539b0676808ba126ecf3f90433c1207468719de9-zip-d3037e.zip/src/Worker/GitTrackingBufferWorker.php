<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Worker;

use Cehlers88\AnalyticsCore\Worker\AbstractWorker;
use Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\TrackingBuffer\EnrichTrackingEntityJob;
use Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\TrackingBuffer\UpdateParentChildRelationsJob;
use Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\TrackingBuffer\UpdateStateJob;

class GitTrackingBufferWorker extends AbstractWorker
{
    private const REQUIRED_DATA_KEYS = [
        //self::BUFFER_REPO_FETCH_KEY,
        'SERVICE_ENDPOINT.git_webhook'
    ];

    public function getRequiredJobs(): array
    {
        return [
            EnrichTrackingEntityJob::class,
            UpdateParentChildRelationsJob::class,
            UpdateStateJob::class
        ];
    }

    public function handleError(string $error, array $data): void
    {
        switch ($error) {
            default:
                parent::handleError($error, $data);
        }
    }

    public function getWorkingObjects(): array
    {
        return $this->trackingBufferRepository->findByAnyDataKeyValue(self::REQUIRED_DATA_KEYS);
    }
}