<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 13.09.2024
 * Time: 12:32
 */

namespace Cehlers88\AnalyticsDevelopeBundle\Worker;

use Analytics\Worker\Job\DispatchUpdateClientInfosJob;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Worker\AbstractWorker;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitRepository;
use Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\CustomObject\UpdateRepositoryInfosJob;

class GitRepositoriesInfosWorker extends AbstractWorker
{
    public function __construct(
        private readonly CustomObjectProvider $customObjectProvider
    )
    {

    }

    public function getRequiredJobs(): array
    {
        return [
            UpdateRepositoryInfosJob::class
        ];
    }

    public function getWorkingObjects(): array
    {
        return $this->customObjectProvider->getCustomEntitiesByClassName(GitRepository::class);
    }
}