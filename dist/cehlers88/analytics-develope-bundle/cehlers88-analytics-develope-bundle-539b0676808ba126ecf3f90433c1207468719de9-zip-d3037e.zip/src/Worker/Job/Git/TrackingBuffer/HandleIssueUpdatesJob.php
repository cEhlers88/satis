<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\TrackingBuffer;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;

class HandleIssueUpdatesJob extends AbstractWorkerJob
{
    public function __construct(
        //private readonly TrackingBufferRepository $trackingBufferRepository,
    )
    {
        $this->setType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION);
    }

    public function willHandle(object $workingObject): bool
    {
        return true;
    }

    /**
     * @param TrackingBuffer $object
     * @return AbstractWorkerJob
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        return $this;
    }

    public function getDescription(): string
    {
        return 'Enrich Tracking Buffer with additional data based on data from GitHub.';
    }
}