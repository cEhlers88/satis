<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\CustomObject;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\Executor\ExecutorInterface;
use Cehlers88\AnalyticsCore\Executor\ExecutorProvider;
use Cehlers88\AnalyticsCore\Executor\ExternalServiceExecutor;
use Cehlers88\AnalyticsCore\Support\DTO\CurlResponseDTO;
use Cehlers88\AnalyticsCore\Support\Logging\SimpleConsoleLogger;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitRepository;

class UpdateRepositoryInfosJob extends AbstractWorkerJob
{
    public function __construct(
        private readonly ExecutorProvider     $executorProvider,
        private readonly CustomObjectProvider $customObjectProvider
    )
    {
        $this->setType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_END);
    }

    /**
     * @param GitRepository $object
     * @return AbstractWorkerJob
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $exec = $this->getExternalServiceExecutor();
        $exec
            ->setPropertyValue(ExternalServiceExecutor::KEY_SERVICE_NAME, 'GitHub')
            ->setPropertyValue(ExternalServiceExecutor::KEY_FUNCTION_NAME, 'getRepository')
            ->setPropertyValue(ExternalServiceExecutor::KEY_ARGUMENTS, ["repositoryName" => $object->getRepositoryPath()])
            ->setPropertyValue(ExternalServiceExecutor::KEY_OPTIONS, []);

        $exec->enableDebugMode(true);
        $exec->setLogger(new SimpleConsoleLogger());
        $exec->run();

        /** @var CurlResponseDTO $lastResult */
        $lastResult = $exec->getLastResult();

        if ($lastResult->statusCode === 200) {
            $object->setAttribute('raw', json_encode($lastResult->body));
        }
        $this->customObjectProvider->save($object);

        return $this;
    }

    /**
     * @return ExternalServiceExecutor
     */
    private function getExternalServiceExecutor(): ExecutorInterface
    {
        return $this->executorProvider->getExecutor(ExternalServiceExecutor::class);
    }

    public function getDescription(): string
    {
        return '';
    }
}