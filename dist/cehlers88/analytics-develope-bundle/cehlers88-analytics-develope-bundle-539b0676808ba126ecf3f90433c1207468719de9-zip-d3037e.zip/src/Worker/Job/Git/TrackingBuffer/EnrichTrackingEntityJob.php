<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\TrackingBuffer;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;

class EnrichTrackingEntityJob extends AbstractWorkerJob
{
    private const EMPTY_HASH = '0000000000000000000000000000000000000000';
    public const BUFFER_REPO_FETCH_KEY = 'BUFFER.git_repo_fetch';

    public function __construct(
        private readonly TrackingBufferRepository $trackingBufferRepository,
    )
    {
        $this->setType(eWorkerJobType::SINGLE_TRACKING_BUFFER_MANIPULATION);
    }

    public function willHandle(object $workingObject): bool
    {
        return true;
    }

    /**
     * @param TrackingBuffer $object
     * @return AbstractWorkerJob
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {

        $handlerData = $object->getHandlerData() ?? [];
        $data = $object->getData();

        if (is_string($data['body'])) {
            $data['body'] = json_decode($data['body'], true);
            $object->setData($data);
        }

        if (!isset($handlerData['eventReason']) || empty($handlerData['eventReason'])) {
            $handlerData['eventReason'] = $this->evalEventReason($data['body']);
            $object->setHandlerData($handlerData);
        }
        if (!isset($handlerData['repositoryName']) || empty($handlerData['repositoryName'])) {
            $handlerData['repositoryName'] = $this->evalRepositoryName($data['body']);
        }
        if (!isset($handlerData['refId']) || empty($handlerData['refId'])) {

            $handlerData['refId'] = $this->generateRefId($object);
        }

        $object->setHandlerData($handlerData);

        return $this;
    }

    private function evalEventReason(array $bodyData): string
    {
        $reason = '';

        if (isset($bodyData['check_run'])) {
            switch ($bodyData['action']) {
                case 'created':
                    return 'check_run_created';
                case 'completed':
                    return 'check_run_completed';
            }
        }
        if (isset($bodyData['check_suite'])) {
            switch ($bodyData['action']) {
                case 'completed':
                    return 'check_suite_completed';
            }
        }

        if (isset($bodyData['workflow_job'])) {
            switch ($bodyData['action']) {
                case 'completed':
                    return 'workflow_job_completed';
                case 'in_progress':
                    return 'workflow_job_in_progress';
                case 'queued':
                    return 'workflow_job_queued';
            }
        }

        if (isset($bodyData['workflow_run'])) {
            switch ($bodyData['action']) {
                case 'completed':
                    return 'workflow_run_completed';
                case 'in_progress':
                    return 'workflow_run_in_progress';
                case 'requested':
                    return 'workflow_run_requested';
            }
        }

        if (isset($bodyData['pull_request'])) {
            switch ($bodyData['action']) {
                case 'assigned':
                    return 'pull_request_assigned';
                case 'edited':
                    return 'pull_request_edited';
                case 'opened':
                    return 'pull_request_opened';
                case 'review_requested':
                    return 'review_requested';
            }
        }

        if (isset($bodyData['issue'])) {
            switch ($bodyData['action']) {
                case 'assigned':
                    return 'issue_assigned';
                case 'opened':
                    return 'issue_opened';
            }
        }

        if (isset($bodyData['repository'])) {
            if (isset($bodyData['zen'])) {
                return 'ping';
            }
            if (isset($bodyData['before']) && $bodyData['before'] === self::EMPTY_HASH) {
                return 'first_branch_push';
            }
            if (isset($bodyData['after']) && $bodyData['after'] === self::EMPTY_HASH) {
                return 'branch_delete';
            }
            if (isset($bodyData['pusher'])) {
                return 'push';
            }
        }

        if (isset($bodyData['ref_type'])) {
            switch ($bodyData['ref_type']) {
                case 'branch':
                    return 'branch_created';
            }
        }

        return $reason;
    }

    private function evalRepositoryName(array $bodyData): string
    {
        if (isset($bodyData['repository'])) {
            return $bodyData['repository']['full_name'];
        }

        return '';
    }

    /**
     * RefId is used to create a parent/child relationship between multiple objects
     * @param TrackingBuffer $buffer
     * @return string
     */
    private function generateRefId(TrackingBuffer $buffer): string
    {
        $eventReason = $buffer->getHandlerData()['eventReason'] ?? '';

        switch ($eventReason) {
            case 'check_run_completed':
            case 'check_run_created':
                $ids = [
                    'check_run_' . $buffer->getData()['body']['check_run']['id'],
                ];
                if ($eventReason === 'check_run_created') {
                    $ids[] = 'workflow_job_' . $buffer->getData()['body']['check_run']['id'];
                }

                return implode('|', $ids);

            case 'check_suite_completed':
            case 'check_suite_in_progress':
                return 'check_suite_' . $buffer->getData()['body']['check_suite']['id'] . '';

            case 'workflow_job_completed':
            case 'workflow_job_in_progress':
            case 'workflow_job_queued':
                $ids = [
                    'workflow_job_' . $buffer->getData()['body']['workflow_job']['id'],
                ];
                if ($eventReason === 'workflow_job_queued') {
                    $ids[] = 'workflow_run_' . $buffer->getData()['body']['workflow_job']['run_id'];
                }

                return implode('|', $ids);

            case 'workflow_run_completed':
            case 'workflow_run_in_progress':
            case 'workflow_run_requested':
                return 'workflow_run_' . $buffer->getData()['body']['workflow_run']['id'] . '';
            default:
                $this->logWarning('Unknown eventReason "' . $eventReason . '"');
        }

        return '';
    }

    public function getDescription(): string
    {
        return 'Enrich Tracking Buffer with additional data based on data from GitHub.';
    }
}