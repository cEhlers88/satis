<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\TrackingBuffer;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\ENUM\State\eTrackingBufferState;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;

class UpdateStateJob extends AbstractWorkerJob
{
    public const CHECK_RUN_COMPLETED_EVENT_REASON = 'check_run_completed';
    public const CHECK_SUITE_COMPLETED_EVENT_REASON = 'check_suite_completed';
    public const CHECK_SUITE_IN_PROGRESS_EVENT_REASON = 'check_suite_in_progress';
    public const WORKFLOW_RUN_COMPLETED_EVENT_REASON = 'workflow_run_completed';
    public const WORKFLOW_RUN_IN_PROGRESS_EVENT_REASON = 'workflow_run_in_progress';
    public const WORKFLOW_RUN_REQUESTED_EVENT_REASON = 'workflow_run_requested';
    public const WORKFLOW_JOB_COMPLETED_EVENT_REASON = 'workflow_job_completed';
    public const WORKFLOW_JOB_QUEUED_EVENT_REASON = 'workflow_job_queued';
    public const WORKFLOW_JOB_IN_PROGRESS_EVENT_REASON = 'workflow_job_in_progress';

    public function __construct()
    {
        $this->setType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_END);
    }

    /**
     * @param TrackingBuffer $object
     * @return AbstractWorkerJob
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $handlerData = $object->getHandlerData() ?? [];
        $eventReason = $handlerData['eventReason'] ?? '';

        switch ($eventReason) {
            case 'check_run_completed':
            case 'workflow_job_completed':
            case 'workflow_job_in_progress':
            case 'workflow_run_completed':
            case 'workflow_run_in_progress':
                $object->setState(eTrackingBufferState::PROCESSED_FINISHED);
                break;
            case 'check_run_created':
                if ($this->hasChildWithEventReason($object, 'check_run_completed')) {
                    $object->setState(eTrackingBufferState::PROCESSED_FINISHED);
                }
                break;
            case 'workflow_job_queued':
                if ($this->hasChildWithEventReason($object, 'workflow_job_completed')) {
                    $object->setState(eTrackingBufferState::PROCESSED_FINISHED);
                }
                break;
            case 'workflow_run_requested':
                if ($this->hasChildWithEventReason($object, 'workflow_run_completed')) {
                    $object->setState(eTrackingBufferState::PROCESSED_FINISHED);
                }
                break;
        }

        return $this;
    }

    private function hasChildWithEventReason(TrackingBuffer $trackingBuffer, string $eventReason, ?eTrackingBufferState $stateFilter = null): bool
    {
        foreach ($trackingBuffer->getChildTrackingBuffers() as $childTrackingBuffer) {
            $handlerData = $childTrackingBuffer->getHandlerData() ?? [];
            if (($handlerData['eventReason'] ?? '') !== $eventReason) continue;
            if (is_null($stateFilter) || $childTrackingBuffer->getState() === $stateFilter) return true;
        }
        return false;
    }

    public function getDescription(): string
    {
        return 'Enrich Tracking Buffer with additional data based on data from GitHub.';
    }
}