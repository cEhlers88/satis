<?php

namespace Cehlers88\AnalyticsDevelopeBundle\Worker\Job\Git\TrackingBuffer;

use Analytics\ENUM\eWorkerJobType;
use Cehlers88\AnalyticsCore\Entity\TrackingBuffer;
use Cehlers88\AnalyticsCore\Repository\TrackingBufferRepository;
use Cehlers88\AnalyticsCore\Worker\Job\AbstractWorkerJob;
use Symfony\Component\Messenger\MessageBusInterface;

class FetchRepositoryDetailInfosJob extends AbstractWorkerJob
{
    private array $_repositories = [];
    private bool $_needFlush = false;
    private ?TrackingBuffer $_lastHandledTrackingBuffer = null;

    public function __construct(
        MessageBusInterface              $messageBus,
        private TrackingBufferRepository $trackingBufferRepository,
    )
    {
        $this->setType(eWorkerJobType::MULTIPLE_TRACKING_BUFFER_MANIPULATION_ON_END);
    }

    /**
     * @param TrackingBuffer $object
     */
    public function workOnObject(object $object): AbstractWorkerJob
    {
        $handlerData = $object->getHandlerData();

        if (!array_key_exists('repositoryName', $handlerData)) {
            return $this;
        }

        $this->_repositories[] = $handlerData['repositoryName'];

        $handlerData['detailRequest'] = new \DateTimeImmutable();
        $object->setHandlerData($handlerData);
        $this->_lastHandledTrackingBuffer = $object;

        return $this;
    }

    public function getName(): string
    {
        return self::class;
    }

    public function willHandle(object $workingObject): bool
    {
        $handlerData = $workingObject->getHandlerData();

        if (empty($handlerData) || isset($handlerData['detailRequest'])) {
            return false;
        }

        return true;
    }

    protected function startJob(): void
    {
        $this->_repositories = [];
    }

    protected function finishJob(): void
    {
        /*if (count($this->_repositories) > 0) {
            $this->_repositories = array_unique($this->_repositories);

            $trackingBuffer = new TrackingBuffer();
            $trackingBuffer
                ->setApplication($this->_lastHandledTrackingBuffer->getApplication())
                ->setData([
                    'key' => GitTrackingBufferWorker::BUFFER_REPO_FETCH_KEY
                ])
                ->setState(eTrackingBufferState::NEW);

            $this->trackingBufferRepository->save($trackingBuffer);
            $this->_needFlush = true;
        }

        if ($this->_needFlush) {
            $this->logInfo('flushing');
            $this->trackingBufferRepository->flush();
            $this->logInfo('flushed');
            $this->_needFlush = false;
        }*/

        parent::finishJob();
    }
}