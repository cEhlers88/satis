<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Changelog;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * The changelog on the server, as two Markdown files and the images they show:
 *
 *     {directory}/current.md        what has changed since the last release
 *     {directory}/history.md        the changelogs of past releases, the newest first
 *     {directory}/images/{id}.{ext} images the changelog shows (changelog-image:{id}.{ext})
 *
 * A document is read with its revision (a hash of its text); a save names the revision it
 * is based on and is refused (ChangelogConflictException) when someone saved in between,
 * unless it is forced.
 */
final class ChangelogStorage
{
    public const CURRENT = 'current';
    public const HISTORY = 'history';
    public const DOCUMENTS = [self::CURRENT, self::HISTORY];

    public const MAX_DOCUMENT_BYTES = 2 * 1024 * 1024;
    public const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
    /** Only pixel images - an SVG could carry script. */
    public const IMAGE_TYPES = ['png' => 'image/png', 'jpg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp'];
    public const IMAGE_ID = '/^[a-f0-9]{16}\.(png|jpg|gif|webp)$/D';

    public function __construct(
        #[Autowire('%analytics_develope.changelog.directory%')]
        private readonly string $directory,
    ) {
    }

    /** @return array{content: string, revision: string} */
    public function read(string $document): array
    {
        $file = $this->file($document);
        $content = is_file($file) ? (string)file_get_contents($file) : '';

        return ['content' => $content, 'revision' => self::revisionOf($content)];
    }

    /**
     * @param string|null $baseRevision the revision the text is based on; null: whatever is there
     * @return string the new revision
     */
    public function write(string $document, string $content, ?string $baseRevision, bool $force = false): string
    {
        if (strlen($content) > self::MAX_DOCUMENT_BYTES) {
            throw new \InvalidArgumentException(sprintf('The changelog is larger than %d MB.', self::MAX_DOCUMENT_BYTES / 1024 / 1024));
        }

        return $this->locked(function () use ($document, $content, $baseRevision, $force): string {
            $current = $this->read($document);
            if (!$force && $baseRevision !== null && $baseRevision !== $current['revision']) {
                throw new ChangelogConflictException($current['content'], $current['revision']);
            }
            $this->put($document, $content);

            return self::revisionOf($content);
        });
    }

    /**
     * Adds entries to the current changelog, one list item each - below what is there.
     *
     * @param list<string> $entries
     * @return int how many were added
     */
    public function appendEntries(array $entries): int
    {
        $lines = [];
        foreach ($entries as $entry) {
            // "- [x] Did it" becomes "- Did it"; one line per entry
            $text = trim(preg_replace('/^\s*(?:[-*+]|\d{1,9}[.)])\s+(?:\[[ xX]\]\s+)?/', '', str_replace(["\r", "\n"], ' ', (string)$entry)) ?? '');
            if ($text !== '') {
                $lines[] = '- ' . $text;
            }
        }
        if ($lines === []) {
            return 0;
        }

        $this->locked(function () use ($lines): void {
            $content = rtrim($this->read(self::CURRENT)['content']);
            $lastLine = $content === '' ? '' : (string)substr($content, (int)strrpos("\n" . $content, "\n"));
            // a list is continued; after anything else the entries start a list of their own
            $separator = $content === '' ? '' : (preg_match('/^\s*[-*+]\s/', $lastLine) === 1 ? "\n" : "\n\n");
            $this->put(self::CURRENT, $content . $separator . implode("\n", $lines) . "\n");
        });

        return count($lines);
    }

    /**
     * Closes the current changelog: it goes on top of the history under the given title and
     * the date, and the current one starts empty.
     *
     * @return string the heading it got in the history
     */
    public function release(string $title, ?\DateTimeInterface $date = null): string
    {
        $title = trim(str_replace(["\r", "\n", '#'], ' ', $title));
        if ($title === '') {
            throw new \InvalidArgumentException('A release needs a title - a version, say.');
        }

        return $this->locked(function () use ($title, $date): string {
            $current = trim($this->read(self::CURRENT)['content']);
            if ($current === '') {
                throw new \InvalidArgumentException('The current changelog is empty - there is nothing to release.');
            }
            $heading = sprintf('## %s (%s)', $title, ($date ?? new \DateTimeImmutable())->format('d.m.Y'));
            $history = trim($this->read(self::HISTORY)['content']);
            $this->put(self::HISTORY, $heading . "\n\n" . $current . "\n" . ($history !== '' ? "\n" . $history . "\n" : ''));
            $this->put(self::CURRENT, '');

            return $heading;
        });
    }

    /** Takes an uploaded image and says the id it is shown by. */
    public function addImage(string $sourcePath, string $originalName): string
    {
        if (!is_file($sourcePath) || filesize($sourcePath) === 0) {
            throw new \InvalidArgumentException('The image did not arrive.');
        }
        if ((int)filesize($sourcePath) > self::MAX_IMAGE_BYTES) {
            throw new \InvalidArgumentException(sprintf('The image is larger than %d MB.', self::MAX_IMAGE_BYTES / 1024 / 1024));
        }
        $info = @getimagesize($sourcePath);
        $extension = $info === false ? false : array_search($info['mime'] ?? '', self::IMAGE_TYPES, true);
        if ($extension === false) {
            throw new \InvalidArgumentException(sprintf('"%s" is no PNG, JPEG, GIF or WebP image.', $originalName));
        }

        $directory = $this->directory . '/images';
        $this->makeDirectory($directory);
        do {
            $id = bin2hex(random_bytes(8)) . '.' . $extension;
        } while (file_exists($directory . '/' . $id));
        if (!copy($sourcePath, $directory . '/' . $id)) {
            throw new \RuntimeException('The image could not be stored.');
        }

        return $id;
    }

    /** The file of an image, null when there is none by that id. */
    public function imagePath(string $id): ?string
    {
        if (preg_match(self::IMAGE_ID, $id) !== 1) {
            return null;
        }
        $file = $this->directory . '/images/' . $id;

        return is_file($file) ? $file : null;
    }

    public static function revisionOf(string $content): string
    {
        return substr(sha1($content), 0, 16);
    }

    private function file(string $document): string
    {
        if (!in_array($document, self::DOCUMENTS, true)) {
            throw new \InvalidArgumentException(sprintf('There is no changelog document "%s".', $document));
        }

        return $this->directory . '/' . $document . '.md';
    }

    /** Written aside and moved into place - a reader never sees half a file. */
    private function put(string $document, string $content): void
    {
        $this->makeDirectory($this->directory);
        $file = $this->file($document);
        $temporary = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
        file_put_contents($temporary, $content);
        rename($temporary, $file);
    }

    /**
     * One change at a time - an entry moved from a note and a save in the editor must not
     * cross.
     *
     * @template T
     * @param callable(): T $work
     * @return T
     */
    private function locked(callable $work): mixed
    {
        $this->makeDirectory($this->directory);
        $lock = fopen($this->directory . '/.lock', 'c');
        if ($lock === false) {
            throw new \RuntimeException('The changelog cannot be locked.');
        }
        try {
            flock($lock, LOCK_EX);

            return $work();
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    private function makeDirectory(string $directory): void
    {
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException(sprintf('The directory "%s" cannot be created.', $directory));
        }
    }
}
