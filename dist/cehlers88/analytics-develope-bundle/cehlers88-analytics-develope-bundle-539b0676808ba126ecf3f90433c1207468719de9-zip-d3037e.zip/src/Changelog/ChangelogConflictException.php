<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Changelog;

/** Someone saved the changelog in between - see ChangelogStorage::write(). */
final class ChangelogConflictException extends \RuntimeException
{
    public function __construct(
        public readonly string $currentContent,
        public readonly string $currentRevision,
    ) {
        parent::__construct('The changelog was changed meanwhile.');
    }
}
