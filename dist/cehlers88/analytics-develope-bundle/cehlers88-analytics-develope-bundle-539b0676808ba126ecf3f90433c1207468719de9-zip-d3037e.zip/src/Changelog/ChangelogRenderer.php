<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Changelog;

use Cehlers88\AnalyticsCore\Support\Markdown\MarkdownRenderer;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

/**
 * The changelog as HTML - the Markdown of AnalyticsCore, which the notes of the application
 * use as well, with the images of the changelog (changelog-image:{id}) and nothing else.
 */
final class ChangelogRenderer
{
    public const IMAGE_SCHEME = 'changelog-image:';

    public function __construct(
        private readonly UrlGeneratorInterface $urlGenerator,
    ) {
    }

    public function render(string $markdown): string
    {
        return (new MarkdownRenderer(function (string $source): ?string {
            if (!str_starts_with($source, self::IMAGE_SCHEME)) {
                // images from elsewhere would be loaded by everyone who opens the changelog
                return null;
            }
            $id = substr($source, strlen(self::IMAGE_SCHEME));

            return preg_match(ChangelogStorage::IMAGE_ID, $id) === 1
                ? $this->urlGenerator->generate('analytics_develope_changelog_image', ['id' => $id])
                : null;
        }))->render($markdown);
    }
}
