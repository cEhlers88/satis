<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Changelog;

use Cehlers88\AnalyticsDevelopeBundle\Changelog\ChangelogConflictException;
use Cehlers88\AnalyticsDevelopeBundle\Changelog\ChangelogStorage;
use PHPUnit\Framework\TestCase;

class ChangelogStorageTest extends TestCase
{
    private const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

    private string $directory;
    private ChangelogStorage $storage;

    protected function setUp(): void
    {
        $this->directory = sys_get_temp_dir() . '/changelog-test-' . bin2hex(random_bytes(4));
        $this->storage = new ChangelogStorage($this->directory);
    }

    protected function tearDown(): void
    {
        self::removeDirectory($this->directory);
    }

    public static function removeDirectory(string $directory): void
    {
        if (!is_dir($directory)) {
            return;
        }
        foreach (scandir($directory) ?: [] as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $path = $directory . '/' . $entry;
            is_dir($path) ? self::removeDirectory($path) : unlink($path);
        }
        rmdir($directory);
    }

    public function testADocumentThatIsNotThereReadsEmpty(): void
    {
        $this->assertSame(['content' => '', 'revision' => ChangelogStorage::revisionOf('')], $this->storage->read(ChangelogStorage::CURRENT));
    }

    public function testASaveOverANewerRevisionIsRefusedUnlessForced(): void
    {
        $first = $this->storage->write(ChangelogStorage::CURRENT, "- one\n", null);
        $this->storage->write(ChangelogStorage::CURRENT, "- one\n- two\n", $first);

        try {
            $this->storage->write(ChangelogStorage::CURRENT, "- mine\n", $first);
            $this->fail('the stale save went through');
        } catch (ChangelogConflictException $exception) {
            $this->assertSame("- one\n- two\n", $exception->currentContent);
        }

        $this->storage->write(ChangelogStorage::CURRENT, "- mine\n", $first, true);
        $this->assertSame("- mine\n", $this->storage->read(ChangelogStorage::CURRENT)['content']);
    }

    public function testUnknownDocumentsAreRefused(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->storage->read('../secrets');
    }

    public function testEntriesContinueTheListAndLoseTheirTaskMarkup(): void
    {
        $this->storage->write(ChangelogStorage::CURRENT, "### Neu\n\n- first\n", null);

        $count = $this->storage->appendEntries(['- [x] Did it', "Two\nlines", '   ', '3. [X] numbered']);

        $this->assertSame(3, $count);
        $this->assertSame("### Neu\n\n- first\n- Did it\n- Two lines\n- numbered\n", $this->storage->read(ChangelogStorage::CURRENT)['content']);
    }

    public function testEntriesAfterAParagraphStartAListOfTheirOwn(): void
    {
        $this->storage->write(ChangelogStorage::CURRENT, 'Some words', null);

        $this->storage->appendEntries(['New']);

        $this->assertSame("Some words\n\n- New\n", $this->storage->read(ChangelogStorage::CURRENT)['content']);
        $this->assertSame(0, $this->storage->appendEntries([' ']), 'nothing to add changes nothing');
    }

    public function testAReleaseMovesTheCurrentChangelogOnTopOfTheHistory(): void
    {
        $this->storage->write(ChangelogStorage::HISTORY, "## 0.1 (01.01.2026)\n\n- old\n", null);
        $this->storage->write(ChangelogStorage::CURRENT, "- new\n", null);

        $heading = $this->storage->release("0.2\n#", new \DateTimeImmutable('2026-09-19'));

        $this->assertSame('## 0.2 (19.09.2026)', $heading);
        $this->assertSame('', $this->storage->read(ChangelogStorage::CURRENT)['content']);
        $this->assertSame("## 0.2 (19.09.2026)\n\n- new\n\n## 0.1 (01.01.2026)\n\n- old\n", $this->storage->read(ChangelogStorage::HISTORY)['content']);
    }

    public function testNothingIsReleasedWithoutEntriesOrTitle(): void
    {
        foreach ([['', "- new\n"], ['1.0', "  \n"]] as [$title, $current]) {
            $this->storage->write(ChangelogStorage::CURRENT, $current, null, true);
            try {
                $this->storage->release($title);
                $this->fail('released: "' . $title . '"');
            } catch (\InvalidArgumentException) {
                $this->assertSame('', $this->storage->read(ChangelogStorage::HISTORY)['content']);
            }
        }
    }

    public function testImagesAreStoredByTheirTypeOnly(): void
    {
        $png = tempnam(sys_get_temp_dir(), 'changelog-image-');
        file_put_contents($png, base64_decode(self::PNG));
        $svg = tempnam(sys_get_temp_dir(), 'changelog-image-');
        file_put_contents($svg, '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>');

        try {
            $id = $this->storage->addImage($png, 'shot.gif');
            $this->assertMatchesRegularExpression(ChangelogStorage::IMAGE_ID, $id);
            $this->assertStringEndsWith('.png', $id, 'the content decides, not the name');
            $this->assertSame(base64_decode(self::PNG), file_get_contents((string)$this->storage->imagePath($id)));

            $this->assertNull($this->storage->imagePath('../current.md'));
            $this->assertNull($this->storage->imagePath('0123456789abcdef.png'));

            $this->expectException(\InvalidArgumentException::class);
            $this->storage->addImage($svg, 'evil.png');
        } finally {
            @unlink($png);
            @unlink($svg);
        }
    }
}
