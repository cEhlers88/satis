<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Ai\Prompt;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Prompt\AiPromptException;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Prompt\AiPromptService;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageService;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AnthropicUsageClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\ClaudeCodeAnalyticsClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\OpenAiUsageClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\StatusPageClient;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Cache\Adapter\ArrayAdapter;
use Symfony\Component\HttpClient\MockHttpClient;
use Symfony\Component\HttpClient\Response\MockResponse;

final class AiPromptServiceTest extends TestCase
{
    public function testClaudeGetsThePromptWithTheFallbackAndTheTextComesBack(): void
    {
        $sent = null;
        $http = new MockHttpClient(function (string $method, string $url, array $options) use (&$sent): MockResponse {
            self::assertSame('POST', $method);
            self::assertSame(AiPromptService::ANTHROPIC_ENDPOINT, $url);
            self::assertSame(['x-api-key: sk-ant-api03-secret'], $options['normalized_headers']['x-api-key']);
            self::assertSame(['anthropic-beta: server-side-fallback-2026-07-01'], $options['normalized_headers']['anthropic-beta']);
            $sent = json_decode($options['body'], true);

            return new MockResponse(json_encode([
                'model' => 'claude-opus-5-5',
                'stop_reason' => 'end_turn',
                'content' => [['type' => 'thinking', 'thinking' => '…'], ['type' => 'text', 'text' => 'Hallo '], ['type' => 'text', 'text' => 'Welt']],
                'usage' => ['input_tokens' => 12, 'cache_read_input_tokens' => 3, 'output_tokens' => 5],
            ]));
        });

        $answer = $this->service($http, ['CONSTANT.ANTHROPIC_API_KEY' => 'sk-ant-api03-secret'])
            ->ask(AnthropicUsageClient::ID, '  Sag hallo  ', '', '');

        self::assertSame('claude-opus-5-5', $sent['model']);
        self::assertSame('default', $sent['fallbacks']);
        self::assertSame([['role' => 'user', 'content' => 'Sag hallo']], $sent['messages']);
        self::assertSame('Hallo Welt', $answer['text']);
        self::assertSame(15, $answer['inputTokens']);
        self::assertSame(5, $answer['outputTokens']);
        self::assertStringNotContainsString('secret', json_encode($answer));
    }

    public function testOtherModelsGoWithoutTheFallback(): void
    {
        $http = new MockHttpClient(function (string $method, string $url, array $options): MockResponse {
            self::assertArrayNotHasKey('anthropic-beta', $options['normalized_headers']);
            self::assertArrayNotHasKey('fallbacks', json_decode($options['body'], true));

            return new MockResponse(json_encode(['content' => [['type' => 'text', 'text' => 'ok']], 'usage' => []]));
        });

        $answer = $this->service($http, ['CONSTANT.ANTHROPIC_API_KEY' => 'sk-ant-api03-x'])
            ->ask(AnthropicUsageClient::ID, 'Hi', 'claude-haiku-5-5', '');

        self::assertSame('claude-haiku-5-5', $answer['model']);
    }

    public function testTheKeyOfTheApplicationWinsThenTheServerThenTheAiSettings(): void
    {
        $keys = [];
        $http = new MockHttpClient(function (string $method, string $url, array $options) use (&$keys): MockResponse {
            $keys[] = substr($options['normalized_headers']['x-api-key'][0], strlen('x-api-key: '));

            return new MockResponse(json_encode(['content' => [['type' => 'text', 'text' => 'ok']]]));
        });

        $this->service($http, ['@7:CONSTANT.MY_KEY' => 'app-key', 'CONSTANT.MY_KEY' => 'server-key'])
            ->ask(AnthropicUsageClient::ID, 'Hi', 'claude-haiku-5-5', 'CONSTANT.MY_KEY', 7);
        $this->service($http, ['CONSTANT.MY_KEY' => 'server-key'])
            ->ask(AnthropicUsageClient::ID, 'Hi', 'claude-haiku-5-5', 'MY_KEY', 7);
        $this->service($http, ['main.ai.anthropicApiKey' => 'settings-key'])
            ->ask(AnthropicUsageClient::ID, 'Hi', 'claude-haiku-5-5', 'MY_KEY', 7);

        self::assertSame(['app-key', 'server-key', 'settings-key'], $keys);
    }

    public function testAnAdminKeyIsRefusedBeforeAnythingIsSent(): void
    {
        $service = $this->service($this->noRequest(), ['CONSTANT.ANTHROPIC_API_KEY' => 'sk-ant-admin01-x']);

        $this->expectException(AiPromptException::class);
        $this->expectExceptionMessage('Admin-Key');
        $service->ask(AnthropicUsageClient::ID, 'Hi', '', '');
    }

    public function testWithoutAnyKeyItSaysWhichConstantIsMissing(): void
    {
        $this->expectException(AiPromptException::class);
        $this->expectExceptionMessage('"ANTHROPIC_API_KEY"');
        $this->service($this->noRequest(), [])->ask(AnthropicUsageClient::ID, 'Hi', '', '');
    }

    public function testAnEmptyPromptOrABadModelIsRefused(): void
    {
        $service = $this->service($this->noRequest(), ['CONSTANT.ANTHROPIC_API_KEY' => 'sk-ant-api03-x']);

        foreach ([['   ', ''], ['Hi', 'model; rm -rf /']] as [$prompt, $model]) {
            try {
                $service->ask(AnthropicUsageClient::ID, $prompt, $model, '');
                self::fail('expected an exception');
            } catch (AiPromptException) {
                $this->addToAssertionCount(1);
            }
        }
    }

    public function testARefusalWithoutTextIsAnError(): void
    {
        $http = new MockHttpClient(new MockResponse(json_encode(['stop_reason' => 'refusal', 'content' => []])));

        $this->expectException(AiPromptException::class);
        $this->expectExceptionMessage('abgelehnt');
        $this->service($http, ['CONSTANT.ANTHROPIC_API_KEY' => 'sk-ant-api03-x'])->ask(AnthropicUsageClient::ID, 'Hi', '', '');
    }

    public function testAnErrorOfTheApiIsPassedOn(): void
    {
        $http = new MockHttpClient(new MockResponse(json_encode(['error' => ['message' => 'model not found']]), ['http_code' => 404]));

        $this->expectException(AiPromptException::class);
        $this->expectExceptionMessage('Fehler 404: model not found');
        $this->service($http, ['CONSTANT.ANTHROPIC_API_KEY' => 'sk-ant-api03-x'])->ask(AnthropicUsageClient::ID, 'Hi', 'claude-nope', '');
    }

    public function testOpenAiGetsAChatCompletion(): void
    {
        $http = new MockHttpClient(function (string $method, string $url, array $options): MockResponse {
            self::assertSame(AiPromptService::OPENAI_ENDPOINT, $url);
            self::assertSame(['authorization: Bearer sk-proj-x'], $options['normalized_headers']['authorization']);
            self::assertSame('gpt-5', json_decode($options['body'], true)['model']);

            return new MockResponse(json_encode([
                'model' => 'gpt-5',
                'choices' => [['message' => ['content' => 'Antwort'], 'finish_reason' => 'stop']],
                'usage' => ['prompt_tokens' => 4, 'completion_tokens' => 2],
            ]));
        });

        $answer = $this->service($http, ['CONSTANT.OPENAI_API_KEY' => 'sk-proj-x'])->ask(OpenAiUsageClient::ID, 'Hi', '', '');

        self::assertSame('Antwort', $answer['text']);
        self::assertSame(4, $answer['inputTokens']);
        self::assertSame('stop', $answer['stopReason']);
    }

    public function testAnOpenAiRefusalIsAnError(): void
    {
        $http = new MockHttpClient(new MockResponse(json_encode([
            'choices' => [['message' => ['content' => null, 'refusal' => 'Dabei kann ich nicht helfen.'], 'finish_reason' => 'stop']],
        ])));

        $this->expectException(AiPromptException::class);
        $this->expectExceptionMessage('abgelehnt: Dabei kann ich nicht helfen.');
        $this->service($http, ['CONSTANT.OPENAI_API_KEY' => 'sk-proj-x'])->ask(OpenAiUsageClient::ID, 'Hi', '', '');
    }

    public function testTheModelOfTheAiSettingsIsTheDefault(): void
    {
        $service = $this->service($this->noRequest(), ['main.ai.anthropicModel' => 'claude-sonnet-5-5']);

        self::assertSame('claude-sonnet-5-5', $service->defaultModel(AnthropicUsageClient::ID));
        self::assertSame(AiPromptService::DEFAULT_OPENAI_MODEL, $service->defaultModel(OpenAiUsageClient::ID));
    }

    private function noRequest(): MockHttpClient
    {
        return new MockHttpClient(static fn() => throw new \LogicException('no request expected'));
    }

    /** @param array<string, string> $store "@<id>:" in front of a key is the value of that application */
    private function service(MockHttpClient $http, array $store): AiPromptService
    {
        $configuration = $this->createMock(ConfigurationProvider::class);
        $configuration->method('getValue')->willReturnCallback(
            static fn(string $group, string $item, int $applicationId = -1, mixed $default = null): mixed
                => $store[($applicationId > 0 ? '@' . $applicationId . ':' : '') . $group . '.' . $item] ?? $default
        );
        $usage = new AiUsageService(new AnthropicUsageClient($http), new OpenAiUsageClient($http), $configuration, new ArrayAdapter(), new ClaudeCodeAnalyticsClient($http), new StatusPageClient($http));

        return new AiPromptService($http, $usage, $configuration);
    }
}
