<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Ai\Usage;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageException;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageService;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AnthropicUsageClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\ClaudeCodeAnalyticsClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\StatusPageClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\OpenAiUsageClient;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Cache\Adapter\ArrayAdapter;
use Symfony\Component\HttpClient\MockHttpClient;
use Symfony\Component\HttpClient\Response\MockResponse;

final class AiUsageServiceTest extends TestCase
{
    #[DataProvider('constantNames')]
    public function testConstantNamesAreAcceptedWithOrWithoutPrefix(string $given, string $expected): void
    {
        self::assertSame($expected, AiUsageService::normalizeConstantName($given));
    }

    public static function constantNames(): iterable
    {
        yield 'plain' => ['ANTHROPIC_ADMIN_API_KEY', 'ANTHROPIC_ADMIN_API_KEY'];
        yield 'prefixed' => ['CONSTANT.ANTHROPIC_ADMIN_API_KEY', 'ANTHROPIC_ADMIN_API_KEY'];
        yield 'lower prefix' => [' constant.myKey ', 'myKey'];
        yield 'empty' => ['', ''];
        yield 'not a name' => ['a b; drop', ''];
    }

    public function testAMissingConstantSaysWhereToSetIt(): void
    {
        $service = $this->service(new MockHttpClient(static fn() => throw new \LogicException('no request expected')), []);

        try {
            $service->report(AnthropicUsageClient::ID, '', 0.0);
            self::fail('expected an exception');
        } catch (AiUsageException $exception) {
            self::assertStringContainsString('"ANTHROPIC_ADMIN_API_KEY"', $exception->getMessage());
            self::assertStringContainsString('Constants', $exception->getMessage());
        }
    }

    public function testTheKeyIsReadFromTheConstantAndTheReportIsCached(): void
    {
        $calls = 0;
        $http = new MockHttpClient(function (string $method, string $url, array $options) use (&$calls): MockResponse {
            $calls++;
            self::assertSame(['x-api-key: sk-ant-admin01-secret'], $options['normalized_headers']['x-api-key']);

            return new MockResponse(json_encode(['data' => [], 'has_more' => false]));
        });
        $service = $this->service($http, ['CONSTANT.MY_KEY' => 'sk-ant-admin01-secret']);

        $now = new \DateTimeImmutable('2026-11-06 10:00 UTC');
        $first = $service->report(AnthropicUsageClient::ID, 'CONSTANT.MY_KEY', 50.0, $now);
        $service->report(AnthropicUsageClient::ID, 'MY_KEY', 50.0, $now);

        // usage + cost once, the second report came from the cache
        self::assertSame(2, $calls);
        self::assertSame('MY_KEY', $first['constantName']);
        // no cost buckets came back, so the budget stays unknown instead of untouched
        self::assertFalse($first['budget']['known']);
        self::assertArrayNotHasKey('apiKey', $first);
        self::assertStringNotContainsString('secret', json_encode($first));
    }

    public function testClaudeCodeAsksForEachOfTheLastSevenDaysOnceAndCachesThem(): void
    {
        $days = [];
        $http = new MockHttpClient(function (string $method, string $url) use (&$days): MockResponse {
            self::assertStringStartsWith(ClaudeCodeAnalyticsClient::ENDPOINT . '?', $url);
            preg_match('/starting_at=([0-9-]+)/', $url, $match);
            $days[] = $match[1];

            return new MockResponse(json_encode(['data' => [[
                'actor' => ['type' => 'user_actor', 'email_address' => 'dev@example.com'],
                'core_metrics' => ['num_sessions' => 1, 'lines_of_code' => ['added' => 10, 'removed' => 2], 'commits_by_claude_code' => 1, 'pull_requests_by_claude_code' => 0],
            ]], 'has_more' => false, 'next_page' => null]));
        });
        $service = $this->service($http, ['CONSTANT.ANTHROPIC_ADMIN_API_KEY' => 'sk-ant-admin01-x']);

        $now = new \DateTimeImmutable('2026-11-06 10:00 UTC');
        $report = $service->claudeCode('', $now);
        $service->claudeCode('', $now);

        self::assertSame(['2026-10-31', '2026-11-01', '2026-11-02', '2026-11-03', '2026-11-04', '2026-11-05', '2026-11-06'], $days);
        self::assertSame(7, $report['period']['sessions']);
        self::assertSame(70, $report['period']['linesAdded']);
        self::assertSame(1, $report['today']['sessions']);
    }

    public function testTheStatusPageIsReadWithoutAKey(): void
    {
        $http = new MockHttpClient(new MockResponse(json_encode(['status' => ['indicator' => 'none', 'description' => 'All Systems Operational']])));

        $status = $this->service($http, [])->status();

        self::assertSame('ok', $status['light']);
        self::assertSame('All Systems Operational', $status['description']);
    }

    public function testTheValueOfTheChosenApplicationWinsAndTheServerIsTheFallback(): void
    {
        $keys = [];
        $http = new MockHttpClient(function (string $method, string $url, array $options) use (&$keys): MockResponse {
            $keys[] = $options['normalized_headers']['x-api-key'][0];

            return new MockResponse(json_encode(['data' => [], 'has_more' => false]));
        });
        $service = $this->service($http, [
            'CONSTANT.ANTHROPIC_ADMIN_API_KEY' => 'sk-ant-admin01-server',
            '@7:CONSTANT.ANTHROPIC_ADMIN_API_KEY' => 'sk-ant-admin01-app7',
        ]);
        $now = new \DateTimeImmutable('2026-11-06 10:00 UTC');

        $service->report(AnthropicUsageClient::ID, '', 0.0, $now, 7);
        // application 9 has no value of its own
        $service->report(AnthropicUsageClient::ID, '', 0.0, $now, 9);

        self::assertSame([
            'x-api-key: sk-ant-admin01-app7', 'x-api-key: sk-ant-admin01-app7',
            'x-api-key: sk-ant-admin01-server', 'x-api-key: sk-ant-admin01-server',
        ], $keys);
    }

    public function testAMissingConstantOfAnApplicationNamesBoth(): void
    {
        $service = $this->service(new MockHttpClient(static fn() => throw new \LogicException('no request expected')), []);

        $this->expectException(AiUsageException::class);
        $this->expectExceptionMessage('weder für die gewählte Anwendung noch für den Server');

        $service->report(AnthropicUsageClient::ID, 'X', 0.0, null, 3);
    }

    /** @param array<string, string> $store variable name => value */
    private function service(MockHttpClient $http, array $store): AiUsageService
    {
        $configuration = $this->createMock(ConfigurationProvider::class);
        $configuration->method('getValue')->willReturnCallback(
            // a store key "@<id>:" in front of the name is the value of that application
            static fn(string $group, string $item, int $applicationId = -1, mixed $default = null): mixed
                => $store[($applicationId > 0 ? '@' . $applicationId . ':' : '') . $group . '.' . $item] ?? $default
        );

        return new AiUsageService(new AnthropicUsageClient($http), new OpenAiUsageClient($http), $configuration, new ArrayAdapter(), new ClaudeCodeAnalyticsClient($http), new StatusPageClient($http));
    }
}
