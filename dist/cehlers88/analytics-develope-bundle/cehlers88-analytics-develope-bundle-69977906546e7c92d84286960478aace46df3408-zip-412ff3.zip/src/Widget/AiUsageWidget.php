<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Widget;

use Analytics\DTO\WidgetSubmitResultDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Entity\Application;
use Cehlers88\AnalyticsCore\Entity\User;
use Cehlers88\AnalyticsCore\Repository\ApplicationRepository;
use Cehlers88\AnalyticsCore\Widget\AbstractWidget;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Prompt\AiPromptException;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Prompt\AiPromptService;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageException;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageService;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AnthropicUsageClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\OpenAiUsageClient;
use Symfony\Bundle\SecurityBundle\Security;

/**
 * AI usage at a glance, like the little desk displays: tokens of today and of the month,
 * the cost, what is left of the monthly budget, a forecast, a bar per day for the last two
 * weeks and the models that used the most. For Claude also, if switched on, what Claude Code
 * did in the last seven days (sessions, lines, commits, PRs, accepted edits, the people who
 * used it most) and the status page of Anthropic as a traffic light.
 *
 * The admin key of the provider is a constant of the settings (/dashboard/settings →
 * Constants); the tile only names which one - and, optionally, the application whose own
 * value of that constant is meant (constants can be set per application; without a value
 * there, the server's applies). Admins only, since it shows what the organization spends.
 *
 * The button "KI fragen" opens a dialog that sends one prompt through submit()
 * (AiPromptService) - with a regular API key, since the admin key cannot send requests.
 */
class AiUsageWidget extends AbstractWidget
{
    public const ACTION_PROMPT = 'prompt';

    public function __construct(
        private readonly AiUsageService        $usageService,
        private readonly AiPromptService       $promptService,
        private readonly ApplicationRepository $applicationRepository,
        private readonly Security              $security,
    )
    {
    }

    public function getName(): string
    {
        return 'AnalyticsDevelopeBundle.aiUsage';
    }

    public function getTemplateName(): string
    {
        return 'aiUsage';
    }

    public function getRequiredRoles(): array
    {
        return ['ROLE_ADMIN'];
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '10px', 'boxes' => [.4]],
            ['height' => '28px', 'boxes' => [.45, .45]],
            ['height' => '8px', 'boxes' => [.9]],
            ['height' => '40px', 'boxes' => [.95]],
            ['height' => '8px', 'boxes' => [.6]],
        ];
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'provider',
                value: AnthropicUsageClient::ID,
                type: 'string',
                label: 'Anbieter',
                description: 'Wessen Verbrauch gezeigt wird.',
                ui: ['options' => $this->usageService->providerChoices()],
            ),
            PropertyDTO::create(
                name: 'constant',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Konstante mit dem Admin-Key',
                description: 'Name der Konstante aus den Einstellungen (Constants). Leer: ANTHROPIC_ADMIN_API_KEY bzw. OPENAI_ADMIN_API_KEY. Verbrauch und Kosten gibt es nur mit einem Admin-Key (Anthropic: sk-ant-admin…, OpenAI: sk-admin-…).',
            ),
            PropertyDTO::create(
                name: 'application',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Anwendung der Konstante',
                description: 'Konstanten lassen sich pro Anwendung festlegen. Gewählt: deren Wert der Konstante, ohne Wert dort der des Servers. Leer: der Wert des Servers.',
                ui: ['options' => ['' => '– Server –'] + $this->applicationChoices()],
            ),
            PropertyDTO::create(
                name: 'monthlyBudget',
                value: 0,
                type: 'float',
                isOptional: true,
                label: 'Monatsbudget (USD)',
                description: 'Daraus wird das restliche Kontingent berechnet - die Anbieter verraten ihr Guthaben nicht über die API. 0 = ohne Budget.',
                ui: ['min' => 0],
            ),
            PropertyDTO::create(
                name: 'showClaudeCode',
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Claude-Code-Statistik zeigen',
                description: 'Sitzungen, Zeilen, Commits und PRs von Claude Code der letzten 7 Tage - mit demselben Admin-Key. Nur Claude Code über die API, nicht über ein Pro/Max-Abo.',
                conditions: [
                    PropertyConditionDTO::when('provider', OpenAiUsageClient::ID)->then([
                        PropertyConditionDTO::EFFECT_VISIBLE => false,
                    ]),
                ],
            ),
            PropertyDTO::create(
                name: 'showStatus',
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Status von Anthropic zeigen',
                description: 'Ampel nach status.claude.com: Störungen und offene Vorfälle.',
                conditions: [
                    PropertyConditionDTO::when('provider', OpenAiUsageClient::ID)->then([
                        PropertyConditionDTO::EFFECT_VISIBLE => false,
                    ]),
                ],
            ),
            PropertyDTO::create(
                name: 'requestConstant',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Konstante mit dem API-Key für „KI fragen“',
                description: 'Anfragen brauchen einen normalen API-Key (Anthropic: sk-ant-api…), der Admin-Key kann keine senden. Leer: ANTHROPIC_API_KEY bzw. OPENAI_API_KEY; ohne Wert dort der Key aus „KI-Unterstützung“. Gelesen im Kontext der gewählten Anwendung.',
            ),
            PropertyDTO::create(
                name: 'requestModel',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Modell für „KI fragen“',
                description: 'Vorbelegung im Dialog, dort änderbar. Leer: das Modell aus „KI-Unterstützung“, sonst claude-opus-5-5 bzw. gpt-5.',
            ),
        ];
    }

    /**
     * Sends the prompt of the dialog. The tile's settings come along with the form (submit
     * gets no tile properties), so the application is checked again here.
     */
    public function submit(array $data, ?User $user): WidgetSubmitResultDTO
    {
        if ($user === null) {
            return WidgetSubmitResultDTO::createError(401, 'Nicht angemeldet.');
        }
        if (!$user->hasRole('ROLE_ADMIN')) {
            return WidgetSubmitResultDTO::createError(403, 'Nur für Administratoren.');
        }
        if (($data['action'] ?? null) !== self::ACTION_PROMPT) {
            return WidgetSubmitResultDTO::createError(400, 'Unbekannte Aktion.');
        }

        $applicationId = $this->applicationId($data['application'] ?? '');
        if ($applicationId === null) {
            return WidgetSubmitResultDTO::createError(404, 'Die gewählte Anwendung gibt es nicht (mehr) oder sie ist für dich nicht sichtbar.');
        }

        try {
            $answer = $this->promptService->ask(
                $this->usageService->client((string)($data['provider'] ?? ''))->getId(),
                self::string($data['prompt'] ?? ''),
                self::string($data['model'] ?? ''),
                self::string($data['constant'] ?? ''),
                $applicationId,
            );
        } catch (AiPromptException $exception) {
            return WidgetSubmitResultDTO::createError(422, $exception->getMessage());
        }

        return WidgetSubmitResultDTO::createSuccess('', $answer);
    }

    public function enrichProperties(array $properties): array
    {
        $provider = (string)($properties['provider'] ?? AnthropicUsageClient::ID);
        $client = $this->usageService->client($provider);
        $budget = is_numeric($properties['monthlyBudget'] ?? null) ? max(0.0, (float)$properties['monthlyBudget']) : 0.0;

        $applicationId = $this->applicationId($properties['application'] ?? '');

        $view = [
            'providerId' => $client->getId(),
            'providerLabel' => $client->getLabel(),
            'report' => null,
            'error' => null,
            'claudeCode' => null,
            'claudeCodeError' => null,
            'status' => null,
            'request' => [
                // an application that is gone stays named, so submit() refuses it instead of
                // quietly falling back to the server's key
                'application' => $applicationId === -1 ? '' : (string)($properties['application'] ?? ''),
                'constant' => (string)($properties['requestConstant'] ?? ''),
                'model' => trim((string)($properties['requestModel'] ?? '')) ?: $this->promptService->defaultModel($client->getId()),
                'maxLength' => AiPromptService::MAX_PROMPT_LENGTH,
            ],
        ];

        try {
            if ($applicationId === null) {
                throw new AiUsageException('Die gewählte Anwendung gibt es nicht (mehr) oder sie ist für dich nicht sichtbar - bitte in den Einstellungen der Kachel eine andere wählen.');
            }
            $view['report'] = $this->usageService->report($client->getId(), (string)($properties['constant'] ?? ''), $budget, null, $applicationId);
        } catch (AiUsageException $exception) {
            $view['error'] = $exception->getMessage();
        }

        if ($client->getId() !== AnthropicUsageClient::ID || $applicationId === null) {
            return $view;
        }

        // each part fails on its own - an unreachable status page must not hide the usage
        if (self::isOn($properties['showClaudeCode'] ?? true)) {
            try {
                $view['claudeCode'] = $this->usageService->claudeCode((string)($properties['constant'] ?? ''), null, $applicationId);
            } catch (AiUsageException $exception) {
                // the usage part already says what is wrong with the key
                $view['claudeCodeError'] = $view['error'] === null ? $exception->getMessage() : null;
            }
        }
        if (self::isOn($properties['showStatus'] ?? true)) {
            try {
                $view['status'] = $this->usageService->status();
            } catch (AiUsageException) {
                $view['status'] = ['light' => 'unknown', 'description' => 'Status nicht abrufbar', 'url' => 'https://status.claude.com', 'components' => [], 'incidents' => []];
            }
        }

        return $view;
    }

    /**
     * The application of the setting: -1 for none (the server), its id when the signed-in
     * user may read it, null when it is gone or not theirs to read.
     */
    private function applicationId(mixed $value): ?int
    {
        if ($value === '' || $value === null || $value === 0 || $value === '0' || $value === -1 || $value === '-1') {
            return -1;
        }
        if (!(is_int($value) && $value > 0) && !(is_string($value) && preg_match('/^[1-9]\d{0,18}$/', $value) === 1)) {
            return null;
        }

        $application = $this->applicationRepository->find((int)$value);
        $user = $this->security->getUser();

        return $application instanceof Application && $user !== null && $application->allowRead($user)
            ? (int)$application->getId()
            : null;
    }

    /** @return array<int, string> id => name of the applications the signed-in user may read */
    private function applicationChoices(): array
    {
        $user = $this->security->getUser();
        if ($user === null) {
            return [];
        }

        $choices = [];
        // findBy, not findAll(): that one is prefiltered by whatever user an earlier request set
        foreach ($this->applicationRepository->findBy([]) as $application) {
            if ($application->allowRead($user)) {
                $choices[(int)$application->getId()] = (string)$application->getName();
            }
        }
        natcasesort($choices);

        return $choices;
    }

    private static function string(mixed $value): string
    {
        return is_scalar($value) ? (string)$value : '';
    }

    /** A switch as the mask stores it: true, 1, "1", "true" or "on". */
    private static function isOn(mixed $value): bool
    {
        return in_array(is_string($value) ? strtolower($value) : $value, [true, 1, '1', 'true', 'on'], true);
    }
}
