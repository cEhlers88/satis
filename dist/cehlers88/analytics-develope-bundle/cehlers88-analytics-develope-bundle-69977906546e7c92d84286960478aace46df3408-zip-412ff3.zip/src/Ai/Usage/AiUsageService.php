<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Symfony\Contracts\Cache\CacheInterface;
use Symfony\Contracts\Cache\ItemInterface;

/**
 * The usage report of a provider, with the admin key read from a constant of the settings
 * (/dashboard/settings → Constants, stored as CONSTANT.<name>). The key stays on the server;
 * the tile only ever gets the numbers.
 *
 * Reports are cached for a few minutes: the providers refresh them about every five minutes
 * and ask not to be polled more than once a minute, while every tile on every open
 * dashboard renders on its own.
 */
final class AiUsageService
{
    public const CACHE_SECONDS = 300;
    /** Claude Code analytics are daily figures an hour behind - a quarter of an hour is plenty. */
    public const CLAUDE_CODE_CACHE_SECONDS = 900;
    public const STATUS_CACHE_SECONDS = 120;

    /** @var array<string, AiUsageClientInterface> */
    private array $clients = [];

    public function __construct(
        AnthropicUsageClient                   $anthropic,
        OpenAiUsageClient                      $openAi,
        private readonly ConfigurationProvider     $configurationProvider,
        private readonly CacheInterface            $cache,
        private readonly ClaudeCodeAnalyticsClient $claudeCodeClient,
        private readonly StatusPageClient          $statusPageClient,
    )
    {
        foreach ([$anthropic, $openAi] as $client) {
            $this->clients[$client->getId()] = $client;
        }
    }

    /** @return array<string, string> id => label */
    public function providerChoices(): array
    {
        return array_map(static fn(AiUsageClientInterface $client): string => $client->getLabel(), $this->clients);
    }

    public function client(string $provider): AiUsageClientInterface
    {
        return $this->clients[$provider] ?? $this->clients[AnthropicUsageClient::ID];
    }

    /**
     * @return array<string, mixed> the report of AiUsageReport::build(), plus fetchedAt
     *
     * @throws AiUsageException
     */
    public function report(string $provider, string $constantName, float $monthlyBudget, ?\DateTimeImmutable $now = null, int $applicationId = -1): array
    {
        $client = $this->client($provider);
        [$constantName, $apiKey] = $this->apiKey($client, $constantName, $applicationId);

        $now ??= new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $from = min(
            $now->modify('first day of this month')->setTime(0, 0),
            $now->modify(sprintf('-%d days', AiUsageReport::CHART_DAYS - 1))->setTime(0, 0),
        );

        // the key is part of the cache key only as a hash - a new key fetches anew
        $cacheKey = sprintf('develope_ai_usage_%s_%s_%s', $client->getId(), $from->format('Ymd'), hash('sha256', $apiKey));
        $cached = $this->cache->get($cacheKey, function (ItemInterface $item) use ($client, $apiKey, $from): array {
            $item->expiresAfter(self::CACHE_SECONDS);

            return ['days' => $client->fetchDays($apiKey, $from), 'fetchedAt' => time()];
        });

        return [
            ...AiUsageReport::build($cached['days'], $now, $monthlyBudget),
            'fetchedAt' => $cached['fetchedAt'],
            'constantName' => $constantName,
        ];
    }

    /**
     * Claude Code of the last ClaudeCodeReport::DAYS days (UTC), with the Anthropic Admin API
     * key of the given constant.
     *
     * @return array<string, mixed> the report of ClaudeCodeReport::build(), plus fetchedAt
     *
     * @throws AiUsageException
     */
    public function claudeCode(string $constantName, ?\DateTimeImmutable $now = null, int $applicationId = -1): array
    {
        [, $apiKey] = $this->apiKey($this->client(AnthropicUsageClient::ID), $constantName, $applicationId);
        $now = ($now ?? new \DateTimeImmutable('now'))->setTimezone(new \DateTimeZone('UTC'));

        $cacheKey = sprintf('develope_ai_claude_code_%s_%s', $now->format('Ymd'), hash('sha256', $apiKey));
        $cached = $this->cache->get($cacheKey, function (ItemInterface $item) use ($apiKey, $now): array {
            $item->expiresAfter(self::CLAUDE_CODE_CACHE_SECONDS);

            $recordsByDate = [];
            for ($i = ClaudeCodeReport::DAYS - 1; $i >= 0; $i--) {
                $day = $now->modify(sprintf('-%d days', $i));
                $recordsByDate[$day->format('Y-m-d')] = $this->claudeCodeClient->fetchDay($apiKey, $day);
            }

            return ['recordsByDate' => $recordsByDate, 'fetchedAt' => time()];
        });

        return [
            ...ClaudeCodeReport::build($cached['recordsByDate'], $now),
            'fetchedAt' => $cached['fetchedAt'],
        ];
    }

    /**
     * The status page of Anthropic as StatusPageClient::describe() puts it.
     *
     * @return array<string, mixed>
     *
     * @throws AiUsageException
     */
    public function status(): array
    {
        return $this->cache->get('develope_ai_status_anthropic', function (ItemInterface $item): array {
            $item->expiresAfter(self::STATUS_CACHE_SECONDS);

            return $this->statusPageClient->fetch();
        });
    }

    /**
     * The constant to read - the given one or the client's default - and the key in it. With
     * an application, its own value of the constant wins; without one there, the value of the
     * server applies, as everywhere else constants are read.
     *
     * @return array{0: string, 1: string}
     *
     * @throws AiUsageException
     */
    private function apiKey(AiUsageClientInterface $client, string $constantName, int $applicationId = -1): array
    {
        $constantName = self::normalizeConstantName($constantName) ?: $client->getDefaultConstantName();
        $apiKey = $this->constantValue($constantName, $applicationId);
        if ($apiKey === '') {
            throw new AiUsageException(sprintf(
                'Die Konstante "%s" ist %s nicht gesetzt. Unter Einstellungen → Constants anlegen (Typ Passwort) und den Admin-Key von %s eintragen.',
                $constantName,
                $applicationId > 0 ? 'weder für die gewählte Anwendung noch für den Server' : 'für den Server',
                $client->getLabel()
            ));
        }

        return [$constantName, $apiKey];
    }

    /**
     * The value of a constant: the application's own one when an application is given and
     * has it, the server's otherwise; '' when neither is set.
     */
    public function constantValue(string $constantName, int $applicationId = -1): string
    {
        $constantName = self::normalizeConstantName($constantName);
        if ($constantName === '') {
            return '';
        }
        $value = $applicationId > 0 ? $this->readConstant($constantName, $applicationId) : '';

        return $value !== '' ? $value : $this->readConstant($constantName, -1);
    }

    /** "CONSTANT.FOO", "constant.FOO" and "FOO" all mean the constant FOO. */
    public static function normalizeConstantName(string $name): string
    {
        $name = trim($name);
        if (stripos($name, ConfigurationProvider::KEY_CONSTANTS . '.') === 0) {
            $name = substr($name, strlen(ConfigurationProvider::KEY_CONSTANTS) + 1);
        }

        return preg_match('/^[A-Za-z0-9_.\-]{1,120}$/', $name) === 1 ? $name : '';
    }

    private function readConstant(string $name, int $applicationId): string
    {
        foreach ([ConfigurationProvider::KEY_CONSTANTS, strtolower(ConfigurationProvider::KEY_CONSTANTS)] as $prefix) {
            $value = $this->configurationProvider->getValue($prefix, $name, $applicationId, '');
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
        }

        return '';
    }
}
