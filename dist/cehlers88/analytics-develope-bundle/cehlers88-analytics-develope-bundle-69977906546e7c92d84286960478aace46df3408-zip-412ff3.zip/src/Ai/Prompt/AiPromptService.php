<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Prompt;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageService;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\OpenAiUsageClient;
use Symfony\Contracts\HttpClient\Exception\ExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

/**
 * Sends one prompt to Claude (Messages API) or OpenAI (Chat Completions) and returns the
 * answer - the "KI fragen" dialog of the AI usage tile.
 *
 * Sending needs the regular API key, not the admin key of the usage report: the one in the
 * constant the tile names (in the context of its application, else the server's), and
 * without one the key of the settings group "KI-Unterstützung" (main.ai of the app, which
 * the DB Structure Planner uses as well). The key never leaves the server. Plain HTTP, like
 * the app's AnthropicProvider - no SDK dependency.
 */
final class AiPromptService
{
    public const MAX_PROMPT_LENGTH = 20000;
    public const ANTHROPIC_ENDPOINT = 'https://api.anthropic.com/v1/messages';
    public const OPENAI_ENDPOINT = 'https://api.openai.com/v1/chat/completions';

    public const DEFAULT_ANTHROPIC_MODEL = 'claude-opus-5-5';
    public const DEFAULT_OPENAI_MODEL = 'gpt-5';

    /** The settings group "KI-Unterstützung" of the app (Analytics\Configuration\AiConfigurationGroup). */
    private const APP_AI_GROUP = 'main.ai';

    private const MAX_TOKENS = 8000;
    /** Models on which a declined request is handed to the recommended fallback by the API itself. */
    private const FALLBACK_MODELS = ['claude-fable-5-1', 'claude-opus-5-5', 'claude-opus-5', 'claude-sonnet-5-5'];
    private const FALLBACK_BETA = 'server-side-fallback-2026-07-01';

    public function __construct(
        private readonly HttpClientInterface   $httpClient,
        private readonly AiUsageService        $usageService,
        private readonly ConfigurationProvider $configurationProvider,
    )
    {
    }

    public function defaultConstantName(string $provider): string
    {
        return $provider === OpenAiUsageClient::ID ? 'OPENAI_API_KEY' : 'ANTHROPIC_API_KEY';
    }

    /** The model the dialog suggests: the one of "KI-Unterstützung", else the default. */
    public function defaultModel(string $provider): string
    {
        $openAi = $provider === OpenAiUsageClient::ID;
        $model = trim((string)$this->configurationProvider->getValue(self::APP_AI_GROUP, $openAi ? 'openAiModel' : 'anthropicModel', -1, ''));

        return $model !== '' ? $model : ($openAi ? self::DEFAULT_OPENAI_MODEL : self::DEFAULT_ANTHROPIC_MODEL);
    }

    /**
     * @return array{text: string, model: string, inputTokens: int, outputTokens: int, stopReason: string}
     *
     * @throws AiPromptException
     */
    public function ask(string $provider, string $prompt, string $model, string $constantName, int $applicationId = -1): array
    {
        $prompt = trim($prompt);
        if ($prompt === '') {
            throw new AiPromptException('Bitte einen Prompt eingeben.');
        }
        if (mb_strlen($prompt) > self::MAX_PROMPT_LENGTH) {
            throw new AiPromptException(sprintf('Der Prompt ist zu lang (höchstens %d Zeichen).', self::MAX_PROMPT_LENGTH));
        }
        $model = trim($model) !== '' ? trim($model) : $this->defaultModel($provider);
        if (preg_match('/^[A-Za-z0-9._:\-]{1,100}$/', $model) !== 1) {
            throw new AiPromptException('Das ist keine gültige Modell-Id.');
        }

        $apiKey = $this->apiKey($provider, $constantName, $applicationId);

        return $provider === OpenAiUsageClient::ID
            ? $this->askOpenAi($apiKey, $prompt, $model)
            : $this->askClaude($apiKey, $prompt, $model);
    }

    private function apiKey(string $provider, string $constantName, int $applicationId): string
    {
        $constantName = AiUsageService::normalizeConstantName($constantName) ?: $this->defaultConstantName($provider);
        $apiKey = $this->usageService->constantValue($constantName, $applicationId);
        if ($apiKey === '') {
            $apiKey = trim((string)$this->configurationProvider->getValue(self::APP_AI_GROUP, $provider === OpenAiUsageClient::ID ? 'openAiApiKey' : 'anthropicApiKey', -1, ''));
        }
        if ($apiKey === '') {
            throw new AiPromptException(sprintf(
                'Kein API-Key zum Senden: weder die Konstante "%s" noch die Einstellung „KI-Unterstützung“ hat einen. Der Admin-Key der Verbrauchsanzeige kann keine Anfragen senden.',
                $constantName
            ));
        }
        if (str_starts_with($apiKey, 'sk-ant-admin')) {
            throw new AiPromptException(sprintf('In "%s" steht ein Admin-Key - damit lassen sich keine Anfragen senden. Gebraucht wird ein normaler API-Key (sk-ant-api…).', $constantName));
        }

        return $apiKey;
    }

    /** @return array{text: string, model: string, inputTokens: int, outputTokens: int, stopReason: string} */
    private function askClaude(string $apiKey, string $prompt, string $model): array
    {
        $headers = [
            'x-api-key' => $apiKey,
            'anthropic-version' => '2023-06-01',
            'content-type' => 'application/json',
        ];
        $body = [
            'model' => $model,
            'max_tokens' => self::MAX_TOKENS,
            'messages' => [['role' => 'user', 'content' => $prompt]],
        ];
        if (in_array($model, self::FALLBACK_MODELS, true)) {
            // a declined request is answered by the recommended fallback model instead
            $headers['anthropic-beta'] = self::FALLBACK_BETA;
            $body['fallbacks'] = 'default';
        }

        $answer = $this->post(self::ANTHROPIC_ENDPOINT, $headers, $body, 'Claude');

        $stopReason = (string)($answer['stop_reason'] ?? '');
        $text = '';
        foreach (is_array($answer['content'] ?? null) ? $answer['content'] : [] as $block) {
            if (is_array($block) && ($block['type'] ?? null) === 'text') {
                $text .= (string)($block['text'] ?? '');
            }
        }
        if ($stopReason === 'refusal' && trim($text) === '') {
            throw new AiPromptException('Claude hat die Anfrage abgelehnt.');
        }
        $usage = is_array($answer['usage'] ?? null) ? $answer['usage'] : [];

        return [
            'text' => $text,
            'model' => (string)($answer['model'] ?? $model),
            'inputTokens' => (int)($usage['input_tokens'] ?? 0) + (int)($usage['cache_read_input_tokens'] ?? 0) + (int)($usage['cache_creation_input_tokens'] ?? 0),
            'outputTokens' => (int)($usage['output_tokens'] ?? 0),
            'stopReason' => $stopReason,
        ];
    }

    /** @return array{text: string, model: string, inputTokens: int, outputTokens: int, stopReason: string} */
    private function askOpenAi(string $apiKey, string $prompt, string $model): array
    {
        $answer = $this->post(self::OPENAI_ENDPOINT, [
            'authorization' => 'Bearer ' . $apiKey,
            'content-type' => 'application/json',
        ], [
            'model' => $model,
            'messages' => [['role' => 'user', 'content' => $prompt]],
        ], 'OpenAI');

        $choice = is_array($answer['choices'][0] ?? null) ? $answer['choices'][0] : [];
        $message = is_array($choice['message'] ?? null) ? $choice['message'] : [];
        $refusal = is_string($message['refusal'] ?? null) ? trim($message['refusal']) : '';
        if ($refusal !== '' && trim((string)($message['content'] ?? '')) === '') {
            throw new AiPromptException('OpenAI hat die Anfrage abgelehnt: ' . $refusal);
        }
        $usage = is_array($answer['usage'] ?? null) ? $answer['usage'] : [];

        return [
            'text' => (string)($message['content'] ?? ''),
            'model' => (string)($answer['model'] ?? $model),
            'inputTokens' => (int)($usage['prompt_tokens'] ?? 0),
            'outputTokens' => (int)($usage['completion_tokens'] ?? 0),
            'stopReason' => (string)($choice['finish_reason'] ?? ''),
        ];
    }

    /**
     * @param array<string, string> $headers
     * @param array<string, mixed> $body
     * @return array<string, mixed>
     */
    private function post(string $url, array $headers, array $body, string $label): array
    {
        try {
            $response = $this->httpClient->request('POST', $url, [
                'headers' => $headers,
                'json' => $body,
                'timeout' => 120,
                'max_duration' => 240,
            ]);
            $status = $response->getStatusCode();
            $answer = $response->toArray(false);
        } catch (ExceptionInterface $exception) {
            throw new AiPromptException(sprintf('%s ist nicht erreichbar: %s', $label, $exception->getMessage()), 0, $exception);
        }

        if ($status !== 200) {
            $error = $answer['error'] ?? null;
            $message = is_array($error) ? trim((string)($error['message'] ?? '')) : '';
            throw new AiPromptException(match ($status) {
                401 => sprintf('%s lehnt den API-Key ab (401).', $label),
                429 => sprintf('%s bremst gerade (429) - bitte gleich noch einmal versuchen.', $label),
                default => sprintf('%s antwortet mit Fehler %d%s', $label, $status, $message !== '' ? ': ' . $message : '.'),
            });
        }

        return $answer;
    }
}
