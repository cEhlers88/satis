<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Prompt;

/** A prompt that could not be answered. The message is shown in the dialog as it is. */
final class AiPromptException extends \RuntimeException
{
}
