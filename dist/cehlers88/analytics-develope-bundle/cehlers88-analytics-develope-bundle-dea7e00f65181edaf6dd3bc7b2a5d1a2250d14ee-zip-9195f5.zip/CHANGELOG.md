# Changelog

## [1.1.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.0.2...v1.1.0) (2026-03-29)


### Features

* add default property initialization in `DevelopWorker` constructor ([f597302](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f597302373e09adc12b6c823badcb8d144d8affe))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.3.13 ([#32](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/32)) ([4ff784b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/4ff784be5157bb20f89a8f197d44c47a15cf63f2))
* **deps:** update dependency cehlers88/analytics-core to v1.4.1 ([#34](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/34)) ([5a113ce](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/5a113cecfddb5adf1b61911b42c82c101bea0872))
* **deps:** update dependency cehlers88/analytics-core to v1.6.0 ([#35](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/35)) ([e10e71c](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e10e71c11a00afe882ec2189b326fa060983e54a))

## [1.0.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.0.1...v1.0.2) (2026-03-26)


### Miscellaneous Chores

* remove unnecessary blank line in `DevelopWorker` class definition ([28d1789](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/28d17890f46d38e55e40a031b5726fe41129c24b))

## [1.0.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v1.0.0...v1.0.1) (2026-03-26)


### Miscellaneous Chores

* bump analytics-core to v1.3.11 in composer.lock ([33f3c9a](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/33f3c9adede30c77c027d37caf27eab1b3f18343))
* **deps:** update dependency cehlers88/analytics-core to v1.3.10 ([#30](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/30)) ([cd8d0a0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/cd8d0a05e8a5efab8d9b4a46e5633647c08ce007))
* **deps:** update dependency cehlers88/analytics-core to v1.3.6 ([#28](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/28)) ([ae27042](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/ae2704213e10417053d8eaaaebeb7a6bc660348f))
* enhance DevelopWorker with job handling and buffer repository integration ([258c007](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/258c007fd7153ae9c029efb35f4966b6fc2dedb4))
* Upgraded the analytics-core package to v1.3.7 to include the latest changes and improvements. Updated the associated reference, distribution URL, and checksum to match the new version. ([e4d32f0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e4d32f0af6d5181bf7f1f12b11842e9dd53885ee))

## [1.0.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.6...v1.0.0) (2026-03-23)


### ⚠ BREAKING CHANGES

* remove unused configuration group code in AnalyticsDevelopeBundle

### Features

* remove unused configuration group code in AnalyticsDevelopeBundle ([4c36b17](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/4c36b17472a536594f48b6e551ac830f42a08d6e))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v1.1.3 ([#25](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/25)) ([bcbbee9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/bcbbee91fe16d29397c445a55b520423d3339642))
* **deps:** update dependency cehlers88/analytics-core to v1.3.5 ([#27](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/27)) ([4ec60a9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/4ec60a9218daf1326657b84c540464e24632fe9e))

## [0.2.6](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.5...v0.2.6) (2026-03-22)


### Miscellaneous Chores

* Update analytics-core dependency to ^1.0 in composer.json and lock file ([97744bb](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/97744bbd806fd223df86159c8227786f6d6bac6c))

## [0.2.5](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.4...v0.2.5) (2026-03-22)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.5.3 ([#20](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/20)) ([1e713ee](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1e713eee6b197f58a5c7eff54e03722eafb044eb))
* **deps:** update dependency cehlers88/analytics-core to v0.5.5 ([#22](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/22)) ([1ac609a](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1ac609af5e6b497c090a8f40428ea8c5d54c2a6d))

## [0.2.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.3...v0.2.4) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.5 ([#19](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/19)) ([8aa417d](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/8aa417ddc827e6cbc1d6017006c83fa5805dba30))
* **deps:** update dependency cehlers88/analytics-core to v0.4.2 ([#14](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/14)) ([fa4cfad](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/fa4cfade68493fbae9ed669002814f68d8c088e2))

## [0.2.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.2...v0.2.3) (2026-03-20)


### Miscellaneous Chores

* Update analytics-core dependency to ^0.4 in composer.json ([b6c385b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/b6c385bad2213abaed7a40b400798863c2a73e47))

## [0.2.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.1...v0.2.2) (2026-03-20)


### Miscellaneous Chores

* update analytics-core dependency to dev-main ([be375b8](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/be375b86faa0a260c12871a6aabfa9b7b1fb5421))

## [0.2.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.2.0...v0.2.1) (2026-03-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to ^0.4 ([#13](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/13)) ([893c765](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/893c765b6be12138a2f34bb22c7e3b9012a6bd9e))

## [0.2.0](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.4...v0.2.0) (2026-03-19)


### Features

* add DevelopWorker and update dependency to analytics-core ^1 ([fc6d36b](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/fc6d36b76ceaee8302502b359007009e7a561fdc))


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.3.0 ([#9](https://github.com/cEhlers88/AnalyticsDevelopeBundle/issues/9)) ([e0d383c](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/e0d383c4664e6ce5698bb6c848ffd36621b011d9))
* downgrade analytics-core dependency to ^0.3 ([1e511c7](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/1e511c7bade6d3a74a41cc25c1feb9ecf8c56ade))

## [0.1.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.3...v0.1.4) (2026-01-22)


### Miscellaneous Chores

* Update dependency versions for analytics-core ([f2a8d15](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2a8d154ac14f01f7e39afb22b0a6e6d616217ff))

## [0.1.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.2...v0.1.3) (2026-01-21)


### Miscellaneous Chores

* add GitHub Actions workflow to trigger Satis rebuild on release ([7ba6034](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/7ba60343f9c515be0aee3f6ae55be094a75e66a9))

## [0.1.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([cf67e17](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/cf67e17329ebd56e001bb3102676a4439e6ad844))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([f2aae12](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2aae12077ba3b0790fb23eadd527cd40e4d85c8))

## [0.1.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([c39c6af](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c39c6af44469b9065e75f992998cbce6b579bce4))
