# Changelog

## [0.1.4](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.3...v0.1.4) (2026-01-22)


### Miscellaneous Chores

* Update dependency versions for analytics-core ([f2a8d15](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2a8d154ac14f01f7e39afb22b0a6e6d616217ff))

## [0.1.3](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.2...v0.1.3) (2026-01-21)


### Miscellaneous Chores

* add GitHub Actions workflow to trigger Satis rebuild on release ([7ba6034](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/7ba60343f9c515be0aee3f6ae55be094a75e66a9))

## [0.1.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([cf67e17](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/cf67e17329ebd56e001bb3102676a4439e6ad844))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([f2aae12](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2aae12077ba3b0790fb23eadd527cd40e4d85c8))

## [0.1.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([c39c6af](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c39c6af44469b9065e75f992998cbce6b579bce4))
