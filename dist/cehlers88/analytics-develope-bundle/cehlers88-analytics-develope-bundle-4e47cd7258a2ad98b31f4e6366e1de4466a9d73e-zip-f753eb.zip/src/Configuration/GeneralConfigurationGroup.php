<?php
/**
 * Created by PhpStorm.
 * User: Christoph Ehlers <Webmaster@C-Ehlers.de>
 * Date: 09.05.2024
 * Time: 20:37
 */


namespace Cehlers88\AnalyticsDevelopeBundle\Configuration;

use Cehlers88\AnalyticsCore\Configuration\AbstractConfigurationGroup;
use Cehlers88\AnalyticsCore\Configuration\DTO\ConfigurationItemDTO;
use Cehlers88\AnalyticsCore\CustomObject\CustomObjectProvider;
use Cehlers88\AnalyticsCore\ENUM\eInputType;
use Cehlers88\AnalyticsDevelopeBundle\CustomObject\GitRepository;

class GeneralConfigurationGroup extends AbstractConfigurationGroup
{
    public function __construct(
        private CustomObjectProvider $objectProvider
    )
    {

    }

    public function getItems(): array
    {
        return [
            ConfigurationItemDTO::createRepeat('selfManagingRepositories', 'Zugrundeliegende Repositories', [
                ConfigurationItemDTO::createSelect('type', [
                    ['value' => 1, 'label' => 'Application'],
                    ['value' => 2, 'label' => 'Plugin'],
                ], 'Type'),
                ConfigurationItemDTO::createSelect('repository', $this->getGitRepositoriesAsSelectOptions(), 'Repository'),
            ], 'Here you can define the workspaces for the documents')
        ];
    }

    private function getGitRepositoriesAsSelectOptions(): array
    {
        $t = $this->objectProvider->getCustomEntitiesByClassName(GitRepository::class);
        return array_map(fn($e) => [
            'label' => $e->getName() . ' (' . $e->getRepositoryPath() . ')',
            'value' => $e->getId()
        ], $this->objectProvider->getCustomEntitiesByClassName(GitRepository::class) ?? []);
    }

    public function getGroupTitle(): string
    {
        return 'Allgemeine Entwicklereinstellungen';
    }

    public function getGroupDescription(): string
    {
        return 'Allgemeine Einstellungen für das Entwicklungen';
    }

    public function getKey(): string
    {
        return 'developeBundle.general';
    }
}