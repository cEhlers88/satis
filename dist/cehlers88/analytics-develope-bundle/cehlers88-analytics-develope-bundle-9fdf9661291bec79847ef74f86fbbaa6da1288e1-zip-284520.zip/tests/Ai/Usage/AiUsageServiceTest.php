<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Ai\Usage;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageException;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageService;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AnthropicUsageClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\OpenAiUsageClient;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Cache\Adapter\ArrayAdapter;
use Symfony\Component\HttpClient\MockHttpClient;
use Symfony\Component\HttpClient\Response\MockResponse;

final class AiUsageServiceTest extends TestCase
{
    #[DataProvider('constantNames')]
    public function testConstantNamesAreAcceptedWithOrWithoutPrefix(string $given, string $expected): void
    {
        self::assertSame($expected, AiUsageService::normalizeConstantName($given));
    }

    public static function constantNames(): iterable
    {
        yield 'plain' => ['ANTHROPIC_ADMIN_API_KEY', 'ANTHROPIC_ADMIN_API_KEY'];
        yield 'prefixed' => ['CONSTANT.ANTHROPIC_ADMIN_API_KEY', 'ANTHROPIC_ADMIN_API_KEY'];
        yield 'lower prefix' => [' constant.myKey ', 'myKey'];
        yield 'empty' => ['', ''];
        yield 'not a name' => ['a b; drop', ''];
    }

    public function testAMissingConstantSaysWhereToSetIt(): void
    {
        $service = $this->service(new MockHttpClient(static fn() => throw new \LogicException('no request expected')), []);

        try {
            $service->report(AnthropicUsageClient::ID, '', 0.0);
            self::fail('expected an exception');
        } catch (AiUsageException $exception) {
            self::assertStringContainsString('"ANTHROPIC_ADMIN_API_KEY"', $exception->getMessage());
            self::assertStringContainsString('Constants', $exception->getMessage());
        }
    }

    public function testTheKeyIsReadFromTheConstantAndTheReportIsCached(): void
    {
        $calls = 0;
        $http = new MockHttpClient(function (string $method, string $url, array $options) use (&$calls): MockResponse {
            $calls++;
            self::assertSame(['x-api-key: sk-ant-admin01-secret'], $options['normalized_headers']['x-api-key']);

            return new MockResponse(json_encode(['data' => [], 'has_more' => false]));
        });
        $service = $this->service($http, ['CONSTANT.MY_KEY' => 'sk-ant-admin01-secret']);

        $now = new \DateTimeImmutable('2026-11-06 10:00 UTC');
        $first = $service->report(AnthropicUsageClient::ID, 'CONSTANT.MY_KEY', 50.0, $now);
        $service->report(AnthropicUsageClient::ID, 'MY_KEY', 50.0, $now);

        // usage + cost once, the second report came from the cache
        self::assertSame(2, $calls);
        self::assertSame('MY_KEY', $first['constantName']);
        // no cost buckets came back, so the budget stays unknown instead of untouched
        self::assertFalse($first['budget']['known']);
        self::assertArrayNotHasKey('apiKey', $first);
        self::assertStringNotContainsString('secret', json_encode($first));
    }

    /** @param array<string, string> $store variable name => value */
    private function service(MockHttpClient $http, array $store): AiUsageService
    {
        $configuration = $this->createMock(ConfigurationProvider::class);
        $configuration->method('getValue')->willReturnCallback(
            static fn(string $group, string $item, int $applicationId = -1, mixed $default = null): mixed => $store[$group . '.' . $item] ?? $default
        );

        return new AiUsageService(new AnthropicUsageClient($http), new OpenAiUsageClient($http), $configuration, new ArrayAdapter());
    }
}
