<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Widget;

use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Widget\AbstractWidget;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageException;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageService;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AnthropicUsageClient;

/**
 * AI usage at a glance, like the little desk displays: tokens of today and of the month,
 * the cost, what is left of the monthly budget, a forecast, a bar per day for the last two
 * weeks and the models that used the most.
 *
 * The admin key of the provider is a constant of the settings (/dashboard/settings →
 * Constants); the tile only names which one. Admins only, since it shows what the
 * organization spends.
 */
class AiUsageWidget extends AbstractWidget
{
    public function __construct(
        private readonly AiUsageService $usageService,
    )
    {
    }

    public function getName(): string
    {
        return 'AnalyticsDevelopeBundle.aiUsage';
    }

    public function getTemplateName(): string
    {
        return 'aiUsage';
    }

    public function getRequiredRoles(): array
    {
        return ['ROLE_ADMIN'];
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '10px', 'boxes' => [.4]],
            ['height' => '28px', 'boxes' => [.45, .45]],
            ['height' => '8px', 'boxes' => [.9]],
            ['height' => '40px', 'boxes' => [.95]],
            ['height' => '8px', 'boxes' => [.6]],
        ];
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'provider',
                value: AnthropicUsageClient::ID,
                type: 'string',
                label: 'Anbieter',
                description: 'Wessen Verbrauch gezeigt wird.',
                ui: ['options' => $this->usageService->providerChoices()],
            ),
            PropertyDTO::create(
                name: 'constant',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Konstante mit dem Admin-Key',
                description: 'Name der Konstante aus den Einstellungen (Constants). Leer: ANTHROPIC_ADMIN_API_KEY bzw. OPENAI_ADMIN_API_KEY. Verbrauch und Kosten gibt es nur mit einem Admin-Key (Anthropic: sk-ant-admin…, OpenAI: sk-admin-…).',
            ),
            PropertyDTO::create(
                name: 'monthlyBudget',
                value: 0,
                type: 'float',
                isOptional: true,
                label: 'Monatsbudget (USD)',
                description: 'Daraus wird das restliche Kontingent berechnet - die Anbieter verraten ihr Guthaben nicht über die API. 0 = ohne Budget.',
                ui: ['min' => 0],
            ),
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $provider = (string)($properties['provider'] ?? AnthropicUsageClient::ID);
        $client = $this->usageService->client($provider);
        $budget = is_numeric($properties['monthlyBudget'] ?? null) ? max(0.0, (float)$properties['monthlyBudget']) : 0.0;

        $view = [
            'providerId' => $client->getId(),
            'providerLabel' => $client->getLabel(),
            'report' => null,
            'error' => null,
        ];

        try {
            $view['report'] = $this->usageService->report($client->getId(), (string)($properties['constant'] ?? ''), $budget);
        } catch (AiUsageException $exception) {
            $view['error'] = $exception->getMessage();
        }

        return $view;
    }
}
