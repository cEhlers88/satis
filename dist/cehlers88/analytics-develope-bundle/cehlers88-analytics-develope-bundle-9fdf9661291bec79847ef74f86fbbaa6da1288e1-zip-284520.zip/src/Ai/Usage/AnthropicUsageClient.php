<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

/**
 * Claude through the Usage and Cost Admin API (GET /v1/organizations/usage_report/messages
 * and /v1/organizations/cost_report). Both answer only to an Admin API key (sk-ant-admin...),
 * which an organization in the Claude Console can create - individual accounts have no
 * Admin API. The data lags about five minutes behind.
 *
 * There is no endpoint for the credit that is left: what remains is worked out from the
 * monthly budget of the widget (AiUsageReport).
 */
final class AnthropicUsageClient extends AbstractAiUsageClient
{
    public const ID = 'anthropic';
    public const USAGE_ENDPOINT = 'https://api.anthropic.com/v1/organizations/usage_report/messages';
    public const COST_ENDPOINT = 'https://api.anthropic.com/v1/organizations/cost_report';
    private const API_VERSION = '2023-06-01';
    /** Daily buckets: at most 31 per page. */
    private const DAY_LIMIT = 31;

    public function getId(): string
    {
        return self::ID;
    }

    public function getLabel(): string
    {
        return 'Claude (Anthropic)';
    }

    public function getDefaultConstantName(): string
    {
        return 'ANTHROPIC_ADMIN_API_KEY';
    }

    public function fetchDays(string $apiKey, \DateTimeImmutable $from): array
    {
        if (str_starts_with($apiKey, 'sk-ant-api')) {
            // the key that sends requests is refused by the Admin API - better said up front
            // than as an anonymous 401
            throw new AiUsageException('Das ist ein normaler API-Key (sk-ant-api…). Verbrauch und Kosten gibt Anthropic nur mit einem Admin API Key (sk-ant-admin…) heraus - anzulegen in der Claude Console unter Settings → Admin Keys.');
        }

        $start = $from->setTimezone(new \DateTimeZone('UTC'))->setTime(0, 0)->format('Y-m-d\TH:i:s\Z');
        $days = [];

        $usage = $this->fetchBuckets(self::USAGE_ENDPOINT, [
            'starting_at' => $start,
            'bucket_width' => '1d',
            'group_by' => ['model'],
            'limit' => self::DAY_LIMIT,
        ], $apiKey, 'page', 'next_page');

        foreach ($usage as $bucket) {
            $date = self::dayOf($bucket['starting_at'] ?? null);
            if ($date === null) {
                continue;
            }
            foreach (is_array($bucket['results'] ?? null) ? $bucket['results'] : [] as $result) {
                if (!is_array($result)) {
                    continue;
                }
                $cacheCreation = is_array($result['cache_creation'] ?? null) ? $result['cache_creation'] : [];
                self::addTokens(
                    $days,
                    $date,
                    self::int($result['uncached_input_tokens'] ?? 0),
                    self::int($result['output_tokens'] ?? 0),
                    self::int($result['cache_read_input_tokens'] ?? 0),
                    self::int($cacheCreation['ephemeral_5m_input_tokens'] ?? 0) + self::int($cacheCreation['ephemeral_1h_input_tokens'] ?? 0),
                    is_string($result['model'] ?? null) ? $result['model'] : null,
                );
            }
        }

        $costs = $this->fetchBuckets(self::COST_ENDPOINT, [
            'starting_at' => $start,
            'limit' => self::DAY_LIMIT,
        ], $apiKey, 'page', 'next_page');

        foreach ($costs as $bucket) {
            $date = self::dayOf($bucket['starting_at'] ?? null);
            if ($date === null) {
                continue;
            }
            $cents = 0.0;
            foreach (is_array($bucket['results'] ?? null) ? $bucket['results'] : [] as $result) {
                // USD as a decimal string in cents
                if (is_array($result) && is_numeric($result['amount'] ?? null)) {
                    $cents += (float)$result['amount'];
                }
            }
            self::addCost($days, $date, $cents / 100);
        }

        return self::sortedDays($days);
    }

    protected function headers(string $apiKey): array
    {
        return [
            'x-api-key' => $apiKey,
            'anthropic-version' => self::API_VERSION,
            'user-agent' => 'AnalyticsDevelopeBundle/1.0 (ai usage widget)',
        ];
    }

    protected function explainStatus(int $status, string $apiMessage): string
    {
        return match ($status) {
            401 => 'Anthropic lehnt den Key ab (401). Gebraucht wird ein gültiger Admin API Key (sk-ant-admin…).',
            403 => 'Der Key darf Verbrauch und Kosten nicht lesen (403). Nur ein Admin API Key einer Organisation kommt an diese Berichte - Einzelkonten haben keine Admin API.',
            429 => 'Anthropic bremst die Abfragen gerade (429) - die Kachel versucht es beim nächsten Aktualisieren wieder.',
            default => '',
        };
    }
}
