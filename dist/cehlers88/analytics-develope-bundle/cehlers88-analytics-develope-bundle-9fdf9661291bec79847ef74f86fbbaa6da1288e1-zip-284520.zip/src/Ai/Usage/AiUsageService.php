<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

use Cehlers88\AnalyticsCore\Configuration\ConfigurationProvider;
use Symfony\Contracts\Cache\CacheInterface;
use Symfony\Contracts\Cache\ItemInterface;

/**
 * The usage report of a provider, with the admin key read from a constant of the settings
 * (/dashboard/settings → Constants, stored as CONSTANT.<name>). The key stays on the server;
 * the tile only ever gets the numbers.
 *
 * Reports are cached for a few minutes: the providers refresh them about every five minutes
 * and ask not to be polled more than once a minute, while every tile on every open
 * dashboard renders on its own.
 */
final class AiUsageService
{
    public const CACHE_SECONDS = 300;

    /** @var array<string, AiUsageClientInterface> */
    private array $clients = [];

    public function __construct(
        AnthropicUsageClient                   $anthropic,
        OpenAiUsageClient                      $openAi,
        private readonly ConfigurationProvider $configurationProvider,
        private readonly CacheInterface        $cache,
    )
    {
        foreach ([$anthropic, $openAi] as $client) {
            $this->clients[$client->getId()] = $client;
        }
    }

    /** @return array<string, string> id => label */
    public function providerChoices(): array
    {
        return array_map(static fn(AiUsageClientInterface $client): string => $client->getLabel(), $this->clients);
    }

    public function client(string $provider): AiUsageClientInterface
    {
        return $this->clients[$provider] ?? $this->clients[AnthropicUsageClient::ID];
    }

    /**
     * @return array<string, mixed> the report of AiUsageReport::build(), plus fetchedAt
     *
     * @throws AiUsageException
     */
    public function report(string $provider, string $constantName, float $monthlyBudget, ?\DateTimeImmutable $now = null): array
    {
        $client = $this->client($provider);
        $constantName = self::normalizeConstantName($constantName) ?: $client->getDefaultConstantName();
        $apiKey = $this->readConstant($constantName);
        if ($apiKey === '') {
            throw new AiUsageException(sprintf(
                'Die Konstante "%s" ist nicht gesetzt. Unter Einstellungen → Constants anlegen (Typ Passwort) und den Admin-Key von %s eintragen.',
                $constantName,
                $client->getLabel()
            ));
        }

        $now ??= new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $from = min(
            $now->modify('first day of this month')->setTime(0, 0),
            $now->modify(sprintf('-%d days', AiUsageReport::CHART_DAYS - 1))->setTime(0, 0),
        );

        // the key is part of the cache key only as a hash - a new key fetches anew
        $cacheKey = sprintf('develope_ai_usage_%s_%s_%s', $client->getId(), $from->format('Ymd'), hash('sha256', $apiKey));
        $cached = $this->cache->get($cacheKey, function (ItemInterface $item) use ($client, $apiKey, $from): array {
            $item->expiresAfter(self::CACHE_SECONDS);

            return ['days' => $client->fetchDays($apiKey, $from), 'fetchedAt' => time()];
        });

        return [
            ...AiUsageReport::build($cached['days'], $now, $monthlyBudget),
            'fetchedAt' => $cached['fetchedAt'],
            'constantName' => $constantName,
        ];
    }

    /** "CONSTANT.FOO", "constant.FOO" and "FOO" all mean the constant FOO. */
    public static function normalizeConstantName(string $name): string
    {
        $name = trim($name);
        if (stripos($name, ConfigurationProvider::KEY_CONSTANTS . '.') === 0) {
            $name = substr($name, strlen(ConfigurationProvider::KEY_CONSTANTS) + 1);
        }

        return preg_match('/^[A-Za-z0-9_.\-]{1,120}$/', $name) === 1 ? $name : '';
    }

    private function readConstant(string $name): string
    {
        foreach ([ConfigurationProvider::KEY_CONSTANTS, strtolower(ConfigurationProvider::KEY_CONSTANTS)] as $prefix) {
            $value = $this->configurationProvider->getValue($prefix, $name, -1, '');
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
        }

        return '';
    }
}
