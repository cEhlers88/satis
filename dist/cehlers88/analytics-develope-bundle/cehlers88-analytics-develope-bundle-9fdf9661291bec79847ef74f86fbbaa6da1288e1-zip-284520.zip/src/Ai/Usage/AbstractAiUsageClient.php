<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

use Symfony\Contracts\HttpClient\Exception\ExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

/**
 * The HTTP part both report APIs share: list parameters as name[]=value (the indexed form
 * http_build_query writes is not what either API documents), cursor pages, and errors
 * turned into a message the tile can show.
 */
abstract class AbstractAiUsageClient implements AiUsageClientInterface
{
    /** More pages than a month of daily buckets ever needs - a guard against a cursor loop. */
    private const MAX_PAGES = 10;

    public function __construct(
        protected readonly HttpClientInterface $httpClient,
    )
    {
    }

    /** @return array<string, string> */
    abstract protected function headers(string $apiKey): array;

    /** What to tell about an answer that is not 200, '' for the generic message. */
    abstract protected function explainStatus(int $status, string $apiMessage): string;

    /**
     * All buckets of a report, page after page.
     *
     * @param array<string, scalar|list<scalar>> $query
     * @return list<array<string, mixed>>
     */
    protected function fetchBuckets(string $url, array $query, string $apiKey, string $pageParameter, string $nextPageField): array
    {
        $buckets = [];
        $page = null;

        for ($i = 0; $i < self::MAX_PAGES; $i++) {
            $answer = $this->get($url, $page === null ? $query : [...$query, $pageParameter => $page], $apiKey);

            foreach (is_array($answer['data'] ?? null) ? $answer['data'] : [] as $bucket) {
                if (is_array($bucket)) {
                    $buckets[] = $bucket;
                }
            }

            $page = $answer[$nextPageField] ?? null;
            if (($answer['has_more'] ?? false) !== true || !is_string($page) || $page === '') {
                break;
            }
        }

        return $buckets;
    }

    /** @param array<string, scalar|list<scalar>> $query */
    public static function buildQuery(array $query): string
    {
        $parts = [];
        foreach ($query as $name => $value) {
            foreach (is_array($value) ? $value : [$value] as $each) {
                $parts[] = rawurlencode((string)$name) . (is_array($value) ? '[]' : '') . '=' . rawurlencode(is_bool($each) ? ($each ? 'true' : 'false') : (string)$each);
            }
        }

        return implode('&', $parts);
    }

    /**
     * @param array<string, scalar|list<scalar>> $query
     * @return array<string, mixed>
     */
    private function get(string $url, array $query, string $apiKey): array
    {
        try {
            $response = $this->httpClient->request('GET', $url . '?' . self::buildQuery($query), [
                'headers' => $this->headers($apiKey),
                'timeout' => 20,
                'max_duration' => 30,
            ]);
            $status = $response->getStatusCode();
            $answer = $response->toArray(false);
        } catch (ExceptionInterface $exception) {
            throw new AiUsageException(sprintf('%s ist nicht erreichbar: %s', $this->getLabel(), $exception->getMessage()), 0, $exception);
        }

        if ($status !== 200) {
            $error = $answer['error'] ?? null;
            $apiMessage = is_array($error) ? trim((string)($error['message'] ?? '')) : '';
            $explanation = $this->explainStatus($status, $apiMessage);

            throw new AiUsageException($explanation !== ''
                ? $explanation
                : sprintf('%s antwortet mit Fehler %d%s', $this->getLabel(), $status, $apiMessage !== '' ? ': ' . $apiMessage : '.'));
        }

        return $answer;
    }

    /** A token count as the reports give it - a number, sometimes absent. */
    protected static function int(mixed $value): int
    {
        return is_numeric($value) ? max(0, (int)$value) : 0;
    }

    /**
     * Adds one result to the day it belongs to.
     *
     * @param array<string, array<string, mixed>> $days
     */
    protected static function addTokens(array &$days, string $date, int $input, int $output, int $cacheRead, int $cacheWrite, ?string $model): void
    {
        $days[$date] ??= self::emptyDay($date);
        $days[$date]['input'] += $input;
        $days[$date]['output'] += $output;
        $days[$date]['cacheRead'] += $cacheRead;
        $days[$date]['cacheWrite'] += $cacheWrite;

        $tokens = $input + $output + $cacheRead + $cacheWrite;
        if ($tokens > 0) {
            $model = $model !== null && $model !== '' ? $model : 'unbekannt';
            $days[$date]['models'][$model] = ($days[$date]['models'][$model] ?? 0) + $tokens;
        }
    }

    /** @param array<string, array<string, mixed>> $days */
    protected static function addCost(array &$days, string $date, float $cost): void
    {
        $days[$date] ??= self::emptyDay($date);
        $days[$date]['cost'] = ($days[$date]['cost'] ?? 0.0) + $cost;
    }

    /**
     * @param array<string, array<string, mixed>> $days
     * @return list<array<string, mixed>>
     */
    protected static function sortedDays(array $days): array
    {
        ksort($days);

        return array_values($days);
    }

    /** @return array{date: string, input: int, output: int, cacheRead: int, cacheWrite: int, cost: float|null, models: array<string, int>} */
    private static function emptyDay(string $date): array
    {
        return ['date' => $date, 'input' => 0, 'output' => 0, 'cacheRead' => 0, 'cacheWrite' => 0, 'cost' => null, 'models' => []];
    }

    /** The UTC day a bucket starts on - from an RFC 3339 string or a unix timestamp. */
    protected static function dayOf(mixed $start): ?string
    {
        try {
            $date = match (true) {
                is_int($start) || (is_string($start) && ctype_digit($start)) => new \DateTimeImmutable('@' . $start),
                is_string($start) && $start !== '' => new \DateTimeImmutable($start),
                default => null,
            };
        } catch (\Exception) {
            return null;
        }

        return $date?->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d');
    }
}
