<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Sql;

use Cehlers88\AnalyticsDevelopeBundle\Sql\SqlQueryModel;
use PHPUnit\Framework\TestCase;

class SqlQueryModelTest extends TestCase
{
    private const MODEL = [
        'from' => ['table' => 'user', 'alias' => 'u'],
        'joins' => [[
            'type' => 'left',
            'table' => 'bug_report',
            'alias' => 'b',
            'on' => [['left' => ['alias' => 'b', 'column' => 'reporter_id'], 'right' => ['alias' => 'u', 'column' => 'id']]],
        ]],
        'columns' => [
            ['alias' => 'u', 'column' => 'email', 'as' => ''],
            ['alias' => 'b', 'column' => 'title', 'as' => 'meldung'],
        ],
        'where' => [
            ['alias' => 'b', 'column' => 'state', 'operator' => '=', 'value' => 'new', 'connector' => 'AND'],
            ['alias' => 'u', 'column' => 'id', 'operator' => '>', 'value' => '10', 'connector' => 'AND'],
        ],
        'orderBy' => [['alias' => 'u', 'column' => 'email', 'direction' => 'DESC']],
        'limit' => 50,
        'distinct' => false,
    ];

    public function testAModelBecomesTheStatementItDescribes(): void
    {
        $sql = SqlQueryModel::toSql(self::MODEL);

        $this->assertSame(
            "SELECT `u`.`email`, `b`.`title` AS `meldung`\n"
            . "FROM `user` `u`\n"
            . "LEFT JOIN `bug_report` `b` ON `b`.`reporter_id` = `u`.`id`\n"
            . "WHERE `b`.`state` = 'new'\n"
            . "  AND `u`.`id` > 10\n"
            . "ORDER BY `u`.`email` DESC\n"
            . 'LIMIT 50',
            $sql,
        );
    }

    public function testTheQuoteFollowsThePlatform(): void
    {
        $sql = SqlQueryModel::toSql(['from' => ['table' => 'user', 'alias' => 'u'], 'columns' => []], '"');

        $this->assertSame("SELECT *\nFROM \"user\" \"u\"", $sql);
    }

    public function testAStatementIsReadBackIntoTheModelItCameFrom(): void
    {
        $model = SqlQueryModel::fromSql(SqlQueryModel::toSql(self::MODEL));

        $this->assertNotNull($model);
        $this->assertSame(self::MODEL['from'], $model['from']);
        $this->assertSame(self::MODEL['joins'], $model['joins']);
        $this->assertSame(self::MODEL['columns'], $model['columns']);
        $this->assertSame(self::MODEL['where'], $model['where']);
        $this->assertSame(self::MODEL['orderBy'], $model['orderBy']);
        $this->assertSame(50, $model['limit']);
        $this->assertFalse($model['distinct']);
    }

    public function testAStatementWrittenByHandIsUnderstoodAsWell(): void
    {
        $model = SqlQueryModel::fromSql('select distinct u.email from user as u inner join note n on n.user_id = u.id where u.email like "%@example.test" order by u.email');

        $this->assertNotNull($model);
        $this->assertTrue($model['distinct']);
        $this->assertSame(['table' => 'user', 'alias' => 'u'], $model['from']);
        $this->assertSame('inner', $model['joins'][0]['type']);
        $this->assertSame('note', $model['joins'][0]['table']);
        $this->assertSame('LIKE', $model['where'][0]['operator']);
        $this->assertSame('ASC', $model['orderBy'][0]['direction']);
        $this->assertSame(0, $model['limit']);
    }

    public function testATableWithoutAnAliasIsItsOwnAlias(): void
    {
        $model = SqlQueryModel::fromSql('SELECT * FROM user');

        $this->assertSame(['table' => 'user', 'alias' => 'user'], $model['from']);
        $this->assertSame([], $model['columns'], 'every column');
    }

    public function testWhatTheVisualViewCannotShowIsRefusedInsteadOfHalved(): void
    {
        foreach ([
            'sub-query' => 'SELECT * FROM (SELECT 1) x',
            'union' => 'SELECT id FROM a UNION SELECT id FROM b',
            'group by' => 'SELECT count(*) FROM user GROUP BY id',
            'function' => 'SELECT count(*) FROM user',
            'join without on' => 'SELECT * FROM a CROSS JOIN b',
            'no select' => 'DELETE FROM user',
        ] as $case => $sql) {
            $this->assertNull(SqlQueryModel::fromSql($sql), $case . ' should not become a model');
        }
    }

    public function testNamesFromTheBrowserAreOnlyEverNames(): void
    {
        $sql = SqlQueryModel::toSql([
            'from' => ['table' => 'user; DROP TABLE user', 'alias' => 'u'],
            'columns' => [],
        ]);
        $this->assertSame('', $sql, 'a table that is no name at all is no query');

        $sql = SqlQueryModel::toSql([
            'from' => ['table' => 'user', 'alias' => 'u'],
            'columns' => [['alias' => 'u', 'column' => 'id`, (SELECT 1) AS x', 'as' => '']],
            'where' => [['alias' => 'u', 'column' => 'email', 'operator' => '=', 'value' => "o'brien", 'connector' => 'AND']],
        ]);
        $this->assertStringNotContainsString('SELECT 1', $sql);
        $this->assertStringContainsString("'o''brien'", $sql, 'a value is quoted, whatever is in it');
    }

    public function testAnEmptyModelIsNoStatement(): void
    {
        $this->assertSame('', SqlQueryModel::toSql([]));
        $this->assertSame('', SqlQueryModel::toSql(['from' => ['table' => '', 'alias' => '']]));
    }

    public function testAValueListForIn(): void
    {
        $sql = SqlQueryModel::toSql([
            'from' => ['table' => 'user', 'alias' => 'u'],
            'where' => [['alias' => 'u', 'column' => 'id', 'operator' => 'IN', 'value' => '1, 2, drei', 'connector' => 'AND']],
        ]);

        $this->assertStringContainsString("IN (1, 2, 'drei')", $sql);
    }

    public function testIsNullNeedsNoValue(): void
    {
        $sql = SqlQueryModel::toSql([
            'from' => ['table' => 'user', 'alias' => 'u'],
            'where' => [['alias' => 'u', 'column' => 'deleted_at', 'operator' => 'IS NULL', 'value' => 'x', 'connector' => 'AND']],
        ]);

        $this->assertStringEndsWith('WHERE `u`.`deleted_at` IS NULL', $sql);
    }
}
