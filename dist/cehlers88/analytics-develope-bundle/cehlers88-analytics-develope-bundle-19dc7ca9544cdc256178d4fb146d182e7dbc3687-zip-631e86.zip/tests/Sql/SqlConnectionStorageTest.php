<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Sql;

use Cehlers88\AnalyticsDevelopeBundle\Sql\SqlConnectionStorage;
use Cehlers88\AnalyticsDevelopeBundle\Sql\SqlSecret;
use Cehlers88\AnalyticsDevelopeBundle\Tests\Changelog\ChangelogStorageTest;
use PHPUnit\Framework\TestCase;

class SqlConnectionStorageTest extends TestCase
{
    private string $directory;
    private SqlConnectionStorage $storage;

    protected function setUp(): void
    {
        $this->directory = sys_get_temp_dir() . '/sql-console-test-' . bin2hex(random_bytes(4));
        $this->storage = new SqlConnectionStorage($this->directory, new SqlSecret('das-geheimnis-der-anwendung'));
    }

    protected function tearDown(): void
    {
        ChangelogStorageTest::removeDirectory($this->directory);
    }

    private function mysql(array $fields = []): array
    {
        return [
            'name' => 'Warenwirtschaft',
            'driver' => 'pdo_mysql',
            'host' => 'db.example.test',
            'port' => '',
            'database' => 'wawi',
            'user' => 'leser',
            'password' => 'geheim',
            ...$fields,
        ];
    }

    public function testTheApplicationsOwnConnectionIsAlwaysThereAndOnlyRead(): void
    {
        $connections = $this->storage->describeAll();

        $this->assertSame(SqlConnectionStorage::APPLICATION, $connections[0]['id']);
        $this->assertTrue($connections[0]['application']);
        $this->assertTrue($connections[0]['readOnly']);
        $this->assertTrue($this->storage->isReadOnly(SqlConnectionStorage::APPLICATION));
        $this->assertCount(1, $connections);
    }

    public function testASavedConnectionComesBackWithoutItsPassword(): void
    {
        $saved = $this->storage->save($this->mysql());

        $this->assertMatchesRegularExpression(SqlConnectionStorage::ID, $saved['id']);
        $this->assertArrayNotHasKey('password', $saved, 'a password never leaves the server');
        $this->assertTrue($saved['hasPassword']);
        $this->assertTrue($saved['readOnly'], 'only reading unless it was said otherwise');

        $params = $this->storage->params($saved['id']);
        $this->assertSame('geheim', $params['password']);
        $this->assertSame(3306, $params['port'], 'the port of the driver when none was given');
        $this->assertSame('wawi', $params['dbname']);
    }

    public function testThePasswordIsNotReadableInTheFile(): void
    {
        $saved = $this->storage->save($this->mysql());
        $content = (string)file_get_contents($this->directory . '/connections.json');

        $this->assertStringNotContainsString('geheim', $content);
        $this->assertStringContainsString('enc:v1:', $content);

        $other = new SqlConnectionStorage($this->directory, new SqlSecret('ein-anderes-geheimnis'));
        $this->expectException(\RuntimeException::class);
        $other->params($saved['id']);
    }

    public function testAnEmptyPasswordKeepsTheOneThatIsStored(): void
    {
        $saved = $this->storage->save($this->mysql());
        $changed = $this->storage->save($this->mysql(['id' => $saved['id'], 'name' => 'Warenwirtschaft (Kopie)', 'password' => '']));

        $this->assertSame($saved['id'], $changed['id']);
        $this->assertSame('Warenwirtschaft (Kopie)', $changed['name']);
        $this->assertSame('geheim', $this->storage->params($saved['id'])['password']);
    }

    public function testAFileIsAllASqliteConnectionNeeds(): void
    {
        $saved = $this->storage->save(['name' => 'Archiv', 'driver' => 'pdo_sqlite', 'database' => '/tmp/archiv.sqlite']);

        $this->assertSame(['driver' => 'pdo_sqlite', 'path' => '/tmp/archiv.sqlite'], $this->storage->params($saved['id']));
    }

    public function testWhatIsNotAConnectionIsRefused(): void
    {
        foreach ([
            'kein Typ' => ['name' => 'X', 'driver' => 'pdo_oracle', 'database' => 'x'],
            'kein Name' => ['name' => ' ', 'driver' => 'pdo_mysql', 'database' => 'x'],
            'keine Datenbank' => ['name' => 'X', 'driver' => 'pdo_mysql', 'database' => ''],
            'gibt es nicht' => ['id' => 'aaaaaaaaaaaa', 'name' => 'X', 'driver' => 'pdo_mysql', 'database' => 'x'],
        ] as $case => $input) {
            try {
                $this->storage->save($input);
                $this->fail('accepted: ' . $case);
            } catch (\InvalidArgumentException) {
                $this->assertTrue(true);
            }
        }
    }

    public function testAConnectionThatMayBeWrittenToSaysSo(): void
    {
        $saved = $this->storage->save($this->mysql(['readOnly' => false]));

        $this->assertFalse($saved['readOnly']);
        $this->assertFalse($this->storage->isReadOnly($saved['id']));

        $this->storage->remove($saved['id']);
        $this->assertNull($this->storage->find($saved['id']));
        $this->assertTrue($this->storage->isReadOnly($saved['id']), 'what is not there is never written to');
    }

    public function testAConnectionThatIsOnlyBeingTriedOut(): void
    {
        $params = $this->storage->paramsOf($this->mysql(['host' => '', 'port' => '3307']));

        $this->assertSame('127.0.0.1', $params['host']);
        $this->assertSame(3307, $params['port']);
        $this->assertSame('geheim', $params['password']);
    }
}
