<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Sql;

use Cehlers88\AnalyticsDevelopeBundle\Sql\SqlGuard;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class SqlGuardTest extends TestCase
{
    public static function statements(): array
    {
        return [
            'select' => ['SELECT * FROM user', 'select', true],
            'select in brackets' => ['(SELECT 1)', 'select', true],
            'with' => ["WITH x AS (SELECT 1) SELECT * FROM x", 'with', true],
            'show' => ['SHOW TABLES', 'show', true],
            'explain' => ['EXPLAIN SELECT 1', 'explain', true],
            'comment first' => ["-- was hier steht\nSELECT 1", 'select', true],
            'block comment' => ['/* hallo */ SELECT 1', 'select', true],
            'insert' => ['INSERT INTO user (id) VALUES (1)', 'insert', false],
            'update' => ['  update user set x = 1 ', 'update', false],
            'delete' => ['DELETE FROM user', 'delete', false],
            'drop' => ['DROP TABLE user', 'drop', false],
            'nothing' => ['   ', '', false],
        ];
    }

    #[DataProvider('statements')]
    public function testWhatAStatementIs(string $sql, string $kind, bool $reading): void
    {
        $this->assertSame($kind, SqlGuard::kindOf($sql));
        $this->assertSame($reading, SqlGuard::isReading($sql));
    }

    public function testATrailingSemicolonIsNoSecondStatement(): void
    {
        $this->assertFalse(SqlGuard::hasSeveralStatements('SELECT 1;'));
        $this->assertFalse(SqlGuard::hasSeveralStatements("SELECT ';' FROM user"), 'a semicolon inside a string is text');
        $this->assertFalse(SqlGuard::hasSeveralStatements('SELECT 1; -- und tschüss'));
        $this->assertTrue(SqlGuard::hasSeveralStatements('SELECT 1; DROP TABLE user'));
    }

    public function testReadingAlwaysRunsAndWritingOnlyWhenItWasAskedFor(): void
    {
        $this->assertNull(SqlGuard::refuse('SELECT * FROM user', false, false));

        $this->assertStringContainsString(
            'auf Lesen beschränkt',
            (string)SqlGuard::refuse('DELETE FROM user', false, true),
            'a connection that only reads never writes, whatever the request says',
        );
        $this->assertStringContainsString(
            'Schreiben erlauben',
            (string)SqlGuard::refuse('DELETE FROM user', true, false),
        );
        $this->assertNull(SqlGuard::refuse('DELETE FROM user WHERE id = 1', true, true));
    }

    public function testNeitherNothingNorTwoStatementsAtOnce(): void
    {
        $this->assertStringContainsString('keine Abfrage', (string)SqlGuard::refuse('  ', true, true));
        $this->assertStringContainsString('eine Anweisung', (string)SqlGuard::refuse('SELECT 1; DELETE FROM user', true, true));
    }

    public function testASelectGetsALimitUnlessItBringsItsOwn(): void
    {
        $this->assertSame('SELECT * FROM user LIMIT 50', SqlGuard::withLimit('SELECT * FROM user;', 50));
        $this->assertSame('SELECT * FROM user LIMIT 10', SqlGuard::withLimit('SELECT * FROM user LIMIT 10', 50));
        $this->assertSame('SELECT * FROM user', SqlGuard::withLimit('SELECT * FROM user', 0));
        $this->assertSame('SHOW TABLES', SqlGuard::withLimit('SHOW TABLES', 50), 'only a plain SELECT is limited');
    }
}
