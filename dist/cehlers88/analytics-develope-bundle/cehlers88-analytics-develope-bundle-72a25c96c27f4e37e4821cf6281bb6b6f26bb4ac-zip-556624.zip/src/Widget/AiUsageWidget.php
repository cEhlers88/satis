<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Widget;

use Cehlers88\AnalyticsCore\DTO\PropertyConditionDTO;
use Cehlers88\AnalyticsCore\DTO\PropertyDTO;
use Cehlers88\AnalyticsCore\Widget\AbstractWidget;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageException;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageService;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AnthropicUsageClient;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\OpenAiUsageClient;

/**
 * AI usage at a glance, like the little desk displays: tokens of today and of the month,
 * the cost, what is left of the monthly budget, a forecast, a bar per day for the last two
 * weeks and the models that used the most. For Claude also, if switched on, what Claude Code
 * did in the last seven days (sessions, lines, commits, PRs, accepted edits, the people who
 * used it most) and the status page of Anthropic as a traffic light.
 *
 * The admin key of the provider is a constant of the settings (/dashboard/settings →
 * Constants); the tile only names which one. Admins only, since it shows what the
 * organization spends.
 */
class AiUsageWidget extends AbstractWidget
{
    public function __construct(
        private readonly AiUsageService $usageService,
    )
    {
    }

    public function getName(): string
    {
        return 'AnalyticsDevelopeBundle.aiUsage';
    }

    public function getTemplateName(): string
    {
        return 'aiUsage';
    }

    public function getRequiredRoles(): array
    {
        return ['ROLE_ADMIN'];
    }

    public function getPreloadPlaceholders(): array
    {
        return [
            ['height' => '10px', 'boxes' => [.4]],
            ['height' => '28px', 'boxes' => [.45, .45]],
            ['height' => '8px', 'boxes' => [.9]],
            ['height' => '40px', 'boxes' => [.95]],
            ['height' => '8px', 'boxes' => [.6]],
        ];
    }

    public function getSettingDefinitions(): array
    {
        return [
            PropertyDTO::create(
                name: 'provider',
                value: AnthropicUsageClient::ID,
                type: 'string',
                label: 'Anbieter',
                description: 'Wessen Verbrauch gezeigt wird.',
                ui: ['options' => $this->usageService->providerChoices()],
            ),
            PropertyDTO::create(
                name: 'constant',
                value: '',
                type: 'string',
                isOptional: true,
                label: 'Konstante mit dem Admin-Key',
                description: 'Name der Konstante aus den Einstellungen (Constants). Leer: ANTHROPIC_ADMIN_API_KEY bzw. OPENAI_ADMIN_API_KEY. Verbrauch und Kosten gibt es nur mit einem Admin-Key (Anthropic: sk-ant-admin…, OpenAI: sk-admin-…).',
            ),
            PropertyDTO::create(
                name: 'monthlyBudget',
                value: 0,
                type: 'float',
                isOptional: true,
                label: 'Monatsbudget (USD)',
                description: 'Daraus wird das restliche Kontingent berechnet - die Anbieter verraten ihr Guthaben nicht über die API. 0 = ohne Budget.',
                ui: ['min' => 0],
            ),
            PropertyDTO::create(
                name: 'showClaudeCode',
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Claude-Code-Statistik zeigen',
                description: 'Sitzungen, Zeilen, Commits und PRs von Claude Code der letzten 7 Tage - mit demselben Admin-Key. Nur Claude Code über die API, nicht über ein Pro/Max-Abo.',
                conditions: [
                    PropertyConditionDTO::when('provider', OpenAiUsageClient::ID)->then([
                        PropertyConditionDTO::EFFECT_VISIBLE => false,
                    ]),
                ],
            ),
            PropertyDTO::create(
                name: 'showStatus',
                value: true,
                type: 'bool',
                isOptional: true,
                label: 'Status von Anthropic zeigen',
                description: 'Ampel nach status.claude.com: Störungen und offene Vorfälle.',
                conditions: [
                    PropertyConditionDTO::when('provider', OpenAiUsageClient::ID)->then([
                        PropertyConditionDTO::EFFECT_VISIBLE => false,
                    ]),
                ],
            ),
        ];
    }

    public function enrichProperties(array $properties): array
    {
        $provider = (string)($properties['provider'] ?? AnthropicUsageClient::ID);
        $client = $this->usageService->client($provider);
        $budget = is_numeric($properties['monthlyBudget'] ?? null) ? max(0.0, (float)$properties['monthlyBudget']) : 0.0;

        $view = [
            'providerId' => $client->getId(),
            'providerLabel' => $client->getLabel(),
            'report' => null,
            'error' => null,
            'claudeCode' => null,
            'claudeCodeError' => null,
            'status' => null,
        ];

        try {
            $view['report'] = $this->usageService->report($client->getId(), (string)($properties['constant'] ?? ''), $budget);
        } catch (AiUsageException $exception) {
            $view['error'] = $exception->getMessage();
        }

        if ($client->getId() !== AnthropicUsageClient::ID) {
            return $view;
        }

        // each part fails on its own - an unreachable status page must not hide the usage
        if (self::isOn($properties['showClaudeCode'] ?? true)) {
            try {
                $view['claudeCode'] = $this->usageService->claudeCode((string)($properties['constant'] ?? ''));
            } catch (AiUsageException $exception) {
                // the usage part already says what is wrong with the key
                $view['claudeCodeError'] = $view['error'] === null ? $exception->getMessage() : null;
            }
        }
        if (self::isOn($properties['showStatus'] ?? true)) {
            try {
                $view['status'] = $this->usageService->status();
            } catch (AiUsageException) {
                $view['status'] = ['light' => 'unknown', 'description' => 'Status nicht abrufbar', 'url' => 'https://status.claude.com', 'components' => [], 'incidents' => []];
            }
        }

        return $view;
    }

    /** A switch as the mask stores it: true, 1, "1", "true" or "on". */
    private static function isOn(mixed $value): bool
    {
        return in_array(is_string($value) ? strtolower($value) : $value, [true, 1, '1', 'true', 'on'], true);
    }
}
