<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

/**
 * What the usage clients share on top of the HTTP part: summing the results of a report
 * up per UTC day.
 */
abstract class AbstractAiUsageClient extends AbstractAdminReportClient implements AiUsageClientInterface
{
    /**
     * Adds one result to the day it belongs to.
     *
     * @param array<string, array<string, mixed>> $days
     */
    protected static function addTokens(array &$days, string $date, int $input, int $output, int $cacheRead, int $cacheWrite, ?string $model): void
    {
        $days[$date] ??= self::emptyDay($date);
        $days[$date]['input'] += $input;
        $days[$date]['output'] += $output;
        $days[$date]['cacheRead'] += $cacheRead;
        $days[$date]['cacheWrite'] += $cacheWrite;

        $tokens = $input + $output + $cacheRead + $cacheWrite;
        if ($tokens > 0) {
            $model = $model !== null && $model !== '' ? $model : 'unbekannt';
            $days[$date]['models'][$model] = ($days[$date]['models'][$model] ?? 0) + $tokens;
        }
    }

    /** @param array<string, array<string, mixed>> $days */
    protected static function addCost(array &$days, string $date, float $cost): void
    {
        $days[$date] ??= self::emptyDay($date);
        $days[$date]['cost'] = ($days[$date]['cost'] ?? 0.0) + $cost;
    }

    /**
     * @param array<string, array<string, mixed>> $days
     * @return list<array<string, mixed>>
     */
    protected static function sortedDays(array $days): array
    {
        ksort($days);

        return array_values($days);
    }

    /** @return array{date: string, input: int, output: int, cacheRead: int, cacheWrite: int, cost: float|null, models: array<string, int>} */
    private static function emptyDay(string $date): array
    {
        return ['date' => $date, 'input' => 0, 'output' => 0, 'cacheRead' => 0, 'cacheWrite' => 0, 'cost' => null, 'models' => []];
    }

    /** The UTC day a bucket starts on - from an RFC 3339 string or a unix timestamp. */
    protected static function dayOf(mixed $start): ?string
    {
        try {
            $date = match (true) {
                is_int($start) || (is_string($start) && ctype_digit($start)) => new \DateTimeImmutable('@' . $start),
                is_string($start) && $start !== '' => new \DateTimeImmutable($start),
                default => null,
            };
        } catch (\Exception) {
            return null;
        }

        return $date?->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d');
    }
}
