<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

/**
 * Claude Code through the Claude Code Analytics Admin API
 * (GET /v1/organizations/usage_report/claude_code): per day and person sessions, lines of
 * code, commits, pull requests, accepted/rejected edits and the estimated cost per model.
 *
 * Takes the same Admin API key as the usage report. It answers one UTC day per request,
 * lags about an hour behind, and covers Claude Code on the Claude API only - usage through
 * a Pro/Max/Team subscription on claude.ai is not in it.
 */
final class ClaudeCodeAnalyticsClient extends AbstractAdminReportClient
{
    use AnthropicAdminAuth;

    public const ENDPOINT = 'https://api.anthropic.com/v1/organizations/usage_report/claude_code';
    private const PAGE_LIMIT = 1000;

    public function getLabel(): string
    {
        return 'Claude Code';
    }

    /**
     * The records of one UTC day - one per actor and terminal/customer combination.
     *
     * @return list<array<string, mixed>>
     *
     * @throws AiUsageException
     */
    public function fetchDay(string $apiKey, \DateTimeImmutable $day): array
    {
        self::assertAdminKey($apiKey);

        return $this->fetchBuckets(self::ENDPOINT, [
            'starting_at' => $day->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d'),
            'limit' => self::PAGE_LIMIT,
        ], $apiKey, 'page', 'next_page');
    }
}
