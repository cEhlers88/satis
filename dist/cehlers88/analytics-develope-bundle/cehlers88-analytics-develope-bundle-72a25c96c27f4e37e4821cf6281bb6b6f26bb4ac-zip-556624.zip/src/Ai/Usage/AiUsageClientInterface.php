<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

/**
 * Reads what an AI provider reports about the token usage and the cost of the organization
 * the key belongs to - one entry per UTC day.
 *
 * Both providers only give these numbers to an organization admin key, not to the key that
 * sends requests: an Anthropic Admin API key (sk-ant-admin...), an OpenAI admin key
 * (sk-admin-...).
 */
interface AiUsageClientInterface
{
    public function getId(): string;

    public function getLabel(): string;

    /** The constant the widget reads the key from unless its setting names another. */
    public function getDefaultConstantName(): string;

    /**
     * The days from $from (00:00 UTC) up to today, oldest first. A day without usage may be
     * missing.
     *
     * @return list<array{date: string, input: int, output: int, cacheRead: int, cacheWrite: int, cost: float|null, models: array<string, int>}>
     *
     * @throws AiUsageException
     */
    public function fetchDays(string $apiKey, \DateTimeImmutable $from): array;
}
