<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

/**
 * Turns the days a client fetched into what the tile shows: today, the month so far (both
 * in UTC, as the providers bill), the remaining budget, a forecast for the month, a bar per
 * day and the models that used the most.
 *
 * "Remaining" is budget minus the cost of the month: neither provider tells the credit that
 * is left through its API, so the budget is the widget's own setting.
 */
final class AiUsageReport
{
    public const CHART_DAYS = 14;
    private const TOP_MODELS = 3;

    /**
     * @param list<array{date: string, input: int, output: int, cacheRead: int, cacheWrite: int, cost: float|null, models: array<string, int>}> $days
     * @return array<string, mixed>
     */
    public static function build(array $days, \DateTimeImmutable $now, float $monthlyBudget = 0.0): array
    {
        $now = $now->setTimezone(new \DateTimeZone('UTC'));
        $today = $now->format('Y-m-d');
        $monthPrefix = $now->format('Y-m-');

        $byDate = [];
        foreach ($days as $day) {
            $byDate[$day['date']] = $day;
        }

        $todayTotals = self::totals(isset($byDate[$today]) ? [$byDate[$today]] : []);
        $monthDays = array_values(array_filter($days, static fn(array $day): bool => str_starts_with($day['date'], $monthPrefix) && $day['date'] <= $today));
        $monthTotals = self::totals($monthDays);

        $chart = [];
        $chartMax = 0;
        for ($i = self::CHART_DAYS - 1; $i >= 0; $i--) {
            $date = $now->modify(sprintf('-%d days', $i))->format('Y-m-d');
            $tokens = isset($byDate[$date]) ? self::tokensOf($byDate[$date]) : 0;
            $chartMax = max($chartMax, $tokens);
            $chart[] = [
                'date' => $date,
                'weekday' => (int)(new \DateTimeImmutable($date))->format('N'),
                'tokens' => $tokens,
                'cost' => $byDate[$date]['cost'] ?? null,
                'isToday' => $date === $today,
            ];
        }
        foreach ($chart as &$bar) {
            $bar['ratio'] = $chartMax > 0 ? round($bar['tokens'] / $chartMax, 4) : 0.0;
        }
        unset($bar);

        $models = [];
        foreach ($monthDays as $day) {
            foreach ($day['models'] as $model => $tokens) {
                $models[$model] = ($models[$model] ?? 0) + $tokens;
            }
        }
        arsort($models);
        $topModels = [];
        foreach (array_slice($models, 0, self::TOP_MODELS, true) as $model => $tokens) {
            $topModels[] = [
                'model' => (string)$model,
                'tokens' => $tokens,
                'share' => $monthTotals['tokens'] > 0 ? round($tokens / $monthTotals['tokens'], 4) : 0.0,
            ];
        }

        $dayOfMonth = (int)$now->format('j');
        $daysInMonth = (int)$now->format('t');
        $monthCost = $monthTotals['cost'];
        $forecast = $monthCost !== null && $dayOfMonth > 0 ? round($monthCost / $dayOfMonth * $daysInMonth, 2) : null;

        $budget = null;
        if ($monthlyBudget > 0 && $monthCost === null) {
            // without cost data nothing is known about the budget - 0 spent would be a lie
            $budget = [
                'amount' => round($monthlyBudget, 2),
                'known' => false,
                'spent' => null,
                'remaining' => null,
                'usedRatio' => null,
                'exceeded' => false,
                'forecastExceeds' => false,
            ];
        } elseif ($monthlyBudget > 0) {
            $spent = $monthCost;
            $budget = [
                'amount' => round($monthlyBudget, 2),
                'known' => true,
                'spent' => round($spent, 2),
                'remaining' => round(max(0.0, $monthlyBudget - $spent), 2),
                'usedRatio' => round(min(1.0, $spent / $monthlyBudget), 4),
                'exceeded' => $spent > $monthlyBudget,
                // the forecast already above the budget is the warning worth having early
                'forecastExceeds' => $forecast !== null && $forecast > $monthlyBudget,
            ];
        }

        return [
            'today' => $todayTotals,
            'month' => $monthTotals,
            'monthLabel' => $now->format('m/Y'),
            'forecast' => $forecast,
            'budget' => $budget,
            'chart' => $chart,
            'topModels' => $topModels,
            'costKnown' => $monthCost !== null || $todayTotals['cost'] !== null,
        ];
    }

    /**
     * @param list<array<string, mixed>> $days
     * @return array{input: int, output: int, cacheRead: int, cacheWrite: int, tokens: int, cost: float|null}
     */
    private static function totals(array $days): array
    {
        $totals = ['input' => 0, 'output' => 0, 'cacheRead' => 0, 'cacheWrite' => 0, 'tokens' => 0, 'cost' => null];
        foreach ($days as $day) {
            $totals['input'] += $day['input'];
            $totals['output'] += $day['output'];
            $totals['cacheRead'] += $day['cacheRead'];
            $totals['cacheWrite'] += $day['cacheWrite'];
            $totals['tokens'] += self::tokensOf($day);
            if ($day['cost'] !== null) {
                $totals['cost'] = ($totals['cost'] ?? 0.0) + $day['cost'];
            }
        }
        if ($totals['cost'] !== null) {
            $totals['cost'] = round($totals['cost'], 2);
        }

        return $totals;
    }

    /** @param array<string, mixed> $day */
    private static function tokensOf(array $day): int
    {
        return $day['input'] + $day['output'] + $day['cacheRead'] + $day['cacheWrite'];
    }
}
