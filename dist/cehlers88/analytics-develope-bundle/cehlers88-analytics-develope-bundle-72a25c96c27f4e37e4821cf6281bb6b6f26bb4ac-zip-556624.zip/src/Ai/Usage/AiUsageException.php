<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

/**
 * A usage report that could not be fetched. The message is shown on the tile as it is,
 * so it says what to do about it - and never contains the key.
 */
final class AiUsageException extends \RuntimeException
{
}
