<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

/**
 * How the Anthropic Admin API is spoken to - shared by the usage/cost reports and the
 * Claude Code analytics, which take the same Admin API key.
 */
trait AnthropicAdminAuth
{
    /**
     * The key that sends requests is refused by the Admin API - better said up front than
     * as an anonymous 401.
     */
    private static function assertAdminKey(string $apiKey): void
    {
        if (str_starts_with($apiKey, 'sk-ant-api')) {
            throw new AiUsageException('Das ist ein normaler API-Key (sk-ant-api…). Verbrauch, Kosten und Claude-Code-Statistik gibt Anthropic nur mit einem Admin API Key (sk-ant-admin…) heraus - anzulegen in der Claude Console unter Settings → Admin Keys.');
        }
    }

    /** @return array<string, string> */
    protected function headers(string $apiKey): array
    {
        return [
            'x-api-key' => $apiKey,
            'anthropic-version' => '2023-06-01',
            'user-agent' => 'AnalyticsDevelopeBundle/1.0 (ai usage widget)',
        ];
    }

    protected function explainStatus(int $status, string $apiMessage): string
    {
        return match ($status) {
            401 => 'Anthropic lehnt den Key ab (401). Gebraucht wird ein gültiger Admin API Key (sk-ant-admin…).',
            403 => 'Der Key darf diese Berichte nicht lesen (403). Nur ein Admin API Key einer Organisation kommt an sie heran - Einzelkonten haben keine Admin API.',
            429 => 'Anthropic bremst die Abfragen gerade (429) - die Kachel versucht es beim nächsten Aktualisieren wieder.',
            default => '',
        };
    }
}
