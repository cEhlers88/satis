<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

/**
 * Sums the Claude Code analytics records of some days up: for the whole period and for
 * today, plus the people (or API keys) who used it most. An actor appears in several
 * records a day - one per terminal, customer type and remote flag - and is summed up.
 */
final class ClaudeCodeReport
{
    public const DAYS = 7;
    private const TOP_ACTORS = 3;
    private const EDIT_TOOLS = ['edit_tool', 'multi_edit_tool', 'write_tool', 'notebook_edit_tool'];

    /**
     * @param array<string, list<array<string, mixed>>> $recordsByDate Y-m-d => records of that day
     * @return array<string, mixed>
     */
    public static function build(array $recordsByDate, \DateTimeImmutable $now): array
    {
        $today = $now->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d');
        $all = [];
        foreach ($recordsByDate as $records) {
            array_push($all, ...$records);
        }

        $actors = [];
        foreach ($all as $record) {
            $name = self::actorName($record['actor'] ?? null);
            $actors[$name] ??= ['name' => $name, 'sessions' => 0, 'linesAdded' => 0, 'cost' => 0.0];
            $metrics = self::metricsOf([$record]);
            $actors[$name]['sessions'] += $metrics['sessions'];
            $actors[$name]['linesAdded'] += $metrics['linesAdded'];
            $actors[$name]['cost'] += $metrics['cost'];
        }
        usort($actors, static fn(array $a, array $b): int => [$b['cost'], $b['sessions']] <=> [$a['cost'], $a['sessions']]);
        foreach ($actors as &$actor) {
            $actor['cost'] = round($actor['cost'], 2);
        }
        unset($actor);

        return [
            'days' => self::DAYS,
            'period' => self::metricsOf($all),
            'today' => self::metricsOf($recordsByDate[$today] ?? []),
            'topActors' => array_slice($actors, 0, self::TOP_ACTORS),
            'actorCount' => count($actors),
        ];
    }

    /**
     * @param list<array<string, mixed>> $records
     * @return array{sessions: int, linesAdded: int, linesRemoved: int, commits: int, pullRequests: int, accepted: int, rejected: int, acceptanceRate: float|null, tokens: int, cost: float}
     */
    private static function metricsOf(array $records): array
    {
        $metrics = ['sessions' => 0, 'linesAdded' => 0, 'linesRemoved' => 0, 'commits' => 0, 'pullRequests' => 0, 'accepted' => 0, 'rejected' => 0, 'acceptanceRate' => null, 'tokens' => 0, 'cost' => 0.0];

        foreach ($records as $record) {
            $core = self::arr($record['core_metrics'] ?? null);
            $lines = self::arr($core['lines_of_code'] ?? null);
            $metrics['sessions'] += self::int($core['num_sessions'] ?? 0);
            $metrics['linesAdded'] += self::int($lines['added'] ?? 0);
            $metrics['linesRemoved'] += self::int($lines['removed'] ?? 0);
            $metrics['commits'] += self::int($core['commits_by_claude_code'] ?? 0);
            $metrics['pullRequests'] += self::int($core['pull_requests_by_claude_code'] ?? 0);

            $tools = self::arr($record['tool_actions'] ?? null);
            foreach (self::EDIT_TOOLS as $tool) {
                $actions = self::arr($tools[$tool] ?? null);
                $metrics['accepted'] += self::int($actions['accepted'] ?? 0);
                $metrics['rejected'] += self::int($actions['rejected'] ?? 0);
            }

            foreach (is_array($record['model_breakdown'] ?? null) ? $record['model_breakdown'] : [] as $model) {
                $model = self::arr($model);
                $tokens = self::arr($model['tokens'] ?? null);
                $metrics['tokens'] += self::int($tokens['input'] ?? 0) + self::int($tokens['output'] ?? 0)
                    + self::int($tokens['cache_read'] ?? 0) + self::int($tokens['cache_creation'] ?? 0);
                $cost = self::arr($model['estimated_cost'] ?? null);
                // estimated cost in cents USD
                if (is_numeric($cost['amount'] ?? null)) {
                    $metrics['cost'] += (float)$cost['amount'] / 100;
                }
            }
        }

        $decided = $metrics['accepted'] + $metrics['rejected'];
        $metrics['acceptanceRate'] = $decided > 0 ? round($metrics['accepted'] / $decided, 4) : null;
        $metrics['cost'] = round($metrics['cost'], 2);

        return $metrics;
    }

    /** Who a record belongs to: the e-mail address of a person, the name of an API key. */
    private static function actorName(mixed $actor): string
    {
        $actor = self::arr($actor);
        foreach (['email_address', 'api_key_name'] as $field) {
            if (is_string($actor[$field] ?? null) && trim($actor[$field]) !== '') {
                return trim($actor[$field]);
            }
        }

        return 'unbekannt';
    }

    /** @return array<mixed> */
    private static function arr(mixed $value): array
    {
        return is_array($value) ? $value : [];
    }

    private static function int(mixed $value): int
    {
        return is_numeric($value) ? max(0, (int)$value) : 0;
    }
}
