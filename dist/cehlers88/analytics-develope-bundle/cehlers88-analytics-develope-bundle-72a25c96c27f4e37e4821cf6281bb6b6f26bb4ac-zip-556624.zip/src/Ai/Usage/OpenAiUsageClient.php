<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

/**
 * OpenAI through its organization Usage and Costs API (GET /v1/organization/usage/completions
 * and /v1/organization/costs), which answers only to an admin key (sk-admin-...).
 *
 * Unlike Anthropic, OpenAI counts the cached input inside input_tokens - it is taken out
 * here, so "input" means the same uncached input for both providers.
 */
final class OpenAiUsageClient extends AbstractAiUsageClient
{
    public const ID = 'openai';
    public const USAGE_ENDPOINT = 'https://api.openai.com/v1/organization/usage/completions';
    public const COST_ENDPOINT = 'https://api.openai.com/v1/organization/costs';
    private const DAY_LIMIT = 31;

    public function getId(): string
    {
        return self::ID;
    }

    public function getLabel(): string
    {
        return 'OpenAI';
    }

    public function getDefaultConstantName(): string
    {
        return 'OPENAI_ADMIN_API_KEY';
    }

    public function fetchDays(string $apiKey, \DateTimeImmutable $from): array
    {
        $start = $from->setTimezone(new \DateTimeZone('UTC'))->setTime(0, 0)->getTimestamp();
        $days = [];

        $usage = $this->fetchBuckets(self::USAGE_ENDPOINT, [
            'start_time' => $start,
            'bucket_width' => '1d',
            'group_by' => ['model'],
            'limit' => self::DAY_LIMIT,
        ], $apiKey, 'page', 'next_page');

        foreach ($usage as $bucket) {
            $date = self::dayOf($bucket['start_time'] ?? null);
            if ($date === null) {
                continue;
            }
            foreach (is_array($bucket['results'] ?? null) ? $bucket['results'] : [] as $result) {
                if (!is_array($result)) {
                    continue;
                }
                $cached = self::int($result['input_cached_tokens'] ?? 0);
                self::addTokens(
                    $days,
                    $date,
                    max(0, self::int($result['input_tokens'] ?? 0) - $cached),
                    self::int($result['output_tokens'] ?? 0),
                    $cached,
                    0,
                    is_string($result['model'] ?? null) ? $result['model'] : null,
                );
            }
        }

        $costs = $this->fetchBuckets(self::COST_ENDPOINT, [
            'start_time' => $start,
            'bucket_width' => '1d',
            'limit' => self::DAY_LIMIT,
        ], $apiKey, 'page', 'next_page');

        foreach ($costs as $bucket) {
            $date = self::dayOf($bucket['start_time'] ?? null);
            if ($date === null) {
                continue;
            }
            $dollars = 0.0;
            foreach (is_array($bucket['results'] ?? null) ? $bucket['results'] : [] as $result) {
                $amount = is_array($result) && is_array($result['amount'] ?? null) ? $result['amount'] : [];
                if (is_numeric($amount['value'] ?? null)) {
                    $dollars += (float)$amount['value'];
                }
            }
            self::addCost($days, $date, $dollars);
        }

        return self::sortedDays($days);
    }

    protected function headers(string $apiKey): array
    {
        return [
            'authorization' => 'Bearer ' . $apiKey,
            'user-agent' => 'AnalyticsDevelopeBundle/1.0 (ai usage widget)',
        ];
    }

    protected function explainStatus(int $status, string $apiMessage): string
    {
        return match ($status) {
            401, 403 => sprintf('OpenAI lässt den Key nicht an die Verbrauchsdaten (%d). Gebraucht wird ein Admin Key (sk-admin-…) der Organisation.', $status),
            429 => 'OpenAI bremst die Abfragen gerade (429) - die Kachel versucht es beim nächsten Aktualisieren wieder.',
            default => '',
        };
    }
}
