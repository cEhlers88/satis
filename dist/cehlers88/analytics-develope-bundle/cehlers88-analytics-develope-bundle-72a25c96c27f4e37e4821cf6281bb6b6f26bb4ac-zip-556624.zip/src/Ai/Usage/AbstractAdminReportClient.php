<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

use Symfony\Contracts\HttpClient\Exception\ExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

/**
 * The HTTP part the admin report APIs share: list parameters as name[]=value (the indexed
 * form http_build_query writes is not what the APIs document), cursor pages, and errors
 * turned into a message the tile can show.
 */
abstract class AbstractAdminReportClient
{
    /** More pages than a month of daily buckets ever needs - a guard against a cursor loop. */
    private const MAX_PAGES = 10;

    public function __construct(
        protected readonly HttpClientInterface $httpClient,
    )
    {
    }

    abstract public function getLabel(): string;

    /** @return array<string, string> */
    abstract protected function headers(string $apiKey): array;

    /** What to tell about an answer that is not 200, '' for the generic message. */
    abstract protected function explainStatus(int $status, string $apiMessage): string;

    /**
     * All buckets of a report, page after page.
     *
     * @param array<string, scalar|list<scalar>> $query
     * @return list<array<string, mixed>>
     */
    protected function fetchBuckets(string $url, array $query, string $apiKey, string $pageParameter, string $nextPageField): array
    {
        $buckets = [];
        $page = null;

        for ($i = 0; $i < self::MAX_PAGES; $i++) {
            $answer = $this->get($url, $page === null ? $query : [...$query, $pageParameter => $page], $apiKey);

            foreach (is_array($answer['data'] ?? null) ? $answer['data'] : [] as $bucket) {
                if (is_array($bucket)) {
                    $buckets[] = $bucket;
                }
            }

            $page = $answer[$nextPageField] ?? null;
            if (($answer['has_more'] ?? false) !== true || !is_string($page) || $page === '') {
                break;
            }
        }

        return $buckets;
    }

    /** @param array<string, scalar|list<scalar>> $query */
    public static function buildQuery(array $query): string
    {
        $parts = [];
        foreach ($query as $name => $value) {
            foreach (is_array($value) ? $value : [$value] as $each) {
                $parts[] = rawurlencode((string)$name) . (is_array($value) ? '[]' : '') . '=' . rawurlencode(is_bool($each) ? ($each ? 'true' : 'false') : (string)$each);
            }
        }

        return implode('&', $parts);
    }

    /**
     * @param array<string, scalar|list<scalar>> $query
     * @return array<string, mixed>
     */
    private function get(string $url, array $query, string $apiKey): array
    {
        try {
            $response = $this->httpClient->request('GET', $url . '?' . self::buildQuery($query), [
                'headers' => $this->headers($apiKey),
                'timeout' => 20,
                'max_duration' => 30,
            ]);
            $status = $response->getStatusCode();
            $answer = $response->toArray(false);
        } catch (ExceptionInterface $exception) {
            throw new AiUsageException(sprintf('%s ist nicht erreichbar: %s', $this->getLabel(), $exception->getMessage()), 0, $exception);
        }

        if ($status !== 200) {
            $error = $answer['error'] ?? null;
            $apiMessage = is_array($error) ? trim((string)($error['message'] ?? '')) : '';
            $explanation = $this->explainStatus($status, $apiMessage);

            throw new AiUsageException($explanation !== ''
                ? $explanation
                : sprintf('%s antwortet mit Fehler %d%s', $this->getLabel(), $status, $apiMessage !== '' ? ': ' . $apiMessage : '.'));
        }

        return $answer;
    }

    /** A token count as the reports give it - a number, sometimes absent. */
    protected static function int(mixed $value): int
    {
        return is_numeric($value) ? max(0, (int)$value) : 0;
    }
}
