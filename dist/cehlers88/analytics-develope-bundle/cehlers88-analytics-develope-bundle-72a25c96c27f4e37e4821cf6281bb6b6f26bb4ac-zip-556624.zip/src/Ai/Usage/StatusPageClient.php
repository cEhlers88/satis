<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Ai\Usage;

use Symfony\Contracts\HttpClient\Exception\ExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

/**
 * The public status page of Anthropic (status.claude.com, an Atlassian Statuspage): the
 * overall state as a traffic light, the components that are not operational and the
 * incidents still open. Needs no key.
 */
final class StatusPageClient
{
    public const SUMMARY_URL = 'https://status.claude.com/api/v2/summary.json';
    public const PAGE_URL = 'https://status.claude.com';

    /** Statuspage indicator => traffic light of the tile. */
    private const LIGHTS = [
        'none' => 'ok',
        'minor' => 'warn',
        'maintenance' => 'warn',
        'major' => 'error',
        'critical' => 'error',
    ];

    private const COMPONENT_LABELS = [
        'degraded_performance' => 'eingeschränkt',
        'partial_outage' => 'teilweise gestört',
        'major_outage' => 'ausgefallen',
        'under_maintenance' => 'Wartung',
    ];

    public function __construct(
        private readonly HttpClientInterface $httpClient,
    )
    {
    }

    /**
     * @return array{light: string, description: string, url: string, components: list<array{name: string, status: string, label: string}>, incidents: list<array{name: string, impact: string, status: string, url: string, updatedAt: int|null}>}
     *
     * @throws AiUsageException
     */
    public function fetch(): array
    {
        try {
            $response = $this->httpClient->request('GET', self::SUMMARY_URL, ['timeout' => 10, 'max_duration' => 15]);
            $status = $response->getStatusCode();
            $summary = $response->toArray(false);
        } catch (ExceptionInterface $exception) {
            throw new AiUsageException('Die Statusseite von Anthropic ist nicht erreichbar: ' . $exception->getMessage(), 0, $exception);
        }
        if ($status !== 200) {
            throw new AiUsageException(sprintf('Die Statusseite von Anthropic antwortet mit Fehler %d.', $status));
        }

        return self::describe($summary);
    }

    /**
     * @param array<string, mixed> $summary summary.json of a Statuspage
     * @return array<string, mixed>
     */
    public static function describe(array $summary): array
    {
        $overall = is_array($summary['status'] ?? null) ? $summary['status'] : [];
        $indicator = (string)($overall['indicator'] ?? '');

        $components = [];
        foreach (is_array($summary['components'] ?? null) ? $summary['components'] : [] as $component) {
            // groups only bundle other components - their own state repeats the worst child
            if (!is_array($component) || ($component['group'] ?? false) === true) {
                continue;
            }
            $state = (string)($component['status'] ?? 'operational');
            if ($state === 'operational' || !isset(self::COMPONENT_LABELS[$state])) {
                continue;
            }
            $components[] = ['name' => (string)($component['name'] ?? ''), 'status' => $state, 'label' => self::COMPONENT_LABELS[$state]];
        }

        $incidents = [];
        foreach (is_array($summary['incidents'] ?? null) ? $summary['incidents'] : [] as $incident) {
            if (!is_array($incident) || in_array($incident['status'] ?? '', ['resolved', 'postmortem'], true)) {
                continue;
            }
            $link = (string)($incident['shortlink'] ?? '');
            $updated = strtotime((string)($incident['updated_at'] ?? ''));
            $incidents[] = [
                'name' => (string)($incident['name'] ?? ''),
                'impact' => (string)($incident['impact'] ?? 'none'),
                'status' => (string)($incident['status'] ?? ''),
                // the link ends up in an href - only a link to the web
                'url' => preg_match('#^https://#', $link) === 1 ? $link : self::PAGE_URL,
                'updatedAt' => $updated === false ? null : $updated,
            ];
        }

        $light = self::LIGHTS[$indicator] ?? 'unknown';
        // an open incident that the overall state does not show yet still deserves yellow
        if ($light === 'ok' && ($components !== [] || $incidents !== [])) {
            $light = 'warn';
        }

        return [
            'light' => $light,
            'description' => (string)($overall['description'] ?? ''),
            'url' => self::PAGE_URL,
            'components' => $components,
            'incidents' => $incidents,
        ];
    }
}
