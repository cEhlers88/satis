<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Ai\Usage;

use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageReport;
use PHPUnit\Framework\TestCase;

final class AiUsageReportTest extends TestCase
{
    private static function day(string $date, int $input, int $output, ?float $cost, array $models = []): array
    {
        return ['date' => $date, 'input' => $input, 'output' => $output, 'cacheRead' => 0, 'cacheWrite' => 0, 'cost' => $cost, 'models' => $models];
    }

    public function testTodayAndMonthAreSplitAtTheMonthBorder(): void
    {
        $report = AiUsageReport::build([
            self::day('2026-10-30', 1000, 500, 1.5),
            self::day('2026-11-01', 200, 100, 0.25, ['claude-opus-5-5' => 300]),
            self::day('2026-11-06', 50, 50, 0.1, ['claude-opus-5-5' => 60, 'claude-haiku-5-5' => 40]),
        ], new \DateTimeImmutable('2026-11-06 09:00:00 UTC'));

        self::assertSame(100, $report['today']['tokens']);
        self::assertSame(0.1, $report['today']['cost']);
        self::assertSame(400, $report['month']['tokens']);
        self::assertSame(0.35, $report['month']['cost']);
        self::assertSame('11/2026', $report['monthLabel']);
        // 0.35 over 6 of 30 days
        self::assertSame(1.75, $report['forecast']);
        self::assertNull($report['budget']);
        self::assertTrue($report['costKnown']);
    }

    public function testChartCoversTheLastTwoWeeksEndingToday(): void
    {
        $report = AiUsageReport::build([
            self::day('2026-11-05', 300, 100, null),
            self::day('2026-11-06', 100, 100, null),
        ], new \DateTimeImmutable('2026-11-06 23:59:00 UTC'));

        self::assertCount(AiUsageReport::CHART_DAYS, $report['chart']);
        self::assertSame('2026-10-24', $report['chart'][0]['date']);
        $last = $report['chart'][AiUsageReport::CHART_DAYS - 1];
        self::assertSame('2026-11-06', $last['date']);
        self::assertTrue($last['isToday']);
        self::assertSame(0.5, $last['ratio']);
        self::assertSame(1.0, $report['chart'][AiUsageReport::CHART_DAYS - 2]['ratio']);
        self::assertFalse($report['costKnown']);
        self::assertNull($report['forecast']);
    }

    public function testBudgetGivesTheRemainingAmountAndWarnsAboutTheForecast(): void
    {
        $report = AiUsageReport::build([
            self::day('2026-11-01', 10, 10, 20.0),
            self::day('2026-11-02', 10, 10, 10.0),
        ], new \DateTimeImmutable('2026-11-03 12:00:00 UTC'), 100.0);

        self::assertSame([
            'amount' => 100.0,
            'known' => true,
            'spent' => 30.0,
            'remaining' => 70.0,
            'usedRatio' => 0.3,
            'exceeded' => false,
            // 30 in 3 days -> 300 for November
            'forecastExceeds' => true,
        ], $report['budget']);
    }

    public function testAnExceededBudgetLeavesNothing(): void
    {
        $report = AiUsageReport::build([self::day('2026-11-01', 1, 1, 120.0)], new \DateTimeImmutable('2026-11-01 08:00 UTC'), 100.0);

        self::assertSame(0.0, $report['budget']['remaining']);
        self::assertSame(1.0, $report['budget']['usedRatio']);
        self::assertTrue($report['budget']['exceeded']);
    }

    public function testTopModelsAreSortedByTokensWithTheirShare(): void
    {
        $report = AiUsageReport::build([
            self::day('2026-11-01', 0, 0, null, ['a' => 10, 'b' => 30]),
            self::day('2026-11-02', 0, 0, null, ['a' => 10, 'c' => 50, 'd' => 1]),
        ], new \DateTimeImmutable('2026-11-02 UTC'));

        self::assertSame(['c', 'b', 'a'], array_column($report['topModels'], 'model'));
        self::assertSame([50, 30, 20], array_column($report['topModels'], 'tokens'));
    }

    public function testABudgetWithoutCostDataIsNotShownAsUntouched(): void
    {
        $report = AiUsageReport::build([self::day('2026-11-01', 500, 100, null)], new \DateTimeImmutable('2026-11-02 UTC'), 100.0);

        self::assertFalse($report['budget']['known']);
        self::assertNull($report['budget']['remaining']);
        self::assertNull($report['budget']['usedRatio']);
        self::assertFalse($report['budget']['exceeded']);
    }
}
