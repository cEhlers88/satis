<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Ai\Usage;

use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageException;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\StatusPageClient;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpClient\MockHttpClient;
use Symfony\Component\HttpClient\Response\MockResponse;

final class StatusPageClientTest extends TestCase
{
    public function testDegradedComponentsAndOpenIncidentsAreListed(): void
    {
        $status = StatusPageClient::describe([
            'status' => ['indicator' => 'minor', 'description' => 'Minor Service Outage'],
            'components' => [
                ['name' => 'Claude API', 'status' => 'degraded_performance', 'group' => false],
                ['name' => 'claude.ai', 'status' => 'operational'],
                ['name' => 'Group', 'status' => 'major_outage', 'group' => true],
            ],
            'incidents' => [
                ['name' => 'Elevated errors on Opus', 'status' => 'investigating', 'impact' => 'minor', 'shortlink' => 'https://stspg.io/abc', 'updated_at' => '2026-11-06T09:00:00Z'],
                ['name' => 'Old one', 'status' => 'resolved', 'impact' => 'major'],
                ['name' => 'Odd link', 'status' => 'identified', 'shortlink' => 'javascript:alert(1)'],
            ],
        ]);

        self::assertSame('warn', $status['light']);
        self::assertSame([['name' => 'Claude API', 'status' => 'degraded_performance', 'label' => 'eingeschränkt']], $status['components']);
        self::assertSame(['Elevated errors on Opus', 'Odd link'], array_column($status['incidents'], 'name'));
        self::assertSame('https://stspg.io/abc', $status['incidents'][0]['url']);
        self::assertSame(StatusPageClient::PAGE_URL, $status['incidents'][1]['url']);
        self::assertSame(strtotime('2026-11-06T09:00:00Z'), $status['incidents'][0]['updatedAt']);
    }

    public function testMajorIsRedAndAnUnknownIndicatorIsUnknown(): void
    {
        self::assertSame('error', StatusPageClient::describe(['status' => ['indicator' => 'critical']])['light']);
        self::assertSame('unknown', StatusPageClient::describe([])['light']);
        // nothing reported overall, but an incident is open
        self::assertSame('warn', StatusPageClient::describe([
            'status' => ['indicator' => 'none'],
            'incidents' => [['name' => 'x', 'status' => 'monitoring']],
        ])['light']);
    }

    public function testAFailingPageThrows(): void
    {
        $this->expectException(AiUsageException::class);

        (new StatusPageClient(new MockHttpClient(new MockResponse('down', ['http_code' => 503]))))->fetch();
    }
}
