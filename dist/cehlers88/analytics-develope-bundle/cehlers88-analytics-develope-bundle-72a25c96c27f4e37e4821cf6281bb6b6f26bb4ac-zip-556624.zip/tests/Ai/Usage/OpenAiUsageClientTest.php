<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Ai\Usage;

use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageException;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\OpenAiUsageClient;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpClient\MockHttpClient;
use Symfony\Component\HttpClient\Response\MockResponse;

final class OpenAiUsageClientTest extends TestCase
{
    public function testCachedInputIsTakenOutOfTheInputTokens(): void
    {
        $urls = [];
        $http = new MockHttpClient(function (string $method, string $url, array $options) use (&$urls): MockResponse {
            $urls[] = $url;
            self::assertSame(['authorization: Bearer sk-admin-1'], $options['normalized_headers']['authorization']);

            if (str_starts_with($url, OpenAiUsageClient::USAGE_ENDPOINT)) {
                return new MockResponse(json_encode([
                    'data' => [[
                        'start_time' => 1762387200, // 2025-11-06 00:00 UTC
                        'results' => [['model' => 'gpt-5', 'input_tokens' => 1000, 'input_cached_tokens' => 400, 'output_tokens' => 50]],
                    ]],
                    'has_more' => false,
                ]));
            }

            return new MockResponse(json_encode([
                'data' => [['start_time' => 1762387200, 'results' => [['amount' => ['value' => 0.42, 'currency' => 'usd']]]]],
                'has_more' => false,
            ]));
        });

        $days = (new OpenAiUsageClient($http))->fetchDays('sk-admin-1', new \DateTimeImmutable('2025-11-01 UTC'));

        self::assertSame([
            ['date' => '2025-11-06', 'input' => 600, 'output' => 50, 'cacheRead' => 400, 'cacheWrite' => 0, 'cost' => 0.42, 'models' => ['gpt-5' => 1050]],
        ], $days);
        self::assertStringContainsString('start_time=1761955200', $urls[0]);
    }

    public function testAnUnauthorizedKeyNamesTheAdminKey(): void
    {
        $http = new MockHttpClient(new MockResponse('{"error":{"message":"bad"}}', ['http_code' => 401]));

        $this->expectException(AiUsageException::class);
        $this->expectExceptionMessage('sk-admin-');

        (new OpenAiUsageClient($http))->fetchDays('sk-proj-x', new \DateTimeImmutable());
    }
}
