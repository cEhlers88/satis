<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Ai\Usage;

use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AiUsageException;
use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\AnthropicUsageClient;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpClient\MockHttpClient;
use Symfony\Component\HttpClient\Response\MockResponse;

final class AnthropicUsageClientTest extends TestCase
{
    public function testUsageAndCostAreSummedPerDayAndModel(): void
    {
        $requests = [];
        $http = new MockHttpClient(function (string $method, string $url, array $options) use (&$requests): MockResponse {
            $requests[] = ['url' => $url, 'headers' => $options['normalized_headers'] ?? []];

            if (str_starts_with($url, AnthropicUsageClient::USAGE_ENDPOINT)) {
                if (!str_contains($url, 'page=next1')) {
                    return new MockResponse(json_encode([
                        'data' => [[
                            'starting_at' => '2026-11-05T00:00:00Z',
                            'ending_at' => '2026-11-06T00:00:00Z',
                            'results' => [
                                ['model' => 'claude-opus-5-5', 'uncached_input_tokens' => 100, 'output_tokens' => 40, 'cache_read_input_tokens' => 1000, 'cache_creation' => ['ephemeral_5m_input_tokens' => 5, 'ephemeral_1h_input_tokens' => 7]],
                                ['model' => 'claude-haiku-5-5', 'uncached_input_tokens' => 10, 'output_tokens' => 2, 'cache_read_input_tokens' => 0, 'cache_creation' => null],
                            ],
                        ]],
                        'has_more' => true,
                        'next_page' => 'next1',
                    ]));
                }

                return new MockResponse(json_encode([
                    'data' => [[
                        'starting_at' => '2026-11-06T00:00:00Z',
                        'results' => [['model' => 'claude-opus-5-5', 'uncached_input_tokens' => 1, 'output_tokens' => 1]],
                    ]],
                    'has_more' => false,
                    'next_page' => null,
                ]));
            }

            return new MockResponse(json_encode([
                'data' => [
                    ['starting_at' => '2026-11-05T00:00:00Z', 'results' => [['amount' => '123.5', 'currency' => 'USD'], ['amount' => '76.5', 'currency' => 'USD']]],
                ],
                'has_more' => false,
            ]));
        });

        $days = (new AnthropicUsageClient($http))->fetchDays('sk-ant-admin01-test', new \DateTimeImmutable('2026-11-01 15:00 UTC'));

        self::assertSame([
            ['date' => '2026-11-05', 'input' => 110, 'output' => 42, 'cacheRead' => 1000, 'cacheWrite' => 12, 'cost' => 2.0, 'models' => ['claude-opus-5-5' => 1152, 'claude-haiku-5-5' => 12]],
            ['date' => '2026-11-06', 'input' => 1, 'output' => 1, 'cacheRead' => 0, 'cacheWrite' => 0, 'cost' => null, 'models' => ['claude-opus-5-5' => 2]],
        ], $days);

        self::assertCount(3, $requests);
        self::assertStringContainsString('starting_at=2026-11-01T00%3A00%3A00Z', $requests[0]['url']);
        self::assertStringContainsString('group_by[]=model', $requests[0]['url']);
        self::assertStringContainsString('bucket_width=1d', $requests[0]['url']);
        self::assertSame(['x-api-key: sk-ant-admin01-test'], $requests[0]['headers']['x-api-key']);
        self::assertStringStartsWith(AnthropicUsageClient::COST_ENDPOINT . '?', $requests[2]['url']);
    }

    public function testARegularApiKeyIsRefusedBeforeAnyRequest(): void
    {
        $http = new MockHttpClient(static fn() => throw new \LogicException('no request expected'));

        $this->expectException(AiUsageException::class);
        $this->expectExceptionMessage('Admin API Key');

        (new AnthropicUsageClient($http))->fetchDays('sk-ant-api03-abc', new \DateTimeImmutable());
    }

    public function testAForbiddenAnswerExplainsWhichKeyIsNeeded(): void
    {
        $http = new MockHttpClient(new MockResponse(json_encode(['error' => ['type' => 'permission_error', 'message' => 'nope']]), ['http_code' => 403]));

        try {
            (new AnthropicUsageClient($http))->fetchDays('sk-ant-admin01-x', new \DateTimeImmutable());
            self::fail('expected an exception');
        } catch (AiUsageException $exception) {
            self::assertStringContainsString('403', $exception->getMessage());
            self::assertStringNotContainsString('sk-ant-admin01-x', $exception->getMessage());
        }
    }
}
