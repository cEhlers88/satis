<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\Ai\Usage;

use Cehlers88\AnalyticsDevelopeBundle\Ai\Usage\ClaudeCodeReport;
use PHPUnit\Framework\TestCase;

final class ClaudeCodeReportTest extends TestCase
{
    private static function record(array $actor, int $sessions, int $added, int $removed, int $commits, int $prs, array $edits, int $costCents, int $tokens = 0): array
    {
        return [
            'actor' => $actor,
            'core_metrics' => [
                'num_sessions' => $sessions,
                'lines_of_code' => ['added' => $added, 'removed' => $removed],
                'commits_by_claude_code' => $commits,
                'pull_requests_by_claude_code' => $prs,
            ],
            'tool_actions' => ['edit_tool' => ['accepted' => $edits[0], 'rejected' => $edits[1]], 'write_tool' => ['accepted' => 1, 'rejected' => 0]],
            'model_breakdown' => [[
                'model' => 'claude-opus-5-5',
                'tokens' => ['input' => $tokens, 'output' => 0, 'cache_read' => 0, 'cache_creation' => 0],
                'estimated_cost' => ['currency' => 'USD', 'amount' => $costCents],
            ]],
        ];
    }

    public function testPeriodTodayAndTopActorsAreSummedUp(): void
    {
        $anna = ['type' => 'user_actor', 'email_address' => 'anna@example.com'];
        $ci = ['type' => 'api_actor', 'api_key_name' => 'ci-key'];

        $report = ClaudeCodeReport::build([
            '2026-11-05' => [self::record($anna, 3, 100, 20, 2, 1, [8, 2], 250, 1000)],
            '2026-11-06' => [
                // one actor, two terminals: two records of the same day
                self::record($anna, 1, 10, 5, 0, 0, [1, 1], 50),
                self::record($anna, 2, 30, 0, 1, 0, [3, 0], 100),
                self::record($ci, 1, 5, 0, 0, 0, [0, 0], 1000),
            ],
        ], new \DateTimeImmutable('2026-11-06 12:00 UTC'));

        self::assertSame(7, $report['period']['sessions']);
        self::assertSame(145, $report['period']['linesAdded']);
        self::assertSame(25, $report['period']['linesRemoved']);
        self::assertSame(3, $report['period']['commits']);
        self::assertSame(1, $report['period']['pullRequests']);
        // edit 12 + write 4 accepted, 3 rejected
        self::assertSame(16, $report['period']['accepted']);
        self::assertSame(round(16 / 19, 4), $report['period']['acceptanceRate']);
        self::assertSame(14.0, $report['period']['cost']);
        self::assertSame(1000, $report['period']['tokens']);

        self::assertSame(4, $report['today']['sessions']);
        self::assertSame(11.5, $report['today']['cost']);

        self::assertSame(['ci-key', 'anna@example.com'], array_column($report['topActors'], 'name'));
        self::assertSame([10.0, 4.0], array_column($report['topActors'], 'cost'));
        self::assertSame(6, $report['topActors'][1]['sessions']);
        self::assertSame(2, $report['actorCount']);
    }

    public function testNoRecordsGiveZerosAndNoAcceptanceRate(): void
    {
        $report = ClaudeCodeReport::build([], new \DateTimeImmutable('2026-11-06 UTC'));

        self::assertSame(0, $report['period']['sessions']);
        self::assertNull($report['period']['acceptanceRate']);
        self::assertSame([], $report['topActors']);
    }
}
