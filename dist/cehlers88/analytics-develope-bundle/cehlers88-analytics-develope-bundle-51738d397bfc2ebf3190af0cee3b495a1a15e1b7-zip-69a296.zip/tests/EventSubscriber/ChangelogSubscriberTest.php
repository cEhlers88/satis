<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\Tests\EventSubscriber;

use Cehlers88\AnalyticsCore\Event\Changelog\AddChangelogEntriesEvent;
use Cehlers88\AnalyticsCore\Event\Changelog\CollectChangelogTargetsEvent;
use Cehlers88\AnalyticsCore\Event\Tool\CollectToolsEvent;
use Cehlers88\AnalyticsDevelopeBundle\Changelog\ChangelogStorage;
use Cehlers88\AnalyticsDevelopeBundle\EventSubscriber\ChangelogSubscriber;
use Cehlers88\AnalyticsDevelopeBundle\Tests\Changelog\ChangelogStorageTest;
use PHPUnit\Framework\TestCase;

class ChangelogSubscriberTest extends TestCase
{
    private string $directory;
    private ChangelogStorage $storage;
    private ChangelogSubscriber $subscriber;

    protected function setUp(): void
    {
        $this->directory = sys_get_temp_dir() . '/changelog-subscriber-test-' . bin2hex(random_bytes(4));
        $this->storage = new ChangelogStorage($this->directory);
        $this->subscriber = new ChangelogSubscriber($this->storage);
    }

    protected function tearDown(): void
    {
        ChangelogStorageTest::removeDirectory($this->directory);
    }

    public function testItBringsTheToolAndTheTarget(): void
    {
        $tools = new CollectToolsEvent();
        $this->subscriber->onCollectTools($tools);
        $targets = new CollectChangelogTargetsEvent();
        $this->subscriber->onCollectChangelogTargets($targets);

        $this->assertSame(['changelogEditor'], array_column($tools->getTools(), 'name'));
        $this->assertSame([ChangelogSubscriber::TARGET => 'Changelog'], $targets->getTargets());
    }

    public function testItTakesEntriesMeantForItOrForAnyChangelog(): void
    {
        foreach ([null, ChangelogSubscriber::TARGET] as $target) {
            $event = new AddChangelogEntriesEvent(['- [x] Done ' . ($target ?? 'any')], $target, 'Notiz „Test“', 'someone');
            $this->subscriber->onAddChangelogEntries($event);

            $this->assertTrue($event->isHandled());
            $this->assertSame(ChangelogSubscriber::TARGET, $event->getAcceptedBy());
            $this->assertSame(1, $event->getAcceptedCount());
        }
        $this->assertSame("- Done any\n- Done develope.changelog\n", $this->storage->read(ChangelogStorage::CURRENT)['content']);
    }

    public function testItLeavesEntriesForOtherChangelogsAndTakenOnesAlone(): void
    {
        $other = new AddChangelogEntriesEvent(['Elsewhere'], 'another.changelog');
        $this->subscriber->onAddChangelogEntries($other);

        $taken = new AddChangelogEntriesEvent(['Taken']);
        $taken->accept('another.changelog', 1);
        $this->subscriber->onAddChangelogEntries($taken);

        $this->assertFalse($other->isHandled());
        $this->assertSame('another.changelog', $taken->getAcceptedBy());
        $this->assertSame('', $this->storage->read(ChangelogStorage::CURRENT)['content']);
    }
}
