<?php

declare(strict_types=1);

namespace Cehlers88\AnalyticsDevelopeBundle\EventSubscriber;

use Cehlers88\AnalyticsCore\Event\Changelog\AddChangelogEntriesEvent;
use Cehlers88\AnalyticsCore\Event\Changelog\CollectChangelogTargetsEvent;
use Cehlers88\AnalyticsCore\Event\Tool\CollectToolsEvent;
use Cehlers88\AnalyticsDevelopeBundle\Changelog\ChangelogStorage;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * How the bundle takes part in the rest of the installation - through the events of
 * AnalyticsCore only, no class of the application or of another bundle is known here:
 *  - it brings the Changelog Editor to the tools page (CollectToolsEvent),
 *  - it says it keeps a changelog (CollectChangelogTargetsEvent),
 *  - and it takes the entries others move there - the done tasks of a note (AddChangelogEntriesEvent).
 */
final class ChangelogSubscriber implements EventSubscriberInterface
{
    public const TARGET = 'develope.changelog';

    public function __construct(
        private readonly ChangelogStorage $storage,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            CollectToolsEvent::class => 'onCollectTools',
            CollectChangelogTargetsEvent::class => 'onCollectChangelogTargets',
            AddChangelogEntriesEvent::class => 'onAddChangelogEntries',
        ];
    }

    public function onCollectTools(CollectToolsEvent $event): void
    {
        $event->addTool([
            'name' => 'changelogEditor',
            'title' => 'Changelog Editor',
            'description' => 'Read and write the changelog - the current one and the history of past releases, with images',
            'categories' => ['Development', 'Workspace'],
            'teaser' => 'teaser/changelogEditor.html.twig',
            'template' => 'changelogEditor.html.twig',
            'scripts' => ['script/changelogEditor.js.twig'],
            'styles' => ['style/changelogEditor.html.twig'],
            'routes' => ['analytics_develope_changelog_'],
        ]);
    }

    public function onCollectChangelogTargets(CollectChangelogTargetsEvent $event): void
    {
        $event->addTarget(self::TARGET, 'Changelog');
    }

    public function onAddChangelogEntries(AddChangelogEntriesEvent $event): void
    {
        if ($event->isHandled() || ($event->target !== null && $event->target !== self::TARGET)) {
            return;
        }
        $event->accept(self::TARGET, $this->storage->appendEntries($event->entries));
    }
}
