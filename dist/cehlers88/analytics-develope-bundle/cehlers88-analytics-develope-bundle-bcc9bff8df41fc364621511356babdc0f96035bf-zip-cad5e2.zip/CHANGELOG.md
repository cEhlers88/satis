# Changelog

## [0.1.2](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.1...v0.1.2) (2026-01-20)


### Miscellaneous Chores

* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([cf67e17](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/cf67e17329ebd56e001bb3102676a4439e6ad844))
* **deps:** update dependency cehlers88/analytics-core to v0.1.3 ([f2aae12](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/f2aae12077ba3b0790fb23eadd527cd40e4d85c8))

## [0.1.1](https://github.com/cEhlers88/AnalyticsDevelopeBundle/compare/v0.1.0...v0.1.1) (2026-01-20)


### Miscellaneous Chores

* implement release-please ([c39c6af](https://github.com/cEhlers88/AnalyticsDevelopeBundle/commit/c39c6af44469b9065e75f992998cbce6b579bce4))
