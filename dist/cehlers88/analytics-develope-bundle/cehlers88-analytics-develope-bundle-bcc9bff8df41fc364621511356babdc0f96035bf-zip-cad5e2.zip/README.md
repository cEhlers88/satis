# Analytics Develope Bundle

A Symfony bundle for development management within the Analytics system.

## Description

The Analytics Develope Bundle provides development tools and configuration management for the Analytics platform. It enables developers to manage git repositories and configure development settings through the Analytics interface.

## Requirements

- PHP 7.4 or higher
- Symfony 5.x or higher
- [cehlers88/analytics-core](https://github.com/cEhlers88/AnalyticsCore) ^0.1

## Installation

Install the bundle using Composer:

```bash
composer require cehlers88/analytics-develope-bundle
```

## Configuration

The bundle provides configuration options for managing development repositories:

### General Configuration

The bundle includes a general configuration group (`developeBundle.general`) that allows you to:

- Define self-managing repositories
- Configure repository types (Application or Plugin)
- Link git repositories to the Analytics system

### Services

The bundle automatically registers its services when Symfony's autowiring is enabled. Configuration is located in `src/Resources/config/services.yaml`.

## Features

### Git Repository Management

The bundle provides a `GitRepository` custom object that allows you to:

- Store repository path information
- Manage git repositories through the Analytics interface
- Associate repositories with the Analytics system

### Configuration Groups

- **General Configuration Group**: Manage general developer settings including repository configurations

## Usage

Once installed and configured, the bundle integrates seamlessly with the Analytics platform. Access the development configuration through the Analytics interface menu item "Dokumentverwaltung".

## Bundle Information

- **Version**: 1.0.0
- **Type**: Symfony Bundle
- **License**: Proprietary
- **Namespace**: `Cehlers88\AnalyticsDevelopeBundle`

## Author

**Christoph Ehlers**  
Email: webmaster@c-ehlers.de

## License

This bundle is proprietary software.
